"""Testing-only runner for ordered form and past-match difficulty inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_role_minutes, score_sequence
from app.research.score_feature_compare import compare_features


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "games", "control", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    raw = args.games.read_bytes()
    with np.load(args.stats_cache) as stored:
        numeric = stored["x"]
        stat_key = str(stored["key"])
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + Path(score_sequence.__file__).read_bytes()
        + Path(score_role_minutes.__file__).read_bytes()
    ).hexdigest()
    path = args.cache / "sequence_features.npz"
    cached = np.load(path) if path.exists() else None
    if cached is not None and str(cached["key"]) == key:
        extra, names = cached["x"], cached["names"].tolist()
        cached.close()
    else:
        if cached is not None:
            cached.close()
        games = [json.loads(s) for s in raw.decode("utf-8").splitlines() if s.strip()]
        roles, _ = score_role_minutes.role_arrays(games, source["rows"])
        roles = np.where(np.array([r["cohort"] == "start" for r in source["rows"]]), roles, 9)
        extra, names = score_sequence.sequence_features(source["rows"], source["features"], roles)
        np.savez_compressed(path, key=key, x=extra, names=names)
    groups = {
        "ordered_observations": np.array([not n.startswith(("state_", "trend_")) for n in names]),
        "ordered_states_trends": np.ones(len(names), dtype=bool),
    }
    metadata = {
        "rows": len(extra),
        "newInputs": len(names),
        "orderedInputs": int(groups["ordered_observations"].sum()),
        "availabilityHours": 48,
        "scoreStates": "below35,35to60,60plus",
        "ordinaryStates": "negative,0to15,15plus",
        "transitionPriorCases": 5,
        "scope": "Testing only",
    }
    print("Sequence inputs " + json.dumps(metadata), flush=True)
    compare_features(args, source, numeric, stat_key, extra, names, groups, key, metadata)


if __name__ == "__main__":
    main()
