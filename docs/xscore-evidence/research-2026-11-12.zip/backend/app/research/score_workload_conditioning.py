"""Testing only: separate observed European load from combined observed load."""

from __future__ import annotations

import numpy as np

from app.research import score_observed_workload as workload


def feature_groups(names):
    if list(names) != list(workload.NAMES):
        raise ValueError("Observed workload feature names differ")
    return {
        "euro": np.array([n.startswith("load_euro_") for n in names]),
        "covered": np.ones(len(names), dtype=bool),
    }


def recent_europe(x, names):
    feature_groups(names)
    if x.ndim != 2 or x.shape[1] != len(names):
        raise ValueError("Observed workload shape differs")
    return (x[:, names.index("load_euro_player_28_known_rows")] > 0) | (
        x[:, names.index("load_euro_club_14_observed_fixtures")] > 0
    )


def scoped_prediction(candidate, control, coverage, scope):
    candidate, control, coverage = np.asarray(candidate), np.asarray(control), np.asarray(coverage)
    if candidate.shape != control.shape or candidate.shape != coverage.shape or coverage.dtype != bool:
        raise ValueError("Observed workload forecast coverage differs")
    if scope == "all":
        return candidate.copy()
    if scope == "recent_euro":
        return np.where(coverage, candidate, control)
    raise ValueError("Unknown observed workload decision scope")
