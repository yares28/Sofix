import copy

import numpy as np

from app.research.score_player_context import link_names, player_metrics, recent_features, stat_verified_links


def test_fixture_names_must_resolve_uniquely_and_bijectively():
    candidates = ["john-smith", "john-smith-1995-01-01", "luis-javier-suarez-charris"]
    links, missing = link_names(["John Smith", "Luis Suarez"], candidates, {})
    assert links == {("luis", "suarez"): "luis-javier-suarez-charris"}
    assert missing == 1


def test_source_model_chance_fields_never_fill_missing_provider_values():
    shot = {"xg": 0.99, "xg_fotmob": None, "xg_understat": None, "x": 90, "y": 50, "sit": "Open Play"}
    before = player_metrics([shot], [], "FW", 90)
    shot["xg"] = 0.01
    after = player_metrics([shot], [], "FW", 90)
    assert np.isnan(before["chance_xg90"])
    assert before["chance_provider_fraction"] == 0
    for key in before:
        np.testing.assert_equal(before[key], after[key])


def test_observed_zero_and_missing_shot_stream_are_distinct():
    zero = player_metrics([], [], "GK", 90)
    missing = player_metrics(None, [], "GK", 90)
    assert zero["chance_xg90"] == 0
    assert zero["chance_shots90"] == 0
    assert np.isnan(missing["chance_xg90"])
    assert np.isnan(missing["chance_shots90"])


def test_partial_provider_coverage_keeps_full_total_unknown():
    shots = [{"xg_fotmob": 0.2, "xg_understat": None}, {"xg_fotmob": None, "xg_understat": None}]
    values = player_metrics(shots, [], "FW", 90)
    assert np.isnan(values["chance_xg90"])
    assert values["chance_known_xg90"] == 0.2
    assert values["chance_provider_fraction"] == 0.5


def test_pass_origins_distinguish_advanced_central_and_deep_wide_usage():
    advanced = player_metrics([], [{"x": 80, "y": 50, "ex": 90, "ey": 50, "ok": True, "key": True}], "AMC", 90)
    deep = player_metrics([], [{"x": 30, "y": 5, "ex": 40, "ey": 10, "ok": True, "key": False}], "DL", 90)
    assert advanced["usage_pass_x"] > deep["usage_pass_x"]
    assert advanced["usage_pass_edge"] < deep["usage_pass_edge"]
    assert advanced["usage_box_passes90"] == 1


def observation(date, metrics, cohort="start"):
    return {"date": date, "player": "p", "cohort": cohort, "club": "club", "minutes": 90, "values": metrics}


def test_current_and_same_week_observations_cannot_enter_recent_features():
    old = observation("2025-10-01T20:00:00Z", player_metrics([], [], "MC", 90))
    later = observation("2025-10-11T20:00:00Z", player_metrics([], [], "FW", 90))
    row = {"date": "2025-10-12T20:00:00Z", "player": "p", "cohort": "start", "game": "g"}
    a, names, _ = recent_features([row], [old, later], {"g": {"players": {"p": {"team": "club"}}}})
    changed = copy.deepcopy(later)
    changed["values"]["chance_xg90"] = 100
    b, _, _ = recent_features([row], [old, changed], {"g": {"players": {"p": {"team": "club"}}}})
    np.testing.assert_array_equal(a, b)
    assert a[0, names.index("same_3_chance_xg90_mean")] == 0


def test_substitutes_keep_their_own_history_and_can_use_past_start_usage():
    old = observation("2025-10-01T20:00:00Z", player_metrics([], [], "AMC", 90))
    row = {"date": "2025-10-12T20:00:00Z", "player": "p", "cohort": "bench", "game": "g"}
    x, names, _ = recent_features([row], [old], {"g": {"players": {"p": {"team": "club"}}}})
    assert x[0, names.index("same_3_source_games")] == 0
    assert np.isnan(x[0, names.index("same_3_chance_xg90_mean")])
    assert x[0, names.index("all_3_chance_xg90_mean")] == 0


def test_zero_minutes_do_not_create_invented_per90_rates():
    values = player_metrics([], [], "Sub", 0)
    assert np.isnan(values["chance_shots90"])


def test_nickname_requires_unique_name_anchor_matching_passes_and_clock():
    people = [({"name": "Alex Pozo", "mins": 66, "off": 66, "g": 0}, True)]
    players = {"alejandro-pozo-pozo": {"started": True, "mins": 66, "stats": {"accurate_pass": [2, 0.16]}}}
    events = {("alex", "pozo"): [{"ok": True}, {"ok": True}]}
    assert stat_verified_links(people, players, {}, {}, events, {}, 96) == {("alex", "pozo"): "alejandro-pozo-pozo"}
    players["alejandro-pozo-pozo"]["mins"] = 20
    assert stat_verified_links(people, players, {}, {}, events, {}, 96) == {}


def test_common_surname_or_zero_pass_count_cannot_force_a_link():
    people = [({"name": "Alex Smith", "mins": 90, "off": None}, True)]
    players = {
        p: {"started": True, "mins": 90, "stats": {"accurate_pass": [2, 0.16]}} for p in ("john-smith", "peter-smith")
    }
    events = {("alex", "smith"): [{"ok": True}, {"ok": True}]}
    assert stat_verified_links(people, players, {}, {}, events, {}, 90) == {}
    del players["peter-smith"]
    players["john-smith"]["stats"]["accurate_pass"] = [0, 0]
    assert stat_verified_links(people, players, {}, {}, events, {}, 90) == {}


def test_unknown_match_end_cannot_validate_a_full_game_nickname_link():
    people = [({"name": "Alex Pozo", "mins": 96, "off": None}, True)]
    players = {"alejandro-pozo-pozo": {"started": True, "mins": 90, "stats": {"accurate_pass": [2, 0.16]}}}
    events = {("alex", "pozo"): [{"ok": True}, {"ok": True}]}
    assert stat_verified_links(people, players, {}, {}, events, {}, 96)
    people[0][0]["mins"] = 90
    assert stat_verified_links(people, players, {}, {}, events, {}, np.nan) == {}
