from app.research import score_pass_source_qualified as qualified


def record(count):
    return {
        "values": {**{f: 0.0 for f in qualified.PASS_FIELDS}, "chance_xg90": 0.2, "usage_role_depth": 0.4},
        "geometrySource": {"passStreamKnown": True, "passCount": count},
    }


def test_positive_native_passes_cannot_be_a_known_source_zero_and_parent_is_preserved():
    parent = record(0)
    result = qualified.qualify(parent, 5, True)
    assert all(result["values"][f] is None for f in qualified.PASS_FIELDS)
    assert result["values"]["chance_xg90"] == 0.2 and parent["values"]["usage_passes90"] == 0
    assert not result["passSourceQuality"]["known"]


def test_empty_unproven_side_is_unknown_even_if_native_player_zero():
    assert not qualified.qualify(record(0), 0, False)["passSourceQuality"]["known"]
    zero = qualified.qualify(record(0), 0, True)
    assert zero["passSourceQuality"]["known"] and zero["values"]["usage_passes90"] == 0


def test_source_attempts_below_native_completions_are_qualified_as_unknown():
    out = qualified.qualify(record(10), 11, True)
    assert out["passSourceQuality"]["reasons"] == ["native_completed_exceeds_source_attempts"]
