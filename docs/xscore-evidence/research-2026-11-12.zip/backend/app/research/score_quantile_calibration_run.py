"""Testing only: previous-period probability calibration of fixed 240-tree AA curves."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_quantile_calibration as calibration
from app.research import score_quantile_curve as curve
from app.research import score_quantile_curve_run as parent
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_modal_trees import CENTRES
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def identity(source, stat_key, old_match, old_stability, old_ordinary, parent_key, version, plan):
    modules = (calibration, curve, parent, flow, matched, controls, ordinary, stability, windows)
    return hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + parent_key
            + version
            + np.__version__
        ).encode()
        + Path(__file__).read_bytes()
        + plan.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()


def bundle(args, cohort, phase, x, rows, mask, old, key, parent_key):
    if phase == "warm2023":
        path = args.cache / f"{args.out.stem}_{cohort}_warm2023_e240.npz"
        expected = key
        if not path.exists():
            print(f"QUANTILE_CALIBRATION_WARM_FIT {cohort} all11models240", flush=True)
            aa, levels = (np.array([r[n] for r in rows]) for n in ("aa", "level"))
            parts, stats = curve.fit_quantiles(
                x,
                aa,
                levels,
                mask["fit"],
                mask["target"],
                old[0],
                old[2],
                240,
                args.cache,
                f"{args.out.stem}_{cohort}_warm2023",
                key,
            )
            np.savez_compressed(
                path,
                key=key,
                classes=old[0],
                probability=old[1],
                statistics=json.dumps(stats),
                **{f"q{q}": v for q, v in parts.items()},
            )
    else:
        path = args.cache / f"laliga_score_quantile_curve_{cohort}_{phase}_e240.npz"
        expected = parent_key
    with np.load(path) as f:
        stats = json.loads(str(f["statistics"]))
        parts = {q: f[f"q{q}"] for q in curve.QUANTILES}
        if (
            str(f["key"]) != expected
            or not np.array_equal(f["classes"], old[0])
            or not np.array_equal(f["probability"], old[1])
            or stats["iterations"] != 240
            or stats["fitCases"] != int(mask["fit"].sum())
            or stats["targetCases"] != int(mask["target"].sum())
            or any(
                v.shape != (int(mask["target"].sum()), len(old[0])) or not np.isfinite(v).all() for v in parts.values()
            )
        ):
            raise ValueError("Fixed quantile calibration bundle identity/masks/coverage differs")
    return parts, {
        "path": str(path),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "key": expected,
        "statistics": stats,
    }


def candidates():
    return [
        dict(spec=dict(group=group, prior=prior, tails=tails, scope=scope), gains=[], errors=[], counts=[], periods={})
        for group in ("global", "position", "position_level")
        for prior in (100, 500)
        for tails in ("clamp", "extrapolate")
        for scope in ("all", "defmid")
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda n: json.loads((args.out.parent / (n + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench, curve_report = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
            "laliga_score_quantile_curve",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench, curve_report)
    ):
        raise ValueError("Quantile calibration canonical source differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
        matched.validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Quantile calibration team feature identity differs")
        x = np.column_stack((base, f["x"]))
    if x.shape != (len(source["rows"]), 677):
        raise ValueError("Quantile calibration all-case design differs")
    parent_key = curve_report["implementationKey"]
    key = identity(
        source,
        stat_key,
        old_match,
        old_stability,
        old_ordinary,
        parent_key,
        sklearn.__version__,
        args.out.with_suffix(".plan.json"),
    )
    report = dict(
        scope="Testing-only fixed quantile probability calibration, no application changes",
        sourceKey=source["key"],
        implementationKey=key,
        parentKey=parent_key,
        evidenceLimit="Historical outcomes reused; exploratory, not fresh blind proof",
        cohorts={},
    )
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] == key:
            report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        masks, records = stability.phase_masks(rows), candidates()
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.out)
        previous = None
        audit = {}
        winner = best = None
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            parts, receipt = bundle(args, cohort, phase, x[keep], rows, mask, old, key, parent_key)
            audit[phase] = dict(fit=int(mask["fit"].sum()), target=int(target.sum()), quantileBundle=receipt)
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            if previous is None:
                previous = target_rows, old[0], parts
                continue
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            metric = measure(y[target], control)
            if metric != expected:
                raise ValueError("Quantile calibration frozen control differs")
            if phase == "later2026" and best is None:
                raise ValueError("Quantile calibration choice must be frozen before 2026")
            active = [best] if phase == "later2026" else records
            banks = {
                prior: calibration.fit_levels(*previous, mask["first"], prior)
                for prior in sorted({r["spec"]["prior"] for r in active})
            }
            audit[phase]["calibrationBanks"] = banks
            audit[phase]["control"] = metric
            masses = {}
            for record in active:
                spec = record["spec"]
                identity_ = spec["prior"], spec["group"], spec["tails"]
                if identity_ not in masses:
                    print(f"QUANTILE_CALIBRATION {cohort} {phase} {identity_}", flush=True)
                    mass = calibration.forecast_mass(
                        old[0], old[1], parts, positions[target], banks[spec["prior"]], spec["group"], spec["tails"]
                    )
                    masses[identity_] = windows.window_centres(mass, CENTRES)
                forecast = ordinary.scoped_prediction(masses[identity_], control, positions[target], spec["scope"])
                cm = measure(y[target], forecast)
                if phase == "later2026":
                    alternate = forecast
                else:
                    gain = cm["within7"] - metric["within7"]
                    record["gains"].append(gain)
                    record["errors"].append(cm["mae"])
                    record["counts"].append(len(forecast))
                    record["periods"][phase] = dict(gain=gain, metrics=cm)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = dict(
                    implementationKey=key,
                    winner=winner,
                    best=best,
                    candidates=records,
                    passingCandidates=sum(min(r["gains"]) > 0 for r in records),
                )
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
                    json.dumps(frozen, indent=2, allow_nan=False)
                )
                print(
                    "QUANTILE_CALIBRATION_FROZEN "
                    + json.dumps(dict(cohort=cohort, selected="candidate" if winner else "control", spec=best["spec"])),
                    flush=True,
                )
            previous = target_rows, old[0], parts
        prediction = alternate if winner else control.copy()
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        weeks = [r["week"] for r in target_rows]
        result = dict(
            selected="candidate" if winner else "control",
            winner=winner,
            candidate=best,
            candidateCount=len(records) + 1,
            earlierPeriods=audit,
            later=measure(y[target], prediction),
            candidateLater=measure(y[target], alternate),
            control=measure(y[target], control),
            candidateGain95=paired_interval(y[target], alternate, control, weeks),
            candidateGainedCorrect=int((h1 & ~h0).sum()),
            candidateLostCorrect=int((h0 & ~h1).sum()),
            positions={
                p: dict(
                    candidate=measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    control=measure(y[target][positions[target] == p], control[positions[target] == p]),
                )
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            controlReproduced=True,
        )
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(dict(cohort=cohort, selected=result["selected"], candidateLater=result["candidateLater"])),
            flush=True,
        )


if __name__ == "__main__":
    main()
