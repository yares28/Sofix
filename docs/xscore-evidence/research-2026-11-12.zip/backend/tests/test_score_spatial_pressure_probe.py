import hashlib
from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_spatial_pressure_probe as probe


def test_takeon_stream_keeps_true_zero_separate_from_unknown_and_ignores_inferred_endpoint():
    assert probe.stream_summary(None, "home")["known"] is False
    zero = probe.stream_summary([], "home")
    assert zero["known"] is True and zero["attempts"] == zero["successes"] == 0
    events = [
        dict(team="home", x=80.0, y=10.0, ok=True, ex=1.0, ey=99.0),
        dict(team="home", x=0.0, y=30.0, ok=False),
        dict(team="away", x=90.0, y=90.0, ok=True),
    ]
    result = probe.stream_summary(events, "home")
    assert result["attempts"] == 2 and result["successes"] == 1
    assert result["spatialKnown"] == 1 and result["ambiguousCoordinates"] == 1
    assert result["grid"][2][0] == 1


def test_opposing_team_frame_mirrors_both_axes_without_using_observed_future_role():
    np.testing.assert_array_equal(
        probe.opposing_frame(np.array([[80.0, 10.0], [20.0, 90.0]])), [[20.0, 90.0], [80.0, 10.0]]
    )


def test_materialized_manifest_can_have_different_cache_name_but_must_match_git_blob():
    root = Path(__file__).parents[1] / "data/raw/spatial-tests" / uuid4().hex
    root.mkdir(parents=True)
    cached = root / "data.txt"
    raw = b'window.DATA = {"seasons":{}};\n'
    cached.write_bytes(raw)
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    value, canonical = probe.read_verified(
        root, "laliga_dashboard/data.js", {"laliga_dashboard/data.js": blob}, local=cached
    )
    assert value == {"seasons": {}} and canonical == raw
