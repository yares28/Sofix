"""Testing only: separate source and personal-AA ablations of verified historical shapes."""

import numpy as np

from app.research import score_europe_shape_history as history


def feature_groups(names):
    if list(names) != list(history.NAMES):
        raise ValueError("European team-shape feature schema differs")
    result = {}
    for source in ("euro", "combined"):
        selected = np.array([n.startswith("europe_shape_" + source + "_") for n in names])
        aa = np.array([n.startswith("europe_shape_" + source + "_aa_") for n in names])
        result[source + "_structural"] = selected & ~aa
        result[source + "_aa"] = aa
        result[source + "_all"] = selected
    return result
