import numpy as np

from app.research.score_activity_dependence import exact_distribution, exact_forecasts, native_points


def test_exact_independent_distribution_has_all_cross_combinations():
    paired, independent = exact_distribution([[0, 0], [4, 6]])
    np.testing.assert_array_equal(paired[0], [0, 10])
    np.testing.assert_array_equal(paired[1], [0.5, 0.5])
    present = independent[1] > 0
    np.testing.assert_array_equal(independent[0][present], [0, 4, 6, 10])
    np.testing.assert_array_equal(independent[1][present], [0.25] * 4)
    assert paired[0] @ paired[1] == independent[0] @ independent[1] == 5


def test_exact_window_includes_both_edges():
    chosen = exact_forecasts(np.array([0.0]), (np.array([-7.0, 7.0, 24.0]), np.array([0.3, 0.4, 0.3])))
    np.testing.assert_array_equal(chosen, [0])


def test_all_native_stat_points_are_kept_in_components():
    stats = {"clean_sheet_60": [1, 10], "duel_lost": [2, -4], "accurate_pass": [20, 2], "other": [1, 3]}
    assert native_points(stats) == [10, -4, 2, 3]
