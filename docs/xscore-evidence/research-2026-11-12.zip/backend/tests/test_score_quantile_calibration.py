"""Testing-only causal calibration and exact native score-window contracts."""

import copy

import numpy as np
import pytest

from app.research import score_quantile_calibration as calibrated
from app.research import score_quantile_curve as curve
from app.research.score_modal_trees import CENTRES


def test_nominal_probabilities_reproduce_original_curve_including_atoms_and_floors():
    knots = np.array([[-30, -20, -10, -5, 0, 1, 2, 5, 10, 20, 50], [0] * 11, [40] * 6 + [80] * 5], dtype=float)
    for level in (0, 5, 15, 35, 60, 70, 80, 90, 100):
        for tails in ("clamp", "extrapolate"):
            np.testing.assert_array_equal(
                calibrated.curve_mass(knots, level, tails, curve.QUANTILES), curve.curve_mass(knots, level, tails)
            )
    mass = calibrated.curve_mass(np.zeros((1, 11)), 35, "clamp", curve.QUANTILES)[0]
    assert mass[CENTRES == 42] == 1
    assert mass[CENTRES == 42.5] == 0


def test_calibration_uses_strictly_available_oof_labels_with_hierarchical_cold_fallback():
    rows = [
        dict(date="2023-12-20T14:00:00Z", aa=0, level=35, pos="MID"),
        dict(date="2023-12-21T14:00:00Z", aa=10, level=60, pos="DEF"),
        dict(date="2024-01-03T14:00:00Z", aa=-99, level=35, pos="MID"),
    ]
    parts = {q: np.full((3, 2), 20 * q) for q in curve.QUANTILES}
    classes = np.array([35, 60])
    bank = calibrated.fit_levels(rows, classes, parts, "2024-01-06T18:00:00Z", 100)
    assert bank["knownCases"] == 2
    assert bank["unavailableCases"] == 1
    assert bank["maximumAvailableUsed"] < bank["firstLock"]
    changed = copy.deepcopy(rows)
    changed[-1].update(aa=np.nan, level=np.nan)
    assert calibrated.fit_levels(changed, classes, parts, "2024-01-06T18:00:00Z", 100) == bank
    for group in ("global", "position", "position_level"):
        values = calibrated.levels_for(bank, "UNKNOWN", 100, group)
        np.testing.assert_array_equal(values, bank["global"])
        assert (np.diff(values) > 0).all()
    np.testing.assert_array_equal(calibrated.levels_for(bank, "MID", 100, "position_level"), bank["position"]["MID"])


def test_calibrated_native_mass_matches_independent_inverse_cdf():
    q = np.array([0.02, 0.08, 0.2, 0.35, 0.4, 0.5, 0.6, 0.7, 0.77, 0.9, 0.98])
    cases = np.array([[-25, -15, -7, -2, 0, 1, 4, 7, 14, 25, 60], [0] * 5 + [10] * 3 + [40] * 3], dtype=float)
    u = (np.arange(200000) + 0.5) / 200000
    for knots in cases:
        for tails in ("clamp", "extrapolate"):
            a, b = knots[0], knots[-1]
            if tails == "extrapolate":
                a -= (knots[1] - knots[0]) / 2
                b += (knots[-1] - knots[-2]) / 2
            aa = np.interp(u, np.r_[0, q, 1], np.r_[a, knots, b])
            for level in (0, 35, 60, 90, 100):
                native = np.sort(np.clip(np.maximum(level if level >= 60 else 0, level + aa), 0, 100))
                expected = (
                    np.searchsorted(native, CENTRES + 7, side="right")
                    - np.searchsorted(native, CENTRES - 7, side="left")
                ) / len(native)
                np.testing.assert_allclose(
                    calibrated.curve_mass(knots[None, :], level, tails, q)[0], expected, atol=2e-5, rtol=0
                )


def test_forecast_api_retains_all_cases_without_current_outcomes_and_rejects_invalid_probability():
    bank = {"global": list(curve.QUANTILES), "position": {}, "position_level": {}}
    parts = {q: np.full((3, 2), q * 40 - 10) for q in curve.QUANTILES}
    p = np.array([[0.8, 0.2], [1.0, 0.0], [0.5, 0.5]])
    result = calibrated.forecast_mass(
        np.array([35, 60]), p, parts, np.array(["GK", "MID", "FWD"]), bank, "position_level", "clamp"
    )
    assert result.shape == (3, 201)
    assert np.isfinite(result).all()
    with pytest.raises(ValueError, match="probabilities"):
        calibrated.forecast_mass(
            np.array([35, 60]), p * 2, parts, np.array(["GK", "MID", "FWD"]), bank, "global", "clamp"
        )
    with pytest.raises(ValueError, match="Monotone"):
        calibrated.curve_mass(np.zeros((1, 11)), 35, "clamp", list(reversed(curve.QUANTILES)))
