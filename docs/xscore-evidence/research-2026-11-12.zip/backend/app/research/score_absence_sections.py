"""Extract explicitly labelled absence claims from locally cached previews."""

import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import timedelta
from html.parser import HTMLParser
from pathlib import Path

from app.research.score_absence_clock_pilot import NATIVE, NATIVE_SHA, ROOT, coverage_ceiling
from app.research.score_referee_archive import OFFICIAL_CLUBS, club_key
from app.research.score_search import cutoff_for, moment

CLAIM = re.compile(r"^-?\s*(sancionados|lesionados|dudas)\s*:\s*(.*)$", re.I)
HEADINGS = {"h2", "h3", "h4"}
BLOCKS = HEADINGS | {"p", "li"}
ALIASES = {
    "Athletic Club de Bilbao": "Athletic Club",
    "Atlético de Madrid": "Club Atlético de Madrid",
    "Atlético Madrid": "Club Atlético de Madrid",
    "Real Betis": "Real Betis Balompié",
    "Celta de Vigo": "RC Celta de Vigo",
    "RC Celta": "RC Celta de Vigo",
    "RCD Espanyol": "RCD Espanyol de Barcelona",
    "CA Osasuna": "Club Atlético Osasuna",
    "Osasuna": "Club Atlético Osasuna",
    "Rayo Vallecano": "Rayo Vallecano de Madrid",
    "Real Madrid": "Real Madrid CF",
    "Real Sociedad": "Real Sociedad de Fútbol",
    "Deportivo de A Coruña": "RC Deportivo",
    "Racing de Santander": "Real Racing Club de Santander",
    "Racing Santander": "Real Racing Club de Santander",
}


class TextBlocks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.blocks = []
        self.active = None
        self.parts = []
        self.hidden = None

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.hidden = tag
        if self.hidden:
            return
        if tag in BLOCKS:
            self.flush()
            self.active = tag
        if tag == "br":
            self.parts.append(" ")

    def handle_data(self, text):
        if self.active and not self.hidden:
            self.parts.append(text)

    def handle_endtag(self, tag):
        if tag == self.hidden:
            self.hidden = None
        if tag == self.active:
            self.flush()

    def flush(self):
        if self.active:
            self.blocks.append((self.active, " ".join("".join(self.parts).split())))
        self.active, self.parts = None, []


def club_sections(html, clubs):
    parser = TextBlocks()
    parser.feed(html)
    parser.flush()
    current, seen = None, set()
    duplicates, values = set(), defaultdict(lambda: defaultdict(list))
    for tag, text in parser.blocks:
        club = clubs.get(club_key(text))
        if club:
            if club in seen:
                duplicates.add(club)
            seen.add(club)
            current = club
        elif tag in HEADINGS:
            current = None
        elif current and (match := CLAIM.fullmatch(text)):
            values[current][match[1].lower()].append(match[2])
    return {
        c: {label: found[0] for label, found in fields.items() if len(found) == 1 and found[0]}
        for c, fields in values.items()
        if c not in duplicates
    }


def player_mentions(value):
    if value.strip().strip(".").strip().casefold() in {"-", "–", "—", "ninguno", "ningún jugador"}:
        return []
    clean = re.sub(r"\([^()]*\)", "", value)
    return [s.strip(" .;") for s in re.split(r"[,;]|\s+y\s+", clean) if s.strip(" .;")]


def linked(mention, candidates):
    # Compare published name components with contiguous tokens in a native ID.
    # A single token must match the entire ID, so surname collisions stay unresolved.
    parts = re.findall(r"[^\W_]+", mention.casefold())
    tokens = [club_key(p) for p in parts]
    hits = []
    for player in candidates:
        components = [club_key(p) for p in player.split("-")]
        if components == tokens or (
            len(tokens) >= 2
            and all(len(t) >= 2 for t in tokens)
            and any(components[i : i + len(tokens)] == tokens for i in range(len(components)))
        ):
            hits.append(player)
    return hits[0] if len(hits) == 1 else None


def histories(games, club, lock):
    selected = [
        g
        for g in games
        if moment(g["date"]) + timedelta(hours=48) < lock and club in (g["home"]["slug"], g["away"]["slug"])
    ]
    eligible = {}
    minutes = defaultdict(float)
    for game in selected:
        age = lock - moment(game["date"])
        if age > timedelta(days=365):
            continue
        for name, p in game["players"].items():
            if p.get("played") is True and p.get("team") == club and p.get("ver") == 7:
                eligible[name] = p["pos"]
    for game in selected[-3:]:
        for name, p in game["players"].items():
            if name in eligible and p.get("played") is True and p.get("team") == club:
                minutes[name] += float(p["mins"]) / min(len(selected), 3)
    return eligible, minutes


def main():
    from app.research.score_absence_archive_coverage import OUT as COVERAGE

    report = json.loads(COVERAGE.read_text())
    directory = ROOT / "suspension-source"
    manifest_path = directory / "ser_archive_article_manifest.json"
    assert hashlib.sha256(manifest_path.read_bytes()).hexdigest() == report["articleManifestSHA"]
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    files = {m["url"]: Path(m["file"]) for m in manifest}
    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, native.splitlines()), key=lambda g: (g["date"], g["id"]))
    indexed = {g["id"]: g for g in games}
    clubs = {club_key(name): slug for name, slug in OFFICIAL_CLUBS.items()}
    clubs.update({club_key(name): OFFICIAL_CLUBS[alias] for name, alias in ALIASES.items()})
    outputs, stats = [], Counter()
    positive = {"sancionados": set(), "lesionados": set()}
    cache = {}
    for article in report["articles"]:
        path = files[article["url"]]
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == article["sha256"]
        sections = club_sections(raw.decode("utf-8"), clubs)
        stats["articles"] += 1
        stats["all20ClubSections"] += len(sections) == 20
        stats["uniqueClubSections"] += len(sections)
        for game_id in article["eligibleGames"]:
            fixture = indexed[game_id]
            lock = cutoff_for(fixture["date"])
            assert moment(article["revision"]) < lock
            for side in ("home", "away"):
                club = fixture[side]["slug"]
                key = club, lock
                if key not in cache:
                    cache[key] = histories(games, club, lock)
                eligible, minutes = cache[key]
                fields = sections.get(club, {})
                stats["eligibleFixtureSides"] += 1
                stats["eligibleSidesWithClubSection"] += bool(fields)
                output = dict(game=game_id, date=fixture["date"], club=club, side=side, fields=fields, mentions={})
                for category, value in fields.items():
                    result = []
                    for mention in player_mentions(value):
                        player = linked(mention, eligible)
                        projected = float(minutes.get(player, 0))
                        stats[category + "Mentions"] += 1
                        stats[category + "IdentityLinks"] += player is not None
                        stats[category + "WithProjectedExposure"] += projected > 0
                        if category in positive and projected > 0:
                            positive[category].add(game_id)
                        result.append(dict(mention=mention, player=player, projectedPriorMinutes=projected))
                    output["mentions"][category] = result
                outputs.append(output)
    rows = json.loads((ROOT / "cases.json").read_text())["rows"]
    result = dict(
        nativeSHA=NATIVE_SHA,
        coverageReportSHA=hashlib.sha256(COVERAGE.read_bytes()).hexdigest(),
        statistics=dict(stats),
        coveredFixturesByCategory={k: len(v) for k, v in positive.items()},
        singleCategoryCeiling={k: coverage_ceiling(rows, v) for k, v in positive.items()},
        jointCeiling=coverage_ceiling(rows, set.union(*positive.values())),
        scope="Provisional name links and past exposure only. Source reports can be wrong. "
        "No target participant or actual minutes used to identify absences. No model evaluated.",
        sourceClaims=outputs,
    )
    Path("reports/experiments/laliga_score_absence_claims_pilot.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "sourceClaims"}, indent=2))


if __name__ == "__main__":
    main()
