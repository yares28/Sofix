from datetime import timedelta

import numpy as np

from app.research import score_native_sot_features as sot
from app.research.score_search import moment


def person(team, count=None):
    return dict(
        team=team, played=True, ver=7, stats={} if count is None else {"ontarget_scoring_att": [count, count * 3]}
    )


def test_native_full_scored_sheet_absent_sot_is_recorded_zero_and_keeper_included():
    game = dict(
        home=dict(slug="A"), away=dict(slug="B"), players=dict(p=person("A", 3), q=person("A"), r=person("B", 2))
    )
    assert sot.native_sot(game) == [3.0, 2.0]
    game["players"]["p"]["ver"] = 6
    assert sot.native_sot(game)[0] is None
    assert sot.native_sot(game)[1] == 2


def test_native_missing_side_or_stats_is_unknown_never_zero():
    game = dict(home=dict(slug="A"), away=dict(slug="B"), players=dict(p=person("A")))
    assert sot.native_sot(game) == [0.0, None]
    game["players"]["p"]["stats"] = None
    assert sot.native_sot(game) == [None, None]


def test_replacing_for_and_against_preserves_parent_and_every_other_metric():
    original = dict(
        date="2025-01-01", available=moment("2025-01-03T12:00:00Z"), sides=["A", "B"], metrics=np.full((2, 12), 5.0)
    )
    new = sot.replace_sot(original, [3, 1])
    assert new["metrics"][:, 8:10].tolist() == [[3, 1], [1, 3]]
    np.testing.assert_array_equal(original["metrics"], np.full((2, 12), 5.0))
    np.testing.assert_array_equal(new["metrics"][:, :8], original["metrics"][:, :8])


def test_legacy_context_keeps_strict48h_and180day_window_without_row_exclusion():
    lock = moment("2026-01-02T14:00:00Z")
    date = "2026-01-03T12:00:00Z"
    rows = [dict(game="g", player="p", date=date)]
    games = [dict(id="g", home=dict(slug="A"), away=dict(slug="B"), players=dict(p=dict(team="A")))]
    external = [
        dict(
            date=(lock - timedelta(days=181)).isoformat(),
            available=lock - timedelta(days=179),
            sides=["A", "B"],
            metrics=np.full((2, 12), 99.0),
        ),
        dict(
            date=(lock - timedelta(hours=48)).isoformat(),
            available=lock,
            sides=["A", "B"],
            metrics=np.full((2, 12), 88.0),
        ),
        dict(
            date=(lock - timedelta(days=3)).isoformat(),
            available=lock - timedelta(days=1),
            sides=["A", "B"],
            metrics=np.full((2, 12), 2.0),
        ),
    ]
    x, names, _ = sot.context_features(rows, games, external)
    assert x.shape == (1, 148)
    assert x[0, names.index("own_3_sot_for_mean")] == 2
    assert x[0, names.index("own_3_sot_for_count")] == 1
