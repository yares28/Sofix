import copy
from datetime import timedelta

import numpy as np
import pytest

from app.research.score_event_intensity import NAMES, build_features
from app.research.score_search import cutoff_for, moment


def sample(dates=("2026-01-03T18:00:00Z", "2026-01-10T18:00:00Z")):
    rows, games = [], []
    for i, date in enumerate(dates):
        row = {
            "game": "g" + str(i),
            "player": "p",
            "date": date,
            "cohort": "start",
            "pos": "FWD",
            "minutes": 90,
            "level": 35,
            "score": 35,
            "aa": 0,
            "x": [1.5, 1],
            "recent": [r["score"] for r in rows if moment(r["date"]) + timedelta(hours=48) < cutoff_for(date)],
        }
        rows.append(row)
        games.append(
            {
                "id": row["game"],
                "date": date,
                "home": {"slug": "home"},
                "away": {"slug": "away"},
                "players": {"p": {"team": "home", "pos": "FWD", "mins": 90, "started": True, "ver": 7, "stats": {}}},
            }
        )
    return rows, games


def native(row, value, field="chance_xg90"):
    return {
        "game": row["game"],
        "player": "p",
        "date": row["date"],
        "cohort": "start",
        "club": "home",
        "minutes": row["minutes"],
        "values": {field: value},
    }


def built(rows, games, shots=None, created=None):
    return build_features(rows, games, ["match_lam_h", "match_lam_a"], shots or {}, created or {})


def test_future_events_minutes_and_native_quality_do_not_change_current_inputs():
    rows, games = sample()
    shots = {(r["game"], "p"): native(r, 0.2) for r in rows}
    before, labels, audit = built(rows, games, shots)
    changed_rows, changed_games, changed_shots = copy.deepcopy(rows), copy.deepcopy(games), copy.deepcopy(shots)
    changed_rows[-1].update(level=60, score=60, minutes=30)
    changed_games[-1]["players"]["p"].update(mins=30, stats={"goals": [1, 0]})
    changed_shots["g1", "p"].update(minutes=30, values={"chance_xg90": 9})
    after, changed_labels, _ = built(changed_rows, changed_games, changed_shots)
    np.testing.assert_equal(before, after)
    assert labels["positive"][-1] == 0 and changed_labels["positive"][-1] == 1
    assert audit["canonicalHistoryAgreements"] == 2


def test_exact_forty_eight_hour_boundary_is_excluded_from_both_player_and_pool():
    rows, games = sample(("2026-01-07T14:00:00Z", "2026-01-10T18:00:00Z"))
    result, _, _ = built(rows, games, {("g0", "p"): native(rows[0], 2)})
    assert result[-1, NAMES.index("event_history_games")] == 0
    assert result[-1, NAMES.index("event_native_goal_exposure90")] == 0
    assert result[-1, NAMES.index("event_expected_minutes")] == 75


def test_known_zero_chance_quality_adds_real_exposure_missing_quality_does_not():
    rows, games = sample()
    known, _, _ = built(rows, games, {("g0", "p"): native(rows[0], 0)})
    unknown, _, _ = built(rows, games, {("g0", "p"): native(rows[0], None)})
    assert known[-1, NAMES.index("event_native_goal_exposure90")] > 0
    assert unknown[-1, NAMES.index("event_native_goal_exposure90")] == 0
    assert known[-1, NAMES.index("event_goal_quality90")] < unknown[-1, NAMES.index("event_goal_quality90")]


def test_wrong_source_identity_and_inconsistent_event_level_are_rejected():
    rows, games = sample()
    wrong = native(rows[0], 0.2)
    wrong["player"] = "another"
    with pytest.raises(ValueError, match="identity differs"):
        built(rows, games, {("g0", "p"): wrong})
    games[0]["players"]["p"]["stats"] = {"goals": [1, 0]}
    with pytest.raises(ValueError, match="reconstruction"):
        built(rows, games)


def test_missing_lambda_keeps_case_and_remains_different_from_known_zero():
    rows, games = sample(dates=("2026-01-03T18:00:00Z",))
    rows[0]["x"][0] = None
    unknown, _, _ = built(rows, games)
    rows[0]["x"][0] = 0
    zero, _, _ = built(rows, games)
    assert np.isfinite(unknown).all() and np.isfinite(zero).all()
    assert unknown[0, NAMES.index("event_current_lambda_known")] == 0
    assert zero[0, NAMES.index("event_current_lambda_known")] == 1
