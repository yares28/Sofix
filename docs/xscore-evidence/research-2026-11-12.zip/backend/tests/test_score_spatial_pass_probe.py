from app.research import score_spatial_pass_probe as probe


def test_explicit_zero_unknown_and_partial_coordinate_lower_bounds_are_distinct():
    assert probe.pass_stream(None, "home")["known"] is False
    empty = probe.pass_stream([], "home")
    assert empty["known"] and empty["classificationComplete"] and empty["passCount"] == 0
    partial = probe.pass_stream([dict(team="home", x=0.0, y=50.0, ex=90.0, ey=50.0, ok=True, cross=True)], "home")
    assert partial["passCount"] == 1 and partial["successes"] == 1
    assert not partial["classificationComplete"] and partial["unknownCoordinates"] == 1
    assert partial["categories"]["cross_end"] == []


def test_endpoint_pressure_uses_recorded_coordinates_and_flags_not_receiver_guess():
    events = [
        dict(team="home", x=30.0, y=20.0, ex=80.0, ey=40.0, ok=False, cross=True, recv="invented"),
        dict(team="away", x=20.0, y=20.0, ex=90.0, ey=40.0, ok=True, cross=True),
    ]
    result = probe.pass_stream(events, "home")
    assert result["classificationComplete"] and result["passCount"] == 1
    assert (
        result["categories"]["cross_end"]
        == result["categories"]["long_forward_end"]
        == result["categories"]["third_entry_end"]
        == [[80.0, 40.0, 0]]
    )
