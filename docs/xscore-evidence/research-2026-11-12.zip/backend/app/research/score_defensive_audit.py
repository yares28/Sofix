"""Testing only: native metric, freeze, coverage and unavailable-label mutation audit."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_defensive_residuals as defensive
from app.research import score_defensive_residuals_run as runner
from app.research import score_defensive_simulation as simulation
from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research.score_search import measure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "event-cache", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    if source["key"] != report["sourceKey"]:
        raise ValueError("Defensive audit source differs")
    games = [json.loads(line) for line in args.games.read_text().splitlines() if line.strip()]
    native = simulation.observations(source["rows"], games, source["features"])
    # Audit exact additive labels as well as clipped totals: clipping can hide a wrong component.
    game_index = {g["id"]: g for g in games}
    for row in source["rows"]:
        stat_points = sum(value[1] for value in game_index[row["game"]]["players"][row["player"]]["stats"].values())
        if abs(stat_points - row["aa"]) > 1e-7:
            raise ValueError("Native additive AA reconstruction differs")
    with np.load(args.event_cache) as f:
        if str(f["key"]) != report["eventFeatureKey"]:
            raise ValueError("Defensive audit minute source differs")
        predicted_minutes = f["x"][:, f["names"].tolist().index("event_expected_minutes")]
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary = map(
        read, ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary")
    )
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        context = {name: values[keep].copy() for name, values in native.items()}
        predicted = predicted_minutes[keep]
        positions = np.array([r["pos"] for r in rows])
        minutes = np.array([r["minutes"] for r in rows], dtype=float)
        masks = stability.phase_masks(rows)
        target, fit = masks["later2026"]["target"], masks["later2026"]["fit"]
        first = masks["later2026"]["first"]
        y = np.array([r["score"] for r in rows])[target]
        path = args.cache / f"{args.report.stem}_predictions_{cohort}.npz"
        with np.load(path) as f:
            if str(f["key"]) != report["implementationKey"] or not np.array_equal(f["y"], y):
                raise ValueError("Defensive audit final cache identity differs")
            alternate, control, prediction = (f[k] for k in ("alternate", "control", "prediction"))
        if len(y) != {"start": 6754, "bench": 2925}[cohort] or any(
            not np.isfinite(p).all() or len(p) != len(y) for p in (alternate, control, prediction)
        ):
            raise ValueError("Defensive audit all-case coverage differs")
        if (
            measure(y, alternate) != result["candidateLater"]
            or measure(y, control) != result["control"]
            or measure(y, prediction) != result["later"]
        ):
            raise ValueError("Defensive audit native metric differs")
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        _, best = stability.choose_stable(frozen["candidates2048"])
        if best["spec"] != frozen["fixedConfirmationSpec"] or best["spec"] != frozen["finalCandidate"]["spec"]:
            raise ValueError("Defensive audit earlier selection changed after confirmation")
        passing = min(frozen["finalCandidate"]["gains"]) > 0
        if bool(frozen["winner"]) != passing or (result["selected"] == "candidate") != passing:
            raise ValueError("Defensive audit earlier stability gate differs")
        for phase in ("spring2024", "season2024", "autumn2025"):
            pm = masks[phase]
            with np.load(
                args.cache / f"{args.report.stem}_{cohort}_{phase}_draws8192_{report['implementationKey'][:12]}.npz"
            ) as f:
                if str(f["key"]) != report["implementationKey"]:
                    raise ValueError("Defensive audit earlier cache identity differs")
                raw = f[best["spec"]["model"]]
            metric = measure(
                np.array([r["score"] for r in rows])[pm["target"]],
                runner.scoped(
                    raw,
                    runner.controls.control_for(
                        SimpleNamespace(rows=rows, cache=args.cache, out=args.report),
                        report["implementationKey"],
                        source,
                        cohort,
                        phase,
                        masks,
                        old_match,
                        old_stability,
                        old_ordinary,
                        read("laliga_score_analogues"),
                    ),
                    positions[pm["target"]],
                    best["spec"]["scope"],
                ),
            )
            if metric != frozen["finalCandidate"]["periods"][phase]["metrics"]:
                raise ValueError("Defensive audit confirmed metric differs")
        spec = defensive.PARAMETERS[best["spec"]["model"]]
        previous = masks["autumn2025"]["target"]
        old_parts = flow.old_components(
            SimpleNamespace(cache=args.cache), cohort, "autumn2025", old_match, old_stability, old_ordinary
        )
        current_parts = flow.old_components(
            SimpleNamespace(cache=args.cache), cohort, "later2026", old_match, old_stability, old_ordinary
        )

        def rebuild(
            row_values,
            minute_labels,
            labels,
            *,
            previous=previous,
            old_parts=old_parts,
            first=first,
            spec=spec,
            positions=positions,
            fit=fit,
            predicted=predicted,
        ):
            curve, _ = defensive.fit_exposure(
                minute_labels, labels["conceded"], labels["full_conceded"], positions, fit
            )
            curve = None if spec["exposure"] == "uniform" else curve
            bank = simulation.make_bank(
                [r for r, yes in zip(row_values, previous, strict=True) if yes],
                old_parts,
                {name: values[previous] for name, values in labels.items()},
                predicted[previous],
                first,
                curve,
                spec,
            )
            return curve, bank

        curve, bank = rebuild(rows, minutes, context)
        unavailable = ~stability.previous_bank_mask(rows, first)
        altered = copy.deepcopy(rows)
        mutated_context = {name: values.copy() for name, values in context.items()}
        mutated_minutes = minutes.copy()
        mutated_minutes[unavailable] = -999
        for i in np.flatnonzero(unavailable):
            altered[i].update(aa=999999, level=-999, minutes=-999, score=-999)
        for name in ("actual", "conceded", "full_conceded"):
            mutated_context[name][unavailable] = np.nan
        changed_curve, changed_bank = rebuild(altered, mutated_minutes, mutated_context)
        if not np.array_equal(curve, changed_curve) or bank.keys() != changed_bank.keys():
            raise ValueError("Unavailable defensive labels changed forecast calibration")
        for group in ("positions", "levels"):
            if bank[group].keys() != changed_bank[group].keys() or any(
                not np.array_equal(v, changed_bank[group][name]) for name, v in bank[group].items()
            ):
                raise ValueError("Unavailable defensive labels changed conditional pairs")
        if not np.array_equal(bank["global"], changed_bank["global"]):
            raise ValueError("Unavailable defensive labels changed pooled pairs")
        count = min(64, int(target.sum()))
        take = slice(0, count)
        parts = current_parts[0], current_parts[1][take], {q: values[take] for q, values in current_parts[2].items()}
        identity = spec["exposure"], spec["goals"], spec["location"]
        raw, _ = simulation.simulate(
            parts,
            positions[target][take],
            context["lam"][target][take],
            context["cs"][target][take],
            predicted[target][take],
            control[take],
            {identity: changed_bank},
            {spec["exposure"]: changed_curve},
            {best["spec"]["model"]: spec},
            8192,
        )
        reproduced = runner.scoped(
            raw[best["spec"]["model"]], control[take], positions[target][take], best["spec"]["scope"]
        )
        if not np.array_equal(reproduced, alternate[take]):
            raise ValueError("Defensive audit real predictions did not reproduce")
        h0, h1 = np.abs(y - control) <= 7, np.abs(y - alternate) <= 7
        evidence[cohort] = {
            "n": len(y),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "candidateRate": float(h1.mean()),
            "unavailableLabelsMutated": int(unavailable.sum()),
            "realPredictionsReproducedAfterMutation": count,
            "earlierGateVerified": True,
            "nativeAASumVerifiedAllRows": len(source["rows"]),
            "frozenSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
    output = {
        "scope": "Testing only, independent metrics/causality checks, no fresh blind claim",
        "implementationKey": report["implementationKey"],
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
