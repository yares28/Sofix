"""Testing only: reconstruct exact-window choices and verify all-case native metrics."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_exact_window as exact
from app.research import score_exact_window_run as runner
from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_search import measure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Exact-window audit source differs")
    modules = (exact, empirical, flow, matched, controls, ordinary, stability)
    key = hashlib.sha256(
        (
            source["key"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Exact-window code/plan fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or best != frozen["best"]
            or winner != frozen["winner"]
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Exact-window earlier selection gate differs")
        reconstructed, boundary_cases = 0, 0
        for phase_index, (phase, _, _) in enumerate(stability.PHASES[1:], start=1):
            target = masks[phase]["target"]
            previous_phase = stability.PHASES[phase_index - 1][0]
            previous_rows = [r for r, yes in zip(rows, masks[previous_phase]["target"], strict=True) if yes]
            previous = flow.old_components(call_args, cohort, previous_phase, old_match, old_stability, old_ordinary)
            current = flow.old_components(call_args, cohort, phase, old_match, old_stability, old_ordinary)
            bank = matched.bank_from(previous, previous_rows, masks[phase]["first"])
            control = controls.control_for(
                call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected_control = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected_control:
                raise ValueError("Exact-window strongest control did not reproduce")
            with np.load(args.cache / f"{args.report.stem}_{cohort}_{phase}_{key[:12]}.npz") as f:
                if str(f["key"]) != key or len(f["prediction"]) != int(target.sum()):
                    raise ValueError("Exact-window phase cache identity differs")
                raw, stats = f["prediction"], json.loads(str(f["statistics"]))
            selected = set(np.linspace(0, len(control) - 1, min(64, len(control))).astype(int))
            selected.update(int(np.flatnonzero(positions[target] == p)[0]) for p in set(positions[target]))
            selected = np.array(sorted(selected))
            parts = current[0], current[1][selected], {q: value[selected] for q, value in current[2].items()}
            repeated, _ = exact.predict(parts, positions[target][selected], bank, control[selected])
            if not np.array_equal(repeated, raw[selected]):
                raise ValueError("Exact-window representative real predictions did not reproduce")
            reconstructed += len(selected)
            boundary_cases += stats["distributionAudit"]["casesWithNativeBoundaryDifference"]
            if (
                not stats["distributionAudit"]["differencesExplainedOnlyByFloatingScoreBoundary"]
                or stats["meanExactMass"] < stats["meanControlMass"] - 1e-12
            ):
                raise ValueError("Exact-window probability reconstruction failed")
            for record in [best] if phase == "later2026" else frozen["candidates"]:
                candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                if phase == "later2026":
                    alternate = candidate
                elif measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                    raise ValueError("Exact-window earlier native metrics differ")
            if phase == "later2026":
                changed = copy.deepcopy(previous_rows)
                unavailable = ~stability.previous_bank_mask(previous_rows, masks[phase]["first"])
                for i in np.flatnonzero(unavailable):
                    changed[i].update(aa=np.nan, level=90.0)
                changed_bank = matched.bank_from(previous, changed, masks[phase]["first"])
                mutated, _ = exact.predict(parts, positions[target][selected], changed_bank, control[selected])
                if not np.array_equal(mutated, repeated):
                    raise ValueError("Unavailable exact-window calibration labels changed forecasts")
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Exact-window full-case final identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Exact-window final native metric differs")
            h1, h0 = np.abs(y[target] - f["alternate"]) <= 7, np.abs(y[target] - f["control"]) <= 7
            rounded = {
                str(decimals): measure(y[target], np.round(f["alternate"], decimals))["within7"]
                for decimals in (0, 1, 2)
            }
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "realPredictionsReconstructed": reconstructed,
            "gridAuditCasesWithLegacyNativeBoundaryDifferences": boundary_cases,
            "roundingDiagnosticOnly": rounded,
            "earlierSelectionVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
    output = {
        "scope": "Research-only independent native all-case/cache/freeze/prediction reconstruction, no fresh blind claim",
        "implementationKey": key,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
