import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))

from app.research import score_physical_duel_signal as signal


def test_binomial_losses_count_wins_and_losses_without_mean_fraction_shortcut():
    actual = np.array([[9.0, 1], [1, 1], [0, 0], [np.nan, np.nan]])
    p = np.array([0.8, 0.2, 0.6, 0.3])
    result = signal.losses(actual, p, np.ones(4, bool))
    assert result["cases"] == 4 and result["positiveDuelCases"] == 2 and result["duels"] == 12
    np.testing.assert_allclose(result["brier"], (9 * 0.2**2 + 0.8**2 + 0.8**2 + 0.2**2) / 12)
    np.testing.assert_allclose(result["logloss"], -(10 * np.log(0.8) + 2 * np.log(0.2)) / 12)


def test_actual_nontraining_outcomes_cannot_change_either_fitted_architecture():
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(7)
    x = rng.normal(size=(200, 5))
    x[::9, 0] = np.nan
    counts = rng.integers(1, 10, size=(200, 2)).astype(float)
    fit, target = np.arange(200) < 150, np.arange(200) >= 150
    blinded = counts.copy()
    blinded[~fit] = np.nan
    for architecture in ("logistic", "nonlinear"):
        expected = signal.fitted(x, counts, fit, target, architecture)
        actual = signal.fitted(x, blinded, fit, target, architecture)
        np.testing.assert_array_equal(actual["probability"], expected["probability"])
        assert np.isfinite(actual["probability"]).all()


def test_zero_duel_cases_keep_predictions_and_no_outcome_weight():
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    x = np.arange(60).reshape(20, 3).astype(float)
    counts = np.tile([5.0, 5.0], (20, 1))
    counts[0] = 0
    fit, target = np.arange(20) < 15, np.arange(20) >= 15
    expected = signal.fitted(x, counts, fit, target, "logistic")
    counts[0] = np.nan
    actual = signal.fitted(x, counts, fit, target, "logistic")
    np.testing.assert_array_equal(actual["probability"], expected["probability"])


def test_independent_raw_baseline_matches_legacy_native_workflow():
    from app.research import score_matchups as legacy
    from app.research.score_physical_duel_audit import raw_baseline
    from tests.test_score_signed_duel_matchups import native_fixture

    rows, games, roles, names = native_fixture()
    expected, fields, _ = legacy.build_matchups(rows, games, roles, names)
    actual = raw_baseline(rows, {g["id"]: g for g in games}, roles)
    np.testing.assert_allclose(
        actual, expected[:, [fields.index(n) for n in signal.MATCHUP_FIELDS]], rtol=0, atol=1e-10, equal_nan=True
    )
