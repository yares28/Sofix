from datetime import UTC, datetime

from app.research import score_market_identity as identity


def test_order_initials_and_unambiguous_static_nickname_not_guess_by_future_squad():
    names = {
        "vedat-muriqi": ["Vedat Muriqi"],
        "jude-victor-william-bellingham": ["Jude Bellingham"],
        "raphael-dias-belloli": ["Raphinha"],
    }
    assert identity.candidates("Muriqi V.", names) == ["vedat-muriqi"]
    assert identity.candidates("Bellingham Jude", names) == ["jude-victor-william-bellingham"]
    assert identity.candidates("Raphinha", names) == ["raphael-dias-belloli"]
    assert identity.candidates("Raph", names) == []


def test_common_names_keep_all_possible_people_despite_one_exact_alias():
    names = {"andre-miguel-valente-silva": ["Andre Silva"], "andre-luis-silva": []}
    assert identity.candidates("Silva Andre", names) == ["andre-luis-silva", "andre-miguel-valente-silva"]


def test_player_disambiguation_uses_only_strictly_available_past_club():
    lock = datetime(2026, 1, 23, 14, tzinfo=UTC)
    games = [
        dict(date="2026-01-20T14:00:00Z", players={"a": dict(played=True, team="A"), "b": dict(played=True, team="B")}),
        dict(date="2026-01-24T14:00:00Z", players={"b": dict(played=True, team="A")}),
    ]
    assert identity.past_club_candidates(["a", "b"], "A", lock, games) == ["a"]
    games[0]["date"] = "2026-01-21T14:00:00Z"
    assert identity.past_club_candidates(["a", "b"], "A", lock, games) == []


def test_no_player_goals_or_current_lineup_are_needed_for_unique_fixture_match():
    quote = dict(club="Real Madrid", listedTimeUTC="2026-01-24T20:00:00+00:00")
    games = [dict(id="g", date="2026-01-24T20:00:00Z", home=dict(slug="real-madrid-madrid"), away=dict(slug="A"))]
    assert identity.fixture_candidates(quote, games) == ["g"]
    games.append(dict(games[0], id="g2"))
    assert identity.fixture_candidates(quote, games) == ["g", "g2"]


def test_optimistic_upper_bound_includes_unresolved_quotes_and_keeps_full_denominator():
    assert identity.optimistic_bound(2765, 6754, 20, 3) == dict(
        baselineCorrect=2765,
        allCases=6754,
        mappedCoveredMisses=20,
        unresolvedPossibleQuotes=3,
        optimisticCorrect=2788,
        optimisticPercent=2788 / 6754 * 100,
        strictlyAbove50Possible=False,
    )
