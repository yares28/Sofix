"""Testing only: chronological defensive mixtures around frozen original forecasts."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_defensive_residuals as defensive
from app.research import score_defensive_simulation as simulation
from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def scoped(candidate, control, positions, scope):
    eligible = positions == "DEF" if scope == "defender" else np.isin(positions, ["DEF", "MID"])
    return np.where(eligible, candidate, control)


def fresh_record(spec):
    return {"spec": spec, "gains": [], "errors": [], "counts": [], "periods": {}}


def record_metric(record, phase, y, prediction, control):
    metric = measure(y, prediction)
    gain = metric["within7"] - measure(y, control)["within7"]
    record["gains"].append(gain)
    record["errors"].append(metric["mae"])
    record["counts"].append(len(y))
    record["periods"][phase] = {"gain": gain, "metrics": metric}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "event-cache", "event-report", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import scipy
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    native = simulation.observations(source["rows"], games, source["features"])
    event_report = json.loads(args.event_report.read_text())
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary = map(
        read, ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary")
    )
    old_start, old_bench = map(read, ("laliga_score_match_empirical_density", "laliga_score_analogues"))
    if any(
        r["sourceKey"] != source["key"]
        for r in (event_report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Defensive study source cases differ")
    with np.load(args.event_cache) as f:
        data, names, feature_key = f["x"], f["names"].tolist(), str(f["key"])
        if (
            feature_key != event_report["featureKey"]
            or feature_key not in plan["inputs"]
            or len(data) != len(source["rows"])
        ):
            raise ValueError("Defensive study causal-minute feature identity differs")
        predicted_minutes = data[:, names.index("event_expected_minutes")]
        if not np.isfinite(predicted_minutes).all() or ((predicted_minutes < 1) | (predicted_minutes > 90)).any():
            raise ValueError("Defensive study forecast minute support differs")
    files = [
        Path(__file__),
        *[Path(m.__file__) for m in (defensive, simulation, controls, ordinary, stability, empirical, flow)],
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + feature_key
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + scipy.__version__
        ).encode()
        + raw
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "eventFeatureKey": feature_key,
        "evidenceLimit": "Repeated historical reuse; exploratory, not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        old = json.loads(args.out.read_text())
        if old["implementationKey"] == key:
            report = old
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        minutes = np.array([r["minutes"] for r in rows])
        predicted = predicted_minutes[keep]
        context = {name: values[keep] for name, values in native.items()}
        masks = stability.phase_masks(rows)
        components = {
            phase: flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            for phase, _, _ in stability.PHASES
        }
        control_bank, audit = {}, {}

        def get_control(phase, *, control_bank=control_bank, cohort=cohort, masks=masks, y=y):
            if phase not in control_bank:
                control = controls.control_for(
                    args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
                )
                metric = measure(y[masks[phase]["target"]], control)
                expected = (
                    old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                    if phase != "later2026"
                    else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
                )
                if metric != expected:
                    raise ValueError("Defensive study strongest control differs")
                control_bank[phase] = control
            return control_bank[phase]

        def predict(
            phase,
            models,
            draws,
            *,
            cohort=cohort,
            masks=masks,
            rows=rows,
            minutes=minutes,
            context=context,
            positions=positions,
            predicted=predicted,
            components=components,
            get_control=get_control,
        ):
            print(f"DEFENSIVE_SIMULATING {cohort} {phase} draws{draws} models{len(models)}", flush=True)
            path = args.cache / f"{args.out.stem}_{cohort}_{phase}_draws{draws}_{key[:12]}.npz"
            if path.exists():
                with np.load(path) as f:
                    if str(f["key"]) != key or any(name not in f for name in models):
                        raise ValueError("Defensive simulation cache identity differs")
                    saved = {name: f[name] for name in models}
                    if any(
                        len(p) != int(masks[phase]["target"].sum()) or not np.isfinite(p).all() for p in saved.values()
                    ):
                        raise ValueError("Defensive simulation cache coverage differs")
                    return saved, json.loads(str(f["statistics"]))
            mask = masks[phase]
            target = mask["target"]
            phase_names = [p[0] for p in stability.PHASES]
            previous_phase = phase_names[phase_names.index(phase) - 1]
            previous = masks[previous_phase]["target"]
            previous_rows = [r for r, yes in zip(rows, previous, strict=True) if yes]
            fitted_curve, fit_stats = defensive.fit_exposure(
                minutes, context["conceded"], context["full_conceded"], positions, mask["fit"]
            )
            curves = {"uniform": None, "learned": fitted_curve}
            banks = {}
            for spec in models.values():
                identity = spec["exposure"], spec["goals"], spec["location"]
                if identity not in banks:
                    banks[identity] = simulation.make_bank(
                        previous_rows,
                        components[previous_phase],
                        {name: value[previous] for name, value in context.items()},
                        predicted[previous],
                        mask["first"],
                        curves[spec["exposure"]],
                        spec,
                    )
            saved, stats = simulation.simulate(
                components[phase],
                positions[target],
                context["lam"][target],
                context["cs"][target],
                predicted[target],
                get_control(phase),
                banks,
                curves,
                models,
                draws,
            )
            stats.update(
                {
                    "exposureFit": fit_stats,
                    "exposureCurve": fitted_curve.tolist(),
                    "banks": {
                        "/".join(identity): {"cases": bank["cases"], "unknownLevels": bank["unknownLevels"]}
                        for identity, bank in banks.items()
                    },
                }
            )
            np.savez_compressed(path, key=key, statistics=json.dumps(stats), **saved)
            return saved, stats

        records = [
            fresh_record({"model": model, "scope": scope})
            for model in defensive.PARAMETERS
            for scope in ("defender", "defmid")
        ]
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            control = get_control(phase)
            predictions, stats = predict(phase, defensive.PARAMETERS, 2048)
            audit[phase] = {
                "fit": int(masks[phase]["fit"].sum()),
                "target": int(target.sum()),
                "control": measure(y[target], control),
                "simulation": stats,
            }
            for record in records:
                spec = record["spec"]
                candidate = scoped(predictions[spec["model"]], control, positions[target], spec["scope"])
                record_metric(record, phase, y[target], candidate, control)
            print(
                "DEFENSIVE_SCREEN "
                + json.dumps(
                    {
                        "cohort": cohort,
                        "phase": phase,
                        "candidates": [{"spec": r["spec"], **r["periods"][phase]} for r in records],
                    }
                ),
                flush=True,
            )
        winner2048, best2048 = stability.choose_stable(records)
        fixed = winner2048 or best2048
        screening = {
            "implementationKey": key,
            "winner2048": winner2048,
            "best2048": best2048,
            "fixedConfirmationSpec": fixed["spec"],
            "candidates2048": records,
        }
        args.out.with_name(args.out.stem + f".{cohort}.screening.json").write_text(json.dumps(screening, indent=2))
        confirmed = fresh_record(fixed["spec"].copy())
        selected_models = {fixed["spec"]["model"]: defensive.PARAMETERS[fixed["spec"]["model"]]}
        confirmation_audit = {}
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            predictions, stats = predict(phase, selected_models, 8192)
            candidate = scoped(
                predictions[fixed["spec"]["model"]], get_control(phase), positions[target], fixed["spec"]["scope"]
            )
            record_metric(confirmed, phase, y[target], candidate, get_control(phase))
            confirmation_audit[phase] = stats
            print(
                "DEFENSIVE_CONFIRM " + json.dumps({"cohort": cohort, "phase": phase, **confirmed["periods"][phase]}),
                flush=True,
            )
        winner = confirmed if min(confirmed["gains"]) > 0 else None
        frozen = {
            **screening,
            "winner": winner,
            "finalCandidate": confirmed,
            "confirmationSimulation": confirmation_audit,
            "passingCandidates2048": sum(min(r["gains"]) > 0 for r in records),
        }
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
        print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "finalCandidate": confirmed}), flush=True)
        phase = "later2026"
        target = masks[phase]["target"]
        predictions, stats = predict(phase, selected_models, 8192)
        control = get_control(phase)
        alternate = scoped(predictions[fixed["spec"]["model"]], control, positions[target], fixed["spec"]["scope"])
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": confirmed,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "laterSimulation": stats,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(
                y[target], alternate, control, [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
            ),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
