import copy

import numpy as np
import pytest

from app.research.score_additive_identity import AdditiveWindows


def test_player_effects_keep_separate_native_modes_and_preserve_unknown_players():
    numeric = np.zeros((100, 2))
    categories = np.array([["a"]] * 60 + [["b"]] * 40, dtype=object)
    scores = np.array([40] * 60 + [80] * 40)
    model = AdditiveWindows().fit(numeric, categories, scores)
    probability = model.predict(np.zeros((3, 2)), [["a"], ["b"], ["cold"]], 1, 5)
    assert probability.shape == (3, 101) and np.isfinite(probability).all()
    assert probability[0, 40] > probability[0, 80]
    assert probability[1, 80] > probability[1, 40]
    np.testing.assert_equal(probability[:, 56], 0)
    assert np.argmax(probability[0]) in range(33, 48)
    assert np.argmax(probability[1]) in range(73, 88)


def test_future_outliers_and_new_identities_cannot_change_fitted_state():
    model = AdditiveWindows().fit([[0], [2], [np.nan], [6]], [["a"], ["b"], [None], ["b"]], [30, 40, 60, 80])
    before = model.predict([[0]], [["a"]])
    means, maps = model.normaliser_.mean_.copy(), copy.deepcopy(model.category_maps_)
    model.predict([[1000000], [np.nan]], [["new"], ["another"]])
    np.testing.assert_equal(model.normaliser_.mean_, means)
    assert model.category_maps_ == maps
    np.testing.assert_allclose(model.predict([[0]], [["a"]]), before)
    assert not np.array_equal(model.normaliser_.transform([[0]]), model.normaliser_.transform([[np.nan]]))


def test_unpenalised_intercept_uses_exact_native_window_boundaries_not_rounded_labels():
    model = AdditiveWindows().fit(np.zeros((3, 1)), [["a"]] * 3, [33, 47, 47.001])
    assert model.predict([[0]], [["a"]])[0, 40] == pytest.approx(2 / 3)
    with pytest.raises(ValueError, match="valid native labels"):
        AdditiveWindows().fit([[0]], [["a"]], [np.nan])
