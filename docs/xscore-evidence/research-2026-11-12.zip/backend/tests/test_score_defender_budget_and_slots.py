import numpy as np

from app.research.score_defender_budget import allocate, components
from app.research.score_defender_role_pressure import pressure_weight, summarize, window_summary
from app.research.score_defender_slots import archived_slot, history_features


def test_defender_budget_keeps_negative_duel_points():
    person = {"stats": {"duel_lost": [4, -8], "duel_won": [2, 3], "interception_won": [1, 2]}}
    np.testing.assert_array_equal(components(person), [0, 2, -5, 0, 2, 3])


def test_budget_missing_team_history_keeps_personal_forecast():
    own = [np.array([90, 3, 2, -4, 3, 2, 4])]
    personal, pooled, adjustment = allocate(own, own, [], 90)
    assert personal[2] < 0
    np.testing.assert_array_equal(pooled, np.zeros(6))
    np.testing.assert_array_equal(adjustment, np.zeros(6))


def test_known_archive_slots_and_cold_role_prediction():
    assert [archived_slot(s) for s in ("DC", "DL", "DR", "DMC", "Sub")] == ["centre", "wide", "wide", "advanced", None]
    anchor, result = history_features([], [(1, 12), (1, 16)], 7)
    assert anchor == 7 and np.argmax(result[:3]) == 1
    np.testing.assert_array_equal(result[3:], np.zeros(4))


def test_empirical_defender_windows_do_not_average_separate_peaks():
    centre, probability, mean = window_summary(np.array([-12, -12, 22]), np.ones(3))
    assert abs(centre + 12) <= 7
    assert abs(centre - 22) > 7
    assert probability == 2 / 3 and mean == -2 / 3


def test_missing_pressure_leaves_role_only_weights_in_place():
    sample = [(0, 4, np.array([2, 2, 2])), (1, 18, np.array([1, 1, 1]))]
    values = summarize(sample, np.array([0.9, 0.1, 0.0]), np.full(3, np.nan))
    np.testing.assert_array_equal(values[0], values[2])
    np.testing.assert_array_equal(values[1], values[3])
    weight = pressure_weight(np.array([[1, 0, np.nan], [2, 0, np.nan]]), np.array([1, 0, 0]))
    assert weight[0] == 1 and weight[1] < 1
