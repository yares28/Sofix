"""Independent full official assignment PDF rows, version clocks and forecast choices."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research import score_referee_archive as primary
from app.research.score_market_booklets_audit import pdf_date
from app.research.score_referee_source_audit import Published


def timestamp(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def newest(rows, cutoff):
    old = [
        r
        for r in rows
        if r.get("referee") is not None and r["availableUTC"] is not None and timestamp(r["availableUTC"]) < cutoff
    ]
    if not old:
        return None
    time = max(timestamp(r["availableUTC"]) for r in old)
    candidates = [r for r in old if timestamp(r["availableUTC"]) == time]
    return candidates[0] if len({r["referee"] for r in candidates}) == 1 else None


def main():
    import pdfplumber
    from pypdf import PdfReader

    folder = Path("data/raw/score-foundation/referee-source")
    reports = Path("reports/experiments")
    result = json.loads((reports / "laliga_score_referee_archive.json").read_text())
    manifest = (folder / "archive_pdf_manifest.json").read_bytes()
    if hashlib.sha256(manifest).hexdigest() != result["documentManifestSHA"]:
        raise ValueError("Official document manifest changed")
    key = hashlib.sha256(
        Path(primary.__file__).read_bytes()
        + manifest
        + result["announcementAuditKey"].encode()
        + result["nativeSHA"].encode()
    ).hexdigest()
    if key != result["implementationKey"]:
        raise ValueError("Official document reader key changed")
    entries = {e["File"]: e for e in json.loads(manifest.decode("utf-8-sig"))}
    requests = json.loads((folder / "archive_pdf_requests.json").read_text())
    if {e["Url"] for e in entries.values()} != {e["Url"] for e in requests} or len(entries) != len(requests):
        raise ValueError("Entire official document request coverage differs")
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    if hashlib.sha256(native.read_bytes()).hexdigest() != result["nativeSHA"]:
        raise ValueError("Native source bytes differ")
    schedule = {
        g["id"]: {k: g[k] for k in ["id", "date", "home", "away"]}
        for g in map(json.loads, native.read_text(encoding="utf-8").splitlines())
    }
    allrows = []
    known_clock_docs = 0
    for doc in result["documents"]:
        entry = entries[doc["file"]]
        if doc["status"] == "unreadable_document":
            if entry["Status"] == "downloaded" or doc["assignments"]:
                raise ValueError("Unreadable PDF received invented assignments")
            continue
        raw = (folder / doc["file"]).read_bytes()
        if (
            not raw.startswith(b"%PDF-")
            or hashlib.sha256(raw).hexdigest() != doc["sha256"]
            or doc["sha256"] != entry["SHA256"].lower()
        ):
            raise ValueError("Actual official PDF bytes differ")
        parent_times = []
        for parent in entry["Parents"]:
            raw_parent = (folder / parent["File"]).read_bytes()
            if hashlib.sha256(raw_parent).hexdigest() != parent["SHA256"].lower():
                raise ValueError("Parent article bytes differ")
            parser = Published()
            parser.feed(raw_parent.decode("utf-8"))
            time = (
                datetime.strptime("".join(parser.content).strip().split(", ", 1)[1], "%d/%m/%Y - %H:%M")
                .replace(tzinfo=ZoneInfo("Europe/Madrid"))
                .astimezone(UTC)
            )
            if time != timestamp(parent["PublicationUTC"]):
                raise ValueError("Independent parent publication differs")
            parent_times.append(time)
        metadata = PdfReader(folder / doc["file"]).metadata
        if doc["clockError"] is None:
            creation, modification = pdf_date(metadata["/CreationDate"]), pdf_date(metadata["/ModDate"])
            http = parsedate_to_datetime(entry["LastModified"][0])
            clock = max(min(parent_times), creation, modification, http)
            if any(
                timestamp(doc[k]) != v
                for k, v in [
                    ("creationUTC", creation),
                    ("modificationUTC", modification),
                    ("httpLastModifiedUTC", http),
                    ("availableUTC", clock),
                ]
            ):
                raise ValueError("Independent document version clock differs")
            known_clock_docs += 1
        elif doc["availableUTC"] is not None:
            raise ValueError("Unknown-clock document acquired a source time")
        with pdfplumber.open(folder / doc["file"]) as pdf:
            text = {i + 1: p.extract_text() for i, p in enumerate(pdf.pages)}
        if doc["parseError"] is not None:
            if doc["assignments"]:
                raise ValueError("Quarantined source document received partial assignments")
            continue
        source_headers = Counter(
            " ".join(m.split()) for t in text.values() for m in re.findall(r"(?m)^\d{2}-\d{2}-\d{4} .+ \d{2}:\d{2}$", t)
        )
        expected_headers = Counter()
        for row in doc["assignments"]:
            day = datetime.fromisoformat(row["localDate"])
            line = day.strftime("%d-%m-%Y") + " " + row["printedPair"] + " " + row["time"]
            expected_headers[line] += 1
            page = "\n".join(" ".join(v.split()) for v in text[row["page"]].splitlines())
            if row["referee"] is not None and not re.search(
                re.escape(line) + r"\nÁrbitr[oa]:\s*" + re.escape(row["referee"]) + r"\s+4[ºª] Árbitr[oa]:", page
            ):
                raise ValueError("Second PDF engine printed fixture/main-referee row differs")
            if row["referee"] is None:
                if line not in page:
                    raise ValueError("Printed unassigned fixture missing")
                tail = page.split(line, 1)[1]
                boundary = re.search(r"\n\d{2}-\d{2}-\d{4} ", tail)
                block = tail[: boundary.start()] if boundary is not None else tail
                if re.search(r"Árbitr[oa]:", block):
                    raise ValueError("Unassigned fixture silently lost its printed referee")
            at = (
                datetime.fromisoformat(row["localDate"] + "T" + row["time"])
                .replace(tzinfo=ZoneInfo("Europe/Madrid"))
                .astimezone(UTC)
            )
            candidates = sorted(
                g["id"]
                for g in schedule.values()
                if timestamp(g["date"]) == at
                and g["home"]["slug"] == primary.OFFICIAL_CLUBS[row["home"]]
                and g["away"]["slug"] == primary.OFFICIAL_CLUBS[row["away"]]
            )
            if candidates != sorted(row["fixtureCandidates"]) or row["game"] != (
                candidates[0] if len(candidates) == 1 else None
            ):
                raise ValueError("Independent schedule-only native fixture identity differs")
            if row["availableUTC"] != doc["availableUTC"] or timestamp(row["kickoffUTC"]) != at:
                raise ValueError("Source row clocks differ")
            allrows.append(row)
        referee_labels = sum(len(re.findall(r"(?m)^Árbitr[oa]:", t)) for t in text.values())
        if source_headers != expected_headers or referee_labels != sum(
            r["referee"] is not None for r in doc["assignments"]
        ):
            raise ValueError("Complete printed source row coverage differs")
    if len(allrows) != result["sourceRows"]:
        raise ValueError("Source row population differs")
    indexed = defaultdict(list)
    for row in allrows:
        if row["game"] is not None:
            indexed[row["game"]].append(row)
    choices = {r["game"]: r for r in result["fixtureChoices"]}
    if set(choices) != set(schedule):
        raise ValueError("Full native fixture population differs")
    for game, g in schedule.items():
        at = timestamp(g["date"])
        lock = max(
            (at - timedelta(days=i)).replace(hour=14, minute=0, second=0, microsecond=0)
            for i in range(8)
            if (at - timedelta(days=i)).weekday() in (1, 4)
            and (at - timedelta(days=i)).replace(hour=14, minute=0, second=0, microsecond=0) <= at
        )
        if choices[game]["prelock"] != newest(indexed[game], lock) or choices[game]["pregame"] != newest(
            indexed[game], at
        ):
            raise ValueError("Independent latest nonconflicting before-cutoff choice differs")
    receipt = dict(
        status="COMPLETE full official source reconstruction audit; no forecast fit",
        implementationKey=key,
        documents=len(result["documents"]),
        independentPrintedRows=len(allrows),
        knownClockDocuments=known_clock_docs,
        quarantinedDocuments=sum(d["status"] == "parse_error" for d in result["documents"]),
        nativeFixtureChoices=len(choices),
        independentAllVersionClocks=True,
        independentAllNativeClocks=True,
        secondPDFEngineAllParsedRows=True,
        noParticipantsOrOutcomesUsedForLinkage=True,
        originalReceiptUnproven=True,
        modelFits=0,
    )
    (reports / "laliga_score_referee_archive.integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("REFEREE_ARCHIVE_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
