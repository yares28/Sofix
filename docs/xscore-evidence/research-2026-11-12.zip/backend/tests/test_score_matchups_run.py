import numpy as np
import pytest

from app.research.score_matchups_run import component_policy, feature_groups, validate_stat_identity


def test_team_composition_ablation_excludes_role_matchup_and_quality_adjustments():
    names = [
        "own_known_games",
        "opponent_total_duel_won",
        "opponent_matchup_duel_won",
        "expected_duel_fraction",
        "duel_point_change90",
        "opponent_baseline_duel_fraction",
        "teammates_recent_games",
    ]
    groups = feature_groups(names)
    np.testing.assert_array_equal(groups["team_composition"], [True, True, False, False, False, False, True])
    assert groups["full_role_matchups"].all()


def test_component_ablation_changes_only_the_requested_forecast_piece():
    old = (np.array([35, 60]), np.array([[0.8, 0.2]]), {0.5: np.array([[1.0, 2]])})
    new = (np.array([35, 60]), np.array([[0.4, 0.6]]), {0.5: np.array([[3.0, 4]])})
    ordinary = component_policy(old, new, "ordinary")
    events = component_policy(old, new, "events")
    assert ordinary[1] is old[1] and ordinary[2] is new[2]
    assert events[1] is new[1] and events[2] is old[2]
    assert component_policy(old, new, "both") is new
    with pytest.raises(ValueError, match="classes"):
        component_policy(old, (np.array([35, 70]), new[1], new[2]), "both")


def test_raw_stat_key_and_combined_stat_team_key_are_distinct_contracts():
    import hashlib

    match = {"statKey": "raw", "featureKey": "team"}
    player = {"statKey": hashlib.sha256(b"rawteam").hexdigest()}
    validate_stat_identity("raw", match, player)
    with pytest.raises(ValueError, match="Raw stat"):
        validate_stat_identity("other", match, player)
    with pytest.raises(ValueError, match="Combined"):
        validate_stat_identity("raw", match, {"statKey": "raw"})
