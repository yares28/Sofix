"""Testing only: defensive-point mixtures and paired past routine/minute errors."""

from __future__ import annotations

import numpy as np

PARAMETERS = {
    f"{exposure}_{goals}_{location}_spread{spread}": {
        "exposure": exposure,
        "goals": goals,
        "location": location,
        "spread": spread,
    }
    for exposure in ("uniform", "learned")
    for goals in ("lambda", "calibratedCS")
    for location in ("mean", "median")
    for spread in (0.75, 1)
}


def monotone(values, weights):
    values, weights = np.asarray(values, dtype=float), np.asarray(weights, dtype=float)
    if (
        values.ndim != 1
        or values.shape != weights.shape
        or not len(values)
        or not np.isfinite(values).all()
        or not np.isfinite(weights).all()
        or (weights <= 0).any()
    ):
        raise ValueError("Finite values and positive isotonic weights required")
    blocks = []
    for value, weight in zip(values, weights, strict=True):
        blocks.append([float(value), float(weight), 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            right, left = blocks.pop(), blocks.pop()
            total = left[1] + right[1]
            blocks.append([(left[0] * left[1] + right[0] * right[1]) / total, total, left[2] + right[2]])
    return np.concatenate([np.full(block[2], block[0]) for block in blocks])


def fit_exposure(minutes, conceded, team_conceded, positions, fit):

    selected = np.asarray(fit) & np.isin(positions, ["DEF", "MID", "GK"])
    m = np.asarray(minutes, dtype=float)[selected]
    player = np.asarray(conceded, dtype=float)[selected]
    team = np.asarray(team_conceded, dtype=float)[selected]
    if (
        not np.isfinite(m).all()
        or not np.isfinite(player).all()
        or not np.isfinite(team).all()
        or ((m < 1) | (m > 90) | (m != np.rint(m))).any()
        or (player < 0).any()
        or (player > team).any()
    ):
        raise ValueError("Known native fit exposure and conceded labels required")
    numerator = np.bincount(m.astype(int), weights=player, minlength=91)
    denominator = np.bincount(m.astype(int), weights=team, minlength=91)
    axis = np.arange(91, dtype=float)
    weights = denominator + 20
    ratio = (numerator + 20 * axis / 90) / weights
    curve = np.clip(monotone(ratio, weights), 0, 1)
    curve[0], curve[90] = 0, 1
    if not np.isfinite(curve).all() or (np.diff(curve) < -1e-12).any():
        raise ValueError("Invalid monotone conceded exposure")
    return curve, {
        "fitCases": int(selected.sum()),
        "playerConceded": float(player.sum()),
        "teamConceded": float(team.sum()),
        "binsWithoutGoals": int((denominator == 0).sum()),
        "fullGameEndpoint": 1,
    }


def point_effect(conceded, minutes, positions):
    conceded, minutes = np.asarray(conceded, dtype=float), np.asarray(minutes, dtype=float)
    pos = np.asarray(positions)
    if (
        not np.isin(pos, ["DEF", "MID"]).all()
        or not np.isfinite(conceded).all()
        or (conceded < 0).any()
        or not np.isfinite(minutes).all()
        or ((minutes < 1) | (minutes > 90)).any()
    ):
        raise ValueError("Supported defensive points and minute range1..90required")
    while pos.ndim < minutes.ndim:
        pos = pos[..., None]
    weights = np.where(pos == "DEF", -4.0, -2.0)
    clean = (minutes >= 60) & (conceded == 0)
    return weights * conceded + (pos == "DEF") * 10 * clean


def rate_and_zero(lam, clean, minutes, curve, method):
    lam, clean, minutes = map(lambda x: np.asarray(x, dtype=float), (lam, clean, minutes))
    if (
        not all(np.isfinite(x).all() for x in (lam, clean, minutes))
        or (lam < 0).any()
        or ((clean < 0) | (clean > 1)).any()
        or ((minutes < 1) | (minutes > 90)).any()
    ):
        raise ValueError("Known valid forecast goals, clean chance and sampled minutes required")
    if curve is not None:
        curve = np.asarray(curve, dtype=float)
        if (
            curve.shape != (91,)
            or not np.isfinite(curve).all()
            or ((curve < 0) | (curve > 1)).any()
            or (np.diff(curve) < -1e-12).any()
        ):
            raise ValueError("Valid monotone exposure curve required")
    exposure = minutes / 90 if curve is None else np.interp(minutes, np.arange(91), curve)
    while lam.ndim < minutes.ndim:
        lam = lam[..., None]
    while clean.ndim < minutes.ndim:
        clean = clean[..., None]
    rate = lam * exposure
    if method == "lambda":
        zero = np.exp(-rate)
    elif method == "calibratedCS":
        zero = clean**exposure
    else:
        raise ValueError("Unknown defensive goal distribution")
    return rate, zero


def forecast_effect(lam, clean, minutes, positions, curve, method, location):
    from scipy.stats import poisson

    rate, zero = rate_and_zero(lam, clean, minutes, curve, method)
    positive = -np.expm1(-rate)
    if location == "mean":
        conditional_mean = np.divide(rate, positive, out=np.ones_like(rate), where=positive > 1e-12)
        expected_goals = (1 - zero) * conditional_mean
        pos = np.asarray(positions)
        while pos.ndim < rate.ndim:
            pos = pos[..., None]
        return (
            np.where(pos == "DEF", -4.0, -2.0) * expected_goals
            + (pos == "DEF") * 10 * (np.asarray(minutes) >= 60) * zero
        )
    if location != "median":
        raise ValueError("Unknown defensive point location")
    quantile = np.divide(0.5 - zero, 1 - zero, out=np.zeros_like(zero), where=zero < 0.5)
    cdf = np.clip(np.exp(-rate) + positive * np.clip(quantile, 0, 1), 0, 1 - 1e-12)
    median = np.where(zero >= 0.5, 0, np.maximum(1, poisson.ppf(cdf, rate)))
    return point_effect(median, minutes, positions)


def draw_conceded(lam, clean, minutes, curve, method, uniform):
    from scipy.stats import poisson

    rate, zero = rate_and_zero(lam, clean, minutes, curve, method)
    u = np.asarray(uniform, dtype=float)
    if not np.isfinite(u).all() or ((u < 0) | (u >= 1)).any():
        raise ValueError("Conceded sampler requires uniform values in0..1")
    conditional = np.clip((u - zero) / np.maximum(1 - zero, 1e-15), 0, 1)
    cdf = np.clip(np.exp(-rate) + (-np.expm1(-rate)) * conditional, 0, 1 - 1e-12)
    positive = np.maximum(1, poisson.ppf(cdf, rate))
    return np.where(u <= zero, 0, positive)


def paired_draws(pooled, conditional, mixture_uniform, record_uniform, prior=20):
    pooled, conditional = np.asarray(pooled, dtype=float), np.asarray(conditional, dtype=float).reshape(-1, 2)
    mixture_uniform, record_uniform = map(lambda x: np.asarray(x, dtype=float), (mixture_uniform, record_uniform))
    if (
        pooled.ndim != 2
        or pooled.shape[1] != 2
        or not len(pooled)
        or not np.isfinite(pooled).all()
        or not np.isfinite(conditional).all()
        or mixture_uniform.shape != record_uniform.shape
        or not np.isfinite(mixture_uniform).all()
        or not np.isfinite(record_uniform).all()
        or prior < 0
        or ((mixture_uniform < 0) | (mixture_uniform >= 1) | (record_uniform < 0) | (record_uniform >= 1)).any()
    ):
        raise ValueError("Known paired calibration errors and valid uniforms required")
    global_draw = pooled[np.minimum((record_uniform * len(pooled)).astype(int), len(pooled) - 1)]
    if not len(conditional):
        return global_draw
    own_draw = conditional[np.minimum((record_uniform * len(conditional)).astype(int), len(conditional) - 1)]
    chosen = mixture_uniform < len(conditional) / (len(conditional) + prior)
    return np.where(chosen[..., None], own_draw, global_draw)
