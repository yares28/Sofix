"""Earlier-only test of conditional substitution history."""

import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from functools import lru_cache
from math import exp

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, fit, metrics

STEM = "laliga_score_substitution_signal"
AGE = timedelta(days=365)
STATES = (-1, 0, 1)


@lru_cache(maxsize=1500)
def state_probabilities(own, opponent):
    if not (0 <= own <= 8 and 0 <= opponent <= 8):
        return None
    columns = []
    for rate in (own * 2 / 3, opponent * 2 / 3):
        mass = [exp(-rate)]
        for n in range(1, 31):
            mass.append(mass[-1] * rate / n)
        columns.append(mass)
    grid = np.outer(*columns)
    return np.array([np.triu(grid, 1).sum(), grid.trace(), np.tril(grid, -1).sum()]) / grid.sum()


def time_history(history, lock, probs, default):
    observations = [(state, minutes) for t, state, minutes in history if t >= lock - AGE]
    if not observations:
        return default, 0.0, 0
    general = sum(v for _, v in observations) / len(observations)
    if probs is None:
        return general, 0.0, len(observations)
    totals, counts = np.zeros(3), np.zeros(3)
    for state, minutes in observations:
        totals[state + 1] += minutes
        counts[state + 1] += 1
    means = (totals + 8 * general) / (counts + 8)
    return general, float(probs @ means - general), len(observations)


def inputs(rows, games, records, names):
    fixtures = {g["id"]: g for g in games}
    if len(fixtures) != len(games):
        raise ValueError("Duplicate fixture")
    available = sorted(
        [(moment(r["date"]) + DELAY, r) for r in records if r["at60"] is not None],
        key=lambda entry: (entry[0], entry[1]["game"], entry[1]["club"]),
    )
    home_rate, away_rate = (names.index(f"match_lam_{side}") for side in ("h", "a"))
    units, people = defaultdict(list), defaultdict(list)
    outputs, cursor = np.empty((len(rows), 6)), 0
    locks = [cutoff_for(r["date"]) for r in rows]
    for i in sorted(range(len(rows)), key=locks.__getitem__):
        row, lock = rows[i], locks[i]
        while cursor < len(available) and available[cursor][0] < lock:
            ready, record = available[cursor]
            historical = fixtures[record["game"]]
            state = STATES[(record["at60"] >= 0) + (record["at60"] > 0)]
            for p in record["players"]:
                original = historical["players"][p["player"]]
                assert original["team"] == record["club"] and original["started"] == p["started"]
                key = record["club"], p["position"], "start" if p["started"] else "bench"
                entry = ready - DELAY, state, original["mins"]
                units[key].append(entry)
                people[p["player"], *key].append(entry)
            cursor += 1
        game = fixtures[row["game"]]
        club = game["players"][row["player"]]["team"]
        assert row["date"] == game["date"] and club in (game["home"]["slug"], game["away"]["slug"])
        home, away = row["x"][home_rate], row["x"][away_rate]
        probs = state_probabilities(home, away) if club == game["home"]["slug"] else state_probabilities(away, home)
        key = club, row["pos"], row["cohort"]
        default = 80.0 if row["cohort"] == "start" else 20.0
        club_mean, club_shift, club_n = time_history(units[key], lock, probs, default)
        person_mean, person_shift, person_n = time_history(people[row["player"], *key], lock, probs, club_mean)
        outputs[i] = club_mean, person_mean, np.log1p(club_n), np.log1p(person_n), club_shift, person_shift
    return outputs


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    receipt = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    archive = (ROOT / "laliga_score_substitution_clock.json").read_bytes()
    assert hashlib.sha256(archive).hexdigest() == receipt["qualifiedCacheSHA"] and receipt["nativeSHA"] == NATIVE_SHA
    extra = inputs(rows, games, json.loads(archive), source["features"])
    baseline_x = np.array([r["x"] for r in rows])
    base, full = (np.column_stack((baseline_x, e)) for e in (extra[:, :-2], extra))
    roles = np.array([r["cohort"] for r in rows])
    dates = np.array([r["date"] for r in rows])
    locks = np.array([cutoff_for(d) for d in dates])
    ready = np.array([moment(d) + DELAY for d in dates])
    minutes = np.array([r["minutes"] for r in rows])
    points = np.array([r["aa"] for r in rows])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        window = (dates >= begin) & (dates < end)
        earlier = ready < locks[window].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, check = earlier & (roles == role), window & (roles == role)
            individual = baseline_x[:, source["features"].index(f"{role}_10_minutes")]
            aa = baseline_x[:, source["features"].index(f"{role}_10_aa")]
            m0, m1 = [
                np.clip(individual[check] + fit(x, minutes - individual, train, check), 1, 100) for x in (base, full)
            ]
            p0, p1 = [fit(x, points - aa, train, check) for x in (base, full)]
            event = (lambda v: v <= 65) if role == "start" else (lambda v: v >= 25)
            truth = event(minutes[check])
            periods[phase][role] = dict(
                routine=metrics(points[check] - aa[check], p0, p1),
                minutesMAE=[float(np.mean(abs(minutes[check] - p))) for p in (m0, m1)],
                actualEarlyExitOrLongBench=int(truth.sum()),
                eventCorrect=[int((truth == event(p)).sum()) for p in (m0, m1)],
                eventCorrectPositive=[int((truth & event(p)).sum()) for p in (m0, m1)],
                stateChangedEstimate=int(np.any(extra[check, -2:] != 0, axis=1).sum()),
            )
    gate = {}
    for role in ("start", "bench"):
        p = [v[role] for v in periods.values()]
        n = sum(r["routine"]["n"] for r in p)
        minute_gain = sum(r["routine"]["n"] * (r["minutesMAE"][0] - r["minutesMAE"][1]) for r in p) / n
        point_gain = sum(r["routine"]["n"] * (r["routine"]["mae"][0] - r["routine"]["mae"][1]) for r in p) / n
        hit_gain = sum(r["routine"]["gained"] - r["routine"]["lost"] for r in p)
        phases_without_loss = sum(
            r["minutesMAE"][1] <= r["minutesMAE"][0]
            and r["routine"]["mae"][1] <= r["routine"]["mae"][0]
            and r["routine"]["hits"][1] >= r["routine"]["hits"][0]
            for r in p
        )
        gate[role] = dict(
            n=n,
            minutesMAEGain=minute_gain,
            pointMAEGain=point_gain,
            routineHitGain=hit_gain,
            phasesWithoutLoss=phases_without_loss,
            passEarlier=minute_gain > 0 and point_gain > 0 and hit_gain > 0 and phases_without_loss >= 2,
        )
    result = dict(
        sourceSHA=receipt["qualifiedCacheSHA"],
        periods=periods,
        gate=gate,
        laterOutcomesEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
