from datetime import UTC, datetime, timedelta

import numpy as np

from app.research.score_substitution_clock import decision_state, paired_clocks
from app.research.score_substitution_exposure import counts
from app.research.score_substitution_signal import state_probabilities, time_history
from app.research.score_travel_recovery import distance, schedule_features


def test_match_state_at_a_goal_minute_is_unknown():
    goals = [(18, "home"), (60, "away")]
    assert decision_state(goals, "home", 60) is None
    assert decision_state(goals, "home", 59) == 1
    assert decision_state(goals, "away", 59) == -1
    assert decision_state(goals, "home", 61) == 0


def test_substitution_entry_needs_a_matching_exit():
    starters = [{"on": None, "off": None, "mins": 90, "rc": 0} for _ in range(11)]
    starters[0]["off"] = 61
    sub = {"on": 60, "off": None, "mins": 30, "rc": 0}
    unit = dict(starters=starters, subs=[sub])
    assert paired_clocks(unit, 90)[1] == "unpaired_clock"
    sub["on"] = 61
    assert paired_clocks(unit, 90)[1] == "paired"
    starters[1]["rc"] = 1
    assert paired_clocks(unit, 90)[1] == "dismissal_present"


def test_travel_distance_symmetry_and_short_turnaround():
    madrid = {"lat": 40.4165, "lon": -3.70256}
    bilbao = {"lat": 43.26271, "lon": -2.92528}
    trip = distance(madrid, bilbao)
    assert 320 < trip < 325
    assert trip == distance(bilbao, madrid)
    assert distance(bilbao, bilbao) == 0
    kickoff = datetime(2025, 1, 17, tzinfo=UTC)
    cold, cold_travel = schedule_features([], kickoff, trip)
    known, known_travel = schedule_features([(kickoff - timedelta(days=4), trip)], kickoff, trip)
    assert cold[0] == 0 and known[:4] == (1, 4, 1, 1)
    assert known_travel[0] == cold_travel[0]
    assert known_travel[2] > cold_travel[2] == 0


def test_prelock_state_probabilities_reverse_with_teams():
    weaker = state_probabilities(0.6, 1.8)
    stronger = state_probabilities(1.8, 0.6)
    np.testing.assert_allclose(weaker, stronger[::-1])
    assert weaker[0] > weaker[2]
    np.testing.assert_array_equal(state_probabilities(0, 0), [0, 1, 0])
    assert state_probabilities(-1, 0) is None


def test_conditioned_minutes_keep_cold_and_unknown_fallbacks():
    at = datetime(2025, 1, 1, tzinfo=UTC)
    prior = [(at - timedelta(days=7), -1, 60), (at - timedelta(days=7), 1, 90)]
    assert time_history([], at, np.array([1, 0, 0]), 80) == (80, 0, 0)
    assert time_history(prior, at, None, 80) == (75, 0, 2)
    mean, shift, count = time_history(prior, at, np.array([1, 0, 0]), 80)
    assert mean == 75 and count == 2 and -2 < shift < -1


def test_substitution_exposure_ends_at_decision_and_skips_goal_clock():
    record = dict(goalsForClub=[(59, -1)], players=[dict(started=True, off=62, position="MID")])
    exposure, events = counts([record])
    assert exposure == {("start", "46-59", "MID", "level"): 13, ("start", "60-74", "MID", "trailing"): 3}
    assert events[("start", "60-74", "MID", "trailing")] == 1
    assert sum(events.values()) == 1
