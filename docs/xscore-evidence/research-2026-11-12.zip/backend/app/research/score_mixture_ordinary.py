"""Testing only: conditional mixtures for native ordinary-action point densities."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research.score_action_network import Normaliser
from app.research.score_modal_trees import CENTRES

SETTINGS = {
    "k2_width32_l2small": {"components": 2, "width": 32, "ridge": 0.001},
    "k2_width32_l2large": {"components": 2, "width": 32, "ridge": 0.01},
    "k4_width64_l2large": {"components": 4, "width": 64, "ridge": 0.01},
}
POSITIONS = ("GK", "DEF", "MID", "FWD")


def sigmoid(values):
    e = np.exp(-np.abs(values))
    return np.where(values >= 0, 1 / (1 + e), e / (1 + e))


def parameters(x, weights, components):
    a, b, c, d = weights
    hidden = np.tanh(x @ a + b)
    raw = hidden @ c + d
    logits = raw[:, :components]
    logits = logits - logits.max(axis=1, keepdims=True)
    mixing = np.exp(logits)
    log_mixing = logits - np.log(mixing.sum(axis=1, keepdims=True))
    mixing /= mixing.sum(axis=1, keepdims=True)
    means = 20 * raw[:, components : 2 * components]
    scale_gate = sigmoid(raw[:, 2 * components :])
    scales = 2 + 38 * scale_gate
    return hidden, mixing, means, scales, scale_gate, log_mixing


def loss_gradient(x, aa, weights, components, ridge):
    hidden, mixing, means, scales, scale_gate, log_mixing = parameters(x, weights, components)
    difference = means - aa[:, None]
    log_density = log_mixing - np.log(scales) - 0.5 * np.log(2 * np.pi) - 0.5 * (difference / scales) ** 2
    peak = log_density.max(axis=1, keepdims=True)
    relative = np.exp(log_density - peak)
    total = relative.sum(axis=1, keepdims=True)
    responsibility = relative / total
    loss = -float(np.mean(peak + np.log(total)))
    delta = np.column_stack(
        (
            mixing - responsibility,
            20 * responsibility * difference / scales**2,
            responsibility * (1 / scales - difference**2 / scales**3) * 38 * scale_gate * (1 - scale_gate),
        )
    ) / len(x)
    a, _, c, _ = weights
    upstream = (delta @ c.T) * (1 - hidden**2)
    gradients = [x.T @ upstream + ridge * a, upstream.sum(axis=0), hidden.T @ delta + ridge * c, delta.sum(axis=0)]
    loss += 0.5 * ridge * ((a**2).sum() + (c**2).sum())
    return float(loss), gradients


class MixtureNetwork:
    def __init__(self, components, width, ridge, epochs=80, batch=256, seed=20261104):
        self.components, self.width, self.ridge = components, width, ridge
        self.epochs, self.batch, self.seed = epochs, batch, seed

    def fit(self, raw, aa):
        aa = np.asarray(aa, dtype=np.float32)
        if aa.shape != (len(raw),) or not len(aa) or not np.isfinite(aa).all() or self.epochs <= 0:
            raise ValueError("Available native AA labels and fixed positive epochs required")
        self.normaliser_ = Normaliser().fit(raw)
        x = self.normaliser_.transform(raw)
        rng = np.random.default_rng(self.seed)
        self.weights_ = [
            rng.normal(0, 1 / np.sqrt(x.shape[1]), (x.shape[1], self.width)).astype(np.float32),
            np.zeros(self.width, dtype=np.float32),
            rng.normal(0, 0.01, (self.width, 3 * self.components)).astype(np.float32),
            np.zeros(3 * self.components, dtype=np.float32),
        ]
        self.weights_[3][self.components : 2 * self.components] = (
            np.quantile(aa, (np.arange(self.components) + 0.5) / self.components) / 20
        )
        initial_scale = float(np.clip(np.std(aa) / 2, 4, 20))
        self.weights_[3][2 * self.components :] = np.log((initial_scale - 2) / (40 - initial_scale))
        means = [np.zeros_like(w) for w in self.weights_]
        squares = [np.zeros_like(w) for w in self.weights_]
        step = 0
        self.loss_history_ = []
        for epoch in range(self.epochs):
            order = rng.permutation(len(x))
            total = 0.0
            for begin in range(0, len(x), self.batch):
                at = order[begin : begin + self.batch]
                loss, gradients = loss_gradient(x[at], aa[at], self.weights_, self.components, self.ridge)
                if not np.isfinite(loss) or any(not np.isfinite(g).all() for g in gradients):
                    raise ValueError("Mixture AA fit became nonfinite")
                norm = np.sqrt(sum(float(np.square(g, dtype=np.float64).sum()) for g in gradients))
                if norm > 10:
                    gradients = [g * (10 / norm) for g in gradients]
                step += 1
                for j, g in enumerate(gradients):
                    means[j] = 0.9 * means[j] + 0.1 * g
                    squares[j] = 0.999 * squares[j] + 0.001 * g**2
                    self.weights_[j] -= (
                        0.001 * (means[j] / (1 - 0.9**step)) / (np.sqrt(squares[j] / (1 - 0.999**step)) + 1e-8)
                    )
                total += loss * len(at)
            self.loss_history_.append(float(total / len(x)))
            if (epoch + 1) % 20 == 0:
                print(
                    f"MIXTURE_AA_EPOCH {epoch + 1}/{self.epochs} trainingOnlyLoss{self.loss_history_[-1]:.6f}",
                    flush=True,
                )
        return self

    def predict(self, raw):
        _, mixing, means, scales, _, _ = parameters(self.normaliser_.transform(raw), self.weights_, self.components)
        mixing = mixing.astype(float)
        mixing /= mixing.sum(axis=1, keepdims=True)
        return mixing, means.astype(float), scales.astype(float)


def mixture_mass(mixing, means, scales, level):
    from scipy.special import ndtr

    mixing, means, scales = map(np.asarray, (mixing, means, scales))
    if (
        mixing.ndim != 2
        or mixing.shape != means.shape
        or means.shape != scales.shape
        or not np.isfinite([mixing, means, scales]).all()
        or (mixing < 0).any()
        or (scales <= 0).any()
        or not np.allclose(mixing.sum(axis=1), 1)
    ):
        raise ValueError("Valid conditional AA mixture parameters required")
    floor = level if level >= 60 else 0
    lower, upper = CENTRES - 7, CENTRES + 7
    lo = ndtr((lower[None, None, :] - level - means[:, :, None]) / scales[:, :, None])
    hi = ndtr((upper[None, None, :] - level - means[:, :, None]) / scales[:, :, None])
    lo = np.where(lower[None, None, :] <= floor, 0, lo)
    hi = np.where(upper[None, None, :] >= 100, 1, hi)
    mass = np.sum(mixing[:, :, None] * np.maximum(0, hi - lo), axis=1)
    mass[:, upper < floor] = 0
    return mass


def design(numeric, positions, levels):
    return np.column_stack(
        (
            numeric,
            *[(np.asarray(positions) == p).astype(float) for p in POSITIONS],
            np.broadcast_to(levels, len(numeric)),
        )
    )


def fit_forecasts(x, aa, levels, positions, fit, target, classes, probability, setting, epochs=80):
    x, aa, levels, positions = map(np.asarray, (x, aa, levels, positions))
    fit, target = np.asarray(fit, dtype=bool), np.asarray(target, dtype=bool)
    if (
        x.ndim != 2
        or any(v.shape != (len(x),) for v in (aa, levels, positions, fit, target))
        or not fit.any()
        or (fit & target).any()
        or not np.isfinite(aa[fit]).all()
        or not np.isfinite(levels[fit]).all()
        or not np.isin(positions, POSITIONS).all()
        or probability.shape != (int(target.sum()), len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Mixture AA fit/probability contract differs")
    raw = design(x[fit], positions[fit], levels[fit])
    model = MixtureNetwork(**setting, epochs=epochs).fit(raw, aa[fit])
    mass = np.zeros((int(target.sum()), len(CENTRES)))
    for j, level in enumerate(classes):
        params = model.predict(design(x[target], positions[target], level))
        mass += probability[:, j, None] * mixture_mass(*params, level)
    if not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1 + 1e-12).any():
        raise ValueError("Mixture AA forecast mass invalid")
    normaliser = model.normaliser_
    stats = {
        "fitCases": int(fit.sum()),
        "targetCases": int(target.sum()),
        "settings": setting,
        "epochs": epochs,
        "numericFeatures": x.shape[1],
        "designFeatures": raw.shape[1],
        "eventProbabilitiesUnchanged": True,
        "trainingOnlyLoss": model.loss_history_,
        "normaliserSha256": hashlib.sha256(
            normaliser.mean_.tobytes() + normaliser.scale_.tobytes() + normaliser.known_.tobytes()
        ).hexdigest(),
        "weightsSha256": hashlib.sha256(b"".join(w.tobytes() for w in model.weights_)).hexdigest(),
    }
    return mass, stats
