"""Combine count-based ordinary points with an explicit decisive-level choice.

The same historical comparison is retained. This is exploratory, never a claim of
fresh blind validation. All intermediate forecasts used for selection precede it.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats import fit_weights, simulate_counts
from app.research.score_stats_run import fit_rates, paired_interval, previous_branch


def choose_level(probability: np.ndarray, classes: np.ndarray, threshold: float) -> np.ndarray:
    positive = classes >= 60
    if not positive.any() or positive.all():
        return classes[probability.argmax(axis=1)]
    high = classes[positive][probability[:, positive].argmax(axis=1)]
    low = classes[~positive][probability[:, ~positive].argmax(axis=1)]
    return np.where(probability[:, positive].sum(axis=1) >= threshold, high, low)


def conditional_components(x: np.ndarray, aa: np.ndarray, level: np.ndarray, fit: np.ndarray, check: np.ndarray):
    """Predict every level's ordinary points; no actual check-set level is used."""
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

    classifier = HistGradientBoostingClassifier(
        max_leaf_nodes=7,
        min_samples_leaf=80,
        max_iter=120,
        learning_rate=0.06,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    ).fit(x[fit], level[fit].astype(int))
    classes = classifier.classes_
    probability = classifier.predict_proba(x[check])
    parts = {}
    for q in (0.35, 0.5, 0.65):
        model = HistGradientBoostingRegressor(
            loss="quantile",
            quantile=q,
            max_leaf_nodes=15,
            min_samples_leaf=60,
            max_iter=120,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261103,
        ).fit(np.column_stack((x[fit], level[fit])), aa[fit])
        parts[q] = np.column_stack(
            [model.predict(np.column_stack((x[check], np.full(check.sum(), v)))) for v in classes]
        )
    return classes, probability, parts


def selected_stat_predictions(
    features: np.ndarray,
    counts: np.ndarray,
    rows: list[dict[str, Any]],
    names: list[str],
    stats: list[str],
    games: list[dict[str, Any]],
    specification: dict[str, Any],
):
    from sklearn.ensemble import HistGradientBoostingRegressor

    dates = np.array([r["date"][:10] for r in rows])
    minutes = np.array([r["minutes"] for r in rows], dtype=float)
    positions = np.array([r["pos"] for r in rows])
    cohort = rows[0]["cohort"]
    train = dates < "2025-07-01"
    valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
    test = dates >= "2026-01-01"
    days = sorted(set(dates[train]))
    boundary = days[int(len(days) * 0.8)]
    fit = train & (dates < boundary)
    calibration = train & ~fit
    target = counts * 90 / np.maximum(minutes[:, None], 1)
    inner, scale = fit_rates(features, target, minutes, specification["minimumLeaf"], fit)
    residual = (
        counts[calibration]
        - np.maximum(0, inner.predict(features[calibration]) * scale) * minutes[calibration, None] / 90
    )
    prior = np.array([r["x"][names.index(cohort + "_10_minutes")] for r in rows])
    params = dict(
        loss="absolute_error",
        max_leaf_nodes=15,
        min_samples_leaf=60,
        max_iter=120,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )
    if specification["learnedMinutes"]:
        model = HistGradientBoostingRegressor(**params).fit(features[fit], minutes[fit])
        min_residual = minutes[calibration] - np.clip(model.predict(features[calibration]), 0, 100)
    else:
        min_residual = minutes[calibration] - prior[calibration]
    home = features[:, names.index("home")] > 0
    ga = np.where(home, features[:, names.index("match_lam_a")], features[:, names.index("match_lam_h")])
    outputs = []
    for training, check, before in ((train, valid, "2025-07-01"), (~test, test, "2026-01-01")):
        model, scale = fit_rates(features, target, minutes, specification["minimumLeaf"], training)
        rates = np.maximum(0, model.predict(features[check]) * scale)
        if specification["learnedMinutes"]:
            min_model = HistGradientBoostingRegressor(**params).fit(features[training], minutes[training])
            predicted = np.clip(min_model.predict(features[check]), 0, 100)
        else:
            predicted = prior[check]
        weights, _ = fit_weights(games, stats, before)
        _, aa = simulate_counts(
            rates,
            predicted,
            residual,
            min_residual,
            minutes[calibration],
            positions[calibration],
            positions[check],
            weights,
            stats,
            ga[check],
            specification["residualSpread"],
        )
        outputs.append(aa)
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("games", "cases", "stats-cache", "stats-result", "previous", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    data = json.loads(args.cases.read_text(encoding="utf-8"))
    stats_result = json.loads(args.stats_result.read_text(encoding="utf-8"))
    old = json.loads(args.previous.read_text(encoding="utf-8"))
    cached = np.load(args.stats_cache)
    allx = cached["x"]
    allcounts = cached["counts"]
    stats = stats_result["stats"]
    games = [json.loads(s) for s in args.games.read_text(encoding="utf-8").splitlines() if s.strip()]
    report = {
        "target": "LaLiga score within seven, separate starts and bench; choose one decisive level then ordinary points",
        "split": "Earlier-data selection, same January-October 2026 retrospective comparison",
        "evidenceLimit": "Exploratory follow-up; no new blind claim",
        "sourceKey": data["key"],
        "cohorts": {},
    }
    args.out.with_suffix(".plan.json").write_text(
        json.dumps(
            {
                **report,
                "candidates": "Fixed classifier; three conditional-AA quantiles; stat/conditional-AA weights 0, .5, 1; shifts -3,0,3; decisive thresholds .1 to .95",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort for r in data["rows"]])
        rows = [r for r in data["rows"] if r["cohort"] == cohort]
        x = allx[selected]
        counts = allcounts[selected]
        y = np.array([r["score"] for r in rows])
        aa = np.array([r["aa"] for r in rows])
        level = np.array([r["level"] for r in rows])
        dates = np.array([r["date"][:10] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        stat_aa = selected_stat_predictions(
            x, counts, rows, data["features"], stats, games, stats_result["cohorts"][cohort]["winner"]
        )
        print(cohort + " stat estimates reconstructed", flush=True)
        folds = []
        for fit, check in ((train, valid), (~test, test)):
            folds.append(conditional_components(x, aa, level, fit, check))
        candidates = []
        best = None
        classes, probability, parts = folds[0]
        for threshold in np.arange(0.1, 0.951, 0.025):
            lev = choose_level(probability, classes, float(threshold))
            index = np.searchsorted(classes, lev)
            for q in (0.35, 0.5, 0.65):
                conditional = parts[q][np.arange(len(index)), index]
                for weight in (0.0, 0.5, 1.0):
                    ordinary = (1 - weight) * stat_aa[0] + weight * conditional
                    for shift in (-3, 0, 3):
                        prediction = np.clip(lev + ordinary + shift, np.where(lev >= 60, lev, 0), 100)
                        metrics = measure(y[valid], prediction)
                        spec = {
                            "threshold": float(threshold),
                            "quantile": q,
                            "conditionalWeight": weight,
                            "ordinaryShift": shift,
                            "selection": metrics,
                        }
                        candidates.append(spec)
                        if best is None or (metrics["within7"], -metrics["mae"]) > (
                            best["selection"]["within7"],
                            -best["selection"]["mae"],
                        ):
                            best = spec
        assert best is not None
        args.out.with_suffix(f".{cohort}.selection.json").write_text(
            json.dumps({"winner": best, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        classes, probability, parts = folds[1]
        lev = choose_level(probability, classes, best["threshold"])
        index = np.searchsorted(classes, lev)
        ordinary = (
            (1 - best["conditionalWeight"]) * stat_aa[1]
            + best["conditionalWeight"] * parts[best["quantile"]][np.arange(len(index)), index]
            + best["ordinaryShift"]
        )
        prediction = np.clip(lev + ordinary, np.where(lev >= 60, lev, 0), 100)
        baseline = previous_branch(x[:, : len(data["features"])], y, ~test, test, old["cohorts"][cohort])
        weeks = [r["week"] for r, keep in zip(rows, test, strict=True) if keep]
        result = {
            "winner": best,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "previousBranch": measure(y[test], baseline),
            "gain95": paired_interval(y[test], prediction, baseline, weeks),
            "ordinaryPoints": measure(aa[test], ordinary),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {},
        }
        positions = np.array([r["pos"] for r in rows])[test]
        for pos in POSITIONS:
            mask = positions == pos
            if mask.any():
                result["positions"][pos] = measure(y[test][mask], prediction[mask])
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
