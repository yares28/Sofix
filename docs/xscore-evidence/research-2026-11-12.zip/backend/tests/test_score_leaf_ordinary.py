from pathlib import Path

import numpy as np

from app.research.score_leaf_ordinary import FitImputer, fit_distribution, leaf_window_histograms
from app.research.score_modal_trees import CENTRES
from app.research.score_windows import window_centres


def test_leaf_histograms_match_native_bruteforce_including_floors_and_caps():
    aa = np.array([-100.0, -60.0, -7.0, -0.001, 0.0, 7.0, 13.123, 39.999, 100.0])
    leaves = np.array([1, 1, 1, 1, 2, 2, 2, 2, 2])
    for level in (0, 5, 15, 35, 60, 70, 100):
        mass, counts = leaf_window_histograms(aa, leaves, 4, level)
        scores = np.clip(np.maximum(level if level >= 60 else 0, level + aa), 0, 100)
        for node in range(4):
            expected = (np.abs(scores[leaves == node, None] - CENTRES) <= 7).sum(axis=0)
            np.testing.assert_equal(mass[node], expected)
            assert counts[node] == (leaves == node).sum()


def test_imputer_uses_fit_only_preserves_missing_and_cold_columns():
    x = np.array([[2.0, np.nan], [4.0, np.nan], [1e8, 20.0]])
    imputer = FitImputer().fit(x[:2])
    np.testing.assert_equal(imputer.median_, [3, 0])
    transformed = imputer.transform(x)
    np.testing.assert_equal(transformed[:2], [[2, 0, 0, 1], [4, 0, 0, 1]])
    assert transformed.dtype == np.float32


def test_real_forest_ignores_all_outside_fit_labels_and_keeps_cold_position(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    rng = np.random.default_rng(44)
    x = rng.normal(size=(170, 4))
    x[::4, 1] = np.nan
    aa = rng.normal(10, 8, 170)
    levels = rng.choice([35.0, 60.0], 170)
    positions = np.array(["DEF"] * 160 + ["GK"] * 10)
    fit = np.arange(170) < 160
    target = ~fit
    classes = np.array([35.0, 60.0])
    probability = np.tile([0.8, 0.2], (10, 1))
    settings = {"trees": 4, "depth": 4, "leaf": 10, "features": "sqrt"}
    first, stats = fit_distribution(x, aa, levels, positions, fit, target, classes, probability, settings, (20, 100))
    aa[~fit] = np.nan
    levels[~fit] = np.nan
    second, repeated = fit_distribution(
        x, aa, levels, positions, fit, target, classes, probability, settings, (20, 100)
    )
    assert stats == repeated and stats["targetCases"] == 10 and stats["coldTargetPositions"] == ["GK"]
    for prior in first:
        np.testing.assert_allclose(first[prior], second[prior], atol=0, rtol=0)
        assert first[prior].shape == (10, 201) and np.isfinite(first[prior]).all()
        assert ((first[prior] >= 0) & (first[prior] <= 1 + 1e-12)).all()


def test_bimodal_leaf_probabilities_choose_one_real_peak():
    aa = np.array([5.0] * 60 + [45.0] * 40)
    hist, count = leaf_window_histograms(aa, np.zeros(100, dtype=int), 1, 35)
    forecast = window_centres(hist / count[:, None], CENTRES)
    assert abs(forecast[0] - 40) <= 7 and abs(forecast[0] - 80) > 7
