from pathlib import Path

import numpy as np
import pytest

from app.research.score_duel_game_spread import log_mass, past_surprises


def test_mass_normalizes_and_widens_without_changing_mean(monkeypatch):
    monkeypatch.syspath_prepend(str(Path("data/raw/formula-packages").resolve()))
    pytest.importorskip("scipy")
    w = np.arange(11)
    independent = np.exp(log_mass(w, 10, 0.4, None))
    spread = np.exp(log_mass(w, 10, 0.4, 0.20))
    np.testing.assert_allclose([independent.sum(), spread.sum(), independent @ w, spread @ w], [1, 1, 4, 4])
    assert spread[[0, -1]].sum() > independent[[0, -1]].sum()
    np.testing.assert_allclose(np.exp(log_mass(np.array([0, 1]), 1, 0.4, 0.2)), [0.6, 0.4])
    assert np.isneginf(log_mass(np.array([2]), 1, 0.4, 0.2)).all()


def test_surprise_records_release_only_after_strict_boundary():
    rows = [{"game": key, "player": "a", "pos": "DEF"} for key in ("past", "same", "future")]
    sides = [("own", "opponent")] * 3
    counts = np.array([[4, 0], [0, 2], [0, 1]])
    p = np.full(3, 0.5)
    available, locks = np.array([48, 60, 70]), np.array([0, 48, 49])
    result = past_surprises(rows, sides, counts, p, available, locks)
    np.testing.assert_array_equal(result[:2], 0)
    np.testing.assert_allclose(result[2], [2 / 24, 3 / 33, 1] * 2)
    counts[1:] = 999
    np.testing.assert_array_equal(past_surprises(rows, sides, counts, p, available, locks), result)
