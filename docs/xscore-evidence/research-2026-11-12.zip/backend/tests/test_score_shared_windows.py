import sys
from types import SimpleNamespace

import numpy as np

from app.research.score_shared_windows import fit_probability, normalise, window_targets


def test_normalisation_does_not_learn_from_later_features():
    x = np.array([[1, 4], [3, 4], [100, -300]], dtype=np.float32)
    fit = np.array([True, True, False])
    before = normalise(x, fit)
    x[-1] = [1e6, -1e6]
    after = normalise(x, fit)
    np.testing.assert_array_equal(before[:2], after[:2])
    assert np.isfinite(after).all()
    assert abs(after).max() <= 6


def test_overlapping_targets_preserve_two_separated_outcomes():
    centres, target = window_targets(np.array([40, 80]))
    assert target[0, centres == 40] == 1
    assert target[0, centres == 80] == 0
    assert target[1, centres == 80] == 1
    assert target[1, centres == 60] == 0


def test_longer_training_check_honours_its_requested_cap(monkeypatch):
    class Model:
        def __init__(self, **kwargs):
            self.n_iter_ = kwargs["max_iter"]
            self.loss_ = 1.0

        def fit(self, x, target):
            self.width = target.shape[1]

        def predict_proba(self, x):
            return np.zeros((len(x), self.width))

    monkeypatch.setitem(sys.modules, "sklearn.neural_network", SimpleNamespace(MLPClassifier=Model))
    monkeypatch.setitem(
        sys.modules,
        "sklearn.exceptions",
        SimpleNamespace(ConvergenceWarning=type("ConvergenceWarning", (Warning,), {})),
    )
    x = np.array([[1], [2], [3]], dtype=np.float32)
    fit = np.array([True, True, False])
    _, training = fit_probability(x, np.zeros((3, 2)), fit, ~fit, [64], 10, max_epochs=500)
    assert training["iterations"] == 500
