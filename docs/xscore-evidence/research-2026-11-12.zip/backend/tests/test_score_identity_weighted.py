from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_identity_interactions as base
from app.research import score_identity_weighted as weighted


def test_identity_penalty_is_population_average_and_missing_row_is_fixed():
    ids = np.array([[1, 1, 1], [1, 1, 1], [2, 1, 0]])
    w = weighted.importance(ids, [2, 1, 1], prior=20)
    np.testing.assert_allclose(w["E_player"], [0, 22 / 43, 21 / 43], atol=1e-8)
    assert w["E_team"].tolist() == [0, 1] and w["E_opponent"].tolist() == [0, 1]


def test_weighted_penalty_gradient_for_every_embedding_and_matrix():
    rng = np.random.default_rng(18)
    x = rng.normal(size=(4, 2))
    ids = np.array([[1, 1, 2], [2, 1, 1], [1, 2, 1], [0, 0, 0]])
    labels = base.targets(np.array([40.0, 80.0, 50.0, 35.0]))
    weights = {n: v.astype(float) for n, v in base.initial_weights(2, [2, 2, 2], 2, 3, 15).items()}
    penalties = weighted.importance(ids, [2, 2, 2])
    loss, gradient = weighted.loss_gradient(x, ids, labels, weights, 0.001, 0.01, penalties)
    assert np.isfinite(loss)
    for name, array in weights.items():
        for index in np.ndindex(array.shape):
            high = {n: v.copy() for n, v in weights.items()}
            low = {n: v.copy() for n, v in weights.items()}
            high[name][index] += 1e-5
            low[name][index] -= 1e-5
            numeric = (
                weighted.loss_gradient(x, ids, labels, high, 0.001, 0.01, penalties)[0]
                - weighted.loss_gradient(x, ids, labels, low, 0.001, 0.01, penalties)[0]
            ) / 2e-5
            np.testing.assert_allclose(gradient[name][index], numeric, atol=1e-9, rtol=1e-4)


def test_weighted_numeric_ablation_is_exact_original_and_ignores_identity():
    rng = np.random.default_rng(14)
    x = rng.normal(size=(48, 2))
    y = rng.choice([40.0, 80.0], 48)
    cats = np.array([[str(i), "t", "o"] for i in range(48)], dtype=object)
    spec = dict(rank=2, width=4, epochs=3, seed=21, use_identities=False)
    a = base.InteractionNetwork(**spec).fit(x, cats, y)
    b = weighted.InteractionNetwork(**spec).fit(x, cats, y)
    for name in a.weights_:
        np.testing.assert_array_equal(a.weights_[name], b.weights_[name])
    np.testing.assert_array_equal(a.history_, b.history_)
    np.testing.assert_array_equal(a.predict_mass(x, cats), b.predict_mass(x, cats))


def test_actual_weighted_cached_fit_excludes_future_labels_and_keeps_prefix(monkeypatch):
    from app.research import score_identity_interactions_run as runner

    monkeypatch.setattr(runner, "network", weighted)
    rng = np.random.default_rng(19)
    x = rng.normal(size=(80, 3))
    y = rng.choice([40.0, 80.0], 80)
    cats = np.array([[str(i % 4), "t", str(i % 2)] for i in range(80)], dtype=object)
    cats[60:, 0] = "future-only"
    mask = {"fit": np.arange(80) < 60, "target": np.arange(80) >= 60}
    spec = dict(rank=2, width=4, ridge=0.001, embedding_ridge=0.01)
    directory = Path(__file__).parents[1] / "data/raw/interaction-weighted-tests" / uuid4().hex
    directory.mkdir(parents=True)
    a, _ = runner.fitted(x, cats, y, mask, spec, 2, directory / "a.npz", "fixture")
    y[~mask["fit"]] = np.nan
    b, _ = runner.fitted(x, cats, y, mask, spec, 2, directory / "b.npz", "fixture")
    runner.fitted(x, cats, y, mask, spec, 4, directory / "long.npz", "fixture")
    np.testing.assert_array_equal(a, b)
    with (
        np.load(directory / "a.npz") as first,
        np.load(directory / "b.npz") as hidden,
        np.load(directory / "long.npz") as longer,
    ):
        for name in first.files:
            if name.startswith("w_") or name in (
                "statistics",
                "category_maps",
                "normaliser_mean",
                "normaliser_scale",
                "normaliser_known",
            ):
                np.testing.assert_array_equal(first[name], hidden[name])
        np.testing.assert_array_equal(first["history"], longer["history"][:2])
