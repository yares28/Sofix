import numpy as np

from app.research.score_search import cutoff_for, interval_mode, make_cases
from app.research.score_search_distribution import distribution_score


def game(date, score, gid="a"):
    return {
        "id": gid,
        "date": date,
        "home": {"slug": "home"},
        "away": {"slug": "away"},
        "homeGoals": 1,
        "awayGoals": 0,
        "players": {
            "player": {
                "pos": "MID",
                "team": "home",
                "score": score,
                "started": True,
                "played": True,
                "ver": 7,
                "mins": 90,
                "aa": 10,
                "level": 35,
                "stats": {},
            }
        },
    }


def test_interval_mode_optimizes_the_requested_window():
    prediction = interval_mode([40, 41, 42, 90])
    assert sum(abs(prediction - value) <= 7 for value in [40, 41, 42, 90]) == 3
    assert abs(prediction - 90) > 7


def test_cutoff_is_before_game_and_preserves_lock_boundary():
    assert cutoff_for("2026-10-12T20:00:00Z").isoformat() == "2026-10-09T14:00:00+00:00"
    assert cutoff_for("2026-10-09T14:00:00Z").isoformat() == "2026-10-09T14:00:00+00:00"


def test_future_target_and_same_week_never_enter_features():
    past = game("2026-09-20T16:00:00Z", 40, "past")
    same_week = game("2026-10-10T16:00:00Z", 99, "same")
    target = game("2026-10-12T20:00:00Z", 10, "target")
    before = make_cases([past, same_week, target])[-1]
    changed = make_cases([past, game(same_week["date"], 0, "same"), game(target["date"], 100, "target")])[-1]
    assert before["x"] == changed["x"]
    assert before["score"] != changed["score"]


def test_zero_is_a_target_and_unknown_is_excluded():
    assert len(make_cases([game("2026-10-12T20:00:00Z", 0)])) == 1
    assert make_cases([game("2026-10-12T20:00:00Z", None)]) == []


def test_missing_version_is_not_assumed_authentic():
    row = game("2026-10-12T20:00:00Z", 45)
    row["players"]["player"].pop("ver")
    assert make_cases([row]) == []


def test_distribution_preserves_zero_and_separates_mean_from_window():
    probability = np.array([[1.0, 0.0], [0.8, 0.2]])
    classes = np.array([0, 20])
    mean = distribution_score(probability, classes, blend=1)
    mode = distribution_score(probability, classes)
    assert mean.tolist() == [0, 20]
    assert (mode <= 7).all()
