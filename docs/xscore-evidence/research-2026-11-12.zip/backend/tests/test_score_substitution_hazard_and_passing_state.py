from datetime import UTC, datetime

import numpy as np

from app.research.score_passing_state import minutes_by_state
from app.research.score_passing_state_signal import mix, probabilities
from app.research.score_passing_style_signal import Rates, forecast
from app.research.score_passing_style_state import pass_categories
from app.research.score_substitution_hazard import decision_distributions, summaries
from app.research.score_team_market_clock import provisional_collection, valid_quotes


def test_hazard_conserves_mass_and_missing_rates_keep_control():
    baseline = np.full((3, 90), 0.02)
    delta = np.full((3, 4, 3), 0.3)
    delta[0] = 0
    pooled, conditioned = decision_distributions(baseline, delta, np.array([1.5, 1.5, -1]), np.array([1, 1, -1]))
    np.testing.assert_allclose(conditioned[0], pooled[0], rtol=0, atol=1e-12)
    np.testing.assert_array_equal(conditioned[2], pooled[2])
    assert summaries(conditioned, "start")[1, 0] < summaries(pooled, "start")[1, 0]
    assert summaries(conditioned, "bench")[1, 0] > summaries(pooled, "bench")[1, 0]


def test_passing_state_omits_goal_and_substitution_boundary_minutes():
    assert minutes_by_state([(62, -1), (64, 1)], 60, 66) == {61: 1, 63: 0, 65: 1}


def test_state_probabilities_and_cold_passing_history():
    np.testing.assert_allclose(probabilities(2, 1), probabilities(1, 2)[:, ::-1])
    np.testing.assert_allclose(probabilities(2, 1).sum(axis=1), 1)
    assert probabilities(-1, 2) is None
    assert mix([], datetime(2025, 5, 1, tzinfo=UTC), np.ones(3), 0.25) == (0.25, 0.0, 0)


def test_pass_types_keep_overlap_and_missing_state_distinct():
    events = [
        {"min": 8, "x": 20, "ex": 35, "key": True, "ok": True},
        {"min": 9, "x": 22, "ex": 5, "key": False, "ok": True},
        {"min": 9, "x": 30, "ex": 49, "key": False, "ok": False},
        {"min": 10, "x": None, "ex": None, "key": True, "ok": False},
    ]
    assert pass_categories(events, {8: 0, 9: 2})["passTypes"] == [[1, 0, 0], [0, 0, 1], [1, 0, 0], [0, 0, 1]]
    assert pass_categories(events, {10: 0})["passTypes"] is None


def test_state_style_keeps_cold_prior_and_does_not_fit_target_outcomes():
    lock = datetime(2025, 5, 1, tzinfo=UTC)
    _, _, shift = Rates().features(lock, np.ones(3) * 30, 90, np.ones(4))
    np.testing.assert_array_equal(shift, np.zeros(4))
    x = np.arange(6, dtype=float).reshape(-1, 1)
    train = np.array([1, 1, 1, 1, 0, 0], dtype=bool)
    y = np.array([-14, -14, 14, 14, 4, 6], dtype=float)
    first = forecast(x, y, train, ~train)
    y[~train] = np.nan
    np.testing.assert_array_equal(first, forecast(x, y, train, ~train))


def test_only_midweek_market_policy_has_an_earlier_provisional_clock():
    assert provisional_collection("2025-01-22T19:00:00Z") == datetime(2025, 1, 21, 13, tzinfo=UTC)
    assert provisional_collection("2025-09-24T19:00:00Z") == datetime(2025, 9, 23, 12, tzinfo=UTC)
    assert provisional_collection("2025-09-27T19:00:00Z") is None
    assert not valid_quotes({"AvgCH": "1.80", "AvgCD": "4.20", "AvgCA": "5"})
