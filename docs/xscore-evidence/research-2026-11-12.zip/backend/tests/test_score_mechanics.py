import numpy as np
import pytest

from app.research.score_mechanics import (
    MINUTE_GRID,
    apply_mechanics,
    conceded_samples,
    paired_bank,
    paired_draws,
    sampled_base_locations,
    stripped_targets,
)


def test_strip_and_rebuild_keeps_clean_sheet_and_goals_conceded_rules_exact():
    positions = np.array(["GK", "DEF", "MID", "FWD"])
    aa = np.array([12.0, 20, 8, 5])
    net = np.array([1, 0, 0, 1])
    conceded = np.array([0, 0, 2, 3])
    clean = np.array([1, 1, 0, 0])
    base_aa, base_net = stripped_targets(aa, net, conceded, clean, positions)
    np.testing.assert_array_equal(base_aa, [12, 10, 12, 5])
    np.testing.assert_array_equal(base_net, [0, 0, 0, 1])
    score, rebuilt_aa, rebuilt_net = apply_mechanics(base_aa, base_net, np.full(4, 90), conceded, positions)
    np.testing.assert_array_equal(rebuilt_aa, aa)
    np.testing.assert_array_equal(rebuilt_net, net)
    np.testing.assert_array_equal(score, [72, 55, 43, 65])


def test_clean_sheet_requires_sixty_minutes_and_positive_decisive_floor_applies():
    positions = np.array(["GK", "GK", "DEF", "DEF", "FWD"])
    score, aa, net = apply_mechanics(
        np.array([-20.0, -20, 0, 0, -50]),
        np.array([0, 0, 0, 0, 1]),
        np.array([59.0, 60, 59, 60, 90]),
        np.zeros(5),
        positions,
    )
    np.testing.assert_array_equal(aa, [-20, -20, 0, 10, -50])
    np.testing.assert_array_equal(net, [0, 1, 0, 0, 1])
    np.testing.assert_array_equal(score, [15, 60, 35, 45, 60])


def test_calibrated_zero_mass_and_exposure_are_explicit_not_observed_goals():
    u = np.linspace(0.0001, 0.9999, 10000)[None, :]
    full = conceded_samples(np.array([2.0]), np.array([0.4]), np.full((1, 10000), 90.0), u, "calibratedCS")
    short = conceded_samples(np.array([2.0]), np.array([0.4]), np.full((1, 10000), 45.0), u, "calibratedCS")
    assert abs((full == 0).mean() - 0.4) < 0.001
    assert abs((short == 0).mean() - np.sqrt(0.4)) < 0.001
    assert short.mean() < full.mean()
    with pytest.raises(ValueError, match="known"):
        stripped_targets(np.array([np.nan]), np.array([0]), np.array([0]), np.array([0]), np.array(["DEF"]))


def test_paired_errors_preserve_the_same_historical_minutes_and_point_error_row():
    pairs = np.array([[1.0, 10], [2, 20]])
    bank = {"global": pairs, "positions": {"DEF": pairs}, "levels": {("DEF", 0.0): pairs}}
    pieces = {"classes": np.array([0.0]), "probability": np.ones((2, 1))}
    indices, minute_error, point_error, _ = paired_draws(pieces, np.array(["DEF", "DEF"]), bank)
    np.testing.assert_array_equal(indices, 0)
    np.testing.assert_array_equal(point_error, minute_error * 10)


def test_calibration_excludes_results_not_available_before_next_lock():
    rows = [{"pos": "DEF", "minutes": 90, "date": date} for date in ("2025-10-20T20:00:00Z", "2025-10-31T20:00:00Z")]
    pieces = {"minutes": np.array([80.0, 80]), "factual_location": np.array([2.0, 2])}
    bank = paired_bank(rows, np.array([3.0, 999]), np.array([0.0, 0]), pieces, "2025-11-01T18:00:00Z")
    assert bank["cases"] == bank["unavailable"] == 1
    np.testing.assert_array_equal(bank["global"], [[10, 1]])


def test_forecast_location_interpolates_the_declared_exposure_grid():
    pieces = {"minutes": np.array([50.0]), "locations": MINUTE_GRID[None, :, None].copy()}
    minutes, location = sampled_base_locations(pieces, np.zeros((1, 3), dtype=int), np.array([[-49.0, 0, 50]]), 1)
    np.testing.assert_array_equal(minutes, [[1, 50, 100]])
    np.testing.assert_array_equal(location, [[5, 50, 95]])


def test_future_observed_minutes_or_net_cannot_enter_normal_mechanics_forecasts(monkeypatch, tmp_path):
    import sys
    from types import SimpleNamespace

    import pandas as pd

    from app.research import score_ordinary as ordinary
    from app.research.score_mechanics import fitted_pieces

    class Pool:
        def __init__(self, data, label=None, cat_features=None):
            self.data, self.label = data, label

    class Model:
        def __init__(self, minute=False, **kwargs):
            self.minute = minute

        def fit(self, pool):
            assert len(pool.data) == 3
            assert np.max(pool.label) < 100
            self.classes_ = np.array([0.0, 1])

        def predict(self, pool):
            x = pool.data
            return (
                np.full(len(x), 80.0) if self.minute else x["exposure"].to_numpy() / 10 + x["candidate_net"].to_numpy()
            )

        def predict_proba(self, pool):
            return np.tile([0.8, 0.2], (len(pool.data), 1))

    monkeypatch.setitem(sys.modules, "catboost", SimpleNamespace(Pool=Pool, CatBoostClassifier=Model))
    monkeypatch.setattr(ordinary, "regressor", lambda loss, minutes=False: Model(minute=minutes))
    frame = pd.DataFrame({"n0": np.arange(5.0), "person": ["p"] * 5})
    mask = {"fit": np.array([True, True, True, False, False]), "target": np.array([False, False, False, True, True])}
    aa, net, minutes = np.array([1.0, 2, 3, 4, 5]), np.array([0.0, 1, 0, 0, 1]), np.full(5, 80.0)
    first = fitted_pieces(frame, ["person"], aa, net, minutes, mask, tmp_path / "a.npz", "a")
    aa[3:], net[3:], minutes[3:] = 900, 900, 900
    second = fitted_pieces(frame, ["person"], aa, net, minutes, mask, tmp_path / "b.npz", "b")
    for name in ("locations", "probability", "minutes", "classes"):
        np.testing.assert_array_equal(first[name], second[name])
    assert not np.array_equal(first["factual_location"], second["factual_location"])
