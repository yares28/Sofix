import copy

import numpy as np

from app.research import score_pass_geometry_corrected as fixed
from app.research import score_player_context as legacy


def passes():
    return [
        dict(x=10.0, y=20.0, ex=30.0, ey=30.0, ok=True, key=False, cross=False, through=False),
        dict(x=80.0, y=50.0, ex=90.0, ey=50.0, ok=True, key=False, cross=False, through=False),
        dict(x=50.0, y=80.0, ex=55.0, ey=90.0, ok=True, key=False, cross=False, through=False),
    ]


def test_distinct_passes_are_measured_eagerly_instead_of_repeating_last_pass():
    result = fixed.player_metrics([], passes(), "DR", 90)
    assert result["usage_progressive90"] == result["usage_box_passes90"] == 1
    np.testing.assert_allclose(result["usage_pass_x"], 140 / 3)
    np.testing.assert_allclose(result["usage_pass_x_sd"], np.std([10.0, 80.0, 50.0]))
    assert result["usage_pass_edge"] == 40
    assert result["usage_attacking_fraction"] == result["usage_central_fraction"] == 1 / 3
    old = legacy.player_metrics([], passes(), "DR", 90)
    assert old["usage_pass_x_sd"] == 0 and old["usage_progressive90"] == 0
    for key in set(legacy.FIELDS) - set(fixed.GEOMETRY_FIELDS):
        np.testing.assert_equal(result[key], old[key])


def test_partial_unknown_geometry_is_not_complete_zero_and_empty_passes_are_known_zero():
    invalid = passes()
    invalid[0]["x"] = None
    result = fixed.player_metrics([], invalid, "DR", 90)
    assert np.isnan(result["usage_progressive90"]) and np.isnan(result["usage_box_passes90"])
    assert result["usage_pass_x"] == 65
    empty = fixed.player_metrics([], [], "DR", 90)
    assert empty["usage_progressive90"] == empty["usage_box_passes90"] == 0
    assert np.isnan(empty["usage_pass_x"])


def test_recent_geometry_features_exclude_equal48h_and_future_values():
    base = dict(
        game="old", player="p", club="t", cohort="start", minutes=90, values={name: None for name in legacy.FIELDS}
    )
    old = {**copy.deepcopy(base), "date": "2023-12-01T14:00:00Z"}
    old["values"]["usage_pass_x"] = 20.0
    edge = {**copy.deepcopy(base), "game": "edge", "date": "2023-12-31T14:00:00Z"}
    edge["values"]["usage_pass_x"] = 999.0
    rows = [dict(game="current", player="p", date="2024-01-02T20:00:00Z", cohort="start")]
    targets = {"current": {"players": {"p": {"team": "t"}}}}
    a, names, _ = fixed.recent_features(rows, [old, edge], targets)
    assert a[0, names.index("same_3_usage_pass_x_mean")] == 20
    edge["values"]["usage_pass_x"] = -999.0
    b, _, _ = fixed.recent_features(rows, [old, edge], targets)
    np.testing.assert_array_equal(a, b)
