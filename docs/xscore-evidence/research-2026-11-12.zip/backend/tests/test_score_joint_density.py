import numpy as np

from app.research.score_joint_density import density_predictions, interval_mass


def test_low_and_high_peaks_choose_one_range_instead_of_the_gap():
    classes = np.array([35, 80])
    probability = np.array([[0.6, 0.4], [0.4, 0.6]])
    parts = {0.35: np.full((2, 2), -1.0), 0.5: np.zeros((2, 2)), 0.65: np.full((2, 2), 1.0)}
    prediction = density_predictions(classes, probability, parts, "normal", 1, 0)
    assert abs(prediction[0] - 35) <= 7
    assert abs(prediction[1] - 80) <= 7
    assert not ((prediction > 45) & (prediction < 70)).any()


def test_narrower_high_branch_can_win_despite_lower_event_probability():
    classes = np.array([35, 80])
    probability = np.array([[0.55, 0.45]])
    parts = {0.35: np.array([[-15, -1]]), 0.5: np.zeros((1, 2)), 0.65: np.array([[15, 1]])}
    prediction = density_predictions(classes, probability, parts, "normal", 1, 0)
    assert abs(prediction[0] - 80) <= 7


def test_floors_and_100_clipping_keep_probability_mass_instead_of_losing_it():
    mass = interval_mass(np.array([60, 100]), np.array([[60, 100]]), np.array([[-50, 20]]), np.ones((1, 2)), "normal")
    np.testing.assert_allclose(mass[0, [0, 1], [0, 1]], [1, 1], atol=1e-8)
    np.testing.assert_allclose(mass[0, [0, 1], [1, 0]], [0, 0], atol=1e-8)


def test_quantile_crossing_and_collapsed_spreads_still_give_finite_predictions():
    classes = np.array([35])
    parts = {0.35: np.array([[3], [0]]), 0.5: np.array([[0], [0]]), 0.65: np.array([[-3], [0]])}
    for family in ("normal", "logistic", "laplace"):
        p = density_predictions(classes, np.ones((2, 1)), parts, family, 1, 0)
        assert np.isfinite(p).all()
        assert ((p >= 0) & (p <= 100)).all()


def test_invalid_probability_rows_are_rejected():
    import pytest

    parts = {q: np.zeros((1, 1)) for q in (0.35, 0.5, 0.65)}
    with pytest.raises(ValueError, match="probability"):
        density_predictions(np.array([35]), np.array([[0.2]]), parts, "normal", 1, 0)
