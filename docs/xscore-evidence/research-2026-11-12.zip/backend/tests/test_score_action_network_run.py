import numpy as np
import pytest

from app.research.score_action_network_run import fitted


def test_fitter_excludes_unavailable_score_labels_and_input_normalisation(tmp_path):
    x = np.array([[0.0], [1], [2], [3], [4]])
    y = np.array([40.0, 40, 80, 20, 90])
    mask = {"fit": np.array([True, True, True, False, False]), "target": np.array([False, False, False, True, True])}
    spec = {"width": 32, "ridge": 0.01, "aux": 0.1}
    a = tmp_path / "a.npz"
    prediction, _ = fitted(x, y, mask, spec, 2, a, "test-only")
    changed_y = y.copy()
    changed_y[~mask["fit"]] = np.nan
    b = tmp_path / "b.npz"
    repeated, _ = fitted(x, changed_y, mask, spec, 2, b, "test-only")
    np.testing.assert_equal(prediction, repeated)
    changed_x = x.copy()
    changed_x[~mask["fit"]] = 999999
    c = tmp_path / "c.npz"
    fitted(changed_x, changed_y, mask, spec, 2, c, "test-only")
    with np.load(a) as f, np.load(c) as other:
        for name in ("normaliser_mean", "normaliser_scale", "normaliser_known", "w0", "w1", "w2", "w3"):
            np.testing.assert_equal(f[name], other[name])


def test_fitter_refuses_wrong_cache_provenance(tmp_path):
    path = tmp_path / "wrong.npz"
    np.savez_compressed(path, key="wrong", prediction=np.array([40]))
    with pytest.raises(ValueError, match="identity"):
        fitted(
            np.array([[0], [1]]),
            np.array([40, 80]),
            {"fit": np.array([True, False]), "target": np.array([False, True])},
            {"width": 32, "ridge": 0.01, "aux": 0},
            2,
            path,
            "expected",
        )
