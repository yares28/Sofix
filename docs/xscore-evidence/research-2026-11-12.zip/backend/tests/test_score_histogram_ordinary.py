from pathlib import Path

import numpy as np
import pytest

from app.research.score_histogram_ordinary import aa_bands, conditional_band_mass, fit_forecasts
from app.research.score_modal_trees import CENTRES


def test_fixed_bands_keep_extreme_tails_and_known_zero():
    values = np.array([-1000.0, -30.0, -25.0, -0.001, 0.0, 5.0, 60.0, 1000.0])
    labels, edges = aa_bands(values, 5)
    np.testing.assert_equal(labels, np.searchsorted(edges, values, side="right"))
    assert labels[0] == 0 and labels[-1] == len(edges) and labels[4] != labels[3]
    with pytest.raises(ValueError, match="finite"):
        aa_bands(np.array([np.nan]), 5)


def test_conditional_band_mass_matches_native_atoms_and_cold_pool_fallback():
    aa = np.array([-30.0, -7.0, 0.0, 2.0, 7.0, 20.0, 50.0, 100.0])
    levels = np.full(8, 35.0)
    positions = np.array(["DEF"] * 8)
    labels, _ = aa_bands(aa, 10)
    for level in (0.0, 35.0, 60.0, 100.0):
        for band in np.unique(labels):
            found = conditional_band_mass(aa, levels, positions, labels, "GK", level, band)
            scores = np.clip(np.maximum(level if level >= 60 else 0, level + aa[labels == band]), 0, 100)
            brute = (np.abs(scores[:, None] - CENTRES) <= 7).mean(axis=0)
            np.testing.assert_equal(found, brute)


def test_actual_hgb_fit_ignores_target_aa_ds_and_keeps_cold_positions(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    rng = np.random.default_rng(88)
    x = rng.normal(size=(180, 3))
    x[::7, 1] = np.nan
    aa = rng.normal(8, 9, 180)
    levels = rng.choice([35.0, 60.0], 180)
    positions = np.array(["DEF"] * 160 + ["GK"] * 20)
    fit = np.arange(180) < 160
    target = ~fit
    classes = np.array([35.0, 60.0])
    p = np.tile([0.8, 0.2], (20, 1))
    setting = {"width": 5, "leaves": 7, "minimum": 20}
    first, stats = fit_forecasts(x, aa, levels, positions, fit, target, classes, p, setting, iterations=3)
    aa[target] = np.nan
    levels[target] = np.nan
    repeated, newstats = fit_forecasts(x, aa, levels, positions, fit, target, classes, p, setting, iterations=3)
    np.testing.assert_equal(first, repeated)
    assert stats == newstats and first.shape == (20, 201) and np.isfinite(first).all()


def test_constant_aa_band_bypasses_classifier_without_dropping_cases(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    x = np.zeros((30, 2))
    aa = np.full(30, 2.0)
    levels = np.full(30, 35.0)
    positions = np.array(["DEF"] * 30)
    fit = np.arange(30) < 20
    target = ~fit
    classes = np.array([35.0, 60.0])
    p = np.tile([0.8, 0.2], (10, 1))
    result, stats = fit_forecasts(
        x, aa, levels, positions, fit, target, classes, p, {"width": 10, "leaves": 7, "minimum": 20}, iterations=3
    )
    assert stats["constantBand"] and stats["targetCases"] == 10 and np.isfinite(result).all()
    with pytest.raises(ValueError, match="fit"):
        aa[0] = np.nan
        fit_forecasts(
            x, aa, levels, positions, fit, target, classes, p, {"width": 10, "leaves": 7, "minimum": 20}, iterations=3
        )
