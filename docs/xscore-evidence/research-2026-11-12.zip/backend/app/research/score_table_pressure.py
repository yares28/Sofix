"""Earlier-only test of lagged LaLiga table context and rank proximity."""

import hashlib
import json
from collections import defaultdict

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES, season_of
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_table_pressure"
PLACES = (1, 4, 6, 18)


def update(table, home, away, h, a):
    if type(h) is not int or type(a) is not int or min(h, a) < 0:
        raise ValueError("Known historical league result required")
    for own, scored, conceded in ((home, h, a), (away, a, h)):
        current = table[own]
        current += np.array([1, 3 if scored > conceded else int(scored == conceded), scored, conceded])


def table_features(table, club):
    played, points, goals_for, goals_against = table[club]
    points_list = sorted((v[1] for v in table.values()), reverse=True)
    rank = 1 + sum(p > points for p in points_list)
    known = max(played, 1)
    strength = np.array([played, points / known, (goals_for - goals_against) / known, rank])
    remaining = 38 - played
    late = (played / 38) ** 2
    gaps = np.array([points - points_list[p - 1] for p in PLACES])
    pressure = np.r_[late * np.exp(-abs(gaps) / (1 + remaining / 3)), late * gaps / (1 + remaining)]
    return strength, pressure


def features(rows, games):
    fixtures = {g["id"]: g for g in games}
    clubs = defaultdict(set)
    for game in games:
        clubs[season_of(game["date"])].update(game[s]["slug"] for s in ("home", "away"))
    assert all(len(participants) == 20 for participants in clubs.values())
    tables = {season: {club: np.zeros(4) for club in participants} for season, participants in clubs.items()}
    states = sorted([(moment(g["date"]) + DELAY, g) for g in games], key=lambda item: (item[0], item[1]["id"]))
    locks = [cutoff_for(r["date"]) for r in rows]
    strength, pressure = np.empty((len(rows), 8)), np.empty((len(rows), 16))
    grouped = {}
    cursor = 0
    for i in sorted(range(len(rows)), key=locks.__getitem__):
        row, lock = rows[i], locks[i]
        while cursor < len(states) and states[cursor][0] < lock:
            _, g = states[cursor]
            home, away = (g[side]["slug"] for side in ("home", "away"))
            update(tables[season_of(g["date"])], home, away, g["homeGoals"], g["awayGoals"])
            cursor += 1
        g = fixtures[row["game"]]
        home, away = (g[s]["slug"] for s in ("home", "away"))
        club = g["players"][row["player"]]["team"]
        assert row["date"] == g["date"] and club in (home, away)
        key = g["id"], club
        if key not in grouped:
            table = tables[season_of(row["date"])]
            other = away if club == home else home
            own_s, own_p = table_features(table, club)
            other_s, other_p = table_features(table, other)
            grouped[key] = np.r_[own_s, other_s], np.r_[own_p, other_p]
        strength[i], pressure[i] = grouped[key]
    return strength, pressure


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    original = np.array([r["x"] for r in rows])
    strength, pressure = features(rows, games)
    models = {
        "control": original,
        "strength": np.column_stack((original, strength)),
        "strengthAndPressure": np.column_stack((original, strength, pressure)),
    }
    actual = np.array([r["score"] for r in rows])
    dates = np.array([r["date"] for r in rows])
    ready = np.array([moment(d) + DELAY for d in dates])
    locks = np.array([cutoff_for(d) for d in dates])
    roles = np.array([r["cohort"] for r in rows])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        window = (dates >= begin) & (dates < end)
        earlier = ready < locks[window].min()
        periods[phase] = {}
        for cohort in ("start", "bench"):
            train, test = earlier & (roles == cohort), window & (roles == cohort)
            anchor = original[:, source["features"].index(f"{cohort}_10_score")]
            pred = {
                key: np.clip(anchor[test] + forecast(x, actual - anchor, train, test), 0, 100)
                for key, x in models.items()
            }
            periods[phase][cohort] = {
                name: metrics(actual[test], pred["control"], pred[name]) for name in ("strength", "strengthAndPressure")
            }
            periods[phase][cohort]["lateSeasonCases"] = int(np.count_nonzero(strength[test, 0] >= 28))
    result = {}
    for cohort in ("start", "bench"):
        result[cohort] = {}
        for name in ("strength", "strengthAndPressure"):
            values = [r[cohort][name] for r in periods.values()]
            n = sum(v["n"] for v in values)
            changes = [v["gained"] - v["lost"] for v in values]
            error = sum(v["n"] * (v["mae"][0] - v["mae"][1]) for v in values) / n
            result[cohort][name] = dict(
                n=n,
                phaseHitGains=changes,
                hitGain=sum(changes),
                maeGain=error,
                passEarlier=sum(changes) > 0 and min(changes) >= 0 and error > 0,
            )
    report = dict(nativeSHA=NATIVE_SHA, sourceKey=source["key"], periods=periods, gate=result, laterEvaluated=False)
    (REPORTS / (STEM + ".json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
