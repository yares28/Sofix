import pytest

from app.research import score_referee_index as source


def card(path, title, date):
    return f'<article><a href="{path}" class="d-block fw-bolder text-lg">{title}</a><div class="font-rfef text-main text-md">{date}</div></article>'


def test_official_archive_dates_and_titles_are_linked_within_each_card():
    rows = source.cards(
        card(
            "/es/noticias/designaciones-a",
            "OFICIAL | Estos son los árbitros de la jornada 20 en Primera División masculina",
            "11 Enero 2024",
        )
    )
    assert rows == [
        dict(
            path="/es/noticias/designaciones-a",
            title="OFICIAL | Estos son los árbitros de la jornada 20 en Primera División masculina",
            date="2024-01-11",
            appointment=True,
        )
    ]


def test_other_referee_news_is_retained_as_nonappointment_and_wrong_competition_rejected():
    assert source.cards(card("/es/noticias/curso", "Curso para árbitros", "01 Junio 2024"))[0]["appointment"] is False
    assert (
        source.cards(
            card("/es/noticias/designaciones-x", "Estos son los árbitros en Primera Federación", "01 Junio 2024")
        )[0]["appointment"]
        is False
    )


def test_older_official_node_urls_are_not_dropped_from_the_inventory():
    row = source.cards(
        card(
            "/es/node/81651",
            "DESIGNACIONES | Estos son los árbitros de la jornada 21 de Primera División",
            "18 Enero 2024",
        )
    )[0]
    assert row["path"] == "/es/node/81651"
    assert row["appointment"] is True


def test_unknown_card_dates_and_conflicting_titles_are_not_silently_dropped():
    with pytest.raises(ValueError, match="date"):
        source.cards(card("/es/noticias/x", "Árbitros en Primera División", "Mañana"))
    malformed = card("/es/noticias/x", "A", "01 Enero 2024").replace(
        "</article>", '<a href="/es/noticias/y" class="d-block fw-bolder">B</a></article>'
    )
    with pytest.raises(ValueError, match="title"):
        source.cards(malformed)
