import numpy as np

from app.research.score_openplay_aerial_exposure import OTHER, rolling_forecasts


def test_roster_and_aerial_opponent_probabilities_use_only_released_matches():
    sides = {"home": {"slug": "home"}, "away": {"slug": "away"}}
    available_players = {
        "p": {"team": "home", "played": True, "pos": "DEF", "mins": 90},
        "r": {"team": "away", "played": True, "pos": "FWD", "mins": 90},
        "s": {"team": "away", "played": True, "pos": "FWD", "mins": 90},
    }
    unavailable_players = available_players | {
        "unavailable": {"team": "away", "played": True, "pos": "FWD", "mins": 90}
    }
    games = {
        "past": sides | {"date": "2024-05-07T14:00:00Z", "players": available_players},
        "exact": sides | {"date": "2024-05-08T14:00:00Z", "players": unavailable_players},
        "target": sides | {"date": "2024-05-12T19:00:00Z", "players": unavailable_players},
    }
    rows = [{"game": "target", "date": games["target"]["date"], "player": "p", "pos": "DEF"}]
    aerial = (0, 10.0, ("home", "away"), ("p", "r"))
    other = (1, 10.0, ("home", "away"), ("p", "s"))
    past = {"past": [aerial, aerial, other]}
    ids, p, win, attempts = rolling_forecasts(rows, games, past | {"exact": [aerial] * 500})[0]
    _, old_p, old_win, old_attempts = rolling_forecasts(rows, games, past)[0]
    assert ids == ["r", "s", OTHER]
    np.testing.assert_array_equal(p, old_p)
    np.testing.assert_array_equal(win, old_win)
    assert attempts == old_attempts
    np.testing.assert_allclose(p.sum(axis=0), 1)
    np.testing.assert_array_equal(p[-1], [0.1, 0.1, 0.1])
    assert p[0, 0] == p[1, 0] and p[0, 2] > p[1, 2]
