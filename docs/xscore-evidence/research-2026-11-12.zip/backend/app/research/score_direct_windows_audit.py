"""Testing only: audit the original direct-window studies without changing their frozen logic."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_direct_window_resume as resume
from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_identity import category_values
from app.research.score_search import measure
from app.research.score_team_shape_conditioning_run import validate_stat_identity


def valid_probability(probability, control):
    p = np.asarray(probability, dtype=float)
    c = np.asarray(control, dtype=float)
    if p.shape != (len(c), 101) or not np.isfinite(p).all() or (p < 0).any() or (p > 1).any():
        raise ValueError("Complete native0to1 window probabilities required")
    if not np.isfinite(c).all() or ((c < 0) | (c > 100)).any():
        raise ValueError("Complete native reference scores required")
    return p, c


def independent_choice(probability, control):
    p, c = valid_probability(probability, control)
    return np.array(
        [
            min(np.flatnonzero(row == row.max()), key=lambda v: (abs(float(v) - reference), v))
            for row, reference in zip(p, c, strict=True)
        ],
        dtype=float,
    )


def independent_gate(probability, control, positions, threshold, scope):
    p, c = valid_probability(probability, control)
    if scope not in ("all", "defmid") or len(positions) != len(c) or threshold < 0:
        raise ValueError("Registered all-case window gate required")
    choice = independent_choice(p, c)
    result = c.copy()
    for i, reference in enumerate(c):
        lo = int(np.floor(reference))
        hi = int(np.ceil(reference))
        fraction = reference - lo
        baseline = p[i, lo] * (1 - fraction) + p[i, hi] * fraction
        if p[i].max() - baseline > threshold and (scope == "all" or positions[i] in ("DEF", "MID")):
            result[i] = choice[i]
    return result


def verify_execution(path, key, mask, runner, execution_root, safe):
    with np.load(path) as f:
        if "execution_adapter_sha256" not in f.files:
            return "original_parent_no_snapshot_receipt"
        adapter = str(f["execution_adapter_sha256"])
    expected_adapter = hashlib.sha256(Path(resume.__file__).read_bytes()).hexdigest()
    folder = execution_root.resolve() / key[:12] / hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:12]
    receipt = json.loads((folder / "execution.json").read_text())
    mask_key = hashlib.sha256(np.packbits(mask["fit"]).tobytes() + np.packbits(mask["target"]).tobytes()).hexdigest()
    setting = next(n for n in runner.MODELS if path.stem.endswith("_" + n))
    if (
        adapter != expected_adapter
        or receipt["adapterSha256"] != expected_adapter
        or receipt["parentKey"] != key
        or receipt["parentSourceSha256"] != hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest()
        or receipt["learningParameters"] != resume.learning_parameters(runner, setting, safe)
        or receipt["fitMaskKey"] != mask_key
        or receipt["fitRows"] != int(mask["fit"].sum())
        or receipt["forecastRows"] != int(mask["target"].sum())
        or not receipt["completed"]
        or Path(receipt["completedProbabilityCache"]).resolve() != path.resolve()
        or receipt["savedProbabilitySha256"] != hashlib.sha256(path.read_bytes()).hexdigest()
    ):
        raise ValueError("Native direct-window snapshot execution provenance differs")
    return "snapshot_execution_verified"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "cache", "packages", "report", "execution-root"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--runner", choices=("start", "bench"), required=True)
    parser.add_argument("--refit-if-better", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import catboost
    import pandas as pd
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    if args.runner == "start":
        from app.research import score_direct_windows as runner
    else:
        from app.research import score_direct_windows_bench_safe as runner
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda n: json.loads((args.report.parent / (n + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (report, old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Direct-window native source-case identity differs")
    with np.load(args.cache / "stats.npz") as f:
        base, names, stat_key = f["x"], f["names"].tolist(), str(f["key"])
    validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        match, match_names = f["x"], f["names"].tolist()
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Direct-window match source identity differs")
    with np.load(args.cache / "player_context_features.npz") as f:
        player, player_names = f["x"], f["names"].tolist()
        if str(f["key"]) != old_player["featureKey"]:
            raise ValueError("Direct-window player source identity differs")
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    identities = category_values(source["rows"], games)
    files = [
        Path(runner.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.report.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + catboost.__version__
        ).encode()
        + raw
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Direct-window original implementation/data/plan fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        if cohort != args.runner:
            raise ValueError("Wrong native direct-window parent for requested cohort")
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or winner != frozen["winner"]
            or best != frozen["best"]
            or result["candidate"] != best
            or result["winner"] != winner
            or len(frozen["candidates"]) != 48
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Direct-window three-period frozen choice/gate differs")
        reconstructed = 0
        provenance = {}
        bundle_count = 0
        for phase, _, _ in stability.PHASES[1:]:
            mask = masks[phase]
            target = mask["target"]
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected or result["earlierPeriods"][phase]["control"] != expected:
                raise ValueError("Direct-window original full native control changed")
            active = [best] if phase == "later2026" else frozen["candidates"]
            for setting in sorted({r["spec"]["model"] for r in active}):
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{setting}.npz"
                with np.load(path) as f:
                    if str(f["key"]) != key or f["probability"].shape != (int(target.sum()), 101):
                        raise ValueError("Direct-window native probability-cache coverage differs")
                    probability = f["probability"]
                raw_choice = independent_choice(probability, control)
                if measure(y[target], raw_choice) != result["earlierPeriods"][phase]["models"][setting]:
                    raise ValueError("Direct-window independent raw native modal predictions differ")
                provenance[phase + ":" + setting] = verify_execution(
                    path, key, mask, runner, args.execution_root, cohort == "bench"
                )
                bundle_count += 1
                for record in [r for r in active if r["spec"]["model"] == setting]:
                    spec = record["spec"]
                    candidate = independent_gate(
                        probability, control, positions[target], spec["threshold"], spec["scope"]
                    )
                    if phase == "later2026":
                        alternate = candidate
                    elif measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                        raise ValueError("Direct-window independent earlier native gate forecasts differ")
                    reconstructed += 1
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Direct-window final native population/vector identity differs")
            for field, metric in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[metric]:
                    raise ValueError("Direct-window native final metrics differ")
            h1, h0 = abs(f["alternate"] - y[target]) <= 7, abs(f["control"] - y[target]) <= 7
        receipt = dict(
            n=int(target.sum()),
            candidateCorrect=int(h1.sum()),
            controlCorrect=int(h0.sum()),
            gained=int((h1 & ~h0).sum()),
            lost=int((h0 & ~h1).sum()),
            modelProbabilityBundlesVerified=bundle_count,
            candidateForecastsIndependentlyReconstructed=reconstructed,
            executionProvenance=provenance,
            earlierSelectionVerified=True,
            freezeSha256=hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
            actualSelectedFullRefitPerformed=False,
        )
        if args.refit_if_better and winner is not None and h1.sum() > {"start": 2765, "bench": 2201}[cohort]:
            numeric, feature_names = ordinary.ordinary_inputs(
                base[keep], names, player[keep], player_names, match[keep], match_names, cohort
            )
            if feature_names != result["featureNames"]:
                raise ValueError("Direct-window native refit feature schema differs")
            frame = pd.DataFrame(numeric, columns=[f"n{i}" for i in range(numeric.shape[1])])
            cats = ["player_id", "playing_side", "opponent_side", "card_position"]
            for j, n in enumerate(cats):
                frame[n] = identities[keep, j]
            hidden = y.copy()
            hidden[~masks["later2026"]["fit"]] = np.nan
            refit_key = hashlib.sha256((key + "actual-final-refit-without-outside-scores").encode()).hexdigest()
            refit_path = args.cache / f"{args.report.stem}_{cohort}_audit_final_{best['spec']['model']}.npz"
            repeated = resume.snapshot_fit(
                runner,
                frame,
                cats,
                hidden,
                masks["later2026"],
                best["spec"]["model"],
                refit_path,
                refit_key,
                args.execution_root,
                safe=cohort == "bench",
            )
            original = args.cache / f"{args.report.stem}_{cohort}_later2026_{best['spec']['model']}.npz"
            with np.load(original) as f:
                if not np.allclose(repeated, f["probability"], atol=1e-12, rtol=0):
                    raise ValueError("Actual final native direct-window refit changed without outside-fit scores")
            receipt["actualSelectedFullRefitPerformed"] = True
            receipt["outsideFitScoresBlanked"] = int((~masks["later2026"]["fit"]).sum())
        evidence[cohort] = receipt
    output = dict(
        scope="Testing-only independent native direct-window caches/gates/freeze/execution audit; no fresh blind claim",
        implementationKey=key,
        cohorts=evidence,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
