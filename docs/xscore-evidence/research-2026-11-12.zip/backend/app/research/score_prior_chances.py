"""Testing-only previous-season chance inputs from a hashed public archive."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import unicodedata
from collections import defaultdict
from pathlib import Path

import numpy as np

from app.research.score_feature_compare import compare_features

CHANCE = ("xG", "npxG", "xA", "shots", "key_passes", "xGChain", "xGBuildup")
OBSERVED = ("goals", "npg", "assists", "yellow_cards", "red_cards")


def words(value):
    plain = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    return tuple(re.findall("[a-z]+", plain))


def link_players(players, aliases, records):
    by_name = defaultdict(set)
    for r in records:
        by_name[words(r["player_name"])].add(r["id"])
    result = {}
    for player in players:
        variants = {words(player), *(words(n) for n in aliases.get(player, []))}
        exact = set().union(*(by_name.get(v, set()) for v in variants))
        if len(exact) == 1:
            result[player] = next(iter(exact))
        elif not exact:
            full = set(words(player))
            subset = set().union(*(ids for name, ids in by_name.items() if len(name) >= 2 and set(name) <= full))
            if len(subset) == 1:
                result[player] = next(iter(subset))
    return result


def prior_features(rows, links, records):
    indexed = defaultdict(list)
    seen = set()
    for r in records:
        identity = (r["id"], int(r["year"]), r["league"])
        if identity in seen:
            raise ValueError(f"Duplicate source identity/year/league: {identity}")
        seen.add(identity)
        indexed[identity[:2]].append(r)
    names = ["prior_found", "prior_games", "prior_minutes", "prior_laliga_minutes_share", "prior_partial_snapshot"]
    names += [f"prior_{field}_per90" for field in CHANCE + OBSERVED]
    extra = np.full((len(rows), len(names)), np.nan)
    counts = defaultdict(int)
    for i, row in enumerate(rows):
        year, month = int(row["date"][:4]), int(row["date"][5:7])
        prior_year = year - (1 if month >= 7 else 2)
        previous = indexed.get((links.get(row["player"]), prior_year), [])
        extra[i, 0] = bool(previous)
        if not previous:
            counts["unmatchedOrNoPreviousSeason"] += 1
            continue
        minutes = sum(float(r["time"]) for r in previous)
        games = sum(float(r["games"]) for r in previous)
        partial = prior_year == 2025
        extra[i, :5] = [
            1,
            games,
            minutes,
            sum(float(r["time"]) for r in previous if r["league"] == "La_Liga") / minutes if minutes else np.nan,
            partial,
        ]
        for j, field in enumerate(CHANCE + OBSERVED, 5):
            values = [r.get(field) for r in previous]
            if minutes and all(v not in (None, "") for v in values):
                extra[i, j] = sum(float(v) for v in values) * 90 / minutes
        counts["matched"] += 1
        counts["partialSnapshot"] += int(partial)
    return extra, names, dict(counts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "archive", "names", "control", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    aliases = json.loads(args.names.read_text(encoding="utf-8"))
    files = sorted(args.archive.glob("*.csv"))
    raw = b"".join(p.read_bytes() for p in files)
    records = []
    for path in files:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            records.extend(csv.DictReader(handle))
    players = sorted({r["player"] for r in source["rows"]})
    links = link_players(players, aliases, records)
    extra, names, coverage = prior_features(source["rows"], links, records)
    key = hashlib.sha256(raw + args.names.read_bytes() + Path(__file__).read_bytes()).hexdigest()
    source_names = defaultdict(set)
    for r in records:
        source_names[r["id"]].add(r["player_name"])
    audit = {
        "source": "Community Understat-derived archive; collector/source hashes in mirror receipt",
        "coverage": coverage,
        "uniquePlayers": len(players),
        "linkedPlayers": len(links),
        "sourceYears": sorted({int(r["year"]) for r in records}),
        "sourceRows": len(records),
        "laterCoverage": {},
        "links": [
            {"player": p, "id": identity, "names": sorted(source_names[identity])} for p, identity in links.items()
        ],
    }
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        audit["laterCoverage"][cohort] = {
            "n": int(selected.sum()),
            "matched": int(extra[selected, 0].sum()),
            "partialSnapshot": int(np.nansum(extra[selected, 4])),
        }
    args.out.with_suffix(".source-audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print("Prior source " + json.dumps({k: v for k, v in audit.items() if k != "links"}), flush=True)
    if args.audit_only:
        return
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    with np.load(args.stats_cache) as stored:
        numeric, stat_key = stored["x"], str(stored["key"])
    groups = {
        "chance_quality": np.array([not any(n == f"prior_{f}_per90" for f in OBSERVED) for n in names]),
        "chance_quality_observed": np.ones(len(names), dtype=bool),
    }
    compare_features(
        args, source, numeric, stat_key, extra, names, groups, key, {k: v for k, v in audit.items() if k != "links"}
    )


if __name__ == "__main__":
    main()
