"""Test matchup memory with additional complete historical seasons."""

import hashlib
import json
from collections import defaultdict, deque
from math import exp, log1p

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS
from app.research.score_card_cycle import PHASES
from app.research.score_goal_context_rebuild import interval
from app.research.score_search import cutoff_for, moment
from app.research.score_table_tempo import make_examples, model, read_all
from app.research.score_team_routine_shift import DELAY

STEM = "laliga_score_repeat_fixture_long"


def matchup_context(fixtures, standard):
    order = sorted(fixtures, key=lambda game: moment(game[0]))
    ready = [moment(g[0]) + DELAY for g in order]
    history = defaultdict(lambda: deque(maxlen=8))
    created = {}
    cursor = 0
    output = []
    for idx, (date, _, home, away, labels, _) in enumerate(order):
        at = moment(date)
        lock = cutoff_for(date)
        while cursor < len(order) and ready[cursor] < lock:
            for key, entry in created.pop(cursor):
                history[key].append(entry)
            cursor += 1
        matchup = []
        for side, own, opp in ((0, home, away), (1, away, home)):
            row = standard[2 * idx + side]
            assert row[0] == date
            current = row[3]
            own_attack = current[[9, 11]]
            opponent_allowed = current[[14, 16]]
            expected = (own_attack + opponent_allowed) / 2
            known = list(history[own, opp])
            weights = np.array([exp(-(lock - t).days / 450) for t, _, _ in known])
            effects = np.array([p for _, _, p in known]).reshape(-1, 2)
            valid = np.isfinite(effects)
            means = np.sum(weights[:, None] * np.where(valid, effects, 0), axis=0) / (5 + weights @ valid)
            output.append(np.r_[means, log1p(len(known)), log1p(sum(s == side for _, s, _ in known))])
            observed = np.array([labels[side], labels[side + 2]], dtype=float)
            matchup.append(((own, opp), (at, side, observed - expected)))
        created[idx] = matchup
    return np.array(output)


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {
        (g["date"][:10], g["home"]["slug"], g["away"]["slug"]): g
        for g in map(json.loads, raw.splitlines())
        if g["date"] < "2026-01-01"
    }
    data, receipts = read_all(NATIVE.parent / "football-data-co-uk", games)
    fixtures = [r for r in data if r[0][:10] < "2026-01-01"]
    examples = make_examples(fixtures)
    assert sum(r[1] for r in examples) == 2 * len(games)
    x = np.array([r[3] for r in examples])
    history = matchup_context(fixtures, examples)
    candidate = np.column_stack((x, history))
    date = np.array([r[0][:10] for r in examples])
    source = np.array([r[1] for r in examples])
    y = np.array([r[2] for r in examples], dtype=float)
    locks = np.array([cutoff_for(r[0]) for r in examples])
    ready = np.array([moment(r[0]) + DELAY for r in examples])
    output = {}
    paired = defaultdict(list)
    for phase, (begin, end) in PHASES.items():
        within = source & (date >= begin) & (date < end)
        earlier = ready < locks[within].min()
        output[phase] = {}
        for j, name in enumerate(("goals", "shotsOnTarget")):
            label = y[:, j]
            fit, test = earlier & np.isfinite(label), within & np.isfinite(label)
            p, q = [model(z, label, fit, test) for z in (x, candidate)]
            paired[name].append((abs(label[test] - p) - abs(label[test] - q), locks[test]))
            output[phase][name] = dict(
                sides=int(test.sum()),
                fitSides=int(fit.sum()),
                knownRepeat=int(np.count_nonzero(history[test, 2])),
                mae=[float(np.mean(abs(label[test] - estimate))) for estimate in (p, q)],
            )
    gains = {}
    for name in ("goals", "shotsOnTarget"):
        values = [d[name] for d in output.values()]
        gains[name] = sum(v["sides"] * (v["mae"][0] - v["mae"][1]) for v in values) / sum(v["sides"] for v in values)
    stable = sum(all(v["mae"][1] <= v["mae"][0] for v in d.values()) for d in output.values())
    uncertainty = {
        name: interval(np.concatenate([gain for gain, _ in records]), np.concatenate([clock for _, clock in records]))
        for name, records in paired.items()
    }
    result = dict(
        sourceSHA=receipts,
        nativeSHA=NATIVE_SHA,
        periods=output,
        pooledMAEGain=gains,
        pairedWeeklyGain95=uncertainty,
        phasesWithoutLoss=stable,
        passEarlier=min(gains.values()) > 0 and stable >= 2,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("sourceSHA", "nativeSHA")}, indent=2))


if __name__ == "__main__":
    main()
