"""Independent full keeper inputs, native probabilities and all48 blinded refits."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_keeper_signal as study
from app.research.score_search import cutoff_for, moment
from app.research.score_shot_style_signal_audit import compare_metrics, independent_inputs, native_losses


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_keeper_signal.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, actual_inputs, labels, provenance = study.load_inputs(args)
    report = json.loads(args.out.read_text())
    key = hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + sklearn.__version__).encode()
        + Path(study.__file__).read_bytes()
        + Path(study.previous.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if key != report["implementationKey"] or provenance != report["provenance"]:
        raise ValueError("Frozen model/source/plan identity differs")
    old = independent_inputs(source, args.cache)["baseline"]
    with np.load(args.cache / "keeper_quality_features.npz") as f:
        x = f["x"]
    shared, extra = [], []
    for offset in (0, 12):
        for j in range(11):
            v = x[:, offset + j]
            shared.append(v if j in (2, 5, 8, 9) else np.log1p(v))
        extra.append(x[:, offset + 11])
    baseline = np.column_stack((old, *shared))
    independent = dict(baseline=baseline, keeper=np.column_stack((baseline, *extra)))
    for arm in independent:
        np.testing.assert_allclose(independent[arm], actual_inputs[arm], rtol=0, atol=1e-14, equal_nan=True)
    games = {g["id"]: g for g in (json.loads(line) for line in args.games.read_text().splitlines() if line.strip())}
    native_y = dict(goal=[], goalassist=[])
    for row in source["rows"]:
        p = games[row["game"]]["players"][row["player"]]
        goals, assists = p["stats"].get("goals", [0])[0], p["stats"].get("goal_assist", [0])[0]
        native_y["goal"].append(float(goals > 0))
        native_y["goalassist"].append(float(goals > 0 or assists > 0))
    for outcome in native_y:
        np.testing.assert_array_equal(labels[outcome], native_y[outcome])
    vectors = refits = 0
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        observed = report["cohorts"][cohort]
        pooled = {(o, a): dict(y=[], old=[], new=[], weeks=[]) for o in native_y for a in ("logistic", "nonlinear")}
        gains = {k: [] for k in pooled}
        for phase, begin, end in (
            ("spring2024", "2024-01-01", "2024-07-01"),
            ("season2024", "2024-07-01", "2025-07-01"),
            ("autumn2025", "2025-07-01", "2026-01-01"),
        ):
            target = np.array([begin <= r["date"] < end for r in rows])
            lock = min(cutoff_for(r["date"]) for r, yes in zip(rows, target, strict=True) if yes)
            fit = np.array([r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
            if any(r["date"] >= "2026-01-01" and (f or t) for r, f, t in zip(rows, fit, target, strict=True)):
                raise ValueError("Forbidden later2026 model selection")
            phase_report = observed["periods"][phase]
            if (
                phase_report["fit"] != sum(fit)
                or phase_report["target"] != sum(target)
                or phase_report["firstLock"] != lock.isoformat()
            ):
                raise ValueError("Full strict chronological period masks differ")
            for outcome, all_y in native_y.items():
                y = np.array(all_y)[keep]
                blanked = y.copy()
                blanked[~fit] = np.nan
                for architecture in ("logistic", "nonlinear"):
                    predictions, metrics, shared_transform = {}, {}, None
                    for arm, full_x in actual_inputs.items():
                        x = full_x[keep]
                        path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{outcome}_{architecture}_{arm}.npz"
                        with np.load(path) as f:
                            if str(f["key"]) != key:
                                raise ValueError("Saved native model probability key differs")
                            np.testing.assert_array_equal(f["fit"], fit)
                            np.testing.assert_array_equal(f["target"], target)
                            np.testing.assert_array_equal(f["actual"], y[target])
                            p = f["probability"].copy()
                            if architecture == "logistic":
                                if int(f["missing_width"]) != 47:
                                    raise ValueError("Same baseline47missing indicators required")
                                med = np.array(
                                    [np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0.0 for c in x[fit].T]
                                )
                                complete = np.where(np.isfinite(x), x, med)
                                mean, scale = complete[fit].mean(axis=0), complete[fit].std(axis=0)
                                scale[scale <= 1e-8] = 1
                                for name, v in (("median", med), ("mean", mean), ("scale", scale)):
                                    np.testing.assert_array_equal(f[name], v)
                                if shared_transform is None:
                                    shared_transform = tuple(f[n][:47].copy() for n in ("median", "mean", "scale"))
                                else:
                                    for v, n in zip(shared_transform, ("median", "mean", "scale"), strict=True):
                                        np.testing.assert_array_equal(v, f[n][:47])
                                z = np.column_stack(((complete - mean) / scale, ~np.isfinite(x[:, :47])))
                                eta = z[target] @ f["coefficient"] + f["intercept"]
                                np.testing.assert_allclose(p, 1 / (1 + np.exp(-eta)), rtol=0, atol=1e-13)
                                model = LogisticRegression(
                                    C=1, solver="lbfgs", max_iter=1000, tol=1e-8, random_state=20261105
                                )
                            else:
                                z = x
                                model = HistGradientBoostingClassifier(
                                    max_iter=120,
                                    max_leaf_nodes=7,
                                    min_samples_leaf=80,
                                    learning_rate=0.06,
                                    l2_regularization=10,
                                    early_stopping=False,
                                    random_state=20261106,
                                )
                        model.fit(z[fit], blanked[fit])
                        np.testing.assert_array_equal(p, model.predict_proba(z[target])[:, 1])
                        predictions[arm] = p
                        metrics[arm] = native_losses(y[target], p)
                        compare_metrics(metrics[arm], phase_report["outcomes"][outcome][architecture]["metrics"][arm])
                        vectors += 1
                        refits += 1
                    gain = dict(
                        logloss=metrics["baseline"]["logloss"] - metrics["keeper"]["logloss"],
                        brier=metrics["baseline"]["brier"] - metrics["keeper"]["brier"],
                    )
                    for loss, v in gain.items():
                        np.testing.assert_allclose(
                            v, phase_report["outcomes"][outcome][architecture]["improvement"][loss], rtol=0, atol=1e-13
                        )
                    gains[outcome, architecture].append(gain)
                    p = pooled[outcome, architecture]
                    p["y"].extend(y[target])
                    p["old"].extend(predictions["baseline"])
                    p["new"].extend(predictions["keeper"])
                    p["weeks"].extend(r["week"] for r, yes in zip(rows, target, strict=True) if yes)
                    print(f"KEEPER_ACTUAL_REFIT {cohort}/{phase}/{outcome}/{architecture}", flush=True)
        for (outcome, architecture), p in pooled.items():
            y, old, new = (np.array(p[k]) for k in ("y", "old", "new"))
            r = observed["pooled"][outcome][architecture]
            for arm, probability in (("baseline", old), ("keeper", new)):
                compare_metrics(native_losses(y, probability), r[arm])
            totals = defaultdict(lambda: [0.0, 0.0])
            for a, b, c, w in zip(y, old, new, p["weeks"], strict=True):
                totals[w][0] += (a - b) ** 2 - (a - c) ** 2
                totals[w][1] += 1
            sums = np.array([totals[w] for w in sorted(totals)])
            selected = np.random.default_rng(20261105).integers(len(sums), size=(2000, len(sums)))
            sampled = sums[selected].sum(axis=1)
            bounds = np.quantile(sampled[:, 0] / sampled[:, 1], [0.025, 0.975])
            np.testing.assert_allclose(bounds, r["brierImprovement95"], rtol=0, atol=1e-13)
            consistent = all(g["brier"] > 0 and g["logloss"] > 0 for g in gains[outcome, architecture])
            if r["allThreeEarlierPeriodsImprove"] != consistent or r["passesSignalGate"] != (
                consistent and bounds[0] > 0
            ):
                raise ValueError("Independent advance gate differs")
        if observed["passesPrimaryGoalGate"] != any(v["passesSignalGate"] for v in observed["pooled"]["goal"].values()):
            raise ValueError("Primary goal gate differs")
    result = dict(
        implementationKey=key,
        nativeCasesVerified=38850,
        independentlyVerifiedInputColumns=49,
        nativeOutcomeLabelsVerified=2 * 38850,
        strictChronologicalMasks=6,
        nativeProbabilityVectors=vectors,
        actualOutsideFitBlankedFullRefits=refits,
        sameBaselineAvailabilityAcrossArms=True,
        independentLossesAndGWBootstrap=True,
        later2026FittedOrEvaluated=False,
        status="COMPLETE independent49inputs/native outcomes/48vectors/48actualblindedrefits/masks/metrics/bootstrap audit",
    )
    args.out.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2) + "\n")
    print("KEEPER_SIGNAL_AUDIT " + json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
