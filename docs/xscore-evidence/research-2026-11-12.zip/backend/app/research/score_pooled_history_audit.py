"""Testing only: independently reconstruct shared native labels and every causal input."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import zipfile
from bisect import bisect_left
from collections import defaultdict
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_europe_routine as routine
from app.research import score_europe_routine_history as history
from app.research import score_europe_routine_history_audit as native_audit
from app.research import score_pooled_history as pooled
from app.research import score_search, score_windows
from app.research import score_team_shape_history as modal
from app.research.score_search import cutoff_for, moment


def score_summary(records, lock):
    if not records:
        return [0, *([np.nan] * 8), 0, *([np.nan] * 5)]
    scores = np.array([r["score"] for r in records])
    centres = np.linspace(0, 100, 201)
    hits = np.array([sum(abs(float(s) - c) <= 7 for s in scores) for c in centres])
    winners = np.flatnonzero(hits == hits.max())
    centre = centres[winners[np.argmin(abs(centres[winners] - centres[winners].mean()))]]
    rates = np.array([90 * r["ordinary"]["point"] / r["minutes"] for r in records if r["ordinary"]["kind"] == "exact"])
    return [
        len(records),
        (lock.timestamp() - moment(records[-1]["date"]).timestamp()) / 86400,
        scores.sum() / len(scores),
        float(np.quantile(scores, 0.5)),
        float(centre),
        hits.max() / len(records),
        sum(r["level"] >= 60 for r in records) / len(records),
        sum(r["level"] < 35 for r in records) / len(records),
        sum(r["minutes"] for r in records) / len(records),
        len(rates),
        rates.sum() / len(rates) if len(rates) else np.nan,
        float(np.quantile(rates, 0.5)) if len(rates) else np.nan,
        *[
            sum(r["ordinary"]["kind"] == kind for r in records) / len(records)
            for kind in ("upper", "lower", "unbounded")
        ],
    ]


def independent_features(queries, records):
    by_player = defaultdict(list)
    for r in sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["player"])):
        by_player[r["player"], r["pos"]].append(r)
    available = {k: [moment(r["date"]).timestamp() + 172800 for r in rs] for k, rs in by_player.items()}
    result = np.full((len(queries), 226), np.nan)
    for i, q in enumerate(queries):
        lock = cutoff_for(q["date"])
        identity = q["player"], q["pos"]
        previous = by_player[identity][: bisect_left(available.get(identity, []), lock.timestamp())]
        previous = [r for r in previous if moment(r["date"]).timestamp() >= lock.timestamp() - 365 * 86400]
        values = []
        for source in ("euro", "combined"):
            eligible = [r for r in previous if source == "combined" or r["source"] == "euro"]
            for same in (False, True):
                selected = [r for r in eligible if not same or r["cohort"] == q["cohort"]]
                for n in (5, 15):
                    summary = native_audit.reference_summary(selected[-n:], lock, q["club"])
                    values.extend(summary[f] for f in native_audit.FIELDS)
        for same in (False, True):
            selected = [r for r in previous if not same or r["cohort"] == q["cohort"]]
            for n in (5, 15):
                values.extend(score_summary(selected[-n:], lock))
        values.extend(float(q["pos"] == p) for p in ("GK", "DEF", "MID", "FWD"))
        values.extend((float(q["home"]), float(q["source"] == "euro")))
        result[i] = values
    return result


def native_labels(games, archives, records, saved):
    by_id = {(r["game"], r["player"]): r for r in records}
    seen, headers = set(), {}

    def attach(identity, score, level, bounds):
        if identity in seen:
            raise ValueError("Ambiguous duplicated native shared outcome")
        original = saved[identity]
        if original["score"] != score or original["level"] != level or original["ordinary"] != bounds:
            raise ValueError("Shared native score/DS/AA point-or-bounds differ")
        by_id[identity].update(score=float(score), level=float(level), ordinary=bounds)
        seen.add(identity)

    for line in games.open("rb"):
        if not line.strip():
            continue
        g = json.loads(line)
        headers[g["id"]] = dict(date=g["date"], home=g["home"]["slug"], away=g["away"]["slug"])
        for player, p in g["players"].items():
            identity = g["id"], player
            if identity not in by_id or by_id[identity]["source"] != "laliga":
                continue
            aa = float(p["aa"])
            attach(identity, p["score"], p["level"], dict(point=aa, lower=aa, upper=aa, kind="exact"))
    for competition in ("CL", "EL", "CONF"):
        with zipfile.ZipFile(archives / f"{competition}.zip") as archive:
            for name in sorted(archive.namelist()):
                if not name.startswith("games/") or not name.endswith(".json"):
                    continue
                g = json.loads(archive.read(name)).get("raw") or {}
                if g.get("statusTyped") != "played":
                    continue
                if all(g.get(k) for k in ("id", "date", "homeTeam", "awayTeam")):
                    h = dict(date=g["date"], home=g["homeTeam"]["slug"], away=g["awayTeam"]["slug"])
                    if g["id"] in headers and headers[g["id"]] != h:
                        raise ValueError("Independent shared native headers disagree")
                    headers[g["id"]] = h
                for p in g.get("playerGameScores") or []:
                    identity = g.get("id"), (p.get("anyPlayer") or {}).get("slug")
                    if (
                        identity not in by_id
                        or by_id[identity]["source"] != "euro"
                        or p.get("scoringVersion") != 7
                        or p.get("scoreStatus") != "FINAL"
                        or (p.get("anyPlayerGameStats") or {}).get("playedInGame") is not True
                    ):
                        continue
                    score, level = p["score"], p["decisiveScore"]["totalScore"]
                    floor = level if level >= 60 else 0
                    if level == 100:
                        low = high = None
                    elif score == floor:
                        low, high = None, float(floor - level)
                    elif score == 100:
                        low, high = float(100 - level), None
                    else:
                        low = high = float(score - level)
                    bounds = native_audit.point_bounds(low, high)
                    attach(identity, score, level, bounds)
    if seen != set(saved):
        raise ValueError("Independent shared native training-label coverage differs")
    return records, headers


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "routine-cache", "features", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    raw = args.routine_cache.with_suffix(".observations.json.gz").read_bytes()
    corpus = json.loads(gzip.decompress(raw))
    saved = {(r["game"], r["player"]): r for r in corpus["records"]}
    records, targets, prices, receipts, ll_sha, evidence = native_audit.native_sources(args.games, args.archives, saved)
    if (
        targets != corpus["targets"]
        or prices != corpus["earlyNativePrices"]
        or ll_sha != corpus["laligaSha256"]
        or any(a["sha256"] != b["sha256"] for a, b in zip(receipts, corpus["receipts"], strict=True))
    ):
        raise ValueError("Independent shared source/early-price/hash mismatch")
    records, headers = native_labels(args.games, args.archives, records, saved)
    expected = []
    for r in sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["player"])):
        if r["cohort"] is None:
            if r["source"] == "laliga":
                raise ValueError("Independent shared canonical cohort missing")
            continue
        h = headers[r["game"]]
        if r["date"] != h["date"] or r["club"] not in (h["home"], h["away"]):
            raise ValueError("Independent shared actual playing side unknown")
        expected.append(
            {
                **{k: r[k] for k in ("game", "player", "date", "club", "pos", "cohort", "source")},
                "home": r["club"] == h["home"],
            }
        )
    query_file = json.loads(gzip.decompress(args.features.with_suffix(".queries.json.gz").read_bytes()))
    if query_file["queries"] != expected or len(expected) != 95852:
        raise ValueError("Independent shared query membership/order/header identity differs")
    modules = (routine, ordinary, history, modal, score_search, score_windows)
    sha = hashlib.sha256(raw).hexdigest()
    key = hashlib.sha256(
        (source["key"] + corpus["key"] + sha).encode()
        + Path(pooled.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    with np.load(args.features) as f:
        x, indices = f["x"], f["canonical_indices"]
        if str(f["key"]) != key or tuple(f["names"]) != pooled.NAMES or x.shape != (95852, 226):
            raise ValueError("Independent shared feature/code/plan/schema identity differs")
    if report["featureKey"] != key or query_file["key"] != key or report["sourceKey"] != source["key"]:
        raise ValueError("Independent shared report identity differs")
    lookup = {(q["game"], q["player"]): i for i, q in enumerate(expected)}
    if not np.array_equal(indices, [lookup[r["game"], r["player"]] for r in source["rows"]]):
        raise ValueError("Independent shared canonical case mapping differs")
    for r in source["rows"]:
        old = saved[r["game"], r["player"]]
        if (
            any(old[n] != r[n] for n in ("date", "pos", "cohort", "minutes", "score", "level"))
            or abs(old["ordinary"]["point"] - r["aa"]) > 1e-10
        ):
            raise ValueError("Independent shared all38850 native canonical labels differ")
    print("SHARED_HISTORY_AUDIT independent95852x226", flush=True)
    repeated = independent_features(expected, records)
    same = np.isclose(x, repeated, atol=1e-10, rtol=0, equal_nan=True)
    if not same.all():
        bad = np.argwhere(~same)
        details = [(int(i), pooled.NAMES[j], float(x[i, j]), float(repeated[i, j])) for i, j in bad[:15]]
        raise ValueError(f"Independent shared features differ {len(bad)} cells: {details}")
    with np.load(args.routine_cache) as f:
        if str(f["key"]) != corpus["key"] or not np.array_equal(x[indices, :160], f["x"], equal_nan=True):
            raise ValueError("Independent shared canonical160 routine inputs changed")
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    chosen = [i for i, q in enumerate(expected) if q["source"] == "laliga" and cutoff_for(q["date"]) == first]
    altered = copy.deepcopy(corpus["records"])
    changed = 0
    for r in altered:
        if moment(r["date"]).timestamp() + 172800 >= first.timestamp():
            r.update(score=np.nan, level=np.nan, minutes=-999, cohort=None)
            r["ordinary"] = dict(point=np.nan, lower=np.nan, upper=np.nan, kind="exact")
            r["routine"] = dict(point=np.nan, lower=np.nan, upper=np.nan, kind="exact")
            changed += 1
    queries = [{**expected[i], "score": np.nan, "aa": np.nan, "level": np.nan, "minutes": -999} for i in chosen]
    causal = pooled.build_features(queries, altered)
    if not np.array_equal(causal, x[chosen], equal_nan=True):
        raise ValueError("Current/future pooled query outcomes changed prelock descriptors")
    result = dict(
        scope="Testing-only full native pooled-history audit, no accuracy claim",
        featureKey=key,
        nativeObservationsVerified=len(records),
        nativeTrainingLabelsAndAAIntervalsVerified=len(records),
        queries=len(expected),
        featureColumns=226,
        all226ColumnsReproduced=True,
        absoluteTolerance=1e-10,
        independentFeatureRows=len(x),
        canonicalCases=38850,
        all6754Starts2925PlayedSubsRetained=True,
        first2026LockCasesUnchanged=len(chosen),
        unavailableObservationOutcomesMutated=changed,
        nativeSourceEvidence=evidence,
        allCanonicalRoutineInputsExactlyReproduced=True,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
