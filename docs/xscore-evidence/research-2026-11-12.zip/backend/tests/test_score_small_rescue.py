import numpy as np
import pytest

from app.research.score_small_rescue import replace_high


def test_only_confident_separated_high_forecasts_replace_old_score():
    old = np.array([40.0, 40, 70, 40, 40])
    high = np.array([80.0, 80, 75, 47, 80])
    confidence = np.array([0.1, 0.3, 0.5, 0.5, 0.2])
    prediction, changed = replace_high(old, high, confidence, 0.2)
    np.testing.assert_array_equal(prediction, [40, 80, 70, 40, 40])
    np.testing.assert_array_equal(changed, [False, True, False, False, False])
    assert len(prediction) == len(old)


def test_missing_or_impossible_confidence_is_rejected():
    for confidence in (np.array([np.nan]), np.array([1.1]), np.array([-0.1])):
        with pytest.raises(ValueError, match="confidence"):
            replace_high(np.array([40.0]), np.array([80.0]), confidence, 0.2)
