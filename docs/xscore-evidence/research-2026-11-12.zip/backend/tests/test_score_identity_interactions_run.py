"""Testing only: real interaction fits retain a fixed training prefix and ignore held-out scores."""

import json
from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_identity_interactions_run as runner


def test_actual_cached_interaction_fit_excludes_future_scores_and_identities(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(29)
    x = rng.normal(size=(180, 3))
    x[::11, 0] = np.nan
    y = rng.choice([40.0, 80.0], 180)
    cats = np.array([["p" + str(i % 2), "t", "o" + str(i % 3)] for i in range(180)], dtype=object)
    cats[150:, 0] = "future-player"
    fit = np.arange(180) < 150
    mask = dict(fit=fit, target=~fit)
    spec = dict(rank=2, width=4, ridge=0.001, embedding_ridge=0.001)
    root = Path(__file__).parents[1] / "data/raw/interaction-tests" / uuid4().hex
    root.mkdir(parents=True)
    first_path, second_path, long_path = (root / (n + ".npz") for n in ("first", "hidden", "longer"))
    first, _ = runner.fitted(x, cats, y, mask, spec, 2, first_path, "fixture")
    y[~fit] = np.nan
    second, _ = runner.fitted(x, cats, y, mask, spec, 2, second_path, "fixture")
    runner.fitted(x, cats, y, mask, spec, 4, long_path, "fixture")
    np.testing.assert_array_equal(first, second)
    with np.load(first_path) as a, np.load(second_path) as b, np.load(long_path) as c:
        maps = json.loads(str(a["category_maps"]))
        assert "future-player" not in maps[0]
        np.testing.assert_array_equal(a["history"], c["history"][:2])
        for name in ("normaliser_mean", "normaliser_scale", "normaliser_known", "category_maps"):
            np.testing.assert_array_equal(a[name], b[name])
            np.testing.assert_array_equal(a[name], c[name])
        for name in a.files:
            if name.startswith("w_"):
                np.testing.assert_array_equal(a[name], b[name])
