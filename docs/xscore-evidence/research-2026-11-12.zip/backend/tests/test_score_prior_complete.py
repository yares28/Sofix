import numpy as np

from app.research.score_prior_chances import prior_features
from app.research.score_prior_complete import complete_records


def test_complete_archive_replaces_only_2025_and_preserves_old_training_inputs():
    old = [
        {
            "year": "2024",
            "id": "1",
            "player_name": "Test",
            "league": "La_Liga",
            "time": "900",
            "games": "10",
            "xG": "1",
        },
        {"year": "2025", "id": "1", "player_name": "Test", "league": "La_Liga", "time": "90", "games": "1", "xG": "9"},
    ]
    full = [
        {
            "season": "2526",
            "player_id": "1",
            "player": "Test",
            "league": "ESP-La Liga",
            "minutes": "1800",
            "matches": "20",
            "xg": "5",
        }
    ]
    merged = complete_records(old, full)
    rows = [{"player": "p", "date": date} for date in ("2025-10-01T20:00:00Z", "2026-08-20T20:00:00Z")]
    before, names, _ = prior_features(rows, {"p": "1"}, old)
    after, _, _ = prior_features(rows, {"p": "1"}, merged)
    np.testing.assert_array_equal(before[0], after[0])
    assert after[1, names.index("prior_xG_per90")] == 0.25


def test_new_full_season_never_backfills_a_missing_older_season():
    full = [
        {
            "season": "2526",
            "player_id": "1",
            "player": "Test",
            "league": "ESP-La Liga",
            "minutes": "1800",
            "matches": "20",
            "xg": "5",
        }
    ]
    merged = complete_records([], full)
    rows = [{"player": "p", "date": "2026-01-20T20:00:00Z"}]
    x, names, _ = prior_features(rows, {"p": "1"}, merged)
    assert x[0, names.index("prior_found")] == 0
    assert np.isnan(x[0, names.index("prior_xG_per90")])
