"""Earlier-only test of club appearance and return patterns for xScore."""

import hashlib
import json
from collections import defaultdict, deque

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, fit, metrics

STEM = "laliga_score_return_sequence"


def status(player, bench, slug, club):
    if player is None or player.get("team") != club:
        return "unknown"
    minutes = player.get("mins")
    if player.get("played") is True and type(minutes) is int and minutes > 0:
        return "start" if player.get("started") is True else "bench"
    if player.get("played") is False and minutes == 0 and slug in bench:
        return "unused"
    return "unknown"


def sequence(states):
    available = {"start", "bench"}
    appeared = np.array([s in available for s in states], dtype=bool)
    observed = np.flatnonzero(appeared)
    since_played = len(states) - 1 - observed[-1] if len(observed) else len(states)
    prior_break = int(observed[-1] - observed[-2] - 1) if len(observed) >= 2 else -1
    active = sum(s in available for s in states[-4:])
    unused = sum(s == "unused" for s in states[-6:])
    unknown = sum(s == "unknown" for s in states[-6:])
    tail = states[-3:]
    return (
        len(states),
        int(appeared.sum()),
        since_played,
        active,
        sum(s == "start" for s in states[-6:]),
        sum(s == "bench" for s in states[-6:]),
        prior_break,
        unused,
        unknown,
        sum(s == "unused" for s in tail),
        int(bool(states) and states[-1] == "unused"),
        int(bool(states) and states[-1] == "bench" and prior_break >= 2),
        int(since_played == 0 and prior_break >= 2),
        int(since_played >= 2 and len(observed) > 0),
    )


def histories(rows, games):
    fixtures = {g["id"]: g for g in games}
    clocks = {g["id"]: moment(g["date"]) for g in games}
    queue = sorted(games, key=lambda g: (clocks[g["id"]], g["id"]))
    history = defaultdict(lambda: deque(maxlen=12))
    cutoffs = [cutoff_for(r["date"]) for r in rows]
    x = np.empty((len(rows), 14))
    cursor = 0
    for i in sorted(range(len(rows)), key=cutoffs.__getitem__):
        row, lock = rows[i], cutoffs[i]
        while cursor < len(queue) and clocks[queue[cursor]["id"]] + DELAY < lock:
            g = queue[cursor]
            for side in ("home", "away"):
                club = g[side]["slug"]
                formation = g["xi"][side]
                history[club].append(
                    (g["players"], set(formation.get("bench", [])) if formation.get("available") else set())
                )
            cursor += 1
        g = fixtures[row["game"]]
        slug = row["player"]
        club = g["players"][slug]["team"]
        assert row["date"] == g["date"] and club in (g["home"]["slug"], g["away"]["slug"])
        x[i] = sequence([status(players.get(slug), bench, slug, club) for players, bench in history[club]])
    return x


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    native = np.array([r["x"] for r in rows])
    extra = histories(rows, games)
    inputs = {
        "control": native,
        "appearances": np.column_stack((native, extra[:, :7])),
        "fullSequence": np.column_stack((native, extra)),
    }
    roles = np.array([r["cohort"] for r in rows])
    dates = np.array([r["date"] for r in rows])
    actual_score = np.array([r["score"] for r in rows])
    actual_minutes = np.array([r["minutes"] for r in rows])
    clocks = np.array([cutoff_for(d) for d in dates])
    ready = np.array([moment(d) + DELAY for d in dates])
    results = {}
    for phase, (begin, end) in PHASES.items():
        period = (dates >= begin) & (dates < end)
        earlier = ready < clocks[period].min()
        results[phase] = {}
        for cohort in ("start", "bench"):
            fit_mask, test = earlier & (roles == cohort), period & (roles == cohort)
            a, b = [native[:, source["features"].index(f"{cohort}_10_{key}")] for key in ("score", "minutes")]
            p = {k: np.clip(a[test] + forecast(v, actual_score - a, fit_mask, test), 0, 100) for k, v in inputs.items()}
            m = {k: np.clip(b[test] + fit(v, actual_minutes - b, fit_mask, test), 1, 100) for k, v in inputs.items()}
            results[phase][cohort] = {
                k: dict(
                    **metrics(actual_score[test], p["control"], p[k]),
                    minutesMAE=[float(np.mean(abs(actual_minutes[test] - m[arm]))) for arm in ("control", k)],
                )
                for k in ("appearances", "fullSequence")
            }
            results[phase][cohort]["coverage"] = dict(
                playedBefore=int(np.count_nonzero(extra[test, 1])),
                confirmedUnusedRecently=int(np.count_nonzero(extra[test, 7])),
                returningAfterGap=int(np.count_nonzero(extra[test, -1])),
                playedSinceGap=int(np.count_nonzero(extra[test, -2])),
            )
    gate = {}
    for cohort in ("start", "bench"):
        gate[cohort] = {}
        for k in ("appearances", "fullSequence"):
            parts = [v[cohort][k] for v in results.values()]
            n = sum(v["n"] for v in parts)
            changes = [v["gained"] - v["lost"] for v in parts]
            mae = sum(v["n"] * (v["mae"][0] - v["mae"][1]) for v in parts) / n
            min_gain = sum(v["n"] * (v["minutesMAE"][0] - v["minutesMAE"][1]) for v in parts) / n
            gate[cohort][k] = dict(
                n=n,
                netHits=sum(changes),
                phaseHitGains=changes,
                maeGain=mae,
                minutesMAEGain=min_gain,
                passEarlier=sum(changes) > 0 and min(changes) >= 0 and mae > 0,
            )
    report = dict(nativeSHA=NATIVE_SHA, sourceKey=source["key"], periods=results, gate=gate, laterEvaluated=False)
    (REPORTS / (STEM + ".json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
