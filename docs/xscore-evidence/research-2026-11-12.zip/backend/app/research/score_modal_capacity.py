"""Testing only: a registered wider capacity grid for exact score-window forests."""

from __future__ import annotations

import math

import numpy as np

from app.research.score_modal_trees import FitBinner, ModalForest, ModalTree, score_intervals, week_weights

PARAMETERS = {
    f"{fraction}_leaf{leaf}_depth{depth}": {"features": fraction, "minLeaf": leaf, "depth": depth}
    for fraction in ("sqrt", "quarter", "all")
    for leaf in (80, 40, 20)
    for depth in (8, 12)
}


def candidate_feature_count(features, strategy):
    if strategy == "sqrt":
        return max(1, int(np.sqrt(features)))
    if strategy == "quarter":
        return max(1, math.ceil(features * 0.25))
    if strategy == "all":
        return None
    raise ValueError("Unknown registered feature strategy")


class CapacityForest(ModalForest):
    def __init__(self, trees, max_depth, min_leaf, feature_strategy, seed=20261104):
        super().__init__(trees, max_depth, min_leaf, seed)
        self.feature_strategy = feature_strategy

    def fit(self, x, scores, weeks):
        self.binner_ = FitBinner().fit(x)
        binned = self.binner_.transform(x)
        intervals = score_intervals(scores)
        count = candidate_feature_count(x.shape[1], self.feature_strategy)
        self.trees_ = []
        for i in range(self.trees):
            rng = np.random.default_rng(self.seed + i * 104729)
            tree = ModalTree(self.max_depth, self.min_leaf, count, prior=20)
            tree.fit_binned(binned, scores, self.binner_.bin_counts_, week_weights(weeks, rng), rng, intervals)
            self.trees_.append(tree)
            if (i + 1) % 16 == 0:
                print(f"CAPACITY_FOREST {i + 1}/{self.trees}", flush=True)
        self.statistics_ = {
            "trees": self.trees,
            "depthLimit": self.max_depth,
            "uniqueLeafMinimum": self.min_leaf,
            "featureStrategy": self.feature_strategy,
            "candidateFeaturesPerNode": x.shape[1] if count is None else count,
            "meanLeaves": float(np.mean([t.statistics_["leaves"] for t in self.trees_])),
            "trainingOnlyMeanTreeHit": float(np.mean([t.statistics_["trainingOnlyWeightedHit"] for t in self.trees_])),
        }
        return self
