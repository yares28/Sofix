import numpy as np

from app.research.score_stability import choose_stable, phase_masks, previous_bank_mask


def candidate(name, gains, errors=(12, 12, 12)):
    return {"name": name, "gains": gains, "errors": errors, "counts": [100, 200, 100]}


def test_large_gain_in_one_period_cannot_hide_a_loss_in_another():
    unstable = candidate("unstable", [0.1, 0.1, -0.001])
    stable = candidate("stable", [0.002, 0.002, 0.002])
    winner, best = choose_stable([unstable, stable])
    assert winner["name"] == best["name"] == "stable"


def test_no_candidate_with_positive_gain_in_every_period_keeps_control():
    winner, best = choose_stable([candidate("loss", [0.03, -0.01, 0.02]), candidate("tie", [0, 0.01, 0.02])])
    assert winner is None
    assert best["name"] == "tie"


def test_weakest_period_takes_priority_over_pooled_gain():
    winner, _ = choose_stable([candidate("fragile", [0.001, 0.1, 0.1]), candidate("consistent", [0.002] * 3)])
    assert winner["name"] == "consistent"


def test_equal_minimum_gain_uses_case_weighted_pooled_gain():
    a = candidate("a", [0.01, 0.03, 0.01])
    b = candidate("b", [0.03, 0.01, 0.01])
    winner, _ = choose_stable([a, b])
    assert winner["name"] == "a"


def test_phase_fit_excludes_unavailable_labels_without_removing_targets():
    rows = [
        {"date": "2023-10-20T20:00:00Z"},
        {"date": "2023-11-02T20:00:00Z"},
        {"date": "2023-11-03T20:00:00Z"},
        {"date": "2023-12-31T20:00:00Z"},
        {"date": "2024-01-02T16:00:00Z"},
        {"date": "2024-01-04T20:00:00Z"},
        {"date": "2025-12-31T20:00:00Z"},
        {"date": "2026-01-02T20:00:00Z"},
    ]
    phases = phase_masks(rows)
    assert phases["warm2023"]["target"].tolist() == [False, True, True, True, False, False, False, False]
    assert not phases["spring2024"]["fit"][3]
    assert not phases["later2026"]["fit"][6]
    assert phases["later2026"]["target"].sum() == 1
    for phase in phases.values():
        assert not (phase["fit"] & phase["target"]).any()


def test_previous_phase_bank_enforces_lock_and_keeps_zero_scores():
    rows = [{"date": "2025-12-30T20:00:00Z", "score": 0}, {"date": "2025-12-31T20:00:00Z", "score": 100}]
    mask = previous_bank_mask(rows, "2026-01-02T20:00:00Z")
    np.testing.assert_array_equal(mask, [True, False])
