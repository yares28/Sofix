import copy

import numpy as np
import pytest

from app.research.score_style import style_features


def source_game(date, gid, passes=20):
    players = {}
    xi = {}
    for side in ("home", "away"):
        slugs = ["player" if side == "home" and i == 0 else f"{side}{i}" for i in range(11)]
        xi[side] = {"available": True, "start": [slugs[:1], slugs[1:5], slugs[5:8], slugs[8:]], "bench": []}
        for slug in slugs:
            players[slug] = {
                "played": True,
                "started": True,
                "ver": 7,
                "pos": "MID",
                "mins": 90,
                "team": side,
                "stats": {"accurate_pass": [passes, 0.4]},
                "aa": 0.4,
                "score": 35.4,
            }
    return {"id": gid, "date": date, "home": {"slug": "home"}, "away": {"slug": "away"}, "players": players, "xi": xi}


def row(g, player="player"):
    return {"game": g["id"], "player": player, "date": g["date"], "cohort": "start", "pos": "MID"}


def test_current_and_same_week_actions_cannot_change_style_or_role_features():
    past = source_game("2025-09-20T18:00:00Z", "past")
    same = source_game("2025-10-11T18:00:00Z", "same")
    target = source_game("2025-10-12T18:00:00Z", "target")
    before = style_features([past, same, target], [row(target)])
    changed = copy.deepcopy(same)
    changed["players"]["player"].update(mins=1, stats={"accurate_pass": [900, 18]})
    target["xi"]["home"]["start"] = [["player"]]
    after = style_features([past, changed, target], [row(target)])
    np.testing.assert_array_equal(before[0], after[0])
    assert before[0][0, before[1].index("team_3_accurate_pass")] == 220


def test_no_history_is_missing_and_cold_start_case_is_kept():
    target = source_game("2025-10-12T18:00:00Z", "target")
    x, names, _ = style_features([target], [row(target)])
    assert len(x) == 1
    assert x[0, names.index("team_history_count")] == 0
    assert np.isnan(x[0, names.index("team_3_accurate_pass")])


def test_missing_action_sheet_does_not_become_zero_team_volume():
    past = source_game("2025-09-20T18:00:00Z", "past")
    past["players"]["player"]["stats"] = None
    target = source_game("2025-10-12T18:00:00Z", "target")
    x, names, receipt = style_features([past, target], [row(target)])
    assert receipt["incompleteGames"] == 1
    assert np.isnan(x[0, names.index("team_3_accurate_pass")])
    assert x[0, names.index("team_incomplete_28")] == 1


def test_backwards_rows_cannot_read_future_team_history():
    past = source_game("2025-09-20T18:00:00Z", "past")
    target = source_game("2025-10-12T18:00:00Z", "target")
    with pytest.raises(ValueError, match="chronological"):
        style_features([past, target], [row(target), row(past)])


def test_known_zero_team_actions_stay_zero():
    past = source_game("2025-09-20T18:00:00Z", "past", passes=0)
    target = source_game("2025-10-12T18:00:00Z", "target")
    x, names, receipt = style_features([past, target], [row(target)])
    assert x.shape == (1, len(names))
    assert receipt["incompleteGames"] == 0
    assert x[0, names.index("team_3_accurate_pass")] == 0
