"""Testing only: past-player involvement as a bounded share of team goals."""

from __future__ import annotations

import numpy as np

from app.research.score_event_probability import event_probabilities as event_probabilities
from app.research.score_event_probability import forecast_policy as forecast_policy

MODELS = {
    f"{group}_{label}": (group, blend)
    for group in ("history", "quality")
    for label, blend in (("half", 0.5), ("full", 1.0))
}


def team_share_rates(event, event_names, matchups, matchup_names, own_lambda, model):
    if model not in MODELS:
        raise ValueError("Unknown team-share model")
    event, matchups, own_lambda = np.asarray(event), np.asarray(matchups), np.asarray(own_lambda, dtype=float)
    if event.ndim != 2 or matchups.ndim != 2 or len(matchups) != len(event) or own_lambda.shape != (len(event),):
        raise ValueError("Team-share input shapes differ")
    group, blend = MODELS[model]
    e = lambda name: event[:, event_names.index(name)]
    m = lambda name: matchups[:, matchup_names.index(name)]
    old, negative = e("event_mu_" + group), e("event_mu_negative")
    if not np.isfinite([old, negative]).all() or (old < 0).any() or (negative < 0).any():
        raise ValueError("Original finite nonnegative event intensities required")
    minutes = e("event_expected_minutes")
    goal, assist = e("event_goal_" + group + "90"), e("event_assist_" + group + "90")
    other = e("event_other_history90")
    exposure = m("teammates_exposure")
    team_goal, team_assist = m("teammates_total_goals"), m("teammates_total_goal_assist")
    inputs = np.column_stack((minutes, goal, assist, other, exposure, team_goal, team_assist, own_lambda))
    eligible = (
        np.isfinite(inputs).all(axis=1)
        & (inputs >= 0).all(axis=1)
        & (minutes >= 1)
        & (minutes <= 90)
        & (exposure > 0)
        & (m("own_known_games") > 0)
        & (m("teammates_recent_games") > 0)
        & (m("teammates_known_fraction") >= 1)
    )
    scale = np.divide(990 - minutes, exposure, out=np.zeros(len(event)), where=exposure > 0)
    own_goal, own_assist = minutes / 90 * goal, minutes / 90 * assist
    denominator = np.maximum(own_goal + team_goal * scale, own_assist + team_assist * scale)
    eligible &= denominator > 0
    raw_share = np.divide(own_goal + own_assist, denominator, out=np.zeros(len(event)), where=eligible)
    share = np.clip(raw_share, 0, 1)
    proposed = own_lambda * share + minutes / 90 * other
    result = np.column_stack((np.where(eligible, (1 - blend) * old + blend * proposed, old), negative))
    if not np.isfinite(result).all() or (result < 0).any():
        raise ValueError("Team-share result lost finite forecast cases")
    return result, {
        "target": len(event),
        "eligible": int(eligible.sum()),
        "fallback": int((~eligible).sum()),
        "shareCapped": int((eligible & (raw_share > 1)).sum()),
        "goalAssistBoundViolations": int((eligible & (own_lambda * share > own_lambda)).sum()),
        "noEventLabelsUsed": True,
    }
