import numpy as np
import pytest

from app.research.score_ordinary import aa_design, activity_features, fit_ordinary, rate_targets, scoped_prediction


def test_rate_targets_use_training_exposure_without_turning_missing_minutes_to_zero():
    target, weight = rate_targets(np.array([10.0, 2, -1]), np.array([90.0, 9, 1]))
    np.testing.assert_allclose(target, [10, 20, -90])
    np.testing.assert_allclose(weight, [1, 0.1, 1 / 90])


def test_only_minute_conditional_modes_receive_minutes_as_a_predictor():
    x = np.array([[1.0, 2], [3, 4]])
    low_minutes = np.array([10.0, 20])
    high_minutes = np.array([80.0, 90])
    levels = np.array([35, 60])
    for mode in ("direct", "rate"):
        np.testing.assert_array_equal(aa_design(x, low_minutes, levels, mode), aa_design(x, high_minutes, levels, mode))
    a = aa_design(x, low_minutes, levels, "minutes")
    b = aa_design(x, high_minutes, levels, "minutes")
    np.testing.assert_array_equal(a[:, -2], low_minutes)
    np.testing.assert_array_equal(b[:, -2], high_minutes)
    np.testing.assert_array_equal(a[:, -1], levels)


def test_defender_midfielder_policy_keeps_every_other_position_and_case():
    old = np.array([40.0, 41, 42, 43])
    new = np.array([60.0, 61, 62, 63])
    prediction = scoped_prediction(new, old, np.array(["GK", "DEF", "MID", "FWD"]), "defmid")
    np.testing.assert_array_equal(prediction, [40, 61, 62, 43])
    np.testing.assert_array_equal(scoped_prediction(new, old, np.array(["GK", "DEF", "MID", "FWD"]), "all"), new)


def test_possession_adjustment_preserves_missingness_and_increases_defensive_work():
    x = np.array([[60.0, 40, 50, 10, 5, 80, 70], [np.nan, 40, 50, 10, 5, 80, 70]])
    names = [
        "own_10_possession_mean",
        "opponent_10_possession_mean",
        "counts_same_10_accurate_pass",
        "counts_same_10_duel_won",
        "counts_same_10_won_tackle",
        "same_3_usage_pass_x_mean",
        "same_10_usage_pass_x_mean",
    ]
    values, labels = activity_features(x, names)
    assert values[0, labels.index("role_depth_change")] == 10
    assert values[0, labels.index("adjusted_passes90")] == 50
    assert np.isnan(values[1, labels.index("adjusted_passes90")])
    changed = x.copy()
    changed[0, 1] = 60
    other, _ = activity_features(changed, names)
    assert other[0, labels.index("adjusted_passes90")] < values[0, labels.index("adjusted_passes90")]
    assert other[0, labels.index("adjusted_duels90")] > values[0, labels.index("adjusted_duels90")]


def test_minutes_artifact_cannot_be_read_as_ordinary_point_components(tmp_path):
    path = tmp_path / "forecast.npz"
    np.savez_compressed(path, key="same-key", minutes=np.array([80.0]))
    base = (np.array([35]), np.ones((1, 1)), {})
    with pytest.raises(ValueError, match="ordinary-point artifact"):
        fit_ordinary(None, [], None, None, None, None, None, None, None, base, "minutes", path, "same-key")
