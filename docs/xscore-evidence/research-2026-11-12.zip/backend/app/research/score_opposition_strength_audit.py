"""Reconstruct the opposition experiment from raw histories, then score frozen duel forecasts."""

import hashlib
import json
import sys
from collections import defaultdict
from datetime import UTC, datetime, timedelta
from pathlib import Path

import numpy as np

from app.research import score_opposition_strength as study
from app.research.score_physical_duel_signal import interval, losses

ROOT = Path("data/raw/score-foundation")
REPORT = Path("reports/experiments/laliga_score_opposition_strength.json")
RAW = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
POSITION = {"DEF": 0, "MID": 1, "FWD": 2}


def clock(iso):
    kickoff = datetime.fromisoformat(iso).astimezone(UTC)
    tick = kickoff.replace(hour=14, minute=0, second=0, microsecond=0)
    while tick > kickoff or tick.weekday() not in (1, 4):
        tick -= timedelta(days=1)
    return tick, kickoff + timedelta(days=2)


def sides(game):
    return game["home"]["slug"], game["away"]["slug"]


def participants(game):
    home, away = sides(game)
    result = {home: {}, away: {}}
    started = {home: 0, away: 0}
    for name, p in game["players"].items():
        if p.get("played") is not True:
            continue
        club, pos, mins = p["team"], p["pos"], p["mins"]
        assert club in result and pos in ("GK", *POSITION)
        assert p["ver"] == 7 and isinstance(p["stats"], dict) and type(p["started"]) is bool
        assert np.isfinite(mins) and mins >= 0
        started[club] += p["started"]
        if pos == "GK":
            continue
        pair = tuple(p["stats"].get(k, [0])[0] for k in ("duel_won", "duel_lost"))
        assert all(int(x) == x and x >= 0 for x in pair)
        result[club][name] = (pos, mins, p["started"], pair)
    assert started == {home: 11, away: 11}
    assert all(sum(v[1] for v in members.values()) > 0 for members in result.values())
    return result


def coeffs(player, pos, home, starter, members, people, joint):
    if pos == "GK":
        return {}
    values = {POSITION[pos] + (0 if starter else 3): 1, 6: int(home)}
    if player in people:
        values[people[player]] = 1
    if joint and members:
        weights = {
            name: minutes / (0.25 + 0.4 * abs(POSITION[pos] + POSITION[other] - 2))
            for name, (other, minutes) in members.items()
        }
        total = sum(weights.values())
        assert total > 0
        for name, weight in weights.items():
            if name in people:
                idx = people[name]
                values[idx] = values.get(idx, 0) - weight / total
    return values


def audit():
    from scipy.sparse import coo_matrix
    from scipy.special import expit

    report = json.loads(REPORT.read_text())
    source = json.loads((ROOT / "cases.json").read_text())
    rows = source["rows"]
    raw = RAW.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == report["nativeSHA"] == study.NATIVE_SHA
    assert len(rows) == 38850 and source["key"] == report["sourceKey"]
    games = {g["id"]: g for g in map(json.loads, raw.splitlines())}
    assert len(games) == 1238
    ordered = sorted(games.values(), key=lambda g: (g["date"], g["id"]))
    membership = {}
    club_games = defaultdict(list)
    availability = {g["id"]: clock(g["date"])[1] for g in ordered}
    for g in ordered:
        for club in sides(g):
            club_games[club].append(g["id"])

    def historical(game):
        if game not in membership:
            membership[game] = participants(games[game])
        return membership[game]

    with np.load(ROOT / "matchup_features.npz") as z:
        assert str(z["key"]) == report["matchupKey"]
        names = z["names"].tolist()
        rate = z["x"][:, names.index("own_duel_won90")] + z["x"][:, names.index("own_duel_lost90")]
    control_columns = {n: i for i, n in enumerate(source["features"])}
    results = {}
    for phase, begin, end in study.PHASES:
        saved = report["periods"][phase]
        path = Path(saved["artifact"])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == saved["artifactSHA"]
        with np.load(path) as z:
            vectors = dict(z)
        assert str(vectors["key"]) == report["implementationKey"]
        mask = np.array([begin <= r["date"] < end for r in rows])
        np.testing.assert_array_equal(mask, vectors["selected"])
        target = [r for r, selected in zip(rows, mask, strict=True) if selected]
        first = min(clock(r["date"])[0] for r in target)
        train = [g for g in ordered if g["date"] < begin and availability[g["id"]] < first]
        train_rows = []
        for g in train:
            h, a = sides(g)
            m = historical(g["id"])
            for own, opp in ((h, a), (a, h)):
                exposure = {p: v[:2] for p, v in m[opp].items()}
                train_rows.extend((g["id"], p, v[0], own == h, v[2], exposure, v[3]) for p, v in m[own].items())
        np.testing.assert_array_equal(vectors["training_game"], [r[0] for r in train_rows])
        np.testing.assert_array_equal(vectors["training_player"], [r[1] for r in train_rows])
        names = sorted({r[1] for r in train_rows})
        np.testing.assert_array_equal(vectors["players"], names)
        people = {name: i + 7 for i, name in enumerate(names)}
        target_rows, known = [], []
        for r in target:
            h, a = sides(games[r["game"]])
            assert games[r["game"]]["date"] == r["date"]
            home = r["x"][control_columns["home"]] == 1
            lock = clock(r["date"])[0]
            opp = a if home else h
            eligible = [g for g in club_games[opp] if availability[g] < lock][-3:]
            known.append(len(eligible))
            minutes, position = defaultdict(float), {}
            for g in eligible:
                for name, (pos, played, _, _) in historical(g)[opp].items():
                    minutes[name] += played
                    position[name] = pos
            exposure = {name: (position[name], mins / len(eligible)) for name, mins in minutes.items()}
            target_rows.append((r["game"], r["player"], r["pos"], home, r["cohort"] == "start", exposure, None))
        np.testing.assert_array_equal(vectors["known_games"], known)

        def matrix(records, people, joint):
            triples = [
                (i, j, v)
                for i, (_, p, pos, home, starter, exposure, _) in enumerate(records)
                for j, v in coeffs(p, pos, home, starter, exposure, people, joint).items()
            ]
            i, j, v = zip(*triples, strict=True)
            return coo_matrix((v, (i, j)), shape=(len(records), len(people) + 7)).tocsr()

        counts = np.array([r[-1] for r in train_rows])
        for arm, joint in (("baseline", False), ("opposition", True)):
            beta = vectors[arm + "_beta"]
            x = matrix(train_rows, people, joint)
            z = x @ beta
            fitted_loss = np.dot(counts.sum(axis=1), np.logaddexp(0, z)) - np.dot(counts[:, 0], z)
            fitted_loss += 0.005 * np.sum(beta[:7] ** 2) + 2.5 * np.sum(beta[7:] ** 2)
            np.testing.assert_allclose(fitted_loss, saved["solvers"][arm]["objective"], rtol=1e-13)
            predicted = expit(matrix(target_rows, people, joint) @ beta)
            np.testing.assert_allclose(predicted, vectors[arm], rtol=0, atol=2e-15)
        projected = rate[mask] * [r["x"][control_columns[r["cohort"] + "_3_minutes"]] for r in target] / 90
        np.testing.assert_array_equal(projected, vectors["projected_duels"])
        points = projected * (vectors["opposition"] - vectors["baseline"]) * 3.5
        np.testing.assert_allclose(points, vectors["point_shift"], rtol=0, atol=1e-14)
        # Remove every participant sheet at or after the phase's first lock availability.
        first_rows = [r for r in target if clock(r["date"])[0] == first]
        mutated = [dict(g, players={}) if availability[g["id"]] >= first else g for g in ordered]
        assert study.projections(first_rows, ordered, source["features"]) == study.projections(
            first_rows, mutated, source["features"]
        )
        results[phase] = (target, vectors)
        print(phase, len(train_rows), len(target), "independently verified", flush=True)
    proof = dict(
        implementationKey=report["implementationKey"],
        forecastCases=sum(len(r) for r, _ in results.values()),
        trainingAndForecastDesignsVerified=6,
        phaseFirstLockFutureParticipantRemovalChecks=3,
        targetProbabilityTolerance=2e-15,
        pointTolerance=1e-14,
        scoreLabelsAccessed=False,
    )
    REPORT.with_suffix(".integrity.json").write_text(json.dumps(proof, indent=2) + "\n")
    return proof, results, games


def signal(proof, results, games):
    plan = REPORT.with_suffix(".signal.plan.json")
    evidence = dict(
        implementationKey=proof["implementationKey"],
        planSHA=hashlib.sha256(plan.read_bytes()).hexdigest(),
        cohorts={},
        later2026Evaluated=False,
    )
    for cohort in ("start", "bench"):
        periods, pooled = {}, defaultdict(list)
        for phase, (rows, vectors) in results.items():
            keep = np.array([r["cohort"] == cohort for r in rows])
            selected = [r for r, yes in zip(rows, keep, strict=True) if yes]
            counts = []
            for r in selected:
                p = games[r["game"]]["players"][r["player"]]
                assert p["pos"] == r["pos"] and p["started"] == (cohort == "start") and p["played"] is True
                assert p["ver"] == 7 and isinstance(p["stats"], dict)
                counts.append(
                    [p["stats"].get(k, [0])[0] for k in ("duel_won", "duel_lost")]
                    if r["pos"] != "GK"
                    else [np.nan, np.nan]
                )
            count = np.array(counts, float)
            old, new = vectors["baseline"][keep], vectors["opposition"][keep]
            outfield = np.array([r["pos"] != "GK" for r in selected])
            primary = np.array([r["pos"] == "DEF" for r in selected]) if cohort == "start" else outfield
            before, after = losses(count, old, primary), losses(count, new, primary)
            periods[phase] = dict(
                cases=len(selected),
                baseline=before,
                opposition=after,
                brierGain=before["brier"] - after["brier"],
                logLossGain=before["logloss"] - after["logloss"],
            )
            for key, value in dict(
                count=count, old=old, new=new, primary=primary, outfield=outfield, weeks=[r["week"] for r in selected]
            ).items():
                pooled[key].append(value)
        count, old, new, primary, outfield, weeks = (
            np.concatenate(pooled[k]) for k in ("count", "old", "new", "primary", "outfield", "weeks")
        )
        bounds = interval(count, old, new, weeks, primary)
        all_gain = losses(count, old, outfield)["brier"] - losses(count, new, outfield)["brier"]
        gate = dict(
            allPeriodsImprove=all(p["brierGain"] > 0 and p["logLossGain"] > 0 for p in periods.values()),
            pooledIntervalAboveZero=bounds[0] > 0,
            allOutfieldNonworse=all_gain >= 0,
        )
        evidence["cohorts"][cohort] = dict(
            periods=periods,
            pooledPrimaryBrierGainInterval=bounds,
            pooledOutfieldBrierGain=all_gain,
            gate=gate,
            passed=all(gate.values()),
        )
    REPORT.with_suffix(".signal.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: dict(passed=v["passed"], gate=v["gate"], interval=v["pooledPrimaryBrierGainInterval"])
                for k, v in evidence["cohorts"].items()
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    signal(*audit())
