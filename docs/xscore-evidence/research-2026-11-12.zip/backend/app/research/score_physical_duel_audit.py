"""Independent raw duel signal inputs, periods, metrics and actual blinded refits."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sys
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from functools import cache
from pathlib import Path

import numpy as np

from app.research import score_physical_duel_signal as study
from app.research.score_search import cutoff_for, moment


def raw_baseline(rows, games, roles):
    events = ("duel_won", "duel_lost", "won_contest", "won_tackle")
    depth_default = dict(GK=0.0, DEF=0.2, MID=0.6, FWD=1.0)
    rolemap = {(r["game"], r["player"]): r["values"] for r in roles}
    people, teams, population = defaultdict(list), defaultdict(list), defaultdict(list)
    for g in sorted(games.values(), key=lambda g: (g["date"], g["id"])):
        t = moment(g["date"]) + timedelta(hours=48)
        clubs = {g[s]["slug"]: [] for s in ("home", "away")}
        for player, p in g["players"].items():
            m = p.get("mins")
            if (
                p.get("played") is not True
                or p.get("pos") not in depth_default
                or p.get("team") not in clubs
                or type(m) not in (int, float)
                or not np.isfinite(m)
                or m < 0
            ):
                continue
            good = p.get("ver") == 7 and isinstance(p.get("stats"), dict)
            counts = np.array([p["stats"].get(e, [0, 0])[0] for e in events]) if good else None
            item = dict(t=t, team=p["team"], minutes=m, counts=counts, role=rolemap.get((g["id"], player)))
            people[player].append(item)
            clubs[p["team"]].append((player, m, p["pos"]))
            if good and m > 0:
                population[p["pos"]].append(item)
        for club, members in clubs.items():
            teams[club].append((t, members))
    pt = {p: [r["t"] for r in rs] for p, rs in people.items()}
    tt = {c: [r[0] for r in rs] for c, rs in teams.items()}
    rt = {p: [r["t"] for r in rs] for p, rs in population.items()}
    cumulative = {
        p: np.vstack((np.zeros(5), np.cumsum([[*r["counts"], r["minutes"]] for r in rs], axis=0)))
        for p, rs in population.items()
    }

    @cache
    def player_profile(player, club, pos, lock):
        end = bisect_left(pt.get(player, []), lock)
        history = [r for r in people.get(player, [])[:end] if r["t"] >= lock - timedelta(days=365)]
        same = [r for r in history if r["team"] == club]
        selected = (same or history)[-10:]
        good = [r for r in selected if r["counts"] is not None and r["minutes"] > 0]
        counts = sum((r["counts"] for r in good), np.zeros(4))
        minutes = sum(r["minutes"] for r in good)
        prior = cumulative[pos][bisect_left(rt[pos], lock)] if pos in cumulative else np.zeros(5)
        rate = (
            (counts + 300 * prior[:4] / prior[4]) * 90 / (minutes + 300)
            if prior[4] > 0
            else counts * 90 / minutes
            if minutes
            else np.full(4, np.nan)
        )
        selected_roles = [r["role"] for r in selected[-3:] if r["role"] is not None]
        depths = [r["usage_role_depth"] for r in selected_roles if r.get("usage_role_depth") is not None]
        edges = [abs(r["usage_role_edge"]) for r in selected_roles if r.get("usage_role_edge") is not None]
        return dict(
            rate=rate,
            known=len(good),
            depth=float(np.mean(depths)) if depths else depth_default[pos],
            edge=float(np.mean(edges)) if edges else np.nan,
            prior=prior[0] / sum(prior[:2]) if sum(prior[:2]) > 0 else np.nan,
        )

    @cache
    def club_profile(club, lock):
        end = bisect_left(tt.get(club, []), lock)
        recent = teams.get(club, [])[:end][-3:]
        exposure, position = defaultdict(float), {}
        for _, members in recent:
            for player, minutes, pos in members:
                exposure[player] += minutes / len(recent)
                position[player] = pos
        return [(player_profile(p, club, position[p], lock), w) for p, w in exposure.items()], len(recent)

    output = []
    for row in rows:
        g, lock = games[row["game"]], cutoff_for(row["date"])
        club = g["players"][row["player"]]["team"]
        opponent = g["away"]["slug"] if club == g["home"]["slug"] else g["home"]["slug"]
        own = player_profile(row["player"], club, row["pos"], lock)
        members, n = club_profile(opponent, lock)
        values, weights, priors, duel_weights = [], [], [], []
        for person, exposure in members:
            w = exposure / (0.25 + abs(own["depth"] + person["depth"] - 1.2))
            if np.isfinite(own["edge"]) and np.isfinite(person["edge"]):
                w *= 0.5 + 1 / (1 + abs(own["edge"] - person["edge"]))
            values.append(person["rate"][:2])
            weights.append(w)
            priors.append(person["prior"])
            duel_weights.append(w * sum(person["rate"][:2]))
        v = np.array(values).reshape(-1, 2)
        w = np.array(weights)
        matched = []
        for j in range(2):
            good = np.isfinite(v[:, j])
            matched.append(np.dot(v[good, j], w[good]) / w[good].sum() if w[good].sum() > 0 else np.nan)
        prior, dw = np.array(priors), np.array(duel_weights)
        good = np.isfinite(prior) & np.isfinite(dw)
        b = np.dot(prior[good], dw[good]) / dw[good].sum() if dw[good].sum() > 0 else np.nan
        a = own["rate"][0] / sum(own["rate"][:2]) if sum(own["rate"][:2]) > 0 else np.nan
        o = matched[0] / sum(matched) if sum(matched) > 0 else np.nan
        expected = np.nan
        if np.isfinite([a, o, b]).all():
            aa, oo, bb = np.clip([a, o, b], 1e-5, 1 - 1e-5)
            odds = aa / (1 - aa) / (oo / (1 - oo)) * (bb / (1 - bb))
            expected = odds / (1 + odds)
        output.append(
            [
                own["known"],
                own["depth"],
                own["edge"],
                own["rate"][0],
                own["rate"][1],
                own["rate"][2],
                own["rate"][3],
                n,
                a,
                o,
                b,
                expected,
            ]
        )
    return np.array(output)


def metrics(counts, probabilities, selected):
    valid = selected & np.isfinite(counts).all(axis=1) & (np.nansum(counts, axis=1) > 0)
    wins, losses = counts[valid].T
    p = np.clip(probabilities[valid], 1e-12, 1 - 1e-12)
    total = sum(wins + losses)
    return dict(
        cases=int(sum(selected)),
        positiveDuelCases=int(sum(valid)),
        duels=int(total),
        wins=int(sum(wins)),
        brier=float(sum(wins * (1 - p) ** 2 + losses * p**2) / total),
        logloss=float(-sum(wins * np.log(p) + losses * np.log(1 - p)) / total),
    )


def compare_dict(actual, expected):
    if set(actual) != set(expected):
        raise ValueError("Independent metric schema differs")
    for k, value in expected.items():
        np.testing.assert_allclose(actual[k], value, rtol=0, atol=1e-11)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_physical_duel_signal.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, inputs, counts, provenance = study.load_inputs(args)
    report = json.loads(args.out.read_text())
    key = hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + sklearn.__version__).encode()
        + Path(study.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if key != report["implementationKey"] or report["provenance"] != provenance:
        raise ValueError("Frozen source/plan/model implementation identity differs")
    games = {g["id"]: g for g in (json.loads(line) for line in args.games.read_text().splitlines() if line.strip())}
    independently_counted = []
    for row in source["rows"]:
        person = games[row["game"]]["players"][row["player"]]
        independently_counted.append(
            [person["stats"].get(k, [0, 0])[0] for k in ("duel_won", "duel_lost")]
            if row["pos"] != "GK"
            else [np.nan, np.nan]
        )
    np.testing.assert_array_equal(counts, independently_counted)
    roles = json.loads(gzip.decompress((args.cache / "player_context_observations.json.gz").read_bytes()))["records"]
    reconstructed = raw_baseline(source["rows"], games, roles)
    for j, field in enumerate(study.MATCHUP_FIELDS):
        if field.endswith("90") or field.endswith("games"):
            reconstructed[:, j] = np.log1p(reconstructed[:, j])
    np.testing.assert_allclose(inputs["baseline"][:, :12], reconstructed, rtol=0, atol=1e-10, equal_nan=True)
    original = np.array([r["x"] for r in source["rows"]])
    np.testing.assert_array_equal(
        inputs["baseline"][:, 12:16],
        original[:, [source["features"].index(n) for n in ("home", "position_DEF", "position_MID", "position_FWD")]],
    )
    with np.load(args.cache / "physical_trait_features.npz") as f:
        np.testing.assert_array_equal(inputs["baseline"][:, 16:18], f["x"][:, 30:32])
        np.testing.assert_array_equal(inputs["physical"][:, 18:], f["x"][:, :20])
    checked = refits = 0
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        c = counts[keep]
        pooled = {a: dict(counts=[], old=[], new=[], week=[], defense=[]) for a in ("logistic", "nonlinear")}
        gains = {a: [] for a in pooled}
        for phase, begin, end in (
            ("spring2024", "2024-01-01", "2024-07-01"),
            ("season2024", "2024-07-01", "2025-07-01"),
            ("autumn2025", "2025-07-01", "2026-01-01"),
        ):
            target = np.array([begin <= r["date"] < end for r in rows])
            lock = min(cutoff_for(r["date"]) for r, yes in zip(rows, target, strict=True) if yes)
            fit = np.array([r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
            blinded = c.copy()
            blinded[~fit] = np.nan
            usable = fit & np.isfinite(blinded).all(axis=1) & (np.nansum(blinded, axis=1) > 0)
            defense = np.array([r["pos"] == "DEF" for r, yes in zip(rows, target, strict=True) if yes])
            groups = dict(
                primary=defense if cohort == "start" else np.ones(sum(target), bool),
                allOutfield=np.ones(sum(target), bool),
                defender=defense,
            )
            phase_report = report["cohorts"][cohort]["periods"][phase]
            if (
                phase_report["fit"] != sum(fit)
                or phase_report["target"] != sum(target)
                or phase_report["firstLock"] != lock.isoformat()
            ):
                raise ValueError("Independent chronological masks differ")
            for architecture in pooled:
                predictions = {}
                for arm, full_x in inputs.items():
                    x = full_x[keep]
                    path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{architecture}_{arm}.npz"
                    with np.load(path) as f:
                        if str(f["key"]) != key:
                            raise ValueError("Native probability artifact identity differs")
                        np.testing.assert_array_equal(f["fit"], fit)
                        np.testing.assert_array_equal(f["target"], target)
                        np.testing.assert_array_equal(f["actual"], c[target])
                        np.testing.assert_array_equal(f["usable"], usable)
                        p = f["probability"].copy()
                        if architecture == "logistic":
                            median = np.array(
                                [
                                    np.median(col[np.isfinite(col)]) if np.isfinite(col).any() else 0.0
                                    for col in x[usable].T
                                ]
                            )
                            complete = np.where(np.isfinite(x), x, median)
                            mean, scale = complete[usable].mean(axis=0), complete[usable].std(axis=0)
                            scale[scale <= 1e-8] = 1
                            z = np.column_stack(((complete - mean) / scale, ~np.isfinite(x)))
                            for name, value in (("median", median), ("mean", mean), ("scale", scale)):
                                np.testing.assert_array_equal(f[name], value)
                            eta = z[target] @ f["coefficient"] + float(f["intercept"])
                            np.testing.assert_allclose(p, 1 / (1 + np.exp(-eta)), rtol=0, atol=1e-12)
                            model = LogisticRegression(
                                C=1, solver="lbfgs", max_iter=2000, tol=1e-8, random_state=20261106
                            )
                        else:
                            z = x
                            model = HistGradientBoostingClassifier(
                                max_iter=120,
                                max_leaf_nodes=7,
                                min_samples_leaf=80,
                                learning_rate=0.06,
                                l2_regularization=10,
                                early_stopping=False,
                                random_state=20261106,
                            )
                    xx = np.concatenate([z[usable], z[usable]])
                    yy = np.repeat([1.0, 0.0], sum(usable))
                    weights = np.concatenate([blinded[usable, 0], blinded[usable, 1]])
                    positive = weights > 0
                    model.fit(xx[positive], yy[positive], sample_weight=weights[positive])
                    np.testing.assert_array_equal(p, model.predict_proba(z[target])[:, 1])
                    for group, mask in groups.items():
                        compare_dict(
                            phase_report["models"][architecture]["metrics"][arm][group], metrics(c[target], p, mask)
                        )
                    predictions[arm] = p
                    checked += 1
                    refits += 1
                old, new = (metrics(c[target], predictions[a], groups["primary"]) for a in ("baseline", "physical"))
                gain = dict(logloss=old["logloss"] - new["logloss"], brier=old["brier"] - new["brier"])
                compare_dict(phase_report["models"][architecture]["primaryImprovement"], gain)
                gains[architecture].append(gain)
                p = pooled[architecture]
                p["counts"].extend(c[target])
                p["old"].extend(predictions["baseline"])
                p["new"].extend(predictions["physical"])
                p["week"].extend(r["week"] for r, yes in zip(rows, target, strict=True) if yes)
                p["defense"].extend(defense)
                print(f"PHYSICAL_DUEL_REFIT {cohort}/{phase}/{architecture}", flush=True)
        for architecture, values in pooled.items():
            c0, old, new, defense = (np.array(values[k]) for k in ("counts", "old", "new", "defense"))
            primary = defense if cohort == "start" else np.ones(len(c0), bool)
            rr = report["cohorts"][cohort]["pooled"][architecture]
            for arm, p in (("baseline", old), ("physical", new)):
                for group, mask in dict(primary=primary, allOutfield=np.ones(len(c0), bool), defender=defense).items():
                    compare_dict(rr["metrics"][arm][group], metrics(c0, p, mask))
            group_totals = defaultdict(lambda: [0.0, 0.0])
            for pair, a, b, week, chosen in zip(c0, old, new, values["week"], primary, strict=True):
                if chosen and np.isfinite(pair).all() and sum(pair) > 0:
                    w, lost = pair
                    group_totals[week][0] += w * ((1 - a) ** 2 - (1 - b) ** 2) + lost * (a * a - b * b)
                    group_totals[week][1] += w + lost
            totals = np.array([group_totals[k] for k in sorted(group_totals)])
            draws = np.random.default_rng(20261106).integers(len(totals), size=(2000, len(totals)))
            samples = totals[draws].sum(axis=1)
            bounds = np.quantile(samples[:, 0] / samples[:, 1], [0.025, 0.975])
            np.testing.assert_allclose(rr["primaryBrierGain95"], bounds, rtol=0, atol=1e-12)
            consistent = all(g["brier"] > 0 and g["logloss"] > 0 for g in gains[architecture])
            all_gain = (
                metrics(c0, old, np.ones(len(c0), bool))["brier"] - metrics(c0, new, np.ones(len(c0), bool))["brier"]
            )
            if rr["allThreeEarlierPeriodsImprove"] != consistent or rr["passesSignalGate"] != (
                consistent and bounds[0] > 0 and all_gain >= 0
            ):
                raise ValueError("Independent earlier mechanism disposition differs")
        if report["cohorts"][cohort]["passesAnySignalGate"] != any(
            v["passesSignalGate"] for v in report["cohorts"][cohort]["pooled"].values()
        ):
            raise ValueError("Cohort gate differs")
    receipt = dict(
        implementationKey=key,
        nativeCasesVerified=38850,
        independentBaselineColumns=18,
        independentlyVerifiedAddedPhysicalColumns=20,
        nativeProbabilityVectors=checked,
        actualBlindedFullModelRefits=refits,
        chronologicalMasksVerified=6,
        later2026FittedOrEvaluated=False,
        status="COMPLETE independent source/inputs/labels/masks/losses/bootstrap/24actualblindedrefits audit",
    )
    args.out.with_suffix(".integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("PHYSICAL_DUEL_AUDIT " + json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
