"""Testing only: retained European team facts never fabricate XI or censored native AA."""

from collections import Counter

import numpy as np

from app.research import score_europe_shape_history as history


def game():
    players = ["gk", *[f"p{i}" for i in range(10)]]
    lines = [
        [dict(slug="gk")],
        [dict(slug=p) for p in players[1:5]],
        [dict(slug=p) for p in players[5:8]],
        [dict(slug=p) for p in players[8:]],
    ]
    return dict(
        id="g",
        date="2024-01-01T12:00:00Z",
        statusTyped="played",
        homeTeam=dict(slug="a"),
        awayTeam=dict(slug="b"),
        homeFormation=dict(startingLineupAvailable=True, startingLineup=lines, bench=[dict(slug="sub")]),
        awayFormation={},
        playerGameScores=[
            dict(
                anyPlayer=dict(slug=p),
                positionTyped="Goalkeeper" if p == "gk" else "Defender",
                scoringVersion=5,
                anyPlayerGameStats=dict(playedInGame=True, minsPlayed=90, gameStarted=1, anyTeam=dict(slug="a")),
            )
            for p in players
        ],
    )


def test_europe_shape_verifies_native_playing_facts_without_using_v5_scorepoints():
    g = game()
    receipt = Counter()
    records = history.euro_team_records(g, {}, receipt)
    own = next(r for r in records if r["club"] == "a")
    assert len(own["xi"]) == 11 and own["shape"] == (4, 3, 3)
    assert own["labels"] == []
    g["playerGameScores"][0]["anyPlayerGameStats"]["playedInGame"] = None
    own = history.euro_team_records(g, {}, Counter())[0]
    assert own["xi"] is None and own["shape"] is None


def test_europe_shape_missing_flag_can_use_complete_past_xi_but_zero_or_conflict_cannot():
    g = game()
    g["playerGameScores"][0]["anyPlayerGameStats"]["gameStarted"] = None
    assert history.euro_team_records(g, {}, Counter())[0]["xi"] is not None
    g["playerGameScores"][0]["anyPlayerGameStats"]["gameStarted"] = 0
    assert history.euro_team_records(g, {}, Counter())[0]["xi"] is None


def test_europe_shape_missing_published_xi_and_conflicting_native_facts_remain_unknown():
    g = game()
    g["homeFormation"]["startingLineupAvailable"] = False
    g["playerGameScores"][0]["anyPlayerGameStats"]["gameStarted"] = None
    assert history.euro_team_records(g, {}, Counter())[0]["xi"] is None
    g = game()
    duplicate = {**g["playerGameScores"][0], "positionTyped": "Defender"}
    g["playerGameScores"].append(duplicate)
    assert history.euro_team_records(g, {}, Counter())[0]["xi"] is None
    g = game()
    g["playerGameScores"][0]["anyPlayerGameStats"]["minsPlayed"] = 0
    assert history.euro_team_records(g, {}, Counter())[0]["xi"] is None


def test_europe_shape_exact_v7_zero_kept_and_censored_or_unknown_cohort_aa_not_fabricated():
    g = game()

    def label(player, kind, cohort="start", point=0):
        return dict(
            game="g",
            player=player,
            club="a",
            pos="DEF",
            cohort=cohort,
            source="euro",
            ordinary=dict(kind=kind, point=point),
        )

    labels = {
        ("g", "p0"): label("p0", "exact"),
        ("g", "p1"): label("p1", "upper", point=None),
        ("g", "p2"): label("p2", "exact", cohort=None, point=2),
    }
    own = history.euro_team_records(g, labels, Counter())[0]
    assert len(own["labels"]) == 1 and own["labels"][0]["aa"] == 0
    g["playerGameScores"][0]["positionTyped"] = "Defender"
    assert history.euro_team_records(g, labels, Counter())[0]["shape"] is None


def test_europe_shape_features_use_strict_prelock_available_facts_only():
    from datetime import timedelta

    from app.research.score_search import cutoff_for

    row = dict(game="current", date="2024-02-03T20:00:00Z", player="p", pos="MID", cohort="start")
    target = dict(
        id="current", date=row["date"], home=dict(slug="a"), away=dict(slug="b"), players={"p": dict(team="a")}
    )
    boundary = (cutoff_for(row["date"]) - timedelta(hours=48)).isoformat()
    old = dict(
        game="old", date="2024-01-01T12:00:00Z", club="a", opponent="b", source="euro", xi=None, shape=None, labels=[]
    )
    edge = {**old, "game": "edge", "date": boundary, "xi": ["p", *[f"x{i}" for i in range(10)]], "shape": (4, 3, 3)}
    x = history.build_features([row], [target], [old, edge])
    assert x.shape == (1, 204)
    assert x[0, history.NAMES.index("europe_shape_euro_own_3_observed_games")] == 1
    assert x[0, history.NAMES.index("europe_shape_euro_own_3_xi_known_count")] == 0
    assert np.isnan(x[0, history.NAMES.index("europe_shape_euro_player_3_start_fraction")])
