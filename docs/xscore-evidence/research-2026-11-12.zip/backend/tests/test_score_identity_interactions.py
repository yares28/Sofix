"""Testing only: identity interactions are trained on past data and keep cold identities."""

import copy
from pathlib import Path

import numpy as np

from app.research import score_identity_interactions as interaction


def test_interaction_gradients_cover_every_matrix_repeated_identity_and_fixed_unknown_row():
    rng = np.random.default_rng(8)
    x = rng.normal(size=(4, 2))
    ids = np.array([[1, 1, 2], [2, 1, 1], [1, 2, 1], [0, 0, 0]])
    labels = interaction.targets(np.array([40.0, 80.0, 50.0, 35.0]))
    weights = {n: w.astype(float) for n, w in interaction.initial_weights(2, [2, 2, 2], 2, 3, 5).items()}
    loss, grad = interaction.loss_gradient(x, ids, labels, weights, 0.001, 0.01)
    assert np.isfinite(loss)
    for name, w in weights.items():
        for index in np.ndindex(w.shape):
            high = {n: a.copy() for n, a in weights.items()}
            low = {n: a.copy() for n, a in weights.items()}
            high[name][index] += 1e-5
            low[name][index] -= 1e-5
            expected = (
                interaction.loss_gradient(x, ids, labels, high, 0.001, 0.01)[0]
                - interaction.loss_gradient(x, ids, labels, low, 0.001, 0.01)[0]
            ) / 2e-5
            np.testing.assert_allclose(grad[name][index], expected, atol=1e-9, rtol=1e-4)
    for n in ("E_player", "E_team", "E_opponent"):
        np.testing.assert_array_equal(grad[n][0], 0)


def test_interaction_dictionaries_use_training_only_and_distinguish_zero_from_missing():
    cats = np.array([[0, "t", "o"], [None, "t", "o"], ["p", "t", "o"]], dtype=object)
    encoder = interaction.CategoryEncoder().fit(cats)
    original = copy.deepcopy(encoder.maps_)
    train = encoder.transform(cats)
    assert train[0, 0] > 0 and train[1, 0] == 0
    cold = encoder.transform(np.array([["future", "new-team", "o"], [None, "t", "new-opponent"]], dtype=object))
    assert cold[0, 0] == cold[0, 1] == cold[1, 0] == cold[1, 2] == 0
    assert cold[0, 2] > 0 and cold[1, 1] > 0
    assert encoder.maps_ == original


def test_interaction_initial_bias_uses_only_known_training_score_frequencies():
    scores = np.array([40.0, 80.0])
    bias = interaction.initial_output_bias(scores)
    expected = (interaction.targets(scores).sum(axis=0) + 1) / (len(scores) + 2)
    np.testing.assert_allclose(1 / (1 + np.exp(-bias)), expected, atol=1e-7, rtol=0)
    assert np.isfinite(bias).all()


def test_actual_interaction_network_learns_balanced_player_opponent_choices_and_keeps_cold_cases(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    base = np.array(
        [["p1", "team", "o1"], ["p1", "team", "o2"], ["p2", "team", "o1"], ["p2", "team", "o2"]], dtype=object
    )
    cats = np.repeat(base, 64, axis=0)
    x = np.zeros((256, 2))
    x[:, 1] = np.nan
    y = np.repeat([40.0, 80.0, 80.0, 40.0], 64)
    model = interaction.InteractionNetwork(
        rank=2, width=8, ridge=0.00001, embedding_ridge=0.00001, epochs=200, batch=64, seed=12
    ).fit(x, cats, y)
    prediction = model.predict(np.array([[0.0, np.nan]] * 4), base)
    assert (abs(prediction - np.array([40.0, 80.0, 80.0, 40.0])) <= 7).all()
    cold = model.predict_mass(
        np.array([[0.0, 12345.0], [np.nan, np.nan]]),
        np.array([["future", "team", "o1"], [None, None, None]], dtype=object),
    )
    assert cold.shape == (2, 201) and np.isfinite(cold).all()
    assert model.normaliser_.known_.tolist() == [True, False]
    for name in ("E_player", "E_team", "E_opponent"):
        np.testing.assert_array_equal(model.weights_[name][0], 0)


def test_numeric_ablation_cannot_learn_or_use_player_or_club_identifiers():
    rng = np.random.default_rng(7)
    x = rng.normal(size=(48, 2))
    scores = rng.choice([40.0, 80.0], 48)
    first = np.array([["p", "t", "o"]] * 48, dtype=object)
    changed = np.array([[str(i), "club" + str(i), "other" + str(i)] for i in range(48)], dtype=object)
    spec = dict(rank=2, width=4, epochs=2, seed=14, use_identities=False)
    a = interaction.InteractionNetwork(**spec).fit(x, first, scores)
    b = interaction.InteractionNetwork(**spec).fit(x, changed, scores)
    assert a.encoder_.maps_ == b.encoder_.maps_ == [{}, {}, {}]
    for name in a.weights_:
        np.testing.assert_array_equal(a.weights_[name], b.weights_[name])
    np.testing.assert_array_equal(a.predict_mass(x, first), a.predict_mass(x, changed))
