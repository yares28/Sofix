"""Screen rebuilt pre-lock team goal rates on chronological LaLiga fixtures."""

import hashlib
import json
from collections import defaultdict

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY

STEM = "laliga_score_goal_context_rebuild"
CONTEXT_KEY = "ae7743ec93e4e3c80ec7732f0d80528bb467c515a630a40f9b8745d48020f5d8"
QUALITY = tuple(
    f"{team}_{n}_{metric}_mean" for team, metric in (("own", "xg_for"), ("opponent", "xg_against")) for n in (3, 10)
)
INTENSITY = tuple(
    f"{team}_10_{metric}_mean"
    for team, metrics in (
        ("own", ("shots_for", "sot_for", "box_for", "possession")),
        ("opponent", ("shots_against", "sot_against", "box_against", "possession")),
    )
    for metric in metrics
)


def load(raw_games, case_data, cache, report):
    games = {g["id"]: g for g in map(json.loads, raw_games.splitlines()) if g["date"] < "2026-01-01"}
    base_names = case_data["features"]
    home, away, side = (base_names.index(k) for k in ("match_lam_h", "match_lam_a", "home"))
    assert report["featureKey"] == CONTEXT_KEY and report["sourceKey"] == case_data["key"]
    with np.load(cache) as archive:
        assert str(archive["key"]) == CONTEXT_KEY
        labels = archive["names"].tolist()
        x = archive["x"][:, [labels.index(n) for n in (*QUALITY, *INTENSITY)]]
    assert len(x) == len(case_data["rows"])
    contexts = defaultdict(list)
    for row, context in zip(case_data["rows"], x, strict=True):
        if row["game"] not in games:
            continue
        values = row["x"]
        g = games[row["game"]]
        is_home = g["players"][row["player"]]["team"] == g["home"]["slug"]
        assert is_home == bool(values[side]) and row["date"] == g["date"]
        rates = (values[home], values[away]) if is_home else (values[away], values[home])
        contexts[row["game"], is_home].append((rates, context))
    fixtures = []
    for game_id, game in sorted(games.items(), key=lambda item: (item[1]["date"], item[0])):
        paired_rates = []
        for is_home in (True, False):
            rows = contexts[game_id, is_home]
            rates, selected = rows[0]
            assert len(rows) >= 11 and all(r == rates for r, _ in rows)
            for _, value in rows[1:]:
                np.testing.assert_array_equal(value, selected)
            paired_rates.append(rates)
            fixtures.append((game["date"], is_home, game["homeGoals" if is_home else "awayGoals"], rates, selected))
        assert paired_rates[0] == paired_rates[1][::-1]
    return fixtures


def poisson_fit(train_x, y, offsets, test_x, test_offsets):
    n = train_x.shape[1]
    penalty = np.diag([0.0, *([24.0] * n)])
    a, b = np.column_stack((np.ones(len(y)), train_x)), np.column_stack((np.ones(len(test_x)), test_x))
    coefs = np.zeros(n + 1)
    for _ in range(20):
        mu = np.exp(np.clip(offsets + a @ coefs, -5, 3))
        change = np.linalg.solve(a.T @ (mu[:, None] * a) + penalty, a.T @ (y - mu) - penalty @ coefs)
        coefs += np.clip(change, -0.5, 0.5)
        if np.linalg.norm(change) < 1e-8:
            break
    else:
        raise ValueError("Poisson fit did not converge")
    return np.exp(np.clip(test_offsets + b @ coefs, -5, 3))


def design(base, add, train):
    mean = np.zeros(add.shape[1])
    for j, col in enumerate(add.T):
        valid = train & np.isfinite(col)
        mean[j] = col[valid].mean() if valid.any() else 0.0
    columns = np.column_stack((base, np.where(np.isfinite(add), add, mean), ~np.isfinite(add)))
    avg, sd = columns[train].mean(axis=0), columns[train].std(axis=0)
    return np.clip((columns - avg) / np.maximum(sd, 1e-8), -5, 5)


def loss(goals, rates):
    return rates - goals * np.log(rates)


def measures(goals, rates):
    return dict(
        poisson=float(loss(goals, rates).mean()),
        cleanSheetBrier=float(np.mean((np.exp(-rates) - (goals == 0)) ** 2)),
        goalMAE=float(np.mean(abs(goals - rates))),
    )


def interval(deltas, lock):
    totals = np.array([[deltas[lock == k].sum(), np.sum(lock == k)] for k in sorted(set(lock))])
    sample = np.random.default_rng(20261111).integers(0, len(totals), (3000, len(totals)))
    aggregate = totals[sample].sum(axis=1)
    return np.quantile(aggregate[:, 0] / aggregate[:, 1], (0.025, 0.975)).tolist()


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    cases = json.loads((ROOT / "cases.json").read_bytes())
    cache = ROOT / "match_context_features.npz"
    receipt = json.loads((REPORTS / "laliga_score_match_context.json").read_bytes())
    source = load(raw, cases, cache, receipt)
    dates = np.array([r[0] for r in source])
    home = np.array([r[1] for r in source])
    goals = np.array([r[2] for r in source])
    rates = np.array([r[3] for r in source])
    history = np.array([r[4] for r in source])
    known = np.all(np.isfinite(rates) & (rates > 0), axis=1)
    rates = np.where(known[:, None], rates, np.column_stack((np.where(home, 1.45, 1.15), np.where(home, 1.15, 1.45))))
    offset = np.log(rates[:, 0])
    core = np.column_stack((home, np.log(rates), ~known))
    clocks = np.array([cutoff_for(date) for date in dates])
    ready = np.array([moment(date) + DELAY for date in dates])
    periods, kept = {}, defaultdict(list)
    for phase, (begin, end) in PHASES.items():
        target = (dates >= begin) & (dates < end)
        fit = ready < clocks[target].min()
        ps = {"original": rates[target, 0]}
        for name, columns in (
            ("calibration", 0),
            ("chanceQuality", len(QUALITY)),
            ("qualityAndIntensity", history.shape[1]),
        ):
            a = design(core, history[:, :columns], fit)
            pred = poisson_fit(a[fit], goals[fit], offset[fit], a[target], offset[target])
            if columns:
                pred = np.where(np.isfinite(history[target, :columns]).any(axis=1), pred, ps["calibration"])
            ps[name] = pred
            kept[name].append(pred)
        kept["original"].append(ps["original"])
        kept["goals"].append(goals[target])
        kept["locks"].append(clocks[target])
        periods[phase] = {
            "fixtures": int(target.sum() / 2),
            "fitFixtures": int(fit.sum() / 2),
            "originalRatesAvailableSides": int(known[target].sum()),
            "qualityAvailableSides": int(np.isfinite(history[target, : len(QUALITY)]).any(axis=1).sum()),
            "metrics": {name: measures(goals[target], pred) for name, pred in ps.items()},
        }
    pool = {k: np.concatenate(v) for k, v in kept.items()}
    values = {
        k: measures(pool["goals"], pool[k]) for k in ("original", "calibration", "chanceQuality", "qualityAndIntensity")
    }
    gate = {}
    for candidate in ("chanceQuality", "qualityAndIntensity"):
        names = ("poisson", "cleanSheetBrier")
        reference = ("original", "calibration")
        improved = all(values[candidate][metric] < values[control][metric] for metric in names for control in reference)
        stable = sum(
            all(
                r["metrics"][candidate][metric] < r["metrics"][control][metric]
                for metric in names
                for control in reference
            )
            for r in periods.values()
        )
        uncertainty = interval(
            loss(pool["goals"], pool["calibration"]) - loss(pool["goals"], pool[candidate]), pool["locks"]
        )
        gate[candidate] = dict(
            phasesBeatingBoth=stable,
            poissonGain95=uncertainty,
            passEarlier=improved and stable >= 2 and uncertainty[0] > 0,
        )
    output = dict(
        contextSHA=hashlib.sha256(cache.read_bytes()).hexdigest(),
        nativeSHA=NATIVE_SHA,
        featureKey=CONTEXT_KEY,
        periods=periods,
        pooled=values,
        gate=gate,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"pooled": values, "gate": gate}, indent=2))


if __name__ == "__main__":
    main()
