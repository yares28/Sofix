"""Count historical decisions per eligible player-minute, by score state."""

import hashlib
import json
from collections import Counter

from app.research.score_absence_role_signal import REPORTS, ROOT
from app.research.score_card_cycle import PHASES


def minute_states(goals, start=46, stop=90):
    result = {}
    for minute in range(start, stop + 1):
        if any(t == minute for t, _ in goals):
            continue
        difference = sum(delta for t, delta in goals if t < minute)
        result[minute] = "leading" if difference > 0 else "trailing" if difference < 0 else "level"
    return result


def counts(records):
    exposure, decisions = Counter(), Counter()
    for r in records:
        for minute, state in minute_states(r["goalsForClub"]).items():
            window = "46-59" if minute < 60 else "60-74" if minute < 75 else "75-90"
            for p in r["players"]:
                role = "start" if p["started"] else "bench"
                decision = p["off"] if p["started"] else p["on"]
                if decision is None or minute <= decision:
                    key = role, window, p["position"], state
                    exposure[key] += 1
                    decisions[key] += int(minute == decision)
    return exposure, decisions


def main():
    audit = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    archive = (ROOT / "laliga_score_substitution_clock.json").read_bytes()
    assert hashlib.sha256(archive).hexdigest() == audit["qualifiedCacheSHA"]
    source = json.loads(archive)
    output = {}
    for phase, (begin, end) in PHASES.items():
        group = [r for r in source if begin <= r["date"] < end]
        exposure, decisions = counts(group)
        phase_output = {}
        for role in ("start", "bench"):
            role_output = {}
            for state in ("trailing", "level", "leading"):
                present = [key for key in exposure if key[0] == role and key[-1] == state]
                minutes = sum(exposure[key] for key in present)
                events = sum(decisions[key] for key in present)
                role_output[state] = dict(
                    eligiblePlayerMinutes=minutes, decisions=events, per1000=round(events * 1000 / minutes, 2)
                )
            phase_output[role] = role_output
        output[phase] = phase_output
    result = dict(
        sourceSHA=audit["qualifiedCacheSHA"],
        periods=output,
        limits="Descriptive rates only. Bench exposure is conditional on eventually appearing. Aggregate differences can "
        "reflect position, club strength, minute or selection. Historical states never enter a target forecast.",
    )
    (REPORTS / "laliga_score_substitution_exposure.json").write_text(json.dumps(result, indent=2) + "\n")
    for phase, data in output.items():
        print(phase, {role: {state: v["per1000"] for state, v in groups.items()} for role, groups in data.items()})


if __name__ == "__main__":
    main()
