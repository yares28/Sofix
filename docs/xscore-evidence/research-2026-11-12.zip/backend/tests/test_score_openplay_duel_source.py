from app.research.score_openplay_duel_source import opposing_actor, pair_kind


def test_opponent_link_requires_reciprocity_and_two_known_players():
    winner = {
        "match_id": "1",
        "team_event_id": "21",
        "opponent_key": "34",
        "period": "SecondHalf",
        "minute": "65",
        "second": "59",
        "duplicates": "1",
        "player_id": "123",
        "type": "Aerial",
        "outcome": "Successful",
    }
    loser = winner | {
        "team_event_id": "34",
        "opponent_key": "21",
        "minute": "66",
        "second": "0",
        "player_id": "456",
        "outcome": "Unsuccessful",
    }
    lookup = {("1", "away", "34"): loser}
    assert opposing_actor(winner, lookup, "away") is loser
    assert pair_kind(winner, loser) == "aerial"
    for invalid in ({"player_id": "NULL"}, {"duplicates": "2"}, {"opponent_key": "22"}, {"second": "1"}):
        assert opposing_actor(winner, {("1", "away", "34"): loser | invalid}, "away") is None
