"""Testing-only matched comparison for additional historical input features."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

from app.research import score_stats_hybrid
from app.research.score_europe_run import predict_components, select_components
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval


def compare_features(args, source, numeric, stat_key, extra, names, groups, feature_key, metadata):
    control = json.loads(args.control.read_text(encoding="utf-8"))
    if source["key"] != control["sourceKey"] or len(extra) != len(source["rows"]):
        raise ValueError("Feature/control source identity differs")
    specification = {group: np.flatnonzero(mask).tolist() for group, mask in groups.items()}
    key = hashlib.sha256(
        (source["key"] + stat_key + feature_key + json.dumps(specification, sort_keys=True)).encode()
        + Path(__file__).read_bytes()
        + Path(score_stats_hybrid.__file__).read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "target": "Actual LaLiga score within7 on all eligible starts and substitutes separately",
        "split": "TrainbeforeJuly2025; selectJuly-Dec2025; refitbeforeJan2026; compareJan-Oct2026",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "featureKey": feature_key,
        "implementationKey": key,
        "metadata": metadata,
        "features": names,
        "cohorts": {},
    }
    full_groups = {name: np.column_stack((numeric, extra[:, mask])) for name, mask in groups.items()}
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        aa = np.array([r["aa"] for r in rows])
        level = np.array([r["level"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        selection = {"control": control["cohorts"][cohort]["selection"]["control"]}
        for name, features in full_groups.items():
            path = args.cache / f"feature_{args.out.stem}_{cohort}_{name}_selection.npz"
            parts = cached_components(path, key, features[keep], aa, level, train, valid)
            winner, candidates = select_components(parts, y[valid])
            selection[name] = winner
            args.out.with_suffix(f".{cohort}.{name}.selection.json").write_text(
                json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
            )
            print(f"Selected {cohort} {name}: " + json.dumps(winner), flush=True)
        chosen = max(selection, key=lambda n: (selection[n]["selection"]["within7"], -selection[n]["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"chosen": chosen, "selection": selection}, indent=2), encoding="utf-8"
        )
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Control cases differ")
            predictions = {"control": stored["control"]}
        for name, features in full_groups.items():
            path = args.cache / f"feature_{args.out.stem}_{cohort}_{name}_later.npz"
            parts = cached_components(path, key, features[keep], aa, level, ~test, test)
            predictions[name] = predict_components(parts, selection[name])
            print(f"Evaluated {cohort} {name}", flush=True)
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        positions = np.array([r["pos"] for r in rows])[test]
        result = {"chosen": chosen, "selection": selection, "groups": {}}
        for name, prediction in predictions.items():
            result["groups"][name] = {
                "later": measure(y[test], prediction),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "gain95": paired_interval(y[test], prediction, predictions["control"], weeks),
                "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
                "positions": {
                    p: measure(y[test][positions == p], prediction[positions == p])
                    for p in POSITIONS
                    if (positions == p).any()
                },
            }
        np.savez_compressed(args.cache / f"{args.out.stem}_predictions_{cohort}.npz", **predictions, y=y[test], key=key)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, "chosen": chosen, "groups": {n: m["later"] for n, m in result["groups"].items()}}
            ),
            flush=True,
        )


def cached_components(path, key, x, aa, level, fit, check):
    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) == key:
                return stored["classes"], stored["probability"], {q: stored[f"q{q}"] for q in (0.35, 0.5, 0.65)}
    classes, probability, parts = score_stats_hybrid.conditional_components(x, aa, level, fit, check)
    np.savez_compressed(
        path, key=key, classes=classes, probability=probability, **{f"q{q}": p for q, p in parts.items()}
    )
    return classes, probability, parts
