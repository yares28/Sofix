"""Testing-only player chance quality and observed pitch usage from pinned event data."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_feature_compare import compare_features
from app.research.score_match_context import CLUBS, normalise, number, season_year
from app.research.score_prior_chances import words
from app.research.score_search import cutoff_for, moment

COMMIT = "20281026b7d3e948e8b25196fcfcf6d7c29ffe90"
FIELDS = (
    "chance_shots90",
    "chance_nonpenalty_shots90",
    "chance_box_shots90",
    "chance_big90",
    "chance_penalties90",
    "chance_xg90",
    "chance_npxg90",
    "chance_known_xg90",
    "chance_provider_fraction",
    "chance_xg_per_known_shot",
    "chance_shot_x",
    "chance_shot_edge",
    "chance_key_passes90",
    "usage_passes90",
    "usage_completed90",
    "usage_progressive90",
    "usage_box_passes90",
    "usage_crosses90",
    "usage_through90",
    "usage_pass_x",
    "usage_pass_edge",
    "usage_pass_x_sd",
    "usage_attacking_fraction",
    "usage_central_fraction",
    "usage_role_depth",
    "usage_role_edge",
)


def link_names(names, candidates, aliases):
    by_name = defaultdict(set)
    for slug in candidates:
        for variant in (slug, *aliases.get(slug, [])):
            by_name[words(variant)].add(slug)
    counts = Counter(words(n) for n in names)
    proposed = {}
    for name in names:
        key = words(name)
        if counts[key] != 1:
            continue
        exact = by_name.get(key, set())
        matches = exact if exact else {s for s in candidates if len(key) >= 2 and set(key) <= set(words(s))}
        if len(matches) == 1:
            proposed[key] = next(iter(matches))
    owners = Counter(proposed.values())
    result = {name: slug for name, slug in proposed.items() if owners[slug] == 1}
    return result, len(names) - len(result)


def stat_verified_links(people, participants, aliases, links, pass_events, shot_events, end_minute):
    if pass_events is None:
        return {}
    used = set(links.values())
    names = Counter(words(p["name"]) for p, _ in people)
    proposed = {}
    for p, started in people:
        name = words(p["name"])
        if name in links or names[name] != 1 or not name or len(name[-1]) < 4:
            continue
        candidates = [
            slug
            for slug, r in participants.items()
            if slug not in used
            and r["started"] == started
            and any(name[-1] in words(v) for v in (slug, *aliases.get(slug, [])))
        ]
        if len(candidates) != 1:
            continue
        slug = candidates[0]
        actual = participants[slug]
        stats = actual.get("stats") or {}
        accurate = stats.get("accurate_pass", [None])[0]
        events = pass_events.get(name, [])
        if (
            accurate is None
            or accurate <= 0
            or not all(type(e.get("ok")) is bool for e in events)
            or sum(e["ok"] for e in events) != accurate
        ):
            continue
        source_minutes = number(p.get("mins"))
        actual_minutes = number(actual.get("mins"))
        if not np.isfinite([source_minutes, actual_minutes]).all():
            continue
        if p.get("off") is None and not np.isfinite(end_minute):
            continue
        expected = source_minutes - (max(0, end_minute - 90) if p.get("off") is None else 0)
        if abs(expected - actual_minutes) > 1:
            continue
        goals = stats.get("goals", [None])[0]
        if goals is not None and p.get("g") is not None and goals != p["g"]:
            continue
        on_target = stats.get("ontarget_scoring_att", [None])[0]
        if (
            on_target is not None
            and shot_events is not None
            and sum(e.get("onTarget") is True for e in shot_events.get(name, [])) != on_target
        ):
            continue
        proposed[name] = slug
    counts = Counter(proposed.values())
    return {name: slug for name, slug in proposed.items() if counts[slug] == 1}


def in_box(x, y):
    return x >= 83 and 21 <= y <= 79


def player_metrics(shots, passes, role, minutes):
    values = dict.fromkeys(FIELDS, np.nan)

    def rate(count):
        return float(count) * 90 / minutes if minutes > 0 else np.nan

    if shots is not None:
        n = len(shots)
        nonpen = [s for s in shots if s.get("sit") != "Penalty"]
        providers = []
        nonpen_providers = []
        for shot in shots:
            observed = [number(shot.get("xg_" + p)) for p in ("fotmob", "understat")]
            observed = [v for v in observed if np.isfinite(v) and 0 <= v <= 1]
            quality = float(np.mean(observed)) if observed else np.nan
            providers.append(quality)
            if shot.get("sit") != "Penalty":
                nonpen_providers.append(quality)
        known = np.array(providers)[np.isfinite(providers)]
        values.update(
            chance_shots90=rate(n),
            chance_nonpenalty_shots90=rate(len(nonpen)),
            chance_penalties90=rate(n - len(nonpen)),
            chance_provider_fraction=len(known) / n if n else 1,
        )
        if len(known) == n:
            values["chance_xg90"] = rate(sum(known))
        if np.isfinite(nonpen_providers).all():
            values["chance_npxg90"] = rate(sum(nonpen_providers))
        if len(known) or not n:
            values["chance_known_xg90"] = rate(sum(known))
        if len(known):
            values["chance_xg_per_known_shot"] = float(known.mean())
        if all("big" in s for s in shots):
            values["chance_big90"] = rate(sum(s["big"] is True for s in shots))
        coordinates = [(number(s.get("x")), number(s.get("y"))) for s in shots]
        valid = [(x, y) for x, y in coordinates if np.isfinite([x, y]).all() and 0 <= x <= 100 and 0 <= y <= 100]
        if len(valid) == n:
            values["chance_box_shots90"] = rate(sum(in_box(x, y) for x, y in valid))
        if valid:
            values["chance_shot_x"] = float(np.mean([x for x, _ in valid]))
            values["chance_shot_edge"] = float(np.mean([2 * abs(y - 50) for _, y in valid]))
    if passes is not None:
        values["usage_passes90"] = rate(len(passes))
        for key, field in (
            ("key", "chance_key_passes90"),
            ("ok", "usage_completed90"),
            ("cross", "usage_crosses90"),
            ("through", "usage_through90"),
        ):
            if all(key in p for p in passes):
                values[field] = rate(sum(p[key] is True for p in passes))
        coordinates = [(number(p.get(k)) for k in ("x", "y", "ex", "ey")) for p in passes]
        coordinates = [tuple(c) for c in coordinates]
        valid = [c for c in coordinates if np.isfinite(c).all() and all(0 <= v <= 100 for v in c)]
        if len(valid) == len(passes):
            values["usage_progressive90"] = rate(sum(ex - x >= 15 for x, _, ex, _ in valid))
            values["usage_box_passes90"] = rate(sum(in_box(ex, ey) for _, _, ex, ey in valid))
        if valid:
            x, y, _, _ = np.array(valid).T
            values.update(
                usage_pass_x=float(x.mean()),
                usage_pass_edge=float((2 * abs(y - 50)).mean()),
                usage_pass_x_sd=float(x.std()),
                usage_attacking_fraction=float((x >= 200 / 3).mean()),
                usage_central_fraction=float((abs(y - 50) <= 20).mean()),
            )
    depth = next(
        (
            v
            for prefix, v in (("GK", 0), ("AM", 0.8), ("DM", 0.4), ("D", 0.2), ("M", 0.6), ("F", 1))
            if role.startswith(prefix)
        ),
        np.nan,
    )
    values["usage_role_depth"] = depth
    if np.isfinite(depth):
        values["usage_role_edge"] = -1 if role.endswith("L") else 1 if role.endswith("R") else 0
    return values


def load_observations(repo, manifest, games, aliases):
    head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if head != COMMIT:
        raise ValueError("Event repository differs from pinned commit")
    tree = subprocess.check_output(["git", "-C", str(repo), "ls-tree", "-r", "HEAD"], text=True)
    blobs = {line.split("\t", 1)[1]: line.split()[2] for line in tree.splitlines()}

    def verified(path, blob):
        raw = path.read_bytes()
        canonical = raw.replace(b"\r\n", b"\n")
        digest = hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest()
        if digest != blob:
            raise ValueError(f"Source hash mismatch: {path.name}")
        return canonical

    raw_manifest = verified(manifest, blobs["laliga_dashboard/data.js"])
    schedule = json.loads(raw_manifest.decode("utf-8").split("=", 1)[1].strip().rstrip(";"))
    local = defaultdict(list)
    for g in games:
        local[season_year(g["date"]), g["home"]["slug"], g["away"]["slug"]].append(g)
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        {
            normalise(k): v
            for k, v in (
                ("Alaves", CLUBS["Deportivo Alaves"]),
                ("Celta", CLUBS["Celta Vigo"]),
                ("Deportivo La Coruna", CLUBS["Deportivo A Coruna"]),
            )
        }
    )
    audit = Counter()
    records, samples = [], []
    source_hash = hashlib.sha256()
    seen = set()
    for season in schedule["seasons"].values():
        for entry in season["matches"]:
            if entry.get("played") is not True:
                continue
            identity = (
                season_year(entry["date"]),
                clubs.get(normalise(entry["home"])),
                clubs.get(normalise(entry["away"])),
            )
            matches = local.get(identity, [])
            if len(matches) != 1:
                audit["noUniqueLocalFixture"] += 1
                continue
            g = matches[0]
            if g["id"] in seen:
                raise ValueError("Duplicate event fixture")
            seen.add(g["id"])
            name = f"laliga_dashboard/matches_detail/{entry['id']}.js"
            path = repo / name
            if name not in blobs or not path.exists():
                audit["missingDetail"] += 1
                continue
            raw = verified(path, blobs[name])
            source_hash.update(raw)
            detail = json.loads(raw.decode("utf-8").split("=", 1)[1].strip().rstrip(";"))
            if [clubs.get(normalise(detail[s].get("name", ""))) for s in ("home", "away")] != list(identity[1:]):
                audit["fixtureClubConflicts"] += 1
                continue
            if (detail["home"].get("score"), detail["away"].get("score")) != (g["homeGoals"], g["awayGoals"]):
                audit["fixtureScoreConflicts"] += 1
                continue
            audit["verifiedFixtures"] += 1
            audit["correctedDates"] += detail.get("date") != g["date"][:10]
            for side in ("home", "away"):
                club = g[side]["slug"]
                participants = {
                    p: r
                    for p, r in g["players"].items()
                    if r.get("played") is True and r.get("team") == club and type(r.get("started")) is bool
                }
                lineup = (detail.get("lineups") or {}).get(side) or {}
                people = [
                    (p, started)
                    for field, started in (("starters", True), ("subs", False))
                    for p in lineup.get(field, [])
                ]
                links, missing = link_names([p["name"] for p, _ in people], participants, aliases)
                audit["strictUnmatchedLineupPlayers"] += missing
                indexed_events = {}
                for category in ("shots", "passes"):
                    event_list = detail.get(category)
                    by_person = defaultdict(list)
                    if isinstance(event_list, list):
                        for event in event_list:
                            if event.get("team") == side:
                                by_person[words(event.get("player", ""))].append(event)
                    indexed_events[category] = by_person if isinstance(event_list, list) else None
                extra_links = stat_verified_links(
                    people,
                    participants,
                    aliases,
                    links,
                    indexed_events["passes"],
                    indexed_events["shots"],
                    number(detail.get("maxMin")),
                )
                audit["statVerifiedNameLinks"] += len(extra_links)
                links.update(extra_links)
                audit["unmatchedLineupPlayers"] += len(people) - len(links)
                for p, _ in people:
                    if words(p["name"]) not in links and len(samples) < 40:
                        samples.append({"game": g["id"], "name": p["name"], "club": club})
                for p, started in people:
                    key = words(p["name"])
                    slug = links.get(key)
                    if slug is None:
                        continue
                    actual = participants[slug]
                    if started != actual["started"]:
                        audit["cohortConflicts"] += 1
                        continue
                    stats = actual.get("stats") or {}
                    actual_goals = stats.get("goals", [None])[0]
                    if actual_goals is not None and p.get("g") is not None and actual_goals != p["g"]:
                        audit["playerGoalConflicts"] += 1
                        continue
                    shots = indexed_events["shots"].get(key, []) if indexed_events["shots"] is not None else None
                    passes = indexed_events["passes"].get(key, []) if indexed_events["passes"] is not None else None
                    actual_shots = stats.get("total_scoring_att", [None])[0]
                    audit["explicitShotCountComparisons"] += int(actual_shots is not None and shots is not None)
                    mismatch = shots is not None and actual_shots is not None and len(shots) != actual_shots
                    audit["shotCountConflicts"] += int(mismatch)
                    if mismatch and not shots:
                        shots = None
                    minutes = actual.get("mins")
                    if minutes is None:
                        audit["unknownMinutes"] += 1
                        continue
                    values = player_metrics(shots, passes, p.get("pos", ""), minutes)
                    if mismatch:
                        values["chance_xg90"] = values["chance_npxg90"] = np.nan
                    audit["observations"] += 1
                    audit["sourceClockDiffers"] += int(p.get("mins") != minutes)
                    audit["fullChanceKnown"] += int(np.isfinite(values["chance_xg90"]))
                    audit["positiveShotRecords"] += int(shots is not None and bool(shots))
                    audit["positiveShotRecordsWithFullChance"] += int(
                        shots is not None and bool(shots) and np.isfinite(values["chance_xg90"])
                    )
                    records.append(
                        {
                            "date": g["date"],
                            "game": g["id"],
                            "player": slug,
                            "club": club,
                            "cohort": "start" if started else "bench",
                            "minutes": minutes,
                            "values": {k: float(v) if np.isfinite(v) else None for k, v in values.items()},
                        }
                    )
    receipt = {
        "commit": head,
        "sourceContentSha256": source_hash.hexdigest(),
        **dict(audit),
        "unmatchedSamples": samples,
        "sourceScope": "Only fixture-verified played participants; source model xG/xA/rating not used; receiver guesses not used; Sorare minutes authoritative",
    }
    return records, receipt


def recent_features(rows, observations, targets):
    names = [
        f"{kind}_{n}_{field}"
        for kind, n in (("same", 3), ("same", 10), ("all", 3))
        for field in (
            "source_games",
            "source_minutes",
            "source_age",
            *[f"{v}_{stat}" for v in FIELDS for stat in ("mean", "count")],
        )
    ]
    names.append("last_source_same_club")
    result = np.full((len(rows), len(names)), np.nan)
    queue = sorted(observations, key=lambda r: moment(r["date"]))
    order = sorted(range(len(rows)), key=lambda i: cutoff_for(rows[i]["date"]))
    histories = defaultdict(list)
    cursor = 0
    for i in order:
        row = rows[i]
        cutoff = cutoff_for(row["date"])
        while cursor < len(queue) and moment(queue[cursor]["date"]) + timedelta(hours=48) < cutoff:
            old = queue[cursor]
            histories[old["player"]].append(old)
            cursor += 1
        history = [r for r in histories[row["player"]] if cutoff - moment(r["date"]) <= timedelta(days=365)]
        same = [r for r in history if r["cohort"] == row["cohort"]]
        values = []
        for group in (same[-3:], same[-10:], history[-3:]):
            values += [
                len(group),
                sum(r["minutes"] for r in group),
                (cutoff - moment(group[-1]["date"])).total_seconds() / 86400 if group else np.nan,
            ]
            a = np.array([[r["values"].get(k) for k in FIELDS] for r in group], dtype=float).reshape(
                len(group), len(FIELDS)
            )
            weight = np.array([r["minutes"] for r in group])[:, None]
            observed = np.isfinite(a) & (weight > 0)
            denominator = (weight * observed).sum(axis=0)
            mean = np.divide(
                (np.where(observed, a, 0) * weight).sum(axis=0),
                denominator,
                out=np.full(len(FIELDS), np.nan),
                where=denominator > 0,
            )
            values.extend(np.column_stack((mean, observed.sum(axis=0))).ravel())
        club = targets[row["game"]]["players"][row["player"]]["team"]
        values.append(float(history[-1]["club"] == club) if history else np.nan)
        result[i] = values
    covered = np.isfinite(result[:, names.index("same_3_chance_xg90_mean")])
    return (
        result,
        names,
        {
            "rows": len(rows),
            "inputs": len(names),
            "sameCohortRecentChanceCovered": int(covered.sum()),
            "historyDays": 365,
            "availabilityHours": 48,
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in (
        "cases",
        "stats-cache",
        "games",
        "source-repo",
        "manifest",
        "aliases",
        "match-report",
        "control",
        "cache",
        "packages",
        "out",
    ):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    raw_games = args.games.read_bytes()
    aliases_raw = args.aliases.read_bytes()
    key = hashlib.sha256(
        (source["key"] + COMMIT).encode() + raw_games + aliases_raw + Path(__file__).read_bytes()
    ).hexdigest()
    games = [json.loads(line) for line in raw_games.decode("utf-8").splitlines() if line.strip()]
    cached_path = args.cache / "player_context_observations.json.gz"
    stored = json.loads(gzip.decompress(cached_path.read_bytes())) if cached_path.exists() else None
    if stored is not None and stored["key"] == key:
        observations, receipt = stored["records"], stored["receipt"]
    else:
        observations, receipt = load_observations(args.source_repo, args.manifest, games, json.loads(aliases_raw))
        cached_path.write_bytes(
            gzip.compress(json.dumps({"key": key, "records": observations, "receipt": receipt}).encode())
        )
    extra, names, metadata = recent_features(source["rows"], observations, {g["id"]: g for g in games})
    metadata["sourceAudit"] = receipt
    metadata["laterCoverage"] = {}
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        metadata["laterCoverage"][cohort] = {
            "n": int(selected.sum()),
            "sameRecentChanceCovered": int(np.isfinite(extra[selected, names.index("same_3_chance_xg90_mean")]).sum()),
            "recentUsageCovered": int(np.isfinite(extra[selected, names.index("all_3_usage_pass_x_mean")]).sum()),
        }
    np.savez_compressed(args.cache / "player_context_features.npz", key=key, x=extra, names=names)
    args.out.with_suffix(".source-audit.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(
        "Player source "
        + json.dumps({k: v for k, v in metadata.items() if k != "sourceAudit"})
        + " audit "
        + json.dumps({k: v for k, v in receipt.items() if k != "unmatchedSamples"}),
        flush=True,
    )
    if args.audit_only:
        return
    match_report = json.loads(args.match_report.read_text(encoding="utf-8"))
    with np.load(args.stats_cache) as stored:
        numeric, stat_key = stored["x"], str(stored["key"])
    with np.load(args.cache / "match_context_features.npz") as stored:
        if str(stored["key"]) != match_report["featureKey"]:
            raise ValueError("Team context feature identity differs")
        numeric = np.column_stack((numeric, stored["x"]))
    stat_key = hashlib.sha256((stat_key + match_report["featureKey"]).encode()).hexdigest()
    groups = {
        "team_context": np.zeros(len(names), dtype=bool),
        "player_chances": np.array(["usage_" not in n for n in names]),
        "player_chances_usage": np.ones(len(names), dtype=bool),
    }
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    compare_features(args, source, numeric, stat_key, extra, names, groups, key, metadata)


if __name__ == "__main__":
    main()
