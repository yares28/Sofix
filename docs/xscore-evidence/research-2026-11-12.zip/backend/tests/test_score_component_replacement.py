import numpy as np

from app.research.score_component_replacement import diagnostics, history_for


def test_component_reference_embargo_and_same_match_pooling():
    rows = [
        {"game": "past", "player": "a", "pos": "DEF"},
        {"game": "past", "player": "b", "pos": "DEF"},
        {"game": "same-lock", "player": "a", "pos": "DEF"},
        {"game": "later", "player": "a", "pos": "DEF"},
    ]
    points = np.array([[10, 0, 3, 2, 0], [10, 0, -2, 0, 1], [0, -16, -6, 0, 3], [0, -20, -8, 0, 4]])
    sides = [("club", "opp")] * 4
    times, locks = np.array([48, 48, 100, 110]), np.array([0, 0, 48, 49])
    history = history_for(rows, sides, points, times, locks)
    np.testing.assert_array_equal(history[:3], 0)
    np.testing.assert_allclose(history[3, [0, 2, 5, 8, 11, 14, 17]], [10, (3 + 5 * 0.5) / 6, 1, 0.5, 1, 0.5, 1])
    points[2:] = 800
    np.testing.assert_array_equal(history_for(rows, sides, points, times, locks), history)


def test_perfect_selection_reports_only_recovered_misses():
    y, base, delta = np.array([52.0, 42.0, 57.0]), np.array([40.0, 40.0, 40.0]), np.array([20.0, 10.0, 24.0])
    report = diagnostics(y, base, delta, np.ones(3, dtype=bool))
    assert report["fixedFullShift"]["rescued"] == 1
    assert report["fixedFullShift"]["spoiled"] == 1
    assert report["rescuesWithPerfectMoveSelection"] == 2
