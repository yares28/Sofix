"""Testing only: chronological exact-window choices around frozen score models."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_exact_window as exact
from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def fitted(parts, positions, bank, control, path, key):
    if path.exists():
        with np.load(path) as f:
            if str(f["key"]) != key or len(f["prediction"]) != len(control):
                raise ValueError("Exact-window cache identity differs")
            return f["prediction"], json.loads(str(f["statistics"]))
    audit = exact.audit_grid(parts, positions, bank)
    prediction, statistics = exact.predict(parts, positions, bank, control)
    statistics["distributionAudit"] = audit
    np.savez_compressed(path, key=key, prediction=prediction, statistics=json.dumps(statistics))
    return prediction, statistics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(r["sourceKey"] != source["key"] for r in (old_match, old_stability, old_ordinary, old_start, old_bench)):
        raise ValueError("Exact-window source case identity differs")
    modules = (exact, empirical, flow, matched, controls, ordinary, stability)
    key = hashlib.sha256(
        (
            source["key"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    report = {
        "scope": "Testing only; exact empirical window decision, no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        prior_report = json.loads(args.out.read_text())
        if prior_report["implementationKey"] == key:
            report = prior_report
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        records = [
            {"spec": {"scope": scope}, "gains": [], "errors": [], "counts": [], "periods": {}}
            for scope in ("all", "defmid")
        ]
        previous, winner, best, audit = None, None, None, {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            current_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            current = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "warm2023":
                previous = current_rows, current
                continue
            if phase == "later2026" and best is None:
                raise ValueError("Exact-window decision must freeze before final outcomes")
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Exact-window strongest control differs")
            previous_rows, previous_parts = previous
            bank = matched.bank_from(previous_parts, previous_rows, mask["first"])
            print(f"EXACT_PREDICTING {cohort} {phase}", flush=True)
            raw, stats = fitted(
                current,
                positions[target],
                bank,
                control,
                args.cache / f"{args.out.stem}_{cohort}_{phase}_{key[:12]}.npz",
                key,
            )
            audit[phase] = {
                "control": expected,
                "target": int(target.sum()),
                "bankCases": bank["cases"],
                "unknownBankClassLabels": bank["unknownLevels"],
                "diagnostics": stats,
            }
            active = [best] if phase == "later2026" else records
            for record in active:
                candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                metric = measure(y[target], candidate)
                if phase == "later2026":
                    alternate = candidate
                else:
                    gain = metric["within7"] - expected["within7"]
                    record["gains"].append(gain)
                    record["errors"].append(metric["mae"])
                    record["counts"].append(len(candidate))
                    record["periods"][phase] = {"gain": gain, "metrics": metric}
                print(
                    "EXACT_TESTED "
                    + json.dumps(
                        {"cohort": cohort, "phase": phase, "scope": record["spec"]["scope"], "metrics": metric}
                    ),
                    flush=True,
                )
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
                    json.dumps(
                        {"implementationKey": key, "winner": winner, "best": best, "candidates": records}, indent=2
                    )
                )
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            previous = current_rows, current
        prediction = alternate if winner else control.copy()
        h0, h1 = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(y[target], alternate, control, [r["week"] for r in current_rows]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
