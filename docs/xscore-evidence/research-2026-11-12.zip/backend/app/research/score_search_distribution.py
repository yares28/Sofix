"""Second search batch on development data only. October is never evaluated here."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_search import make_cases, measure


def distribution_score(probability: np.ndarray, classes: np.ndarray, blend: float = 0) -> np.ndarray:
    centres = np.arange(101)
    # Approximate each five-point score bin as uniform. Boundaries stay inside [0,100].
    low, high = np.maximum(0, classes * 5 - 2.5), np.minimum(100, classes * 5 + 2.5)
    overlap = np.maximum(0, np.minimum(high[:, None], centres + 7) - np.maximum(low[:, None], centres - 7))
    mass = probability @ (overlap / (high - low)[:, None])
    mode = centres[mass.argmax(axis=1)]
    mean = probability @ (classes * 5)
    return (1 - blend) * mode + blend * mean


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--packages", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import HistGradientBoostingClassifier
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    games = [json.loads(s) for s in args.games.read_text(encoding="utf-8").splitlines() if s.strip()]
    rows = make_cases([g for g in games if g["date"][:10] < "2026-10-01"])
    x = np.asarray([r["x"] for r in rows], dtype=np.float32)
    y = np.array([r["score"] for r in rows])
    train = np.array([r["date"][:10] < "2025-07-01" for r in rows])
    labels = np.clip(np.floor((y + 2.5) / 5), 0, 20).astype(int)
    results = []
    leader = None
    for leaves in (7, 15, 31):
        for minimum in (30, 150):
            model = HistGradientBoostingClassifier(
                max_leaf_nodes=leaves,
                min_samples_leaf=minimum,
                max_iter=100,
                learning_rate=0.05,
                l2_regularization=10,
                early_stopping=False,
                random_state=20261103,
            ).fit(x[train], labels[train])
            probability = model.predict_proba(x[~train])
            for blend in (0, 0.25, 0.5, 0.75, 1):
                base = distribution_score(probability, model.classes_, blend)
                for shift in range(-6, 7):
                    score = measure(y[~train], np.clip(base + shift, 0, 100))
                    row = {"leaves": leaves, "minLeaf": minimum, "blend": blend, "shift": shift, **score}
                    results.append(row)
                    if leader is None or (row["within7"], -row["mae"]) > (leader["within7"], -leader["mae"]):
                        leader = row
                        print("LEADER " + json.dumps(leader), flush=True)
            # Checkpoint completed models; interruption cannot erase the evidence.
            args.out.write_text(
                json.dumps(
                    {
                        "scope": "Development only, October excluded; not independent confirmation",
                        "candidates": results,
                        "best": leader,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
    balanced = [r for r in results if abs(r["bias"]) <= 2]
    report = {
        "scope": "Development only, October excluded; not independent confirmation",
        "candidateCount": len(results),
        "best": leader,
        "bestWithBiasUnder2": max(balanced, key=lambda r: r["within7"]) if balanced else None,
        "candidates": results,
        "test": "No new test; later untouched gameweeks required",
    }
    args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("RESULT " + json.dumps({k: v for k, v in report.items() if k != "candidates"}), flush=True)


if __name__ == "__main__":
    main()
