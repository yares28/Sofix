"""Testing only: independently reproduce the original median-AA model before extending its quantiles."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from sklearn.ensemble import HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda n: json.loads((args.out.parent / (n + ".json")).read_text())
    old_match, old_stability, old_ordinary = map(
        read, ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary")
    )
    if any(r["sourceKey"] != source["key"] for r in (old_match, old_stability, old_ordinary)):
        raise ValueError("Original quantile anchor source differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Original anchor match features differ")
        all_x = np.column_stack((base, f["x"]))
    evidence = {}
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        aa, levels = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level"))
        masks = stability.phase_masks(rows)
        mask = masks["spring2024"]
        old = flow.old_components(
            SimpleNamespace(cache=args.cache), cohort, "spring2024", old_match, old_stability, old_ordinary
        )
        print(f"QUANTILE_ANCHOR_REFIT {cohort} spring2024", flush=True)
        model = HistGradientBoostingRegressor(
            loss="quantile",
            quantile=0.5,
            max_leaf_nodes=15,
            min_samples_leaf=60,
            max_iter=120,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261103,
        )
        x = all_x[keep]
        fit, target = mask["fit"], mask["target"]
        aa[~fit] = np.nan
        levels[~fit] = np.nan
        model.fit(np.column_stack((x[fit], levels[fit])), aa[fit])
        replay = np.column_stack(
            [model.predict(np.column_stack((x[target], np.full(int(target.sum()), level)))) for level in old[0]]
        )
        maximum = float(np.max(np.abs(replay - old[2][0.5])))
        evidence[cohort] = {
            "fitCases": int(fit.sum()),
            "forecastCases": int(target.sum()),
            "possibleClasses": len(old[0]),
            "unavailableAAandDSRowsBlanked": int((~fit).sum()),
            "maximumAbsoluteDifference": maximum,
            "identical": bool(np.array_equal(replay, old[2][0.5])),
        }
        if maximum > 1e-10:
            args.out.write_text(
                json.dumps(
                    {"scope": "Original quantile anchor mismatch; no forecast accuracy claim", "evidence": evidence},
                    indent=2,
                )
            )
            raise ValueError("Original median-AA forecasts did not reproduce exactly: " + str(maximum))
    output = {
        "scope": "Original median-AA replay check only, no new accuracy claim",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "matchFeatureKey": old_match["featureKey"],
        "sklearnVersion": sklearn.__version__,
        "sourceSha256": hashlib.sha256(
            Path(__file__).read_bytes() + Path(conditional.__file__).read_bytes()
        ).hexdigest(),
        "evidence": evidence,
    }
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
