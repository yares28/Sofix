"""Testing only: verified past chance-creation observations and lock-safe histories."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import subprocess
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_created_chances as creation
from app.research import score_player_context as native
from app.research.score_match_context import CLUBS, normalise, number, season_year
from app.research.score_prior_chances import words
from app.research.score_search import cutoff_for, moment


def observations(repo, manifest, games, aliases):
    head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if head != native.COMMIT:
        raise ValueError("Chance-creation source commit differs")
    tree = subprocess.check_output(["git", "-C", str(repo), "ls-tree", "-r", "HEAD"], text=True)
    blobs = {line.split("\t", 1)[1]: line.split()[2] for line in tree.splitlines()}
    digest = hashlib.sha256()

    def read(path, name):
        raw = path.read_bytes().replace(b"\r\n", b"\n")
        actual = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if actual != blobs[name]:
            raise ValueError("Chance-creation source blob differs: " + name)
        digest.update(raw)
        return json.loads(raw.decode().split("=", 1)[1].strip().rstrip(";"))

    schedule = read(manifest, "laliga_dashboard/data.js")
    local = defaultdict(list)
    for game in games:
        local[season_year(game["date"]), game["home"]["slug"], game["away"]["slug"]].append(game)
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        {
            normalise(k): CLUBS[v]
            for k, v in (
                ("Alaves", "Deportivo Alaves"),
                ("Celta", "Celta Vigo"),
                ("Deportivo La Coruna", "Deportivo A Coruna"),
            )
        }
    )
    audit, records, seen = Counter(), [], set()
    for season in schedule["seasons"].values():
        for entry in season["matches"]:
            if entry.get("played") is not True:
                continue
            identity = (
                season_year(entry["date"]),
                clubs.get(normalise(entry["home"])),
                clubs.get(normalise(entry["away"])),
            )
            matches = local.get(identity, [])
            if len(matches) != 1:
                audit["noUniqueLocalFixture"] += 1
                continue
            game = matches[0]
            if game["id"] in seen:
                raise ValueError("Duplicate chance-creation fixture")
            seen.add(game["id"])
            name = f"laliga_dashboard/matches_detail/{entry['id']}.js"
            if name not in blobs or not (repo / name).exists():
                audit["missingDetail"] += 1
                continue
            detail = read(repo / name, name)
            if [clubs.get(normalise(detail[s].get("name", ""))) for s in ("home", "away")] != list(identity[1:]):
                audit["fixtureClubConflict"] += 1
                continue
            if (detail["home"].get("score"), detail["away"].get("score")) != (game["homeGoals"], game["awayGoals"]):
                audit["fixtureScoreConflict"] += 1
                continue
            audit["verifiedFixtures"] += 1
            passes, shots = detail.get("passes"), detail.get("shots")
            links, link_audit = creation.link_chances(passes, shots)
            audit.update({"link_" + k: v for k, v in link_audit.items()})
            for side in ("home", "away"):
                club = game[side]["slug"]
                participants = {
                    p: r
                    for p, r in game["players"].items()
                    if r.get("played") is True and r.get("team") == club and type(r.get("started")) is bool
                }
                lineup = (detail.get("lineups") or {}).get(side) or {}
                people = [
                    (p, start) for field, start in (("starters", True), ("subs", False)) for p in lineup.get(field, [])
                ]
                identities, _ = native.link_names([p["name"] for p, _ in people], participants, aliases)
                events = {}
                for category, stream in (("passes", passes), ("shots", shots)):
                    by_person = defaultdict(list)
                    if isinstance(stream, list):
                        for event in stream:
                            if event.get("team") == side:
                                by_person[words(event.get("player", ""))].append(event)
                    events[category] = by_person if isinstance(stream, list) else None
                extra = native.stat_verified_links(
                    people,
                    participants,
                    aliases,
                    identities,
                    events["passes"],
                    events["shots"],
                    number(detail.get("maxMin")),
                )
                identities.update(extra)
                audit["statVerifiedNameLinks"] += len(extra)
                audit["unmatchedLineupPeople"] += len(people) - len(identities)
                for person, start in people:
                    who = words(person["name"])
                    slug = identities.get(who)
                    if slug is None:
                        continue
                    actual = participants[slug]
                    if start != actual["started"]:
                        audit["cohortConflict"] += 1
                        continue
                    minutes = actual.get("mins")
                    if minutes is None or minutes <= 0:
                        audit["unknownMinutes"] += 1
                        continue
                    indices = [
                        i
                        for i, p in enumerate(passes or [])
                        if p.get("team") == side and words(p.get("player", "")) == who
                    ]
                    values = creation.created_metrics(passes, shots, links, indices, minutes)
                    stats = actual.get("stats") or {}
                    goals = stats.get("goals", [None])[0]
                    if goals is not None and person.get("g") is not None and goals != person["g"]:
                        audit["playerGoalConflict"] += 1
                        continue
                    accurate = stats.get("accurate_pass", [None])[0]
                    if accurate is not None and isinstance(passes, list):
                        audit["explicitAccuratePassComparisons"] += 1
                        conflict = sum(passes[i].get("ok") is True for i in indices) != accurate
                        audit["explicitAccuratePassConflicts"] += conflict
                        if conflict:
                            values = dict.fromkeys(creation.FIELDS, np.nan)
                    assists = stats.get("goal_assist", [None])[0]
                    if assists is not None and isinstance(passes, list):
                        audit["explicitAssistComparisons"] += 1
                        conflict = sum(passes[i].get("assist") is True for i in indices) != assists
                        audit["explicitAssistConflicts"] += conflict
                        if conflict:
                            values = dict.fromkeys(creation.FIELDS, np.nan)
                    audit["observations"] += 1
                    audit["fullQualityObservations"] += int(np.isfinite(values["created_quality90"]))
                    has_chances = values["created_chances90"] > 0
                    audit["positiveChanceObservations"] += int(has_chances)
                    audit["positiveChanceFullQuality"] += int(has_chances and np.isfinite(values["created_quality90"]))
                    records.append(
                        {
                            "date": game["date"],
                            "game": game["id"],
                            "player": slug,
                            "club": club,
                            "cohort": "start" if start else "bench",
                            "minutes": minutes,
                            "values": {k: float(v) if np.isfinite(v) else None for k, v in values.items()},
                        }
                    )
    return records, {"commit": head, "sourceSha256": digest.hexdigest(), **dict(audit)}


def lag_features(rows, records, games):
    groups = (("same", 3), ("same", 10), ("all", 3), ("all", 10))
    names = [
        f"{kind}_{n}_{field}"
        for kind, n in groups
        for field in (
            "source_games",
            "source_minutes",
            "source_age",
            *[f"{v}_{stat}" for v in creation.FIELDS for stat in ("mean", "count")],
        )
    ]
    names.append("last_source_same_club")
    result = np.full((len(rows), len(names)), np.nan)
    queue = sorted(records, key=lambda r: moment(r["date"]))
    histories, cursor = defaultdict(list), 0
    for i in sorted(range(len(rows)), key=lambda j: cutoff_for(rows[j]["date"])):
        row, cutoff = rows[i], cutoff_for(rows[i]["date"])
        while cursor < len(queue) and moment(queue[cursor]["date"]) + timedelta(hours=48) < cutoff:
            record = queue[cursor]
            histories[record["player"]].append(record)
            cursor += 1
        history = [r for r in histories[row["player"]] if cutoff - moment(r["date"]) <= timedelta(days=365)]
        values = []
        for kind, n in groups:
            group = [r for r in history if kind == "all" or r["cohort"] == row["cohort"]][-n:]
            values += [
                len(group),
                sum(r["minutes"] for r in group),
                (cutoff - moment(group[-1]["date"])).total_seconds() / 86400 if group else np.nan,
            ]
            a = np.array([[r["values"].get(k) for k in creation.FIELDS] for r in group], dtype=float).reshape(
                len(group), len(creation.FIELDS)
            )
            weight = np.array([r["minutes"] for r in group])[:, None]
            observed = np.isfinite(a) & (weight > 0)
            den = (weight * observed).sum(axis=0)
            mean = np.divide(
                (np.where(observed, a, 0) * weight).sum(axis=0),
                den,
                out=np.full(len(creation.FIELDS), np.nan),
                where=den > 0,
            )
            values.extend(np.column_stack((mean, observed.sum(axis=0))).ravel())
        club = games[row["game"]]["players"][row["player"]]["team"]
        values.append(float(history[-1]["club"] == club) if history else np.nan)
        result[i] = values
    return result, names


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "source-repo", "manifest", "aliases", "cache", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    raw = args.games.read_bytes()
    aliases = args.aliases.read_bytes()
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + aliases
        + Path(__file__).read_bytes()
        + Path(creation.__file__).read_bytes()
        + Path(native.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    records, receipt = observations(args.source_repo, args.manifest, games, json.loads(aliases))
    values, names = lag_features(source["rows"], records, {g["id"]: g for g in games})
    if values.shape != (len(source["rows"]), len(names)) or np.isinf(values).any():
        raise ValueError("Chance-creation case coverage differs")
    args.cache.mkdir(parents=True, exist_ok=True)
    (args.cache / "created_chances_observations.json.gz").write_bytes(
        gzip.compress(json.dumps({"key": key, "records": records, "receipt": receipt}, allow_nan=False).encode())
    )
    np.savez_compressed(args.cache / "created_chances_features.npz", key=key, x=values, names=names)
    report = {
        "sourceKey": source["key"],
        "featureKey": key,
        "scope": "Testing-only inputs; no forecast accuracy claim",
        "features": len(names),
        "sourceAudit": receipt,
        "knownByFeature": {n: int(np.isfinite(values[:, j]).sum()) for j, n in enumerate(names)},
        "laterCoverage": {},
    }
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        report["laterCoverage"][cohort] = {
            "n": int(selected.sum()),
            "knownRecentQuality": int(
                np.isfinite(values[selected, names.index("same_3_created_quality90_mean")]).sum()
            ),
        }
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
    print(json.dumps({k: v for k, v in report.items() if k != "knownByFeature"}), flush=True)


if __name__ == "__main__":
    main()
