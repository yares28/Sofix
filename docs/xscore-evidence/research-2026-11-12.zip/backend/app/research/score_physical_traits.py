"""Testing-only fixed 2022 player traits and past-only projected opponent ability."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_matchups import DEPTH
from app.research.score_search import cutoff_for, moment

FIELDS = (
    "Height",
    "Weight",
    "Strength",
    "Jumping",
    "HeadingAccuracy",
    "Acceleration",
    "SprintSpeed",
    "Balance",
    "StandingTackle",
    "Dribbling",
)
PUBLISHED = "2022-11-02T19:07:54Z"
CSV_SHA = "37b99198a6642408d6fc90b9e856c434ef9d8f9f54e2909fffe7cc8924b2d64c"
NATIVE_SHA = "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"


def normalized(value):
    return " ".join(
        re.findall(
            "[a-z0-9]+",
            "".join(c for c in unicodedata.normalize("NFKD", value.lower()) if not unicodedata.combining(c)),
        )
    )


def identities(players, aliases, data):
    index = defaultdict(set)
    unique = {}
    for r in data:
        if r["ID"] in unique and r != unique[r["ID"]]:
            raise ValueError("Conflicting duplicate source player ID")
        unique[r["ID"]] = r
    for r in data:
        for name in (r["FullName"], r["Name"]):
            tokens = normalized(name).split()
            if len(tokens) >= 2 and all(len(t) > 1 for t in tokens):
                index[" ".join(tokens)].add(int(r["ID"]))
    result = {}
    for player in sorted(players):
        names = sorted({normalized(player.replace("-", " ")), *(normalized(n) for n in aliases.get(player, []))})
        evidence = {name: sorted(index[name]) for name in names if index[name]}
        candidates = sorted(set().union(*evidence.values())) if evidence else []
        result[player] = dict(
            id=candidates[0] if len(candidates) == 1 else None,
            status="exact_name" if len(candidates) == 1 else "ambiguous" if candidates else "unmatched",
            candidates=candidates,
            evidence=evidence,
        )
    reverse = defaultdict(list)
    for player, record in result.items():
        if record["id"] is not None:
            reverse[record["id"]].append(player)
    for members in reverse.values():
        if len(members) > 1:
            for player in members:
                result[player].update(id=None, status="duplicate_identity")
    return result


def ability(identity, data):
    if identity.get("id") is None:
        return np.full(len(FIELDS), np.nan)
    record = data[identity["id"]] if isinstance(data, dict) else next(r for r in data if int(r["ID"]) == identity["id"])
    result = []
    for name in FIELDS:
        try:
            value = float(record[name])
        except (ValueError, KeyError, TypeError):
            value = np.nan
        lo, hi = (130, 230) if name == "Height" else (35, 150) if name == "Weight" else (1, 99)
        result.append(value if np.isfinite(value) and lo <= value <= hi else np.nan)
    return np.array(result)


def build_features(rows, games, mapping, data, feature_names):
    source = {int(r["ID"]): r for r in data}
    ability_cache = {p: ability(record, source) for p, record in mapping.items()}
    indexed = {g["id"]: g for g in games}
    if len(indexed) != len(games):
        raise ValueError("Duplicate native fixture")
    names = [prefix + field for prefix in ("own_", "opponent_", "gap_") for field in FIELDS] + [
        "own_known",
        "opponent_known_fraction",
        "opponent_exposure",
        "opponent_known_players",
        "opponent_games",
    ]
    schedule = sorted(games, key=lambda g: (g["date"], g["id"]))
    teams = defaultdict(list)
    x, cursor, previous = [], 0, None
    club_cache = {}
    audit = dict(rows=len(rows), coldOpponentRows=0, ownUnknownRows=0, projectedUnknownRows=0)
    for row in rows:
        cutoff = cutoff_for(row["date"])
        if previous is not None and cutoff < previous:
            raise ValueError("Forecast rows must be chronological")
        if cutoff != previous:
            club_cache.clear()
            previous = cutoff
        while cursor < len(schedule) and moment(schedule[cursor]["date"]) + timedelta(hours=48) < cutoff:
            game = schedule[cursor]
            for side in ("home", "away"):
                club = game[side]["slug"]
                members = []
                for player, p in game["players"].items():
                    minutes = p.get("mins")
                    if (
                        p.get("played") is True
                        and p.get("team") == club
                        and p.get("pos") in ("DEF", "MID", "FWD")
                        and type(minutes) in (float, int)
                        and np.isfinite(minutes)
                        and minutes > 0
                    ):
                        members.append((player, float(minutes), p["pos"]))
                teams[club].append((moment(game["date"]), members))
            cursor += 1
        game = indexed[row["game"]]
        if game["date"] != row["date"]:
            raise ValueError("Native target date differs")
        home = row["x"][feature_names.index("home")] > 0
        club = game["away" if home else "home"]["slug"]
        cache_key = club, row["pos"]
        if cache_key not in club_cache:
            recent = [(date, members) for date, members in teams[club] if cutoff - date <= timedelta(days=365)][-3:]
            exposure, positions = defaultdict(float), {}
            for _, members in recent:
                for player, minutes, pos in members:
                    exposure[player] += minutes / len(recent)
                    positions[player] = pos
            profiles = []
            weights = []
            for player, minutes in sorted(exposure.items()):
                profiles.append(ability_cache.get(player, np.full(len(FIELDS), np.nan)))
                weights.append(minutes / (0.25 + abs(DEPTH[row["pos"]] + DEPTH[positions[player]] - 1.2)))
            values = np.array(profiles).reshape(-1, len(FIELDS))
            weights = np.array(weights)
            known = np.isfinite(values)
            denominator = (known * weights[:, None]).sum(axis=0)
            projected = np.divide(
                (np.where(known, values, 0) * weights[:, None]).sum(axis=0),
                denominator,
                out=np.full(len(FIELDS), np.nan),
                where=denominator > 0,
            )
            covered = known.all(axis=1)
            fraction = float(weights[covered].sum() / weights.sum()) if weights.sum() else 0.0
            club_cache[cache_key] = projected, fraction, sum(exposure.values()), int(covered.sum()), len(recent)
        opponent, coverage, exposure, known_players, n = club_cache[cache_key]
        own = ability_cache.get(row["player"], np.full(len(FIELDS), np.nan))
        if moment(PUBLISHED) >= cutoff:
            own, opponent, coverage, known_players = np.full(len(FIELDS), np.nan), np.full(len(FIELDS), np.nan), 0.0, 0
        audit["coldOpponentRows"] += n == 0
        audit["ownUnknownRows"] += not np.isfinite(own).all()
        audit["projectedUnknownRows"] += not np.isfinite(opponent).all()
        x.append(
            np.r_[own, opponent, own - opponent, float(np.isfinite(own).all()), coverage, exposure, known_players, n]
        )
    return np.array(x), names, audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_physical_traits.json"))
    args = parser.parse_args()
    source = json.loads((args.cache / "cases.json").read_text())
    folder = args.cache / "physical-traits"
    csv_raw, raw = (folder / "players_fifa23.csv").read_bytes(), args.games.read_bytes()
    if hashlib.sha256(csv_raw).hexdigest() != CSV_SHA or hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Pinned physical/native source changed")
    meta = json.loads((folder / "commit_metadata.json").read_text())
    blob = hashlib.sha1(b"blob " + str(len(csv_raw)).encode() + b"\0" + csv_raw).hexdigest()
    if meta["commit"]["committer"]["date"] != PUBLISHED or blob != next(
        f["sha"] for f in meta["files"] if f["filename"] == "players_fifa23.csv"
    ):
        raise ValueError("Source commit time/blob differs")
    data = list(csv.DictReader(csv_raw.decode("utf-8-sig").splitlines()))
    aliases_raw = (args.cache / "player_names.json").read_bytes()
    aliases = json.loads(aliases_raw)
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    players = sorted({p for g in games for p in g["players"]})
    mapping = identities(players, aliases, data)
    identity_path = folder / "identities.json"
    identity_path.write_text(json.dumps(mapping, indent=2, ensure_ascii=True) + "\n")
    x, names, audit = build_features(source["rows"], games, mapping, data, source["features"])
    if x.shape != (38850, 35):
        raise ValueError("Full registered population/schema differs")
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + csv_raw
        + aliases_raw
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    feature_path = args.cache / "physical_trait_features.npz"
    np.savez_compressed(feature_path, key=key, source_key=source["key"], x=x, names=names)
    report = dict(
        scope="Source/identity/projected-physical ability only; no prediction improvement claimed",
        featureKey=key,
        sourceKey=source["key"],
        csvSha256=CSV_SHA,
        nativeSha256=NATIVE_SHA,
        identitySha256=hashlib.sha256(identity_path.read_bytes()).hexdigest(),
        featureSha256=hashlib.sha256(feature_path.read_bytes()).hexdigest(),
        audit=audit,
        sourcePlayers=len(data),
        uniqueSourcePlayers=len({r["ID"] for r in data}),
        nativePlayers=len(players),
        matchedNativePlayers=sum(v["id"] is not None for v in mapping.values()),
        identityStatus={
            s: sum(v["status"] == s for v in mapping.values()) for s in sorted({v["status"] for v in mapping.values()})
        },
        fields=list(FIELDS),
        rows=len(x),
        columns=len(names),
        warning="Third-party fixed 2022 game ratings are subjective ability proxies. Exact unique names are provisional identity evidence, not DOB corroboration; unmatched/ambiguous players retained. Commit metadata not independent historical web-archive proof.",
        stage="Independent full raw identity/35feature/time audit required before any outcome modeling",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print("PHYSICAL_TRAITS_BUILT " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
