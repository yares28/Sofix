import numpy as np

from app.research.score_mechanics_capped import bounded_locations


def test_simulated_exposure_never_exceeds_full_sorare_match_minutes():
    values = np.array([5, 15, 25, 35, 45, 55, 65, 75, 85, 90], dtype=float)
    pieces = {"minutes": np.array([88.0]), "locations": values[None, :, None]}
    minutes, locations = bounded_locations(pieces, np.zeros((1, 3), dtype=int), np.array([[-87.0, 0, 40]]), 1)
    np.testing.assert_array_equal(minutes, [[1, 88, 90]])
    np.testing.assert_allclose(locations, [[5, 88, 90]])


def test_ceiling_uses_maximum_tree_bin_without_inventing_linear_extrapolation():
    values = np.array([1, 2, 3, 4, 5, 6, 7, 8, 10, 20], dtype=float)
    pieces = {"minutes": np.array([90.0]), "locations": values[None, :, None]}
    minutes, locations = bounded_locations(pieces, np.zeros((1, 2), dtype=int), np.array([[-2.5, 10]]), 1)
    np.testing.assert_array_equal(minutes, [[87.5, 90]])
    np.testing.assert_allclose(locations, [[15, 20]])
