"""Test team-specific goal timing against a pooled match-flow control."""

import hashlib
import json
from collections import defaultdict
from functools import lru_cache

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_goal_context_rebuild import interval
from app.research.score_search import cutoff_for, moment
from app.research.score_substitution_clock import capture
from app.research.score_team_routine_shift import DELAY

STEM = "laliga_score_goal_timing_context"
PRIOR_GOALS = 24


def goal_bands(events):
    counts = np.zeros((2, 3), dtype=int)
    for minute, side in events:
        band = 0 if minute < 30 else 1 if minute < 60 else 2
        counts[int(side == "away"), band] += 1
    return counts


def fit_history(fixtures, first_lock):
    pooled = np.zeros((2, 3))
    attack, defend = defaultdict(lambda: np.zeros(3)), defaultdict(lambda: np.zeros(3))
    n = 0
    for kickoff, clubs, goals in fixtures:
        if moment(kickoff) + DELAY >= first_lock:
            continue
        n += 1
        pooled += goals
        for i, (own, opponent) in enumerate((clubs, clubs[::-1])):
            attack[own, i] += goals[i]
            defend[opponent, i] += goals[i]
    return (pooled + 1) / (pooled.sum(axis=1, keepdims=True) + 3), attack, defend, n


def profiles(clubs, bank):
    base, attack, defend, _ = bank
    revised = np.empty_like(base)
    for i, (own, opponent) in enumerate((clubs, clubs[::-1])):
        a, d = attack[own, i], defend[opponent, i]
        x = (a + PRIOR_GOALS * base[i]) / (a.sum() + PRIOR_GOALS)
        y = (d + PRIOR_GOALS * base[i]) / (d.sum() + PRIOR_GOALS)
        revised[i] = (x + y) / 2
    return base, revised


@lru_cache(maxsize=12000)
def state_probability(home, away):
    components = []
    for mu in (home, away):
        values = [np.exp(-mu)]
        for goal in range(1, 31):
            values.append(values[-1] * mu / goal)
        components.append(values)
    joint = np.outer(*components)
    return np.array([np.tril(joint, -1).sum(), joint.trace(), np.triu(joint, 1).sum()]) / joint.sum()


def errors(actual, rates, profile):
    observed = actual.cumsum(axis=1)[:, :2]
    prediction = rates[:, None] * profile.cumsum(axis=1)[:, :2]
    counts = prediction - observed * np.log(prediction)
    state = np.sign(observed[1] - observed[0]) + 1
    targets = np.eye(3)[state]
    probability = np.array([state_probability(h, a) for h, a in prediction.T])
    return float(counts.mean()), float(np.sum((targets - probability) ** 2, axis=1).mean())


def main():
    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, native.splitlines()) if g["date"] < "2026-01-01"]
    aliases = json.loads((ROOT / "player_names.json").read_bytes())
    observed = {}

    def inspect(g, events, detail):
        # Each valid match appears exactly once, independent of player coverage.
        assert g["id"] not in observed
        bands = goal_bands(events)
        np.testing.assert_array_equal(bands.sum(axis=1), [g["homeGoals"], g["awayGoals"]])
        observed[g["id"]] = bands

    _, _, digest = capture(games, aliases, observe_fixture=inspect)
    receipt = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    assert digest == receipt["archiveReadSHA"]
    cases = json.loads((ROOT / "cases.json").read_bytes())
    home, away = (cases["features"].index(f"match_lam_{s}") for s in ("h", "a"))
    rates = {}
    for row in cases["rows"]:
        if row["game"] in observed:
            pair = row["x"][home], row["x"][away]
            if row["game"] in rates:
                assert rates[row["game"]] == pair
            rates[row["game"]] = pair
    assert len(observed) == len(games)
    fixtures = [(g["date"], (g["home"]["slug"], g["away"]["slug"]), observed[g["id"]]) for g in games]
    results, grouped_gain, all_clocks = {}, [], []
    for phase, (start, stop) in PHASES.items():
        selected = [g for g in games if start <= g["date"] < stop]
        cutoffs = [cutoff_for(g["date"]) for g in selected]
        bank = fit_history(fixtures, min(cutoffs))
        forecast = []
        valid = 0
        for g in selected:
            pair = np.array(rates[g["id"]])
            available = np.all(np.isfinite(pair) & (pair > 0))
            valid += int(available)
            if not available:
                pair = np.array([1.45, 1.15])
            actual = observed[g["id"]]
            control, revised = profiles((g["home"]["slug"], g["away"]["slug"]), bank)
            forecast.append([errors(actual, pair, control), errors(actual, pair, revised if available else control)])
        array = np.array(forecast)
        grouped_gain.extend(array[:, 0, :] - array[:, 1, :])
        all_clocks.extend(cutoffs)
        results[phase] = dict(
            matches=len(selected),
            originalRatesAvailable=valid,
            fitMatches=bank[-1],
            cumulativeGoalLoss=array.mean(axis=0)[:, 0].tolist(),
            scoreStateBrier=array.mean(axis=0)[:, 1].tolist(),
        )
    gains = np.array(grouped_gain)
    ci = interval(gains[:, 1], np.array(all_clocks))
    stable = sum(
        r["cumulativeGoalLoss"][1] <= r["cumulativeGoalLoss"][0] and r["scoreStateBrier"][1] <= r["scoreStateBrier"][0]
        for r in results.values()
    )
    output = dict(
        sourceSHA=digest,
        goalClockFixtures=len(games),
        phases=results,
        scoreStateGain95=ci,
        pooledGoalLossGain=float(gains[:, 0].mean()),
        pooledStateGain=float(gains[:, 1].mean()),
        phasesWithoutLoss=stable,
        passEarlier=bool((gains.mean(axis=0) > 0).all() and stable >= 2 and ci[0] > 0),
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
