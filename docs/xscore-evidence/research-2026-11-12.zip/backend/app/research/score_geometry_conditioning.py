"""Testing only: paired old/corrected pass geometry added to frozen strong inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_ordinary as ordinary
from app.research import score_pass_geometry_corrected as geometry
from app.research import score_routine_conditioning_run as helpers
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval

REPORTS = (
    "laliga_score_match_context",
    "laliga_score_player_context",
    "laliga_score_stability",
    "laliga_score_ordinary",
    "laliga_score_match_empirical_density",
    "laliga_score_analogues",
)


def feature_arms(base, legacy, corrected, selected):
    if legacy.shape != corrected.shape or len(base) != len(legacy) or selected.shape != (legacy.shape[1],):
        raise ValueError("Matched full-population geometry arms required")
    return {
        "legacy_geometry": np.column_stack((base, legacy[:, selected])),
        "corrected_geometry": np.column_stack((base, corrected[:, selected])),
    }


def fitted(x, aa, levels, mask, path, key):
    if path.exists():
        with np.load(path) as f:
            if not np.array_equal(mask["fit"], f["fit"]) or not np.array_equal(mask["target"], f["target"]):
                raise ValueError("Geometry cached chronological masks differ")
        return components(path, key)
    classes, probability, parts = conditional.conditional_components(x, aa, levels, mask["fit"], mask["target"])
    np.savez_compressed(
        path,
        key=key,
        classes=classes,
        probability=probability,
        fit=mask["fit"],
        target=mask["target"],
        **{f"q{q}": values for q, values in parts.items()},
    )
    return classes, probability, parts


def load_inputs(args):
    source = json.loads((args.cache / "cases.json").read_text())
    reports = {name: json.loads((args.out.parent / (name + ".json")).read_text()) for name in REPORTS}
    if any(report["sourceKey"] != source["key"] for report in reports.values()):
        raise ValueError("Frozen original score-case references differ")
    feature_report = json.loads((args.out.parent / "laliga_score_pass_geometry_corrected.json").read_text())
    audit = json.loads((args.out.parent / "laliga_score_pass_geometry_corrected.integrity.json").read_text())
    if (
        audit["featureKey"] != feature_report["featureKey"]
        or audit["nativeSourceObservationsVerified"] != 34871
        or audit["independentlyRecomputedFeatureRows"] != len(source["rows"])
        or audit["independentlyRecomputedGeometryColumns"] != 42
        or not audit["actualFutureMutation"]["all166columnsExact"]
    ):
        raise ValueError("Corrected source/native/lag audit missing or different")
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    if feature_report["sourceKey"] != source["key"] or feature_report["featureKey"] not in plan["featureStage"]:
        raise ValueError("Registered geometry source stage differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
    helpers.validate_stat_identity(
        stat_key, reports["laliga_score_match_context"], reports["laliga_score_player_context"]
    )
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != reports["laliga_score_match_context"]["featureKey"]:
            raise ValueError("Original strong match-input key differs")
        full = np.column_stack((base, f["x"]))
    with np.load(args.cache / "player_context_features.npz") as f:
        if str(f["key"]) != feature_report["legacyKey"]:
            raise ValueError("Preserved old geometry input key differs")
        legacy, names = f["x"], f["names"].tolist()
    with np.load(args.cache / "pass_geometry_corrected_features.npz") as f:
        if str(f["key"]) != feature_report["featureKey"] or f["names"].tolist() != names:
            raise ValueError("Corrected geometry input key/schema differs")
        corrected, selected = f["x"], f["geometry"]
    if full.shape != (38850, 677) or legacy.shape != (38850, 166) or selected.sum() != 42:
        raise ValueError("Registered complete geometry input dimensions differ")
    np.testing.assert_array_equal(legacy[:, ~selected], corrected[:, ~selected])
    arms = feature_arms(full, legacy, corrected, selected)
    return (
        source,
        reports,
        arms,
        dict(statKey=stat_key, featureKey=feature_report["featureKey"], legacyKey=feature_report["legacyKey"]),
    )


def implementation_key(source, reports, provenance, plan, sklearn_version):
    modules = (empirical, flow, ordinary, geometry, helpers, stability, conditional)
    text = (
        source["key"]
        + json.dumps(provenance, sort_keys=True)
        + "".join(reports[n]["implementationKey"] for n in REPORTS)
        + sklearn_version
    )
    return hashlib.sha256(
        text.encode()
        + Path(__file__).read_bytes()
        + plan.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()


def reference(args, key, source, reports, cohort, phase, mask, previous, old):
    if cohort == "start":
        previous_rows, previous_old = previous
        pieces = stability.starter_control(previous_old, old, previous_rows, mask["first"])
        positions = np.array([r["pos"] for r, yes in zip(args.rows, mask["target"], strict=True) if yes])
        return empirical.empirical_predictions(*pieces[:3], positions, pieces[3], 20, 0.75, 0)
    return stability.analogue_control(args, key, source, reports["laliga_score_analogues"], phase, mask)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_geometry_conditioning.json"))
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, reports, all_inputs, provenance = load_inputs(args)
    key = implementation_key(source, reports, provenance, args.out.with_suffix(".plan.json"), sklearn.__version__)
    report = dict(
        scope="Research only; paired geometry source repair, not application change",
        sourceKey=source["key"],
        implementationKey=key,
        provenance=provenance,
        evidenceLimit="Repeated retrospective reuse, not fresh blind proof",
        cohorts={},
    )
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] != key:
            raise ValueError("Existing geometry study has a different frozen implementation")
        report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        if cohort in report["cohorts"]:
            continue
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        inputs = {name: x[keep] for name, x in all_inputs.items()}
        aa, level, y = (np.array([r[name] for r in rows]) for name in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        records = [
            dict(spec=dict(group=group, policy=policy, scope=scope), gains=[], errors=[], counts=[], periods={})
            for group in inputs
            for policy in ("ordinary", "events", "both")
            for scope in ("all", "defmid")
        ]
        previous, winner, best, audit = None, None, None, {}
        for phase, _, _ in stability.PHASES:
            if phase == "later2026" and winner is None:
                break
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(
                args,
                cohort,
                phase,
                reports["laliga_score_match_context"],
                reports["laliga_score_stability"],
                reports["laliga_score_ordinary"],
            )
            active = [winner] if phase == "later2026" else records
            current = {}
            for group in sorted({r["spec"]["group"] for r in active}):
                print(f"GEOMETRY_FIT {cohort} {phase} {group} inputs{inputs[group].shape[1]}", flush=True)
                current[group] = fitted(
                    inputs[group], aa, level, mask, args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}.npz", key
                )
            audit[phase] = dict(fit=int(mask["fit"].sum()), target=int(target.sum()), inputWidth=719)
            if previous is None:
                previous = target_rows, old, current
                continue
            previous_rows, previous_old, previous_models = previous
            control = reference(args, key, source, reports, cohort, phase, mask, (previous_rows, previous_old), old)
            expected = (
                reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else reports["laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"][
                    "cohorts"
                ][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("All-case original geometry-study control did not reproduce")
            audit[phase]["control"] = expected
            for group in sorted(current):
                for policy in ("ordinary", "events", "both"):
                    selected = [r for r in active if r["spec"]["group"] == group and r["spec"]["policy"] == policy]
                    if not selected:
                        continue
                    pieces = helpers.component_policy(old, current[group], policy)
                    previous_pieces = helpers.component_policy(previous_old, previous_models[group], policy)
                    bank = helpers.bank_from(previous_pieces, previous_rows, mask["first"])
                    raw_prediction = empirical.empirical_predictions(*pieces, positions[target], bank, 20, 0.75, 0)
                    for record in selected:
                        spec = record["spec"]
                        candidate = ordinary.scoped_prediction(
                            raw_prediction, control, positions[target], spec["scope"]
                        )
                        metric = measure(y[target], candidate)
                        if phase != "later2026":
                            gain = metric["within7"] - expected["within7"]
                            record["gains"].append(gain)
                            record["counts"].append(len(candidate))
                            record["errors"].append(metric["mae"])
                            record["periods"][phase] = dict(gain=gain, metrics=metric)
                        else:
                            alternate = candidate
                        np.savez_compressed(
                            args.cache
                            / f"{args.out.stem}_{cohort}_{phase}_{group}_{policy}_{spec['scope']}_prediction.npz",
                            key=key,
                            y=y[target],
                            prediction=candidate,
                            control=control,
                        )
                    print(f"GEOMETRY_TESTED {cohort} {phase} {group} {policy}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = dict(
                    implementationKey=key,
                    winner=winner,
                    best=best,
                    candidates=records,
                    passingCandidates=sum(min(r["gains"]) > 0 for r in records),
                )
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print(
                    "GEOMETRY_FROZEN "
                    + json.dumps(dict(cohort=cohort, accepted=bool(winner), spec=best["spec"], gains=best["gains"])),
                    flush=True,
                )
            previous = target_rows, old, current
        result = dict(
            selected="candidate" if winner else "control",
            winner=winner,
            candidate=best,
            candidateCount=len(records) + 1,
            earlierPeriods=audit,
            laterStatus="Evaluated frozen earlier winner"
            if winner
            else "Not evaluated: no candidate improved all three earlier periods",
        )
        if winner:
            if int(target.sum()) != {"start": 6754, "bench": 2925}[cohort]:
                raise ValueError("Full native final denominator changed")
            old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
            result.update(
                later=measure(y[target], alternate),
                candidateLater=measure(y[target], alternate),
                control=measure(y[target], control),
                gained=int((new_hit & ~old_hit).sum()),
                spoiled=int((old_hit & ~new_hit).sum()),
                gain95=paired_interval(y[target], alternate, control, [r["week"] for r in target_rows]),
                largeErrorsAbove25=int((np.abs(y[target] - alternate) > 25).sum()),
                positions={
                    p: measure(y[target][positions[target] == p], alternate[positions[target] == p])
                    for p in POSITIONS
                    if (positions[target] == p).any()
                },
            )
            np.savez_compressed(
                args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
                key=key,
                y=y[target],
                prediction=alternate,
                control=control,
            )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "GEOMETRY_RESULT "
            + json.dumps(
                dict(
                    cohort=cohort, selected=result["selected"], later=result.get("later"), status=result["laterStatus"]
                )
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
