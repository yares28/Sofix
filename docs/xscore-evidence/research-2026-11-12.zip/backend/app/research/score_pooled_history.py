"""Testing only: shared causal descriptors for retained native domestic/European outcomes."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import zipfile
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_europe_routine as routine
from app.research import score_europe_routine_history as history
from app.research import score_search, score_windows
from app.research import score_team_shape_history as modal
from app.research.score_search import cutoff_for, moment

POSITIONS = ("GK", "DEF", "MID", "FWD")
SCORE_NAMES = tuple("combined_" + n.removeprefix("euro_") for n in ordinary.NAMES)
NAMES = (*history.NAMES, *SCORE_NAMES, *("position_" + p for p in POSITIONS), "home", "source_is_euro")


def build_features(queries, records):
    if any(q.get("cohort") not in ("start", "bench") for q in queries):
        raise ValueError("Shared training query requires known native cohort")
    if any(
        q.get("pos") not in POSITIONS
        or type(q.get("home")) is not bool
        or q.get("source") not in ("laliga", "euro")
        or not q.get("player")
        or not q.get("club")
        for q in queries
    ):
        raise ValueError("Shared query native position/source/side identity missing")
    ordered = sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["player"]))
    locks = [cutoff_for(q["date"]) for q in queries]
    past, cursor = defaultdict(list), 0
    output = np.full((len(queries), len(NAMES)), np.nan)
    for i in sorted(range(len(queries)), key=lambda j: locks[j]):
        q, lock = queries[i], locks[i]
        while cursor < len(ordered) and moment(ordered[cursor]["date"]) + timedelta(hours=48) < lock:
            r = ordered[cursor]
            past[r["player"], r["pos"]].append(r)
            cursor += 1
        previous = [r for r in past[q["player"], q["pos"]] if moment(r["date"]) >= lock - timedelta(days=365)]
        values = []
        for source in history.SOURCES:
            eligible = [r for r in previous if source == "combined" or r["source"] == "euro"]
            for group in history.GROUPS:
                selected = [r for r in eligible if group == "same_position" or r["cohort"] == q["cohort"]]
                for n in history.WINDOWS:
                    summary = routine.summary(selected[-n:], lock, q["club"])
                    values.extend(summary[f] for f in routine.FIELDS)
        same = [r for r in previous if r["cohort"] == q["cohort"]]
        for selected in (previous, same):
            for n in (5, 15):
                values.extend(ordinary.summarise(selected, n, lock))
        values.extend(float(q["pos"] == p) for p in POSITIONS)
        values.extend((float(q["home"]), float(q["source"] == "euro")))
        output[i] = values
    if np.isinf(output).any():
        raise ValueError("Infinite shared-history feature")
    return output


def native_headers(corpus, archives):
    headers = {g["id"]: dict(date=g["date"], home=g["home"]["slug"], away=g["away"]["slug"]) for g in corpus["targets"]}
    for receipt in corpus["receipts"]:
        path = archives / receipt["archive"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != receipt["sha256"]:
            raise ValueError("Shared native archive source hash differs")
        with zipfile.ZipFile(path) as archive:
            for name in sorted(archive.namelist()):
                if not name.startswith("games/") or not name.endswith(".json"):
                    continue
                raw = json.loads(archive.read(name)).get("raw") or {}
                if raw.get("statusTyped") != "played":
                    continue
                header = dict(
                    date=raw.get("date"),
                    home=(raw.get("homeTeam") or {}).get("slug"),
                    away=(raw.get("awayTeam") or {}).get("slug"),
                )
                if not raw.get("id") or not all(header.values()):
                    continue
                if raw["id"] in headers and headers[raw["id"]] != header:
                    raise ValueError("Conflicting native fixture header")
                headers[raw["id"]] = header
    return headers


def make_queries(records, headers):
    queries, excluded = [], Counter()
    for r in records:
        if r["cohort"] not in ("start", "bench"):
            if r["source"] == "laliga":
                raise ValueError("Canonical LaLiga cohort cannot be excluded")
            excluded["unknownEuropeanCohort"] += 1
            continue
        h = headers.get(r["game"])
        if h is None or h["date"] != r["date"] or r["club"] not in (h["home"], h["away"]):
            raise ValueError("Shared native query fixture/date/playing-side mismatch")
        queries.append(
            {
                **{k: r[k] for k in ("game", "player", "date", "club", "pos", "cohort", "source")},
                "home": r["club"] == h["home"],
            }
        )
    return queries, dict(excluded)


def canonical_indices(rows, queries, records):
    lookup = {(q["game"], q["player"]): i for i, q in enumerate(queries)}
    native = {(r["game"], r["player"]): r for r in records}
    if len(lookup) != len(queries) or len(native) != len(records):
        raise ValueError("Duplicate native shared player-game")
    indices = []
    for row in rows:
        identity = row["game"], row["player"]
        i, r = lookup[identity], native[identity]
        if r["source"] != "laliga" or any(
            r[n] != row[n] for n in ("date", "cohort", "pos", "minutes", "score", "level")
        ):
            raise ValueError("Canonical shared LaLiga query identity/labels differ")
        if r["ordinary"]["kind"] != "exact" or abs(r["ordinary"]["point"] - row["aa"]) > 1e-10:
            raise ValueError("Canonical shared native AA differs")
        indices.append(i)
    return np.asarray(indices, dtype=int)


def implementation_key(source_key, routine_key, corpus_sha, plan):
    modules = (routine, ordinary, history, modal, score_search, score_windows)
    return hashlib.sha256(
        (source_key + routine_key + corpus_sha).encode()
        + Path(__file__).read_bytes()
        + plan.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "routine-cache", "routine-report", "archives", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, feature_report, audit = (
        json.loads(p.read_text())
        for p in (args.cases, args.routine_report, args.routine_report.with_suffix(".integrity.json"))
    )
    raw = args.routine_cache.with_suffix(".observations.json.gz").read_bytes()
    corpus = json.loads(gzip.decompress(raw))
    if (
        source["key"] != feature_report["sourceKey"]
        or corpus["key"] != audit["featureKey"]
        or feature_report["featureKey"] != corpus["key"]
        or not audit["all160ColumnsReproduced"]
        or audit["nativeObservationsVerified"] != len(corpus["records"])
    ):
        raise ValueError("Shared source requires full independently audited native routine corpus")
    plan = args.report.with_suffix(".plan.json")
    if corpus["key"] not in json.loads(plan.read_text())["source"]:
        raise ValueError("Shared source differs from registered plan")
    records = corpus["records"]
    headers = native_headers(corpus, args.archives)
    queries, excluded = make_queries(records, headers)
    indices = canonical_indices(source["rows"], queries, records)
    sha = hashlib.sha256(raw).hexdigest()
    key = implementation_key(source["key"], corpus["key"], sha, plan)
    print(f"SHARED_HISTORY_BUILD queries{len(queries)} observations{len(records)} inputs{len(NAMES)}", flush=True)
    x = build_features(queries, records)
    with np.load(args.routine_cache) as f:
        if str(f["key"]) != corpus["key"] or not np.array_equal(f["x"], x[indices, :160], equal_nan=True):
            raise ValueError("Shared LaLiga routine descriptors differ from independently audited inputs")
    np.savez_compressed(args.out, key=key, x=x, names=NAMES, canonical_indices=indices)
    args.out.with_suffix(".queries.json.gz").write_bytes(
        gzip.compress(json.dumps(dict(key=key, queries=queries), allow_nan=False).encode())
    )
    result = dict(
        scope="Testing-only shared native training source/features; no accuracy claim",
        sourceKey=source["key"],
        featureKey=key,
        routineFeatureKey=corpus["key"],
        routineCorpusSha256=sha,
        queries=len(queries),
        canonicalCases=len(indices),
        features=len(NAMES),
        excludedAdditionalTrainingQueries=excluded,
        queryCohorts=dict(Counter(q["source"] + ":" + q["cohort"] for q in queries)),
        exactAATrainingLabels=dict(
            Counter(
                r["source"] + ":" + r["cohort"]
                for r in records
                if r["cohort"] in ("start", "bench") and r["ordinary"]["kind"] == "exact"
            )
        ),
        allCanonicalRoutineInputsExactlyReproduced=True,
        limitations=json.loads(plan.read_text())["limitations"],
    )
    args.report.write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
