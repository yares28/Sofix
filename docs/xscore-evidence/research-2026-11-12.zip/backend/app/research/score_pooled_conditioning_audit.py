"""Testing only: native source-fit masks, frozen choices and all pooled score predictions."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_density_blend as density
from app.research import score_density_blend_run as reference_runner
from app.research import score_pooled_conditioning as conditioning
from app.research import score_pooled_conditioning_run as runner
from app.research import score_stability as stability
from app.research import score_team_shape_conditioning_run as policy_runner
from app.research.score_joint_density import components
from app.research.score_search import cutoff_for, measure, moment


def native_masks(queries, aa, levels, cohort, begin, first, classes, weight):
    available = np.array([moment(q["date"]).timestamp() + 172800 for q in queries])
    selected = np.array([q["cohort"] == cohort and q["date"] < begin for q in queries])
    selected &= available < cutoff_for(first).timestamp()
    europe = np.array([q["source"] == "euro" for q in queries])
    selected &= ~europe | (weight > 0)
    ds = selected & np.isin(levels, classes)
    ordinary = selected & np.isfinite(aa)
    weights = np.array([weight if q["source"] == "euro" else 1.0 for q in queries])
    receipt = dict(
        dsFitLaLiga=int((ds & ~europe).sum()),
        dsFitEurope=int((ds & europe).sum()),
        aaFitLaLiga=int((ordinary & ~europe).sum()),
        aaFitEurope=int((ordinary & europe).sum()),
        europeanDSOutsideLLSupport=int((selected & europe & ~np.isin(levels, classes)).sum()),
        europeanCensoredAA=int((selected & europe & ~np.isfinite(aa)).sum()),
        europeanWeight=float(weight),
    )
    return ds, ordinary, weights, receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "history-cache", "history-report", "routine-cache", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    args.out = args.report
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    feature, x, canonical_all, queries, aa, levels = runner.load_shared(args, source)
    reports = {n: json.loads((args.report.parent / (n + ".json")).read_text()) for n in runner.REPORTS}
    key = runner.implementation_key(
        source, feature["featureKey"], reports, args.report.with_suffix(".plan.json"), sklearn.__version__
    )
    if key != report["implementationKey"]:
        raise ValueError("Shared formula implementation/source/plan identity differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        canonical = canonical_all[keep]
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or frozen["winner"] != winner
            or frozen["best"] != best
            or result["candidate"] != best
            or result["winner"] != winner
            or (winner is not None) != (result["selected"] == "candidate")
            or len(frozen["candidates"]) != 108
        ):
            raise ValueError("Shared formula three-period freeze/choice/gate differs")
        old = {
            p: runner.flow.old_components(
                call,
                cohort,
                p,
                reports["laliga_score_match_context"],
                reports["laliga_score_stability"],
                reports["laliga_score_ordinary"],
            )
            for p, _, _ in stability.PHASES
        }
        bundles = {}
        source_counts = {}
        for phase, begin, _ in stability.PHASES:
            mask = masks[phase]
            groups = [best["spec"]["group"]] if phase == "later2026" else conditioning.GROUPS
            classes = np.unique(levels[canonical[mask["fit"]]])
            if not np.array_equal(classes, old[phase][0]):
                raise ValueError("Shared formula original LL-only native class support changed")
            for group in groups:
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{group}.npz"
                parts = components(path, key)
                ds, ordinary, weights, receipt = native_masks(
                    queries, aa, levels, cohort, begin, mask["first"], classes, conditioning.GROUPS[group]
                )
                with np.load(path) as f:
                    if (
                        not np.array_equal(ds, f["ds_fit"])
                        or not np.array_equal(ordinary, f["aa_fit"])
                        or not np.array_equal(weights, f["weights"])
                        or not np.array_equal(canonical[mask["target"]], f["target_indices"])
                        or json.loads(str(f["receipt"])) != receipt
                        or receipt != result["earlierPeriods"][phase]["groups"][group]
                        or not np.array_equal(ds[canonical], mask["fit"])
                        or not np.array_equal(ordinary[canonical], mask["fit"])
                    ):
                        raise ValueError("Independent native source-specific training masks/weights changed")
                if (
                    not np.array_equal(parts[0], classes)
                    or parts[1].shape != (int(mask["target"].sum()), len(classes))
                    or not np.isfinite(parts[1]).all()
                    or not np.allclose(parts[1].sum(axis=1), 1)
                    or any(v.shape != parts[1].shape or not np.isfinite(v).all() for v in parts[2].values())
                ):
                    raise ValueError("Shared fitted all-case probability/AA bundle is incomplete")
                bundles[phase, group] = parts
                source_counts[phase + ":" + group] = receipt
        reconstructed, mutated = 0, 0
        for i, (phase, _, _) in enumerate(stability.PHASES[1:], start=1):
            mask = masks[phase]
            target = mask["target"]
            previous_phase = stability.PHASES[i - 1][0]
            previous_rows = [r for r, yes in zip(rows, masks[previous_phase]["target"], strict=True) if yes]
            base_mass, control, _, _ = reference_runner.reference(call, key, source, cohort, phase, masks, reports)
            expected = (
                reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else reports["laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"][
                    "cohorts"
                ][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Shared formula exact original all-case control differs")
            active = [best] if phase == "later2026" else frozen["candidates"]
            for group, policy, spread in sorted(
                {(r["spec"]["group"], r["spec"]["policy"], r["spec"]["spread"]) for r in active}
            ):
                pieces = policy_runner.component_policy(old[phase], bundles[phase, group], policy)
                previous = policy_runner.component_policy(old[previous_phase], bundles[previous_phase, group], policy)
                bank = policy_runner.bank_from(previous, previous_rows, mask["first"])
                mass = conditioning.empirical_mass(*pieces, positions[target], bank, spread)
                if phase == "later2026":
                    changed_rows = copy.deepcopy(previous_rows)
                    unavailable = ~stability.previous_bank_mask(previous_rows, mask["first"])
                    for j in np.flatnonzero(unavailable):
                        changed_rows[j].update(aa=np.nan, level=100.0)
                    changed_bank = policy_runner.bank_from(previous, changed_rows, mask["first"])
                    repeated = conditioning.empirical_mass(*pieces, positions[target], changed_bank, spread)
                    if not np.array_equal(mass, repeated):
                        raise ValueError(
                            "Unavailable historical pooled calibration labels changed native probabilities"
                        )
                    mutated = int(unavailable.sum())
                for r in [
                    r
                    for r in active
                    if (r["spec"]["group"], r["spec"]["policy"], r["spec"]["spread"]) == (group, policy, spread)
                ]:
                    spec = r["spec"]
                    candidate, _ = density.forecast(
                        base_mass, mass, spec["weight"], control, positions[target], spec["scope"]
                    )
                    if phase == "later2026":
                        alternate = candidate
                    elif measure(y[target], candidate) != r["periods"][phase]["metrics"]:
                        raise ValueError("Shared formula earlier native forecast vector/metrics changed")
                    reconstructed += 1
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Shared formula final native query coverage/vector identity differs")
            for field, metric in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[metric]:
                    raise ValueError("Shared formula final exact native within7 metrics changed")
            h1, h0 = abs(f["alternate"] - y[target]) <= 7, abs(f["control"] - y[target]) <= 7
        receipt = dict(
            n=int(target.sum()),
            candidateCorrect=int(h1.sum()),
            controlCorrect=int(h0.sum()),
            gained=int((h1 & ~h0).sum()),
            lost=int((h0 & ~h1).sum()),
            candidateForecastsReconstructed=reconstructed,
            modelBundlesVerified=len(bundles),
            nativeFitMasksAndWeightsVerified=True,
            sourceCounts=source_counts,
            unavailableCalibrationLabelsMutated=mutated,
            earlierSelectionVerified=True,
            freezeSha256=hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        )
        if args.refit_final:
            phase, begin, _ = stability.PHASES[-1]
            group = best["spec"]["group"]
            ds, ordinary, weights, _ = native_masks(
                queries, aa, levels, cohort, begin, masks[phase]["first"], old[phase][0], conditioning.GROUPS[group]
            )
            hidden_aa, hidden_levels = aa.copy(), levels.copy()
            hidden_aa[~ordinary] = np.nan
            hidden_levels[~(ds | ordinary)] = np.nan
            print(f"POOLED_AUDIT_REFIT {cohort} {group}", flush=True)
            repeated = conditioning.fitted_components(
                x, hidden_aa, hidden_levels, ds, ordinary, weights, canonical[target], old[phase][0]
            )
            saved = bundles[phase, group]
            if (
                not np.array_equal(repeated[0], saved[0])
                or not np.allclose(repeated[1], saved[1], atol=1e-12, rtol=0)
                or any(not np.allclose(repeated[2][q], saved[2][q], atol=1e-10, rtol=0) for q in saved[2])
            ):
                raise ValueError("Actual shared final4model refit changed without outside-training outcomes")
            receipt["realRefitWithoutOutsideOutcomes"] = dict(
                all4FittedModelsReproduced=True,
                outsideAAFitLabelsBlanked=int((~ordinary).sum()),
                outsideBothTrainingSetsDSLabelsBlanked=int((~(ds | ordinary)).sum()),
                dsFitCases=int(ds.sum()),
                aaFitCases=int(ordinary.sum()),
                forecastCases=int(target.sum()),
            )
        evidence[cohort] = receipt
    output = dict(
        scope="Testing-only native source masks/forecasts/freeze/full actual refit audit; no fresh blind claim",
        implementationKey=key,
        cohorts=evidence,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
