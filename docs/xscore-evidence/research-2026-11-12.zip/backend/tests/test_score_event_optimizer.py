import json
from pathlib import Path

import numpy as np

from app.research.score_event_probability_robust import calibrate


def test_real_small_poisson_fit_does_not_abort_at_line_search_precision_limit():
    fixture = json.loads((Path(__file__).parent / "fixtures" / "event_optimizer_case.json").read_text())
    raw, target = np.array(fixture["raw"]), np.array(fixture["target"])
    prior = np.array(fixture["prior"])
    beta, stats = calibrate(raw, target, fixture["ridge"], prior)
    assert stats["converged"] is True and np.isfinite(beta).all()
    x = np.column_stack((np.ones(len(raw)), np.log(np.clip(raw, 1e-8, 20))))
    gradient = x.T @ (np.exp(x @ beta) - target) + fixture["ridge"] * (beta - prior)
    projected = beta - np.clip(beta - gradient, [-3, 0.25], [3, 2])
    assert np.max(np.abs(projected)) < 1e-5
