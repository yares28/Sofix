import numpy as np

from app.research.score_candidate_rank import candidate_frame, choose_candidate


def test_candidates_include_low_and_high_outcomes_without_actual_outcomes():
    classes = np.array([35, 80])
    probability = np.array([[0.6, 0.4]])
    parts = {q: np.zeros((1, 2)) for q in (0.35, 0.5, 0.65)}
    x, scores, p = candidate_frame(np.zeros((1, 2)), classes, probability, parts)
    assert set(scores[0]) == {35, 80}
    assert x.shape[0] == 6
    np.testing.assert_array_equal(p[0], [0.6] * 3 + [0.4] * 3)
    pred = choose_candidate(scores, np.array([[0.1] * 3 + [0.8] * 3]), p, 0, np.array([35.0]))
    assert pred[0] == 80


def test_floor_and_zero_quantiles_are_kept():
    classes = np.array([0, 60, 100])
    parts = {q: np.full((1, 3), -20.0) for q in (0.35, 0.5, 0.65)}
    _, scores, _ = candidate_frame(np.zeros((1, 1)), classes, np.full((1, 3), 1 / 3), parts)
    np.testing.assert_array_equal(scores[0], [0] * 3 + [60] * 3 + [100] * 3)


def test_ties_choose_existing_candidate_near_anchor_not_an_average():
    scores = np.array([[40.0, 80]])
    pred = choose_candidate(scores, np.ones((1, 2)), np.full((1, 2), 0.5), 0, np.array([55.0]))
    assert pred[0] == 40
