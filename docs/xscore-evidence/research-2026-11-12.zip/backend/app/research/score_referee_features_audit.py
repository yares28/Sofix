"""Independent raw native-stat referee histories and actual future-data mutation."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_referee_features as primary
from app.research.score_search import cutoff_for, moment


def normal(value):
    text = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return " ".join(re.findall("[a-z]+", text.casefold()))


def independent_groups(labels):
    mapped = {}
    complete = {}
    for text in labels:
        if "," in text:
            family, given = text.split(",")
            given, family = normal(given), normal(family)
            core = family.rsplit(" ", 1)[0] if " " in family else family
            mapped[text] = given + " " + core
            complete[given + " " + family] = mapped[text]
    for text in labels:
        if text not in mapped:
            mapped[text] = complete.get(normal(text), normal(text))
    return mapped


def raw_stats(game):
    participants = [p for p in game.get("players", {}).values() if p.get("played") is True]
    home, away = game["home"]["slug"], game["away"]["slug"]
    if home == away:
        return None
    for club in [home, away]:
        if sum(p.get("team") == club and p.get("started") is True for p in participants) != 11:
            return None
    stats = []
    for p in participants:
        if (
            p.get("team") not in [home, away]
            or p.get("pos") not in ["GK", "DEF", "MID", "FWD"]
            or p.get("ver") != 7
            or type(p.get("started")) is not bool
            or not isinstance(p.get("stats"), dict)
        ):
            return None
        minutes = p.get("mins")
        if type(minutes) not in (int, float) or not np.isfinite(minutes) or minutes < 0:
            return None
        if p["pos"] == "GK":
            continue
        values = {}
        for name in ["fouls", "was_fouled", "yellow_card", "red_card", "penalty_conceded", "duel_won", "duel_lost"]:
            pair = p["stats"].get(name, [0, 0])
            if not isinstance(pair, (tuple, list)) or len(pair) != 2:
                return None
            value = pair[0]
            if type(value) not in (int, float) or not np.isfinite(value) or value < 0 or value != int(value):
                return None
            values[name] = value
        stats.append(dict(pos=p["pos"], club=p["team"], minutes=minutes, **values))
    minutes = sum(p["minutes"] for p in stats)
    if minutes <= 0:
        return None
    defenders = [p for p in stats if p["pos"] == "DEF"]
    return np.array(
        [
            minutes,
            *[sum(p[k] for p in stats) for k in ["fouls", "was_fouled", "yellow_card", "red_card", "penalty_conceded"]],
            sum(p["duel_won"] for p in defenders),
            sum(p["duel_lost"] for p in defenders),
            sum(p["minutes"] for p in defenders),
            sum(p["fouls"] for p in defenders),
            sum(p["fouls"] for p in stats if p["club"] == home),
            sum(p["fouls"] for p in stats if p["club"] == away),
        ],
        dtype=float,
    )


def main():
    root = Path("data/raw/score-foundation")
    reports = Path("reports/experiments")
    source = json.loads((root / "cases.json").read_text())
    report = json.loads((reports / "laliga_score_referee_features.json").read_text())
    archive_path = reports / "laliga_score_referee_archive.json"
    archive = json.loads(archive_path.read_text())
    archive_audit_path = reports / "laliga_score_referee_archive.integrity.json"
    archive_audit = json.loads(archive_audit_path.read_text())
    if (
        archive_audit["implementationKey"] != archive["implementationKey"]
        or archive_audit["nativeFixtureChoices"] != 1238
    ):
        raise ValueError("Completed entire source audit required")
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    raw = native.read_bytes()
    if hashlib.sha256(raw).hexdigest() != report["nativeSHA"]:
        raise ValueError("Native source bytes changed")
    key = hashlib.sha256(
        Path(primary.__file__).read_bytes()
        + (reports / "laliga_score_referee_features.plan.json").read_bytes()
        + archive_path.read_bytes()
        + archive_audit_path.read_bytes()
        + source["key"].encode()
        + raw
    ).hexdigest()
    matrix_path = root / "referee_features.npz"
    if key != report["featureKey"] or hashlib.sha256(matrix_path.read_bytes()).hexdigest() != report["matrixSHA"]:
        raise ValueError("Frozen feature identity differs")
    with np.load(matrix_path) as z:
        if str(z["key"]) != key or str(z["source_key"]) != source["key"]:
            raise ValueError("Feature source row identity differs")
        actual = z["x"].copy()
    games = [json.loads(v) for v in raw.decode("utf-8").splitlines()]
    indexed = {g["id"]: g for g in games}
    if len(indexed) != 1238 or actual.shape != (38850, 13):
        raise ValueError("Entire feature population differs")
    choices = {r["game"]: r for r in archive["fixtureChoices"]}
    labels = {r[k]["referee"] for r in choices.values() for k in ["prelock", "pregame"] if r[k] is not None}
    groups = independent_groups(labels)
    if groups != report["audit"]["nameGroups"]:
        raise ValueError("Independent published-name group categories differ")
    native_stats = {g["id"]: raw_stats(g) for g in games}
    histories = defaultdict(list)
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        selected = choices[g["id"]]["pregame"]
        if selected is None:
            continue
        at = moment(g["date"])
        if moment(selected["availableUTC"]) >= at:
            raise ValueError("Historical announcement after past kickoff")
        histories[groups[selected["referee"]]].append(g["id"])
    expected = []
    cached = {}
    home_i = source["features"].index("home")
    for row in source["rows"]:
        cutoff = cutoff_for(row["date"])
        current = choices[row["game"]]["prelock"]
        if current is None:
            expected.append([0, 0, 0, *([np.nan] * 10)])
            continue
        if moment(current["availableUTC"]) >= cutoff:
            raise ValueError("Current source is not prelock")
        group = groups[current["referee"]]
        cachekey = group, cutoff
        if cachekey not in cached:
            selected = [
                g
                for g in histories[group]
                if moment(indexed[g]["date"]) + timedelta(hours=48) < cutoff
                and cutoff - moment(indexed[g]["date"]) <= timedelta(days=365)
            ][-10:]
            good = [g for g in selected if native_stats[g] is not None]
            rates = [np.nan] * 9
            age = np.nan
            if good:
                total = np.sum([native_stats[g] for g in good], axis=0)
                for j in range(5):
                    rates[j] = total[j + 1] / total[0] * 90
                w, lost, minutes, def_fouls, home, away = total[6:]
                rates[5] = w / (w + lost) if w + lost > 0 else np.nan
                rates[6] = (w + lost) / minutes * 90 if minutes > 0 else np.nan
                rates[7] = def_fouls / (w + lost) if w + lost > 0 else np.nan
                rates[8] = (home - away) / (home + away) if home + away > 0 else np.nan
                age = (cutoff - max(moment(indexed[g]["date"]) for g in good)).total_seconds() / 86400
            cached[cachekey] = [1, len(selected), len(good), age, *rates]
        values = list(cached[cachekey])
        values[-1] *= 1 if row["x"][home_i] > 0 else -1
        expected.append(values)
    np.testing.assert_allclose(actual, np.array(expected), rtol=0, atol=1e-12, equal_nan=True)
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    selected = np.array([cutoff_for(r["date"]) == first for r in source["rows"]])
    poisoned = deepcopy(games)
    changed = 0
    for g in poisoned:
        if moment(g["date"]) + timedelta(hours=48) >= first:
            g["players"] = {}
            g.pop("xi", None)
            g["homeGoals"] = -999
            g["awayGoals"] = -999
            changed += 1
    rows = [r for r, keep in zip(source["rows"], selected, strict=True) if keep]
    rebuilt, _, _ = primary.feature_rows(rows, poisoned, archive, source["features"])
    np.testing.assert_array_equal(rebuilt, actual[selected])
    receipt = dict(
        status="COMPLETE independent all-native referee history feature audit",
        featureKey=key,
        nativeCasesVerified=len(actual),
        independentColumns=13,
        nativeStatFixtures=len(games),
        publishedNameGroups=len(set(groups.values())),
        independentPublishedNameGroups=True,
        independentAllHistoricalCountsAndRates=True,
        independentStrictHistorySelection=True,
        actualFutureMutation=dict(changedFixtures=changed, firstLockRows=len(rows), all13ColumnsExact=True),
        modelFits=0,
    )
    (reports / "laliga_score_referee_features.integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("REFEREE_FEATURES_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
