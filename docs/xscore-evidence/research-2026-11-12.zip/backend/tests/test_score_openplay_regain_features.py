import numpy as np

from app.research.score_openplay_regain_features import fixture_context


def event(tick, team, kind, period="FirstHalf", outcome="Successful"):
    return {
        "tick": str(tick),
        "team": team,
        "kind": kind,
        "period": period,
        "outcome": outcome,
        "player": team,
        "x": "10",
    }


def test_regain_after_opponent_pass_and_retention_use_regainer_pitch_frame():
    rows = [event(11, "a", "Pass", outcome="Unsuccessful"), event(14, "b", "Interception"), event(17, "b", "Pass")]
    players, teams, allowed, _, audit = fixture_context(rows, "a", "b", {("b", "b"): "player"})
    np.testing.assert_array_equal(players["player"][1, 0], [1, 1, 1, 1, 1])
    np.testing.assert_array_equal(teams["b"][1, 0], [1, 1, 1, 1, 1])
    assert allowed["a"][1, 0] == 1 and allowed["b"].sum() == 0
    assert audit["mappedAnchors"] == audit["retained"] == 1


def test_unordered_same_second_and_stoppages_do_not_become_live_context():
    rows = [
        event(10, "a", "Pass"),
        event(11, "b", "BallRecovery"),
        event(11, "a", "Pass"),
        event(25, "a", "Pass"),
        event(26, "a", "Stop"),
        event(27, "b", "BallRecovery"),
        event(35, "b", "Pass", period="SecondHalf"),
    ]
    _, teams, allowed, _, audit = fixture_context(rows, "a", "b", {})
    assert audit["sameSecondAmbiguousAnchors"] == 1
    np.testing.assert_array_equal(teams["b"][0, 0], [2, 0, 0, 0, 0])
    assert allowed["a"].sum() == 0
