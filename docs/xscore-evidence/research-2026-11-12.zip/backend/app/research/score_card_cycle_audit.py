"""Independently rebuild card-based predictions before reading participation labels."""

import hashlib
import json
from collections import Counter, defaultdict
from datetime import timedelta

import numpy as np

from app.research.score_absence_role_audit import lock_time
from app.research.score_card_cycle import NATIVE, NATIVE_SHA, PHASES, REPORTS, STEM, freeze
from app.research.score_search import moment


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = sorted(
        (g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"),
        key=lambda g: (g["date"], g["id"]),
    )
    indexed = {g["id"]: g for g in games}
    kicks = {g["id"]: moment(g["date"]) for g in games}
    ready = {i: t + timedelta(days=2) for i, t in kicks.items()}
    locks = {g["id"]: lock_time(g["date"]) for g in games}
    by_club, by_name, card_sheets = defaultdict(list), defaultdict(list), defaultdict(list)
    totals = Counter()
    for g in games:
        i = g["id"]
        season = kicks[i].year - (kicks[i].month <= 6)
        for side in ("home", "away"):
            by_club[g[side]["slug"]].append(i)
        for p, record in g["players"].items():
            if record.get("ver") != 7:
                continue
            if record.get("played") is True:
                by_name[p].append((i, record["team"]))
            sheet = record.get("stats")
            if not isinstance(sheet, dict) or sheet.get("yellow_card", [0])[0] == 0:
                continue
            assert sheet["yellow_card"][0] == 1
            if sheet.get("red_card", [0])[0] > 0:
                totals["excludedRedYellow"] += 1
                continue
            card_sheets[season, p].append((i, record["team"]))
            totals["singleYellow"] += 1
            totals["unusedBenchYellow"] += record["played"] is not True
    path = REPORTS / f"{STEM}.forecasts.json"
    record = json.loads(path.read_text())
    assert record["nativeSHA"] == NATIVE_SHA and record["countedEvents"] == dict(totals)
    reported = {(p["player"], p["origin"], p["target"]): p for p in record["predictions"]}
    assert len(reported) == len(record["predictions"])
    seen = set()
    for (season, p), entries in card_sheets.items():
        for j in range(4, len(entries), 5):
            origin, club = entries[j]
            new = [
                i for i in by_club[club] if kicks[i] > kicks[origin] and kicks[i].year - (kicks[i].month <= 6) == season
            ]
            if not new:
                continue
            target = new[0]
            phase = next((n for n, (a, b) in PHASES.items() if a <= indexed[target]["date"] < b), None)
            if phase is None:
                continue
            key = p, origin, target
            row = reported[key]
            seen.add(key)
            assert (row["season"], row["club"], row["phase"], row["countedCards"]) == (season, club, phase, j + 1)
            assert row["cycleCards"] == [i for i, _ in entries[j - 4 : j + 1]]
            assert moment(row["available"]) == ready[origin] and moment(row["lock"]) == locks[target]
            if ready[origin] >= locks[target]:
                assert row["status"] == "late"
                continue
            past_clubs = [c for i, c in by_name[p] if ready[i] < locks[target]]
            if not past_clubs or past_clubs[-1] != club:
                assert row["status"] == "no_eligible_current_club"
                continue
            assert row["status"] == "timely"
            last3 = [i for i in by_club[club] if ready[i] < locks[target]][-3:]
            observations = [indexed[i]["players"].get(p, {}) for i in last3]
            minutes = sum(v["mins"] for v in observations if v.get("played") is True and v["team"] == club) / len(last3)
            np.testing.assert_allclose(minutes, row["projectedPriorMinutes"], rtol=0, atol=1e-12)
    assert seen == reported.keys()
    mutations = []
    for phase in PHASES:
        lock = min(moment(r["lock"]) for r in reported.values() if r["phase"] == phase and r["status"] == "timely")
        poisoned = [dict(g, players={}) if ready[g["id"]] >= lock else g for g in games]
        affected = [r for r in reported.values() if r["status"] == "timely" and moment(r["lock"]) == lock]
        trial, _ = freeze(poisoned)
        fresh = [r for r in trial if r["status"] == "timely" and moment(r["lock"]) == lock]
        assert affected == fresh
        mutations.append(dict(phase=phase, exactCandidates=len(fresh), lock=lock.isoformat()))

    official_raw = (REPORTS / "laliga_score_suspension_candidates.json").read_text()
    official = [
        r for r in json.loads(official_raw)["candidates"] if r["status"] == "pending_amendment_and_appeal_check"
    ]
    official += json.loads((REPORTS / "laliga_score_suspension_corroborated.json").read_text())["rows"]
    official_overlap = []
    for r in official:
        key = r["player"], r["origin"], r["target"]
        match = reported.get(key, {})
        official_overlap.append(
            dict(
                player=r["player"],
                target=r["target"],
                origin=r["origin"],
                officialSource=r["source"],
                counterState=match.get("status", "not_flagged"),
            )
        )
    # All forecast inputs have been reconstructed before comparing any label.
    periods = {}
    for phase in PHASES:
        selected = [r for r in reported.values() if r["phase"] == phase]
        timely = [r for r in selected if r["status"] == "timely"]
        regular = [r for r in timely if r["projectedPriorMinutes"] >= 15]

        def metrics(rows):
            misses, conflicting = 0, []
            for r in rows:
                actual = indexed[r["target"]]["players"].get(r["player"], {})
                absent = not (actual.get("played") is True and actual["team"] == r["club"])
                misses += absent
                if not absent:
                    conflicting.append(dict(player=r["player"], target=r["target"], origin=r["origin"]))
            return dict(
                count=len(rows),
                didNotPlay=misses,
                nonparticipationRate=misses / len(rows) if rows else None,
                conflictingAppearances=conflicting,
            )

        periods[phase] = dict(allCandidates=len(selected), timely=metrics(timely), recentRegulars=metrics(regular))
    gate = all(
        p["recentRegulars"]["count"] >= 20 and p["recentRegulars"]["nonparticipationRate"] >= 0.8
        for p in periods.values()
    )
    result = dict(
        key=record["key"],
        forecastSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        independentEarlierCandidateRows=len(seen),
        futureSheetMutation=mutations,
        officialMatchedIdentities=len(official),
        officialTimelyExactMatches=sum(r["counterState"] == "timely" for r in official_overlap),
        officialOverlap=official_overlap,
        later2026Evaluated=False,
        passesEarlierParticipationGate=gate,
        periods=periods,
    )
    (REPORTS / f"{STEM}.json").write_text(json.dumps(result, indent=2) + "\n")
    compact = {
        phase: {k: v for k, v in info["recentRegulars"].items() if k != "conflictingAppearances"}
        for phase, info in periods.items()
    }
    print(
        json.dumps(
            dict(
                regulars=compact,
                gate=gate,
                officialMatches=result["officialTimelyExactMatches"],
                officialMatchedIdentities=len(official),
                independentCandidateRows=len(seen),
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
