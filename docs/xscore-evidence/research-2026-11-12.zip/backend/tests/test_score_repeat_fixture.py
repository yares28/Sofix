from datetime import UTC, datetime, timedelta

import numpy as np

from app.research.score_repeat_fixture import overlap, pair_history, player_history
from app.research.score_repeat_fixture_long import matchup_context
from app.research.score_table_tempo import make_examples


def test_missing_lineups_remain_separate_from_no_overlap():
    players = {str(n) for n in range(11)}
    assert overlap(None, players) is None
    assert overlap(set(), players) == 0
    assert overlap(players, players) == 1


def test_repeat_history_shrinks_and_keeps_missing_zero():
    lock = datetime(2025, 1, 1, tzinfo=UTC)
    assert not pair_history([], lock, None, None).any()
    earlier = lock - timedelta(days=30)
    value = player_history([(earlier, np.array([9, 12, 6]))], lock)
    assert 0 < value[1] < 9 and value[0] > 0


def test_repeat_fixture_requires_strict_prior_knowledge():
    clubs = [str(i) for i in range(20)]
    rows = [
        ("2025-01-04T14:00:00Z", "2425", clubs[0], clubs[1], [3, 0, 8, 1], False),
        ("2025-01-06T20:00:00Z", "2425", clubs[0], clubs[1], [1, 1, 4, 4], False),
        ("2025-01-10T20:00:00Z", "2425", clubs[0], clubs[1], [1, 1, 4, 4], False),
    ]
    rows.extend(("2025-02-01T20:00:00Z", "2425", clubs[i], clubs[i + 1], [1, 1, 4, 4], False) for i in range(2, 20, 2))
    context = matchup_context(rows, make_examples(rows))
    np.testing.assert_array_equal(context[:4, 2], [0, 0, 0, 0])
    assert (context[4:6, 2] > 0).all()
