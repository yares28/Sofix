"""Qualify and lag sustained passing-run pressure from the Openplay archive."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
from collections import Counter, defaultdict, deque
from datetime import timedelta
from itertools import groupby
from pathlib import Path

import numpy as np

from app.research.score_openplay_duel_signal import native_archive
from app.research.score_openplay_duel_source import SHA, source_fixtures
from app.research.score_search import cutoff_for, moment

METRICS = ("passes", "sustainedRuns", "entries", "shots", "pressure")
FLOW_FEATURES = 4 * len(METRICS) + 2


def fixture_runs(events, home, away):
    results = {team: np.zeros(len(METRICS)) for team in (home, away)}
    audit = Counter()
    for _, half in groupby(events, lambda e: e["period"]):
        previous, run_team, run_length, entered = None, None, 0, False
        for tick, members in groupby(half, lambda e: int(e["tick"])):
            group = list(members)
            if previous is not None and tick < previous:
                raise ValueError("Source event clock is unsorted")
            for e in group:
                if e["team"] not in results:
                    raise ValueError("Event team differs from matched fixture")
                if e["kind"] == "complete":
                    results[e["team"]][0] += 1
            teams, kinds = {e["team"] for e in group}, {e["kind"] for e in group}
            if len(teams) != 1 or "break" in kinds or len(kinds) != 1 or (kinds == {"shot"} and len(group) > 1):
                audit["ambiguousActionTicks"] += len(group) > 1 and bool({"complete", "shot"} & kinds)
                run_team, run_length, entered = None, 0, False
                previous = tick
                continue
            team, kind = group[0]["team"], group[0]["kind"]
            if previous is None or tick - previous > 8 or team != run_team:
                run_team, run_length, entered = team, 0, False
            if kind == "shot":
                results[team][3] += run_length >= 2
                run_team, run_length, entered = None, 0, False
            else:
                old_length = run_length
                run_length += len(group)
                results[team][1] += old_length < 3 <= run_length
                # A tied tick does not establish which pass reached the threshold first.
                enough = old_length >= 2 if len(group) == 1 else old_length >= 3
                for e in group:
                    if e["x"] in ("", "NULL") or e["end_x"] in ("", "NULL"):
                        audit["completedPassesMissingCoordinates"] += 1
                    elif not entered and enough and float(e["x"]) < 100 / 3 * 2 <= float(e["end_x"]):
                        results[team][2] += 1
                        entered = True
            previous = tick
    for values in results.values():
        values[4] = values[2] + 2 * values[3]
    return results, audit


def team_modes(home, away):
    share = (home + 4) / (home + away + 8)
    mode = 0 if share < 0.38 else 2 if share > 0.62 else 1
    return mode, 2 - mode


def event_stream(directory):
    sql = """
      SELECT match_id,team_id AS team,period,60*minute+second AS tick,x,end_x,
        CASE WHEN type='Pass' AND outcome='Successful' AND NOT
          (coalesce(q_ThrowIn,false) OR coalesce(q_FreekickTaken,false) OR coalesce(q_GoalKick,false)
           OR coalesce(q_CornerTaken,false) OR coalesce(q_IndirectFreekickTaken,false)) THEN 'complete'
          WHEN is_shot THEN 'shot' ELSE 'break' END AS kind
      FROM read_parquet('events_esp_*.parquet',union_by_name=true)
      WHERE period IN ('FirstHalf','SecondHalf') AND
        (type IN ('Pass','BallRecovery','Interception','Dispossessed','Foul','OffsidePass',
                  'CornerAwarded','Start','End','SubstitutionOn','SubstitutionOff','Card')
          OR (type='TakeOn' AND outcome='Unsuccessful') OR is_shot)
      ORDER BY match_id,period,tick
    """
    with subprocess.Popen(
        [str(directory.resolve() / "duckdb.exe"), "-batch", "-csv", "-c", sql],
        cwd=directory,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
    ) as process:
        if process.stdout is None or process.stderr is None:
            raise ValueError("Source reader pipes unavailable")
        for key, events in groupby(csv.DictReader(process.stdout), lambda e: e["match_id"]):
            yield key, list(events)
        error = process.stderr.read()
        if process.wait():
            raise ValueError(f"Source reader failed: {error}")


def observations(directory, games):
    for name, expected in SHA.items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Unverified archive input: {name}")
    fixtures, _, _ = source_fixtures(directory, list(games.values()))
    records, counts = {}, Counter()
    for match_id, events in event_stream(directory):
        if match_id not in fixtures:
            continue
        game, f = fixtures[match_id]
        h, a = f["home_team_id"], f["away_team_id"]
        values, audit = fixture_runs(events, h, a)
        if not all(x[0] > 0 for x in values.values()):
            raise ValueError("Missing usable team event stream")
        counts.update(audit)
        for record in values.values():
            counts.update({name: int(v) for name, v in zip(METRICS, record, strict=True)})
        records[game["id"]] = (values[h], values[a])
    if len(records) != len(fixtures):
        raise ValueError("Matched fixtures missing passing runs")
    return records, dict(counts)


def rolling(rows, games, records):
    queue = sorted((moment(games[k]["date"]) + timedelta(hours=48), k) for k in records)
    history = defaultdict(lambda: deque(maxlen=8))
    out = np.empty((len(rows), FLOW_FEATURES))
    cursor = 0
    for lock, i in sorted((cutoff_for(row["date"]), i) for i, row in enumerate(rows)):
        while cursor < len(queue) and queue[cursor][0] < lock:
            available, key = queue[cursor]
            cursor += 1
            home, away = records[key]
            game = games[key]
            for side, values in (("home", np.r_[home, away]), ("away", np.r_[away, home])):
                history[game[side]["slug"]].append((available, values))
        row = rows[i]
        game = games[row["game"]]
        sides = game["home"]["slug"], game["away"]["slug"]
        club = game["players"][row["player"]]["team"]
        if club not in sides or row["date"] != game["date"]:
            raise ValueError("Case fixture or team differs")
        cutoff = lock - timedelta(days=118)
        teams = [club, sides[1 - sides.index(club)]]
        past = [[v for t, v in history[team] if t >= cutoff] for team in teams]
        out[i] = np.r_[
            *[np.mean(p, axis=0) if p else np.full(2 * len(METRICS), np.nan) for p in past], [len(p) for p in past]
        ]
    return out


def run(args):
    source = json.loads((args.cache / "cases.json").read_text())
    games = native_archive(args.games)
    directory = args.cache / "openplay-data-v0.1.0"
    records, audit = observations(directory, games)
    rows = source["rows"]
    features = rolling(rows, games, records)
    modes = {key: team_modes(h[-1], a[-1]) for key, (h, a) in records.items()}
    mode = np.array(
        [
            modes[r["game"]][int(games[r["game"]]["players"][r["player"]]["team"] == games[r["game"]]["away"]["slug"])]
            if r["game"] in modes
            else -1
            for r in rows
        ]
    )
    first = min(cutoff_for(r["date"]) for r in rows if r["date"] >= "2026-01-01")
    ids = [i for i, r in enumerate(rows) if cutoff_for(r["date"]) == first]
    past = {key: v for key, v in records.items() if moment(games[key]["date"]) + timedelta(hours=48) < first}
    stubs = {key: games[key] for key in past}
    for i in ids:
        r = rows[i]
        game = games[r["game"]]
        stub = stubs.setdefault(r["game"], {k: game[k] for k in ("date", "home", "away")} | {"players": {}})
        stub["players"][r["player"]] = {"team": game["players"][r["player"]]["team"]}
    np.testing.assert_array_equal(features[ids], rolling([rows[i] for i in ids], stubs, past))
    artifact = directory / "shared_flow_features.npz"
    np.savez_compressed(artifact, sourceKey=source["key"], flow=features, modes=mode)
    args.out.write_text(
        json.dumps(
            {
                "sourceKey": source["key"],
                "matchedFixtures": len(records),
                "sourceAudit": audit,
                "forecastRows": len(rows),
                "firstLockUnchangedAfterUnavailableFactsRemoved": len(ids),
                "unavailableEventFixturesRemoved": len(records) - len(past),
                "featureSha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
                "observedModesByCase": {str(k): int(v) for k, v in sorted(Counter(mode).items())},
            },
            indent=2,
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_shared_flow_features.json")
    )
    run(parser.parse_args())


if __name__ == "__main__":
    main()
