"""Controlled offline test of European workload/form added to LaLiga xScore."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

from app.research.score_europe_history import europe_features, read_archives
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats import add_stat_features
from app.research.score_stats_hybrid import choose_level, conditional_components
from app.research.score_stats_run import paired_interval


def predict_components(components, specification: dict[str, Any]) -> np.ndarray:
    classes, probability, parts = components
    level = choose_level(probability, classes, specification["threshold"])
    indices = np.searchsorted(classes, level)
    ordinary = parts[specification["quantile"]][np.arange(len(indices)), indices] + specification["ordinaryShift"]
    return np.clip(level + ordinary, np.where(level >= 60, level, 0), 100)


def select_components(components, target: np.ndarray) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    candidates = []
    for threshold in np.arange(0.1, 0.951, 0.025):
        for q in (0.35, 0.5, 0.65):
            for shift in (-3, 0, 3):
                spec = {"threshold": float(threshold), "quantile": q, "ordinaryShift": shift}
                candidates.append({**spec, "selection": measure(target, predict_components(components, spec))})
    return max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"])), candidates


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "games", "archives", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    data = json.loads(args.cases.read_text(encoding="utf-8"))
    rows = data["rows"]
    stored = np.load(args.stats_cache)
    x = stored["x"]
    raw = [json.loads(s) for s in args.games.read_text(encoding="utf-8").splitlines() if s.strip()]
    stat_names = sorted(
        {s for g in raw if g["date"][:10] < "2025-07-01" for r in g["players"].values() for s in r.get("stats", {})}
    )
    stat_key = hashlib.sha256(
        (data["key"] + json.dumps(stat_names)).encode() + Path(__file__).with_name("score_stats.py").read_bytes()
    ).hexdigest()
    if x.shape[0] != len(rows) or str(stored["key"]) != stat_key:
        x, counts, stat_features = add_stat_features(raw, rows, data["features"], stat_names)
        stored.close()
        np.savez_compressed(args.stats_cache, key=stat_key, x=x, counts=counts, names=stat_features)
        print("Rebuilt historical stat-feature cache for current implementation", flush=True)
    paths = [args.archives / (name + ".zip") for name in ("CL", "EL", "CONF")]
    source_key = hashlib.sha256(
        b"".join(hashlib.sha256(p.read_bytes()).digest() for p in paths)
        + Path(__file__).with_name("score_europe_history.py").read_bytes()
        + data["key"].encode()
    ).hexdigest()
    games, receipt = read_archives(paths)
    receipt["sourceKey"] = source_key
    receipt["availability"] = (
        "Minutes assumed available after 3h or 48h; FINAL v7 scores only after 48h; actual publication timing is not archived"
    )
    args.out.with_name("laliga_europe_source_receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    groups = {"control": x}
    extra = {}
    for lag in (48, 3):
        values, names = europe_features(rows, raw, games, workload_hours=lag)
        key = f"europe_{lag}h"
        extra[key] = values
        groups[key] = np.column_stack((x, values))
    np.savez_compressed(args.cache / "europe_features.npz", **extra, names=names, sourceKey=source_key)
    report = {
        "target": "LaLiga within seven on every eligible appearance, separate starts and played substitutes",
        "sourceKey": data["key"],
        "europeKey": source_key,
        "split": "Earlier selection July-December 2025; refit before January 2026; same January-October 2026 comparison",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceReceipt": receipt,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in rows])
        own = [r for r in rows if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in own])
        y = np.array([r["score"] for r in own])
        aa = np.array([r["aa"] for r in own])
        level = np.array([r["level"] for r in own])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        weeks = [r["week"] for r, yes in zip(own, test, strict=True) if yes]
        selection = {}
        for name, inputs in groups.items():
            components = conditional_components(inputs[keep], aa, level, train, valid)
            winner, candidates = select_components(components, y[valid])
            selection[name] = winner
            args.out.with_suffix(f".{cohort}.{name}.selection.json").write_text(
                json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
            )
            print(f"Selected {cohort} {name}: " + json.dumps(winner), flush=True)
        # Freeze feature group before any later target is used for comparison.
        chosen = max(
            selection, key=lambda name: (selection[name]["selection"]["within7"], -selection[name]["selection"]["mae"])
        )
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"chosenGroup": chosen, "selection": selection}, indent=2), encoding="utf-8"
        )
        predictions = {}
        for name, inputs in groups.items():
            components = conditional_components(inputs[keep], aa, level, ~test, test)
            predictions[name] = predict_components(components, selection[name])
            print(f"Evaluated {cohort} {name}", flush=True)
        baseline = predictions["control"]
        result = {"chosenGroup": chosen, "selection": selection, "groups": {}}
        positions = np.array([r["pos"] for r in own])[test]
        covered = extra["europe_48h"][keep, 0][test] == 1
        for name, prediction in predictions.items():
            metrics = {
                "later": measure(y[test], prediction),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "gain95": paired_interval(y[test], prediction, baseline, weeks),
                "coveredSecondary": measure(y[test][covered], prediction[covered]),
                "outsideArchiveSecondary": measure(y[test][~covered], prediction[~covered]),
                "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
                "positions": {
                    pos: measure(y[test][positions == pos], prediction[positions == pos])
                    for pos in POSITIONS
                    if (positions == pos).any()
                },
            }
            result["groups"][name] = metrics
        np.savez_compressed(args.cache / f"europe_predictions_{cohort}.npz", **predictions, y=y[test], covered=covered)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "chosenGroup": chosen,
                    "groups": {k: v["later"] for k, v in result["groups"].items()},
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
