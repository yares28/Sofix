"""Testing-only catalogue of official men's top-division referee announcement links."""

from __future__ import annotations

import hashlib
import html
import json
import re
import unicodedata
from collections import Counter
from datetime import date
from pathlib import Path

MONTHS = dict(
    enero=1,
    febrero=2,
    marzo=3,
    abril=4,
    mayo=5,
    junio=6,
    julio=7,
    agosto=8,
    septiembre=9,
    octubre=10,
    noviembre=11,
    diciembre=12,
)


def plain(text):
    return " ".join(html.unescape(re.sub("<[^>]+>", " ", text)).split())


def cards(text):
    result = []
    for block in re.findall(r"<article\b.*?</article>", text, re.S):
        anchors = re.findall(r"<a\b([^>]*)>(.*?)</a>", block, re.S)
        titles = [
            (re.search(r'href="([^"]+)"', attrs)[1], plain(body))
            for attrs, body in anchors
            if re.search(r'class="[^"]*fw-bolder', attrs)
        ]
        if len(titles) != 1 or not titles[0][0].startswith("/es/"):
            raise ValueError("Unknown or ambiguous official card title")
        dates = re.findall(r"(\d{2})\s+(" + "|".join(MONTHS) + r")\s+(\d{4})", plain(block), re.I)
        if len(dates) != 1:
            raise ValueError("Unknown or ambiguous official card date")
        day, month, year = dates[0]
        value = date(int(year), MONTHS[month.lower()], int(day)).isoformat()
        path, title = titles[0]
        normalized = unicodedata.normalize("NFKD", title).encode("ascii", "ignore").decode().lower()
        appointment = (
            ("estos son los arbitros" in normalized or "designaciones" in normalized)
            and "primera division" in normalized
            and not any(v in normalized for v in ["femenina", "futbol sala", "segunda division", "primera federacion"])
        )
        result.append(dict(path=path, title=title, date=value, appointment=appointment))
    if not result:
        raise ValueError("No official archive cards found")
    return result


def main():
    folder = Path("data/raw/score-foundation/referee-source")
    manifests = [folder / name for name in ["index_filtered_pilot_manifest.json", "archive_index_manifest.json"]]
    entries, manifest_hashes = [], {}
    for path in manifests:
        raw = path.read_bytes()
        manifest_hashes[path.name] = hashlib.sha256(raw).hexdigest()
        data = json.loads(raw.decode("utf-8-sig"))
        entries.extend(data if isinstance(data, list) else [data])
    observations, inventory = {}, []
    for entry in entries:
        if entry["Status"] != "downloaded":
            inventory.append(entry | dict(cards=0))
            continue
        raw = (folder / entry["File"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["SHA256"].lower():
            raise ValueError("Pinned official index bytes changed")
        rows = cards(raw.decode("utf-8"))
        for row in rows:
            if row["path"] in observations and observations[row["path"]] != row:
                raise ValueError("Conflicting official announcement catalogue")
            observations[row["path"]] = row
        inventory.append(
            dict(
                file=entry["File"],
                cards=len(rows),
                newest=max(r["date"] for r in rows),
                oldest=min(r["date"] for r in rows),
            )
        )
    rows = sorted(observations.values(), key=lambda r: (r["date"], r["path"]))
    relevant = [r for r in rows if r["appointment"] and "2023-07-01" <= r["date"] < "2026-11-01"]
    requests = [
        dict(
            File="archive_article_" + hashlib.sha256(r["path"].encode()).hexdigest()[:16] + ".html",
            Url="https://rfef.es" + r["path"],
            CatalogueDate=r["date"],
            Title=r["title"],
        )
        for r in relevant
    ]
    (folder / "archive_article_requests.json").write_text(json.dumps(requests, indent=2) + "\n")
    report = dict(
        scope="Official archive inventory; no claim every indexed announcement is prelock or usable",
        implementationKey=hashlib.sha256(
            Path(__file__).read_bytes() + json.dumps(manifest_hashes, sort_keys=True).encode()
        ).hexdigest(),
        manifestHashes=manifest_hashes,
        pages=inventory,
        uniqueCards=len(rows),
        appointmentCards=sum(r["appointment"] for r in rows),
        candidateArticleRequests=len(requests),
        candidateYearCounts=dict(Counter(r["CatalogueDate"][:4] for r in requests)),
        records=rows,
    )
    Path("reports/experiments/laliga_score_referee_index.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        "REFEREE_ARCHIVE_INDEX",
        json.dumps(
            {
                k: report[k]
                for k in ["uniqueCards", "appointmentCards", "candidateArticleRequests", "candidateYearCounts"]
            }
        ),
    )


if __name__ == "__main__":
    main()
