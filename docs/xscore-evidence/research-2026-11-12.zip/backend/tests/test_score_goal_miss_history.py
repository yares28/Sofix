from app.research.score_goal_miss_history import bucket


def test_cold_and_short_history_cannot_be_mislabelled_regular_contributors():
    assert bucket(0, 0) == "no_history"
    assert bucket(4, 4) == "short_history_1_to_4"
    assert bucket(0, 10) == "zero_in_recent_5_to_10"
    assert bucket(2, 10) == "positive_to_20_percent"
    assert bucket(4, 10) == "above20_to40_percent"
    assert bucket(5, 10) == "above40_percent"
