"""Replicate the team goal component on earlier card-based absence forecasts."""

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_absence_team_audit import paired
from app.research.score_absence_team_signal import (
    DELAY,
    NATIVE,
    NATIVE_SHA,
    REPORTS,
    ROOT,
    anchor_rates,
    fit,
    predictions,
)
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment

STEM = "laliga_score_absence_team_earlier"


def score(arrays, goals, weeks, matched):
    outcome = goals[:, None, :]
    scores = {
        "poisson": arrays - outcome * np.log(arrays),
        "cleanSheetBrier": (np.exp(-arrays) - (outcome == 0)) ** 2,
        "goalAbsoluteError": np.abs(arrays - outcome),
    }
    data = {}
    for name, loss in scores.items():
        a, b, c = (loss[:, j].ravel() for j in range(3))
        data[name] = dict(
            controlMean=float(a.mean()),
            interventionMean=float(b.mean()),
            placeboMean=float(c.mean()),
            interventionVsControl=paired(a - b, weeks, np.ones(len(a), bool)),
            matchedInterventionVsPlacebo=paired(c - b, weeks, matched) if matched.any() else None,
        )
    return data


def prepare():
    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = sorted(
        (g for g in map(json.loads, native.splitlines()) if g["date"] < "2025-07-01"),
        key=lambda g: (g["date"], g["id"]),
    )
    source = json.loads((ROOT / "cases.json").read_text())
    rates = anchor_rates(source)
    cycle_forecast = REPORTS / "laliga_score_card_cycle.forecasts.json"
    cycle_audit = REPORTS / "laliga_score_card_cycle.json"
    audit = json.loads(cycle_audit.read_text())
    raw = cycle_forecast.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == audit["forecastSHA"]
    assert audit["independentEarlierCandidateRows"] == 303
    claims = {}
    for r in json.loads(raw)["predictions"]:
        if r["phase"] in ("spring2024", "season2024") and r["status"] == "timely":
            people = claims.setdefault((r["target"], r["club"]), {})
            assert r["player"] not in people
            people[r["player"]] = r["projectedPriorMinutes"]
    report = dict(
        sourceKey=source["key"],
        nativeSHA=NATIVE_SHA,
        cardCycleKey=audit["key"],
        planSHA=hashlib.sha256((REPORTS / f"{STEM}.plan.json").read_bytes()).hexdigest(),
        codeSHA=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        phases={},
    )
    batches = []
    for phase, expect, counts in (
        ("spring2024", (180, 200), (4400, 1865)),
        ("season2024", (380, 380), (8360, 3540)),
    ):
        start, stop = PHASES[phase]
        target = [g for g in games if start <= g["date"] < stop]
        lock = min(cutoff_for(g["date"]) for g in target)
        training = [g for g in games if g["date"] < start and moment(g["date"]) + DELAY < lock]
        assert (len(training), len(target)) == expect
        case_rows = [r for r in source["rows"] if start <= r["date"] < stop]
        assert tuple(sum(r["cohort"] == c for r in case_rows) for c in ("start", "bench")) == counts
        fit_fx, beta, names, clubs, solver = fit(training, rates)
        vectors = predictions(games, target, rates, claims, fit_fx)
        phase_first = next(v["lock"] for v in vectors if v["removed"][0] or v["removed"][1])
        first = [g for g in target if cutoff_for(g["date"]).isoformat() == phase_first]
        modified = [dict(g, players={}) if moment(g["date"]) + DELAY >= moment(phase_first) else g for g in games]
        assert predictions(modified, first, rates, claims, fit_fx) == [v for v in vectors if v["lock"] == phase_first]
        array = np.array([v["rates"] for v in vectors])
        affected = sum(bool(v["removed"][0] or v["removed"][1]) for v in vectors)
        matched = sum(v["completelyMatchedPlacebo"] for v in vectors)
        report["phases"][phase] = dict(
            fittedFixtures=[g["id"] for g in training],
            fixtures=len(target),
            starterCases=counts[0],
            substituteCases=counts[1],
            solver=solver,
            affectedFixtures=affected,
            fullyMatchedPlaceboFixtures=matched,
            mutationLock=phase_first,
            mutationsChecked=len(first),
            vectors=vectors,
        )
        path = ROOT / f"{STEM}_{phase}.npz"
        np.savez_compressed(path, beta=beta, names=np.array(names), clubs=np.array(clubs), rates=array)
        report["phases"][phase]["arraySHA"] = hashlib.sha256(path.read_bytes()).hexdigest()
        batches.append((phase, target, array, vectors))
        print(phase, len(target), "fixtures;", affected, "affected and", matched, "placebo matches", flush=True)
    path = REPORTS / f"{STEM}.forecasts.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    return batches


if __name__ == "__main__":
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    prepare()
