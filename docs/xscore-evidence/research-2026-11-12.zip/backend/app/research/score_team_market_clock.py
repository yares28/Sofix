"""Audit historical match-odds coverage without using untimed quotes."""

import csv
import hashlib
import json
from collections import Counter
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from app.research.score_absence_clock_pilot import coverage_ceiling
from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_match_context import CLUBS, normalise, read_calendar
from app.research.score_search import cutoff_for, moment

DIRECTORY = ROOT / "team-market-source"
SEASONS = ("2324", "2425", "2526", "2627")
SOURCE = "https://football-data.co.uk/matches.php"


def provisional_collection(kickoff):
    # The publisher's Tuesday schedule is earlier than our Tuesday lock.
    # A season CSV contains no per-row capture clock, so this is provisional.
    lock = cutoff_for(kickoff)
    if lock.weekday() != 1 or moment(kickoff).weekday() not in (1, 2, 3):
        return None
    clock = datetime.combine(lock.date(), datetime.min.time(), tzinfo=ZoneInfo("Europe/London")).replace(hour=13)
    return clock.astimezone(UTC) if clock < lock else None


def valid_quotes(values):
    fields = ("AvgH", "AvgD", "AvgA", "Avg>2.5", "Avg<2.5")
    try:
        return all(1 < float(values[field]) < 100 for field in fields)
    except (TypeError, ValueError, KeyError):
        return False


def local_snapshot(games):
    backup = NATIVE.parent / "neon-backup-2026-10-12"
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        alaves=CLUBS["Deportivo Alaves"],
        celta=CLUBS["Celta Vigo"],
        deportivo=CLUBS["Deportivo A Coruna"],
        levante=CLUBS["Levante"],
    )
    file_hashes = {}

    def read(name, columns):
        path = backup / (name + ".copy")
        raw = path.read_bytes()
        file_hashes[path.name] = hashlib.sha256(raw).hexdigest()
        parsed = [line.split("\t") for line in raw.decode("utf-8").splitlines()]
        assert all(len(row) == columns for row in parsed)
        return parsed

    team = {r[0]: clubs[normalise(r[1])] for r in read("teams", 7)}
    fixture = {r[0]: (moment(r[5]), team[r[6]], team[r[7]]) for r in read("fixtures", 14)}
    native = {(moment(g["date"]), g["home"]["slug"], g["away"]["slug"]): g for g in games}
    odds = read("market_odds", 11)
    timely = set()
    matched = 0
    for row in odds:
        probabilities = [float(value) for value in row[5:8]]
        assert all(0 < value < 1 for value in probabilities) and abs(sum(probabilities) - 1) < 1e-6
        g = native.get(fixture[row[1]])
        if g is None:
            continue
        matched += 1
        if moment(row[2]) < cutoff_for(g["date"]):
            timely.add(g["id"])
    return dict(rows=len(odds), nativeMatch=matched, prelock=len(timely), files=file_hashes), timely


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    files = NATIVE.parent / "football-data-co-uk"
    csv_lookup, file_hashes = {}, {}
    for season in SEASONS:
        path = files / f"SP1_{season}.csv"
        file_hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        calendar = read_calendar(path)
        with path.open(encoding="utf-8-sig", newline="") as stream:
            listed = [
                r
                for r in csv.DictReader(stream)
                if r.get("Date") and r.get("FTHG") not in ("", None) and r.get("FTAG") not in ("", None)
            ]
        for row, calendar_row in zip(listed, calendar, strict=True):
            key = calendar_row["date"][:10], calendar_row["home"]["slug"], calendar_row["away"]["slug"]
            if key in csv_lookup:
                raise ValueError("Duplicate CSV fixture key")
            csv_lookup[key] = valid_quotes(row)
    games = list(map(json.loads, raw.splitlines()))
    by_fixture = {}
    for game in games:
        kickoff = game["date"]
        key = kickoff[:10], game["home"]["slug"], game["away"]["slug"]
        by_fixture[game["id"]] = dict(
            kickoff=kickoff,
            matched=key in csv_lookup,
            nonClosingQuoteFields=csv_lookup.get(key, False),
            provisionalMidweekClock=provisional_collection(kickoff) is not None,
        )
    rows = json.loads((ROOT / "cases.json").read_bytes())["rows"]
    local, timely = local_snapshot(games)
    local["allCases"] = dict(Counter(r["cohort"] for r in rows if r["game"] in timely))
    local["perfectRepairCeiling"] = coverage_ceiling(rows, timely)
    periods = {}
    for phase, (start, stop) in {**PHASES, "later2026": ("2026-01-01", "2027-01-01")}.items():
        scoped = {key for key, info in by_fixture.items() if start <= info["kickoff"] < stop}
        matched = {key for key in scoped if by_fixture[key]["matched"]}
        with_quotes = {key for key in matched if by_fixture[key]["nonClosingQuoteFields"]}
        provisional = {key for key in with_quotes if by_fixture[key]["provisionalMidweekClock"]}
        periods[phase] = dict(
            fixtures=len(scoped),
            joinedFixtures=len(matched),
            nonClosingFields=len(with_quotes),
            provisionalMidweekFixtures=len(provisional),
            provisionalCases=dict(Counter(r["cohort"] for r in rows if r["game"] in provisional)),
        )
    archive = {}
    for path in sorted(DIRECTORY.glob("cdx*.json")):
        records = json.loads(path.read_bytes())
        archive[path.name] = dict(
            sha=hashlib.sha256(path.read_bytes()).hexdigest(),
            capturesByYear=dict(Counter(row[1][:4] for row in records[1:])),
        )
    output = dict(
        nativeSHA=NATIVE_SHA,
        csvSHA=file_hashes,
        archivedIndexes=archive,
        publisherSchedule=SOURCE,
        periods=periods,
        localTimestampedSnapshot=local,
        archivedCsvQualifiedFixtures=0,
        laterForecastModelsEvaluated=False,
        additionalPublicSourceProbe={
            "provider": "Polymarket public Gamma",
            "source": "https://docs.polymarket.com/api-reference/events/list-events",
            "attempt": "Sports metadata and two variants of the same representative fixture lookup",
            "result": "Direct API requests failed TLS host verification, and the browser search surface did not expose "
            "the representative event endpoint. No price history fetched.",
        },
        limitation="Season CSV quote values are not timestamped row by row. Tuesday policy yields a provisional "
        "coverage estimate only. Weekend collection can occur after Sorare lock. Archived CSV index captures "
        "during the native period were outside the league season. No odds were used in a model.",
    )
    (REPORTS / "laliga_score_team_market_clock.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"periods": periods, "local": local}, indent=2))


if __name__ == "__main__":
    main()
