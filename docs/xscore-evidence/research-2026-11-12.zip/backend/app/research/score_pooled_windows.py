"""Testing only: source-weighted direct probabilities of native seven-point score windows."""

from __future__ import annotations

import numpy as np

from app.research.score_search import cutoff_for, moment
from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)
PARAMETERS = {f"width{w}_l2{r}": dict(width=w, ridge=r) for w in (32, 96) for r in (0.0001, 0.001)}


def training_mask(queries, cohort, begin, first, euro_weight):
    if euro_weight not in (0, 0.25, 1) or cohort not in ("start", "bench"):
        raise ValueError("Registered source weight and known cohort required")
    if any(q["cohort"] not in ("start", "bench") or q["source"] not in ("laliga", "euro") for q in queries):
        raise ValueError("Unknown native direct-window training scenario")
    europe = np.array([q["source"] == "euro" for q in queries])
    lock = cutoff_for(first).timestamp()
    fit = np.array(
        [q["cohort"] == cohort and q["date"] < begin and moment(q["date"]).timestamp() + 172800 < lock for q in queries]
    )
    fit &= ~europe | (euro_weight > 0)
    weights = np.where(europe, euro_weight, 1.0)
    return (
        fit,
        weights,
        dict(
            fitLaLiga=int((fit & ~europe).sum()), fitEurope=int((fit & europe).sum()), europeanWeight=float(euro_weight)
        ),
    )


class Normaliser:
    def fit(self, raw, weights):
        x, weights = np.asarray(raw, dtype=float), np.asarray(weights, dtype=float)
        if (
            x.ndim != 2
            or len(x) == 0
            or weights.shape != (len(x),)
            or not np.isfinite(weights).all()
            or (weights <= 0).any()
        ):
            raise ValueError("Nonempty training inputs and positive source weights required")
        valid = np.isfinite(x)
        count = (valid * weights[:, None]).sum(axis=0)
        self.known_ = count > 0
        self.mean_ = np.divide(
            (np.where(valid, x, 0) * weights[:, None]).sum(axis=0), count, out=np.zeros(x.shape[1]), where=count > 0
        )
        self.scale_ = np.sqrt(
            np.divide(
                (np.where(valid, (x - self.mean_) ** 2, 0) * weights[:, None]).sum(axis=0),
                count,
                out=np.zeros(x.shape[1]),
                where=count > 0,
            )
        )
        self.scale_[self.scale_ < 1e-8] = 1
        return self

    def transform(self, raw):
        x = np.asarray(raw, dtype=float)
        if x.ndim != 2 or x.shape[1] != len(self.mean_):
            raise ValueError("Shared window input dimensions differ")
        valid = np.isfinite(x)
        values = np.clip((np.where(valid, x, self.mean_) - self.mean_) / self.scale_, -8, 8)
        missing = (~valid).astype(float)
        values[:, ~self.known_] = 0
        missing[:, ~self.known_] = 0
        return np.column_stack((values, missing)).astype(np.float32)


def targets(scores):
    scores = np.asarray(scores, dtype=float)
    if scores.ndim != 1 or not np.isfinite(scores).all() or ((scores < 0) | (scores > 100)).any():
        raise ValueError("Known native0to100 score labels required")
    return (np.abs(scores[:, None] - CENTRES) <= 7).astype(float)


def forward(x, weights):
    a, b, c, d = weights
    hidden = np.tanh(x @ a + b)
    logits = hidden @ c + d
    probability = np.exp(-np.logaddexp(0, -logits))
    return hidden, logits, probability


def loss_gradient(x, labels, weights, sample, ridge):
    sample = np.asarray(sample, dtype=x.dtype)
    if sample.shape != (len(x),) or not np.isfinite(sample).all() or (sample <= 0).any():
        raise ValueError("Positive finite window-learning source weights required")
    hidden, logits, p = forward(x, weights)
    row_weight = sample / sample.sum()
    loss = float(row_weight @ ((np.logaddexp(0, logits) - labels * logits).mean(axis=1)))
    delta = (p - labels) * row_weight[:, None] / labels.shape[1]
    a, _, c, _ = weights
    upstream = (delta @ c.T) * (1 - hidden**2)
    gradients = [x.T @ upstream + ridge * a, upstream.sum(axis=0), hidden.T @ delta + ridge * c, delta.sum(axis=0)]
    loss += 0.5 * ridge * ((a**2).sum() + (c**2).sum())
    return float(loss), gradients


class WindowNetwork:
    def __init__(self, width, ridge, epochs=80, batch=256, seed=20261105):
        self.width, self.ridge, self.epochs, self.batch, self.seed = width, ridge, epochs, batch, seed

    def fit(self, raw, scores, sample):
        if self.epochs <= 0 or self.batch <= 0:
            raise ValueError("Positive training epochs and batch required")
        sample = np.asarray(sample, dtype=np.float32)
        self.normaliser_ = Normaliser().fit(raw, sample)
        x = self.normaliser_.transform(raw)
        labels = targets(scores).astype(np.float32)
        if len(labels) != len(x):
            raise ValueError("Matched native training rows and score labels required")
        rng = np.random.default_rng(self.seed)
        self.weights_ = [
            rng.normal(0, 1 / np.sqrt(x.shape[1]), (x.shape[1], self.width)).astype(np.float32),
            np.zeros(self.width, dtype=np.float32),
            rng.normal(0, 0.01, (self.width, len(CENTRES))).astype(np.float32),
            np.zeros(len(CENTRES), dtype=np.float32),
        ]
        means = [np.zeros_like(w) for w in self.weights_]
        squares = [np.zeros_like(w) for w in self.weights_]
        history = []
        step = 0
        for epoch in range(self.epochs):
            order = rng.permutation(len(x))
            total = 0.0
            for begin in range(0, len(x), self.batch):
                at = order[begin : begin + self.batch]
                loss, gradients = loss_gradient(x[at], labels[at], self.weights_, sample[at], self.ridge)
                if not np.isfinite(loss) or any(not np.isfinite(g).all() for g in gradients):
                    raise ValueError("Pooled window training became nonfinite")
                step += 1
                for j, g in enumerate(gradients):
                    means[j] = 0.9 * means[j] + 0.1 * g
                    squares[j] = 0.999 * squares[j] + 0.001 * g**2
                    self.weights_[j] -= (
                        0.001 * (means[j] / (1 - 0.9**step)) / (np.sqrt(squares[j] / (1 - 0.999**step)) + 1e-8)
                    )
                total += loss * float(sample[at].sum())
            history.append(total / float(sample.sum()))
            if (epoch + 1) % 40 == 0:
                print(f"POOLED_WINDOW_EPOCH {epoch + 1}/{self.epochs} loss{history[-1]:.6f}", flush=True)
        self.history_ = np.array(history)
        self.statistics_ = dict(
            epochs=self.epochs,
            fitRows=len(x),
            rawFeatures=raw.shape[1],
            normalisedFeatures=x.shape[1],
            width=self.width,
            ridge=self.ridge,
            seed=self.seed,
            batch=self.batch,
            steps=step,
            sourceWeightSum=float(sample.sum()),
            lossFirst=history[0],
            lossLast=history[-1],
            lossLastTenMean=float(np.mean(history[-10:])),
        )
        return self

    def predict_mass(self, raw):
        x = self.normaliser_.transform(raw)
        result = forward(x, self.weights_)[2]
        if result.shape != (len(raw), 201) or not np.isfinite(result).all() or (result < 0).any() or (result > 1).any():
            raise ValueError("Complete finite overlapping window probabilities required")
        return result

    def predict(self, raw):
        return window_centres(self.predict_mass(raw), CENTRES)
