"""Testing-only signed opponent-role mixture; preserve legacy projected squads."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_matchups as legacy
from app.research.score_search import POSITIONS, cutoff_for, moment

EVENTS, DEPTH = legacy.EVENTS, legacy.DEPTH
finite_mean = legacy.finite_mean
adjusted_duel_fraction = legacy.adjusted_duel_fraction


def role_weights(own, others, opposite):
    if not opposite:
        return legacy.role_weights(own, others, opposite)
    result = []
    for other in others:
        own_edges, other_edges = own.get("role_edges", ()), other.get("role_edges", ())
        if not own_edges or not other_edges:
            result.append(legacy.role_weights(own, [other], True)[0])
            continue
        lateral = np.mean([0.5 + 1 / (1 + abs(a + b)) for a in own_edges for b in other_edges])
        depth = 1 / (0.25 + abs(own["depth"] + other["depth"] - 1.2))
        result.append(float(lateral * depth))
    return np.array(result)


def build_matchups(rows, games, native_records, feature_names):
    indexed = {g["id"]: g for g in games}
    if len(indexed) != len(games):
        raise ValueError("Duplicate matchup fixture")
    native = {}
    for r in native_records:
        game = indexed.get(r["game"])
        if game is None or r["date"] != game["date"] or r["club"] not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Native matchup identity/date differs")
        if game["players"].get(r["player"], {}).get("team") != r["club"]:
            raise ValueError("Native player playing side differs")
        identity = r["game"], r["player"]
        if identity in native:
            raise ValueError("Duplicate native matchup observation")
        native[identity] = r["values"]
    schedule = sorted(games, key=lambda g: (g["date"], g["id"]))
    teams, people = defaultdict(list), defaultdict(list)
    prior = {p: [np.zeros(len(EVENTS)), 0.0] for p in POSITIONS}
    cursor, old_cutoff = 0, None
    person_cache, club_cache = {}, {}
    out, names = [], []
    audit = {
        "rows": len(rows),
        "coldOpponentRows": 0,
        "coldOwnRows": 0,
        "nativeRolesUsed": 0,
        "missingCompleteStats": 0,
        "completeObservations": 0,
        "cacheUnavailableFields": ["aerial_won", "aerial_lost", "total_scoring_att"],
    }

    def player_profile(player, club, position, cutoff):
        identity = player, club, position
        if identity in person_cache:
            return person_cache[identity]
        history = [r for r in people[player] if cutoff - r["available"] <= timedelta(days=365)]
        same_club = [r for r in history if r["club"] == club]
        recent = (same_club or history)[-10:]
        valid = [r for r in recent if r["counts"] is not None and r["minutes"] > 0]
        total_minutes = sum(r["minutes"] for r in valid)
        counts = sum((r["counts"] for r in valid), np.zeros(len(EVENTS)))
        prior_count, prior_minutes = prior[position]
        prior_duels = prior_count[0] + prior_count[1]
        if prior_minutes > 0:
            rate = (counts + prior_count * 300 / prior_minutes) * 90 / (total_minutes + 300)
        else:
            rate = counts * 90 / total_minutes if total_minutes else np.full(len(EVENTS), np.nan)
        roles = [r["role"] for r in recent[-3:] if r["role"] is not None]
        depths = [r.get("usage_role_depth") for r in roles if r.get("usage_role_depth") is not None]
        edges = [abs(r["usage_role_edge"]) for r in roles if r.get("usage_role_edge") is not None]
        profile = {
            "role_edges": tuple(
                float(r["usage_role_edge"])
                for r in roles
                if r.get("usage_role_edge") is not None and np.isfinite(r["usage_role_edge"])
            ),
            "rate": rate,
            "depth": float(np.mean(depths)) if depths else DEPTH[position],
            "edge": float(np.mean(edges)) if edges else np.nan,
            "native_role": bool(depths),
            "known": len(valid),
            "same_club": len(same_club),
            "position": position,
            "player": player,
            "prior_duel": float(prior_count[0] / prior_duels) if prior_duels > 0 else np.nan,
        }
        person_cache[identity] = profile
        return profile

    def club_profile(club, cutoff):
        if club in club_cache:
            return club_cache[club]
        recent = teams[club][-3:]
        exposure = defaultdict(float)
        positions = {}
        for members in recent:
            for player, minutes, position in members:
                exposure[player] += minutes / len(recent)
                positions[player] = position
        players = [player_profile(p, club, positions[p], cutoff) for p in exposure]
        weights = np.array([exposure[p["player"]] for p in players])
        latest = {p: m for p, m, _ in recent[-1]} if recent else {}
        a = np.array([latest.get(p["player"], 0) for p in players])
        continuity = (
            float(np.dot(a, weights) / (np.linalg.norm(a) * np.linalg.norm(weights)))
            if np.linalg.norm(a) * np.linalg.norm(weights)
            else np.nan
        )
        value = {"players": players, "weights": weights, "games": len(recent), "continuity": continuity}
        club_cache[club] = value
        return value

    for row in rows:
        cutoff = cutoff_for(row["date"])
        if old_cutoff is not None and cutoff < old_cutoff:
            raise ValueError("Matchup target rows must be chronological")
        if cutoff != old_cutoff:
            person_cache.clear()
            club_cache.clear()
            old_cutoff = cutoff
        while cursor < len(schedule) and moment(schedule[cursor]["date"]) + timedelta(hours=48) < cutoff:
            game = schedule[cursor]
            by_club = {game[s]["slug"]: [] for s in ("home", "away")}
            for player, r in game["players"].items():
                if r.get("played") is not True or r.get("pos") not in POSITIONS:
                    continue
                club, pos = r.get("team"), r["pos"]
                minutes = r.get("mins")
                if club not in by_club or type(minutes) not in (int, float) or not np.isfinite(minutes) or minutes < 0:
                    continue
                by_club[club].append((player, float(minutes), pos))
                stats = r.get("stats")
                known = r.get("ver") == 7 and isinstance(stats, dict)
                counts = np.array([stats.get(e, [0, 0])[0] for e in EVENTS], dtype=float) if known else None
                if counts is not None and not np.isfinite(counts).all():
                    raise ValueError("Unknown event count in complete matchup stats")
                audit["completeObservations" if known else "missingCompleteStats"] += 1
                record = {
                    "available": moment(game["date"]) + timedelta(hours=48),
                    "club": club,
                    "minutes": minutes,
                    "counts": counts,
                    "role": native.get((game["id"], player)),
                }
                people[player].append(record)
                if known and minutes > 0:
                    prior[pos][0] += counts
                    prior[pos][1] += minutes
            for club, members in by_club.items():
                teams[club].append(members)
            cursor += 1
        game = indexed[row["game"]]
        home = row["x"][feature_names.index("home")] > 0
        own_club, other_club = (
            (game["home"]["slug"], game["away"]["slug"]) if home else (game["away"]["slug"], game["home"]["slug"])
        )
        own = player_profile(row["player"], own_club, row["pos"], cutoff)
        own_team, opponent = club_profile(own_club, cutoff), club_profile(other_club, cutoff)
        audit["coldOpponentRows"] += opponent["games"] == 0
        audit["coldOwnRows"] += own["known"] == 0
        audit["nativeRolesUsed"] += own["native_role"]
        features = {
            "own_known_games": float(own["known"]),
            "own_same_club_games": float(own["same_club"]),
            "own_role_depth": own["depth"],
            "own_role_width": own["edge"],
            "own_native_role": float(own["native_role"]),
        }
        features.update({"own_" + e + "90": value for e, value in zip(EVENTS, own["rate"], strict=True)})
        for label, club, opposite in (("teammates", own_team, False), ("opponent", opponent, True)):
            members = [p for p in club["players"] if opposite or p["player"] != row["player"]]
            lookup = {p["player"]: w for p, w in zip(club["players"], club["weights"], strict=True)}
            weights = np.array([lookup[p["player"]] for p in members])
            values = np.array([p["rate"] for p in members])
            features[label + "_recent_games"] = float(club["games"])
            features[label + "_exposure"] = float(weights.sum())
            features[label + "_continuity"] = club["continuity"]
            features[label + "_known_fraction"] = (
                float(sum(w for p, w in zip(members, weights, strict=True) if p["known"] > 0) / weights.sum())
                if weights.sum()
                else np.nan
            )
            mean = finite_mean(values, weights)
            total = mean * weights.sum() / 90
            matched = finite_mean(values, weights * role_weights(own, members, opposite))
            for prefix, vector in (("total", total), ("matchup", matched)):
                features.update({f"{label}_{prefix}_{e}": value for e, value in zip(EVENTS, vector, strict=True)})
            if opposite:
                duel_weights = (
                    weights
                    * role_weights(own, members, True)
                    * np.array([p["rate"][0] + p["rate"][1] for p in members])
                )
                baselines = np.array([p["prior_duel"] for p in members])
                valid = np.isfinite(baselines) & np.isfinite(duel_weights)
                features["opponent_baseline_duel_fraction"] = (
                    float(np.average(baselines[valid], weights=duel_weights[valid]))
                    if duel_weights[valid].sum() > 0
                    else np.nan
                )
        won, lost = EVENTS.index("duel_won"), EVENTS.index("duel_lost")
        denominator = own["rate"][won] + own["rate"][lost]
        features["own_duel_fraction"] = float(own["rate"][won] / denominator) if denominator > 0 else np.nan
        denominator = features["opponent_matchup_duel_won"] + features["opponent_matchup_duel_lost"]
        features["opponent_duel_fraction"] = (
            float(features["opponent_matchup_duel_won"] / denominator) if denominator > 0 else np.nan
        )
        features["duel_fraction_gap"] = features["own_duel_fraction"] - features["opponent_duel_fraction"]
        features["expected_duel_fraction"] = adjusted_duel_fraction(
            features["own_duel_fraction"],
            features["opponent_duel_fraction"],
            features["opponent_baseline_duel_fraction"],
        )
        factor = {"DEF": 3.5, "MID": 1.6, "FWD": 2}.get(row["pos"], np.nan)
        features["duel_point_change90"] = (
            factor
            * (own["rate"][won] + own["rate"][lost])
            * (features["expected_duel_fraction"] - features["own_duel_fraction"])
        )
        if names and list(features) != names:
            raise ValueError("Matchup feature order changed")
        names = list(features)
        out.append(list(features.values()))
    return np.array(out), names, audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_signed_duel_matchups.json"))
    args = parser.parse_args()
    source = json.loads((args.cache / "cases.json").read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native matchup archive changed")
    native_bytes = (args.cache / "player_context_observations.json.gz").read_bytes()
    native = json.loads(gzip.decompress(native_bytes))
    parent = json.loads((args.out.parent / "laliga_score_matchups.json").read_text())
    if native["key"] != parent["nativeKey"] or parent["sourceKey"] != source["key"]:
        raise ValueError("Preserved matchup/player sources changed")
    expected_old = hashlib.sha256(
        source["key"].encode()
        + raw
        + native_bytes
        + Path(legacy.__file__).read_bytes()
        + (args.out.parent / "laliga_score_matchups.plan.json").read_bytes()
    ).hexdigest()
    if (
        expected_old != parent["featureKey"]
        or expected_old != "c823678a28410cd6f76bd73b824f54579522f44c49021ee1def6accc63e70d55"
    ):
        raise ValueError("Original matchup implementation/source/plan changed")
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    old, names, old_audit = legacy.build_matchups(source["rows"], games, native["records"], source["features"])
    with np.load(args.cache / "matchup_features.npz") as f:
        if str(f["key"]) != expected_old or f["names"].tolist() != names:
            raise ValueError("Original cached matchup identity differs")
        np.testing.assert_array_equal(old, f["x"])
    if old_audit != parent["audit"]:
        raise ValueError("Original native matchup source coverage changed")
    print("SIGNED_DUEL_ORIGINAL_REPRODUCED " + json.dumps(old_audit), flush=True)
    x, new_names, audit = build_matchups(source["rows"], games, native["records"], source["features"])
    allowed = {
        "opponent_baseline_duel_fraction",
        "opponent_duel_fraction",
        "duel_fraction_gap",
        "expected_duel_fraction",
        "duel_point_change90",
    }
    selected = np.array([n.startswith("opponent_matchup_") or n in allowed for n in names])
    if x.shape != (38850, 104) or names != new_names or audit != old_audit or selected.sum() != 22:
        raise ValueError("Registered same-population signed matchup schema/coverage changed")
    np.testing.assert_array_equal(x[:, ~selected], old[:, ~selected])
    key = hashlib.sha256(
        expected_old.encode() + Path(__file__).read_bytes() + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    path = args.cache / "signed_duel_matchup_features.npz"
    np.savez_compressed(
        path, key=key, source_key=source["key"], original_key=expected_old, x=x, names=names, selected=selected
    )
    changed = ~np.isclose(x, old, rtol=0, atol=1e-10, equal_nan=True)
    report = dict(
        scope="Testing-only signed opponent winability source/features; no accuracy claim",
        sourceKey=source["key"],
        featureKey=key,
        originalFeatureKey=expected_old,
        featuresSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        audit=audit,
        rows=len(x),
        columns=len(names),
        changedAllowedColumns=int(selected.sum()),
        unchangedColumns=int((~selected).sum()),
        changedColumns=int(changed.any(axis=0).sum()),
        changedCells=int(changed.sum()),
        changedRows=int(changed.any(axis=1).sum()),
        status="Independent full22changedcolumns/nativeprojectedroles/futuremutation audit REQUIRED before earlier-only signal",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
    print("SIGNED_DUEL_BUILT " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
