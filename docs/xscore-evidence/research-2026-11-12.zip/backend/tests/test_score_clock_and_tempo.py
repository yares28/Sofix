from app.research.score_clock_and_tempo import observed_clock, observed_tempo


def test_clock_proxy_needs_consistent_full_match_goalkeeper():
    goalkeeper = {"pos": "GK", "mins": 96, "on": None, "off": None, "rc": 0}
    match = {"maxMin": 96, "lineups": {"home": {"starters": [goalkeeper]}}}
    assert observed_clock(match) == 6
    goalkeeper["mins"] = 90
    assert observed_clock(match) is None
    goalkeeper["mins"] = 96
    goalkeeper["off"] = 90
    assert observed_clock(match) is None


def test_tempo_uses_short_unique_timestamp_gaps_and_keeps_missing():
    home = {"team": "home", "min": 1, "sec": 0}
    away = {"team": "away", "min": 1, "sec": 5}
    match = {
        "passes": [home] * 100 + [away] * 100,
        "shots": [{"team": "away", "min": 1, "sec": 12}, {"team": "away", "min": 1, "sec": 30}],
    }
    assert observed_tempo(match) == 0.2
    match["shots"][1]["sec"] = None
    assert observed_tempo(match) is None
