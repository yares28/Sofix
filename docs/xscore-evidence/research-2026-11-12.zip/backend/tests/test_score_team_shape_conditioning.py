"""Testing-only ablation coverage: structural and conditional-AA fields remain distinct."""

import numpy as np
import pytest

from app.research import score_team_shape_conditioning as conditioning
from app.research import score_team_shape_history as shape


def test_team_shape_ablation_covers_all102_fields_without_cross_group_leakage():
    groups = conditioning.feature_groups(shape.NAMES)
    assert groups["structural"].sum() == 88
    assert groups["aa"].sum() == 14
    assert groups["all"].sum() == 102
    assert not (groups["structural"] & groups["aa"]).any()
    np.testing.assert_array_equal(groups["structural"] | groups["aa"], groups["all"])
    assert all(n.startswith("shape_aa_") for n, yes in zip(shape.NAMES, groups["aa"], strict=True) if yes)
    with pytest.raises(ValueError, match="schema"):
        conditioning.feature_groups(list(shape.NAMES)[::-1])
