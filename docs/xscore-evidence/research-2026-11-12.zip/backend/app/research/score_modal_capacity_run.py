"""Testing only: wider exact-hit forest search with a larger-tree confirmation."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_capacity as capacity
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_matchups_run import validate_stat_identity
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def fitted(x, scores, weeks, mask, setting, trees, path, key):
    if path.exists():
        with np.load(path) as stored:
            stats = json.loads(str(stored["statistics"]))
            if (
                str(stored["key"]) != key
                or stats["trees"] != trees
                or len(stored["prediction"]) != int(mask["target"].sum())
            ):
                raise ValueError("Capacity cache identity differs")
            return stored["prediction"], stats
    fit, target = mask["fit"], mask["target"]
    spec = capacity.PARAMETERS[setting]
    at = time.monotonic()
    model = capacity.CapacityForest(trees, spec["depth"], spec["minLeaf"], spec["features"]).fit(
        x[fit], scores[fit], weeks[fit]
    )
    mass = model.predict_mass(x[target])
    prediction = window_centres(mass, modal.CENTRES)
    if not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1 + 1e-12).any():
        raise ValueError("Invalid capacity score-window probabilities")
    chosen = (prediction * 2).astype(int)
    if not np.allclose(mass[np.arange(len(prediction)), chosen], mass.max(axis=1), rtol=0, atol=1e-12):
        raise ValueError("Capacity forecast is not a maximum-mass window")
    stats = {
        **model.statistics_,
        "fitSeconds": time.monotonic() - at,
        "fitRows": int(fit.sum()),
        "targetRows": int(target.sum()),
    }
    np.savez_compressed(path, key=key, prediction=prediction, mass=mass, statistics=json.dumps(stats))
    return prediction, stats


def control_for(args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench):
    mask = masks[phase]
    if cohort == "bench":
        return stability.analogue_control(args, key, source, old_bench, phase, mask)
    phases = [p[0] for p in stability.PHASES]
    previous_phase = phases[phases.index(phase) - 1]
    previous_rows = [r for r, yes in zip(args.rows, masks[previous_phase]["target"], strict=True) if yes]
    previous = flow.old_components(args, cohort, previous_phase, old_match, old_stability, old_ordinary)
    current = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
    pieces = stability.starter_control(previous, current, previous_rows, mask["first"])
    positions = np.array([r["pos"] for r, yes in zip(args.rows, mask["target"], strict=True) if yes])
    return empirical.empirical_predictions(*pieces[:3], positions, pieces[3], 20, 0.75, 0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "cases",
        "stats-cache",
        "match-cache",
        "player-cache",
        "matchup-cache",
        "matchup-report",
        "history-cache",
        "history-report",
        "cache",
        "packages",
        "out",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    matchup_report, history_report = (json.loads(p.read_text()) for p in (args.matchup_report, args.history_report))
    if any(
        r["sourceKey"] != source["key"]
        for r in (
            old_match,
            old_player,
            old_stability,
            old_ordinary,
            old_start,
            old_bench,
            matchup_report,
            history_report,
        )
    ):
        raise ValueError("Capacity source cases differ")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.match_cache) as stored:
        match, match_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Team feature identity differs")
    with np.load(args.player_cache) as stored:
        player, player_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_player["featureKey"]:
            raise ValueError("Player feature identity differs")
    with np.load(args.matchup_cache) as stored:
        matchups, matchup_key = stored["x"], str(stored["key"])
        if matchup_key != matchup_report["featureKey"]:
            raise ValueError("Matchup feature identity differs")
    with np.load(args.history_cache) as stored:
        history, history_key = stored["x"], str(stored["key"])
        if history_key != history_report["featureKey"]:
            raise ValueError("Mode/bound history identity differs")
    if any(len(a) != len(source["rows"]) for a in (base, match, player, matchups, history)):
        raise ValueError("Capacity input coverage differs")
    files = [
        Path(__file__),
        Path(capacity.__file__),
        Path(modal.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + matchup_key
            + history_key
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "historyFeatureKey": history_key,
        "matchupFeatureKey": matchup_key,
        "cohorts": {},
    }
    if args.out.exists():
        previous = json.loads(args.out.read_text())
        if previous.get("implementationKey") == key:
            report = previous
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        weeks = np.array([r["week"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, _ = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        inputs = {
            "compact": np.column_stack((numeric, history[keep])),
            "rich": np.column_stack((base[keep], match[keep], player[keep], matchups[keep], history[keep])),
        }
        records = [
            {
                "spec": {"group": group, "model": setting, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for group in inputs
            for setting in capacity.PARAMETERS
            for scope in ("all", "defmid")
        ]
        audit, controls = {}, {}

        def get_prediction(
            group, setting, phase, trees, *, cohort=cohort, inputs=inputs, y=y, weeks=weeks, masks=masks
        ):
            print(f"FITTING {cohort} {phase} {group} {setting} trees{trees}", flush=True)
            path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}_{setting}_t{trees}_{key[:12]}.npz"
            return fitted(inputs[group], y, weeks, masks[phase], setting, trees, path, key)

        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            control = control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            controls[phase] = control
            metric = measure(y[target], control)
            if metric["within7"] != old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]["within7"]:
                raise ValueError("Capacity earlier control did not reproduce")
            audit[phase] = {
                "fit": int(masks[phase]["fit"].sum()),
                "target": int(target.sum()),
                "control": metric,
                "models": {},
            }
            for setting in capacity.PARAMETERS:
                for group in inputs:
                    raw, stats = get_prediction(group, setting, phase, 32)
                    audit[phase]["models"][group + "/" + setting] = {
                        "forecast": measure(y[target], raw),
                        "fitDiagnostics": stats,
                    }
                    for record in [r for r in records if r["spec"]["group"] == group and r["spec"]["model"] == setting]:
                        candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                        cm = measure(y[target], candidate)
                        gain = cm["within7"] - metric["within7"]
                        record["gains"].append(gain)
                        record["errors"].append(cm["mae"])
                        record["counts"].append(len(candidate))
                        record["periods"][phase] = {"gain": gain, "metrics": cm}
                    print(
                        "MODEL "
                        + json.dumps(
                            {
                                "cohort": cohort,
                                "phase": phase,
                                "group": group,
                                "setting": setting,
                                "forecast": measure(y[target], raw),
                                "fitDiagnostics": stats,
                            }
                        ),
                        flush=True,
                    )
        winner32, best32 = stability.choose_stable(records)
        candidate, winner, tree_count = best32, None, 32
        confirmation = None
        if winner32 is not None:
            candidate = {"spec": winner32["spec"].copy(), "gains": [], "errors": [], "counts": [], "periods": {}}
            spec = candidate["spec"]
            tree_count = 128
            for phase, _, _ in stability.PHASES[1:-1]:
                target = masks[phase]["target"]
                raw, stats = get_prediction(spec["group"], spec["model"], phase, 128)
                prediction = ordinary.scoped_prediction(raw, controls[phase], positions[target], spec["scope"])
                cm = measure(y[target], prediction)
                gain = cm["within7"] - audit[phase]["control"]["within7"]
                candidate["gains"].append(gain)
                candidate["errors"].append(cm["mae"])
                candidate["counts"].append(len(prediction))
                candidate["periods"][phase] = {"gain": gain, "metrics": cm, "fitDiagnostics": stats}
            winner = candidate if min(candidate["gains"]) > 0 else None
            confirmation = {"passed": winner is not None, "candidate": candidate}
        frozen = {
            "implementationKey": key,
            "winner": winner,
            "winner32": winner32,
            "best32": best32,
            "finalCandidate": candidate,
            "finalTreeCount": tree_count,
            "confirmation": confirmation,
            "passingCandidates32": sum(min(r["gains"]) > 0 for r in records),
            "candidates32": records,
        }
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
        print(
            "FROZEN "
            + json.dumps({"cohort": cohort, "winner": winner, "finalCandidate": candidate, "trees": tree_count}),
            flush=True,
        )
        phase = "later2026"
        target = masks[phase]["target"]
        spec = candidate["spec"]
        raw, stats = get_prediction(spec["group"], spec["model"], phase, tree_count)
        control = control_for(
            args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
        )
        expected = (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
        if measure(y[target], control)["within7"] != expected["within7"]:
            raise ValueError("Capacity final control did not reproduce")
        alternate = ordinary.scoped_prediction(raw, control, positions[target], spec["scope"])
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": candidate,
            "winner32": winner32,
            "candidateCount": len(records) + 1,
            "confirmation": confirmation,
            "finalTreeCount": tree_count,
            "earlierPeriods": audit,
            "inputCounts": {g: x.shape[1] for g, x in inputs.items()},
            "finalFitDiagnostics": stats,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks[target].tolist()),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
