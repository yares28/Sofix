"""Testing only: audit the wider forest's native scores, caches and larger-tree gate."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_modal_capacity as capacity
from app.research import score_modal_capacity_run as runner
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_search import measure
from app.research.score_windows import window_centres


def check_cached(path, key, target_count, fit_count, setting, trees, feature_count):
    with np.load(path) as f:
        if str(f["key"]) != key or f["mass"].shape != (target_count, 201):
            raise ValueError("Capacity fitted cache identity/coverage differs")
        mass, prediction, stats = f["mass"], f["prediction"], json.loads(str(f["statistics"]))
    spec = capacity.PARAMETERS[setting]
    expected_features = capacity.candidate_feature_count(feature_count, spec["features"]) or feature_count
    if (
        not np.isfinite(mass).all()
        or (mass < 0).any()
        or (mass > 1 + 1e-12).any()
        or not np.array_equal(prediction, window_centres(mass, modal.CENTRES))
    ):
        raise ValueError("Capacity choices are not finite native maximum-mass windows")
    expected = {
        "trees": trees,
        "depthLimit": spec["depth"],
        "uniqueLeafMinimum": spec["minLeaf"],
        "featureStrategy": spec["features"],
        "candidateFeaturesPerNode": expected_features,
        "fitRows": fit_count,
        "targetRows": target_count,
    }
    if any(stats[k] != value for k, value in expected.items()):
        raise ValueError("Capacity fitted model contract differs")
    return prediction


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_bench = map(
        read,
        ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary", "laliga_score_analogues"),
    )
    if any(r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_bench)):
        raise ValueError("Capacity native audit source differs")
    key = report["implementationKey"]
    old_player = read("laliga_score_player_context")
    with np.load(args.cache / "stats.npz") as f:
        stat_key = str(f["key"])
    runner.validate_stat_identity(stat_key, old_match, old_player)
    feature_keys = []
    for filename, expected in (
        ("match_context_features.npz", old_match["featureKey"]),
        ("player_context_features.npz", old_player["featureKey"]),
        ("matchup_features.npz", read("laliga_score_matchups")["featureKey"]),
        ("modal_history_features.npz", read("laliga_score_modal_history")["featureKey"]),
    ):
        with np.load(args.cache / filename) as f:
            if str(f["key"]) != expected:
                raise ValueError("Capacity native audit input source fingerprint differs")
            feature_keys.append(str(f["key"]))
    files = [
        Path(runner.__file__),
        *[Path(m.__file__) for m in (capacity, modal, ordinary, stability, runner.empirical, runner.flow)],
        args.report.with_suffix(".plan.json"),
    ]
    expected_key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + "".join(feature_keys)
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    if key != expected_key:
        raise ValueError("Capacity native audit model/code/plan fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner32, best32 = stability.choose_stable(frozen["candidates32"])
        if frozen["implementationKey"] != key or best32 != frozen["best32"] or winner32 != frozen["winner32"]:
            raise ValueError("Capacity native audit earlier32tree selection differs")
        cached, checks = {}, 0
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            control = runner.control_for(
                call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            for record in frozen["candidates32"]:
                spec = record["spec"]
                identity = phase, spec["group"], spec["model"], 32
                if identity not in cached:
                    path = (
                        args.cache
                        / f"{args.report.stem}_{cohort}_{phase}_{spec['group']}_{spec['model']}_t32_{key[:12]}.npz"
                    )
                    cached[identity] = check_cached(
                        path,
                        key,
                        int(target.sum()),
                        int(masks[phase]["fit"].sum()),
                        spec["model"],
                        32,
                        result["inputCounts"][spec["group"]],
                    )
                    checks += 1
                candidate = ordinary.scoped_prediction(cached[identity], control, positions[target], spec["scope"])
                if measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                    raise ValueError("Capacity native audit earlier32tree forecast differs")
        candidate = frozen["finalCandidate"]
        spec, trees = candidate["spec"], frozen["finalTreeCount"]
        if winner32 is None:
            if trees != 32 or candidate != best32 or frozen["winner"] is not None:
                raise ValueError("Capacity rejected32tree candidate selection differs")
        else:
            if trees != 128 or spec != winner32["spec"] or (min(candidate["gains"]) > 0) != bool(frozen["winner"]):
                raise ValueError("Capacity128tree confirmation gate differs")
            for phase, _, _ in stability.PHASES[1:-1]:
                target = masks[phase]["target"]
                path = (
                    args.cache
                    / f"{args.report.stem}_{cohort}_{phase}_{spec['group']}_{spec['model']}_t128_{key[:12]}.npz"
                )
                raw = check_cached(
                    path,
                    key,
                    int(target.sum()),
                    int(masks[phase]["fit"].sum()),
                    spec["model"],
                    128,
                    result["inputCounts"][spec["group"]],
                )
                control = runner.control_for(
                    call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
                )
                measured = measure(
                    y[target], ordinary.scoped_prediction(raw, control, positions[target], spec["scope"])
                )
                if measured != candidate["periods"][phase]["metrics"]:
                    raise ValueError("Capacity128tree earlier confirmation did not reproduce")
                checks += 1
        phase = "later2026"
        target = masks[phase]["target"]
        path = (
            args.cache / f"{args.report.stem}_{cohort}_{phase}_{spec['group']}_{spec['model']}_t{trees}_{key[:12]}.npz"
        )
        raw = check_cached(
            path,
            key,
            int(target.sum()),
            int(masks[phase]["fit"].sum()),
            spec["model"],
            trees,
            result["inputCounts"][spec["group"]],
        )
        control = runner.control_for(
            call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
        )
        alternate = ordinary.scoped_prediction(raw, control, positions[target], spec["scope"])
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Capacity native audit all-case identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Capacity native audit final metrics differ")
            if (result["selected"] == "candidate") != bool(frozen["winner"]):
                raise ValueError("Capacity final winner selection differs")
            h1, h0 = np.abs(y[target] - f["alternate"]) <= 7, np.abs(y[target] - f["control"]) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "fittedMassCachesVerified": checks + 1,
            "candidate32ForecastsReconstructed": len(frozen["candidates32"]) * 3,
            "largerConfirmationGateVerified": True,
            "finalTreeCount": trees,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
    output = {
        "scope": "Research-only independent native all-case/mass/fit-contract/gate audit, no fresh blind claim",
        "implementationKey": key,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
