"""Testing only: recalibrate AA quantile probabilities using earlier out-of-fit outcomes."""

from __future__ import annotations

import numpy as np

from app.research import score_quantile_curve as curve
from app.research.score_modal_trees import CENTRES
from app.research.score_search import cutoff_for, moment


def fit_levels(rows, classes, parts, first_date, prior):
    if not np.isfinite(prior) or prior <= 0:
        raise ValueError("Positive probability-calibration prior required")
    classes = np.asarray(classes)
    knots = np.sort(np.stack([parts[q] for q in curve.QUANTILES], axis=2), axis=2)
    if knots.shape != (len(rows), len(classes), len(curve.QUANTILES)) or not np.isfinite(knots).all():
        raise ValueError("Complete earlier out-of-fit quantile profiles required")
    lock = cutoff_for(first_date).timestamp()
    available = np.array([moment(r["date"]).timestamp() + 48 * 3600 for r in rows])
    past = available < lock
    levels = np.array([r["level"] for r in rows], dtype=float)
    aa = np.array([r["aa"] for r in rows], dtype=float)
    known = past & np.isin(levels, classes)
    chosen = np.flatnonzero(known)
    if not np.isfinite(aa[known]).all():
        raise ValueError("Known available calibration AA labels required")
    columns = np.searchsorted(classes, levels[known])
    below = aa[known, None] <= knots[chosen, columns]
    positions = np.array([r["pos"] for r in rows])[known]
    q = np.array(curve.QUANTILES)

    def shrunk(selected, base):
        return ((below[selected].sum(axis=0) + prior * base) / (int(selected.sum()) + prior)).tolist()

    pooled = np.array(shrunk(np.ones(len(chosen), dtype=bool), q))
    by_pos, by_level = {}, {}
    counts_pos, counts_level = {}, {}
    for position in sorted(set(positions)):
        selected = positions == position
        values = np.array(shrunk(selected, pooled))
        by_pos[position] = values.tolist()
        counts_pos[position] = int(selected.sum())
        for level in sorted(set(levels[known][selected])):
            select = selected & (levels[known] == level)
            name = f"{position}:{float(level)}"
            by_level[name] = shrunk(select, values)
            counts_level[name] = int(select.sum())
    return {
        "global": pooled.tolist(),
        "position": by_pos,
        "position_level": by_level,
        "knownCases": len(chosen),
        "unavailableCases": int((~past).sum()),
        "unknownPastClasses": int((past & ~known).sum()),
        "positionCounts": counts_pos,
        "positionLevelCounts": counts_level,
        "prior": prior,
        "maximumAvailableUsed": float(available[known].max()) if known.any() else None,
        "firstLock": lock,
    }


def levels_for(bank, position, level, group):
    if group not in ("global", "position", "position_level"):
        raise ValueError("Registered quantile calibration group required")
    base = bank["global"]
    if group != "global":
        base = bank["position"].get(position, base)
    if group == "position_level":
        base = bank["position_level"].get(f"{position}:{float(level)}", base)
    values = np.asarray(base, dtype=float)
    if (
        values.shape != (len(curve.QUANTILES),)
        or not np.isfinite(values).all()
        or (np.diff(values) < 0).any()
        or not (0 <= values[0] <= values[-1] <= 1)
    ):
        raise ValueError("Monotone finite calibrated probability levels required")
    return values


def curve_mass(knots, level, tails, probabilities):
    knots, probabilities = np.asarray(knots, dtype=float), np.asarray(probabilities, dtype=float)
    if knots.ndim != 2 or knots.shape[1] != len(curve.QUANTILES) or not np.isfinite(knots).all():
        raise ValueError("Complete finite AA quantile curves required")
    if (
        probabilities.shape != (len(curve.QUANTILES),)
        or not np.isfinite(probabilities).all()
        or (np.diff(probabilities) < 0).any()
        or not (0 <= probabilities[0] <= probabilities[-1] <= 1)
    ):
        raise ValueError("Monotone finite calibrated probabilities required")
    if tails not in ("clamp", "extrapolate"):
        raise ValueError("Registered tail policy required")
    values = np.sort(knots, axis=1)
    left, right = values[:, 0], values[:, -1]
    if tails == "extrapolate":
        left = left - (values[:, 1] - left) * 0.05 / 0.1
        right = right + (right - values[:, -2]) * 0.05 / 0.1
    points = np.column_stack((left, values, right))
    weights = np.diff(np.r_[0, probabilities, 1])
    floor = level if level >= 60 else 0
    low, high = CENTRES - 7, CENTRES + 7
    mass = np.zeros((len(knots), len(CENTRES)))
    for k, weight in enumerate(weights):
        a, b = points[:, k, None], points[:, k + 1, None]
        width = b - a
        before = np.clip(np.divide(low[None, :] - level - a, width, out=np.zeros_like(mass), where=width > 0), 0, 1)
        after = np.clip(np.divide(high[None, :] - level - a, width, out=np.zeros_like(mass), where=width > 0), 0, 1)
        before = np.where(low[None, :] <= floor, 0, before)
        after = np.where(high[None, :] >= 100, 1, after)
        interval = np.where(high[None, :] < floor, 0, np.maximum(0, after - before))
        atom = (np.abs(np.clip(np.maximum(floor, level + a), 0, 100) - CENTRES) <= 7).astype(float)
        mass += weight * np.where(width > 0, interval, atom)
    if not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1 + 1e-12).any():
        raise ValueError("Invalid calibrated native score-window mass")
    return mass


def forecast_mass(classes, probability, parts, positions, bank, group, tails):
    probability, positions = np.asarray(probability), np.asarray(positions)
    if (
        probability.ndim != 2
        or probability.shape != (len(positions), len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Valid unchanged decisive probabilities and all target positions required")
    knots = np.stack([parts[q] for q in curve.QUANTILES], axis=2)
    if knots.shape != (len(positions), len(classes), len(curve.QUANTILES)):
        raise ValueError("All target cases and possible-class quantile profiles required")
    mass = np.zeros((len(positions), len(CENTRES)))
    for position in sorted(set(positions)):
        selected = positions == position
        for j, level in enumerate(classes):
            cdf = levels_for(bank, position, level, group)
            mass[selected] += probability[selected, j, None] * curve_mass(knots[selected, j], level, tails, cdf)
    return mass
