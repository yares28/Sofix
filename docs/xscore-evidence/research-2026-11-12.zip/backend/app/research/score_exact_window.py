"""Testing only: exact score-window choices for frozen empirical distributions."""

from __future__ import annotations

import numpy as np

from app.research.score_empirical_density import location_scale, window_mass


def atoms(classes, probability, location, scale, position, bank, prior=20):
    if (
        prior < 0
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.isclose(probability.sum(), 1)
        or not np.isfinite(location).all()
        or not np.isfinite(scale).all()
        or (scale <= 0).any()
    ):
        raise ValueError("Known valid score-distribution inputs required")
    pool = bank["positions"].get(position, bank["global"])
    if not len(pool) or not np.isfinite(pool).all():
        raise ValueError("Known nonempty earlier residual pool required")
    values, weights = [], []
    for j, level in enumerate(classes):
        p = probability[j]
        if p == 0:
            continue
        conditional = bank["levels"].get((position, float(level)))
        if conditional is not None and len(conditional):
            if not np.isfinite(conditional).all():
                raise ValueError("Unknown conditional residuals cannot become zero")
            own_weight, base_weight = len(conditional) / (len(conditional) + prior), prior / (len(conditional) + prior)
            groups = ((conditional, own_weight), (pool, base_weight))
        else:
            groups = ((pool, 1.0),)
        for errors, weight in groups:
            if not weight:
                continue
            floor = level if level >= 60 else 0
            samples = np.clip(np.maximum(floor, level + location[j] + scale[j] * errors), 0, 100)
            values.append(samples)
            weights.append(np.full(len(samples), p * weight / len(samples)))
    if not values:
        raise ValueError("No positive forecast mass")
    return np.concatenate(values), np.concatenate(weights)


def native_bounds(x):
    """First/last representable forecasts satisfying the exact native abs test."""
    x = np.asarray(x, dtype=np.float64)
    outer_radius, inner_radius = np.nextafter(7.0, np.inf), np.nextafter(7.0, 0)
    result = []
    for lower in (True, False):
        if lower:
            outer = np.maximum(0, np.nextafter(x - outer_radius, -np.inf))
            inner = np.minimum(x, np.maximum(0, np.nextafter(x - inner_radius, np.inf)))
        else:
            outer = np.minimum(100, np.nextafter(x + outer_radius, np.inf))
            inner = np.maximum(x, np.minimum(100, np.nextafter(x + inner_radius, -np.inf)))
        outer_good = np.abs(x - outer) <= 7
        if not (np.abs(x - inner) <= 7).all():
            raise ValueError("Native score-window boundary lacks a valid bracket")
        invalid, valid = outer.view(np.uint64).copy(), inner.view(np.uint64).copy()
        for _ in range(64):
            gap = valid - invalid if lower else invalid - valid
            active = (~outer_good) & (gap > 1)
            if not active.any():
                break
            middle = invalid + gap // 2 if lower else valid + gap // 2
            good = np.abs(x - middle.view(np.float64)) <= 7
            valid = np.where(active & good, middle, valid)
            invalid = np.where(active & ~good, middle, invalid)
        else:
            raise ValueError("Native boundary binary search did not finish")
        result.append(np.where(outer_good, outer, valid.view(np.float64)))
    return result[0], result[1]


def maximum_window(samples, weights, reference):
    samples, weights = np.asarray(samples, dtype=float), np.asarray(weights, dtype=float)
    if (
        samples.ndim != 1
        or weights.shape != samples.shape
        or not len(samples)
        or not np.isfinite(samples).all()
        or not np.isfinite(weights).all()
        or (weights < 0).any()
        or weights.sum() <= 0
        or ((samples < 0) | (samples > 100)).any()
        or not np.isfinite(reference)
        or not 0 <= reference <= 100
    ):
        raise ValueError("Finite0to100score atoms, nonnegative mass and known control required")
    x, inverse = np.unique(samples, return_inverse=True)
    weight = np.bincount(inverse, weights=weights, minlength=len(x))
    positive = weight > 0
    x, weight = x[positive], weight[positive]
    weight /= weight.sum()
    low, high = native_bounds(x)
    coordinates, indices = np.unique(np.concatenate((low, high)), return_inverse=True)
    starts = np.bincount(indices[: len(x)], weights=weight, minlength=len(coordinates))
    ends = np.bincount(indices[len(x) :], weights=weight, minlength=len(coordinates))
    delta = starts - ends
    before = np.concatenate(([0.0], np.cumsum(delta)[:-1]))
    at_point = before + starts
    after_point = at_point - ends
    best = float(at_point.max())
    points = coordinates[at_point >= best - 1e-12]
    segments = after_point[:-1] >= best - 1e-12
    projections = np.clip(reference, coordinates[:-1][segments], coordinates[1:][segments])
    choices = np.concatenate((points, projections))
    prediction = float(choices[np.lexsort((choices, np.abs(choices - reference)))[0]])
    achieved = float(weight[np.abs(x - prediction) <= 7].sum())
    if abs(achieved - best) > 1e-12:
        raise ValueError("Native closed-interval maximum does not achieve its stated mass")
    return prediction, {"maximumMass": best, "chosenMass": achieved, "uniqueAtoms": len(x)}


def predict(parts, positions, bank, control, prior=20, spread=0.75):
    classes, probability, quantiles = parts
    location, scale = location_scale(quantiles, bank["mode"])
    scale *= spread
    if len(control) != len(probability) or len(positions) != len(control):
        raise ValueError("Exact forecast case identities differ")
    prediction = np.zeros(len(control))
    statistics = {
        "cases": len(control),
        "changedFromControl": 0,
        "maximumAtoms": 0,
        "meanExactMass": 0.0,
        "meanControlMass": 0.0,
    }
    for i, pos in enumerate(positions):
        samples, weights = atoms(classes, probability[i], location[i], scale[i], pos, bank, prior)
        prediction[i], diagnostic = maximum_window(samples, weights, float(control[i]))
        control_mass = float(weights[np.abs(samples - control[i]) <= 7].sum() / weights.sum())
        if diagnostic["chosenMass"] < control_mass - 1e-12:
            raise ValueError("Exact window lost predicted mass against control")
        statistics["maximumAtoms"] = max(statistics["maximumAtoms"], diagnostic["uniqueAtoms"])
        statistics["meanExactMass"] += diagnostic["chosenMass"] / len(control)
        statistics["meanControlMass"] += control_mass / len(control)
        if (i + 1) % 2000 == 0:
            print(f"EXACT_CASES {i + 1}/{len(control)}", flush=True)
    statistics["changedFromControl"] = int((prediction != control).sum())
    return prediction, statistics


def audit_grid(parts, positions, bank, count=64, prior=20, spread=0.75):
    classes, probability, quantiles = parts
    location, scale = location_scale(quantiles, bank["mode"])
    scale *= spread
    chosen = set(np.linspace(0, len(positions) - 1, min(count, len(positions))).astype(int))
    chosen.update(int(np.flatnonzero(positions == p)[0]) for p in set(positions))
    centres = np.arange(0, 100.01, 0.5)
    largest, differences = 0.0, 0
    for i in sorted(chosen):
        samples, weights = atoms(classes, probability[i], location[i], scale[i], positions[i], bank, prior)
        distance = np.abs(samples[:, None] - centres)
        native = ((distance <= 7) * weights[:, None]).sum(axis=0)
        expected = np.zeros(len(centres))
        pool = bank["positions"].get(positions[i], bank["global"])
        for j, level in enumerate(classes):
            low, high = centres - 7, centres + 7
            clipping = low <= (level if level >= 60 else 0), high >= 100, high < (level if level >= 60 else 0)
            bounds = (low - level - location[i, j]) / scale[i, j], (high - level - location[i, j]) / scale[i, j]
            mass = window_mass(pool, *bounds, *clipping)
            own = bank["levels"].get((positions[i], float(level)))
            if own is not None and len(own):
                mass = (len(own) * window_mass(own, *bounds, *clipping) + prior * mass) / (len(own) + prior)
            expected += probability[i, j] * mass
        error = np.abs(native - expected)
        boundary_mass = ((np.abs(distance - 7) <= 1e-10) * weights[:, None]).sum(axis=0)
        if (error > boundary_mass + 1e-12).any():
            raise ValueError("Exact atom distribution differs from originalCDF beyond roundoff at score-window edges")
        largest = max(largest, float(error.max()))
        differences += int(error.max() > 1e-12)
    return {
        "cases": len(chosen),
        "gridPointsPerCase": len(centres),
        "maximumLegacyNativeMassDifference": largest,
        "casesWithNativeBoundaryDifference": differences,
        "differencesExplainedOnlyByFloatingScoreBoundary": True,
    }
