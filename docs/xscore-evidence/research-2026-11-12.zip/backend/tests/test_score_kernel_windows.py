import numpy as np
import pytest

from app.research.score_kernel_windows import KernelWindows


def test_constant_information_preserves_two_score_modes_instead_of_their_average():
    x = np.zeros((100, 2))
    scores = np.array([40] * 60 + [80] * 40)
    model = KernelWindows(features=8).fit(x, scores)
    p = model.predict(np.array([[0, 0]]))[0]
    assert p[40] == pytest.approx(0.6)
    assert p[80] == pytest.approx(0.4)
    assert p[56] == 0
    assert 33 <= np.argmax(p) <= 47


def test_fit_normalisation_is_unchanged_by_future_outliers_and_missing_is_not_zero():
    x = np.array([[0, np.nan], [2, np.nan], [4, 0], [6, 2]], dtype=float)
    model = KernelWindows(features=8).fit(x, np.array([30, 40, 60, 80]))
    mean = model.mean_.copy()
    original = model.predict([[0, 0]])
    model.predict([[1e10, 1e10], [np.nan, np.nan]])
    np.testing.assert_equal(model.mean_, mean)
    np.testing.assert_allclose(model.predict([[0, 0]]), original)
    assert not np.array_equal(model.normalise([[0, np.nan]]), model.normalise([[0, 0]]))


def test_native_score_window_edges_are_exact_and_unknown_targets_are_rejected():
    model = KernelWindows(features=8).fit(np.zeros((3, 1)), np.array([33, 47, 47.001]))
    assert model.predict([[0]])[0, 40] == pytest.approx(2 / 3)
    with pytest.raises(ValueError, match="valid labels"):
        KernelWindows(features=8).fit(np.zeros((1, 1)), np.array([np.nan]))
