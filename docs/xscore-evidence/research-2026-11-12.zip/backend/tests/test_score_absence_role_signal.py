from app.research.score_absence_role_signal import historical_difference


def test_shrunk_difference_requires_both_known_groups():
    assert historical_difference([90, 80], [50, 60]) == 6
    assert historical_difference([90], [50, 60]) == 0
    assert historical_difference([90, 80], []) == 0


def test_more_recent_support_increases_weight_without_changing_sign():
    assert historical_difference([60] * 8, [80] * 8) == -10
