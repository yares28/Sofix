"""Testing only: independently rebuild European history columns and time exclusions."""

from __future__ import annotations

import argparse
import bisect
import copy
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as europe
from app.research import score_search, score_windows
from app.research.score_search import cutoff_for, moment


def reference_summary(recent, lock):
    if not recent:
        return [0, *([np.nan] * 8), 0, *([np.nan] * 5)]
    points = np.array([r["score"] for r in recent])
    centres = np.arange(201) / 2
    counts = (np.abs(points[:, None] - centres) <= 7).sum(axis=0)
    winning = centres[counts == counts.max()]
    mode = float(winning[np.abs(winning - winning.mean()).argmin()])
    exact = [
        90 * (r["score"] - r["level"]) / r["minutes"]
        for r in recent
        if (r["level"] if r["level"] >= 60 else 0) < r["score"] < 100
    ]
    return [
        len(recent),
        (lock - moment(recent[-1]["date"])).total_seconds() / 86400,
        float(np.mean(points)),
        float(np.median(points)),
        mode,
        float(counts.max() / len(recent)),
        float(sum(r["level"] >= 60 for r in recent) / len(recent)),
        float(sum(r["level"] < 35 for r in recent) / len(recent)),
        float(np.mean([r["minutes"] for r in recent])),
        len(exact),
        float(np.mean(exact)) if exact else np.nan,
        float(np.median(exact)) if exact else np.nan,
        *[
            float(sum(r["ordinary"]["kind"] == k for r in recent) / len(recent))
            for k in ("upper", "lower", "unbounded")
        ],
    ]


def independent_features(rows, observations):
    groups = defaultdict(list)
    for record in observations:
        groups[record["player"], record["pos"]].append(record)
    index = {}
    for identity, records in groups.items():
        records.sort(key=lambda r: (r["date"], r["game"]))
        dates = [moment(r["date"]) for r in records]
        index[identity] = records, dates, [d + timedelta(hours=48) for d in dates]
    output = np.full((len(rows), len(europe.NAMES)), np.nan)
    for i, row in enumerate(rows):
        lock = cutoff_for(row["date"])
        records, dates, available = index.get((row["player"], row["pos"]), ([], [], []))
        low = bisect.bisect_left(dates, lock - timedelta(days=365))
        high = bisect.bisect_left(available, lock)
        past = records[low:high]
        same = [r for r in past if r["cohort"] == row["cohort"]]
        output[i] = [v for group in (past, same) for count in (5, 15) for v in reference_summary(group[-count:], lock)]
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "archives", "features", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    if source["key"] != report["sourceKey"]:
        raise ValueError("European ordinary audit source cases differ")
    with np.load(args.features) as f:
        actual = f["x"]
        if (
            str(f["key"]) != report["featureKey"]
            or f["names"].tolist() != list(europe.NAMES)
            or actual.shape != (len(source["rows"]), 60)
        ):
            raise ValueError("European ordinary feature identity/coverage differs")
    native = json.loads(gzip.decompress(args.features.with_suffix(".observations.json.gz").read_bytes()))
    if native["key"] != report["featureKey"]:
        raise ValueError("European ordinary observation identity differs")
    observations = native["records"]
    files = (
        Path(europe.__file__),
        Path(score_search.__file__),
        Path(score_windows.__file__),
        args.report.with_suffix(".plan.json"),
    )
    receipt = report["receipt"]
    for r in receipt:
        if hashlib.sha256((args.archives / r["archive"]).read_bytes()).hexdigest() != r["sha256"]:
            raise ValueError("European ordinary pinned archive digest differs")
    key = hashlib.sha256(
        (source["key"] + "".join(r["sha256"] for r in receipt)).encode() + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    if key != report["featureKey"]:
        raise ValueError("European ordinary feature source/code/plan fingerprint differs")
    for r in observations:
        s, d = r["score"], r["level"]
        floor = d if d >= 60 else 0
        expected = (
            {"point": None, "lower": None, "upper": None, "kind": "unbounded"}
            if floor == 100
            else {"point": None, "lower": None, "upper": float(floor - d), "kind": "upper"}
            if s == floor
            else {"point": None, "lower": float(100 - d), "upper": None, "kind": "lower"}
            if s == 100
            else {"point": s - d, "lower": s - d, "upper": s - d, "kind": "exact"}
        )
        if r["ordinary"] != expected or s < floor or not 1 <= r["minutes"] <= 120:
            raise ValueError("European ordinary independent native bounds differ")
    canonical_checked = 0
    for row in source["rows"]:
        bounds = europe.ordinary_bounds(row["score"], row["level"])
        if (
            bounds["lower"] is not None
            and row["aa"] < bounds["lower"] - 1e-7
            or bounds["upper"] is not None
            and row["aa"] > bounds["upper"] + 1e-7
        ):
            raise ValueError("Scoring-bound algebra disagrees with native LaLiga actual ordinary points")
        canonical_checked += 1
    rebuilt = independent_features(source["rows"], observations)
    if not np.allclose(rebuilt, actual, equal_nan=True, rtol=0, atol=1e-10):
        bad = ~np.isclose(rebuilt, actual, equal_nan=True, rtol=0, atol=1e-10)
        raise ValueError(f"European independent past-history features differ in{bad.sum()}cells")
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    selected = np.array([r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first for r in source["rows"]])
    query_rows = [copy.deepcopy(r) for r, yes in zip(source["rows"], selected, strict=True) if yes]
    for r in query_rows:
        r.update(aa=999999, score=-999, minutes=-999, level=100)
    changed, mutations = [], 0
    for r in observations:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            changed.append(
                {
                    **r,
                    "score": np.nan,
                    "level": 100,
                    "minutes": -999,
                    "cohort": None,
                    "ordinary": {"kind": "exact", "point": np.nan},
                }
            )
            mutations += 1
        else:
            changed.append(r)
    causality = europe.build_features(query_rows, changed)
    if not np.allclose(causality, actual[selected], equal_nan=True, rtol=0, atol=1e-10):
        raise ValueError("Unavailable European outcomes or current target labels changed earlier features")
    output = {
        "scope": "Research-only source/feature audit, no accuracy claim",
        "featureKey": key,
        "nativeEuropeanObservationsChecked": len(observations),
        "nativeEuropeanCensorCounts": dict(Counter(r["ordinary"]["kind"] for r in observations)),
        "nativeLaLigaPointBoundsChecked": canonical_checked,
        "independentFeatureRowsReconstructed": len(rebuilt),
        "featureColumns": 60,
        "unavailableEuropeanOutcomeRowsMutated": mutations,
        "first2026LockCasesUnchangedAfterMutation": len(query_rows),
        "all6754Starts2925BenchRetained": True,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
