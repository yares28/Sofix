"""Research-only conditional corner count and ordinary point prediction."""

import hashlib
import json
from collections import Counter, defaultdict
from datetime import timedelta
from statistics import mean

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, POSITIONS, fit, metrics, own_history

STEM = "laliga_score_corner_allocation"


def corner_estimate(own, opponent, history, person, cohort, lock):
    recent_limit = lock - timedelta(days=180)
    recent_own = [r for r in own[-8:] if r[0] >= recent_limit]
    recent_other = [r for r in opponent[-8:] if r[0] >= recent_limit]
    appearances = [r for r in history[-10:] if r[0] >= recent_limit]
    personal = mean(r[1] for r in appearances) if appearances else 0.0
    same_role = [r for r in recent_own if (person, cohort) in r[3]]
    if not same_role or not recent_other:
        return personal, personal
    volume = (sum(r[1] for r in recent_own) + sum(r[2] for r in recent_other) + 20) / (
        len(recent_own) + len(recent_other) + 4
    )
    role_corners = sum(r[3][person, cohort] for r in same_role)
    role_volume = sum(r[1] for r in same_role)
    # Four prior team matches at the personal per-appearance rate.
    allocated = volume * (role_corners + 4 * personal) / (role_volume + 20)
    return personal, allocated


def features(rows, games):
    fixtures = {g["id"]: g for g in games}
    by_game = defaultdict(list)
    for i, row in enumerate(rows):
        by_game[row["game"]].append(i)
    ordered = sorted(by_game, key=lambda k: (fixtures[k]["date"], k))
    clubs, people, aa_history = defaultdict(list), defaultdict(list), defaultdict(list)
    future, cursor = {}, 0
    ready = [moment(fixtures[k]["date"]) + DELAY for k in ordered]
    output, labels = np.empty((len(rows), 10)), np.empty((len(rows), 2))
    for game in ordered:
        g = fixtures[game]
        lock = cutoff_for(g["date"])
        while cursor < len(ordered) and ready[cursor] < lock:
            previous = ordered[cursor]
            date, club_records, players = future.pop(previous)
            for club, total, opponent_total, records in club_records:
                clubs[club].append((date, total, opponent_total, records))
            for key, count, aa in players:
                people[key].append((date, count))
                aa_history[key].append((date, aa))
            cursor += 1
        home, away = (g[side]["slug"] for side in ("home", "away"))
        corners, players = {home: {}, away: {}}, []
        for i in by_game[game]:
            row = rows[i]
            player, cohort, pos = (row[f] for f in ("player", "cohort", "pos"))
            source = g["players"][player]
            club = source["team"]
            other = away if club == home else home
            key = (player, club, cohort)
            personal, allocated = corner_estimate(clubs[club], clubs[other], people[key], player, cohort, lock)
            long, short, n = own_history(aa_history[key], lock)
            output[i] = [
                *(float(pos == p) for p in POSITIONS),
                float(club == home),
                long,
                short - long,
                np.log1p(n),
                personal,
                allocated - personal,
            ]
            count, aa = source["corners"], row["aa"]
            if type(count) is not int or count < 0 or row["date"] != g["date"] or abs(aa - source["aa"]) > 1e-7:
                raise ValueError("Invalid corner count or case identity")
            labels[i] = count, aa - long
            corners[club][player, cohort] = count
            players.append((key, count, aa))
        # Avoid calling incomplete native team coverage a known total.
        expected = {p for p, info in g["players"].items() if info.get("played")}
        assert expected == {key[0] for records in corners.values() for key in records}
        totals = {club: sum(records.values()) for club, records in corners.items()}
        future[game] = (
            moment(g["date"]),
            [(home, totals[home], totals[away], corners[home]), (away, totals[away], totals[home], corners[away])],
            players,
        )
    return output, labels


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    x, y = features(rows, games)
    roles = np.array([r["cohort"] for r in rows])
    date = np.array([r["date"] for r in rows])
    locks = np.array([cutoff_for(d) for d in date])
    ready = np.array([moment(d) + DELAY for d in date])
    periods, totals = {}, defaultdict(Counter)
    for phase, (begin, end) in PHASES.items():
        window = (date >= begin) & (date < end)
        earlier = ready < locks[window].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, check = earlier & (roles == role), window & (roles == role)
            old, new = [fit(a, y[:, 1], train, check) for a in (x[:, :-1], x)]
            result = metrics(y[check, 1], old, new)
            mse = []
            for inputs in (x[:, :-1], x):
                residual = y[:, 0] - x[:, 8]
                forecast = np.maximum(x[check, 8] + fit(inputs, residual, train, check), 0)
                mse.append(float(np.mean((y[check, 0] - forecast) ** 2)))
            periods[phase][role] = dict(
                **result,
                cornerMSE=mse,
                allocatedFeatureCases=int(np.count_nonzero(x[check, -1])),
            )
            total = totals[role]
            total["cornerGain"] += result["n"] * (mse[0] - mse[1])
            total["aaGain"] += result["n"] * (result["mae"][0] - result["mae"][1])
            total["hitGain"] += result["gained"] - result["lost"]
            total["n"] += result["n"]
            total["phasesWithoutLoss"] += (
                result["mae"][1] <= result["mae"][0] and result["hits"][1] >= result["hits"][0]
            )
    gate = {
        role: dict(
            **t,
            passEarlier=t["cornerGain"] > 0 and t["aaGain"] > 0 and t["hitGain"] > 0 and t["phasesWithoutLoss"] >= 2,
        )
        for role, t in totals.items()
    }
    result = dict(
        source=NATIVE_SHA,
        casesKey=source["key"],
        periods=periods,
        gate=gate,
        laterOutcomesEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
