import numpy as np
import pytest

from app.research.score_direct_windows import direct_choice, gated_choice, window_targets


def test_labels_cover_overlapping_windows_and_include_exact_boundaries():
    values = window_targets(np.array([0.0, 35, 40, 100]))
    assert values.shape == (4, 101)
    assert values[1, 28] == values[1, 42] == 1
    assert values[1, 27] == values[1, 43] == 0
    assert values[0, 0] == values[-1, -1] == 1
    assert values[1].sum() == 15
    with pytest.raises(ValueError, match="known"):
        window_targets(np.array([np.nan]))


def test_choice_preserves_one_winning_mode_instead_of_averaging_modes():
    probability = np.zeros((2, 101))
    probability[:, 40] = probability[:, 80] = 0.5
    candidate = direct_choice(probability, np.array([56.0, 65]))
    np.testing.assert_array_equal(candidate, [40, 80])


def test_gate_compares_to_interpolated_control_chance_and_keeps_every_case():
    probability = np.full((3, 101), 0.1)
    probability[:, 40] = 0.6
    probability[:, 50] = 0.59
    probability[:, 51] = 0.57
    control = np.array([50.5, 50.5, 50.5])
    positions = np.array(["DEF", "MID", "FWD"])
    np.testing.assert_array_equal(gated_choice(probability, control, positions, 0.01, "defmid"), [40, 40, 50.5])
    np.testing.assert_array_equal(gated_choice(probability, control, positions, 0.025, "all"), control)
