"""Testing only: independent position models with all-case control fallbacks."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_europe_run import predict_components, select_components
from app.research.score_feature_compare import cached_components
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval


def position_masks(positions, fit, check, position):
    return fit & (positions == position), check & (positions == position)


def put_predictions(fallback, selected, replacements):
    if int(selected.sum()) != len(replacements):
        raise ValueError("Prediction count differs from selected cases")
    result = fallback.copy()
    result[selected] = replacements
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "control", "selector", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    control = json.loads(args.control.read_text(encoding="utf-8"))
    selector = json.loads(args.selector.read_text(encoding="utf-8"))
    if source["key"] != control["sourceKey"]:
        raise ValueError("Control source differs")
    with np.load(args.stats_cache) as stored:
        allx, stat_key = stored["x"], str(stored["key"])
    key = hashlib.sha256((source["key"] + stat_key).encode() + Path(__file__).read_bytes()).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "implementationKey": key,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        x = allx[keep]
        dates = np.array([r["date"][:10] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        y, aa, level = (np.array([r[n] for r in rows]) for n in ("score", "aa", "level"))
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        with np.load(args.cache / f"selector_{cohort}_control_earlier.npz") as stored:
            if str(stored["key"]) != selector["implementationKey"]:
                raise ValueError("Earlier control cache differs")
            earlier_control = stored["prediction"]
        if measure(y[valid], earlier_control) != control["cohorts"][cohort]["selection"]["control"]["selection"]:
            raise ValueError("Earlier control metrics do not reproduce")
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Later cases differ")
            baseline = stored["control"]
        frozen = {}
        for pos in POSITIONS:
            fit, check = position_masks(positions, train, valid, pos)
            if fit.sum() < 200 or check.sum() < 50:
                frozen[pos] = {
                    "use": "control",
                    "reason": "Insufficient earlier cases",
                    "fit": int(fit.sum()),
                    "selection": int(check.sum()),
                }
                continue
            path = args.cache / f"specialists_{cohort}_{pos}_selection.npz"
            parts = cached_components(path, key, x, aa, level, fit, check)
            winner, _ = select_components(parts, y[check])
            reference = measure(y[check], earlier_control[positions[valid] == pos])
            use = (
                "specialist"
                if (winner["selection"]["within7"], -winner["selection"]["mae"])
                > (reference["within7"], -reference["mae"])
                else "control"
            )
            frozen[pos] = {"use": use, "winner": winner, "control": reference}
            print(f"Selected {cohort} {pos}: " + json.dumps(frozen[pos]), flush=True)
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2), encoding="utf-8")
        predictions = {"control": baseline, "specialists": baseline.copy(), "earlier_position_choice": baseline.copy()}
        for pos, spec in frozen.items():
            if "winner" not in spec:
                continue
            fit, check = position_masks(positions, ~test, test, pos)
            if not check.any():
                continue
            path = args.cache / f"specialists_{cohort}_{pos}_later.npz"
            parts = cached_components(path, key, x, aa, level, fit, check)
            prediction = predict_components(parts, spec["winner"])
            selected = positions[test] == pos
            predictions["specialists"] = put_predictions(predictions["specialists"], selected, prediction)
            if spec["use"] == "specialist":
                predictions["earlier_position_choice"] = put_predictions(
                    predictions["earlier_position_choice"], selected, prediction
                )
            print(f"Evaluated {cohort} {pos}", flush=True)
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {"frozen": frozen, "groups": {}}
        for group, prediction in predictions.items():
            result["groups"][group] = {
                "later": measure(y[test], prediction),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "gain95": paired_interval(y[test], prediction, baseline, weeks),
                "positions": {
                    pos: measure(y[test][positions[test] == pos], prediction[positions[test] == pos])
                    for pos in POSITIONS
                    if (positions[test] == pos).any()
                },
            }
        np.savez_compressed(args.cache / f"specialists_predictions_{cohort}.npz", key=key, y=y[test], **predictions)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT " + json.dumps({"cohort": cohort, "groups": {n: v["later"] for n, v in result["groups"].items()}}),
            flush=True,
        )


if __name__ == "__main__":
    main()
