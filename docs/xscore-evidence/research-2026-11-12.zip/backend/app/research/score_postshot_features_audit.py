"""Independent all24 lagged finishing inputs and actual unavailable-data mutation."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from bisect import bisect_left
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_postshot_features as study
from app.research.score_search import cutoff_for, moment


def reconstruct(rows, games, records):
    source = {(r["game"], r["player"]): r for r in records}
    by_person = defaultdict(list)
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        for player, p in g["players"].items():
            m = p.get("mins")
            if (
                p.get("played") is True
                and p.get("ver") == 7
                and p.get("pos") in ("GK", "DEF", "MID", "FWD")
                and isinstance(p.get("stats"), dict)
                and type(m) in (int, float)
                and np.isfinite(m)
                and m >= 0
            ):
                by_person[player].append((moment(g["date"]), g["id"], p))
    times = {p: [a for a, _, _ in values] for p, values in by_person.items()}
    built = []
    for row in rows:
        lock = cutoff_for(row["date"])
        dates = times.get(row["player"], [])
        end = bisect_left(dates, lock - timedelta(hours=48))
        begin = bisect_left(dates, lock - timedelta(days=365))
        history = by_person.get(row["player"], [])
        values = []
        for size in (3, 10):
            chosen = history[max(begin, end - size) : end]
            total_minutes = sum(p["mins"] for _, _, p in chosen)
            total_sot = sum(p["stats"].get("ontarget_scoring_att", [0])[0] for _, _, p in chosen)
            goals = sum(p["stats"].get("goals", [0])[0] for _, _, p in chosen)
            valid = [
                (date, p, source[gid, row["player"]])
                for date, gid, p in chosen
                if (gid, row["player"]) in source and source[gid, row["player"]]["known"]
            ]
            known_minutes = sum(p["mins"] for _, p, _ in valid)
            sot = sum(r["nativeSOT"] for _, _, r in valid)
            quality = sum(r["postshotTotal"] for _, _, r in valid)
            paired = [r for _, _, r in valid if r["matchedPreshotTotal"] is not None]
            paired_n = sum(r["nativeSOT"] for r in paired)
            preshot = sum(r["matchedPreshotTotal"] for r in paired)
            shot_dates = [date for date, _, r in valid if r["nativeSOT"] > 0]
            values.extend(
                [
                    len(chosen),
                    total_minutes,
                    90 * total_sot / total_minutes if total_minutes > 0 else np.nan,
                    90 * goals / total_minutes if total_minutes > 0 else np.nan,
                    len(valid),
                    known_minutes,
                    known_minutes / total_minutes if total_minutes > 0 else 0.0,
                    90 * sot / known_minutes if known_minutes > 0 else np.nan,
                    preshot / paired_n if paired_n > 0 else np.nan,
                    (lock - max(shot_dates)).total_seconds() / 86400 if shot_dates else np.nan,
                    quality / sot if sot > 0 else np.nan,
                    90 * quality / known_minutes if known_minutes > 0 else np.nan,
                ]
            )
        built.append(values)
    return np.array(built)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_postshot_features.json"))
    args = parser.parse_args()
    source, report = json.loads((args.cache / "cases.json").read_text()), json.loads(args.out.read_text())
    raw, data = args.games.read_bytes(), (args.cache / "postshot_observations.json.gz").read_bytes()
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + data
        + Path(study.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if (
        key != report["featureKey"]
        or hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(data).hexdigest() != "8aed062f076105d35eb99a9e3234321d840b05dbe960702ed6ed68dd0a1c1bcf"
    ):
        raise ValueError("Pinned feature/native/source identity differs")
    path = args.cache / "postshot_features.npz"
    if hashlib.sha256(path.read_bytes()).hexdigest() != report["featuresSHA"]:
        raise ValueError("Feature artifact changed")
    with np.load(path) as f:
        if str(f["key"]) != key or str(f["source_key"]) != source["key"] or len(f["names"]) != 24:
            raise ValueError("Full case/schema identity differs")
        x = f["x"]
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    indexed = {g["id"]: g for g in games}
    for r in source["rows"]:
        p, g = indexed[r["game"]]["players"][r["player"]], indexed[r["game"]]
        if (
            g["date"] != r["date"]
            or p["played"] is not True
            or p["ver"] != 7
            or bool(p["started"]) != (r["cohort"] == "start")
            or p["pos"] != r["pos"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Independent native forecast case differs")
    records = json.loads(gzip.decompress(data))["records"]
    rebuilt = reconstruct(source["rows"], games, records)
    np.testing.assert_allclose(rebuilt, x, rtol=0, atol=1e-10, equal_nan=True)
    lock = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if cutoff_for(r["date"]) == lock]
    selected = [source["rows"][i] for i in indices]
    changed_games, changed_records = deepcopy((games, records))
    n_games, n_records = 0, 0
    for g in changed_games:
        if moment(g["date"]) + timedelta(hours=48) >= lock:
            n_games += 1
            g["xi"] = "UNAVAILABLE ACTUAL XI"
            for p in g["players"].values():
                p.update(mins=999999, stats={"goals": [999999, 0], "ontarget_scoring_att": [999999, 0]})
    for r in changed_records:
        if moment(r["date"]) + timedelta(hours=48) >= lock:
            n_records += 1
            r.update(known=True, minutes=999999, nativeSOT=999999, postshotTotal=999999, matchedPreshotTotal=999999)
    mutated, _, _ = study.build_features(selected, changed_games, changed_records)
    np.testing.assert_array_equal(mutated, x[indices])
    result = dict(
        featureKey=key,
        nativeCasesVerified=len(x),
        independentlyRecomputedColumns=24,
        sourceQualifiedRecords=len(records),
        allNativeHistoryAndMissingCasesVerified=True,
        actualFutureMutation=dict(
            unavailableFixtures=n_games,
            unavailableProviderProfiles=n_records,
            targetRows=len(indices),
            all24columnsExact=True,
        ),
        status="COMPLETE independent full native24column/strict-history/future-mutation audit; no accuracy claim",
    )
    args.out.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2) + "\n")
    print("POSTSHOT_FEATURE_AUDIT " + json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
