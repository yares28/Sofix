"""Testing only: prove unchanged event forecasts and reconstruct unconditional AA scores."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_unconditional_ordinary as unconditional
from app.research import score_unconditional_ordinary_run as runner
from app.research.score_joint_density import components
from app.research.score_search import measure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Unconditional audit source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        stat_key = str(f["key"])
    modules = (unconditional, empirical, flow, matched, controls, ordinary, stability)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Unconditional audit code/plan fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or winner != frozen["winner"]
            or best != frozen["best"]
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Unconditional audit earlier choice/gate differs")
        bundles = {}
        for phase, _, _ in stability.PHASES:
            old = flow.old_components(call_args, cohort, phase, old_match, old_stability, old_ordinary)
            for mode in [best["spec"]["model"]] if phase == "later2026" else ("pooled", "position"):
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{mode}.npz"
                pieces = components(path, key)
                with np.load(path) as f:
                    stats = json.loads(str(f["statistics"]))
                if (
                    not np.array_equal(pieces[0], old[0])
                    or not np.array_equal(pieces[1], old[1])
                    or len(pieces[1]) != int(masks[phase]["target"].sum())
                ):
                    raise ValueError("Unconditional AA changed event probabilities/classes or coverage")
                if any(
                    not np.isfinite(q).all() or not np.array_equal(q, np.repeat(q[:, :1], len(pieces[0]), axis=1))
                    for q in pieces[2].values()
                ):
                    raise ValueError("Unconditional AA differs across possible decisive classes")
                counts = {
                    p: int((masks[phase]["fit"] & (positions == p)).sum())
                    for p in set(positions[masks[phase]["target"]])
                }
                expected_fallback = sorted(p for p, n in counts.items() if n < 80) if mode == "position" else []
                if (
                    stats["fitCasesByTargetPosition"] != counts
                    or stats["pooledFallbackPositions"] != expected_fallback
                    or stats["DSLabelsPassedToAARegressor"]
                    or stats["fitCases"] != int(masks[phase]["fit"].sum())
                ):
                    raise ValueError("Unconditional AA fit/fallback contract differs")
                bundles[(phase, mode)] = pieces
        comparisons = 0
        for phase_index, (phase, _, _) in enumerate(stability.PHASES[1:], start=1):
            target = masks[phase]["target"]
            past_phase = stability.PHASES[phase_index - 1][0]
            past_rows = [r for r, yes in zip(rows, masks[past_phase]["target"], strict=True) if yes]
            control = controls.control_for(
                call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Unconditional AA strongest control differs")
            active = [best] if phase == "later2026" else frozen["candidates"]
            for mode, spread in sorted({(r["spec"]["model"], r["spec"]["spread"]) for r in active}):
                bank = matched.bank_from(bundles[(past_phase, mode)], past_rows, masks[phase]["first"])
                raw = empirical.empirical_predictions(*bundles[(phase, mode)], positions[target], bank, 20, spread, 0)
                for record in [r for r in active if (r["spec"]["model"], r["spec"]["spread"]) == (mode, spread)]:
                    candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    if phase == "later2026":
                        alternate = candidate
                    elif measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                        raise ValueError("Unconditional AA earlier score forecasts do not reconstruct")
                    comparisons += 1
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Unconditional AA final case/score identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Unconditional AA final native metric differs")
            h1, h0 = np.abs(y[target] - f["alternate"]) <= 7, np.abs(y[target] - f["control"]) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "candidateForecastsReconstructed": comparisons,
            "eventProbabilitiesUnchangedEveryCaseAndPhase": True,
            "AAIdenticalAcrossAllPossibleClasses": True,
            "earlierSelectionVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            keep = np.array([r["cohort"] == cohort for r in source["rows"]])
            with np.load(args.cache / "stats.npz") as f:
                base = f["x"][keep]
            with np.load(args.cache / "match_context_features.npz") as f:
                x = np.column_stack((base, f["x"][keep]))
            aa = np.array([r["aa"] for r in rows], dtype=float)
            aa[~masks["later2026"]["fit"]] = np.nan
            saved = bundles[("later2026", best["spec"]["model"])]
            print(f"UNCONDITIONAL_AUDIT_REFIT {cohort} {best['spec']['model']}", flush=True)
            repeated, _ = unconditional.fit_quantiles(
                x,
                aa,
                positions,
                masks["later2026"]["fit"],
                masks["later2026"]["target"],
                saved[0],
                best["spec"]["model"],
            )
            if any(not np.allclose(repeated[q], saved[2][q], rtol=0, atol=1e-10) for q in repeated):
                raise ValueError("Unconditional AA real refit changed after blanking outside-fit outcomes")
            evidence[cohort]["realRefitAfterOutsideFitAABlanked"] = {
                "outsideFitAARowsBlanked": int((~masks["later2026"]["fit"]).sum()),
                "allThreeQuantilesReproduced": True,
            }
    output = {
        "scope": "Research-only independent native all-case/components/freeze/score audit, no fresh blind claim",
        "implementationKey": key,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
