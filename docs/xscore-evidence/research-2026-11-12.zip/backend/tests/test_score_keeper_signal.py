import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))

from app.research import score_keeper_signal as signal


def test_both_keeper_architectures_ignore_nontraining_labels():
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(6)
    x = rng.normal(size=(240, 49))
    x[::9, -1] = np.nan
    y = rng.integers(0, 2, size=240).astype(float)
    fit, target = np.arange(240) < 180, np.arange(240) >= 180
    blinded = y.copy()
    blinded[~fit] = np.nan
    for architecture in ("logistic", "nonlinear"):
        expected = signal.fitted(x, y, fit, target, architecture)
        actual = signal.fitted(x, blinded, fit, target, architecture)
        np.testing.assert_array_equal(expected["probability"], actual["probability"])


def test_full_keeper_schema_coverage_shared_baseline_and_actual_quality_not_injected():
    from types import SimpleNamespace

    args = SimpleNamespace(
        cache=Path("data/raw/score-foundation"),
        games=Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl"),
        out=Path("reports/experiments/laliga_score_keeper_signal.json"),
    )
    source, inputs, labels, _ = signal.load_inputs(args)
    assert len(source["rows"]) == 38850 and inputs["baseline"].shape == (38850, 47)
    assert inputs["keeper"].shape == (38850, 49)
    np.testing.assert_array_equal(inputs["keeper"][:, :47], inputs["baseline"])
    assert np.isnan(inputs["keeper"][:, -2:]).any()
    assert set(labels) == {"goal", "goalassist"}
