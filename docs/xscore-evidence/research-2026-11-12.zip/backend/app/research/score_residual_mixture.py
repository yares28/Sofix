"""Testing only: conditional density of genuinely earlier out-of-fit AA errors."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research.score_mixture_ordinary import MixtureNetwork, design, mixture_mass
from app.research.score_modal_trees import CENTRES

SETTINGS = {
    "k2_width16_l2small": {"components": 2, "width": 16, "ridge": 0.01},
    "k2_width16_l2strong": {"components": 2, "width": 16, "ridge": 0.1},
    "k4_width32_l2strong": {"components": 4, "width": 32, "ridge": 0.1},
}


def eligible_training(records, first_lock):
    selected = np.asarray(records["available"]) < first_lock
    if not selected.any():
        raise ValueError("No available out-of-fit AA errors before first phase lock")
    x = np.asarray(records["x"])[selected]
    errors = np.asarray(records["error"])[selected]
    positions = np.asarray(records["position"])[selected]
    levels = np.asarray(records["level"])[selected]
    if not np.isfinite(errors).all() or not np.isfinite(levels).all():
        raise ValueError("Available out-of-fit labels cannot be unknown or replaced by zero")
    raw = design(x, positions, levels)
    return selected, raw, errors


def fit_forecasts(records, context, parts, positions, first_lock, setting, epochs=80):
    classes, probability, quantiles = parts
    classes, probability, positions, context = map(np.asarray, (classes, probability, positions, context))
    n = len(context)
    if (
        context.ndim != 2
        or positions.shape != (n,)
        or probability.shape != (n, len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Residual mixture target probability/coverage differs")
    q = np.sort(np.stack([quantiles[v] for v in (0.35, 0.5, 0.65)]), axis=0)
    if q.shape != (3, n, len(classes)) or not np.isfinite(q).all():
        raise ValueError("Residual mixture original conditional quantiles differ")
    selected, raw, errors = eligible_training(records, first_lock)
    if raw.shape[1] != context.shape[1] + 8:
        raise ValueError("Residual mixture past/target context dimensions differ")
    model = MixtureNetwork(**setting, epochs=epochs).fit(raw, errors)
    mass = np.zeros((n, len(CENTRES)))
    for j, level in enumerate(classes):
        location = q[1, :, j]
        query = np.column_stack((context, location, q[2, :, j] - q[0, :, j], probability[:, j]))
        weights, means, scales = model.predict(design(query, positions, level))
        mass += probability[:, j, None] * mixture_mass(weights, means + location[:, None], scales, level)
    if not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1 + 1e-12).any():
        raise ValueError("Residual mixture lost valid all-case native window mass")
    normaliser = model.normaliser_
    receipt = {
        "eligibleOOFErrors": int(selected.sum()),
        "excludedUnavailableErrors": int((~selected).sum()),
        "firstLock": float(first_lock),
        "targetCases": n,
        "contextFeatures": context.shape[1],
        "designFeatures": raw.shape[1],
        "settings": setting,
        "epochs": epochs,
        "eventProbabilitiesUnchanged": True,
        "currentOutcomeLabelsNotAnInput": True,
        "trainingOnlyLoss": model.loss_history_,
        "normaliserSha256": hashlib.sha256(
            normaliser.mean_.tobytes() + normaliser.scale_.tobytes() + normaliser.known_.tobytes()
        ).hexdigest(),
        "weightsSha256": hashlib.sha256(b"".join(w.tobytes() for w in model.weights_)).hexdigest(),
        "eligibleDataSha256": hashlib.sha256(raw.tobytes() + errors.tobytes()).hexdigest(),
    }
    return mass, receipt
