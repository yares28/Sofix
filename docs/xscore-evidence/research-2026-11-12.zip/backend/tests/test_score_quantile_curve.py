from pathlib import Path

import numpy as np
import pytest

from app.research.score_modal_trees import CENTRES
from app.research.score_quantile_curve import QUANTILES, curve_mass, fit_quantiles, forecast_mass
from app.research.score_windows import window_centres


def test_linear_quantile_curve_gives_exact_uniform_score_mass_with_floor_and_cap():
    q = np.array(QUANTILES)
    for lower, upper, level in ((-10.0, 10.0, 60.0), (30.0, 50.0, 60.0), (-50.0, -20.0, 35.0), (-5.0, 20.0, 0.0)):
        knots = (lower + (upper - lower) * q)[None, :]
        mass = curve_mass(knots, level, "extrapolate")[0]
        expected = []
        floor = level if level >= 60 else 0
        for centre in CENTRES:
            lo, hi = centre - 7, centre + 7
            before = 0 if lo <= floor else np.clip((lo - level - lower) / (upper - lower), 0, 1)
            after = 1 if hi >= 100 else np.clip((hi - level - lower) / (upper - lower), 0, 1)
            expected.append(0 if hi < floor else max(0, after - before))
        np.testing.assert_allclose(mass, expected, rtol=0, atol=1e-14)


def test_duplicate_knots_are_exact_native_atoms_with_inclusive_seven_boundary():
    for aa, level in ((5.0, 35.0), (-20.0, 60.0), (100.0, 35.0), (-100.0, 35.0)):
        score = np.clip(max(level if level >= 60 else 0, level + aa), 0, 100)
        for tails in ("clamp", "extrapolate"):
            mass = curve_mass(np.full((1, len(QUANTILES)), aa), level, tails)[0]
            np.testing.assert_allclose(mass, (np.abs(score - CENTRES) <= 7).astype(float), rtol=0, atol=1e-14)


def test_multimodal_quantile_curve_selects_a_peak_and_missing_values_are_not_zero():
    knots = np.where(np.array(QUANTILES) <= 0.6, 5.0, 45.0)[None, :]
    mass = curve_mass(knots, 35.0, "clamp")
    forecast = window_centres(mass, CENTRES)[0]
    assert abs(forecast - 40) <= 7 and abs(forecast - 80) > 7
    with pytest.raises(ValueError, match="finite"):
        curve_mass(knots * np.nan, 35.0, "clamp")


def test_actual_quantile_models_ignore_all_outside_fit_labels(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    rng = np.random.default_rng(41)
    x = rng.normal(size=(180, 2))
    x[::7, 0] = np.nan
    aa = rng.normal(8, 8, 180)
    levels = rng.choice([35.0, 60.0], 180)
    fit = np.arange(180) < 160
    target = ~fit
    classes = np.array([35.0, 60.0])
    old = {q: np.zeros((20, 2)) for q in (0.35, 0.5, 0.65)}
    first, _ = fit_quantiles(x, aa, levels, fit, target, classes, old, iterations=3)
    aa[target] = np.nan
    levels[target] = np.nan
    repeated, _ = fit_quantiles(x, aa, levels, fit, target, classes, old, iterations=3)
    assert set(first) == set(QUANTILES)
    for q in QUANTILES:
        np.testing.assert_equal(first[q], repeated[q])


def test_possible_class_mass_rejects_invalid_probabilities_and_keeps_every_case():
    classes = np.array([35.0, 60.0])
    parts = {q: np.full((2, 2), 5.0) for q in QUANTILES}
    mass = forecast_mass(classes, np.tile([0.8, 0.2], (2, 1)), parts, "clamp")
    assert mass.shape == (2, 201) and np.isfinite(mass).all()
    with pytest.raises(ValueError, match="probability"):
        forecast_mass(classes, np.ones((2, 2)), parts, "clamp")
