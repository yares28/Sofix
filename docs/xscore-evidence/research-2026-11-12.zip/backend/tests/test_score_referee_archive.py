from datetime import UTC, datetime

import pytest

from app.research import score_referee_archive as source


def test_female_fourth_official_does_not_replace_the_match_referee():
    rows = source.parse_rows(
        "Competición: Campeonato Nacional de Liga de Primera División - Primera División\n02-01-2026 Rayo Vallecano de Madrid Getafe CF 21:00\nÁrbitro:Miguel Ángel Ortiz 4ª Árbitra: Olatz Rivera\nA. Asistente 1: José Antonio Garrido VAR: Javier Iglesias"
    )
    assert rows[0]["referee"] == "Miguel Ángel Ortiz"
    assert len(rows) == 1


def test_bare_top_division_header_is_valid_but_other_competitions_are_not():
    row = "08-02-2026 Deportivo Alavés Getafe CF 14:00\nÁrbitro:Juan Martínez 4º Árbitro:Aimar Velasco"
    assert (
        source.parse_rows("Competición: Campeonato Nacional de Liga de Primera División\n" + row)[0]["referee"]
        == "Juan Martínez"
    )
    for suffix in [" Femenina", " de Fútbol Sala", " - Segunda División"]:
        with pytest.raises(ValueError, match="competition"):
            source.parse_rows("Competición: Campeonato Nacional de Liga de Primera División" + suffix + "\n" + row)


def test_legacy_punctuation_and_split_competition_header_are_source_format_only():
    rows = source.parse_rows(
        "Competición:\nCampeonato Nacional de Primera División - Primera División Jornada - 13\n29-11-2023 R.C.D. Mallorca Cádiz C.F. 21:00\n\nÁrbitro:Iglesias Villanueva, Javier 4º Árbitro:Muñoz Piedra, Pedro Eugenio"
    )
    assert rows[0]["home"] == "RCD Mallorca"
    assert rows[0]["away"] == "Cádiz CF"
    assert rows[0]["printedPair"] == "R.C.D. Mallorca Cádiz C.F."


def test_empty_footer_page_and_unassigned_printed_slot_cannot_invent_referees():
    header = "Competición: Campeonato Nacional de Primera División - Primera División Jornada - 13\n"
    assert source.parse_rows(header + "TEMPORADA2023-2024\nPágina 2 de 2") == []
    rows = source.parse_rows(header + "29-11-2023 R.C.D. Mallorca Cádiz C.F. 21:00\nPlaza Luis Aragonés s/n")
    assert rows[0]["referee"] is None
    assert (
        source.choose([dict(rows[0], availableUTC="2023-11-08T12:00:00+00:00")], datetime(2023, 11, 28, 14, tzinfo=UTC))
        is None
    )


def test_later_available_revision_overrides_earlier_appointment_only_after_release():
    old = dict(referee="A", availableUTC="2026-01-23T12:00:00+00:00")
    new = dict(referee="B", availableUTC="2026-01-23T15:00:00+00:00")
    lock = datetime(2026, 1, 23, 14, tzinfo=UTC)
    assert source.choose([old, new], lock) == old
    assert source.choose([old, new], lock.replace(hour=16)) == new


def test_exact_lock_equality_and_unknown_clock_are_not_available():
    cutoff = datetime(2026, 1, 23, 14, tzinfo=UTC)
    assert (
        source.choose(
            [dict(referee="A", availableUTC=None), dict(referee="B", availableUTC=cutoff.isoformat())], cutoff
        )
        is None
    )


def test_conflicting_latest_appointments_are_unknown_instead_of_arbitrary_choice():
    stamp = "2026-01-23T12:00:00+00:00"
    assert (
        source.choose(
            [dict(referee="A", availableUTC=stamp), dict(referee="B", availableUTC=stamp)],
            datetime(2026, 1, 23, 14, tzinfo=UTC),
        )
        is None
    )
