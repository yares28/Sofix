import numpy as np
import pytest

from app.research import score_rolling_strong as rolling
from app.research.score_rolling_strong_audit import rebuild_raw, verify_phase
from app.research.score_rolling_strong_run import cached_parts


def example(tmp_path, monkeypatch):
    rows = [
        {"date": d, "level": level}
        for d, level in (
            ("2023-08-01T20:00:00Z", 35),
            ("2023-08-02T20:00:00Z", 60),
            ("2024-01-12T20:00:00Z", 35),
            ("2024-02-03T20:00:00Z", 35),
        )
    ]
    selected = np.array([False, False, True, True])

    def fit(x, aa, levels, fit, check):
        classes = np.unique(levels[fit])
        p = np.full((int(check.sum()), len(classes)), 1 / len(classes))
        return classes, p, {q: np.full_like(p, 5.0) for q in rolling.QUANTILES}

    monkeypatch.setattr(rolling, "conditional_components", fit)
    cached_parts(
        np.zeros((4, 1)),
        rows,
        np.ones(4),
        np.array([r["level"] for r in rows]),
        selected,
        0,
        tmp_path,
        "testkey",
        "toy",
        "start",
        "spring2024",
    )
    path = tmp_path / "toy_components_start_spring2024_w0_testkey.npz"
    return path, rows, selected


def test_independent_month_audit_reconstructs_exact_masks_support_and_coverage(tmp_path, monkeypatch):
    path, rows, selected = example(tmp_path, monkeypatch)
    _, known, receipt = verify_phase(path, "testkey", rows, selected, 0, tmp_path)
    assert known.shape == (2, 9) and receipt["months"] == receipt["cases"] == 2
    rows[-1]["level"] = -999  # Future label is absent from every earlier fit support check.
    _, changed, _ = verify_phase(path, "testkey", rows, selected, 0, tmp_path)
    np.testing.assert_equal(known, changed)


@pytest.mark.parametrize("corruption", ["maskKey", "classes"])
def test_independent_audit_rejects_wrong_fit_mask_or_unsupported_training_class(tmp_path, monkeypatch, corruption):
    path, rows, selected = example(tmp_path, monkeypatch)
    month = next(tmp_path.glob("toy_month_start*.npz"))
    with np.load(month) as f:
        contents = {k: f[k] for k in f.files}
    contents[corruption] = np.array("wrong") if corruption == "maskKey" else np.array([35.0, 70])
    np.savez_compressed(month, **contents)
    with pytest.raises(ValueError, match="identity|class support"):
        verify_phase(path, "testkey", rows, selected, 0, tmp_path)


def test_forecast_reconstruction_ignores_unavailable_past_error_labels():
    p = np.ones((2, 1))
    parts = np.array([35.0]), p, {q: np.full_like(p, 5) for q in rolling.QUANTILES}
    padded, known = rolling.aligned(parts)
    previous_rows = [
        {"date": "2023-12-01T20:00:00Z", "pos": "DEF", "level": 35.0, "aa": 10.0},
        {"date": "2024-01-10T14:00:00Z", "pos": "DEF", "level": 35.0, "aa": 999.0},
    ]
    args = (padded, known, padded, known, padded, known, padded, known)
    forecast, audit = rebuild_raw(*args, previous_rows, "2024-01-12T20:00:00Z", np.array(["DEF", "FWD"]), "both")
    previous_rows[-1].update(aa=np.nan, level=90.0)
    changed, changed_audit = rebuild_raw(*args, previous_rows, "2024-01-12T20:00:00Z", np.array(["DEF", "FWD"]), "both")
    np.testing.assert_equal(forecast, changed)
    assert audit == changed_audit and audit["cases"] == 1
    assert len(forecast) == 2 and np.isfinite(forecast).all()
