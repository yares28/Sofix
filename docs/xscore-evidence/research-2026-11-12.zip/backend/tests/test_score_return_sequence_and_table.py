import numpy as np

from app.research.score_return_sequence import sequence, status
from app.research.score_table_pressure import table_features, update


def test_unused_requires_a_named_bench_and_same_club():
    person = {"team": "home", "played": False, "started": False, "mins": 0}
    assert status(person, set(), "player", "home") == "unknown"
    assert status(person, {"player"}, "player", "away") == "unknown"
    assert status(person, {"player"}, "player", "home") == "unused"


def test_sequence_tracks_gaps_and_separates_unknown_from_named_unused():
    observed = sequence(["start", "unknown", "unused", "bench"])
    assert observed[:7] == (4, 2, 0, 2, 1, 1, 2)
    assert observed[7:10] == (1, 1, 1)
    assert observed[-3:] == (1, 1, 0)
    assert sequence([])[-1] == 0


def test_points_table_keeps_tied_clubs_equal_and_zero_history_explicit():
    table = {str(i): np.zeros(4) for i in range(20)}
    before, no_pressure = table_features(table, "2")
    np.testing.assert_array_equal(before, [0, 0, 0, 1])
    np.testing.assert_array_equal(no_pressure, np.zeros(8))
    update(table, "0", "1", 3, 1)
    update(table, "2", "3", 1, 0)
    assert table_features(table, "0")[0][-1] == table_features(table, "2")[0][-1] == 1
    assert table_features(table, "1")[0][-1] == 3
