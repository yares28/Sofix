"""Testing only: independent monthly mask/class reconstruction and full-case checks."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_rolling as calendar
from app.research import score_rolling_strong as rolling
from app.research import score_rolling_strong_run as runner
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional
from app.research.score_search import cutoff_for, measure, moment


def verify_phase(path, key, rows, selected, window, cache):
    with np.load(path) as f:
        if str(f["key"]) != key or not np.array_equal(f["classes"], rolling.CLASSES):
            raise ValueError("Monthly independent phase identity differs")
        observed_p, observed_known = f["probability"], f["known"]
        observed_q = {q: f[f"q{q}"] for q in rolling.QUANTILES}
        receipts = json.loads(str(f["receipt"]))
    cutoffs = [cutoff_for(r["date"]) for r in rows]
    available = [moment(r["date"]) + timedelta(hours=48) for r in rows]
    expected_months = sorted({c.strftime("%Y-%m") for c, yes in zip(cutoffs, selected, strict=True) if yes})
    if len(receipts) != len(expected_months):
        raise ValueError("Monthly independent group coverage differs")
    probability = np.zeros((len(rows), len(rolling.CLASSES)))
    known = np.zeros_like(probability, dtype=bool)
    quantiles = {q: np.zeros_like(probability) for q in rolling.QUANTILES}
    coverage = np.zeros(len(rows), dtype=int)
    for month, receipt in zip(expected_months, receipts, strict=True):
        check = np.array([yes and c.strftime("%Y-%m") == month for c, yes in zip(cutoffs, selected, strict=True)])
        anchor = min(c for c, yes in zip(cutoffs, check, strict=True) if yes)
        fit = np.array([v < anchor and (not window or v >= anchor - timedelta(days=window)) for v in available])
        identity = hashlib.sha256(np.packbits(fit).tobytes() + np.packbits(check).tobytes()).hexdigest()
        expected = {
            "anchor": anchor.isoformat(),
            "fit": int(fit.sum()),
            "target": int(check.sum()),
            "maskKey": identity,
        }
        if any(receipt[k] != value for k, value in expected.items()):
            raise ValueError("Monthly fit/target chronological receipt differs")
        with np.load(cache / receipt["cache"]) as f:
            if str(f["key"]) != key or str(f["maskKey"]) != identity:
                raise ValueError("Monthly cache chronological identity differs")
            classes = f["classes"]
            fitted_classes = np.unique(np.array([r["level"] for r in rows])[fit])
            if not np.array_equal(classes, fitted_classes) or receipt["classes"] != classes.tolist():
                raise ValueError("Monthly trained class support differs from available labels")
            columns = np.searchsorted(rolling.CLASSES, classes)
            at = np.flatnonzero(check)
            probability[np.ix_(at, columns)] = f["probability"]
            known[np.ix_(at, columns)] = True
            for q in rolling.QUANTILES:
                quantiles[q][np.ix_(at, columns)] = f[f"q{q}"]
        coverage[check] += 1
    if not np.all(coverage[selected] == 1) or coverage[~selected].any():
        raise ValueError("Monthly cases omitted or duplicated")
    if (
        not np.array_equal(probability[selected], observed_p)
        or not np.array_equal(known[selected], observed_known)
        or any(not np.array_equal(value[selected], observed_q[q]) for q, value in quantiles.items())
    ):
        raise ValueError("Monthly class-aligned phase bundle differs from raw fitted pieces")
    if (
        not np.isfinite(observed_p).all()
        or not np.allclose(observed_p.sum(axis=1), 1)
        or (observed_p[~observed_known] != 0).any()
        or any(not np.isfinite(value).all() for value in observed_q.values())
    ):
        raise ValueError("Monthly forecast coverage/support invalid")
    return (
        (rolling.CLASSES.copy(), observed_p, observed_q),
        observed_known,
        {
            "cases": int(selected.sum()),
            "months": len(receipts),
            "fitMasksReconstructed": True,
            "nativeClassSupportsReconstructed": True,
            "unsupportedForecastMass": 0,
        },
    )


def rebuild_raw(
    old,
    old_known,
    new,
    new_known,
    past_old,
    past_old_known,
    past_new,
    past_new_known,
    past_rows,
    first,
    positions,
    policy,
):
    current, _ = rolling.combine(old, old_known, new, new_known, policy)
    past, known = rolling.combine(past_old, past_old_known, past_new, past_new_known, policy)
    bank, audit = rolling.bank_from(past, known, past_rows, first)
    return empirical.empirical_predictions(*current, positions, bank, 20, 0.75, 0), audit


def reconstruct_forecasts(
    args, key, source, cohort, rows, masks, bundles, frozen, old_match, old_stability, old_ordinary
):
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_bench = read("laliga_score_analogues")
    old_start = read("laliga_score_match_empirical_density")
    call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
    old = {
        phase: rolling.aligned(flow.old_components(call_args, cohort, phase, old_match, old_stability, old_ordinary))
        for phase, _, _ in stability.PHASES
    }
    y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
    comparisons, mutated = 0, 0
    for phase_index, (phase, _, _) in enumerate(stability.PHASES[1:], start=1):
        mask = masks[phase]
        target = mask["target"]
        past_phase = stability.PHASES[phase_index - 1][0]
        past_rows = [r for r, yes in zip(rows, masks[past_phase]["target"], strict=True) if yes]
        control = controls.control_for(
            call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
        )
        expected_control = (
            old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
            if phase != "later2026"
            else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
        )
        if measure(y[target], control) != expected_control:
            raise ValueError("Monthly reconstructed strongest control differs")
        active = [frozen["best"]] if phase == "later2026" else frozen["candidates"]
        groups = {(r["spec"]["window"], r["spec"]["policy"]) for r in active}
        for window, policy in sorted(groups):
            raw, bank_audit = rebuild_raw(
                *old[phase],
                *bundles[(phase, window)],
                *old[past_phase],
                *bundles[(past_phase, window)],
                past_rows,
                mask["first"],
                positions[target],
                policy,
            )
            if phase == "later2026":
                changed_rows = copy.deepcopy(past_rows)
                unavailable = ~stability.previous_bank_mask(past_rows, mask["first"])
                for i in np.flatnonzero(unavailable):
                    changed_rows[i].update(aa=np.nan, level=90.0)
                repeated, changed_bank_audit = rebuild_raw(
                    *old[phase],
                    *bundles[(phase, window)],
                    *old[past_phase],
                    *bundles[(past_phase, window)],
                    changed_rows,
                    mask["first"],
                    positions[target],
                    policy,
                )
                if not np.array_equal(raw, repeated) or bank_audit != changed_bank_audit:
                    raise ValueError("Unavailable monthly calibration labels changed predictions")
                mutated = int(unavailable.sum())
            for record in [r for r in active if r["spec"]["window"] == window and r["spec"]["policy"] == policy]:
                candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                if phase == "later2026":
                    with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
                        if not np.array_equal(candidate, f["alternate"]):
                            raise ValueError("Monthly final forecast does not reconstruct from fitted components")
                elif measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                    raise ValueError("Monthly earlier candidate forecast does not reconstruct")
                comparisons += 1
    return {
        "candidateForecastsReconstructed": comparisons,
        "unavailablePastCalibrationLabelsMutated": mutated,
        "reconstructionIncludesAllFinalCases": True,
    }


def refit_first_final(args, key, cohort, rows, window):
    selected = stability.phase_masks(rows)["later2026"]["target"]
    fit, check, anchor = calendar.month_folds(rows, selected, window)[0]
    keep = np.array([r["cohort"] == cohort for r in json.loads(args.cases.read_text())["rows"]])
    with np.load(args.cache / "stats.npz") as f:
        base = f["x"][keep]
    with np.load(args.cache / "match_context_features.npz") as f:
        x = np.column_stack((base, f["x"][keep]))
    aa, levels = np.array([r["aa"] for r in rows]), np.array([r["level"] for r in rows], dtype=float)
    # Replace all unavailable outcome labels before a real refit, not just before prediction.
    aa[~fit], levels[~fit] = np.nan, np.nan
    changed = conditional.conditional_components(x, aa, levels, fit, check)
    identity = hashlib.sha256(np.packbits(fit).tobytes() + np.packbits(check).tobytes()).hexdigest()
    path = args.cache / f"{args.report.stem}_month_{cohort}_{anchor[:10]}_{identity[:12]}_{key[:12]}.npz"
    with np.load(path) as f:
        if (
            str(f["key"]) != key
            or not np.array_equal(changed[0], f["classes"])
            or not np.allclose(changed[1], f["probability"], rtol=0, atol=1e-12)
            or any(not np.allclose(changed[2][q], f[f"q{q}"], rtol=0, atol=1e-10) for q in rolling.QUANTILES)
        ):
            raise ValueError("Monthly real refit changed after unavailable outcome mutation")
    return {
        "anchor": anchor,
        "fit": int(fit.sum()),
        "forecastCases": int(check.sum()),
        "outcomeRowsReplacedOutsideFit": int((~fit).sum()),
        "all4ActualFittedModelsReproduced": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-first-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary = map(
        read, ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary")
    )
    with np.load(args.cache / "stats.npz") as f:
        stat_key = str(f["key"])
    modules = (rolling, calendar, conditional, empirical, flow, controls, ordinary, stability)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    evidence, full_results = {}, {}
    full = json.loads(args.report.read_text()) if args.report.exists() else None
    if full and full["implementationKey"] != key:
        raise ValueError("Monthly result source fingerprint differs")
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        masks = stability.phase_masks(rows)
        evidence[cohort] = {}
        bundles = {}
        for phase, _, _ in stability.PHASES:
            for window in (0, 365):
                path = args.cache / f"{args.report.stem}_components_{cohort}_{phase}_w{window}_{key[:12]}.npz"
                if path.exists():
                    parts, known, audit = verify_phase(path, key, rows, masks[phase]["target"], window, args.cache)
                    bundles[(phase, window)] = parts, known
                    evidence[cohort][phase + "/" + str(window)] = audit
        if full and cohort in full["cohorts"]:
            result = full["cohorts"][cohort]
            frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
            frozen = json.loads(frozen_path.read_text())
            winner, best = stability.choose_stable(frozen["candidates"])
            if (
                frozen["implementationKey"] != key
                or winner != frozen["winner"]
                or best != frozen["best"]
                or (winner is not None) != (result["selected"] == "candidate")
            ):
                raise ValueError("Monthly earlier selection gate differs")
            target = masks["later2026"]["target"]
            y = np.array([r["score"] for r in rows])[target]
            with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
                if (
                    str(f["key"]) != key
                    or not np.array_equal(f["y"], y)
                    or len(y) != {"start": 6754, "bench": 2925}[cohort]
                ):
                    raise ValueError("Monthly final full-case identity differs")
                for name, metric in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                    if measure(y, f[name]) != result[metric]:
                        raise ValueError("Monthly final native metrics differ")
                h1, h0 = np.abs(y - f["alternate"]) <= 7, np.abs(y - f["control"]) <= 7
                full_results[cohort] = {
                    "n": len(y),
                    "candidateCorrect": int(h1.sum()),
                    "controlCorrect": int(h0.sum()),
                    "gained": int((h1 & ~h0).sum()),
                    "lost": int((h0 & ~h1).sum()),
                    "earlierGateVerified": True,
                }
            full_results[cohort].update(
                reconstruct_forecasts(
                    args, key, source, cohort, rows, masks, bundles, frozen, old_match, old_stability, old_ordinary
                )
            )
            if args.refit_first_final:
                full_results[cohort]["realRefitAfterUnavailableLabelMutation"] = refit_first_final(
                    args, key, cohort, rows, frozen["best"]["spec"]["window"]
                )
    output = {
        "scope": "Research-only independent chronological mask/class/cache audit; partial runs are not accuracy results",
        "implementationKey": key,
        "cohorts": evidence,
        "completedNativeResults": full_results,
    }
    destination = args.report.with_suffix(".integrity.json" if full_results else ".partial-integrity.json")
    destination.write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
