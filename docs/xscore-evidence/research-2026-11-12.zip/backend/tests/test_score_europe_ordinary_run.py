import numpy as np

from app.research.score_europe_ordinary import NAMES
from app.research.score_europe_ordinary_run import feature_groups


def test_ordinary_ablation_keeps_censor_coverage_and_excludes_decisive_and_score_fields():
    groups = feature_groups(NAMES)
    assert set(groups) == {"ordinary", "all"}
    assert int(groups["ordinary"].sum()) == 36 and int(groups["all"].sum()) == 60
    selected = np.array(NAMES)[groups["ordinary"]].tolist()
    assert not any("_score_" in n or n.endswith(("positive_rate", "negative_rate")) for n in selected)
    for group in ("same_position", "same_cohort"):
        for n in (5, 15):
            for field in (
                "aa_exact_games",
                "aa90_mean",
                "aa90_median",
                "aa_upper_rate",
                "aa_lower_rate",
                "aa_unbounded_rate",
                "retained_games",
                "last_days",
                "minutes_mean",
            ):
                assert f"euro_{group}_{n}_{field}" in selected
