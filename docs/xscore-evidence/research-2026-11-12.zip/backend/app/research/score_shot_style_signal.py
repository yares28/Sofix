"""Earlier-only shot-style event-signal diagnosis; never score accuracy."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

PHASES = (
    ("spring2024", "2024-01-01", "2024-07-01"),
    ("season2024", "2024-07-01", "2025-07-01"),
    ("autumn2025", "2025-07-01", "2026-01-01"),
)
BASE_FIELDS = (
    "player_native_games",
    "player_known_games",
    "player_known_minutes",
    "player_nonpen_shots90",
    "player_native_goalassist_fraction",
    "player_native_goals90",
    "player_native_assists90",
    "player_source_fraction",
    "player_age_days",
    "opponent_native_games",
    "opponent_known_games",
    "opponent_nonpen_allowed_pergame",
    "opponent_source_fraction",
    "opponent_age_days",
)
STYLE = ("body_lift", "zone_lift", "combined_lift")


def fitted(x, y, fit, target, missing_width=None):
    from sklearn.linear_model import LogisticRegression

    if missing_width is None:
        missing_width = x.shape[1]
    if not np.isfinite(y[fit]).all() or set(np.unique(y[fit])) != {0.0, 1.0}:
        raise ValueError("Two finite native training classes required")
    median = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0.0 for c in x[fit].T])
    complete = np.where(np.isfinite(x), x, median)
    mean, scale = complete[fit].mean(axis=0), complete[fit].std(axis=0)
    scale = np.where(scale > 1e-8, scale, 1.0)
    z = np.column_stack(((complete - mean) / scale, ~np.isfinite(x[:, :missing_width])))
    model = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000, tol=1e-8, random_state=20261105).fit(
        z[fit], y[fit]
    )
    if int(model.n_iter_.max()) >= 1000:
        raise ValueError("Fixed signal regression did not converge")
    return dict(
        probability=model.predict_proba(z[target])[:, 1],
        coefficient=model.coef_[0],
        intercept=model.intercept_[0],
        median=median,
        mean=mean,
        scale=scale,
        missing_width=missing_width,
        iterations=model.n_iter_,
    )


def losses(actual, probability):
    if len(actual) != len(probability) or not np.isfinite(actual).all() or not np.isfinite(probability).all():
        raise ValueError("Full matching probability/label vectors required")
    p = np.clip(probability, 1e-12, 1 - 1e-12)
    return dict(
        n=len(actual),
        positives=int(actual.sum()),
        logloss=float(-np.mean(actual * np.log(p) + (1 - actual) * np.log1p(-p))),
        brier=float(np.mean((actual - probability) ** 2)),
    )


def interval(actual, baseline, proposed, weeks):
    names = sorted(set(weeks))
    error = (actual - baseline) ** 2 - (actual - proposed) ** 2
    total = np.array([error[np.array(weeks) == week].sum() for week in names])
    count = np.array([sum(w == week for w in weeks) for week in names])
    selected = np.random.default_rng(20261105).integers(len(names), size=(2000, len(names)))
    draws = total[selected].sum(axis=1) / count[selected].sum(axis=1)
    return np.quantile(draws, [0.025, 0.975]).tolist()


def load_inputs(args):
    source = json.loads((args.cache / "cases.json").read_text())
    feature_report = json.loads((args.out.parent / "laliga_score_shot_style_features.json").read_text())
    audit_path = args.out.parent / "laliga_score_shot_style_features.integrity.json"
    audit = json.loads(audit_path.read_text())
    if (
        audit["featureKey"] != feature_report["featureKey"]
        or audit["nativeCasesVerified"] != 38850
        or audit["nativeRawPlayerProfilesVerified"] != 34871
        or audit["independentlyRecomputedColumns"] != 46
        or not audit["actualFutureMutation"]["all46columnsExact"]
    ):
        raise ValueError("Complete source/profile/46feature audit required")
    with np.load(args.cache / "shot_style_features.npz") as f:
        if (
            str(f["key"]) != "60adcfd265019fb6457dcaabb8cb26c8f2f2f820484207ac0bf4923c770efc9e"
            or str(f["source_key"]) != source["key"]
        ):
            raise ValueError("Registered shot-style feature identity differs")
        x, names = f["x"], f["names"].tolist()
    with np.load(args.cache / "pass_source_qualified_features.npz") as f:
        if str(f["key"]) != "ea7140d00451d52b9e74069bdbeea424d5176a46c31758588f56d1e6ae0cec13":
            raise ValueError("Verified quality source changed")
        quality, qnames = f["x"], f["names"].tolist()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    target = dict(goal=[], goalassist=[])
    for r in source["rows"]:
        p, g = games[r["game"]]["players"][r["player"]], games[r["game"]]
        if (
            p["ver"] != 7
            or not p["played"]
            or p["started"] != (r["cohort"] == "start")
            or g["date"] != r["date"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Native signal identity/outcome differs")
        goal, assist = (p["stats"].get(stat, [0, 0])[0] > 0 for stat in ("goals", "goal_assist"))
        target["goal"].append(goal)
        target["goalassist"].append(goal or assist)
    columns = [x[:, names.index("shotstyle_" + n)].copy() for n in BASE_FIELDS]
    for i, n in enumerate(BASE_FIELDS):
        if any(k in n for k in ("minutes", "shots90", "goals90", "assists90", "age_days", "allowed_pergame")):
            columns[i] = np.log1p(columns[i])
    columns += [
        np.log1p(quality[:, qnames.index("same_10_chance_npxg90_mean")]),
        quality[:, qnames.index("same_10_chance_npxg90_count")],
    ]
    original = np.array([r["x"] for r in source["rows"]], dtype=float)
    original_names = source["features"]
    columns += [
        original[:, original_names.index(n)]
        for n in ("home", "position_GK", "position_DEF", "position_MID", "position_FWD")
    ]
    own = np.where(
        original[:, original_names.index("home")] > 0,
        original[:, original_names.index("match_lam_h")],
        original[:, original_names.index("match_lam_a")],
    )
    columns.append(np.log1p(own))
    styles = np.column_stack([x[:, names.index("shotstyle_match_" + n)] for n in STYLE])
    available = np.isfinite(styles) & (styles > 0)
    columns.extend(available.T.astype(float))
    baseline = np.column_stack(columns)
    extra = np.full_like(styles, np.nan)
    np.log(styles, out=extra, where=available)
    if baseline.shape != (38850, 25):
        raise ValueError("Frozen25covariate baseline differs")
    inputs = dict(baseline=baseline, matched_style=np.column_stack((baseline, extra)))
    return (
        source,
        inputs,
        {k: np.array(v, dtype=float) for k, v in target.items()},
        dict(
            featureKey=feature_report["featureKey"],
            featureAuditSha256=hashlib.sha256(audit_path.read_bytes()).hexdigest(),
            nativeSha256=hashlib.sha256(raw).hexdigest(),
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_shot_style_signal.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, all_inputs, all_y, provenance = load_inputs(args)
    key = hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + sklearn.__version__).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    report = dict(
        scope="Earlier-only event signal diagnosis; NOT score-within7 accuracy",
        implementationKey=key,
        sourceKey=source["key"],
        provenance=provenance,
        cohorts={},
        later2026="Not fitted or evaluated; no2026selection",
        evidenceLimit="Retrospective reuse, not fresh blind proof",
    )
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        inputs = {k: v[keep] for k, v in all_inputs.items()}
        result, pooled = dict(periods={}), {o: dict(actual=[], baseline=[], proposed=[], weeks=[]) for o in all_y}
        gains = {o: [] for o in all_y}
        for phase, begin, end in PHASES:
            target_mask = np.array([begin <= r["date"] < end for r in rows])
            first = min(r["date"] for r, yes in zip(rows, target_mask, strict=True) if yes)
            lock = cutoff_for(first)
            fit = np.array([r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
            result["periods"][phase] = dict(
                fit=int(fit.sum()), target=int(target_mask.sum()), firstLock=lock.isoformat(), outcomes={}
            )
            for outcome, all_actual in all_y.items():
                actual = all_actual[keep]
                models, metrics = {}, {}
                for group, x in inputs.items():
                    model = fitted(x, actual, fit, target_mask, missing_width=25)
                    probability = model["probability"]
                    models[group] = probability
                    metrics[group] = losses(actual[target_mask], probability)
                    path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{outcome}_{group}.npz"
                    np.savez_compressed(path, key=key, fit=fit, target=target_mask, actual=actual[target_mask], **model)
                log_gain = metrics["baseline"]["logloss"] - metrics["matched_style"]["logloss"]
                brier_gain = metrics["baseline"]["brier"] - metrics["matched_style"]["brier"]
                gains[outcome].append(dict(logloss=log_gain, brier=brier_gain))
                result["periods"][phase]["outcomes"][outcome] = dict(
                    metrics=metrics, loglossImprovement=log_gain, brierImprovement=brier_gain
                )
                p = pooled[outcome]
                p["actual"].extend(actual[target_mask])
                p["baseline"].extend(models["baseline"])
                p["proposed"].extend(models["matched_style"])
                p["weeks"].extend(r["week"] for r, yes in zip(rows, target_mask, strict=True) if yes)
                print(
                    "SHOT_STYLE_SIGNAL_PERIOD "
                    + json.dumps(
                        dict(
                            cohort=cohort,
                            phase=phase,
                            outcome=outcome,
                            loglossImprovement=log_gain,
                            brierImprovement=brier_gain,
                        )
                    ),
                    flush=True,
                )
        result["pooled"] = {}
        for outcome, values in pooled.items():
            y, old, new = (np.array(values[k]) for k in ("actual", "baseline", "proposed"))
            bounds = interval(y, old, new, values["weeks"])
            passing = all(g["logloss"] > 0 and g["brier"] > 0 for g in gains[outcome]) and bounds[0] > 0
            result["pooled"][outcome] = dict(
                baseline=losses(y, old),
                matchedStyle=losses(y, new),
                brierImprovement95=bounds,
                allThreeEarlierPeriodsImprove=all(g["logloss"] > 0 and g["brier"] > 0 for g in gains[outcome]),
                passesSignalGate=passing,
            )
        result["passesPrimaryGoalGate"] = result["pooled"]["goal"]["passesSignalGate"]
        result["disposition"] = (
            "Eligible for separately registered score-formula experiment, NOT proven score improvement"
            if result["passesPrimaryGoalGate"]
            else "REJECT/RETIRE shot-style score-formula grid; primary goal signal failed earlier gate"
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "SHOT_STYLE_SIGNAL_RESULT "
            + json.dumps(
                dict(
                    cohort=cohort, primaryGoalPassed=result["passesPrimaryGoalGate"], disposition=result["disposition"]
                )
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
