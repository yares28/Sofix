"""Test a shared pre-lock match scenario in the ordinary-score distribution."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research.score_component_replacement import EVENT_KEY
from app.research.score_failure_review import activity_groups
from app.research.score_openplay_aerial_routine import ordinary_quantiles
from app.research.score_openplay_duel_signal import native_archive
from app.research.score_search import POSITIONS
from app.research.score_shared_error_recovery import compare, snapshots
from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)


def team_probabilities(source, flow_features, observed, phase):
    from sklearn.ensemble import HistGradientBoostingClassifier

    rows = source["rows"]
    index = [
        source["features"].index(n)
        for n in (
            "home",
            "match_lam_h",
            "match_lam_a",
            "match_cs_h",
            "match_cs_a",
        )
    ]
    native_match = np.array([[r["x"][j] for j in index] for r in rows])
    home = native_match[:, 0] > 0
    match_row = {}
    for i in np.flatnonzero(home):
        match_row.setdefault(rows[i]["game"], i)
    if set(match_row) != {r["game"] for r in rows}:
        raise ValueError("No home-side representative for a native fixture")
    group = np.array(list(match_row.values()))
    current_rows = [rows[i] for i in group]
    mask = stability.phase_masks(current_rows)[phase]
    target, fit = mask["target"], mask["fit"] & (observed[group] >= 0)
    x = np.column_stack((native_match[group, 1:], flow_features[group]))
    y = observed[group]
    model = HistGradientBoostingClassifier(
        max_iter=80, max_leaf_nodes=7, min_samples_leaf=30, l2_regularization=8, early_stopping=False
    ).fit(x[fit], y[fit])
    if not np.array_equal(model.classes_, [0, 1, 2]):
        raise ValueError("Historical fit lacks a pressure mode")
    predicted = model.predict_proba(x[target])
    by_game = {
        r["game"]: prob for r, prob in zip([current_rows[i] for i in np.flatnonzero(target)], predicted, strict=True)
    }
    probabilities = {
        i: by_game[r["game"]] if home[i] else by_game[r["game"]][::-1]
        for i, r in enumerate(rows)
        if r["game"] in by_game
    }
    scored = y[target] >= 0
    prior = np.bincount(y[fit], minlength=3) / fit.sum()
    audit = {"fitFixtures": int(fit.sum()), "forecastFixtures": len(predicted), "knownModeFixtures": int(scored.sum())}
    if scored.any():
        labels = y[target][scored]
        audit |= {
            "topModeAccuracy": float((predicted[scored].argmax(axis=1) == labels).mean()),
            "mostCommonModeAccuracy": float((prior.argmax() == labels).mean()),
            "modeLogLossPriorAndForecast": [
                float(-np.log(prior[labels]).mean()),
                float(-np.log(predicted[scored, labels]).mean()),
            ],
        }
    return probabilities, audit


def scenario_quantiles(x, points, levels, observed, classes, fit, target):
    from sklearn.ensemble import HistGradientBoostingRegressor

    train = np.column_stack((x[fit], observed[fit], levels[fit]))
    target_x = x[target]
    grid = np.column_stack(
        (
            np.tile(target_x, (len(classes), 1)),
            np.zeros(len(classes) * len(target_x)),
            np.repeat(classes, len(target_x)),
        )
    )
    result = [{} for _ in range(3)]
    for q in (0.35, 0.5, 0.65):
        model = HistGradientBoostingRegressor(
            loss="quantile",
            quantile=q,
            max_leaf_nodes=15,
            min_samples_leaf=60,
            max_iter=80,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261112,
        ).fit(train, points[fit])
        for mode in range(3):
            grid[:, -2] = mode
            result[mode][q] = model.predict(grid).reshape(len(classes), len(target_x)).T
    return result


def score_mass(classes, probabilities, parts, pos, bank):
    median, scale = empirical.location_scale(parts, "raw")
    scale *= 0.75
    total = np.zeros((len(probabilities), len(CENTRES)))
    for position in set(pos):
        keep = np.flatnonzero(pos == position)
        pool = bank["positions"].get(position, bank["global"])
        for j, level in enumerate(classes):
            floor = level if level >= 60 else 0
            low, high = CENTRES[None, :] - 7, CENTRES[None, :] + 7
            lo = (low - level - median[keep, j, None]) / scale[keep, j, None]
            hi = (high - level - median[keep, j, None]) / scale[keep, j, None]
            clipping = low <= floor, high >= 100, high < floor
            mass = empirical.window_mass(pool, lo, hi, *clipping)
            local = bank["levels"].get((position, float(level)))
            if local is not None and len(local):
                mass = (20 * mass + len(local) * empirical.window_mass(local, lo, hi, *clipping)) / (20 + len(local))
            total[keep] += probabilities[keep, j, None] * mass
    return total


def banks_from(previous, previous_classes, points, levels, pos, actual_mode, valid):
    usable = valid & (actual_mode >= 0)
    control, scenario = previous
    baseline = empirical.fit_bank(previous_classes, control, points, levels, pos, usable, "raw")
    selected = {q: np.choose(np.maximum(actual_mode, 0)[:, None], [p[q] for p in scenario]) for q in control}
    fallback = empirical.fit_bank(previous_classes, selected, points, levels, pos, usable, "raw")
    banks = [
        empirical.fit_bank(previous_classes, selected, points, levels, pos, usable & (actual_mode == m), "raw")
        if (usable & (actual_mode == m) & np.isin(levels, previous_classes)).sum() >= 40
        else fallback
        for m in range(3)
    ]
    return baseline, banks


def observed_association(rows, games, modes):
    buckets = {}
    for mode, label in ((0, "underPressure"), (2, "applyingPressure")):
        selected = [
            activity_groups(games[r["game"]]["players"][r["player"]]["stats"])
            for r, state in zip(rows, modes, strict=True)
            if state == mode and r["pos"] == "DEF" and r["level"] == 35 and "2024-01-01" <= r["date"] < "2026-01-01"
        ]
        buckets[label] = {
            "n": len(selected),
            "mean": {k: float(np.mean([s[k] for s in selected])) for k in selected[0]},
        }
    return buckets


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    read = lambda key: json.loads((args.out.parent / f"{key}.json").read_text())
    source = json.loads((args.cache / "cases.json").read_text())
    audit = read("laliga_score_openplay_shared_flow_features")
    feature_path = args.cache / "openplay-data-v0.1.0" / "shared_flow_features.npz"
    if hashlib.sha256(feature_path.read_bytes()).hexdigest() != audit["featureSha256"]:
        raise ValueError("Feature audit fingerprint differs")
    with np.load(feature_path) as f:
        if str(f["sourceKey"]) != source["key"] or audit["firstLockUnchangedAfterUnavailableFactsRemoved"] != 310:
            raise ValueError("Lag audit incomplete")
        flow_features, observed = f["flow"], f["modes"]
    with np.load(args.cache / "event_intensity_features.npz") as f:
        if str(f["key"]) != EVENT_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Pre-lock minutes differ")
        minutes = f["x"][:, f["names"].tolist().index("event_expected_minutes")]
    old = tuple(read(f"laliga_score_{key}") for key in ("match_context", "stability", "ordinary"))
    if any(r["sourceKey"] != source["key"] for r in old):
        raise ValueError("Original decisive probabilities use other cases")
    report = {
        "scope": "Test only, reused historical outcomes",
        "sourceKey": source["key"],
        "cohorts": {},
        "matchMode": {},
    }
    team = {}
    for phase, _, _ in stability.PHASES[1:-1]:
        team[phase], report["matchMode"][phase] = team_probabilities(source, flow_features, observed, phase)
    games = native_archive(args.games)
    for cohort in ("start", "bench"):
        indices = np.array([i for i, r in enumerate(source["rows"]) if r["cohort"] == cohort])
        rows = [source["rows"][i] for i in indices]
        pos = np.array([r["pos"] for r in rows])
        points, levels, y = (np.array([r[k] for r in rows]) for k in ("aa", "level", "score"))
        modes = observed[indices]
        x = np.column_stack(
            ([r["x"] for r in rows], minutes[indices], flow_features[indices], *[pos == p for p in POSITIONS])
        )
        known = (flow_features[indices, -2:] >= 3).any(axis=1)
        masks = stability.phase_masks(rows)
        frozen = snapshots(args, source, rows, cohort, read)
        periods, previous = {}, None
        advance = False
        for phase, _, _ in stability.PHASES:
            if phase == "later2026":
                advance = all(
                    v["againstFrozen"]["net"] > 0 and v["againstMatched"]["net"] > 0 for v in periods.values()
                )
                args.out.with_suffix(f".{cohort}.selection.json").write_text(json.dumps({"advanced": advance}))
                if not advance:
                    break
                if phase not in team:
                    team[phase], report["matchMode"][phase] = team_probabilities(source, flow_features, observed, phase)
            mask = masks[phase]
            fit, target = mask["fit"] & (modes >= 0), mask["target"]
            if (fit & target).any() or not fit.any():
                raise ValueError("Chronological training split differs")
            classes, p_decisive, _ = flow.old_components(SimpleNamespace(cache=args.cache), cohort, phase, *old)
            safe_p, safe_l, safe_mode = (np.where(fit, v, np.nan) for v in (points, levels, modes))
            control = ordinary_quantiles(x, safe_p, safe_l, classes, fit, target)
            scenarios = scenario_quantiles(x, safe_p, safe_l, safe_mode, classes, fit, target)
            if previous is not None:
                parts, prev_classes, prev_target = previous
                past_rows = [r for r, keep in zip(rows, prev_target, strict=True) if keep]
                available = stability.previous_bank_mask(past_rows, mask["first"])
                base_bank, mode_banks = banks_from(
                    parts,
                    prev_classes,
                    points[prev_target],
                    levels[prev_target],
                    pos[prev_target],
                    modes[prev_target],
                    available,
                )
                mix = np.array([team[phase][i] for i in indices[target]])
                np.testing.assert_allclose(mix.sum(axis=1), 1)
                pos_target = pos[target]
                matched = empirical.empirical_predictions(
                    classes, p_decisive, control, pos_target, base_bank, 20, 0.75, 0
                )
                masses = [
                    score_mass(classes, p_decisive, p, pos_target, b)
                    for p, b in zip(scenarios, mode_banks, strict=True)
                ]
                decoded = window_centres(sum(mix[:, j, None] * a for j, a in enumerate(masses)), CENTRES)
                reference = frozen[phase][1]
                matched, decoded = (np.where(known[target], candidate, reference) for candidate in (matched, decoded))
                all_cases = np.ones(int(target.sum()), dtype=bool)
                periods[phase] = {
                    "fitRows": int(fit.sum()),
                    "usedSourceHistory": int(known[target].sum()),
                    "matchedAgainstFrozen": compare(y[target], reference, matched, all_cases),
                    "againstFrozen": compare(y[target], reference, decoded, all_cases),
                    "againstMatched": compare(y[target], matched, decoded, all_cases),
                }
                print(
                    cohort,
                    phase,
                    "vs frozen",
                    periods[phase]["againstFrozen"]["net"],
                    "vs matched",
                    periods[phase]["againstMatched"]["net"],
                    flush=True,
                )
            previous = (control, scenarios), classes, target
        report["cohorts"][cohort] = {"advanced": advance, "periods": periods}
        if cohort == "start":
            report["hindsightNeutralStartingDefenders"] = observed_association(rows, games, modes)
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_shared_flow.json"))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
