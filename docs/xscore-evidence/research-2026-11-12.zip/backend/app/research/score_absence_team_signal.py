"""Team goal forecasts with a fixed, pre-lock roster absence intervention."""

import hashlib
import json
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_search import cutoff_for, moment

STEM = "laliga_score_absence_team_signal"
DELAY = timedelta(hours=48)
ROLES = ("GK", "DEF", "MID", "FWD")


def redistribute(roster, removed):
    result = {name: value for name, value in roster.items() if name not in removed}
    anonymous = {}
    for role in ROLES:
        residual = sum(mins for p, (pos, mins) in roster.items() if p in removed and pos == role)
        while residual > 1e-9:
            active = {p: roster[p][1] for p, (pos, m) in result.items() if pos == role and m < 90 - 1e-9}
            weight = sum(active.values())
            if weight <= 0:
                anonymous[role] = residual
                break
            distributed = 0.0
            for p, base in active.items():
                m = result[p][1]
                shift = min(90 - m, residual * base / weight)
                result[p] = role, m + shift
                distributed += shift
            residual -= distributed
    return result, anonymous


def matched_placebo(roster, removed, excluded):
    selected = set()
    for name in sorted(removed, key=lambda p: (-roster[p][1], p)):
        pos, mins = roster[name]
        best = min(
            (
                (abs(m - mins), p)
                for p, (role, m) in roster.items()
                if role == pos and p not in (removed | excluded | selected) and abs(m - mins) <= 15
            ),
            default=None,
        )
        if best is not None:
            selected.add(best[1])
    return selected


def sides(game):
    return game["home"]["slug"], game["away"]["slug"]


def actual_roster(game):
    clubs = sides(game)
    members = {c: {} for c in clubs}
    starters = {c: 0 for c in clubs}
    for name, p in game["players"].items():
        if p["played"] is not True:
            continue
        club, pos, minutes = p["team"], p["pos"], p["mins"]
        if (
            club not in members
            or pos not in ROLES
            or not 0 < minutes <= 90
            or p["ver"] != 7
            or type(p["started"]) is not bool
        ):
            return None
        members[club][name] = pos, float(minutes)
        starters[club] += p["started"]
    return members if all(n == 11 for n in starters.values()) else None


def anchor_rates(source):
    i, j = (source["features"].index(k) for k in ("match_lam_h", "match_lam_a"))
    rates = {}
    for r in source["rows"]:
        v = r["x"][i], r["x"][j]
        if r["game"] in rates and v != rates[r["game"]]:
            raise ValueError("Fixture forecast differs between player cases")
        rates[r["game"]] = v
    if len(rates) != 1238 or not all(0 < n < 8 for v in rates.values() for n in v):
        raise ValueError("Original goal-rate coverage differs")
    return rates


def fit_design(games, rates):
    from scipy.sparse import coo_matrix

    rosters = {g["id"]: actual_roster(g) for g in games}
    if any(v is None for v in rosters.values()):
        raise ValueError("Incomplete fit participant sheet")
    names = sorted({p for teams in rosters.values() for members in teams.values() for p in members})
    clubs = sorted({c for g in games for c in sides(g)})
    cn = {c: i for i, c in enumerate(clubs)}
    pn = {p: i for i, p in enumerate(names)}
    c, n = len(clubs), len(names)
    rr, cc, values, offset, goals = [], [], [], [], []
    for i, g in enumerate(games):
        team = sides(g)
        roster = rosters[g["id"]]
        for side in (0, 1):
            own, opp = team[side], team[1 - side]
            elements = {side: 1.0, 2 + cn[own]: 1.0, 2 + c + cn[opp]: 1.0}
            elements.update({2 + 2 * c + pn[p]: m / 90 for p, (_, m) in roster[own].items()})
            elements.update({2 + 2 * c + n + pn[p]: m / 90 for p, (_, m) in roster[opp].items()})
            for j, value in sorted(elements.items()):
                rr.append(2 * i + side)
                cc.append(j)
                values.append(value)
            offset.append(np.log(rates[g["id"]][side]))
            goals.append(g["homeGoals" if side == 0 else "awayGoals"])
    design = coo_matrix((values, (rr, cc)), shape=(2 * len(games), 2 + 2 * c + 2 * n)).tocsr()
    penalty = np.r_[np.full(2, 0.01), np.full(2 * c, 6.0), np.full(2 * n, 12.0)]
    return design, np.array(offset), np.array(goals), penalty, names, clubs


def objective(beta, design, offset, goals, penalty):
    linear = design @ beta + offset
    rates = np.exp(linear)
    loss = np.sum(rates - goals * linear) + 0.5 * np.dot(penalty, beta**2)
    grad = np.asarray(design.T @ (rates - goals)) + penalty * beta
    return float(loss), grad


def fit(games, rates):
    from scipy.optimize import minimize

    x, offset, goals, penalty, names, clubs = fit_design(games, rates)
    result = minimize(
        objective,
        np.zeros(x.shape[1]),
        args=(x, offset, goals, penalty),
        jac=True,
        method="L-BFGS-B",
        options=dict(maxiter=2000, gtol=1e-7, ftol=1e-12),
    )
    if not result.success or not np.isfinite(result.x).all():
        raise ValueError(f"Fixed fit failed: {result.message}")
    first = 2 + 2 * len(clubs)
    n = len(names)
    effects = {p: (result.x[first + i], result.x[first + n + i]) for i, p in enumerate(names)}
    return (
        effects,
        result.x,
        names,
        clubs,
        dict(iterations=int(result.nit), objective=float(result.fun), maxAbsGradient=float(np.max(np.abs(result.jac)))),
    )


def projected(history):
    if not history or any(h is None for h in history):
        return {}
    role, minutes = {}, defaultdict(float)
    for players in history:
        for p, (pos, m) in players.items():
            role[p] = pos
            minutes[p] += m / len(history)
    return {p: (role[p], m) for p, m in minutes.items()}


def roster_effects(old, new, effects):
    delta = np.zeros(2)
    for p in sorted(old.keys() | new.keys()):
        if p in effects:
            minutes = new.get(p, ("", 0.0))[1] - old.get(p, ("", 0.0))[1]
            delta += np.array(effects[p]) * minutes / 90
    return delta


def predictions(schedule, target, rates, claims, effects):
    history, latest = defaultdict(list), {}
    cursor, output = 0, []
    for g in target:
        lock = cutoff_for(g["date"])
        while cursor < len(schedule) and moment(schedule[cursor]["date"]) + DELAY < lock:
            past = schedule[cursor]
            known = actual_roster(past)
            for club in sides(past):
                members = known[club] if known is not None else None
                history[club].append(members)
                for name in members or ():
                    latest[name] = club
            cursor += 1
        actual_delta, placebo_delta, removals, placebo_removals, proof = [], [], [], [], []
        for club in sides(g):
            base = projected(history[club][-3:])
            source = claims.get((g["id"], club), {})
            removed = {p for p, (_, m) in base.items() if m >= 15 and p in source and latest.get(p) == club}
            for p in removed:
                np.testing.assert_allclose(base[p][1], source[p], rtol=0, atol=1e-12)
            excluded = set(source) | {p for p in base if latest.get(p) != club}
            placebo = matched_placebo(base, removed, excluded)
            a, unseen_a = redistribute(base, removed)
            b, unseen_b = redistribute(base, placebo)
            for role in ROLES:
                total = sum(m for pos, m in base.values() if pos == role)
                for replacement, unknown in ((a, unseen_a), (b, unseen_b)):
                    new_total = sum(m for pos, m in replacement.values() if pos == role) + unknown.get(role, 0)
                    np.testing.assert_allclose(total, new_total, rtol=0, atol=1e-8)
            actual_delta.append(roster_effects(base, a, effects))
            placebo_delta.append(roster_effects(base, b, effects))
            removals.append(sorted(removed))
            placebo_removals.append(sorted(placebo))
            proof.append(
                dict(
                    club=club,
                    baseline=base,
                    proposal=a,
                    placebo=b,
                    anonymousProposal=unseen_a,
                    anonymousPlacebo=unseen_b,
                    projectedPastGames=len(history[club][-3:]),
                )
            )
        base_rate = np.array(rates[g["id"]])
        vectors = [base_rate]
        for d in (actual_delta, placebo_delta):
            log_change = np.array([d[0][0] + d[1][1], d[1][0] + d[0][1]])
            vectors.append(np.where(log_change == 0, base_rate, np.clip(base_rate * np.exp(log_change), 0.05, 8.0)))
        matched = sum(map(len, removals)) > 0 and all(
            len(a) == len(b) for a, b in zip(removals, placebo_removals, strict=True)
        )
        output.append(
            dict(
                game=g["id"],
                lock=lock.isoformat(),
                removed=removals,
                placeboRemoved=placebo_removals,
                completelyMatchedPlacebo=matched,
                rates=np.array(vectors).tolist(),
                clubs=proof,
            )
        )
    return output


def main():
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    import scipy

    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, native.splitlines()), key=lambda g: (g["date"], g["id"]))
    source = json.loads((ROOT / "cases.json").read_text())
    rates = anchor_rates(source)
    reports = REPORTS / "laliga_score_absence_claims_pilot.json"
    raw_claims = reports.read_bytes()
    claims = {}
    for side in json.loads(raw_claims)["sourceClaims"]:
        if not "2025-07-01" <= side["date"] < "2026-01-01":
            continue
        key = side["game"], side["club"]
        assert key not in claims
        claims[key] = {
            r["player"]: r["projectedPriorMinutes"]
            for category in ("sancionados", "lesionados")
            for r in side["mentions"].get(category, [])
            if r["player"] is not None
        }
    target = [g for g in games if "2025-07-01" <= g["date"] < "2026-01-01"]
    lock = cutoff_for(target[0]["date"])
    earlier = [g for g in games if g["date"] < "2025-07-01" and moment(g["date"]) + DELAY < lock]
    assert len(earlier) == 760 and len(target) == 171
    effects, beta, names, clubs, solver = fit(earlier, rates)
    vector = predictions(games, target, rates, claims, effects)
    current = [g for g in target if cutoff_for(g["date"]) == lock]
    poisoned = [dict(g, players={}) if moment(g["date"]) + DELAY >= lock else g for g in games]
    assert predictions(games, current, rates, claims, effects) == predictions(poisoned, current, rates, claims, effects)
    plan = (REPORTS / f"{STEM}.plan.json").read_bytes()
    key = hashlib.sha256(
        Path(__file__).read_bytes()
        + plan
        + raw_claims
        + source["key"].encode()
        + scipy.__version__.encode()
        + NATIVE_SHA.encode()
    ).hexdigest()
    arrays = np.array([r["rates"] for r in vector])
    removed = sum(sum(map(len, r["removed"])) for r in vector)
    matched = sum(r["completelyMatchedPlacebo"] for r in vector)
    moved = np.abs(arrays[:, 1] - arrays[:, 0])
    report = dict(
        key=key,
        nativeSHA=NATIVE_SHA,
        sourceKey=source["key"],
        planSHA=hashlib.sha256(plan).hexdigest(),
        claimSHA=hashlib.sha256(raw_claims).hexdigest(),
        fitFixtures=[g["id"] for g in earlier],
        solver=solver,
        fixtures=len(vector),
        arms=["control", "reported_absence", "placebo"],
        affectedFixtures=sum(bool(r["removed"][0] or r["removed"][1]) for r in vector),
        removals=removed,
        completelyMatchedFixtures=matched,
        maxGoalRateShift=float(moved.max()),
        meanNonzeroGoalRateShift=float(moved[moved > 0].mean()),
        deletedFuturePlayerSheetFirstLockFixtures=len(current),
        later2026Evaluated=False,
        targetGoalLabelsEvaluated=False,
        vectors=vector,
    )
    np.savez_compressed(
        ROOT / f"{STEM}.npz", key=key, beta=beta, names=np.array(names), clubs=np.array(clubs), rates=arrays
    )
    (REPORTS / f"{STEM}.forecasts.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: report[k]
                for k in (
                    "fixtures",
                    "affectedFixtures",
                    "removals",
                    "completelyMatchedFixtures",
                    "meanNonzeroGoalRateShift",
                    "maxGoalRateShift",
                    "solver",
                )
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
