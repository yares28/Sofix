import numpy as np
import pytest

from app.research.score_team_share import MODELS, team_share_rates


def inputs():
    event_names = [
        "event_mu_history",
        "event_mu_quality",
        "event_mu_negative",
        "event_goal_history90",
        "event_assist_history90",
        "event_goal_quality90",
        "event_assist_quality90",
        "event_other_history90",
        "event_expected_minutes",
    ]
    event = np.array([[0.7, 0.8, 0.04, 0.4, 0.2, 0.5, 0.3, 0.1, 90.0]])
    match_names = [
        "own_known_games",
        "teammates_recent_games",
        "teammates_exposure",
        "teammates_known_fraction",
        "teammates_total_goals",
        "teammates_total_goal_assist",
    ]
    match = np.array([[10.0, 3.0, 900.0, 1.0, 1.6, 1.0]])
    return event, event_names, match, match_names, np.array([2.0])


def test_exact_share_arithmetic_and_finite_budget():
    args = inputs()
    rates, stats = team_share_rates(*args, "history_full")
    np.testing.assert_allclose(rates, [[2 * 0.6 / 2 + 0.1, 0.04]])
    assert stats["eligible"] == 1 and stats["fallback"] == 0
    rates, _ = team_share_rates(*args, "quality_half")
    np.testing.assert_allclose(rates[0, 0], 0.5 * 0.8 + 0.5 * (2 * 0.8 / 2.1 + 0.1))
    for model in MODELS:
        rates, _ = team_share_rates(*args, model)
        assert np.isfinite(rates).all() and (rates >= 0).all()


def test_known_zero_lambda_removes_goal_mean_unknown_lambda_falls_back():
    event, en, match, mn, lam = inputs()
    zero, stats = team_share_rates(event, en, match, mn, lam * 0, "history_full")
    assert zero[0, 0] == pytest.approx(0.1) and stats["eligible"] == 1
    unknown, stats = team_share_rates(event, en, match, mn, lam * np.nan, "history_full")
    assert unknown[0, 0] == 0.7 and stats["fallback"] == 1


@pytest.mark.parametrize(
    "field,value",
    [
        ("own_known_games", 0),
        ("teammates_recent_games", 0),
        ("teammates_exposure", 0),
        ("teammates_known_fraction", 0.9),
        ("teammates_total_goals", np.nan),
        ("teammates_total_goal_assist", -1),
    ],
)
def test_missing_or_invalid_team_inputs_preserve_every_control_rate(field, value):
    event, en, match, mn, lam = inputs()
    match[0, mn.index(field)] = value
    rates, stats = team_share_rates(event, en, match, mn, lam, "history_full")
    np.testing.assert_array_equal(rates, [[0.7, 0.04]])
    assert stats["fallback"] == 1 and stats["target"] == 1


def test_extreme_own_involvement_is_capped_and_actual_labels_are_not_inputs():
    event, en, match, mn, lam = inputs()
    event[0, en.index("event_goal_history90")] = 100
    event[0, en.index("event_assist_history90")] = 100
    base, stats = team_share_rates(event, en, match, mn, lam, "history_full")
    assert base[0, 0] == pytest.approx(2.1) and stats["shareCapped"] == 1
    augmented = np.column_stack([event, [[999, -888, 1, 90]]])
    after, _ = team_share_rates(
        augmented, en + ["actual_score", "actual_AA", "actual_goals", "actual_minutes"], match, mn, lam, "history_full"
    )
    np.testing.assert_equal(base, after)


def test_zero_denominator_and_wrong_model_or_shape():
    event, en, match, mn, lam = inputs()
    event[0, [en.index("event_goal_history90"), en.index("event_assist_history90")]] = 0
    match[0, [mn.index("teammates_total_goals"), mn.index("teammates_total_goal_assist")]] = 0
    rates, stats = team_share_rates(event, en, match, mn, lam, "history_full")
    assert rates[0, 0] == 0.7 and stats["fallback"] == 1
    with pytest.raises(ValueError, match="model"):
        team_share_rates(event, en, match, mn, lam, "no")
    with pytest.raises(ValueError, match="shape"):
        team_share_rates(event, en, match, mn, np.array([]), "history_full")
