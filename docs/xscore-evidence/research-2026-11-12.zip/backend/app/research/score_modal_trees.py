"""Testing only: score trees that optimize native within-seven hits directly."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)


def score_intervals(scores):
    if scores.ndim != 1 or not np.isfinite(scores).all() or ((scores < 0) | (scores > 100)).any():
        raise ValueError("Known native score targets within0..100 required")
    hits = np.abs(scores[:, None] - CENTRES) <= 7
    low = hits.argmax(axis=1)
    high = len(CENTRES) - hits[:, ::-1].argmax(axis=1)
    if not np.array_equal(hits, (np.arange(len(CENTRES)) >= low[:, None]) & (np.arange(len(CENTRES)) < high[:, None])):
        raise ValueError("Non-contiguous native score window")
    return low, high


def interval_histogram(bins, low, high, weights, bin_count):
    width = len(CENTRES) + 1
    offsets = bins.astype(np.int64) * width
    if len(bins) and (bins.min() < 0 or bins.max() >= bin_count):
        raise ValueError("Invalid feature bin")
    start = np.bincount(offsets + low, weights=weights, minlength=bin_count * width)
    end = np.bincount(offsets + high, weights=weights, minlength=bin_count * width)
    return np.cumsum((start - end).reshape(bin_count, width)[:, :-1], axis=1)


class FitBinner:
    def fit(self, x):
        if x.ndim != 2 or np.isinf(x).any():
            raise ValueError("Numeric feature matrix with explicit NaN missingness required")
        self.cuts_ = []
        for column in x.T:
            values = column[np.isfinite(column)]
            cuts = np.unique(np.quantile(values, np.arange(1, 16) / 16)) if len(values) else np.array([])
            # Retain a cut at the minimum for discrete0/1 columns; drop the maximum.
            self.cuts_.append(cuts[cuts < values.max()] if len(values) else cuts)
        self.bin_counts_ = np.array([len(c) + 2 for c in self.cuts_])
        return self

    def transform(self, x):
        if x.ndim != 2 or x.shape[1] != len(self.cuts_) or np.isinf(x).any():
            raise ValueError("Prediction feature schema differs")
        binned = np.empty(x.shape, dtype=np.uint8)
        for j, cuts in enumerate(self.cuts_):
            binned[:, j] = np.where(np.isnan(x[:, j]), len(cuts) + 1, np.searchsorted(cuts, x[:, j], side="left"))
        return binned


def week_weights(weeks, rng):
    unique, inverse = np.unique(weeks, return_inverse=True)
    if not len(unique):
        raise ValueError("Earlier training weeks required")
    counts = np.bincount(rng.integers(0, len(unique), size=len(unique)), minlength=len(unique))
    return counts[inverse].astype(float)


@dataclass
class Node:
    mass: np.ndarray
    prediction: float
    feature: int = -1
    threshold: int = -1
    missing_left: bool = False
    left: Node | None = None
    right: Node | None = None


class ModalTree:
    def __init__(self, max_depth, min_leaf, feature_count=None, prior=0):
        self.max_depth, self.min_leaf = max_depth, min_leaf
        self.feature_count, self.prior = feature_count, prior

    def fit(self, x, scores):
        self.binner_ = FitBinner().fit(x)
        return self.fit_binned(
            self.binner_.transform(x),
            scores,
            self.binner_.bin_counts_,
            np.ones(len(scores)),
            np.random.default_rng(20261104),
        )

    def fit_binned(self, binned, scores, bin_counts, weights, rng, intervals=None):
        if (
            len(binned) != len(scores)
            or len(weights) != len(scores)
            or not np.isfinite(weights).all()
            or (weights < 0).any()
        ):
            raise ValueError("Invalid modal training rows/weights")
        self._x, self._y, self._weights = binned, scores, weights
        self._bin_counts, self._rng = bin_counts, rng
        self._low, self._high = score_intervals(scores) if intervals is None else intervals
        selected = np.flatnonzero(weights > 0)
        if not len(selected):
            raise ValueError("Empty bootstrap sample")
        root_counts = self._hits(selected)
        self._global = root_counts / weights.sum()
        self._leaf_hits = 0.0
        self.statistics_ = {"nodes": 0, "leaves": 0, "maximumDepth": 0}
        self.root_ = self._grow(selected, 0)
        self.statistics_["trainingOnlyWeightedHit"] = self._leaf_hits / weights.sum()
        # Prediction retains only the binner and fitted nodes, never target rows.
        del self._x, self._y, self._weights, self._low, self._high, self._rng, self._global
        return self

    def _hits(self, indices):
        return interval_histogram(
            np.zeros(len(indices), dtype=int), self._low[indices], self._high[indices], self._weights[indices], 1
        )[0]

    def _best_split(self, indices, total):
        feature_count = self._x.shape[1]
        selected = (
            np.arange(feature_count)
            if self.feature_count is None
            else np.sort(self._rng.choice(feature_count, min(feature_count, self.feature_count), replace=False))
        )
        best, parent = None, total.max()
        for feature in selected:
            bins = self._x[indices, feature]
            count = self._bin_counts[feature]
            hist = interval_histogram(bins, self._low[indices], self._high[indices], self._weights[indices], count)
            prefix = np.cumsum(hist[:-1], axis=0)
            sizes = np.bincount(bins, minlength=count)
            prefix_size = np.cumsum(sizes[:-1])
            for missing_left in (False, True):
                left = prefix + hist[-1] if missing_left else prefix
                left_size = prefix_size + sizes[-1] if missing_left else prefix_size
                gain = left.max(axis=1) + (total[None, :] - left).max(axis=1) - parent
                valid = (left_size >= self.min_leaf) & (len(indices) - left_size >= self.min_leaf)
                gain = np.where(valid, gain, -np.inf)
                threshold = int(np.argmax(gain))
                value = gain[threshold]
                if value >= 1 and (best is None or value > best[0]):
                    best = float(value), int(feature), threshold, missing_left
        return best

    def _grow(self, indices, depth):
        counts = self._hits(indices)
        weight = self._weights[indices].sum()
        order = np.argsort(self._y[indices], kind="stable")
        median_index = np.searchsorted(np.cumsum(self._weights[indices][order]), weight / 2, side="left")
        median = self._y[indices][order[median_index]]
        winners = CENTRES[counts == counts.max()]
        prediction = float(winners[np.argmin(np.abs(winners - median))])
        mass = (counts + self.prior * self._global) / (weight + self.prior)
        node = Node(mass, prediction)
        self.statistics_["nodes"] += 1
        self.statistics_["maximumDepth"] = max(depth, self.statistics_["maximumDepth"])
        split = (
            self._best_split(indices, counts) if depth < self.max_depth and len(indices) >= 2 * self.min_leaf else None
        )
        if split is None:
            self.statistics_["leaves"] += 1
            self._leaf_hits += counts.max()
            return node
        _, feature, threshold, missing_left = split
        bins = self._x[indices, feature]
        is_left = np.where(bins == self._bin_counts[feature] - 1, missing_left, bins <= threshold)
        node.feature, node.threshold, node.missing_left = feature, threshold, missing_left
        node.left = self._grow(indices[is_left], depth + 1)
        node.right = self._grow(indices[~is_left], depth + 1)
        return node

    def _predict_binned(self, binned, return_mass):
        result = np.empty((len(binned), len(CENTRES))) if return_mass else np.empty(len(binned))

        def assign(node, indices):
            if node.feature < 0:
                result[indices] = node.mass if return_mass else node.prediction
                return
            bins = binned[indices, node.feature]
            left = np.where(bins == self._bin_counts[node.feature] - 1, node.missing_left, bins <= node.threshold)
            assign(node.left, indices[left])
            assign(node.right, indices[~left])

        assign(self.root_, np.arange(len(binned)))
        return result

    def predict_binned_mass(self, binned):
        return self._predict_binned(binned, True)

    def predict(self, x):
        return self._predict_binned(self.binner_.transform(x), False)


class ModalForest:
    def __init__(self, trees, max_depth, min_leaf, seed=20261104):
        self.trees, self.max_depth, self.min_leaf, self.seed = trees, max_depth, min_leaf, seed

    def fit(self, x, scores, weeks):
        self.binner_ = FitBinner().fit(x)
        binned = self.binner_.transform(x)
        intervals = score_intervals(scores)
        self.trees_ = []
        for i in range(self.trees):
            rng = np.random.default_rng(self.seed + i * 104729)
            tree = ModalTree(self.max_depth, self.min_leaf, max(1, int(np.sqrt(x.shape[1]))), prior=20)
            tree.fit_binned(binned, scores, self.binner_.bin_counts_, week_weights(weeks, rng), rng, intervals)
            self.trees_.append(tree)
            if (i + 1) % 16 == 0:
                print(f"MODAL_FOREST {i + 1}/{self.trees}", flush=True)
        self.statistics_ = {
            "trees": self.trees,
            "meanLeaves": float(np.mean([t.statistics_["leaves"] for t in self.trees_])),
            "trainingOnlyMeanTreeHit": float(np.mean([t.statistics_["trainingOnlyWeightedHit"] for t in self.trees_])),
        }
        return self

    def predict_mass(self, x):
        binned = self.binner_.transform(x)
        mass = np.zeros((len(x), len(CENTRES)))
        for tree in self.trees_:
            mass += tree.predict_binned_mass(binned)
        return mass / len(self.trees_)

    def predict(self, x):
        return window_centres(self.predict_mass(x), CENTRES)
