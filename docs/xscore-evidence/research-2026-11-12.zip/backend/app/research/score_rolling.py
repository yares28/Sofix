"""Refit a frozen LaLiga score architecture using only completed earlier games."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_europe_run import predict_components
from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval

LEVELS = np.array([0, 5, 15, 35, 60, 70, 80, 90, 100])


def month_folds(rows: list[dict], selected: np.ndarray, window_days: int):
    cutoffs = [cutoff_for(r["date"]) for r in rows]
    groups = sorted({at.strftime("%Y-%m") for at, keep in zip(cutoffs, selected, strict=True) if keep})
    available = [moment(r["date"]) + timedelta(hours=48) for r in rows]
    folds = []
    for group in groups:
        check = np.array([keep and at.strftime("%Y-%m") == group for at, keep in zip(cutoffs, selected, strict=True)])
        anchor = min(at for at, keep in zip(cutoffs, check, strict=True) if keep)
        fit = np.array(
            [at < anchor and (window_days == 0 or at >= anchor - timedelta(days=window_days)) for at in available]
        )
        folds.append((fit, check, anchor.isoformat()))
    return folds


def fit_parts(x, aa, level, fit, check, q):
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

    classifier = HistGradientBoostingClassifier(
        max_leaf_nodes=7,
        min_samples_leaf=80,
        max_iter=120,
        learning_rate=0.06,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    ).fit(x[fit], level[fit].astype(int))
    probability = np.zeros((int(check.sum()), len(LEVELS)))
    probability[:, np.searchsorted(LEVELS, classifier.classes_)] = classifier.predict_proba(x[check])
    regressor = HistGradientBoostingRegressor(
        loss="quantile",
        quantile=q,
        max_leaf_nodes=15,
        min_samples_leaf=60,
        max_iter=120,
        learning_rate=0.1,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    ).fit(np.column_stack((x[fit], level[fit])), aa[fit])
    ordinary = np.column_stack(
        [regressor.predict(np.column_stack((x[check], np.full(check.sum(), v)))) for v in LEVELS]
    )
    return probability, ordinary


def rolling_parts(x, rows, aa, level, selected, window, q, cache, key, label):
    probability = np.zeros((len(rows), len(LEVELS)))
    ordinary = np.full_like(probability, np.nan)
    receipt = []
    for fit, check, anchor in month_folds(rows, selected, window):
        path = cache / f"rolling_{label}_{window}_{anchor[:10]}.npz"
        cached = np.load(path) if path.exists() else None
        if cached is not None and str(cached["key"]) == key:
            p, a = cached["probability"], cached["ordinary"]
            cached.close()
        else:
            if cached is not None:
                cached.close()
            p, a = fit_parts(x, aa, level, fit, check, q)
            np.savez_compressed(path, key=key, probability=p, ordinary=a)
        probability[check], ordinary[check] = p, a
        receipt.append({"anchor": anchor, "fit": int(fit.sum()), "check": int(check.sum())})
        print(f"{label} window{window} at{anchor[:10]}: fit{fit.sum()} predict{check.sum()}", flush=True)
    if not np.isfinite(ordinary[selected]).all():
        raise ValueError("A target case did not receive a rolling prediction")
    return (LEVELS, probability[selected], {q: ordinary[selected]}), receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    with np.load(args.stats_cache) as stored:
        allx = stored["x"]
        stat_key = str(stored["key"])
    key = hashlib.sha256((source["key"] + stat_key).encode() + Path(__file__).read_bytes()).hexdigest()
    report = {
        "target": "Actual score within seven on all eligible LaLiga cases, starts and substitutes separately",
        "hypothesis": "Update the learned model with past completed games; no same-GW outcomes or retuning on later scores",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "implementationKey": key,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        x = allx[keep]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        aa = np.array([r["aa"] for r in rows])
        level = np.array([r["level"] for r in rows])
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        q = 0.35 if cohort == "start" else 0.5
        candidates = []
        for window in (0, 730, 365):
            parts, _ = rolling_parts(x, rows, aa, level, valid, window, q, args.cache, key, cohort + "_selection")
            for threshold in np.arange(0.1, 0.951, 0.025):
                for shift in (-3, 0, 3):
                    spec = {"windowDays": window, "quantile": q, "threshold": float(threshold), "ordinaryShift": shift}
                    candidates.append({**spec, "selection": measure(y[valid], predict_components(parts, spec))})
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        parts, folds = rolling_parts(
            x, rows, aa, level, test, winner["windowDays"], q, args.cache, key, cohort + "_later"
        )
        prediction = predict_components(parts, winner)
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Control cases differ")
            baseline = stored["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        pos = np.array([r["pos"] for r in rows])[test]
        result = {
            "winner": winner,
            "folds": folds,
            "later": measure(y[test], prediction),
            "staticControl": measure(y[test], baseline),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, baseline, weeks),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {p: measure(y[test][pos == p], prediction[pos == p]) for p in POSITIONS if (pos == p).any()},
        }
        np.savez_compressed(args.cache / f"rolling_predictions_{cohort}.npz", prediction=prediction, y=y[test], key=key)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
