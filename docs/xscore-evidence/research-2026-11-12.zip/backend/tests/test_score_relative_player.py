from datetime import UTC, datetime, timedelta

import numpy as np

from app.research.score_relative_player import deviations, prior


def test_player_history_excludes_own_score_from_peer_average():
    players = [("one", (8, 38)), ("two", (12, 45)), ("three", (20, 65))]
    shifted = deviations(players)
    np.testing.assert_array_equal(shifted["one"], [-8, -17])
    np.testing.assert_array_equal(sum(shifted.values()), [0, 0])
    assert deviations(players[:1]) == {}


def test_sparse_relative_history_shrinks_and_old_rows_are_excluded():
    lock = datetime(2026, 1, 1, tzinfo=UTC)
    target = np.array([4, 40])
    result, n = prior([(lock - timedelta(days=366), (100, 100))], lock, target)
    np.testing.assert_array_equal(result, target)
    assert n == 0
    result, n = prior([(lock - timedelta(days=5), (10, 46))], lock, target)
    np.testing.assert_array_equal(result, [5, 41])
    assert n == 1
