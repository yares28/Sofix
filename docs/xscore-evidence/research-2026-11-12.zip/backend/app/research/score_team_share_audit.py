"""Testing only: independent team-share arithmetic and complete chronological score audit."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_event_probability as event_policy
from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_team_share as share
from app.research import score_team_share_run as runner
from app.research.score_search import measure


def independent_rates(events, en, matchups, mn, lambdas, model):
    group, blend = share.MODELS[model]
    output, eligible_count, capped = [], 0, 0
    for ev, mat, lam in zip(events, matchups, lambdas, strict=True):
        e = dict(zip(en, ev, strict=True))
        m = dict(zip(mn, mat, strict=True))
        old = e["event_mu_" + group]
        minutes = e["event_expected_minutes"]
        goal, assist = e["event_goal_" + group + "90"], e["event_assist_" + group + "90"]
        other, exposure = e["event_other_history90"], m["teammates_exposure"]
        tg, ta = m["teammates_total_goals"], m["teammates_total_goal_assist"]
        values = [minutes, goal, assist, other, exposure, tg, ta, lam]
        eligible = (
            all(np.isfinite(v) and v >= 0 for v in values)
            and 1 <= minutes <= 90
            and exposure > 0
            and m["own_known_games"] > 0
            and m["teammates_recent_games"] > 0
            and m["teammates_known_fraction"] >= 1
        )
        if eligible:
            factor = (990 - minutes) / exposure
            own_g, own_a = minutes / 90 * goal, minutes / 90 * assist
            denominator = max(own_g + tg * factor, own_a + ta * factor)
            eligible = denominator > 0
        value = old
        if eligible:
            fraction = (own_g + own_a) / denominator
            capped += fraction > 1
            fraction = min(1, max(0, fraction))
            if not 0 <= lam * fraction <= lam:
                raise ValueError("Independent individual goal budget failed")
            value = (1 - blend) * old + blend * (lam * fraction + minutes / 90 * other)
            eligible_count += 1
        output.append([value, e["event_mu_negative"]])
    return np.array(output), {
        "target": len(events),
        "eligible": eligible_count,
        "fallback": len(events) - eligible_count,
        "shareCapped": int(capped),
        "goalAssistBoundViolations": 0,
        "noEventLabelsUsed": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "cases",
        "event-cache",
        "event-report",
        "matchup-cache",
        "matchup-report",
        "cache",
        "packages",
        "report",
        "games",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import scipy
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    er, mr = (json.loads(p.read_text()) for p in (args.event_report, args.matchup_report))
    if any(
        r["sourceKey"] != source["key"]
        for r in (report, er, mr, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Team-share audit source differs")
    with np.load(args.event_cache) as f:
        event, en, ek = f["x"], f["names"].tolist(), str(f["key"])
    with np.load(args.matchup_cache) as f:
        matchup, mn, mk = f["x"], f["names"].tolist(), str(f["key"])
    if (
        ek != er["featureKey"]
        or mk != mr["featureKey"]
        or len(event) != len(source["rows"])
        or len(matchup) != len(event)
    ):
        raise ValueError("Team-share audit feature coverage differs")
    files = (runner, share, event_policy, matched, controls, ordinary, stability, empirical, flow)
    key = hashlib.sha256(
        (
            source["key"]
            + ek
            + mk
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + scipy.__version__
        ).encode()
        + b"".join(Path(m.__file__).read_bytes() for m in files)
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Team-share audit formula fingerprint differs")
    names = source["features"]
    lambdas = np.array(
        [
            r["x"][names.index("match_lam_h" if r["x"][names.index("home")] > 0 else "match_lam_a")]
            for r in source["rows"]
        ],
        dtype=float,
    )
    arithmetic = {}
    for model in share.MODELS:
        independently, stats = independent_rates(event, en, matchup, mn, lambdas, model)
        original, original_stats = share.team_share_rates(event, en, matchup, mn, lambdas, model)
        if not np.allclose(original, independently, rtol=0, atol=1e-12) or original_stats != stats:
            raise ValueError("Team-share all-case independent arithmetic differs")
        arithmetic[model] = stats
    raw = [json.loads(line) for line in args.games.read_text().splitlines() if line.strip()]
    native_cases = 0
    for game in raw:
        for person in game["players"].values():
            if person.get("ver") != 7 or not person.get("played") or not isinstance(person.get("stats"), dict):
                continue
            side = next((s for s in ("home", "away") if person.get("team") == game[s]["slug"]), None)
            if side is None:
                raise ValueError("Native goal-share player side unknown")
            total = sum(person["stats"].get(k, [0, 0])[0] for k in ("goals", "goal_assist"))
            if total > game[side + "Goals"]:
                raise ValueError("Native individual goal-share bound fails")
            native_cases += 1
    if native_cases != len(source["rows"]):
        raise ValueError("Native individual goal-share cases differ")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        selected = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            winner != frozen["winner"]
            or best != frozen["best"]
            or frozen["implementationKey"] != key
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Team-share earlier freeze differs")
        previous = None
        reconstructed, caches = 0, 0
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            current_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            current = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "warm2023":
                previous = current_rows, current
                continue
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Team-share strongest control differs")
            bank = matched.bank_from(previous[1], previous[0], mask["first"])
            active = [best] if phase == "later2026" else frozen["candidates"]
            for model in sorted({r["spec"]["model"] for r in active}):
                rates, stats = independent_rates(
                    event[selected][target], en, matchup[selected][target], mn, lambdas[selected][target], model
                )
                with np.load(args.cache / f"{args.report.stem}_{cohort}_{phase}_{model}.npz") as f:
                    if (
                        str(f["key"]) != key
                        or not np.array_equal(rates, f["rates"])
                        or stats != json.loads(str(f["statistics"]))
                    ):
                        raise ValueError("Team-share cached rate arithmetic differs")
                caches += 1
                for policy in sorted({r["spec"]["event_policy"] for r in active if r["spec"]["model"] == model}):
                    probability = event_policy.event_probabilities(
                        current[0], rates[:, 0], rates[:, 1], policy, current[1]
                    )
                    candidate = empirical.empirical_predictions(
                        current[0], probability, current[2], positions[target], bank, 20, 0.75, 0
                    )
                    for record in [
                        r for r in active if r["spec"]["model"] == model and r["spec"]["event_policy"] == policy
                    ]:
                        spec = record["spec"]
                        forecast = event_policy.forecast_policy(
                            candidate, control, positions[target], spec["decision"], spec["scope"]
                        )
                        if phase == "later2026":
                            alternate = forecast
                        elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                            raise ValueError("Team-share earlier forecasts do not reconstruct")
                        reconstructed += 1
            previous = current_rows, current
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Team-share final all-case score identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Team-share native final metric differs")
            h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "candidateForecastsReconstructed": reconstructed,
            "rateCachesVerified": caches,
            "earlierSelectionVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
    output = {
        "scope": "Testing-only full native audit; reused historical outcomes not fresh blind proof",
        "implementationKey": key,
        "allCaseIndependentArithmetic": arithmetic,
        "nativeIndividualBoundCases": native_cases,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
