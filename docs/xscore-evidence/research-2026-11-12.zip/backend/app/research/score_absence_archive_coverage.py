"""Preview page availability by exact round, with no player claims used as features."""

import hashlib
import json
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

from app.research.score_absence_clock_pilot import NATIVE, NATIVE_SHA, ROOT, available_clock, coverage_ceiling
from app.research.score_search import cutoff_for, moment

DIRECTORY = ROOT / "suspension-source"
OUT = Path("reports/experiments/laliga_score_absence_archive_coverage.json")
PHASES = (
    ("spring2024", "2024-01-01", "2024-07-01"),
    ("season2024", "2024-07-01", "2025-07-01"),
    ("autumn2025", "2025-07-01", "2026-01-01"),
    ("later2026", "2026-01-01", "2027-01-01"),
)


def group_fixtures(games, calendars):
    groups = defaultdict(list)
    for season, calendar in calendars.items():
        assert len(calendar["pairs"]) == 380 and calendar["independentEnginesAgree"]
        keys = {(r["home"], r["away"]): r["round"] for r in calendar["pairs"]}
        assert len(keys) == 380
        year = int(season[:4])
        for game in games:
            if f"{year}-07-01" <= game["date"] < f"{year + 1}-07-01":
                pair = tuple(game[s]["slug"] for s in ("home", "away"))
                groups[season, keys[pair]].append(game)
    assert sum(map(len, groups.values())) == 478
    assert len({g["id"] for group in groups.values() for g in group}) == 478
    assert max(map(len, groups.values())) == 10
    return groups


def main():
    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = [json.loads(row) for row in native.splitlines()]
    source = json.loads((ROOT / "cases.json").read_text())
    manifest = DIRECTORY / "ser_archive_article_manifest.json"
    calendars = DIRECTORY / "calendar_rounds.json"
    articles = json.loads(manifest.read_text(encoding="utf-8-sig"))
    groups = group_fixtures(games, json.loads(calendars.read_text()))
    assert len(articles) == 44 and len({(a["season"], a["round"]) for a in articles}) == 44
    evidence, eligible, raw_clock_only = [], set(), set()
    for a in articles:
        path = Path(a["file"])
        raw = path.read_bytes()
        assert a["status"] == 200 and hashlib.sha256(raw).hexdigest() == a["sha256"]
        targets = groups[a["season"], a["round"]]
        item = dict(season=a["season"], round=a["round"], url=a["url"], sha256=a["sha256"], nativeFixtures=len(targets))
        try:
            canonical, published, modified = available_clock(raw.decode("utf-8"))
            if canonical.rstrip("/") != a["url"].rstrip("/"):
                raise ValueError("Article canonical URL mismatch")
        except (ValueError, KeyError) as error:
            evidence.append(dict(item, status="unknown_article_clock", reason=str(error)))
            continue
        clock_ok, fresh, late, stale = [], [], [], []
        for g in targets:
            lock, kickoff = cutoff_for(g["date"]), moment(g["date"])
            if modified >= lock:
                late.append(g["id"])
                continue
            clock_ok.append(g["id"])
            # Avoid treating a preview for a postponed fixture as evidence months later.
            if kickoff - modified > timedelta(days=7):
                stale.append(g["id"])
            else:
                fresh.append(g["id"])
        assert len(fresh) + len(late) + len(stale) == len(targets)
        assert not eligible.intersection(fresh)
        eligible.update(fresh)
        raw_clock_only.update(clock_ok)
        evidence.append(
            dict(
                item,
                status="clock_verified",
                published=published.isoformat(),
                revision=modified.isoformat(),
                eligibleGames=fresh,
                lateGames=late,
                staleGames=stale,
            )
        )
    rows = source["rows"]
    periods = {}
    for phase, begin, end in PHASES:
        group = [r for r in rows if begin <= r["date"] < end]
        periods[phase] = dict(
            games=len({r["game"] for r in group}),
            fixturesWithTimelyRecentPage=len({r["game"] for r in group if r["game"] in eligible}),
            fixturesWithTimelyPageIgnoringAge=len({r["game"] for r in group if r["game"] in raw_clock_only}),
            cases=dict(Counter(r["cohort"] for r in group)),
            eligibleCases={
                c: sum(r["cohort"] == c and r["game"] in eligible for r in group) for c in ("start", "bench")
            },
        )
    report = dict(
        nativeSHA=NATIVE_SHA,
        caseSourceKey=source["key"],
        articleManifestSHA=hashlib.sha256(manifest.read_bytes()).hexdigest(),
        calendarRoundsSHA=hashlib.sha256(calendars.read_bytes()).hexdigest(),
        maximumRevisionAgeDaysAtKickoff=7,
        articleStatus=dict(Counter(r["status"] for r in evidence)),
        periods=periods,
        articles=evidence,
        perfectCoverageCeiling=coverage_ceiling(rows, eligible),
        scope="Source timing and optimistic headroom only. No player claims qualified, no model evaluated.",
    )
    OUT.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("articleStatus", "periods", "perfectCoverageCeiling")}, indent=2))


if __name__ == "__main__":
    main()
