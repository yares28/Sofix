from datetime import UTC, datetime

import pytest

from app.research.score_market_booklets_audit import pdf_date, raw_row_codes


def test_raw_pdf_timezone_signs_are_not_inferred_from_cover_country():
    assert pdf_date("D:20260123123000+02'00'") == datetime(2026, 1, 23, 10, 30, tzinfo=UTC)
    assert pdf_date("D:20260123123000-03'30'") == datetime(2026, 1, 23, 16, 0, tzinfo=UTC)
    with pytest.raises(ValueError, match="timezone"):
        pdf_date("D:20260123123000")


def test_two_side_by_side_tables_are_distinct_complete_printed_rows():
    page = (
        "GOALSCORER SPAIN LA LIGA Pe 21:00 6642 Name Club 2.30 "
        "Su 16:15 6643 Another Club 3.50 "
        "GOALSCORER SPAIN LA LIGA Ne 18:30 7250 Third Club 4.20"
    )
    assert raw_row_codes(page) == ["6642", "6643", "7250"]
