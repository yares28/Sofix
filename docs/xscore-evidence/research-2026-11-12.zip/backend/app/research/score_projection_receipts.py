"""Join local, time-stamped Sorare projection receipts to exact native cases."""

import hashlib
import json
import re
from collections import Counter, defaultdict

import numpy as np

from app.research.score_absence_clock_pilot import NATIVE, NATIVE_SHA, ROOT
from app.research.score_absence_role_signal import REPORTS
from app.research.score_failure_review import summary
from app.research.score_penalty_miss_scope import REFERENCES
from app.research.score_search import cutoff_for, moment

STEM = "laliga_score_projection_receipts"
MAIN = NATIVE.parents[3]


def copy_text(raw):
    lookup = {"t": "\t", "n": "\n", "r": "\r", "b": "\b", "f": "\f", "v": "\v", "\\": "\\"}
    return re.sub(r"\\(.)", lambda match: lookup.get(match[1], match[1]), raw)


def backup_rows(folder, name, expected):
    schema = json.loads((folder / "manifest.json").read_bytes())["tables"][name]
    names = schema["columns"]
    assert set(expected) <= set(names)
    with (folder / (name + ".copy")).open(encoding="utf-8") as stream:
        for line in stream:
            row = line.rstrip("\n").split("\t")
            assert len(row) == len(names)
            yield {k: row[names.index(k)] if row[names.index(k)] != r"\N" else None for k in expected}


def time_valid(written, official, kickoff):
    times = [cutoff_for(kickoff)]
    if official is not None:
        times.append(moment(official))
    return moment(written) < min(times)


def snapshot_records(blocks, backup):
    hashes, payloads = {}, []
    paths = sorted(blocks.glob("score_record%3A*.json"))
    if not paths:
        raise ValueError("No local score-record snapshots found")
    for path in paths:
        raw = path.read_bytes()
        payload = json.loads(raw)["payload"]
        hashes[path.name] = hashlib.sha256(raw).hexdigest()
        payloads.append((path.name, payload))
    raw = (backup / "read_models.copy").read_bytes()
    hashes["read_models.copy"] = hashlib.sha256(raw).hexdigest()
    for line in raw.decode("utf-8").splitlines():
        if line.startswith("score_record:"):
            key, content, _ = line.split("\t")
            payloads.append((key, json.loads(copy_text(content))))
    return payloads, hashes


def collect(games, payloads, backup):
    receipts, audit, official = defaultdict(list), Counter(), {}
    for name, payload in payloads:
        week = payload["gameweek"]
        for slug, entry in payload["players"].items():
            for details in entry["games"]:
                game_id = details.get("id")
                game = games.get(game_id)
                if game is None or slug not in game["players"]:
                    continue
                if not details.get("kickoff") or moment(details["kickoff"]) != moment(game["date"]):
                    audit["snapshotKickoffDiffers"] += 1
                    continue
                official.setdefault(game_id, set()).add(week["lock"])
                if not time_valid(payload["writtenAt"], week["lock"], game["date"]):
                    audit["snapshotAtOrAfterLock"] += 1
                    continue
                value = details.get("sorare")
                if type(value) not in (int, float) or not 0 <= value <= 100:
                    continue
                receipts[game_id, slug].append((moment(payload["writtenAt"]), float(value), name))
                audit["snapshotQuotes"] += 1
    fields = ("player", "game_id", "date", "sorare_x", "said_at")
    for r in backup_rows(backup, "player_games", fields):
        game = games.get(r["game_id"])
        if game is None or r["player"] not in game["players"] or not r["said_at"] or r["sorare_x"] is None:
            continue
        if moment(r["date"]) != moment(game["date"]):
            audit["backupKickoffDiffers"] += 1
            continue
        clocks = official.get(r["game_id"], set())
        first = min(clocks, key=moment) if clocks else None
        if not time_valid(r["said_at"], first, game["date"]):
            audit["backupAtOrAfterLock"] += 1
            continue
        value = float(r["sorare_x"])
        if not 0 <= value <= 100:
            continue
        receipts[r["game_id"], r["player"]].append((moment(r["said_at"]), value, "player_games.copy"))
        audit["backupQuotes"] += 1
    accepted = {}
    for key, options in receipts.items():
        latest = max(item[0] for item in options)
        same_time = {item[1] for item in options if item[0] == latest}
        if len(same_time) == 1:
            accepted[key] = next(iter(same_time))
        else:
            audit["sameTimeDisagreement"] += 1
    return accepted, dict(audit)


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines())}
    backup = NATIVE.parent / "neon-backup-2026-10-12"
    blocks = MAIN / "frontend" / ".blocks"
    payloads, hashes = snapshot_records(blocks, backup)
    hashes["player_games.copy"] = hashlib.sha256((backup / "player_games.copy").read_bytes()).hexdigest()
    qualified, audit = collect(games, payloads, backup)
    all_rows = json.loads((ROOT / "cases.json").read_bytes())["rows"]
    report = dict(
        nativeSHA=NATIVE_SHA,
        localSourceSHA=hashes,
        audit=audit,
        earlierQualified=dict(
            Counter(r["cohort"] for r in all_rows if r["date"] < "2026-01-01" and (r["game"], r["player"]) in qualified)
        ),
        later={},
        modelFitted=False,
    )
    for cohort, (stem, key, n, correct) in REFERENCES.items():
        rows = [r for r in all_rows if r["date"] >= "2026-01-01" and r["cohort"] == cohort]
        with np.load(ROOT / f"laliga_score_{stem}_predictions_{cohort}.npz") as f:
            assert str(f["key"]) == key
            y, baseline = f["y"], f["prediction"]
        np.testing.assert_array_equal(y, [r["score"] for r in rows])
        np.testing.assert_equal(int((abs(y - baseline) <= 7).sum()), correct)
        assert len(rows) == n
        quote = np.array([qualified.get((r["game"], r["player"]), np.nan) for r in rows])
        retrospective = np.array(
            [
                games[r["game"]]["players"][r["player"]]["proj"]
                if games[r["game"]]["players"][r["player"]]["proj"] is not None
                else np.nan
                for r in rows
            ]
        )
        known = np.isfinite(quote)
        paired = known & np.isfinite(retrospective)
        miss = known & (abs(y - baseline) > 7)
        frozen_hit = abs(y[known] - baseline[known]) <= 7
        receipt_hit = abs(y[known] - quote[known]) <= 7
        raw_hit = abs(y[paired] - retrospective[paired]) <= 7
        raw_receipt_hit = abs(y[paired] - quote[paired]) <= 7
        heavy = known & (abs(y - baseline) > 25)
        report["later"][cohort] = dict(
            allCases=n,
            covered=int(known.sum()),
            coveredFixtures=len({r["game"] for r, present in zip(rows, known, strict=True) if present}),
            rawProjectionPresent=int(np.isfinite(retrospective).sum()),
            matchedRetrospectiveAndReceipt=int(paired.sum()),
            sameProjectionWithinTenth=int(np.sum(abs(quote[paired] - retrospective[paired]) <= 0.1000001)),
            medianAbsoluteDifference=float(np.median(abs(quote[paired] - retrospective[paired])))
            if paired.any()
            else None,
            frozenOnCovered=summary(y[known], baseline[known]),
            sorareOnCovered=summary(y[known], quote[known]),
            pairedComparison={
                "receiptHitFrozenMiss": int(np.sum(receipt_hit & ~frozen_hit)),
                "frozenHitReceiptMiss": int(np.sum(frozen_hit & ~receipt_hit)),
                "bothHit": int(np.sum(frozen_hit & receipt_hit)),
                "bothMiss": int(np.sum(~frozen_hit & ~receipt_hit)),
                "receiptFixedFrozenMissOver25": int(np.sum(abs(y[heavy] - quote[heavy]) <= 7)),
                "rawAndReceiptDisagreeOnWithin7": int(np.sum(raw_hit != raw_receipt_hit)),
            },
            coveredFrozenMisses=int(miss.sum()),
            perfectWithinCoveragePct=100 * (correct + int(miss.sum())) / n,
        )
    report["limit"] = (
        "The receipt benchmark is Sorare's score-if-playing value, common to both cohorts. "
        "Later outcomes are used only to diagnose the paired benchmark. Retrospective projections and reliability "
        "have no per-game observation clock and are not adopted as target inputs."
    )
    report["otherLocalSource"] = {
        "playerGameBlocks": sum(1 for _ in blocks.glob("player_games%3A*.json")),
        "timingLimit": "Published player-game blocks omit said_at. Their read_at day tracks later game re-reads, "
        "so they are not added to qualified quote coverage.",
    }
    (REPORTS / (STEM + ".json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"audit": audit, "earlier": report["earlierQualified"], "later": report["later"]}, indent=2))


if __name__ == "__main__":
    main()
