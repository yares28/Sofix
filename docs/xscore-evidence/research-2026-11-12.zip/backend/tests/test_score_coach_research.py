from datetime import UTC, datetime

import numpy as np

from app.research.score_coach_clocks import inspect, version_clock, visible_title_mentions
from app.research.score_corner_allocation import corner_estimate
from app.research.score_team_routine_shift import build_earlier, team_shift


def test_headline_keeps_article_and_ignores_recommendations():
    title, headline, dates = inspect(
        '<head><meta property="og:title" content="Villarreal"></head>'
        "<h1><strong>Iñigo Pérez</strong>, head coach</h1><h1>New manager Marcelino</h1>"
        '<script>{"datePublished":"2026-06-01T09:00:00Z","dateModified":"2026-06-01T09:30:00Z"}</script>'
    )
    assert title == "Villarreal"
    assert visible_title_mentions("Iñigo Pérez", headline)
    assert not visible_title_mentions("Marcelino", headline)
    assert version_clock(dates) == (datetime(2026, 6, 1, 9, 30, tzinfo=UTC), "revision_explicit_timezone")


def test_date_without_time_is_unqualified():
    _, _, dates = inspect('<script>{"datePublished":"2026-06-01","dateModified":"2026-06-01"}</script>')
    assert version_clock(dates)[0] is None


def test_shift_requires_repeated_same_position_teammate_effect():
    lock = datetime(2026, 1, 1, tzinfo=UTC)
    players = [("subject", "MID", -25), ("team", "MID", 10), ("team2", "DEF", 20)]
    assert team_shift([(lock, players)], "subject", "MID", lock) == 0
    assert team_shift([(lock, players), (lock, players)], "subject", "MID", lock) == 5


def test_corner_share_uses_matching_historical_role():
    lock = datetime(2026, 1, 1, tzinfo=UTC)
    own = [(lock, 5, 3, {("player", "start"): 5}), (lock, 5, 3, {("player", "bench"): 0})]
    other = [(lock, 4, 8, {})]
    assert corner_estimate([], other, [], "player", "start", lock) == (0, 0)
    assert corner_estimate(own, other, [(lock, 2)], "player", "start", lock) == (2, (38 / 7) * (13 / 25))
    assert corner_estimate(own, other, [(lock, 0)], "player", "bench", lock) == (0, 0)


def test_two_fixtures_sharing_a_lock_cannot_use_each_others_scores():
    dates = ("2024-01-06T14:00:00Z", "2024-01-07T14:00:00Z", "2024-01-12T20:00:00Z")

    def build(value):
        rows, games = [], []
        for i, (date, aa) in enumerate(zip(dates, (value, 3.0, 4.0), strict=True)):
            rows.append(dict(date=date, game=i, player="player", pos="MID", cohort="start", aa=aa))
            games.append(
                dict(
                    id=i,
                    date=date,
                    home={"slug": "home"},
                    away={"slug": "away"},
                    players={"player": dict(team="home", played=True, aa=aa)},
                )
            )
        return build_earlier(rows, games)

    base, x = build(10.0)
    changed, changed_x = build(20.0)
    np.testing.assert_array_equal(base[:2], changed[:2])
    np.testing.assert_array_equal(x[:2], changed_x[:2])
    assert base[2] == 6.5 and changed[2] == 11.5
