"""Testing only: chronological search of small arithmetic score formulas."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_symbolic_formula as network
from app.research.score_matchups_run import validate_stat_identity
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval

MODELS = {
    f"d{d}_{tag}": {"max_depth": d, "penalty": p} for d in (3, 5) for tag, p in (("small", 0.0001), ("strong", 0.001))
}


def fitted(x, y, mask, spec, epochs, path, key, names):
    if path.exists():
        with np.load(path) as f:
            stats = json.loads(str(f["statistics"]))
            if (
                str(f["key"]) != key
                or len(f["prediction"]) != int(mask["target"].sum())
                or stats["generations"] != epochs
            ):
                raise ValueError("Symbolic formula cache identity differs")
            return f["prediction"], stats
    snapshot = path.with_name(path.stem.rsplit("_e", 1)[0] + "_" + key[:12] + ".search.json")
    model = network.FormulaSearch(**spec, generations=epochs, population=256).fit(
        x[mask["fit"]], y[mask["fit"]], names=names, snapshot=snapshot, key=key
    )
    prediction = model.predict(x[mask["target"]])
    stats = {**model.statistics_, "targetRows": int(mask["target"].sum())}
    np.savez_compressed(
        path,
        key=key,
        prediction=prediction,
        statistics=json.dumps(stats),
        feature_names=names,
        median=model.median_,
        lower=model.lower_,
        upper=model.upper_,
        known=model.known_,
    )
    return prediction, stats


def fresh(spec):
    return {"spec": spec, "gains": [], "errors": [], "counts": [], "periods": {}}


def add_metric(record, phase, y, prediction, control, statistics):
    metric = measure(y, prediction)
    gain = metric["within7"] - measure(y, control)["within7"]
    record["gains"].append(gain)
    record["errors"].append(metric["mae"])
    record["counts"].append(len(y))
    record["periods"][phase] = {"gain": gain, "metrics": metric, "fitDiagnostics": statistics}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_bench, old_start, event_report, history_report = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_analogues",
            "laliga_score_match_empirical_density",
            "laliga_score_event_intensity",
            "laliga_score_modal_history",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (
            old_match,
            old_player,
            old_stability,
            old_ordinary,
            old_bench,
            old_start,
            event_report,
            history_report,
        )
    ):
        raise ValueError("Symbolic-formula source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, names, stat_key = f["x"], f["names"].tolist(), str(f["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    arrays, feature_keys = {}, []
    for label, file, expected in (
        ("match", "match_context_features.npz", old_match["featureKey"]),
        ("player", "player_context_features.npz", old_player["featureKey"]),
        ("history", "modal_history_features.npz", history_report["featureKey"]),
        ("event", "event_intensity_features.npz", event_report["featureKey"]),
    ):
        with np.load(args.cache / file) as f:
            if str(f["key"]) != expected or len(f["x"]) != len(source["rows"]):
                raise ValueError("Symbolic-formula feature provenance differs")
            arrays[label] = (f["x"], f["names"].tolist())
            feature_keys.append(str(f["key"]))
    if event_report["featureKey"] not in plan["inputs"]:
        raise ValueError("Symbolic-formula registered causal inputs differ")
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + "".join(feature_keys)
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in (network, controls, ordinary, stability))
        + Path(__file__).read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no app changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "eventFeatureKey": event_report["featureKey"],
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] == key:
            report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y, weeks, positions = (
            np.array([r["score"] for r in rows]),
            np.array([r["week"] for r in rows]),
            np.array([r["pos"] for r in rows]),
        )
        masks = stability.phase_masks(rows)
        numeric, numeric_names = ordinary.ordinary_inputs(
            base[keep],
            names,
            arrays["player"][0][keep],
            arrays["player"][1],
            arrays["match"][0][keep],
            arrays["match"][1],
            cohort,
        )
        x = np.column_stack(
            (
                numeric,
                arrays["history"][0][keep],
                arrays["event"][0][keep],
                *[(positions == p).astype(float) for p in POSITIONS],
            )
        )
        input_names = numeric_names + arrays["history"][1] + arrays["event"][1] + ["position_" + p for p in POSITIONS]
        if x.shape[1] != len(input_names) or x.shape[1] != 182:
            raise ValueError("Symbolic formula fixed182input coverage differs")
        records = [fresh({"model": model, "scope": scope}) for model in MODELS for scope in ("all", "defmid")]
        audit, control_bank = {}, {}

        def get_control(phase, *, cohort=cohort, masks=masks, y=y, control_bank=control_bank):
            if phase not in control_bank:
                control = controls.control_for(
                    args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
                )
                expected = (
                    old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                    if phase != "later2026"
                    else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
                )
                if measure(y[masks[phase]["target"]], control) != expected:
                    raise ValueError("Symbolic-formula strongest control differs")
                control_bank[phase] = control
            return control_bank[phase]

        def get_prediction(phase, name, epochs, *, cohort=cohort, masks=masks, x=x, y=y, input_names=input_names):
            print(f"SYMBOLIC_FITTING {cohort} {phase} {name} generations{epochs}", flush=True)
            return fitted(
                x,
                y,
                masks[phase],
                MODELS[name],
                epochs,
                args.cache / f"{args.out.stem}_{cohort}_{phase}_{name}_e{epochs}_{key[:12]}.npz",
                key,
                input_names,
            )

        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            control = get_control(phase)
            audit[phase] = {
                "fit": int(masks[phase]["fit"].sum()),
                "target": int(target.sum()),
                "control": measure(y[target], control),
                "models": {},
            }
            for name in MODELS:
                raw, stats = get_prediction(phase, name, 80)
                audit[phase]["models"][name] = {"rawForecast": measure(y[target], raw), "fitDiagnostics": stats}
                for record in [r for r in records if r["spec"]["model"] == name]:
                    candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    add_metric(record, phase, y[target], candidate, control, stats)
                print(
                    "SYMBOLIC_SCREEN "
                    + json.dumps(
                        {"cohort": cohort, "phase": phase, "model": name, "rawForecast": measure(y[target], raw)}
                    ),
                    flush=True,
                )
        winner80, best80 = stability.choose_stable(records)
        fixed = winner80 or best80
        args.out.with_name(args.out.stem + f".{cohort}.screening.json").write_text(
            json.dumps(
                {
                    "implementationKey": key,
                    "winner80": winner80,
                    "best80": best80,
                    "fixedConfirmationSpec": fixed["spec"],
                    "candidates80": records,
                },
                indent=2,
            )
        )
        confirmed = fresh(fixed["spec"].copy())
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            raw, stats = get_prediction(phase, fixed["spec"]["model"], 160)
            candidate = ordinary.scoped_prediction(raw, get_control(phase), positions[target], fixed["spec"]["scope"])
            add_metric(confirmed, phase, y[target], candidate, get_control(phase), stats)
        winner = confirmed if min(confirmed["gains"]) > 0 else None
        frozen = {
            "implementationKey": key,
            "winner": winner,
            "finalCandidate": confirmed,
            "screenWinner80": winner80,
            "screenBest80": best80,
            "candidates80": records,
            "passingCandidates80": sum(min(r["gains"]) > 0 for r in records),
        }
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
        print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "candidate": confirmed}), flush=True)
        phase = "later2026"
        target = masks[phase]["target"]
        raw, stats = get_prediction(phase, fixed["spec"]["model"], 160)
        control = get_control(phase)
        alternate = ordinary.scoped_prediction(raw, control, positions[target], fixed["spec"]["scope"])
        prediction = alternate if winner else control.copy()
        h0, h1 = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": confirmed,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks[target].tolist()),
            "finalFitDiagnostics": stats,
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            alternate=alternate,
            prediction=prediction,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
