from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from app.research import score_residual_mixture_run as runner
from app.research.score_residual_mixture import fit_forecasts


def inputs():
    records = {
        "available": np.array([99.0, 100.0, 101.0]),
        "error": np.array([2.0, 999.0, -999.0]),
        "x": np.array([[1.0, 5.0, 4.0, 0.8], [2.0, 1.0, 2.0, 0.9], [3.0, 1.0, 2.0, 0.1]]),
        "position": np.array(["DEF", "DEF", "DEF"]),
        "level": np.array([35.0, 60.0, 15.0]),
    }
    context = np.array([[np.nan], [4.0]])
    classes = np.array([35.0, 60.0])
    p = np.tile([0.8, 0.2], (2, 1))
    q = {
        0.35: np.array([[3.0, 3.0], [3.0, 3.0]]),
        0.5: np.array([[5.0, 5.0], [5.0, 5.0]]),
        0.65: np.array([[7.0, 7.0], [7.0, 7.0]]),
    }
    return records, context, (classes, p, q), np.array(["GK", "DEF"])


def test_exact_availability_boundary_and_unavailable_labels_cannot_affect_fit(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    records, context, parts, positions = inputs()
    setting = {"components": 2, "width": 4, "ridge": 0.1}
    first, stats = fit_forecasts(records, context, parts, positions, 100.0, setting, epochs=3)
    records["error"][1:] = np.nan
    records["level"][1:] = np.nan
    records["x"][1:] = np.nan
    repeated, newstats = fit_forecasts(records, context, parts, positions, 100.0, setting, epochs=3)
    np.testing.assert_equal(first, repeated)
    assert stats == newstats and stats["eligibleOOFErrors"] == 1 and stats["excludedUnavailableErrors"] == 2
    assert first.shape == (2, 201) and np.isfinite(first).all()


def test_no_available_errors_is_reported_and_never_becomes_zero(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    records, context, parts, positions = inputs()
    with pytest.raises(ValueError, match="available"):
        fit_forecasts(records, context, parts, positions, 99.0, {"components": 2, "width": 4, "ridge": 0.1}, epochs=3)


def test_original_probabilities_are_validated_and_all_cold_targets_kept(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    records, context, parts, positions = inputs()
    context[:] = np.nan
    mass, stats = fit_forecasts(
        records, context, parts, positions, 100.0, {"components": 2, "width": 4, "ridge": 0.1}, epochs=3
    )
    assert mass.shape == (2, 201) and stats["targetCases"] == 2 and np.isfinite(mass).all()
    classes, p, q = parts
    p[0] = [1, 1]
    with pytest.raises(ValueError, match="probability"):
        fit_forecasts(
            records, context, (classes, p, q), positions, 100.0, {"components": 2, "width": 4, "ridge": 0.1}, epochs=3
        )


def test_phase_banks_use_only_previous_predictions_and_never_2026_labels(tmp_path, monkeypatch):
    dates = [
        "2023-11-10T18:00:00Z",
        "2024-01-12T18:00:00Z",
        "2024-08-16T18:00:00Z",
        "2025-08-16T18:00:00Z",
        "2026-01-09T18:00:00Z",
    ]
    rows = [
        {"date": date, "player": "p", "pos": "DEF", "level": 35.0, "aa": float(i), "score": 35.0 + i}
        for i, date in enumerate(dates)
    ]
    calls = []

    def old(_, cohort, phase, *reports):
        assert phase != "later2026"
        calls.append(phase)
        return (
            np.array([35.0, 60.0]),
            np.array([[0.8, 0.2]]),
            {q: np.full((1, 2), v) for q, v in ((0.35, 1.0), (0.5, 2.0), (0.65, 3.0))},
        )

    monkeypatch.setattr(runner.flow, "old_components", old)
    args = SimpleNamespace(cache=tmp_path, out=tmp_path / "residual.json")
    context = np.arange(5.0)[:, None]
    first, unknown = runner.prepare_banks(rows, context, "start", args, {}, {}, {}, "test")
    rows[-1].update(aa=np.nan, level=np.nan)
    repeated, new_unknown = runner.prepare_banks(rows, context, "start", args, {}, {}, {}, "test")
    assert calls == ["warm2023", "spring2024", "season2024", "autumn2025"] * 2
    assert unknown == new_unknown and len(first["spring2024"]["error"]) == 1 and len(first["later2026"]["error"]) == 4
    for phase in first:
        for name in first[phase]:
            np.testing.assert_equal(first[phase][name], repeated[phase][name])


def test_runner_converts_phase_date_string_to_preceding_inferred_lock(tmp_path, monkeypatch):
    from app.research.score_search import cutoff_for

    records, context, parts, positions = inputs()
    seen = []

    def forecast(bank, ctx, old, pos, first_lock, setting, epochs):
        seen.append(first_lock)
        return np.zeros((2, 201)), {"epochs": epochs}

    monkeypatch.setattr(runner.mixture, "fit_forecasts", forecast)
    date = np.str_("2026-01-10T18:00:00Z")
    runner.fitted(
        records, context, positions, {"first": date}, parts, "k2_width16_l2small", 80, tmp_path / "fit.npz", "test"
    )
    assert seen == [cutoff_for(date).timestamp()]
