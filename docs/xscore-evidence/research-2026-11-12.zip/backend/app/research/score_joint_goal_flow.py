"""Earlier-only joint goal distribution comparison, keeping original marginals."""

import hashlib
import json
from itertools import product

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_goal_context_rebuild import interval, load
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY

STEM = "laliga_score_joint_goal_flow"
GRID = np.arange(-0.8, 0.81, 0.2)
SUPPORT = 31


def marginal(rate):
    probs = np.empty(SUPPORT)
    probs[0] = np.exp(-rate)
    for count in range(1, SUPPORT):
        probs[count] = probs[count - 1] * rate / count
    probs /= probs.sum()
    return probs


def joint_parts(home, away):
    p, q = marginal(home), marginal(away)
    independent = np.outer(p, q)
    left, right = (1 - 2 * np.cumsum(a) + a for a in (p, q))
    return independent, independent * np.outer(left, right)


def three_way(matrix):
    return np.array([np.tril(matrix, -1).sum(), matrix.trace(), np.triu(matrix, 1).sum()])


def fit_parameters(x, true_interaction, constant):
    options = np.column_stack((GRID, np.zeros((len(GRID), 2)))) if constant else np.array(list(product(GRID, repeat=3)))
    theta = np.tanh(x @ options.T)
    scores = -np.log1p(theta * true_interaction[:, None]).sum(axis=0)
    # Small fixed penalty to prefer restrained dependence with sparse samples.
    scores += 2 * np.square(options).sum(axis=1)
    return options[int(np.argmin(scores))]


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    case_data = json.loads((ROOT / "cases.json").read_bytes())
    cache = ROOT / "match_context_features.npz"
    receipt = json.loads((REPORTS / "laliga_score_match_context.json").read_bytes())
    rows = load(raw, case_data, cache, receipt)
    n = len(rows) // 2
    games = list(zip(rows[::2], rows[1::2], strict=True))
    dates = np.array([h[0] for h, _ in games])
    outcomes = np.array([(h[2], a[2]) for h, a in games])
    rates = np.array([h[3] for h, _ in games])
    known = np.all(np.isfinite(rates) & (rates > 0) & (rates <= 8), axis=1)
    rates[~known] = (1.45, 1.15)
    assert np.all((outcomes >= 0) & (outcomes < SUPPORT)) and all(h[0] == a[0] for h, a in games)
    design = np.column_stack((np.ones(n), rates.sum(axis=1) - 2.6, abs(rates[:, 0] - rates[:, 1]) - 0.5))
    p0, interaction, result0, result_delta = [], [], [], []
    for (h, a), score in zip(rates, outcomes, strict=True):
        base, delta = joint_parts(h, a)
        idx = tuple(score)
        p0.append(base[idx])
        interaction.append(delta[idx] / base[idx])
        result0.append(three_way(base))
        result_delta.append(three_way(delta))
    interaction, result0, result_delta = np.array(interaction), np.array(result0), np.array(result_delta)
    base_loss = -np.log(p0)
    truth = np.eye(3)[np.sign(outcomes[:, 1] - outcomes[:, 0]) + 1]
    ready = np.array([moment(d) + DELAY for d in dates])
    locks = np.array([cutoff_for(d) for d in dates])
    phases, kept = {}, {"constant": [], "context": []}
    selected_locks = []
    for phase, (begin, end) in PHASES.items():
        select = (dates >= begin) & (dates < end)
        train = (ready < locks[select].min()) & known
        phases[phase] = dict(matches=int(select.sum()), knownOriginalRates=int((select & known).sum()), arms={})
        ref_brier = ((truth[select] - result0[select]) ** 2).sum(axis=1)
        selected_locks.extend(locks[select])
        for name, constant in (("constant", True), ("context", False)):
            weights = fit_parameters(design[train], interaction[train], constant)
            theta = np.where(known[select], np.tanh(design[select] @ weights), 0)
            joint_gain = np.log1p(theta * interaction[select])
            probability = result0[select] + theta[:, None] * result_delta[select]
            np.testing.assert_allclose(probability.sum(axis=1), 1, rtol=0, atol=1e-10)
            brier = ((truth[select] - probability) ** 2).sum(axis=1)
            phases[phase]["arms"][name] = dict(
                parameters=weights.tolist(),
                logLoss=[float(base_loss[select].mean()), float((base_loss[select] - joint_gain).mean())],
                resultBrier=[float(ref_brier.mean()), float(brier.mean())],
            )
            kept[name].append(np.column_stack((joint_gain, ref_brier - brier)))
    gains = {k: np.concatenate(v) for k, v in kept.items()}
    gate = {}
    for name in gains:
        pooled = gains[name].mean(axis=0)
        stable = sum(np.all(v.mean(axis=0) > 0) for v in kept[name])
        ci = interval(gains[name][:, 0], np.array(selected_locks))
        extra = (gains[name] - gains["constant"]).mean(axis=0)
        gate[name] = dict(
            pooledJointLogLossGain=float(pooled[0]),
            pooledResultBrierGain=float(pooled[1]),
            jointGain95=ci,
            phasesBeatingIndependence=int(stable),
            passEarlier=bool(
                (pooled > 0).all() and stable >= 2 and ci[0] > 0 and (name == "constant" or (extra > 0).all())
            ),
        )
    output = dict(nativeSHA=NATIVE_SHA, earlierFixtures=n, periods=phases, gate=gate, laterEvaluated=False)
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
