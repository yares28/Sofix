"""Earlier-only native goal signal from strictly lagged provider shot placement."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_shot_style_signal as previous
from app.research.score_search import cutoff_for, moment

PHASES = previous.PHASES


def fitted(x, y, fit, target, architecture):
    if architecture == "logistic":
        return previous.fitted(x, y, fit, target, missing_width=45)
    if architecture != "nonlinear":
        raise ValueError("Unregistered finishing architecture")
    from sklearn.ensemble import HistGradientBoostingClassifier

    if not np.isfinite(y[fit]).all() or set(np.unique(y[fit])) != {0.0, 1.0}:
        raise ValueError("Two known training classes required")
    model = HistGradientBoostingClassifier(
        max_iter=120,
        max_leaf_nodes=7,
        min_samples_leaf=80,
        learning_rate=0.06,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261106,
    )
    model.fit(x[fit], y[fit])
    return dict(probability=model.predict_proba(x[target])[:, 1])


def load_inputs(args):
    source, old_inputs, outcomes, provenance = previous.load_inputs(args)
    audit_path = args.out.parent / "laliga_score_postshot_features.integrity.json"
    audit = json.loads(audit_path.read_text())
    if (
        audit["nativeCasesVerified"] != 38850
        or audit["independentlyRecomputedColumns"] != 24
        or not audit["actualFutureMutation"]["all24columnsExact"]
    ):
        raise ValueError("Independent all24column finishing-feature audit required")
    path = args.cache / "postshot_features.npz"
    with np.load(path) as f:
        if str(f["key"]) != audit["featureKey"] or str(f["source_key"]) != source["key"]:
            raise ValueError("Finishing feature identity differs")
        x, names = f["x"], f["names"].tolist()
    baseline, new = [], []
    for j, name in enumerate(names):
        v = x[:, j]
        if name.endswith("postshot_per_sot"):
            new.append(v)
        elif name.endswith("postshot90"):
            new.append(np.log1p(v))
        else:
            baseline.append(v if name.endswith(("source_minutes_fraction", "paired_preshot_per_sot")) else np.log1p(v))
    baseline = np.column_stack((old_inputs["baseline"], *baseline))
    proposed = np.column_stack((baseline, *new))
    if baseline.shape != (38850, 45) or proposed.shape != (38850, 49):
        raise ValueError("Registered45/49finishing input schema differs")
    provenance = dict(
        previous=provenance,
        postshotFeatureKey=audit["featureKey"],
        featureArtifactSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        postshotAuditSHA=hashlib.sha256(audit_path.read_bytes()).hexdigest(),
        all49inputSHA=hashlib.sha256(proposed.tobytes()).hexdigest(),
    )
    return source, dict(baseline=baseline, postshot=proposed), outcomes, provenance


def implementation_key(args, source, provenance, version):
    return hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + version).encode()
        + Path(__file__).read_bytes()
        + Path(previous.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_postshot_signal.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, inputs, all_y, provenance = load_inputs(args)
    key = implementation_key(args, source, provenance, sklearn.__version__)
    report = dict(
        scope="Earlier goal probability mechanism only, NOT xScore accuracy",
        implementationKey=key,
        sourceKey=source["key"],
        provenance=provenance,
        cohorts={},
        later2026="Not fitted/evaluated",
        evidenceLimit="Historical outcome reuse; provider player/shot matching and48h publication assumptions",
    )
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        result = dict(periods={}, pooled={})
        pooled = {
            (o, a): dict(y=[], baseline=[], postshot=[], weeks=[]) for o in all_y for a in ("logistic", "nonlinear")
        }
        gains = {k: [] for k in pooled}
        for phase, begin, end in PHASES:
            target = np.array([begin <= r["date"] < end for r in rows])
            lock = min(cutoff_for(r["date"]) for r, yes in zip(rows, target, strict=True) if yes)
            fit = np.array([r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
            result["periods"][phase] = dict(
                firstLock=lock.isoformat(), fit=int(fit.sum()), target=int(target.sum()), outcomes={}
            )
            for outcome, labels in all_y.items():
                y = labels[keep]
                result["periods"][phase]["outcomes"][outcome] = {}
                for architecture in ("logistic", "nonlinear"):
                    probabilities, metrics = {}, {}
                    for arm, full_x in inputs.items():
                        model = fitted(full_x[keep], y, fit, target, architecture)
                        path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{outcome}_{architecture}_{arm}.npz"
                        np.savez_compressed(path, key=key, fit=fit, target=target, actual=y[target], **model)
                        probabilities[arm] = model["probability"]
                        metrics[arm] = previous.losses(y[target], model["probability"])
                    gain = dict(
                        logloss=metrics["baseline"]["logloss"] - metrics["postshot"]["logloss"],
                        brier=metrics["baseline"]["brier"] - metrics["postshot"]["brier"],
                    )
                    gains[outcome, architecture].append(gain)
                    result["periods"][phase]["outcomes"][outcome][architecture] = dict(
                        metrics=metrics, improvement=gain
                    )
                    p = pooled[outcome, architecture]
                    p["y"].extend(y[target])
                    p["weeks"].extend(r["week"] for r, yes in zip(rows, target, strict=True) if yes)
                    for arm in inputs:
                        p[arm].extend(probabilities[arm])
                    print(
                        "POSTSHOT_SIGNAL_PERIOD "
                        + json.dumps(
                            dict(
                                cohort=cohort, phase=phase, outcome=outcome, architecture=architecture, improvement=gain
                            )
                        ),
                        flush=True,
                    )
        for (outcome, architecture), p in pooled.items():
            y, old, new = (np.array(p[k]) for k in ("y", "baseline", "postshot"))
            bounds = previous.interval(y, old, new, p["weeks"])
            consistent = all(g["brier"] > 0 and g["logloss"] > 0 for g in gains[outcome, architecture])
            result["pooled"].setdefault(outcome, {})[architecture] = dict(
                baseline=previous.losses(y, old),
                postshot=previous.losses(y, new),
                brierImprovement95=bounds,
                allThreeEarlierPeriodsImprove=consistent,
                passesSignalGate=consistent and bounds[0] > 0,
            )
        result["passesPrimaryGoalGate"] = any(v["passesSignalGate"] for v in result["pooled"]["goal"].values())
        result["disposition"] = (
            "Eligible for separately registered xScore experiment, not proven score gain"
            if result["passesPrimaryGoalGate"]
            else "REJECT/RETIRE postshot-formula grid; neither architecture passed earlier primary goal gate"
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
        print(
            "POSTSHOT_SIGNAL_RESULT "
            + json.dumps(
                dict(cohort=cohort, passed=result["passesPrimaryGoalGate"], disposition=result["disposition"])
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
