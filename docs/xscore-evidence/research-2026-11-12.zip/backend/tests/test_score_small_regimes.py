import numpy as np
import pytest

from app.research.score_small_regimes import (
    branch_mass,
    choose_score,
    compact_inputs,
    error_bank,
    odds_shift,
    split_masks,
)


def test_regime_selection_does_not_average_two_separated_outcomes():
    low = np.zeros((2, 201))
    high = np.zeros((2, 201))
    low[:, 80] = 1
    high[:, 160] = 1
    prediction = choose_score(low, high, np.array([0.4, 0.6]), 1)
    np.testing.assert_array_equal(prediction, [40, 80])


def test_odds_scaling_preserves_zero_one_and_is_identity_at_one():
    probability = np.array([0, 0.2, 0.5, 0.8, 1])
    np.testing.assert_allclose(odds_shift(probability, 1), probability)
    shifted = odds_shift(probability, 2)
    assert shifted[0] == 0 and shifted[-1] == 1
    np.testing.assert_allclose(shifted[1:-1], [1 / 3, 2 / 3, 8 / 9])


def test_truncated_branches_cannot_place_mass_on_the_other_side():
    residuals = np.array([-30, -20, -10, 0, 10, 20, 30], dtype=float)
    centres = np.array([20, 50, 75, 100])
    low = branch_mass(residuals, np.array([45.0]), np.ones(1), centres, 60, False)
    high = branch_mass(residuals, np.array([65.0]), np.ones(1), centres, 60, True)
    np.testing.assert_allclose(low, [[2 / 5, 2 / 5, 0, 0]])
    np.testing.assert_allclose(high, [[0, 0, 1 / 4, 1 / 4]])


def test_physical_zero_and_hundred_keep_clipped_probability():
    residuals = np.array([-20, 0, 20], dtype=float)
    low = branch_mass(residuals, np.array([5.0]), np.ones(1), np.array([0.0]), 60, False)
    high = branch_mass(residuals, np.array([95.0]), np.ones(1), np.array([100.0]), 60, True)
    np.testing.assert_allclose(low, [[2 / 3]])
    np.testing.assert_allclose(high, [[2 / 3]])


def test_exact_regime_boundary_belongs_only_to_high_branch():
    residuals = np.array([0, 10], dtype=float)
    low = branch_mass(residuals, np.array([50.0]), np.ones(1), np.array([53.0]), 60, False)
    high = branch_mass(residuals, np.array([50.0]), np.ones(1), np.array([53.0]), 60, True)
    np.testing.assert_allclose(low, [[1]])
    np.testing.assert_allclose(high, [[1]])


def test_empty_support_rejected_instead_of_dropping_target_cases():
    with pytest.raises(ValueError, match="support"):
        branch_mass(np.array([-1, 0]), np.array([20.0]), np.ones(1), np.array([80.0]), 60, True)


def test_unknown_spread_is_rejected_instead_of_silent_zero_mass():
    with pytest.raises(ValueError, match="support"):
        branch_mass(np.array([-1, 0, 1]), np.array([40.0]), np.array([np.nan]), np.array([40.0]), 60, False)


def test_error_bank_ignores_unselected_future_scores_and_positions():
    parts = np.tile(np.array([[35, 40, 45], [65, 70, 75]]), (4, 1, 1))
    fit = np.array([True, True, False, False])
    a = error_bank(np.array([40, 70, 35, 75]), parts, np.array(["FWD"] * 4), fit, 60)
    b = error_bank(np.array([40, 70, 100, 0]), parts, np.array(["FWD", "FWD", "GK", "MID"]), fit, 60)
    assert a.keys() == b.keys()
    for key in a:
        np.testing.assert_array_equal(a[key], b[key])


def test_split_keeps_all_later_targets_and_embargoes_unavailable_labels():
    rows = [
        {"date": "2025-06-28T20:00:00Z"},
        {"date": "2025-08-01T20:00:00Z"},
        {"date": "2025-10-30T20:00:00Z"},
        {"date": "2025-11-01T20:00:00Z"},
        {"date": "2026-01-03T20:00:00Z"},
        {"date": "2026-10-25T20:00:00Z"},
    ]
    split = split_masks(rows)
    assert split["test"].tolist() == [False, False, False, False, True, True]
    assert split["bank"].tolist() == [False, True, False, False, False, False]
    assert split["select"].tolist() == [False, False, False, True, False, False]
    assert not (split["refit"] & split["test"]).any()


def test_compact_inputs_exclude_target_fields_and_preserve_missing_native_chances():
    names = ["home", "match_lam_h", "match_lam_a", "match_cs_h", "match_cs_a", "start_10_score"]
    base = np.array([[1, 2, 1, 0.3, 0.1, 45], [0, 2, 1, 0.3, 0.1, 40]], dtype=float)
    pn = ["same_3_chance_xg90_mean", "same_3_source_games", "same_3_usage_pass_x_mean", "current_score"]
    player = np.array([[np.nan, 0, np.nan, 100], [0, 3, 70, 10]], dtype=float)
    groups, selected = compact_inputs(base, names, player, pn, "start")
    assert np.isnan(groups["chances"][0, selected["chances"].index("same_3_chance_xg90_mean")])
    assert groups["chances"][1, selected["chances"].index("same_3_chance_xg90_mean")] == 0
    assert all("current_score" not in ns for ns in selected.values())
    idx = selected["form"].index("own_model_goals")
    np.testing.assert_array_equal(groups["form"][:, idx], [2, 1])
    assert "same_3_usage_pass_x_mean" not in selected["chances"]
    assert "same_3_usage_pass_x_mean" in selected["usage"]
