"""Testing only: causal event-rate inputs from counts, native chances and exposure."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_search, score_stats
from app.research.score_search import cutoff_for, moment
from app.research.score_stats import NEGATIVE, POSITIVE

NAMES = (
    "event_mu_history",
    "event_mu_quality",
    "event_mu_negative",
    "event_goal_history90",
    "event_assist_history90",
    "event_other_history90",
    "event_negative_history90",
    "event_goal_quality90",
    "event_assist_quality90",
    "event_expected_minutes",
    "event_fixture_factor",
    "event_history_games",
    "event_history_minutes",
    "event_native_goal_exposure90",
    "event_native_assist_exposure90",
    "event_native_goal_fraction",
    "event_native_assist_fraction",
    "event_fixture_history_goal_mean",
    "event_current_lambda_known",
)
LEVELS = np.array([0, 5, 15, 35, 60, 70, 80, 90, 100])
DAY = 86400


def quality(record, name, row, club):
    if record is None:
        return np.nan
    if (
        record["game"] != row["game"]
        or record["player"] != row["player"]
        or record["date"] != row["date"]
        or record["cohort"] != row["cohort"]
        or record["minutes"] != row["minutes"]
        or record["club"] != club
    ):
        raise ValueError("Native event-quality identity differs")
    value = record["values"].get(name)
    if value is None:
        return np.nan
    if not np.isfinite(value) or value < 0:
        raise ValueError("Invalid known native event quality")
    return float(value)


def build_features(rows, games, names, shot_records, creation_records):
    games = {g["id"]: g for g in games}
    home_index, away_index = names.index("match_lam_h"), names.index("match_lam_a")
    records, identities = [], set()
    audit = {
        "cases": len(rows),
        "scoreLevelReconstructed": 0,
        "canonicalHistoryAgreements": 0,
        "knownOwnLambda": 0,
        "knownNativeGoalRecords": 0,
        "knownNativeAssistRecords": 0,
    }
    for row in rows:
        identity = row["game"], row["player"]
        if identity in identities:
            raise ValueError("Duplicate event-rate case")
        identities.add(identity)
        game = games[row["game"]]
        person = game["players"][row["player"]]
        if (
            game["date"] != row["date"]
            or person.get("pos") != row["pos"]
            or person.get("mins") != row["minutes"]
            or person.get("ver") != 7
            or person.get("started") is not (row["cohort"] == "start")
        ):
            raise ValueError("Event-rate raw case identity differs")
        stats = person.get("stats")
        if not isinstance(stats, dict) or not 0 < row["minutes"] <= 90:
            raise ValueError("Known native event stats and exposure required")

        def count(name, stats=stats):
            value = float(stats.get(name, [0, 0])[0])
            if not np.isfinite(value) or value < 0 or value != int(value):
                raise ValueError("Native event count is not a nonnegative integer")
            return value

        goals, assists = count("goals"), count("goal_assist")
        positive, negative = sum(count(n) for n in POSITIVE), sum(count(n) for n in NEGATIVE)
        net = positive - negative + (row["pos"] == "GK") * count("clean_sheet_60")
        if LEVELS[int(np.clip(net, -3, 5)) + 3] != row["level"]:
            raise ValueError("Event counts fail native decisive-level reconstruction")
        club = person.get("team")
        if club not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Event-rate participant side differs")
        value = row["x"][home_index if club == game["home"]["slug"] else away_index]
        lam = float(value) if value is not None else np.nan
        if np.isfinite(lam) and lam < 0:
            raise ValueError("Negative prematch event lambda")
        goal_quality = quality(shot_records.get(identity), "chance_xg90", row, club)
        assist_quality = quality(creation_records.get(identity), "created_quality90", row, club)
        records.append(
            {
                "available": (moment(row["date"]) + timedelta(hours=48)).timestamp(),
                "player": row["player"],
                "cohort": row["cohort"],
                "position": row["pos"],
                "score": row["score"],
                "minutes": row["minutes"],
                "goals": goals,
                "assists": assists,
                "other": positive - goals - assists,
                "negative": negative,
                "positive": positive,
                "lam": lam,
                "goal_quality": goal_quality,
                "assist_quality": assist_quality,
            }
        )
        audit["scoreLevelReconstructed"] += 1
        audit["knownOwnLambda"] += int(np.isfinite(lam))
        audit["knownNativeGoalRecords"] += int(np.isfinite(goal_quality))
        audit["knownNativeAssistRecords"] += int(np.isfinite(assist_quality))
    ordered = sorted(records, key=lambda r: r["available"])
    history = defaultdict(lambda: deque(maxlen=20))
    pools = defaultdict(lambda: np.zeros(9))
    result = np.full((len(rows), len(NAMES)), np.nan)
    cursor, previous_lock = 0, None
    for i in sorted(range(len(rows)), key=lambda j: cutoff_for(rows[j]["date"])):
        row, own = rows[i], records[i]
        lock = cutoff_for(row["date"]).timestamp()
        if previous_lock is not None:
            factor = np.exp2(-(lock - previous_lock) / (365 * DAY))
            for pool in pools.values():
                pool *= factor
        previous_lock = lock
        while cursor < len(ordered) and ordered[cursor]["available"] < lock:
            old = ordered[cursor]
            weight = np.exp2(-(lock - old["available"]) / (365 * DAY))
            exposure = old["minutes"] / 90
            known_lam = np.isfinite(old["lam"])
            pools[old["cohort"], old["position"]] += weight * np.array(
                [
                    old["goals"],
                    old["assists"],
                    old["other"],
                    old["negative"],
                    exposure,
                    1,
                    old["minutes"],
                    old["lam"] * exposure if known_lam else 0,
                    exposure if known_lam else 0,
                ]
            )
            history[old["player"], old["cohort"]].append(old)
            cursor += 1
        past = list(history[row["player"], row["cohort"]])
        if [r["score"] for r in past] != row["recent"]:
            raise ValueError("Event-rate history differs from canonical prelock history")
        audit["canonicalHistoryAgreements"] += 1
        pool = pools[row["cohort"], row["pos"]]
        rates = (pool[:4] + np.array([0.5, 0.5, 0.05, 0.15])) / (pool[4] + 5)
        pool_minutes = pool[6] / pool[5] if pool[5] else (75 if row["cohort"] == "start" else 20)
        weights = np.array([np.exp2(-(lock - r["available"]) / (365 * DAY)) for r in past])
        exposure = np.array([r["minutes"] / 90 for r in past])
        events = np.array([[r[k] for k in ("goals", "assists", "other", "negative")] for r in past]).reshape(
            len(past), 4
        )
        player_rates = ((events * weights[:, None]).sum(axis=0) + 6 * rates) / ((weights * exposure).sum() + 6)
        recent, recent_weights = past[-10:], weights[-10:]
        recent_exposure = np.array([r["minutes"] / 90 for r in recent])
        minutes = float(
            np.clip(
                (sum(w * r["minutes"] for w, r in zip(recent_weights, recent, strict=True)) + 3 * pool_minutes)
                / (recent_weights.sum() + 3),
                1,
                90,
            )
        )
        native_rates, native_exposures = [], []
        for field, prior in (("goal_quality", player_rates[0]), ("assist_quality", player_rates[1])):
            known = np.array([np.isfinite(r[field]) for r in recent], dtype=bool)
            observed_exposure = float((recent_exposure * recent_weights * known).sum())
            total = sum(
                w * r[field] * r["minutes"] / 90
                for w, r in zip(recent_weights, recent, strict=True)
                if np.isfinite(r[field])
            )
            native_rates.append((total + 5 * prior) / (observed_exposure + 5))
            native_exposures.append(observed_exposure)
        known_lam = np.array([np.isfinite(r["lam"]) for r in past], dtype=bool)
        pool_lam = pool[7] / pool[8] if pool[8] else (own["lam"] if np.isfinite(own["lam"]) else 1.4)
        numerator = sum(
            w * r["lam"] * r["minutes"] / 90 for w, r in zip(weights, past, strict=True) if np.isfinite(r["lam"])
        )
        fixture_mean = (numerator + 3 * pool_lam) / ((weights * exposure * known_lam).sum() + 3)
        current_lam = own["lam"] if np.isfinite(own["lam"]) else fixture_mean
        fixture_ratio = float(np.clip(current_lam / max(fixture_mean, 0.05), 0.25, 4))
        mu_history = minutes / 90 * ((player_rates[0] + player_rates[1]) * fixture_ratio + player_rates[2])
        mu_quality = minutes / 90 * ((sum(native_rates)) * fixture_ratio + player_rates[2])
        native_total_exposure = float((recent_exposure * recent_weights).sum())
        result[i] = [
            mu_history,
            mu_quality,
            minutes / 90 * player_rates[3],
            *player_rates,
            *native_rates,
            minutes,
            fixture_ratio,
            len(past),
            float((exposure * weights).sum() * 90),
            *native_exposures,
            *[e / native_total_exposure if native_total_exposure else 0 for e in native_exposures],
            fixture_mean,
            float(np.isfinite(own["lam"])),
        ]
    if not np.isfinite(result).all() or (result < 0).any():
        raise ValueError("Invalid event intensity or lost forecast case")
    return (
        result,
        {
            "positive": np.array([r["positive"] for r in records]),
            "negative": np.array([r["negative"] for r in records]),
        },
        audit,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "cases",
        "games",
        "player-observations",
        "creation-observations",
        "player-report",
        "creation-report",
        "out",
        "report",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    raw, player_raw, creation_raw = (
        args.games.read_bytes(),
        args.player_observations.read_bytes(),
        args.creation_observations.read_bytes(),
    )
    player, creation = json.loads(gzip.decompress(player_raw)), json.loads(gzip.decompress(creation_raw))
    for native, path in ((player, args.player_report), (creation, args.creation_report)):
        expected = json.loads(path.read_text())
        if expected["sourceKey"] != source["key"] or native["key"] != expected["featureKey"]:
            raise ValueError("Native event-rate observation provenance differs")

    def indexed(native):
        records = {(r["game"], r["player"]): r for r in native["records"]}
        if len(records) != len(native["records"]):
            raise ValueError("Duplicate native event-quality identity")
        return records

    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    values, labels, audit = build_features(
        source["rows"], games, source["features"], indexed(player), indexed(creation)
    )
    files = [
        Path(__file__),
        Path(score_search.__file__),
        Path(score_stats.__file__),
        args.report.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        source["key"].encode() + raw + player_raw + creation_raw + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    np.savez_compressed(args.out, key=key, x=values, names=NAMES, **labels)
    later = {}
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        later[cohort] = {
            "n": int(selected.sum()),
            "pastGoalQuality": int((values[selected, NAMES.index("event_native_goal_exposure90")] > 0).sum()),
            "pastAssistQuality": int((values[selected, NAMES.index("event_native_assist_exposure90")] > 0).sum()),
        }
    receipt = {
        "sourceKey": source["key"],
        "featureKey": key,
        "scope": "Testing-only causal features, no accuracy claim",
        "features": len(NAMES),
        "audit": audit,
        "laterCoverage": later,
    }
    args.report.write_text(json.dumps(receipt, indent=2, allow_nan=False))
    print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
