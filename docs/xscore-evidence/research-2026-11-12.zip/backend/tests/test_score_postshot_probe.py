import pytest

from app.research import score_postshot_probe as post


def shot(q=0.4, xg=0.2, target=True):
    return dict(xgot_fotmob=q, xg_fotmob=xg, onTarget=target, xgot_model=0.99)


def test_null_on_positive_native_target_is_unknown_not_zero_or_model_replacement():
    result = post.qualify([shot(q=None)], 1, True, False)
    assert not result["known"] and result["postshotTotal"] is None
    assert "provider_count_differs_native_sot" in result["reasons"]


def test_native_zero_targets_gives_derived_zero_total_and_undefined_placement_average():
    result = post.qualify([shot(q=None, target=False)], 0, True, False)
    assert result["known"] and result["postshotTotal"] == 0
    assert result["placementPerTarget"] is None and result["postshotPerTarget"] is None
    assert result["zeroOrigin"] == "native_no_sot_derived_zero"


def test_same_provider_pair_placement_only_and_unknown_xg_stays_unknown():
    result = post.qualify([shot(0.4, 0.2), shot(0.6, 0.3)], 2, True, False)
    assert result["known"] and result["postshotTotal"] == 1
    assert result["postshotPerTarget"] == 0.5 and result["placementPerTarget"] == 0.25
    result = post.qualify([shot(0.4, None)], 1, True, False)
    assert result["known"] and result["postshotTotal"] == 0.4 and result["placementPerTarget"] is None


@pytest.mark.parametrize(
    "known,collision,events,reason",
    [
        (False, False, [shot()], "parent_identity_or_stream_unknown"),
        (True, True, [shot()], "same_side_surname_collision"),
        (True, False, [shot(target=False)], "positive_postshot_on_offtarget"),
        (True, False, [shot(q=1.5)], "invalid_provider_quality"),
    ],
)
def test_contradictions_and_uncertain_actor_remain_unknown(known, collision, events, reason):
    result = post.qualify(events, 1, known, collision)
    assert not result["known"] and reason in result["reasons"]
