"""Testing only: direct native score windows learned from shared domestic/European histories."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_density_blend as density
from app.research import score_density_blend_run as reference_runner
from app.research import score_pooled_conditioning as source_groups
from app.research import score_pooled_conditioning_run as shared
from app.research import score_pooled_windows as network
from app.research import score_stability as stability
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def implementation_key(source, feature, reports, plan):
    inherited = shared.implementation_key(source, feature, reports, plan, "no-sklearn-fits:" + np.__version__)
    return hashlib.sha256(
        inherited.encode() + Path(__file__).read_bytes() + Path(network.__file__).read_bytes() + plan.read_bytes()
    ).hexdigest()


def fitted(x, y, queries, cohort, begin, mask, spec, epochs, target_indices, canonical, path, key):
    fit, weights, receipt = network.training_mask(
        queries, cohort, begin, mask["first"], source_groups.GROUPS[spec["group"]]
    )
    if not np.array_equal(fit[canonical], mask["fit"]):
        raise ValueError("Direct-window training changed canonical domestic fit cases")
    if path.exists():
        with np.load(path) as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["fit"], fit)
                or not np.array_equal(f["weights"], weights)
                or not np.array_equal(f["target_indices"], target_indices)
                or json.loads(str(f["receipt"])) != receipt
            ):
                raise ValueError("Direct-window cached source/fit/weight identity differs")
            mass = f["mass"]
            density.validate_mass(mass)
            return mass, json.loads(str(f["statistics"]))
    model = network.WindowNetwork(spec["width"], spec["ridge"], epochs=epochs).fit(x[fit], y[fit], weights[fit])
    mass = model.predict_mass(x[target_indices])
    statistics = {**model.statistics_, **receipt, "targetRows": len(target_indices)}
    np.savez_compressed(
        path,
        key=key,
        mass=mass,
        prediction=network.window_centres(mass, network.CENTRES),
        fit=fit,
        weights=weights,
        target_indices=target_indices,
        receipt=json.dumps(receipt, sort_keys=True),
        statistics=json.dumps(statistics, sort_keys=True),
        history=model.history_,
        normaliser_mean=model.normaliser_.mean_,
        normaliser_scale=model.normaliser_.scale_,
        normaliser_known=model.normaliser_.known_,
        **{f"w{i}": w for i, w in enumerate(model.weights_)},
    )
    return mass, statistics


def fresh(spec):
    return dict(spec=spec, gains=[], errors=[], counts=[], periods={})


def add_metric(record, phase, y, prediction, control, statistics):
    metric = measure(y, prediction)
    gain = metric["within7"] - measure(y, control)["within7"]
    record["gains"].append(gain)
    record["errors"].append(metric["mae"])
    record["counts"].append(len(y))
    record["periods"][phase] = dict(gain=gain, metrics=metric, fitDiagnostics=statistics)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "history-cache", "history-report", "routine-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    feature, x, canonical_all, queries, _, _ = shared.load_shared(args, source)
    corpus = json.loads(gzip.decompress(args.routine_cache.with_suffix(".observations.json.gz").read_bytes()))
    lookup = {(r["game"], r["player"]): r["score"] for r in corpus["records"]}
    shared_y = np.array([lookup[q["game"], q["player"]] for q in queries])
    if not np.isfinite(shared_y).all() or ((shared_y < 0) | (shared_y > 100)).any():
        raise ValueError("Direct-window native known total-score training labels required")
    if not np.array_equal(shared_y[canonical_all], [r["score"] for r in source["rows"]]):
        raise ValueError("Direct-window canonical native score identity differs")
    reports = {n: json.loads((args.out.parent / (n + ".json")).read_text()) for n in shared.REPORTS}
    if any(r["sourceKey"] != source["key"] for r in reports.values()):
        raise ValueError("Direct-window original comparator source differs")
    key = implementation_key(source, feature["featureKey"], reports, args.out.with_suffix(".plan.json"))
    report = dict(
        scope="Testing only, no application changes",
        sourceKey=source["key"],
        implementationKey=key,
        historyFeatureKey=feature["featureKey"],
        featureAuditVerified=True,
        evidenceLimit="Repeated retrospective reuse, exploratory not fresh blind proof",
        cohorts={},
    )
    if args.out.exists():
        old_report = json.loads(args.out.read_text())
        if old_report["implementationKey"] != key:
            raise ValueError("Existing direct-window report has different frozen source/code/plan")
        report = old_report
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        if cohort in report["cohorts"]:
            continue
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        canonical = canonical_all[keep]
        y, positions, weeks = (np.array([r[n] for r in rows]) for n in ("score", "pos", "week"))
        masks = stability.phase_masks(rows)
        references = {}

        def reference(phase, references=references, cohort=cohort, masks=masks, y=y):
            if phase not in references:
                mass, control, _, receipt = reference_runner.reference(args, key, source, cohort, phase, masks, reports)
                expected = (
                    reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                    if phase != "later2026"
                    else reports[
                        "laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"
                    ]["cohorts"][cohort]["later"]
                )
                if measure(y[masks[phase]["target"]], control) != expected:
                    raise ValueError("Direct-window original all-case control did not reproduce")
                references[phase] = mass, control, receipt
            return references[phase]

        def get_mass(phase, model_name, group, epochs, masks=masks, cohort=cohort, canonical=canonical):
            begin = next(b for p, b, _ in stability.PHASES if p == phase)
            mask = masks[phase]
            spec = {**network.PARAMETERS[model_name], "group": group}
            path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}_{model_name}_{epochs}.npz"
            print(f"DIRECT_WINDOW_FIT {cohort} {phase} {group} {model_name} epochs{epochs}", flush=True)
            mass, stats = fitted(
                x, shared_y, queries, cohort, begin, mask, spec, epochs, canonical[mask["target"]], canonical, path, key
            )
            if epochs == 160 and phase != "later2026":
                previous = args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}_{model_name}_80.npz"
                with np.load(previous) as a, np.load(path) as b:
                    if not np.array_equal(a["history"], b["history"][:80]) or any(
                        not np.array_equal(a[n], b[n])
                        for n in ("normaliser_mean", "normaliser_scale", "normaliser_known", "fit", "weights")
                    ):
                        raise ValueError("160-epoch direct-window confirmation lost fixed80 training prefix")
            return mass, stats

        records = [
            fresh(dict(model=n, group=g, weight=w, scope=c))
            for n in network.PARAMETERS
            for g in source_groups.GROUPS
            for w in (0.25, 0.5, 1)
            for c in ("all", "defmid")
        ]
        audit = {}
        for phase, _, _ in stability.PHASES[1:-1]:
            mask = masks[phase]
            target = mask["target"]
            base, control, receipt = reference(phase)
            audit[phase] = dict(control=measure(y[target], control), reference=receipt, models={})
            for name in network.PARAMETERS:
                for group in source_groups.GROUPS:
                    mass, stats = get_mass(phase, name, group, 80)
                    audit[phase]["models"][name + ":" + group] = stats
                    for record in [r for r in records if r["spec"]["model"] == name and r["spec"]["group"] == group]:
                        spec = record["spec"]
                        prediction, _ = density.forecast(
                            base, mass, spec["weight"], control, positions[target], spec["scope"]
                        )
                        add_metric(record, phase, y[target], prediction, control, stats)
                    print(f"DIRECT_WINDOW_SCREEN {cohort} {phase} {group} {name}", flush=True)
        winner80, best80 = stability.choose_stable(records)
        fixed = winner80 or best80
        args.out.with_name(args.out.stem + f".{cohort}.screening.json").write_text(
            json.dumps(
                dict(
                    implementationKey=key,
                    winner80=winner80,
                    best80=best80,
                    fixedConfirmationSpec=fixed["spec"],
                    candidates80=records,
                ),
                indent=2,
            )
        )
        confirmed = fresh(fixed["spec"].copy())
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            spec = fixed["spec"]
            mass, stats = get_mass(phase, spec["model"], spec["group"], 160)
            base, control, _ = reference(phase)
            prediction, _ = density.forecast(base, mass, spec["weight"], control, positions[target], spec["scope"])
            add_metric(confirmed, phase, y[target], prediction, control, stats)
        winner = confirmed if min(confirmed["gains"]) > 0 else None
        frozen = dict(
            implementationKey=key,
            winner=winner,
            finalCandidate=confirmed,
            screenWinner80=winner80,
            screenBest80=best80,
            candidates80=records,
            passingCandidates80=sum(min(r["gains"]) > 0 for r in records),
        )
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
        print("DIRECT_WINDOW_FROZEN " + json.dumps(dict(cohort=cohort, winner=winner, candidate=confirmed)), flush=True)
        phase = "later2026"
        target = masks[phase]["target"]
        spec = fixed["spec"]
        mass, stats = get_mass(phase, spec["model"], spec["group"], 160)
        base, control, _ = reference(phase)
        alternate, _ = density.forecast(base, mass, spec["weight"], control, positions[target], spec["scope"])
        prediction = alternate if winner else control.copy()
        h0, h1 = abs(y[target] - control) <= 7, abs(y[target] - alternate) <= 7
        result = dict(
            selected="candidate" if winner else "control",
            winner=winner,
            candidate=confirmed,
            candidateCount=len(records) + 1,
            earlierPeriods=audit,
            later=measure(y[target], prediction),
            candidateLater=measure(y[target], alternate),
            control=measure(y[target], control),
            candidateGainedCorrect=int((h1 & ~h0).sum()),
            candidateLostCorrect=int((h0 & ~h1).sum()),
            candidateGain95=paired_interval(y[target], alternate, control, weeks[target].tolist()),
            finalFitDiagnostics=stats,
            positions={
                p: dict(
                    candidate=measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    control=measure(y[target][positions[target] == p], control[positions[target] == p]),
                )
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        )
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "DIRECT_WINDOW_RESULT "
            + json.dumps(
                dict(
                    cohort=cohort,
                    selected=result["selected"],
                    later=result["later"],
                    candidateLater=result["candidateLater"],
                )
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
