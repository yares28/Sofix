"""Explicit ordinary/high-score choices, using the foundation's fixed chronological split."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, measure


def choose_branch(chance: np.ndarray, low: np.ndarray, high: np.ndarray, threshold: float) -> np.ndarray:
    return np.where(chance >= threshold, high, low)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--packages", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    data = json.loads(args.cases.read_text(encoding="utf-8"))
    report = {
        "target": "Within seven, explicit ordinary/high outcome; no blending of the two scores",
        "sourceKey": data["key"],
        "split": "Same earlier selection and later January-October retrospective cohort as foundation",
        "evidenceLimit": "Exploratory follow-up; never fresh blind confirmation",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in data["rows"] if r["cohort"] == cohort]
        x = np.asarray([r["x"] for r in rows], dtype=np.float32)
        y = np.array([r["score"] for r in rows])
        dates = np.array([r["date"][:10] for r in rows])
        train, valid, test = (
            dates < "2025-07-01",
            (dates >= "2025-07-01") & (dates < "2026-01-01"),
            dates >= "2026-01-01",
        )
        high = y >= 60
        models = []
        for leaves in (7, 15):
            for quantile in (0.35, 0.5, 0.65):
                outputs = []
                for fit, check in ((train, valid), (~test, test)):
                    classifier = HistGradientBoostingClassifier(
                        max_leaf_nodes=leaves,
                        min_samples_leaf=80,
                        max_iter=120,
                        learning_rate=0.06,
                        l2_regularization=10,
                        early_stopping=False,
                        random_state=20261103,
                    )
                    classifier.fit(x[fit], high[fit])
                    chance = classifier.predict_proba(x[check])[:, 1]
                    branch = []
                    for upper in (False, True):
                        regressor = HistGradientBoostingRegressor(
                            loss="quantile",
                            quantile=quantile,
                            max_leaf_nodes=leaves,
                            min_samples_leaf=40,
                            max_iter=120,
                            learning_rate=0.06,
                            l2_regularization=10,
                            early_stopping=False,
                            random_state=20261103,
                        )
                        subset = fit & (high == upper)
                        regressor.fit(x[subset], y[subset])
                        branch.append(np.clip(regressor.predict(x[check]), 60 if upper else 0, 100 if upper else 60))
                    outputs.append((chance, *branch))
                models.append((leaves, quantile, outputs))
        candidates = []
        best = None
        for i, (leaves, quantile, outputs) in enumerate(models):
            for threshold in np.arange(0.1, 0.951, 0.025):
                prediction = choose_branch(*outputs[0], float(threshold))
                metrics = measure(y[valid], prediction)
                candidate = {
                    "model": i,
                    "leaves": leaves,
                    "quantile": quantile,
                    "threshold": float(threshold),
                    "selection": metrics,
                }
                candidates.append(candidate)
                if best is None or (metrics["within7"], -metrics["mae"]) > (
                    best["selection"]["within7"],
                    -best["selection"]["mae"],
                ):
                    best = candidate
        assert best is not None
        # Selection is complete before evaluating later outcomes.
        outputs = models[best["model"]][2][1]
        prediction = choose_branch(*outputs, best["threshold"])
        actual = y[test]
        later = [r for r, keep in zip(rows, test, strict=True) if keep]
        chosen_high = outputs[0] >= best["threshold"]
        result = {
            "chosen": best,
            "candidateCount": len(candidates),
            "later": measure(actual, prediction),
            "positions": {
                p: measure(
                    actual[np.array([r["pos"] == p for r in later])],
                    prediction[np.array([r["pos"] == p for r in later])],
                )
                for p in POSITIONS
                if any(r["pos"] == p for r in later)
            },
            "weekly95": bootstrap(actual, prediction, [r["week"] for r in later]),
            "actualHighScoreGames": measure(actual[actual >= 60], prediction[actual >= 60]),
            "predictedHigh": int(chosen_high.sum()),
            "actualHigh": int((actual >= 60).sum()),
            "highCalledCorrectly": int((chosen_high & (actual >= 60)).sum()),
            "candidates": candidates,
        }
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, **{k: v for k, v in result.items() if k not in ("candidates", "positions")}}
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
