from datetime import timedelta

import numpy as np

from app.research import score_spatial_context as spatial
from app.research.score_search import moment


def test_signed_mirror_matches_opposite_wing_and_depth():
    points = [[80, 20, 1]]
    correct = spatial.pressure(points, (20, 80), True)
    wrong = spatial.pressure(points, (20, 20), True)
    assert correct[2:] == [1.0, 1.0, 1.0, 1.0]
    assert wrong[2] < 0.02 and wrong[4] < 0.02
    own = spatial.pressure(points, (80, 20), False)
    np.testing.assert_array_equal(correct, own)


def test_missing_stream_is_unknown_but_observed_empty_subset_is_zero():
    assert np.isnan(spatial.pressure(None, (40, 30), True)).all()
    assert spatial.pressure([], (40, 30), True) == [0.0] * 6
    no_lane = spatial.pressure([[50, 40, 1]], None, True)
    assert no_lane[:2] == [1, 1] and np.isnan(no_lane[2:]).all()


def test_strict_availability_history_window_and_native_source_gaps():
    lock = moment("2026-01-02T14:00:00Z")
    observations = [
        dict(date=(lock - timedelta(days=366)).isoformat(), cohort="start", tag="expired"),
        dict(date=(lock - timedelta(days=8)).isoformat(), cohort="start", tag="known"),
        dict(date=(lock - timedelta(days=7)).isoformat(), cohort="bench", tag="other"),
        dict(date=(lock - timedelta(days=6)).isoformat(), cohort="start", tag="missing-source"),
        dict(date=(lock - timedelta(hours=48)).isoformat(), cohort="start", tag="equal"),
    ]
    result = spatial.available(observations, lock, 1, "start")
    assert [r["tag"] for r in result] == ["missing-source"]


def test_lane_uses_past_minutes_and_never_invents_position():
    records = [dict(minutes=90, lane=[20, 80, 0, 0]), dict(minutes=30, lane=[60, 20, 0, 0])]
    np.testing.assert_allclose(spatial.pooled_lane(records)[:2], [30, 65])
    assert spatial.pooled_lane([dict(minutes=90, lane=None)]) is None


def test_fixed_schema_is_220_distinct_columns():
    names = spatial.feature_names()
    assert len(names) == len(set(names)) == 220


def side(game, date, club, points):
    return dict(
        game=game,
        date=date,
        club=club,
        passes=dict(
            known=True,
            passCount=10,
            invalidFlags=0,
            unknownCoordinates=2,
            categories={s: points for s in spatial.STREAMS[1:]},
        ),
        takeons=points,
        summary=dict(known=True, invalidFlags=0),
        countsVerified=True,
    )


def test_partial_or_absent_side_cannot_become_a_quiet_stream():
    record = side("g", "2025-01-01", "A", [])
    assert spatial.stream_points(record, "takeon_start") == []
    record["passes"]["passCount"] = 0
    assert spatial.stream_points(record, "takeon_start") is None
    assert spatial.stream_points(record, "cross_end") is None
    record["passes"]["passCount"] = 10
    record["passes"]["invalidFlags"] = 1
    assert spatial.stream_points(record, "cross_end") is None


def test_feature_workflow_preserves_rows_identity_and_current_future_fact_mutation():
    from copy import deepcopy

    dates = ["2025-12-20T12:00:00Z", "2025-12-28T12:00:00Z", "2026-01-03T12:00:00Z"]
    rows = [dict(game=f"g{i}", player="p", date=d, minutes=90, cohort="start") for i, d in enumerate(dates)]
    games = {
        f"g{i}": dict(id=f"g{i}", date=d, home=dict(slug="A"), away=dict(slug="B"), players=dict(p=dict(team="A")))
        for i, d in enumerate(dates)
    }
    lanes = [dict(game=f"g{i}", player="p", lane=[20, 80, 2, 3]) for i in range(3)]
    sides = [side(f"g{i}", d, "B", [[80, 20, 1]]) for i, d in enumerate(dates)]
    x, names = spatial.build_features(rows, games, lanes, sides)
    assert x.shape == (3, 220)
    assert np.isnan(x[0, names.index("spatial_3_lane_x")])
    assert x[-1, names.index("spatial_3_opponent_takeon_start_near2_attempts")] == 1
    assert x[-1, names.index("spatial_3_opponent_source_games")] == 2
    assert x[-1, names.index("spatial_3_own_source_games")] == 0
    assert np.isnan(x[-1, names.index("spatial_3_own_takeon_start_attempts")])
    assert x[-1, names.index("spatial_3_change_takeon_start_near2_attempts")] == 0
    changed = deepcopy((rows, games, lanes, sides))
    changed[0][-1]["minutes"] = 1e6
    changed[1]["g2"]["players"]["p"]["stats"] = {"goals": [9, 9]}
    changed[2][-1]["lane"] = [99, 1, 0, 0]
    changed[3][-1]["takeons"] = [[20, 80, 0]] * 10
    altered, _ = spatial.build_features(*changed)
    np.testing.assert_array_equal(x, altered)
