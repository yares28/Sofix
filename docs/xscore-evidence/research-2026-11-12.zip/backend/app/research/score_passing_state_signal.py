"""Earlier-only component comparison for state-conditioned passing rates."""

import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from functools import lru_cache

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, fit, metrics

STEM = "laliga_score_passing_state_signal"
AGE = timedelta(days=365)


@lru_cache(maxsize=2000)
def probabilities(own, opponent):
    if not (0 <= own <= 8 and 0 <= opponent <= 8):
        return None
    progress = (np.arange(90) + 0.5) / 90
    shapes = []
    for goals in (own, opponent):
        rate = goals * progress
        mass = np.empty((90, 31))
        mass[:, 0] = np.exp(-rate)
        for n in range(1, 31):
            mass[:, n] = mass[:, n - 1] * rate / n
        shapes.append(mass)
    first, second = shapes
    level = np.sum(first * second, axis=1)
    leading = np.sum(first[:, 1:] * np.cumsum(second, axis=1)[:, :-1], axis=1)
    trailing = np.sum(second[:, 1:] * np.cumsum(first, axis=1)[:, :-1], axis=1)
    output = np.column_stack((trailing, level, leading))
    return output / output.sum(axis=1, keepdims=True)


def mix(history, lock, state_minutes, prior):
    recent = [r for r in history if r[0] >= lock - AGE]
    if not recent:
        return prior, 0.0, 0
    exposure, actions = np.sum([r[1] for r in recent], axis=0)
    baseline = (actions.sum() + 180 * prior) / (exposure.sum() + 180)
    per_state = (actions + 180 * baseline) / (exposure + 180)
    return baseline, float(state_minutes @ (per_state - baseline)), len(recent)


def features(rows, games, histories, names):
    ordered = sorted(
        [(moment(r["date"]) + DELAY, r) for r in histories],
        key=lambda item: (item[0], item[1]["game"], item[1]["player"]),
    )
    result = np.empty((len(rows), 7))
    club_position, player_club = defaultdict(list), defaultdict(list)
    cursor = 0
    locks = [cutoff_for(r["date"]) for r in rows]
    home_rate, away_rate = (names.index(f"match_lam_{side}") for side in ("h", "a"))
    minutes_idx = {r: names.index(f"{r}_10_minutes") for r in ("start", "bench")}
    count_idx = {r: names.index(f"{r}_rate_accurate_pass") for r in ("start", "bench")}
    known = 0
    for i in sorted(range(len(rows)), key=locks.__getitem__):
        row, lock = rows[i], locks[i]
        while cursor < len(ordered) and ordered[cursor][0] < lock:
            available, r = ordered[cursor]
            key = r["club"], r["position"], r["cohort"]
            observation = available - DELAY, np.array([r["exposure"], r["completed"]])
            club_position[key].append(observation)
            player_club[r["player"], *key].append(observation)
            cursor += 1
        fixture = games[row["game"]]
        club = fixture["players"][row["player"]]["team"]
        if row["date"] != fixture["date"] or club not in (fixture["home"]["slug"], fixture["away"]["slug"]):
            raise ValueError("Fixture identity differs")
        role, x = row["cohort"], row["x"]
        home, away = x[home_rate], x[away_rate]
        states = probabilities(home, away) if club == fixture["home"]["slug"] else probabilities(away, home)
        count = int(np.clip(round(x[minutes_idx[role]]), 1, 90))
        state_minutes = np.zeros(3)
        if states is not None:
            state_minutes = (states[:count] if role == "start" else states[-count:]).sum(axis=0)
            known += 1
        key = club, row["pos"], role
        prior = x[count_idx[role]] / 90
        club_mean, club_shift, club_n = mix(club_position[key], lock, state_minutes, prior)
        player_mean, player_shift, player_n = mix(player_club[row["player"], *key], lock, state_minutes, prior)
        result[i] = (
            count * prior,
            count * club_mean,
            count * player_mean,
            np.log1p(club_n),
            np.log1p(player_n),
            club_shift,
            player_shift,
        )
    return result, known


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    history = (ROOT / "laliga_score_passing_state.json").read_bytes()
    receipt = json.loads((REPORTS / "laliga_score_passing_state.source.json").read_bytes())
    assert receipt["nativeSHA"] == NATIVE_SHA and hashlib.sha256(history).hexdigest() == receipt["stateArchiveSHA"]
    extra, rates_known = features(rows, games, json.loads(history), source["features"])
    base_x = np.array([r["x"] for r in rows])
    base, candidate = (np.column_stack((base_x, a)) for a in (extra[:, :-2], extra))
    y_pass = np.array([games[r["game"]]["players"][r["player"]]["stats"].get("accurate_pass", [0])[0] for r in rows])
    y_points = np.array([r["aa"] for r in rows])
    date = np.array([r["date"] for r in rows])
    roles = np.array([r["cohort"] for r in rows])
    ready = np.array([moment(d) + DELAY for d in date])
    locks = np.array([cutoff_for(d) for d in date])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        window = (date >= begin) & (date < end)
        available = ready < locks[window].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, test = available & (roles == role), window & (roles == role)
            aa_base = base_x[:, source["features"].index(f"{role}_10_aa")]
            passing = [
                np.maximum(extra[test, 0] + fit(x, y_pass - extra[:, 0], train, test), 0) for x in (base, candidate)
            ]
            points = [fit(x, y_points - aa_base, train, test) for x in (base, candidate)]
            periods[phase][role] = dict(
                passingMAE=[float(np.mean(abs(y_pass[test] - p))) for p in passing],
                routine=metrics(y_points[test] - aa_base[test], *points),
                nonzeroCandidateInput=int(np.any(extra[test, -2:] != 0, axis=1).sum()),
            )
    gates = {}
    for role in ("start", "bench"):
        values = [periods[p][role] for p in PHASES]
        weights = [r["routine"]["n"] for r in values]
        pass_gains = [r["passingMAE"][0] - r["passingMAE"][1] for r in values]
        aa_gains = [r["routine"]["mae"][0] - r["routine"]["mae"][1] for r in values]
        hits = [r["routine"]["gained"] - r["routine"]["lost"] for r in values]
        pooled_pass, pooled_aa = (float(np.average(v, weights=weights)) for v in (pass_gains, aa_gains))
        preserved = sum(a >= 0 and b >= 0 and c >= 0 for a, b, c in zip(pass_gains, aa_gains, hits, strict=True))
        gates[role] = dict(
            n=sum(weights),
            passingMAEGain=pooled_pass,
            routineMAEGain=pooled_aa,
            routineHitGain=sum(hits),
            phasesWithoutLoss=preserved,
            passEarlier=pooled_pass > 0 and pooled_aa > 0 and sum(hits) > 0 and preserved >= 2,
        )
    result = dict(
        sourceSHA=receipt["stateArchiveSHA"], ratesKnown=rates_known, periods=periods, gate=gates, laterEvaluated=False
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(gates, indent=2))


if __name__ == "__main__":
    main()
