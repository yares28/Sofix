"""Testing only: choose compact score formulas across three earlier season periods."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_small_regimes as small
from app.research import score_stats_hybrid
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_small_rescue import replace_high
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres

PHASES = (
    ("warm2023", "2023-11-01", "2024-01-01"),
    ("spring2024", "2024-01-01", "2024-07-01"),
    ("season2024", "2024-07-01", "2025-07-01"),
    ("autumn2025", "2025-07-01", "2026-01-01"),
    ("later2026", "2026-01-01", "2027-01-01"),
)


def previous_bank_mask(rows, first_date):
    lock = cutoff_for(first_date)
    return np.array([moment(r["date"]) + timedelta(hours=48) < lock for r in rows])


def phase_masks(rows):
    dates = np.array([r["date"] for r in rows])
    result = {}
    for name, begin, end in PHASES:
        target = (dates >= begin) & (dates < end)
        first = min(dates[target]) if target.any() else None
        fit = (dates < begin) & previous_bank_mask(rows, first) if first else np.zeros(len(rows), dtype=bool)
        result[name] = {"target": target, "fit": fit, "first": first}
    return result


def stability_rank(candidate):
    weights = np.array(candidate["counts"])
    return (
        min(candidate["gains"]),
        float(np.average(candidate["gains"], weights=weights)),
        -float(np.average(candidate["errors"], weights=weights)),
    )


def choose_stable(candidates):
    best = max(candidates, key=stability_rank)
    return (best if min(best["gains"]) > 0 else None), best


def specifications():
    records = []
    for group in ("form", "chances", "usage"):
        for cutoff in (50, 60):
            for spread in (0.75, 1, 1.25):
                for gate in small.GATES:
                    for odds in (0.5, 1, 1.5, 2, 3):
                        records.append(
                            {
                                "kind": "full",
                                "group": group,
                                "cutoff": cutoff,
                                "spread": spread,
                                "gate": gate,
                                "odds": odds,
                            }
                        )
                    for threshold in np.arange(0.05, 0.45001, 0.025):
                        records.append(
                            {
                                "kind": "rescue",
                                "group": group,
                                "cutoff": cutoff,
                                "spread": spread,
                                "gate": gate,
                                "threshold": float(threshold),
                            }
                        )
    return [{"spec": s, "gains": [], "errors": [], "counts": [], "periods": {}} for s in records]


def cached_small(args, key, old, cohort, phase, group, cutoff, x, y, masks):
    if phase in ("autumn2025", "later2026"):
        old_split = small.split_masks(args.rows)
        target, fit = ("valid", "train") if phase == "autumn2025" else ("test", "refit")
        if not np.array_equal(masks["target"], old_split[target]) or not np.array_equal(masks["fit"], old_split[fit]):
            raise ValueError("Cached small-model fit/target masks differ")
        ending = "selection" if phase == "autumn2025" else "later"
        path = args.cache / f"laliga_score_small_regimes_{cohort}_{group}_{cutoff}_{ending}.npz"
        with np.load(path) as stored:
            if str(stored["key"]) != old["implementationKey"]:
                raise ValueError("Existing small-model identity differs")
            return stored["parts"], stored["gates"]
    path = args.cache / f"{args.out.stem}_{cohort}_{group}_{cutoff}_{phase}.npz"
    return small.fitted_components(x, y, masks["fit"], masks["target"], cutoff, path, key)


def base_components(args, key, old, phase, x, aa, levels, masks):
    if phase in ("autumn2025", "later2026"):
        ending = "selection" if phase == "autumn2025" else "later"
        expected_fit = np.array(
            [r["date"] < ("2025-07-01" if phase == "autumn2025" else "2026-01-01") for r in args.rows]
        )
        if not np.array_equal(expected_fit, masks["fit"]):
            raise ValueError("Cached conditional model fit mask differs")
        return components(
            args.cache / f"feature_laliga_score_match_context_start_chances_and_intensity_{ending}.npz",
            old["implementationKey"],
        )
    path = args.cache / f"{args.out.stem}_base_{phase}.npz"
    if path.exists():
        return components(path, key)
    classes, probability, parts = score_stats_hybrid.conditional_components(
        x, aa, levels, masks["fit"], masks["target"]
    )
    np.savez_compressed(
        path, key=key, classes=classes, probability=probability, **{f"q{q}": a for q, a in parts.items()}
    )
    return classes, probability, parts


def starter_control(previous, current, previous_rows, first_date):
    classes, _, parts = previous
    bank = empirical.fit_bank(
        classes,
        parts,
        np.array([r["aa"] for r in previous_rows]),
        np.array([r["level"] for r in previous_rows]),
        np.array([r["pos"] for r in previous_rows]),
        previous_bank_mask(previous_rows, first_date),
        "raw",
    )
    classes, probability, parts = current
    return classes, probability, parts, bank


def analogue_control(args, key, source, report, phase, masks):
    from app.research.score_analogues import descriptor_groups, lookup_neighbours, predict_lookup, prepare_lookup

    if report["sourceKey"] != source["key"]:
        raise ValueError("Analogue control source differs")
    spec = report["cohorts"]["bench"]["winner"]
    if phase == "later2026":
        with np.load(args.cache / "analogues_predictions_bench.npz") as stored:
            y = np.array([r["score"] for r, yes in zip(args.rows, masks["target"], strict=True) if yes])
            if str(stored["key"]) != report["implementationKey"] or not np.array_equal(stored["y"], y):
                raise ValueError("Later analogue identity differs")
            return stored["prediction"]
    if phase == "autumn2025":
        path = args.cache / f"analogues_bench_{spec['group']}_selection.npz"
        with np.load(path) as stored:
            if str(stored["key"]) != report["implementationKey"]:
                raise ValueError("Earlier analogue identity differs")
            indices, distance = stored["indices"], stored["distance"]
    else:
        features = descriptor_groups(args.rows, source["features"], "bench")[spec["group"]]
        indices, distance = lookup_neighbours(
            features,
            args.rows,
            masks["target"],
            masks["fit"],
            args.cache / f"{args.out.stem}_analogue_{phase}.npz",
            key,
        )
    prepared = prepare_lookup(args.rows, masks["target"], masks["fit"], indices, distance)
    return predict_lookup(prepared, spec)[0]


def get_prediction(spec, low, high, gates, baseline):
    probability = gates[:, small.GATES.index(spec["gate"])]
    if spec["kind"] == "full":
        return small.choose_score(low, high, probability, spec["odds"])
    high_prediction = window_centres(high, small.CENTRES)
    confidence = probability * high.max(axis=1)
    return replace_high(baseline, high_prediction, confidence, spec["threshold"])[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "stats-cache", "match-cache", "player-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    source = json.loads(args.cases.read_text())
    reports = args.out.parent
    read = lambda name: json.loads((reports / (name + ".json")).read_text())
    old_small, old_match = read("laliga_score_small_regimes"), read("laliga_score_match_context")
    old_starter, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    player_report = read("laliga_score_player_context")
    if any(d["sourceKey"] != source["key"] for d in (old_small, old_match, old_starter, old_bench, player_report)):
        raise ValueError("Reference source differs")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    with np.load(args.match_cache) as stored:
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Match input identity differs")
        full = np.column_stack((base, stored["x"]))
    with np.load(args.player_cache) as stored:
        player, player_names, player_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    if player_key != player_report["featureKey"] or len(base) != len(source["rows"]) or len(player) != len(base):
        raise ValueError("Player input identity differs")
    dependencies = [
        Path(__file__),
        Path(small.__file__),
        Path(empirical.__file__),
        Path(score_stats_hybrid.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    dependencies.extend(
        Path(__file__).with_name(name)
        for name in ("score_small_rescue.py", "score_analogues.py", "score_shared_windows.py", "score_windows.py")
    )
    key = hashlib.sha256(
        (source["key"] + stat_key + player_key + old_match["featureKey"] + old_small["implementationKey"]).encode()
        + b"".join(p.read_bytes() for p in dependencies)
    ).hexdigest()
    report = {
        "scope": "Testing only; no live formula changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective exploratory reuse, not fresh blind evidence",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        pos = np.array([r["pos"] for r in rows])
        masks = phase_masks(rows)
        groups, feature_names = small.compact_inputs(base[keep], names, player[keep], player_names, cohort)
        records, phase_audit = specifications(), {}
        previous_rows, previous_models, previous_base = None, None, None
        last_models = None
        for phase, _, _ in PHASES[:-1]:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            phase_audit[phase] = {
                "fit": int(mask["fit"].sum()),
                "target": len(target_rows),
                "firstLock": cutoff_for(mask["first"]).isoformat(),
            }
            current_base = None
            if cohort == "start":
                current_base = base_components(
                    args,
                    key,
                    old_match,
                    phase,
                    full[keep],
                    np.array([r["aa"] for r in rows]),
                    np.array([r["level"] for r in rows]),
                    mask,
                )
            models = {}
            for group, x in groups.items():
                for cutoff in (50, 60):
                    models[group, cutoff] = cached_small(args, key, old_small, cohort, phase, group, cutoff, x, y, mask)
                    print(f"FITTED {cohort} {phase} {group} {cutoff}", flush=True)
            if previous_rows is not None:
                if cohort == "start":
                    classes, probability, parts, bank = starter_control(
                        previous_base, current_base, previous_rows, mask["first"]
                    )
                    baseline = empirical.empirical_predictions(
                        classes, probability, parts, pos[target], bank, 20, 0.75, 0
                    )
                else:
                    baseline = analogue_control(args, key, source, old_bench, phase, mask)
                phase_audit[phase]["control"] = measure(y[target], baseline)
                bank_fit = previous_bank_mask(previous_rows, mask["first"])
                phase_audit[phase]["bankCasesAvailable"] = int(bank_fit.sum())
                for group in groups:
                    for cutoff in (50, 60):
                        old_parts, _ = previous_models[group, cutoff]
                        parts, gates = models[group, cutoff]
                        bank = small.error_bank(
                            np.array([r["score"] for r in previous_rows]),
                            old_parts,
                            np.array([r["pos"] for r in previous_rows]),
                            bank_fit,
                            cutoff,
                        )
                        for spread in (0.75, 1, 1.25):
                            low, high, fallback = small.conditional_masses(parts, pos[target], bank, cutoff, spread)
                            high_prediction = window_centres(high, small.CENTRES)
                            high_probability = high.max(axis=1)
                            for record in records:
                                spec = record["spec"]
                                if (spec["group"], spec["cutoff"], spec["spread"]) != (group, cutoff, spread):
                                    continue
                                if spec["kind"] == "rescue":
                                    confidence = gates[:, small.GATES.index(spec["gate"])] * high_probability
                                    prediction = replace_high(baseline, high_prediction, confidence, spec["threshold"])[
                                        0
                                    ]
                                else:
                                    prediction = get_prediction(spec, low, high, gates, baseline)
                                metric = measure(y[target], prediction)
                                gain = metric["within7"] - phase_audit[phase]["control"]["within7"]
                                record["gains"].append(gain)
                                record["errors"].append(metric["mae"])
                                record["counts"].append(len(prediction))
                                record["periods"][phase] = {
                                    "gain": gain,
                                    "metrics": metric,
                                    "pooledFallbackCases": fallback,
                                }
                phase_audit[phase]["bestMinimumGainSoFar"] = max(min(r["gains"]) for r in records)
                print("PERIOD " + json.dumps({"cohort": cohort, "phase": phase, **phase_audit[phase]}), flush=True)
            previous_rows, previous_models, previous_base = target_rows, models, current_base
            last_models = models
        if any(len(r["gains"]) != 3 for r in records):
            raise ValueError("Missing earlier selection period")
        winner, best = choose_stable(records)
        passed = sum(min(r["gains"]) > 0 for r in records)
        frozen = {"winner": winner, "bestCandidate": best, "passingCandidates": passed, "candidates": records}
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2, allow_nan=False))
        print(
            "FROZEN "
            + json.dumps({"cohort": cohort, "passingCandidates": passed, "winner": winner, "bestCandidate": best}),
            flush=True,
        )
        mask = masks["later2026"]
        target = mask["target"]
        if cohort == "start":
            current_base = base_components(
                args,
                key,
                old_match,
                "later2026",
                full[keep],
                np.array([r["aa"] for r in rows]),
                np.array([r["level"] for r in rows]),
                mask,
            )
            classes, probability, parts, bank = starter_control(
                previous_base, current_base, previous_rows, mask["first"]
            )
            baseline = empirical.empirical_predictions(classes, probability, parts, pos[target], bank, 20, 0.75, 0)
            control_file, control_report = "laliga_score_match_empirical_density_predictions_start.npz", old_starter
        else:
            baseline = analogue_control(args, key, source, old_bench, "later2026", mask)
            control_file, control_report = "analogues_predictions_bench.npz", old_bench
        with np.load(args.cache / control_file) as stored:
            if (
                str(stored["key"]) != control_report["implementationKey"]
                or not np.array_equal(stored["y"], y[target])
                or not np.allclose(stored["prediction"], baseline, rtol=1e-10, atol=1e-10)
            ):
                raise ValueError("2026 control did not reproduce exactly")
        spec = best["spec"]
        group, cutoff = spec["group"], spec["cutoff"]
        parts, gates = cached_small(args, key, old_small, cohort, "later2026", group, cutoff, groups[group], y, mask)
        bank = small.error_bank(
            np.array([r["score"] for r in previous_rows]),
            last_models[group, cutoff][0],
            np.array([r["pos"] for r in previous_rows]),
            previous_bank_mask(previous_rows, mask["first"]),
            cutoff,
        )
        low, high, fallback = small.conditional_masses(parts, pos[target], bank, cutoff, spec["spread"])
        alternate = get_prediction(spec, low, high, gates, baseline)
        prediction = alternate if winner else baseline.copy()
        weeks = [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
        old_hit, new_hit = np.abs(y[target] - baseline) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "passingCandidates": passed,
            "featureNames": feature_names,
            "earlierPeriods": phase_audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], baseline),
            "candidateGain95": paired_interval(y[target], alternate, baseline, weeks),
            "weekly95": bootstrap(y[target], prediction, weeks),
            "candidateChangedCases": int((alternate != baseline).sum()),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "candidatePositions": {
                p: measure(y[target][pos[target] == p], alternate[pos[target] == p])
                for p in POSITIONS
                if (pos[target] == p).any()
            },
            "pooledFallbackCases": fallback,
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=baseline,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
