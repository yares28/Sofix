"""Test causal changes in ordinary and decisive score histories."""

import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta
from math import lgamma

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_form_change"
AGE = timedelta(days=365)


def normal_evidence(values, centre, noise, prior_games):
    n = len(values)
    total = np.sum(values - centre)
    squared = np.sum((values - centre) ** 2)
    return -0.5 * (np.log1p(n / prior_games) + (squared - total * total / (n + prior_games)) / noise**2)


def binary_evidence(values, centre, prior_games):
    alpha, beta = centre * prior_games, (1 - centre) * prior_games
    good = float(values.sum())
    bad = len(values) - good
    return (
        lgamma(alpha + good)
        + lgamma(beta + bad)
        - lgamma(alpha + beta + len(values))
        - (lgamma(alpha) + lgamma(beta) - lgamma(alpha + beta))
    )


def estimates(values, centre, noise, binary=False):
    prior = 5.0
    average = (values.sum() + prior * centre) / (len(values) + prior)
    candidates = [n for n in (3, 6, 10) if n + 5 <= len(values)]
    if not candidates:
        return average, 0.0, 0.0
    evidence = (
        (lambda x: binary_evidence(x, centre, prior))
        if binary
        else (lambda x: normal_evidence(x, centre, noise, prior))
    )
    scores = [evidence(values) + np.log(0.9)]
    expectations = [average]
    for n in candidates:
        older, recent = values[:-n], values[-n:]
        scores.append(evidence(older) + evidence(recent) + np.log(0.1 / len(candidates)))
        expectations.append((recent.sum() + prior * centre) / (n + prior))
    probabilities = np.exp(np.asarray(scores) - max(scores))
    probabilities /= probabilities.sum()
    return average, float(probabilities @ expectations - average), float(1 - probabilities[0])


def inputs(rows, games, names):
    fixtures = {g["id"]: g for g in games}
    clocks = [cutoff_for(r["date"]) for r in rows]
    ready = [moment(r["date"]) + DELAY for r in rows]
    history = defaultdict(lambda: deque(maxlen=24))
    order = sorted(range(len(rows)), key=ready.__getitem__)
    club = [fixtures[r["game"]]["players"][r["player"]]["team"] for r in rows]
    for c, row in zip(club, rows, strict=True):
        g = fixtures[row["game"]]
        assert c in (g["home"]["slug"], g["away"]["slug"]) and g["date"] == row["date"]
    keys = [(r["player"], c, r["pos"], r["cohort"]) for r, c in zip(rows, club, strict=True)]
    aa_name = {r: names.index(f"{r}_30_aa") for r in ("start", "bench")}
    anchor = np.array([r["x"][aa_name[r["cohort"]]] for r in rows])
    data = np.array([(r["aa"], float(r["level"] >= 60), float(r["level"] < 35)) for r in rows])
    base, candidate = np.empty((len(rows), 4)), np.empty((len(rows), 6))
    cursor = 0
    for i in sorted(range(len(rows)), key=clocks.__getitem__):
        lock = clocks[i]
        while cursor < len(order) and ready[order[cursor]] < lock:
            prev = order[cursor]
            history[keys[prev]].append((ready[prev] - DELAY, data[prev]))
            cursor += 1
        values = np.array([v for t, v in history[keys[i]] if t >= lock - AGE]).reshape(-1, 3)
        role = rows[i]["cohort"]
        noise = 13 if role == "start" else 7
        positive = 0.15 if role == "start" else 0.08
        neutral = (10 if role == "start" else 3, positive, 0.04)
        result = np.array([estimates(values[:, j], centre, noise, binary=j != 0) for j, centre in enumerate(neutral)])
        base[i] = result[0, 0] - anchor[i], result[1, 0], result[2, 0], np.log1p(len(values))
        candidate[i] = result[:, 1:].ravel()
    return base, candidate


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    base, candidate = inputs(rows, games, source["features"])
    native = np.array([r["x"] for r in rows])
    common = np.column_stack((native, base))
    models = {
        "fixed": common,
        "routine": np.column_stack((common, candidate[:, :2])),
        "all": np.column_stack((common, candidate)),
    }
    date = np.array([r["date"] for r in rows])
    cohort = np.array([r["cohort"] for r in rows])
    locks = np.array([cutoff_for(r["date"]) for r in rows])
    ready = np.array([moment(r["date"]) + DELAY for r in rows])
    actual = np.array([r["score"] for r in rows])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        period = (date >= begin) & (date < end)
        available = ready < locks[period].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, test = available & (cohort == role), period & (cohort == role)
            anchor = native[:, source["features"].index(f"{role}_10_score")]
            forecasted = {
                k: np.clip(anchor[test] + forecast(x, actual - anchor, train, test), 0, 100) for k, x in models.items()
            }
            periods[phase][role] = {
                **{k: metrics(actual[test], forecasted["fixed"], forecasted[k]) for k in ("routine", "all")},
                "adaptiveRoutineKnown": int(np.count_nonzero(candidate[test, 1])),
                "routineBreakProbabilityAboveHalf": int(np.sum(candidate[test, 1] > 0.5)),
                "positiveBreakProbabilityAboveHalf": int(np.sum(candidate[test, 3] > 0.5)),
                "negativeBreakProbabilityAboveHalf": int(np.sum(candidate[test, 5] > 0.5)),
            }
    gates = {}
    for role in ("start", "bench"):
        gates[role] = {}
        for k in ("routine", "all"):
            selected = [v[role][k] for v in periods.values()]
            n = sum(r["n"] for r in selected)
            hits = [r["gained"] - r["lost"] for r in selected]
            mae = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in selected) / n
            gates[role][k] = dict(
                n=n,
                phaseHitGains=hits,
                netHits=sum(hits),
                maeGain=mae,
                passEarlier=sum(hits) > 0 and min(hits) >= 0 and mae > 0,
            )
    output = dict(nativeSHA=NATIVE_SHA, sourceKey=source["key"], periods=periods, gate=gates, laterEvaluated=False)
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(gates, indent=2))


if __name__ == "__main__":
    main()
