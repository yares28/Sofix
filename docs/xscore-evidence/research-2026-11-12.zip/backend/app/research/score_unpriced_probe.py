"""Testing only: one keyless public historical read for unpriced event counts."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

QUERY = """
query HistoricalUnpriced($player:String!,$from:ISO8601DateTime!,$to:ISO8601DateTime!){anyPlayer(slug:$player){slug
 ... on Player{allPlayerGameScores(first:5,from:$from,to:$to){nodes{
 anyGame{id date ... on Game{homeTeam{slug} awayTeam{slug}}} anyPlayerGameStats{
 ... on PlayerGameStats{playedInGame minsPlayed anyTeam{slug} duelWon duelLost wonTackle interceptionWon totalScoringAtt}
 }}}}}}
"""
ENDPOINT = "https://api.sorare.com/federation/graphql"
FIELDS = {
    "duel_won": "duelWon",
    "duel_lost": "duelLost",
    "won_tackle": "wonTackle",
    "interception_won": "interceptionWon",
    "total_scoring_att": "totalScoringAtt",
}


def compare(game, result):
    if result.get("id") != game["id"] or result.get("date") != game["date"]:
        raise ValueError("Representative game identity/date differs")
    if any((result.get(side + "Team") or {}).get("slug") != game[side]["slug"] for side in ("home", "away")):
        raise ValueError("Representative playing clubs differ")
    evidence, mismatches = [], 0
    for item in result.get("playerGameScores") or []:
        slug = (item.get("anyPlayer") or {}).get("slug")
        cached = game["players"].get(slug)
        full = item.get("anyPlayerGameStats")
        if cached is None or not isinstance(full, dict) or cached.get("played") is not True:
            continue
        if (full.get("anyTeam") or {}).get("slug") != cached["team"]:
            raise ValueError("Representative player club differs")
        detailed = cached.get("stats") or {}
        values = {old: full.get(new) for old, new in FIELDS.items()}
        for name in ("duel_won", "duel_lost", "interception_won"):
            old = detailed.get(name, [0, 0])[0]
            mismatches += values[name] is not None and values[name] != old
        if cached["pos"] in ("DEF", "MID"):
            old = detailed.get("won_tackle", [0, 0])[0]
            mismatches += values["won_tackle"] is not None and values["won_tackle"] != old
        evidence.append(
            {
                "player": slug,
                "position": cached["pos"],
                "counts": values,
                "cachedTackleFieldPresent": "won_tackle" in detailed,
                "recordedBonus": sum(
                    detailed.get(n, [0, 0])[1] for n in ("double_double", "triple_double", "triple_triple")
                ),
            }
        )
    return {
        "comparedPlayedPlayers": len(evidence),
        "pricedCountMismatches": int(mismatches),
        "positiveForwardTackles": sum(
            e["position"] == "FWD" and e["counts"]["won_tackle"] is not None and e["counts"]["won_tackle"] > 0
            for e in evidence
        ),
        "players": evidence,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("games", "out", "raw"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    chosen = next(g for g in games if g["date"].startswith("2023-10-29") and "ayoze-perez-gutierrez" in g["players"])
    base = {
        "scope": "Testing only; one historical public read, no forecast accuracy claim",
        "query": QUERY,
        "variables": {
            "player": "ayoze-perez-gutierrez",
            "from": chosen["date"][:10] + "T00:00:00Z",
            "to": chosen["date"][:10] + "T23:59:59Z",
        },
        "sourceSha256": hashlib.sha256(raw).hexdigest(),
        "implementationSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "calls": 0,
    }
    if args.prepare_only:
        args.out.write_text(json.dumps({**base, "status": "prepared"}, indent=2))
        print("Prepared one historical unpriced-stat query; no network call", flush=True)
        return
    import httpx

    base["calls"] = 1
    try:
        response = httpx.post(
            ENDPOINT,
            json={"query": QUERY, "variables": base["variables"]},
            headers={"User-Agent": "Sofix historical scoring research (read-only)"},
            timeout=40,
            follow_redirects=False,
        )
    except httpx.HTTPError as exc:
        receipt = {**base, "status": "network_error", "errorType": type(exc).__name__}
    else:
        receipt = {**base, "httpStatus": response.status_code}
        if response.status_code != 200:
            receipt["status"] = "http_error"
        else:
            body = response.json()
            args.raw.write_text(json.dumps(body, indent=2))
            player = (body.get("data") or {}).get("anyPlayer") or {}
            nodes = (player.get("allPlayerGameScores") or {}).get("nodes") or []
            matches = [n for n in nodes if (n.get("anyGame") or {}).get("id") == chosen["id"]]
            found = None
            if player.get("slug") == base["variables"]["player"] and len(matches) == 1:
                found = {
                    **matches[0]["anyGame"],
                    "playerGameScores": [
                        {
                            "anyPlayer": {"slug": player["slug"]},
                            "anyPlayerGameStats": matches[0].get("anyPlayerGameStats"),
                        }
                    ],
                }
            if body.get("errors") or not isinstance(found, dict):
                receipt.update({"status": "graphql_error", "errorCount": len(body.get("errors") or [])})
            else:
                receipt.update({"status": "compared", "comparison": compare(chosen, found)})
    args.out.write_text(json.dumps(receipt, indent=2, allow_nan=False))
    print(json.dumps({k: v for k, v in receipt.items() if k not in ("query", "variables", "comparison")}), flush=True)
    if "comparison" in receipt:
        print(json.dumps(receipt["comparison"]), flush=True)


if __name__ == "__main__":
    main()
