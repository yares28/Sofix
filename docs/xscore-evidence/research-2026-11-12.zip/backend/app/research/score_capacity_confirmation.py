"""Testing only: fixed earlier-selected rejected forest at four times its size."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_modal_capacity as capacity
from app.research import score_modal_capacity_run as parent
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_matchups_run import validate_stat_identity
from app.research.score_search import measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    original = args.out.parent / "laliga_score_modal_capacity.start.frozen.json"
    frozen = json.loads(original.read_text())
    if (
        frozen["best32"]["spec"] != plan["fixedSpec"]
        or frozen["implementationKey"] not in plan["frozenSource"]
        or frozen["winner32"] is not None
    ):
        raise ValueError("Fixed larger-forest confirmation differs from registered earlier selection")
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_bench, old_start = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_analogues",
            "laliga_score_match_empirical_density",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_bench, old_start)
    ):
        raise ValueError("Larger-forest source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, names, stat_key = f["x"], f["names"].tolist(), str(f["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    arrays, feature_keys = {}, []
    for label, file, expected in (
        ("match", "match_context_features.npz", old_match["featureKey"]),
        ("player", "player_context_features.npz", old_player["featureKey"]),
        ("history", "modal_history_features.npz", "761a464fdc15c7f9b11780c227dcf9819de302f65a7964a57298e4fbb023c255"),
    ):
        with np.load(args.cache / file) as f:
            if str(f["key"]) != expected or len(f["x"]) != len(source["rows"]):
                raise ValueError("Larger-forest feature provenance differs")
            arrays[label] = (f["x"], f["names"].tolist())
            feature_keys.append(str(f["key"]))
    key = hashlib.sha256(
        (source["key"] + stat_key + "".join(feature_keys) + frozen["implementationKey"] + np.__version__).encode()
        + original.read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in (capacity, parent, modal, ordinary, stability))
        + Path(__file__).read_bytes()
    ).hexdigest()
    keep = np.array([r["cohort"] == "start" for r in source["rows"]])
    rows = [r for r in source["rows"] if r["cohort"] == "start"]
    args.rows = rows
    y, weeks, positions = (
        np.array([r["score"] for r in rows]),
        np.array([r["week"] for r in rows]),
        np.array([r["pos"] for r in rows]),
    )
    masks = stability.phase_masks(rows)
    numeric, _ = ordinary.ordinary_inputs(
        base[keep],
        names,
        arrays["player"][0][keep],
        arrays["player"][1],
        arrays["match"][0][keep],
        arrays["match"][1],
        "start",
    )
    x = np.column_stack((numeric, arrays["history"][0][keep]))
    if x.shape[1] != 159:
        raise ValueError("Fixed compact input width differs")
    spec = plan["fixedSpec"]
    confirmation = {"spec": spec, "gains": [], "errors": [], "counts": [], "periods": {}}
    for phase, _, _ in stability.PHASES[1:]:
        mask = masks[phase]
        target, fit = mask["target"], mask["fit"]
        if phase == "later2026":
            winner = confirmation if min(confirmation["gains"]) > 0 else None
            args.out.with_name(args.out.stem + ".start.frozen.json").write_text(
                json.dumps({"implementationKey": key, "winner": winner, "finalCandidate": confirmation}, indent=2)
            )
            print("FROZEN " + json.dumps({"winner": winner, "candidate": confirmation}), flush=True)
        cache = args.cache / f"{args.out.stem}_start_{phase}_{key[:12]}.npz"
        if cache.exists():
            with np.load(cache) as f:
                if str(f["key"]) != key:
                    raise ValueError("Larger-forest cache identity differs")
                raw, statistics = f["prediction"], json.loads(str(f["statistics"]))
        else:
            setting = capacity.PARAMETERS[spec["model"]]
            model = capacity.CapacityForest(128, setting["depth"], setting["minLeaf"], setting["features"]).fit(
                x[fit], y[fit], weeks[fit]
            )
            binned = model.binner_.transform(x[target])
            mass = np.zeros((int(target.sum()), len(modal.CENTRES)))
            for i, tree in enumerate(model.trees_):
                mass += tree.predict_binned_mass(binned)
                if i == 31:
                    old_path = (
                        args.cache
                        / f"laliga_score_modal_capacity_start_{phase}_compact_{spec['model']}_t32_{frozen['implementationKey'][:12]}.npz"
                    )
                    with np.load(old_path) as old:
                        if str(old["key"]) != frozen["implementationKey"] or not np.allclose(
                            mass / 32, old["mass"], rtol=0, atol=1e-12
                        ):
                            raise ValueError("Larger forest first32 real members differ from original search")
            raw = window_centres(mass / 128, modal.CENTRES)
            statistics = {
                **model.statistics_,
                "fitRows": int(fit.sum()),
                "targetRows": int(target.sum()),
                "originalFirst32RealMemberMassReproduced": True,
            }
            np.savez_compressed(cache, key=key, prediction=raw, statistics=json.dumps(statistics))
        control = parent.control_for(
            args, key, source, "start", phase, masks, old_match, old_stability, old_ordinary, old_bench
        )
        expected = (
            old_stability["cohorts"]["start"]["earlierPeriods"][phase]["control"]
            if phase != "later2026"
            else old_start["cohorts"]["start"]["later"]
        )
        if measure(y[target], control) != expected:
            raise ValueError("Larger-forest strongest control differs")
        candidate = ordinary.scoped_prediction(raw, control, positions[target], spec["scope"])
        metric = measure(y[target], candidate)
        gain = metric["within7"] - expected["within7"]
        if phase != "later2026":
            confirmation["gains"].append(gain)
            confirmation["errors"].append(metric["mae"])
            confirmation["counts"].append(len(candidate))
            confirmation["periods"][phase] = {"gain": gain, "metrics": metric, "fitDiagnostics": statistics}
        print("CAPACITY_CONFIRM " + json.dumps({"phase": phase, "metrics": metric, "gain": gain}), flush=True)
    prediction = candidate if winner else control.copy()
    old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - candidate) <= 7
    report = {
        "scope": "Testing only, fixed128tree confirmation, no app changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse; no fresh blind proof",
        "cohorts": {
            "start": {
                "selected": "candidate" if winner else "control",
                "winner": winner,
                "candidate": confirmation,
                "later": measure(y[target], prediction),
                "candidateLater": measure(y[target], candidate),
                "control": expected,
                "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
                "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
                "candidateGain95": paired_interval(y[target], candidate, control, weeks[target].tolist()),
                "finalFitDiagnostics": statistics,
            }
        },
    }
    np.savez_compressed(
        args.cache / f"{args.out.stem}_predictions_start.npz",
        key=key,
        y=y[target],
        prediction=prediction,
        alternate=candidate,
        control=control,
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
    print("RESULT " + json.dumps(report["cohorts"]["start"]), flush=True)


if __name__ == "__main__":
    main()
