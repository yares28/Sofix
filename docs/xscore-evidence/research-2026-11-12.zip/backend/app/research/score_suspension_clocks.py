"""Reconstruct conservative source clocks for explicitly dated federation PDFs."""

import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import UTC, date, datetime, time
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from pypdf import PdfReader

ROOT = Path("data/raw/score-foundation/suspension-source")
REPORT = Path("reports/experiments/laliga_score_suspension_clocks.json")
MONTHS = (
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre",
)


def publication_dates(index_rows):
    dates = set()
    for r in index_rows:
        for day, name, year in re.findall(
            r"\bpublicad[oa]s? el (\d{1,2}) de ([a-z]+) del? (20\d{2})\b", r["description"].casefold()
        ):
            dates.add(date(int(year), MONTHS.index(name) + 1, int(day)))
    return sorted(dates)


def review(item, request):
    path = Path(item["file"])
    raw = path.read_bytes()
    if item["status"] != 200 or not raw.startswith(b"%PDF-") or hashlib.sha256(raw).hexdigest() != item["sha256"]:
        raise ValueError("PDF source failed identity validation")
    pdf = PdfReader(path)
    published = publication_dates(request["indexRows"])
    creation, modification = pdf.metadata.creation_date, pdf.metadata.modification_date
    served = [parsedate_to_datetime(v) for v in item.get("modified", [])]
    times = [v for v in [creation, modification, *served] if v is not None]
    if len(published) != 1 or creation is None or not served or any(v.tzinfo is None for v in times):
        clock = None
    else:
        # A dated publication can be used after the end of that local date,
        # provided no observed version timestamp moves it later.
        day_end = datetime.combine(published[0], time.max, tzinfo=ZoneInfo("Europe/Madrid"))
        clock = max(day_end, *times).astimezone(UTC)
    front = pdf.pages[0].extract_text() or ""
    lines = [" ".join(line.split()) for line in front.splitlines() if line.strip()]
    norm = unicodedata.normalize("NFKD", front).encode("ascii", "ignore").decode().casefold()
    if re.search(r"campeonato nacional de (?:liga de )?primera division - liga regular", norm):
        scope = "primera_regular_header"
    elif any(
        "primera division" in unicodedata.normalize("NFKD", line).encode("ascii", "ignore").decode().casefold()
        for line in lines[:4]
    ):
        scope = "primera_mentioned_first_four_lines"
    else:
        scope = "needs_document_scope_read"
    return dict(
        url=item["url"],
        sha256=item["sha256"],
        pages=len(pdf.pages),
        header=lines[:5],
        firstPageScope=scope,
        indexPublishedDates=[d.isoformat() for d in published],
        pdfCreation=creation.isoformat() if creation else None,
        pdfModification=modification.isoformat() if modification else None,
        httpLastModified=[x.isoformat() for x in served],
        conservativeSourceTime=clock.isoformat() if clock is not None else None,
        sourceClockQualified=clock is not None,
        forecastEligibilityChecked=False,
    )


def main():
    requests = ROOT / "rfef_explicit_publication_requests.json"
    manifest = ROOT / "rfef_explicit_publication_manifest.json"
    wanted = {r["url"]: r for r in json.loads(requests.read_text())}
    records = json.loads(manifest.read_text(encoding="utf-8-sig"))
    assert set(wanted) == {r["url"] for r in records} and len(records) == len(wanted) == 26
    result = []
    for item in records:
        if item.get("status") != 200:
            result.append(
                dict(
                    url=item["url"],
                    sourceClockQualified=False,
                    error=item.get("error"),
                    forecastEligibilityChecked=False,
                )
            )
            continue
        result.append(review(item, wanted[item["url"]]))
    summary = dict(
        documents=len(result),
        sourceClockQualified=sum(r["sourceClockQualified"] for r in result),
        noPDFModification=sum(r.get("pdfModification") is None and "error" not in r for r in result),
        scopes=dict(Counter(r.get("firstPageScope", "download_failed") for r in result)),
        completeFixtureLinkedPlayerBans=0,
    )
    out = dict(
        manifestSHA=hashlib.sha256(manifest.read_bytes()).hexdigest(),
        summary=summary,
        limitation="Conservative time for the current archived document, not original capture. Do not use adoption-only rows. "
        "A clock does not prove a player ban or its effective fixture; verify competition, binding outcome, applicable rule and appeals.",
        documents=result,
    )
    REPORT.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
