"""Testing only: conservative native shot-quality credit for past key passes."""

from __future__ import annotations

from collections import Counter

import numpy as np

from app.research.score_prior_chances import words

FIELDS = (
    "created_quality90",
    "created_known_quality90",
    "created_chances90",
    "created_big90",
    "created_link_fraction",
    "created_provider_fraction",
)


def clock(event):
    minute, second = event.get("min"), event.get("sec")
    if type(minute) not in (int, float) or type(second) not in (int, float):
        return np.nan
    return (
        float(minute * 60 + second)
        if np.isfinite([minute, second]).all() and minute >= 0 and 0 <= second < 60
        else np.nan
    )


def eligible_pass(event):
    return event.get("key") is True or event.get("assist") is True


def native_quality(shot):
    values = [shot.get(key) for key in ("xg_fotmob", "xg_understat")]
    valid = [v for v in values if type(v) in (int, float) and np.isfinite(v) and 0 <= v <= 1]
    return float(np.mean(valid)) if valid else np.nan


def link_chances(passes, shots):
    if not isinstance(passes, list) or not isinstance(shots, list):
        return {}, {"missingStreams": 1, "linked": 0}
    times = np.array([clock(p) for p in passes])
    shot_times = np.array([clock(s) for s in shots])
    chances = [i for i, p in enumerate(passes) if eligible_pass(p)]
    audit = Counter({"chancePasses": len(chances)})
    links, used = {}, set()
    for shot_index in np.argsort(np.where(np.isfinite(shot_times), shot_times, np.inf), kind="stable"):
        shot = shots[shot_index]
        at = shot_times[shot_index]
        if (
            not np.isfinite(at)
            or not isinstance(shot.get("player"), str)
            or not words(shot["player"])
            or shot.get("team") not in ("home", "away")
        ):
            audit["invalidShotClockOrPlayer"] += 1
            continue
        candidates = [
            i
            for i in chances
            if i not in used
            and passes[i].get("ok") is True
            and passes[i].get("team") == shot.get("team")
            and isinstance(passes[i].get("recv"), str)
            and words(passes[i]["recv"]) == words(shot["player"])
            and np.isfinite(times[i])
            and 0 <= at - times[i] <= 20
        ]
        if not candidates:
            continue
        latest = max(times[i] for i in candidates)
        best = [i for i in candidates if times[i] == latest]
        if len(best) != 1:
            audit["ambiguousLatestPass"] += 1
            continue
        index = best[0]
        if any(
            p.get("ok") is True and times[i] >= latest and times[i] <= at for i, p in enumerate(passes) if i != index
        ):
            audit["intermediatePass"] += 1
            continue
        if passes[index].get("assist") is True and shot.get("goal") is not True:
            audit["assistGoalConflict"] += 1
            continue
        links[index] = int(shot_index)
        used.add(index)
    audit["linked"] = len(links)
    audit["unlinkedChancePasses"] = len(chances) - len(links)
    return links, dict(audit)


def created_metrics(passes, shots, links, own_indices, minutes):
    unknown = dict.fromkeys(FIELDS, np.nan)
    if (
        not isinstance(passes, list)
        or not isinstance(shots, list)
        or minutes is None
        or not np.isfinite(minutes)
        or minutes <= 0
    ):
        return unknown
    if any(type(passes[i].get(k)) is not bool for i in own_indices for k in ("key", "assist", "ok")):
        return unknown
    chances = [i for i in own_indices if eligible_pass(passes[i])]
    linked = [links[i] for i in chances if i in links]
    qualities = [native_quality(shots[i]) for i in linked]
    known = [v for v in qualities if np.isfinite(v)]
    count = len(chances)
    result = {
        "created_quality90": sum(known) * 90 / minutes if len(known) == count else np.nan,
        "created_known_quality90": sum(known) * 90 / minutes,
        "created_chances90": count * 90 / minutes,
        "created_big90": sum(shots[i]["big"] is True for i in linked) * 90 / minutes
        if len(linked) == count and all(type(shots[i].get("big")) is bool for i in linked)
        else np.nan,
        "created_link_fraction": len(linked) / count if count else 1.0,
        "created_provider_fraction": len(known) / count if count else 1.0,
    }
    return {k: float(v) for k, v in result.items()}
