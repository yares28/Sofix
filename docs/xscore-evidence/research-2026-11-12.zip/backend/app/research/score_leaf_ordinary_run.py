"""Testing only: frozen earlier-season comparison of conditional AA leaf distributions."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_flow as flow
from app.research import score_leaf_ordinary as leaf
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def fitted(x, aa, levels, positions, mask, old, setting, path, key):
    if path.exists():
        with np.load(path) as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["classes"], old[0])
                or not np.array_equal(f["probability"], old[1])
            ):
                raise ValueError("Ordinary leaf cache/event identity differs")
            return {p: f[f"mass{p}"] for p in (20, 100)}, json.loads(str(f["statistics"]))
    masses, stats = leaf.fit_distribution(
        x, aa, levels, positions, mask["fit"], mask["target"], old[0], old[1], leaf.SETTINGS[setting]
    )
    np.savez_compressed(
        path,
        key=key,
        classes=old[0],
        probability=old[1],
        statistics=json.dumps(stats),
        **{f"mass{p}": m for p, m in masses.items()},
    )
    return masses, stats


def study_key(source_key, stat_key, old_match, old_stability, old_ordinary, version, plan_path):
    modules = (leaf, flow, matched, controls, modal, ordinary, stability, windows)
    return hashlib.sha256(
        (
            source_key
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + version
        ).encode()
        + Path(__file__).read_bytes()
        + plan_path.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Ordinary leaf study source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
        matched.validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Ordinary leaf study match features differ")
        all_x = np.column_stack((base, f["x"]))
    if all_x.shape != (len(source["rows"]), 677):
        raise ValueError("Ordinary leaf study feature coverage differs")
    key = study_key(
        source["key"],
        stat_key,
        old_match,
        old_stability,
        old_ordinary,
        sklearn.__version__,
        args.out.with_suffix(".plan.json"),
    )
    report = {
        "scope": "Testing only, full ordinary-point leaf distributions, no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Historical reuse, exploratory not fresh blind evidence",
        "cohorts": {},
    }
    if args.out.exists():
        previous = json.loads(args.out.read_text())
        if previous["implementationKey"] == key:
            report = previous
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        aa, levels, y = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        records = [
            {
                "spec": {"model": model, "prior": prior, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for model in leaf.SETTINGS
            for prior in (20, 100)
            for scope in ("all", "defmid")
        ]
        winner, best, audit = None, None, {}
        for phase, _, _ in stability.PHASES[1:]:
            target = masks[phase]["target"]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "later2026" and best is None:
                raise ValueError("Ordinary leaf choice must freeze before final outcomes")
            active = [best] if phase == "later2026" else records
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Ordinary leaf strongest control differs")
            audit[phase] = {
                "fit": int(masks[phase]["fit"].sum()),
                "target": int(target.sum()),
                "control": expected,
                "models": {},
            }
            for setting in sorted({r["spec"]["model"] for r in active}):
                print(f"LEAF_AA_FITTING {cohort} {phase} {setting}", flush=True)
                masses, stats = fitted(
                    all_x[keep],
                    aa,
                    levels,
                    positions,
                    masks[phase],
                    old,
                    setting,
                    args.cache / f"{args.out.stem}_{cohort}_{phase}_{setting}.npz",
                    key,
                )
                audit[phase]["models"][setting] = stats
                for prior in sorted({r["spec"]["prior"] for r in active if r["spec"]["model"] == setting}):
                    raw = windows.window_centres(masses[prior], modal.CENTRES)
                    for record in [r for r in active if r["spec"]["model"] == setting and r["spec"]["prior"] == prior]:
                        forecast = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                        measured = measure(y[target], forecast)
                        if phase == "later2026":
                            alternate = forecast
                        else:
                            gain = measured["within7"] - expected["within7"]
                            record["gains"].append(gain)
                            record["errors"].append(measured["mae"])
                            record["counts"].append(len(forecast))
                            record["periods"][phase] = {"gain": gain, "metrics": measured}
                    print(f"LEAF_AA_TESTED {cohort} {phase} {setting} prior{prior}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
                    json.dumps(
                        {
                            "implementationKey": key,
                            "winner": winner,
                            "best": best,
                            "candidates": records,
                            "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                        },
                        indent=2,
                    )
                )
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
        prediction = alternate if winner else control.copy()
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "candidate": best,
            "winner": winner,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": expected,
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(
                y[target], alternate, control, [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
            ),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, "selected": result["selected"], "candidateLater": result["candidateLater"]}
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
