"""Testing only: reconstruct action choices, fit normalisers and native full-case results."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_action_network as network
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_search import POSITIONS, measure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    if source["key"] != report["sourceKey"]:
        raise ValueError("Action audit source differs")
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_bench = map(
        read,
        ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary", "laliga_score_analogues"),
    )
    arrays = {}
    for label, file in (
        ("base", "stats.npz"),
        ("match", "match_context_features.npz"),
        ("player", "player_context_features.npz"),
        ("history", "modal_history_features.npz"),
        ("event", "event_intensity_features.npz"),
    ):
        with np.load(args.cache / file) as f:
            arrays[label] = f["x"], f["names"].tolist()
            if label == "event" and str(f["key"]) != report["eventFeatureKey"]:
                raise ValueError("Action audit causal event-feature identity differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, _ = ordinary.ordinary_inputs(
            arrays["base"][0][keep],
            arrays["base"][1],
            arrays["player"][0][keep],
            arrays["player"][1],
            arrays["match"][0][keep],
            arrays["match"][1],
            cohort,
        )
        x = np.column_stack(
            (
                numeric,
                arrays["history"][0][keep],
                arrays["event"][0][keep],
                *[(positions == p).astype(float) for p in POSITIONS],
            )
        )
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        if frozen["implementationKey"] != report["implementationKey"]:
            raise ValueError("Action audit frozen identity differs")
        _, best = stability.choose_stable(frozen["candidates80"])
        if best["spec"] != frozen["finalCandidate"]["spec"]:
            raise ValueError("Action audit earlier fixed choice changed")
        passing = min(frozen["finalCandidate"]["gains"]) > 0
        if passing != bool(frozen["winner"]) or passing != (result["selected"] == "candidate"):
            raise ValueError("Action audit stability gate differs")
        cached, checked = {}, 0
        for path in sorted(args.cache.glob(f"{args.report.stem}_{cohort}_*_e*_{report['implementationKey'][:12]}.npz")):
            phase = next(p[0] for p in stability.PHASES if "_" + p[0] + "_" in path.name)
            mask = masks[phase]
            name = next(n for n in network.PARAMETERS if "_" + n + "_" in path.name)
            epochs = 160 if "_e160_" in path.name else 80
            with np.load(path) as f:
                if str(f["key"]) != report["implementationKey"]:
                    raise ValueError("Action audit fitted cache identity differs")
                normaliser = network.Normaliser().fit(x[mask["fit"]])
                if not all(
                    np.array_equal(getattr(normaliser, attr), f["normaliser_" + attr.rstrip("_")])
                    for attr in ("mean_", "scale_", "known_")
                ):
                    raise ValueError("Action audit normaliser differs from earlier fit data")
                weights = [f[f"w{i}"] for i in range(4)]
                # No target score, minutes, actual event or outcome labels enter this reconstruction.
                mass = network.probabilities(normaliser.transform(x[mask["target"]]), weights)[1]
                raw = network.window_centres(mass, network.CENTRES)
                if not np.allclose(mass, f["mass"], rtol=0, atol=1e-7) or not np.array_equal(raw, f["prediction"]):
                    raise ValueError("Action audit real model choices did not reproduce")
                diagnostics = json.loads(str(f["statistics"]))
                if (
                    diagnostics["epochs"] != epochs
                    or diagnostics["fitRows"] != int(mask["fit"].sum())
                    or diagnostics["targetRows"] != int(mask["target"].sum())
                ):
                    raise ValueError("Action audit fit coverage differs")
                cached[(phase, name, epochs)] = raw
                checked += 1
        if checked != 28:
            raise ValueError("Action audit expected24screen+3confirmation+1final models")
        control_bank = {}
        call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        for phase, _, _ in stability.PHASES[1:]:
            control_bank[phase] = controls.control_for(
                call_args,
                report["implementationKey"],
                source,
                cohort,
                phase,
                masks,
                old_match,
                old_stability,
                old_ordinary,
                old_bench,
            )
        for record in frozen["candidates80"]:
            for phase, _, _ in stability.PHASES[1:-1]:
                target = masks[phase]["target"]
                candidate = ordinary.scoped_prediction(
                    cached[(phase, record["spec"]["model"], 80)],
                    control_bank[phase],
                    positions[target],
                    record["spec"]["scope"],
                )
                if measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                    raise ValueError("Action audit earlier screen metric differs")
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            candidate = ordinary.scoped_prediction(
                cached[(phase, best["spec"]["model"], 160)],
                control_bank[phase],
                positions[target],
                best["spec"]["scope"],
            )
            if measure(y[target], candidate) != frozen["finalCandidate"]["periods"][phase]["metrics"]:
                raise ValueError("Action audit earlier confirmation metric differs")
        phase = "later2026"
        target = masks[phase]["target"]
        candidate = ordinary.scoped_prediction(
            cached[(phase, best["spec"]["model"], 160)], control_bank[phase], positions[target], best["spec"]["scope"]
        )
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != report["implementationKey"]
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], candidate)
                or not np.array_equal(f["control"], control_bank[phase])
            ):
                raise ValueError("Action audit final case/forecast identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Action audit final native metric differs")
            h1, h0 = np.abs(f["alternate"] - y[target]) <= 7, np.abs(f["control"] - y[target]) <= 7
        if int(target.sum()) != {"start": 6754, "bench": 2925}[cohort]:
            raise ValueError("Action audit all-case denominator differs")
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "modelsReproducedWithoutOutcomeInputs": checked,
            "allFitNormalisersReconstructedFromEarlierCases": checked,
            "earlierSelectionAndStabilityGateVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
    output = {
        "scope": "Research-only native metrics, fitted-model and chronology audit, no fresh blind claim",
        "implementationKey": report["implementationKey"],
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
