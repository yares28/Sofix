from datetime import date

import pytest

from app.research.score_market_booklets_pages import market_grid, printed_page_range


def test_actual_quote_page_date_overrides_an_unrelated_stale_cover():
    assert printed_page_range("35 6.2.2026 - 12.2.2026 STAR BET lista br. 7") == (date(2026, 2, 6), date(2026, 2, 12))


def test_conflicting_or_missing_page_dates_cannot_borrow_cover_dates():
    for text in ["GOALSCORER SPAIN LA LIGA", "6.2.2026 - 12.2.2026 30.1.2026 - 5.2.2026"]:
        with pytest.raises(ValueError, match="quote-page"):
            printed_page_range(text)


def test_lower_league_standings_grid_is_not_a_second_player_market():
    price = [
        ["vreme", None, "šifra", "igrač", "tim", "kvota"],
        ["Pe", "21:00", "6642", "Garcia Alvaro", "Rayo Vallecano", "3.00"],
    ]
    standings = [["Spain La Liga", None, "Ukupno"], ["1", "Barcelona", "29"]]
    assert market_grid([price, standings]) == price
    with pytest.raises(ValueError, match="Ambiguous"):
        market_grid([price, price])
