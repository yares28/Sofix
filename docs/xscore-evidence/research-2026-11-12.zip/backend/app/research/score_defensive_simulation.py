"""Testing only: simulate stripped defensive effects around frozen AA forecasts."""

from __future__ import annotations

import numpy as np

from app.research import score_defensive_residuals as defensive
from app.research import score_stability as stability
from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)


def observations(rows, games, feature_names):
    games = {g["id"]: g for g in games}
    gc, full, actual, lam, cs = [], [], [], [], []
    for row in rows:
        game = games[row["game"]]
        person = game["players"][row["player"]]
        if (
            game["date"] != row["date"]
            or person.get("mins") != row["minutes"]
            or person.get("pos") != row["pos"]
            or person.get("ver") != 7
        ):
            raise ValueError("Defensive calibration identity differs")
        stats = person.get("stats")
        if not isinstance(stats, dict):
            raise ValueError("Known native defensive labels required")
        conceded = float(stats.get("goals_conceded", [0, 0])[0])
        clean = float(stats.get("clean_sheet_60", [0, 0])[0])
        team = person.get("team")
        if team not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Defensive side identity differs")
        home = team == game["home"]["slug"]
        full.append(game["awayGoals" if home else "homeGoals"])
        gc.append(conceded)
        lam.append(row["x"][feature_names.index("match_lam_a" if home else "match_lam_h")])
        cs.append(row["x"][feature_names.index("match_cs_h" if home else "match_cs_a")])
        if row["pos"] in ("DEF", "MID"):
            expected = (-4 if row["pos"] == "DEF" else -2) * conceded + (10 * clean if row["pos"] == "DEF" else 0)
            native = sum(float(stats.get(name, [0, 0])[1]) for name in ("goals_conceded", "clean_sheet_60"))
            if abs(expected - native) > 1e-9:
                raise ValueError("Native defensive AA component price differs")
            if row["pos"] == "DEF" and clean != float(row["minutes"] >= 60 and conceded == 0):
                raise ValueError("Native defensive clean flag differs")
            actual.append(expected)
        else:
            actual.append(0)
    return {
        name: np.array(value, dtype=float)
        for name, value in (("conceded", gc), ("full_conceded", full), ("actual", actual), ("lam", lam), ("cs", cs))
    }


def make_bank(previous_rows, parts, context, predicted_minutes, first, curve, spec):
    classes = parts[0]
    pos = np.array([r["pos"] for r in previous_rows])
    levels = np.array([r["level"] for r in previous_rows])
    valid = np.isin(pos, ["DEF", "MID"]) & stability.previous_bank_mask(previous_rows, first)
    known = np.isin(levels, classes)
    valid &= known & np.isfinite(context["lam"]) & np.isfinite(context["cs"]) & np.isfinite(predicted_minutes)
    at = np.flatnonzero(valid)
    if not len(at):
        raise ValueError("No earlier defensive residual pairs; cannot drop forecasts")
    columns = np.searchsorted(classes, levels[at])
    median = np.sort(np.stack([parts[2][q] for q in (0.35, 0.5, 0.65)]), axis=0)[1, at, columns]
    effect = defensive.forecast_effect(
        context["lam"][at], context["cs"][at], predicted_minutes[at], pos[at], curve, spec["goals"], spec["location"]
    )
    residual = np.array([r["aa"] for r in previous_rows])[at] - context["actual"][at] - (median - effect)
    minute_error = np.array([r["minutes"] for r in previous_rows])[at] - predicted_minutes[at]
    pairs = np.column_stack((residual, minute_error))
    if not np.isfinite(pairs).all():
        raise ValueError("Unknown earlier residual/minute pair")
    return {
        "global": pairs,
        "positions": {p: pairs[pos[at] == p] for p in set(pos[at])},
        "levels": {
            (p, float(v)): pairs[(pos[at] == p) & (levels[at] == v)]
            for p, v in set(zip(pos[at], levels[at], strict=True))
        },
        "cases": len(at),
        "unknownLevels": int((~known & np.isin(pos, ["DEF", "MID"])).sum()),
    }


def class_indices(probability, uniform):
    uniform = np.asarray(uniform, dtype=float)
    if uniform.ndim != 1 or not np.isfinite(uniform).all() or ((uniform < 0) | (uniform >= 1)).any():
        raise ValueError("Class sampler requires uniform values in0..1")
    if not np.isfinite(probability).all() or (probability < 0).any() or not np.allclose(probability.sum(axis=1), 1):
        raise ValueError("Valid forecast class probabilities required")
    cumulative = np.cumsum(probability, axis=1)
    cumulative[:, -1] = 1
    return np.array([np.searchsorted(row, uniform, side="right") for row in cumulative])


def draw_pairs(bank, positions, classes, indices, uniform):
    errors = np.zeros(indices.shape)
    minutes = np.zeros(indices.shape)
    for pos in set(positions):
        selected = np.flatnonzero(positions == pos)
        pooled = bank["positions"].get(pos, bank["global"])
        for j, level in enumerate(classes):
            pairs = defensive.paired_draws(
                pooled, bank["levels"].get((pos, float(level)), np.empty((0, 2))), uniform[:, 1], uniform[:, 2]
            )
            take = indices[selected] == j
            errors[selected] = np.where(take, pairs[None, :, 0], errors[selected])
            minutes[selected] = np.where(take, pairs[None, :, 1], minutes[selected])
    return errors, minutes


def simulate(parts, positions, lam, cs, predicted_minutes, control, banks, curves, settings, draws, chunk_size=64):
    from scipy.stats import qmc

    if draws <= 0 or draws & (draws - 1):
        raise ValueError("Draw count must be a power of two")
    classes, probability, quantiles = parts
    if probability.shape != (len(control), len(classes)):
        raise ValueError("Defensive simulation cases differ")
    locations = np.sort(np.stack([quantiles[q] for q in (0.35, 0.5, 0.65)]), axis=0)[1]
    uniform = qmc.Sobol(4, scramble=True, seed=20261104).random_base2(int(np.log2(draws)))
    eligible = np.isin(positions, ["DEF", "MID"]) & np.isfinite(lam) & np.isfinite(cs) & np.isfinite(predicted_minutes)
    at = np.flatnonzero(eligible)
    predictions = {name: control.copy() for name in settings}
    min_minute, max_minute = 90.0, 1.0
    for begin in range(0, len(at), chunk_size):
        batch = at[begin : begin + chunk_size]
        index = class_indices(probability[batch], uniform[:, 0])
        level = classes[index]
        location = locations[batch[:, None], index]
        pairs = {
            identity: draw_pairs(bank, positions[batch], classes, index, uniform) for identity, bank in banks.items()
        }
        reference = next(iter(pairs.values()))[1]
        if any(not np.array_equal(value[1], reference) for value in pairs.values()):
            raise ValueError("Calibration pair order differs across mechanical settings")
        future_minutes = np.clip(predicted_minutes[batch, None] + reference, 1, 90)
        min_minute = min(min_minute, float(future_minutes.min()))
        max_minute = max(max_minute, float(future_minutes.max()))
        goals_cache = {}
        for name, spec in settings.items():
            pair_key = spec["exposure"], spec["goals"], spec["location"]
            curve = curves[spec["exposure"]]
            goal_key = spec["exposure"], spec["goals"]
            if goal_key not in goals_cache:
                goal_draw = defensive.draw_conceded(
                    lam[batch], cs[batch], future_minutes, curve, spec["goals"], uniform[:, 3]
                )
                goals_cache[goal_key] = defensive.point_effect(goal_draw, future_minutes, positions[batch])
            effect = defensive.forecast_effect(
                lam[batch],
                cs[batch],
                predicted_minutes[batch],
                positions[batch],
                curve,
                spec["goals"],
                spec["location"],
            )
            aa = location - effect[:, None] + spec["spread"] * pairs[pair_key][0] + goals_cache[goal_key]
            scores = np.sort(np.clip(np.maximum(np.where(level >= 60, level, 0), level + aa), 0, 100), axis=1)
            mass = np.array(
                [
                    np.searchsorted(row, CENTRES + 7, side="right") - np.searchsorted(row, CENTRES - 7, side="left")
                    for row in scores
                ]
            )
            predictions[name][batch] = window_centres(mass, CENTRES)
        if begin and begin % (chunk_size * 10) == 0:
            print(f"DEFENSIVE_CASES {min(begin + chunk_size, len(at))}/{len(at)} draws{draws}", flush=True)
    if any(not np.isfinite(p).all() or ((p < 0) | (p > 100)).any() for p in predictions.values()):
        raise ValueError("Defensive forecast coverage or bounds differ")
    return predictions, {
        "cases": len(control),
        "simulated": len(at),
        "fallbackMissingFootball": int((np.isin(positions, ["DEF", "MID"]) & ~eligible).sum()),
        "draws": draws,
        "minuteMinimum": min_minute if len(at) else None,
        "minuteMaximum": max_minute if len(at) else None,
    }
