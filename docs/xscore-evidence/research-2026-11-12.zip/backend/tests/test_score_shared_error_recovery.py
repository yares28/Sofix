import numpy as np

from app.research.score_shared_error_recovery import compare, historical_rewards, score_options


def test_history_waits_for_strict_lock_and_counts_a_team_once():
    rows = [
        {"game": "past", "player": "a", "pos": "DEF"},
        {"game": "past", "player": "b", "pos": "DEF"},
        {"game": "same-lock", "player": "a", "pos": "DEF"},
        {"game": "later", "player": "a", "pos": "DEF"},
    ]
    rewards = np.array([[0, 1, 0, 0, 0], [0, 0, 0, 0, 0], [0, -1, 0, 0, 0], [0, 0, 0, 0, 0]])
    available = np.array([48, 48, 100, 101])
    locks = np.array([0, 0, 48, 49])
    sides = [("club", "opp")] * 4
    history = historical_rewards(rows, rewards, available, locks, sides)
    np.testing.assert_array_equal(history[:3], 0)
    np.testing.assert_allclose(history[3, [0, 4, 5, 9, 10, 14]], [0.5 / 11, 1, 0.5 / 11, 1, 1 / 11, 1])
    rewards[2:, 1:] = 1
    np.testing.assert_array_equal(historical_rewards(rows, rewards, available, locks, sides), history)


def test_paired_changes_count_inclusive_seven_and_keep_all_cases():
    actual = np.array([50.0, 50.0, 0.0])
    base = np.array([40.0, 57.0, 0.0])
    options = score_options(base)
    forecast = options[:, 2]
    assert compare(actual, base, forecast, np.ones(3, dtype=bool)) == {
        "n": 3,
        "baseHits": 2,
        "hits": 2,
        "changed": 3,
        "rescued": 1,
        "spoiled": 1,
        "net": 0,
    }
    np.testing.assert_array_equal(options[2], [0, 0, 3, 0, 7])
