"""Testing-only native recorded-SOT repair of the preserved team-history inputs."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np

from app.research import score_match_context as legacy

context_features = legacy.context_features


def native_sot(game):
    result = []
    for side in ("home", "away"):
        members = [
            p for p in game["players"].values() if p.get("played") is True and p.get("team") == game[side]["slug"]
        ]
        known = bool(members) and all(p.get("ver") == 7 and isinstance(p.get("stats"), dict) for p in members)
        total = 0.0
        if known:
            for p in members:
                values = p["stats"].get("ontarget_scoring_att", [0.0, 0.0])
                if (
                    len(values) != 2
                    or not all(type(v) in (int, float) and np.isfinite(v) for v in values)
                    or values[0] < 0
                    or abs(values[1] - 3 * values[0]) > 1e-7
                ):
                    known = False
                    break
                total += values[0]
        result.append(total if known else None)
    return result


def replace_sot(record, counts):
    metrics = record["metrics"].copy()
    own, against = legacy.FIELDS.index("sot_for"), legacy.FIELDS.index("sot_against")
    for i in range(2):
        metrics[i, own] = counts[i] if counts[i] is not None else np.nan
        metrics[i, against] = counts[1 - i] if counts[1 - i] is not None else np.nan
    return {**record, "metrics": metrics}


def corrected_external(external, games, calendar, calendar_rows):
    native = {(legacy.season_year(g["date"]), g["home"]["slug"], g["away"]["slug"]): g for g in games}
    historical = {}
    if len(calendar) != len(calendar_rows) or len(native) != len(games):
        raise ValueError("Unique native/calendar source join required")
    for g, row in zip(calendar, calendar_rows, strict=True):
        if (int(row["FTHG"]), int(row["FTAG"])) != (g["homeGoals"], g["awayGoals"]):
            raise ValueError("Historical CSV fixture score differs")
        values = [float(row[k]) if row.get(k) not in (None, "") else None for k in ("HST", "AST")]
        if any(v is not None and (not np.isfinite(v) or v < 0 or not v.is_integer()) for v in values):
            raise ValueError("Historical SOT counts invalid")
        key = legacy.season_year(g["date"]), g["home"]["slug"], g["away"]["slug"]
        if key in historical:
            raise ValueError("Duplicate historical SOT fixture")
        historical[key] = g, values
    output, provenance = [], []
    for record in external:
        key = legacy.season_year(record["date"]), *record["sides"]
        if key in native:
            game, kind = native[key], "native_sorare"
            counts = native_sot(game)
            if record["date"] != game["date"]:
                raise ValueError("Native source kickoff differs")
            game_id = game["id"]
        elif key in historical:
            game, counts = historical[key]
            kind, game_id = "calendar_csv", None
            if record["date"] != game["date"]:
                raise ValueError("Historical source date differs")
        else:
            raise ValueError("Source SOT has no unique native/historical fixture")
        output.append(replace_sot(record, counts))
        provenance.append(dict(kind=kind, game=game_id, sot=counts))
    return output, provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--calendar", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_native_sot_features.json"))
    args = parser.parse_args()
    native_raw, calendar_raw = args.games.read_bytes(), args.calendar.read_bytes()
    manifest_raw = (args.cache / "match-context/data.txt").read_bytes()
    if (
        hashlib.sha256(native_raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(calendar_raw).hexdigest()
        != "53348112526b5165539df240be350083989bb258f30c0ff7cacbc0165ca7e4b3"
    ):
        raise ValueError("Pinned native/calendar data changed")
    source = json.loads((args.cache / "cases.json").read_text())
    games = [json.loads(line) for line in native_raw.decode().splitlines() if line.strip()]
    calendar = legacy.read_calendar(args.calendar)
    calendar_rows = list(csv.DictReader(calendar_raw.decode("utf-8-sig").splitlines()))
    payload = json.loads(manifest_raw.decode().partition("=")[2].strip().removesuffix(";"))
    old, receipt = legacy.parse_source(payload, games + calendar)
    expected = hashlib.sha256(manifest_raw + Path(legacy.__file__).read_bytes() + native_raw + calendar_raw).hexdigest()
    if expected != "ae7743ec93e4e3c80ec7732f0d80528bb467c515a630a40f9b8745d48020f5d8":
        raise ValueError("Preserved legacy implementation/source key changed")
    old_x, names, metadata = context_features(source["rows"], games, old)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != expected or f["names"].tolist() != names:
            raise ValueError("Original match-context cache key/schema differs")
        np.testing.assert_array_equal(old_x, f["x"])
    original_receipt = json.loads((args.out.parent / "laliga_score_match_context.source-audit.json").read_text())[
        "sourceAudit"
    ]
    if receipt != original_receipt:
        raise ValueError("Preserved original source fixture coverage changed")
    new, origins = corrected_external(old, games, calendar, calendar_rows)
    if (
        len(new) != 1598
        or Counter(r["kind"] for r in origins) != {"native_sorare": 1218, "calendar_csv": 380}
        or any(v is None for r in origins for v in r["sot"])
    ):
        raise ValueError("Registered complete1598fixture SOT source coverage differs")
    key = hashlib.sha256(
        (source["key"] + expected).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    records, changed_sides = [], 0
    for previous, current, origin in zip(old, new, origins, strict=True):
        changed_sides += int((previous["metrics"][:, 8] != current["metrics"][:, 8]).sum())
        as_json = lambda a: [[float(v) if np.isfinite(v) else None for v in row] for row in a]
        records.append(
            dict(
                date=current["date"],
                available=current["available"].isoformat(),
                sides=current["sides"],
                metrics=as_json(current["metrics"]),
                oldMetrics=as_json(previous["metrics"]),
                **origin,
            )
        )
    archive = args.cache / "native_sot_observations.json.gz"
    archive.write_bytes(
        gzip.compress(
            json.dumps(
                dict(key=key, records=records, receipt=receipt), separators=(",", ":"), allow_nan=False
            ).encode(),
            mtime=0,
        )
    )
    x, new_names, new_metadata = context_features(source["rows"], games, new)
    selected = np.array(["_sot_" in name for name in names])
    known_counts = np.array(["_sot_" in name and name.endswith("_count") for name in names])
    if (
        x.shape != (38850, 148)
        or new_names != names
        or new_metadata != metadata
        or selected.sum() != 24
        or known_counts.sum() != 8
    ):
        raise ValueError("Same-population/schema/source coverage contract changed")
    np.testing.assert_array_equal(x[:, ~selected], old_x[:, ~selected])
    np.testing.assert_array_equal(x[:, known_counts], old_x[:, known_counts])
    changed = ~np.isclose(x, old_x, rtol=0, atol=1e-10, equal_nan=True)
    feature_key = hashlib.sha256((key + hashlib.sha256(archive.read_bytes()).hexdigest()).encode()).hexdigest()
    path = args.cache / "native_sot_features.npz"
    np.savez_compressed(
        path,
        key=feature_key,
        source_key=source["key"],
        legacy_key=expected,
        x=x,
        names=names,
        sot=selected,
        known_counts=known_counts,
    )
    output = dict(
        scope="Testing-only nativeSOT input repair, no accuracy/app claim",
        sourceKey=source["key"],
        legacyFeatureKey=expected,
        implementationKey=key,
        featureKey=feature_key,
        observationsSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        featuresSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        metadata=new_metadata,
        fixtures=len(records),
        sourceKinds=dict(Counter(r["kind"] for r in origins)),
        rawSideSOTchanged=changed_sides,
        selectedColumns=int(selected.sum()),
        unchangedOtherColumns=int((~selected).sum()),
        unchangedSOTCountColumns=int(known_counts.sum()),
        changedColumns=int(changed.any(axis=0).sum()),
        changedCells=int(changed.sum()),
        changedRows=int(changed.any(axis=1).sum()),
        status="Independent ALLrawSOT/24laggedcolumns/full38850/futuremutation audit REQUIRED before models",
    )
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print("NATIVE_SOT_REBUILT " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
