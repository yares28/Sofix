"""Testing only: choose between two score forecasts using earlier evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_analogues import descriptor_groups, lookup_neighbours, predict_lookup, prepare_lookup
from app.research.score_europe_run import predict_components
from app.research.score_rolling import LEVELS, fit_parts
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval


def advantage_target(actual, control, alternate):
    return (np.abs(actual - alternate) <= 7).astype(int) - (np.abs(actual - control) <= 7).astype(int)


def choose_forecast(control, alternate, advantage, threshold):
    return np.where(advantage > threshold, alternate, control)


def position_choice(actual, control, alternate, positions):
    def better(mask):
        a, b = measure(actual[mask], alternate[mask]), measure(actual[mask], control[mask])
        return (a["within7"], -a["mae"]) > (b["within7"], -b["mae"])

    overall = better(np.ones(len(actual), dtype=bool))
    return {p: better(positions == p) if (positions == p).sum() >= 100 else overall for p in POSITIONS}


def make_model(leaves, minimum):
    from sklearn.ensemble import HistGradientBoostingRegressor

    return HistGradientBoostingRegressor(
        max_leaf_nodes=leaves,
        min_samples_leaf=minimum,
        max_iter=100,
        learning_rate=0.05,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "analogues", "control", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    analogues = json.loads(args.analogues.read_text(encoding="utf-8"))
    control = json.loads(args.control.read_text(encoding="utf-8"))
    if source["key"] != analogues["sourceKey"] or source["key"] != control["sourceKey"]:
        raise ValueError("Source cases differ")
    with np.load(args.stats_cache) as stored:
        allx = stored["x"]
        stat_key = str(stored["key"])
    key = hashlib.sha256(
        (source["key"] + stat_key + analogues["implementationKey"]).encode() + Path(__file__).read_bytes()
    ).hexdigest()
    report = {
        "target": "Within seven, choose one whole forecast using earlier evidence; all LaLiga cases",
        "evidenceLimit": "Retrospective exploratory reuse; no fresh blind claim",
        "sourceKey": source["key"],
        "implementationKey": key,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y = np.array([r["score"] for r in rows])
        aa = np.array([r["aa"] for r in rows])
        level = np.array([r["level"] for r in rows])
        dates = np.array([r["date"][:10] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        spec = control["cohorts"][cohort]["selection"]["control"]
        base_path = args.cache / f"selector_{cohort}_control_earlier.npz"
        cached = np.load(base_path) if base_path.exists() else None
        if cached is not None and str(cached["key"]) == key:
            earlier_control = cached["prediction"]
            cached.close()
        else:
            if cached is not None:
                cached.close()
            p, ordinary = fit_parts(allx[keep], aa, level, train, valid, spec["quantile"])
            earlier_control = predict_components((LEVELS, p, {spec["quantile"]: ordinary}), spec)
            np.savez_compressed(base_path, key=key, prediction=earlier_control)
        reproduced = measure(y[valid], earlier_control)
        if abs(reproduced["within7"] - spec["selection"]["within7"]) > 1e-12:
            raise ValueError("Earlier control predictions did not reproduce")
        groups = descriptor_groups(rows, source["features"], cohort)
        nn_spec = analogues["cohorts"][cohort]["winner"]
        indices, distance = lookup_neighbours(
            groups[nn_spec["group"]],
            rows,
            valid,
            train,
            args.cache / f"analogues_{cohort}_{nn_spec['group']}_selection.npz",
            analogues["implementationKey"],
        )
        earlier_nn, earlier_confidence = predict_lookup(prepare_lookup(rows, valid, train, indices, distance), nn_spec)
        if abs(measure(y[valid], earlier_nn)["within7"] - nn_spec["selection"]["within7"]) > 1e-12:
            raise ValueError("Earlier analogue predictions did not reproduce")
        with np.load(args.cache / f"analogues_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Analogue later cases differ")
            later_nn, later_confidence = stored["prediction"], stored["confidence"]
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Control later cases differ")
            later_control = stored["control"]
        posflags = np.column_stack([positions == p for p in POSITIONS])

        def inputs(mask, base, alternate, confidence, groups=groups, posflags=posflags):
            return np.column_stack(
                (groups["form_role_match"][mask], posflags[mask], base, alternate, confidence, abs(base - alternate))
            ).astype(np.float32)

        earlier_x = inputs(valid, earlier_control, earlier_nn, earlier_confidence)
        later_x = inputs(test, later_control, later_nn, later_confidence)
        target = advantage_target(y[valid], earlier_control, earlier_nn)
        gate_fit = dates[valid] < "2025-11-01"
        gate_select = ~gate_fit
        candidates = [
            {"kind": "control", "selection": measure(y[valid][gate_select], earlier_control[gate_select])},
            {"kind": "analogues", "selection": measure(y[valid][gate_select], earlier_nn[gate_select])},
        ]
        pos_choice = position_choice(
            y[valid][gate_fit], earlier_control[gate_fit], earlier_nn[gate_fit], positions[valid][gate_fit]
        )
        pos_prediction = np.where(
            np.array([pos_choice[p] for p in positions[valid][gate_select]]),
            earlier_nn[gate_select],
            earlier_control[gate_select],
        )
        candidates.append({"kind": "position", "selection": measure(y[valid][gate_select], pos_prediction)})
        for leaves in (3, 7):
            for minimum in (80, 160):
                model = make_model(leaves, minimum).fit(earlier_x[gate_fit], target[gate_fit])
                advantage = model.predict(earlier_x[gate_select])
                for threshold in (-0.1, -0.05, 0, 0.05, 0.1):
                    prediction = choose_forecast(
                        earlier_control[gate_select], earlier_nn[gate_select], advantage, threshold
                    )
                    candidates.append(
                        {
                            "kind": "learned",
                            "leaves": leaves,
                            "minimumLeaf": minimum,
                            "threshold": threshold,
                            "selection": measure(y[valid][gate_select], prediction),
                        }
                    )
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        if winner["kind"] == "control":
            use_nn = np.zeros(int(test.sum()), dtype=bool)
        elif winner["kind"] == "analogues":
            use_nn = np.ones(int(test.sum()), dtype=bool)
        elif winner["kind"] == "position":
            choices = position_choice(y[valid], earlier_control, earlier_nn, positions[valid])
            use_nn = np.array([choices[p] for p in positions[test]])
        else:
            model = make_model(winner["leaves"], winner["minimumLeaf"]).fit(earlier_x, target)
            use_nn = model.predict(later_x) > winner["threshold"]
        prediction = np.where(use_nn, later_nn, later_control)
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "control": measure(y[test], later_control),
            "analogues": measure(y[test], later_nn),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, later_control, weeks),
            "choseAnalogue": int(use_nn.sum()),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {
                p: measure(y[test][positions[test] == p], prediction[positions[test] == p])
                for p in POSITIONS
                if (positions[test] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"selector_predictions_{cohort}.npz",
            prediction=prediction,
            y=y[test],
            useAnalogue=use_nn,
            key=key,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
