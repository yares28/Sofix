"""Testing only: causal European ordinary-point histories with explicit censoring."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import zipfile
from collections import Counter, defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_search, score_windows
from app.research.score_search import cutoff_for, moment

POSITIONS = {"Forward": "FWD", "Midfielder": "MID", "Defender": "DEF", "Goalkeeper": "GK"}
LEVELS = (0, 5, 15, 35, 60, 70, 80, 90, 100)
FIELDS = (
    "retained_games",
    "last_days",
    "score_mean",
    "score_median",
    "score_mode",
    "score_mode_mass",
    "positive_rate",
    "negative_rate",
    "minutes_mean",
    "aa_exact_games",
    "aa90_mean",
    "aa90_median",
    "aa_upper_rate",
    "aa_lower_rate",
    "aa_unbounded_rate",
)
NAMES = tuple(
    f"euro_{group}_{n}_{field}" for group in ("same_position", "same_cohort") for n in (5, 15) for field in FIELDS
)


def ordinary_bounds(score, level):
    if (
        score is None
        or level is None
        or isinstance(score, bool)
        or isinstance(level, bool)
        or not np.isfinite(score)
        or not np.isfinite(level)
        or not 0 <= score <= 100
        or level not in LEVELS
    ):
        raise ValueError("Known native0to100score and supported decisive level required")
    floor = level if level >= 60 else 0
    if score < floor:
        raise ValueError("Native score below its decisive floor")
    if floor == 100:
        return {"point": None, "lower": None, "upper": None, "kind": "unbounded"}
    if score == floor:
        return {"point": None, "lower": None, "upper": float(floor - level), "kind": "upper"}
    if score == 100:
        return {"point": None, "lower": float(100 - level), "upper": None, "kind": "lower"}
    point = float(score - level)
    return {"point": point, "lower": point, "upper": point, "kind": "exact"}


def observed_cohort(player, stats, formation):
    raw = stats.get("gameStarted")
    if raw not in (None, 0, 1, False, True):
        raise ValueError("Unknown native start flag")
    explicit = None if raw is None else bool(raw)
    xi = {p["slug"] for line in formation.get("startingLineup") or [] for p in line if p.get("slug")}
    bench = {p["slug"] for p in formation.get("bench") or [] if p.get("slug")}
    complete = formation.get("startingLineupAvailable") is True and len(xi) == 11
    if complete and ((explicit is True and player not in xi) or (explicit is False and player in xi)):
        raise ValueError("Native explicit start disagrees with complete historical XI")
    if complete and player in xi:
        return "start"
    if complete and player in bench:
        return "bench"
    return "start" if explicit is True else "bench" if explicit is False else None


def game_records(game, receipt):
    if game.get("statusTyped") != "played":
        receipt["unplayedFixtures"] += 1
        return []
    records = []
    if not game.get("id") or not game.get("date"):
        raise ValueError("Known European fixture identity/date required")
    moment(game["date"])
    sides = {(game.get(side + "Team") or {}).get("slug"): side for side in ("home", "away")}
    for source in game.get("playerGameScores") or []:
        receipt["scoreRecords"] += 1
        stats = source.get("anyPlayerGameStats") or {}
        if (
            source.get("scoringVersion") != 7
            or source.get("scoreStatus") != "FINAL"
            or stats.get("playedInGame") is not True
        ):
            receipt["notFinalV7Played"] += 1
            continue
        player = (source.get("anyPlayer") or {}).get("slug")
        team = (stats.get("anyTeam") or {}).get("slug")
        pos, minutes = POSITIONS.get(source.get("positionTyped")), stats.get("minsPlayed")
        if (
            not player
            or not team
            or team not in sides
            or not pos
            or minutes is None
            or isinstance(minutes, bool)
            or not np.isfinite(minutes)
            or not 1 <= minutes <= 120
        ):
            receipt["unknownIdentityPositionSideOrMinutes"] += 1
            continue
        try:
            bounds = ordinary_bounds(source.get("score"), (source.get("decisiveScore") or {}).get("totalScore"))
            cohort = observed_cohort(player, stats, game.get(sides[team] + "Formation") or {})
        except ValueError as error:
            receipt["invalid:" + str(error)] += 1
            continue
        records.append(
            {
                "game": game["id"],
                "player": player,
                "date": game["date"],
                "club": team,
                "pos": pos,
                "cohort": cohort,
                "minutes": float(minutes),
                "score": float(source["score"]),
                "level": float(source["decisiveScore"]["totalScore"]),
                "ordinary": bounds,
            }
        )
        receipt["accepted"] += 1
        receipt["cohort:" + str(cohort)] += 1
        receipt["AA:" + bounds["kind"]] += 1
        receipt["extraTimeRecords"] += minutes > 90
    return records


def read_archives(paths):
    records, receipts = {}, []
    for path in paths:
        raw = path.read_bytes()
        receipt = Counter()
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            coverage = json.loads(archive.read("coverage.json"))
            if coverage.get("sourceComplete") is not True:
                raise ValueError("European archive source index is incomplete")
            for name in sorted(archive.namelist()):
                if not name.startswith("games/") or not name.endswith(".json"):
                    continue
                game = json.loads(archive.read(name)).get("raw") or {}
                for row in game_records(game, receipt):
                    identity = row["game"], row["player"]
                    if identity in records and records[identity] != row:
                        raise ValueError("Conflicting duplicate European player-game observation")
                    receipt["duplicates"] += identity in records
                    records[identity] = row
        receipts.append({"archive": path.name, "sha256": hashlib.sha256(raw).hexdigest(), "counts": dict(receipt)})
    return sorted(records.values(), key=lambda r: (r["date"], r["game"], r["player"])), receipts


def summarise(history, count, lock):
    recent = history[-count:]
    if not recent:
        return [0, *([np.nan] * 8), 0, *([np.nan] * 5)]
    scores = np.array([r["score"] for r in recent])
    centres = np.arange(0, 100.01, 0.5)
    mass = (np.abs(scores[:, None] - centres) <= 7).mean(axis=0)
    mode = float(score_windows.window_centres(mass[None, :], centres)[0])
    exact = [r["ordinary"]["point"] * 90 / r["minutes"] for r in recent if r["ordinary"]["kind"] == "exact"]
    return [
        len(recent),
        (lock - moment(recent[-1]["date"])).total_seconds() / 86400,
        float(scores.mean()),
        float(np.median(scores)),
        mode,
        float(mass.max()),
        float(np.mean([r["level"] >= 60 for r in recent])),
        float(np.mean([r["level"] < 35 for r in recent])),
        float(np.mean([r["minutes"] for r in recent])),
        len(exact),
        float(np.mean(exact)) if exact else np.nan,
        float(np.median(exact)) if exact else np.nan,
        *[float(np.mean([r["ordinary"]["kind"] == kind for r in recent])) for kind in ("upper", "lower", "unbounded")],
    ]


def build_features(rows, observations):
    queue = sorted(observations, key=lambda r: (moment(r["date"]), r["game"], r["player"]))
    history = defaultdict(deque)
    cursor = 0
    result = np.full((len(rows), len(NAMES)), np.nan)
    for i in sorted(range(len(rows)), key=lambda j: cutoff_for(rows[j]["date"])):
        row = rows[i]
        lock = cutoff_for(row["date"])
        while cursor < len(queue) and moment(queue[cursor]["date"]) + timedelta(hours=48) < lock:
            old = queue[cursor]
            history[old["player"], old["pos"]].append(old)
            cursor += 1
        past = history[row["player"], row["pos"]]
        while past and moment(past[0]["date"]) < lock - timedelta(days=365):
            past.popleft()
        pooled = list(past)
        same = [r for r in past if r["cohort"] == row["cohort"]]
        result[i] = [v for group in (pooled, same) for count in (5, 15) for v in summarise(group, count, lock)]
    if result.shape != (len(rows), 60) or np.isinf(result).any():
        raise ValueError("European ordinary history feature coverage/finite values differ")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "archives", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    plan = json.loads(args.report.with_suffix(".plan.json").read_text())
    paths = [args.archives / f"{name}.zip" for name in ("CL", "EL", "CONF")]
    observations, receipt = read_archives(paths)
    if any(r["sha256"] not in plan["sourceEvidence"] for r in receipt):
        raise ValueError("European ordinary archive differs from registered source evidence")
    feature = build_features(source["rows"], observations)
    files = (
        Path(__file__),
        Path(score_search.__file__),
        Path(score_windows.__file__),
        args.report.with_suffix(".plan.json"),
    )
    key = hashlib.sha256(
        (source["key"] + "".join(r["sha256"] for r in receipt)).encode() + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    np.savez_compressed(args.out, key=key, x=feature, names=NAMES)
    args.out.with_suffix(".observations.json.gz").write_bytes(
        gzip.compress(json.dumps({"key": key, "records": observations, "receipt": receipt}, allow_nan=False).encode())
    )
    later = {}
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        later[cohort] = {
            "n": int(selected.sum()),
            "pastEuropeanScores": int(
                (feature[selected, NAMES.index("euro_same_position_15_retained_games")] > 0).sum()
            ),
            "pastExactOrdinaryPoints": int(
                (feature[selected, NAMES.index("euro_same_position_15_aa_exact_games")] > 0).sum()
            ),
            "pastSameCohortScores": int(
                (feature[selected, NAMES.index("euro_same_cohort_15_retained_games")] > 0).sum()
            ),
        }
    report = {
        "scope": "Research-only source/features, no accuracy claim",
        "sourceKey": source["key"],
        "featureKey": key,
        "cases": len(source["rows"]),
        "features": len(NAMES),
        "observations": len(observations),
        "receipt": receipt,
        "laterCoverage": later,
    }
    args.report.write_text(json.dumps(report, indent=2, allow_nan=False))
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
