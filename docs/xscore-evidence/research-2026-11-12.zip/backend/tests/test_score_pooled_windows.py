"""Testing only: source-weighted native score-window learning has an explicit objective."""

from pathlib import Path

import numpy as np
import pytest

from app.research import score_pooled_windows as windows


def test_pooled_window_targets_keep_exact_zero_cap_and_inclusive_seven():
    y = np.array([0.0, 35.0, 40.0, 80.0, 100.0])
    result = windows.targets(y)
    np.testing.assert_array_equal(result, abs(y[:, None] - windows.CENTRES) <= 7)
    assert result[0, windows.CENTRES == 7][0] == 1
    assert result[0, windows.CENTRES == 7.5][0] == 0
    assert result[-1, windows.CENTRES == 93][0] == 1
    with pytest.raises(ValueError, match="score"):
        windows.targets(np.array([np.nan]))


def test_pooled_window_weighted_gradients_match_finite_differences_and_row_replication():
    rng = np.random.default_rng(4)
    x = rng.normal(size=(3, 2))
    y = windows.targets(np.array([40.0, 80.0, 35.0]))
    weights = [rng.normal(0, 0.2, (2, 2)), rng.normal(0, 0.2, 2), rng.normal(0, 0.2, (2, 201)), rng.normal(0, 0.2, 201)]
    sample = np.array([1.0, 0.25, 0.5])
    loss, gradients = windows.loss_gradient(x, y, weights, sample, 0.001)
    assert np.isfinite(loss)
    for j, w in enumerate(weights):
        for index in np.ndindex(w.shape):
            high = [a.copy() for a in weights]
            low = [a.copy() for a in weights]
            high[j][index] += 1e-5
            low[j][index] -= 1e-5
            expected = (
                windows.loss_gradient(x, y, high, sample, 0.001)[0] - windows.loss_gradient(x, y, low, sample, 0.001)[0]
            ) / 2e-5
            np.testing.assert_allclose(gradients[j][index], expected, atol=1e-9, rtol=1e-4)
    copies = np.repeat(np.arange(3), [4, 1, 2])
    expanded = windows.loss_gradient(x[copies], y[copies], weights, np.ones(len(copies)), 0.001)
    np.testing.assert_allclose(expanded[0], loss, atol=1e-14, rtol=0)
    for a, b in zip(expanded[1], gradients, strict=True):
        np.testing.assert_allclose(a, b, atol=1e-14, rtol=0)


def test_pooled_window_weighted_normalization_keeps_cold_missing_inputs_inert():
    normal = windows.Normaliser().fit(np.array([[0.0, np.nan], [10.0, np.nan]]), np.array([1.0, 0.25]))
    np.testing.assert_allclose(normal.mean_, [2.0, 0.0])
    np.testing.assert_allclose(normal.scale_, [4.0, 1.0])
    result = normal.transform(np.array([[np.nan, 999999.0], [10.0, np.nan]]))
    assert np.isfinite(result).all()
    np.testing.assert_array_equal(result[:, [1, 3]], 0)
    assert result[0, 2] == 1


def test_actual_pooled_window_model_learns_input_specific_peaks(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    x = np.repeat(np.array([[-1.0], [1.0]]), 64, axis=0)
    scores = np.repeat([40.0, 80.0], 64)
    sample = np.tile([1.0, 0.25], 64)
    model = windows.WindowNetwork(width=16, ridge=0.0001, epochs=100, batch=32, seed=15).fit(x, scores, sample)
    forecast = model.predict(np.array([[-1.0], [1.0]]))
    assert abs(forecast[0] - 40) <= 7 and abs(forecast[1] - 80) <= 7
    assert model.statistics_["epochs"] == 100
    assert model.predict_mass(np.array([[-1.0], [1.0]])).shape == (2, 201)


def test_direct_window_source_masks_keep_cold_and_censored_scores_but_exclude_future():
    queries = [
        dict(date=d, cohort=c, source=s)
        for d, c, s in (
            ("2023-12-01T12:00:00Z", "start", "laliga"),
            ("2023-12-01T12:00:00Z", "start", "euro"),
            ("2023-12-31T14:00:00Z", "start", "euro"),
            ("2023-12-01T12:00:00Z", "bench", "euro"),
        )
    ]
    fit, weights, receipt = windows.training_mask(queries, "start", "2024-01-01", "2024-01-02T20:00:00Z", 0.25)
    np.testing.assert_array_equal(fit, [True, True, False, False])
    np.testing.assert_array_equal(weights, [1.0, 0.25, 0.25, 0.25])
    assert receipt["fitLaLiga"] == 1 and receipt["fitEurope"] == 1
    fit, _, _ = windows.training_mask(queries, "start", "2024-01-01", "2024-01-02T20:00:00Z", 0)
    np.testing.assert_array_equal(fit, [True, False, False, False])
