"""Audit only the two completed first-period logistic fits before solver failure."""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_referee_signal as study
from app.research.score_search import cutoff_for, moment


def main():
    root = Path("data/raw/score-foundation")
    reports = Path("reports/experiments")
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    import sklearn
    from sklearn.linear_model import LogisticRegression
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    args = SimpleNamespace(
        cache=root,
        games=Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl"),
        out=reports / "laliga_score_referee_duel_signal.json",
    )
    source, inputs, all_counts, provenance = study.load_inputs(args)
    key = hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + sklearn.__version__).encode()
        + Path(study.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    keep = np.array([r["cohort"] == "start" for r in source["rows"]])
    rows = [r for r in source["rows"] if r["cohort"] == "start"]
    target = np.array(["2024-01-01" <= r["date"] < "2024-07-01" for r in rows])
    lock = min(cutoff_for(r["date"]) for r, yes in zip(rows, target, strict=True) if yes)
    fit = np.array([r["date"] < "2024-01-01" and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
    counts = all_counts[keep]
    blind = counts.copy()
    blind[~fit] = np.nan
    valid = fit & np.isfinite(blind).all(axis=1) & (np.nansum(blind, axis=1) > 0)
    primary = np.array([r["pos"] == "DEF" for r, yes in zip(rows, target, strict=True) if yes])
    losses = {}
    for arm, matrix in inputs.items():
        x = matrix[keep]
        median = np.array([np.median(col[np.isfinite(col)]) if np.isfinite(col).any() else 0 for col in x[valid].T])
        complete = np.where(np.isfinite(x), x, median)
        mean = complete[valid].mean(axis=0)
        scale = complete[valid].std(axis=0)
        scale[scale <= 1e-8] = 1
        z = np.column_stack(((complete - mean) / scale, ~np.isfinite(x[:, :195])))
        xx = np.concatenate([z[valid], z[valid]])
        yy = np.repeat([1.0, 0.0], valid.sum())
        weights = np.concatenate([blind[valid, 0], blind[valid, 1]])
        model = LogisticRegression(C=1, solver="lbfgs", max_iter=2000, tol=1e-8, random_state=20261106).fit(
            xx[weights > 0], yy[weights > 0], sample_weight=weights[weights > 0]
        )
        if model.n_iter_.max() >= 2000:
            raise ValueError("First-period independent logistic refit did not converge")
        p = model.predict_proba(z[target])[:, 1]
        with np.load(root / f"laliga_score_referee_duel_signal_start_spring2024_logistic_{arm}.npz") as old:
            if str(old["key"]) != key:
                raise ValueError("Original completed model key differs")
            for name, value in [
                ("probability", p),
                ("fit", fit),
                ("target", target),
                ("median", median),
                ("mean", mean),
                ("scale", scale),
            ]:
                np.testing.assert_array_equal(old[name], value)
        selected = primary & np.isfinite(counts[target]).all(axis=1) & (np.nansum(counts[target], axis=1) > 0)
        w, lost = counts[target][selected].T
        pp = p[selected]
        n = (w + lost).sum()
        losses[arm] = dict(
            brier=float((w * (1 - pp) ** 2 + lost * pp**2).sum() / n),
            logloss=float(-(w * np.log(pp) + lost * np.log1p(-pp)).sum() / n),
        )
    gains = {k: losses["baseline"][k] - losses["referee"][k] for k in losses["baseline"]}
    if any(v >= 0 for v in gains.values()):
        raise ValueError("Original first-period failure conclusion differs")
    receipt = dict(
        status="COMPLETE audit of two completed first-period logistic fits only; remaining logistic periods/bench untested",
        implementationKey=key,
        actualOutsideFitBlankedRefits=2,
        firstPeriodStarterPrimaryGain=gains,
        all3StarterGateAlreadyFailed=True,
        later2026Fitted=False,
    )
    (reports / "laliga_score_referee_logistic_partial.integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("REFEREE_LOGISTIC_PARTIAL_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
