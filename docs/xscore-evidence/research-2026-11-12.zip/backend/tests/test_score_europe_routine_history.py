"""Testing-only native point prices and full-query causal corrected-history coverage."""

import copy
from collections import Counter

import numpy as np
import pytest

from app.research import score_europe_routine_history as history


def target():
    return dict(
        id="target",
        date="2024-01-06T18:00:00Z",
        home=dict(slug="A"),
        away=dict(slug="B"),
        players=dict(p=dict(team="A")),
    )


def query(cohort="start", pos="DEF"):
    return dict(
        game="target",
        date="2024-01-06T18:00:00Z",
        player="p",
        pos=pos,
        cohort=cohort,
        aa=np.nan,
        score=np.nan,
        level=np.nan,
        minutes=np.nan,
    )


def observation(identity, date, value, cohort="start", source="euro"):
    return dict(
        game=identity,
        date=date,
        player="p",
        pos="DEF",
        club="A",
        source=source,
        cohort=cohort,
        minutes=90,
        routine=dict(point=value, lower=value, upper=value, kind="exact"),
        effect=dict(gcInferredZero=False),
    )


def test_native_ll_point_sheet_is_exact_and_early_prices_do_not_learn_from_later_games():
    p = dict(
        pos="DEF",
        team="A",
        played=True,
        started=True,
        ver=7,
        aa=18,
        score=53,
        level=35,
        mins=90,
        stats=dict(goals_conceded=[2, -8], accurate_pass=[26, 26]),
    )
    g = dict(id="g", date="2023-10-20T14:00:00Z", home=dict(slug="A"), away=dict(slug="B"), players=dict(p=p))
    prices, receipt = {}, Counter()
    record = history.laliga_records(g, receipt, prices)[0]
    assert record["routine"]["point"] == 26
    assert prices["DEF:goals_conceded"] == -4
    later = copy.deepcopy(g)
    later.update(id="later", date="2024-10-20T14:00:00Z")
    untouched = {}
    history.laliga_records(later, Counter(), untouched)
    assert untouched == {}
    broken = copy.deepcopy(g)
    broken["players"]["p"]["aa"] = 19
    with pytest.raises(ValueError, match="reconstruct"):
        history.laliga_records(broken, Counter(), {})


def test_goalkeeper_clean_sheet_ds_is_not_removed_from_native_aa():
    p = dict(
        pos="GK",
        team="A",
        played=True,
        started=True,
        ver=7,
        aa=2,
        score=62,
        level=60,
        mins=90,
        stats=dict(clean_sheet_60=[1, 0], saves=[1, 2]),
    )
    g = dict(id="g", date="2023-10-20T14:00:00Z", home=dict(slug="A"), away=dict(slug="B"), players=dict(p=p))
    r = history.laliga_records(g, Counter(), {})[0]
    assert r["routine"]["point"] == 2
    assert r["effect"]["lower"] == 0


def test_unknown_euro_cohort_is_never_bench_and_cross_source_cold_queries_stay_present():
    records = [
        observation("e", "2023-12-01T14:00:00Z", 5, cohort=None),
        observation("ll", "2023-12-02T14:00:00Z", 8, source="laliga"),
    ]
    x = history.build_features([query("bench"), query("start"), query("start", pos="MID")], records, [target()])
    assert x.shape == (3, 160)
    c = lambda n: history.NAMES.index(n)
    assert x[0, c("routine_euro_same_position_15_observed_games")] == 1
    assert x[0, c("routine_euro_same_cohort_15_observed_games")] == 0
    assert x[0, c("routine_combined_same_position_15_observed_games")] == 2
    assert x[0, c("routine_combined_same_cohort_15_observed_games")] == 0
    assert x[1, c("routine_combined_same_cohort_15_observed_games")] == 1
    assert x[2, c("routine_combined_same_position_15_observed_games")] == 0
    assert np.isnan(x[2, c("routine_combined_same_position_15_routine90_weighted_mean")])


def test_current_and_exact48_future_routine_labels_minutes_gc_and_scores_cannot_affect_inputs():
    records = [
        observation("old", "2023-12-20T14:00:00Z", 0),
        observation("boundary", "2024-01-03T14:00:00Z", 40),
        observation("current", "2024-01-06T18:00:00Z", 80),
    ]
    x = history.build_features([query()], records, [target()])
    changed = copy.deepcopy(records)
    for r in changed[1:]:
        r.update(minutes=-999, score=np.nan, level=np.nan, nativeConceded=999, nativeClean=999)
        r["routine"] = dict(point=np.nan, lower=np.nan, upper=np.nan, kind="exact")
    repeated = history.build_features([query()], changed, [target()])
    np.testing.assert_array_equal(x, repeated)
    field = history.NAMES.index("routine_euro_same_position_15_routine90_weighted_mean")
    assert x[0, field] == 0
