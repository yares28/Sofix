from datetime import UTC, date, datetime

import pytest

from app.research import score_market_booklets as market


def test_printed_table_separates_player_club_price_and_never_reads_season_scorer():
    table = [
        ["vreme", None, "šifra", "igrač", "tim", "kvota"],
        ["Ut", "21:30", "6760", "Bellingham J.", "Real Madrid", "2.10"],
    ]
    result = market.table_rows(table)
    assert result == [
        dict(weekday="Ut", time="21:30", code="6760", player="Bellingham J.", club="Real Madrid", decimalOdds="2.10")
    ]
    with pytest.raises(ValueError, match="header"):
        market.table_rows([["season", "top scorer"], ["2024", "Bellingham"]])


def test_invalid_quote_or_ambiguous_cell_layout_is_not_silently_repaired():
    header = ["vreme", None, "šifra", "igrač", "tim", "kvota"]
    with pytest.raises(ValueError, match="price"):
        market.table_rows([header, ["Ut", "21:30", "6760", "Bellingham J.", "Real Madrid", "0"]])
    with pytest.raises(ValueError, match="columns"):
        market.table_rows([header, ["Ut 21:30", "6760", "Real Madrid", "2.10"]])


def test_unique_weekday_in_cover_range_and_dst_use_named_timezone():
    assert market.kickoff("Pe", "21:30", date(2024, 10, 25), date(2024, 10, 28)) == datetime(
        2024, 10, 25, 19, 30, tzinfo=UTC
    )
    assert market.kickoff("Ne", "21:30", date(2024, 10, 25), date(2024, 10, 28)) == datetime(
        2024, 10, 27, 20, 30, tzinfo=UTC
    )
    with pytest.raises(ValueError, match="unique"):
        market.kickoff("Pe", "21:30", date(2024, 10, 25), date(2024, 11, 1))


def test_creation_is_not_enough_when_actual_modification_is_after_lock():
    created = datetime(2024, 5, 13, 13, 21, tzinfo=UTC)
    modified = datetime(2024, 5, 14, 15, 0, tzinfo=UTC)
    received_modified = datetime(2024, 5, 14, 6, 30, tzinfo=UTC)
    assert market.available_at(created, modified, received_modified) == modified
    assert not market.before_lock(modified, datetime(2024, 5, 14, 19, 30, tzinfo=UTC))
    assert market.before_lock(received_modified, datetime(2024, 5, 14, 19, 30, tzinfo=UTC))


def test_missing_timezone_or_timestamp_never_becomes_known_prelock():
    with pytest.raises(ValueError, match="timezone"):
        market.available_at(datetime(2024, 5, 13), datetime(2024, 5, 13, tzinfo=UTC), datetime(2024, 5, 13, tzinfo=UTC))
    with pytest.raises(ValueError, match="timestamps"):
        market.available_at(None, datetime(2024, 5, 13, tzinfo=UTC), datetime(2024, 5, 13, tzinfo=UTC))
