"""Qualify historical substitution clocks and score state at decisions."""

import hashlib
import json
import subprocess
from collections import Counter, defaultdict

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_flow import verified_flow
from app.research.score_match_context import CLUBS, normalise, season_year
from app.research.score_player_context import COMMIT, link_names, words

STEM = "laliga_score_substitution_clock"
REPO = ROOT / "player-context-source"


def decision_state(events, side, minute):
    if any(t == minute for t, _ in events):
        return None
    return sum(1 if team == side else -1 for t, team in events if t < minute)


def paired_clocks(unit, final_minute):
    starts, subs = unit.get("starters"), unit.get("subs")
    if not isinstance(starts, list) or not isinstance(subs, list) or len(starts) != 11:
        return None, "incomplete_lineup"
    if any(p.get("rc") not in (0, None) for p in starts + subs):
        return None, "dismissal_present"
    if any(p.get("on") is not None for p in starts):
        return None, "starter_on_clock"
    active_subs = [p for p in subs if type(p.get("mins")) is int and p["mins"] > 0]
    if any((p.get("on") is not None) != (p in active_subs) for p in subs):
        return None, "inconsistent_sub_appearance"
    used = starts + active_subs
    entries = [p["on"] for p in active_subs]
    exits = [p["off"] for p in used if p.get("off") is not None]
    if any(type(t) is not int or t <= 0 or t > final_minute for t in entries + exits):
        return None, "invalid_clock"
    if Counter(entries) != Counter(exits):
        return None, "unpaired_clock"
    if any(p["off"] <= p["on"] for p in active_subs if p.get("off") is not None):
        return None, "invalid_interval"
    return (starts, active_subs), "paired"


def historical_players(g, club, clocks, events, side, aliases, audit):
    players = {slug: p for slug, p in g["players"].items() if p.get("played") and p["team"] == club}
    starts, subs = clocks
    links, _ = link_names([p["name"] for p in starts + subs], players, aliases)
    linked = []
    for started, group in ((True, starts), (False, subs)):
        for p in group:
            slug = links.get(words(p["name"]))
            if slug is None or players[slug].get("started") is not started:
                audit["unlinkedOrCohortConflict"] += 1
                continue
            native = players[slug]
            if (
                type(native.get("mins")) is not int
                or type(p.get("mins")) is not int
                or abs(p["mins"] - native["mins"]) > 10
            ):
                audit["nativeMinutesConflict"] += 1
                continue
            on, off = p.get("on"), p.get("off")
            minute = off if started else on
            state = decision_state(events, side, minute) if minute is not None else None
            if minute is not None:
                audit["decisionWithKnownState" if state is not None else "decisionSameMinuteAsGoal"] += 1
            linked.append(dict(player=slug, position=native["pos"], started=started, on=on, off=off, state=state))
            audit["linkedStart" if started else "linkedSub"] += 1
    return linked


def capture(games, aliases, observe=None, observe_fixture=None):
    if subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip() != COMMIT:
        raise ValueError("Pinned event archive commit differs")
    tree = subprocess.check_output(["git", "-C", str(REPO), "ls-tree", "-r", "HEAD"], text=True)
    blobs = {line.split("\t", 1)[1]: line.split()[2] for line in tree.splitlines()}
    receipt = hashlib.sha256()

    def read(name):
        canonical = (REPO / name).read_bytes().replace(b"\r\n", b"\n")
        actual = hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest()
        if actual != blobs[name]:
            raise ValueError("Changed archive blob: " + name)
        receipt.update(canonical)
        return json.loads(canonical.decode("utf-8").split("=", 1)[1].strip().rstrip(";"))

    schedule = read("laliga_dashboard/data.js")
    fixture_lookup = defaultdict(list)
    for game in games:
        fixture_lookup[season_year(game["date"]), game["home"]["slug"], game["away"]["slug"]].append(game)
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        alaves=CLUBS["Deportivo Alaves"], celta=CLUBS["Celta Vigo"], deportivolacoruna=CLUBS["Deportivo A Coruna"]
    )
    audit, games_seen, records = Counter(), set(), []
    for season in schedule["seasons"].values():
        for item in season["matches"]:
            if item.get("played") is not True:
                continue
            sides = tuple(clubs.get(normalise(item[s])) for s in ("home", "away"))
            matches = fixture_lookup[season_year(item["date"]), *sides]
            if len(matches) != 1:
                continue
            g = matches[0]
            assert g["id"] not in games_seen
            games_seen.add(g["id"])
            name = f"laliga_dashboard/matches_detail/{item['id']}.js"
            if name not in blobs or not (REPO / name).is_file():
                audit["missingSourceDetail"] += 1
                continue
            detail = read(name)
            if tuple(clubs.get(normalise(detail[s].get("name", ""))) for s in ("home", "away")) != sides:
                audit["sourceClubConflict"] += 1
                continue
            if (detail["home"].get("score"), detail["away"].get("score")) != (g["homeGoals"], g["awayGoals"]):
                audit["sourceScoreConflict"] += 1
                continue
            if verified_flow(detail, g["homeGoals"], g["awayGoals"]) is None:
                audit["unverifiedGoals"] += 1
                continue
            audit["verifiedFixture"] += 1
            events = [(p["min"], p["team"]) for p in detail["goals"]]
            final_minute = max(90, detail["maxMin"], max((t for t, _ in events), default=0))
            if observe_fixture is not None:
                observe_fixture(g, events, detail)
            for side, club in zip(("home", "away"), sides, strict=True):
                clocks, reason = paired_clocks((detail.get("lineups") or {}).get(side) or {}, final_minute)
                audit[reason] += 1
                if clocks is not None:
                    linked = historical_players(g, club, clocks, events, side, aliases, audit)
                    record = dict(
                        game=g["id"],
                        club=club,
                        date=g["date"],
                        at60=decision_state(events, side, 60),
                        goalsForClub=[(t, 1 if team == side else -1) for t, team in events],
                        players=linked,
                    )
                    records.append(record)
                    if observe is not None:
                        observe(g, detail, side, clocks, record)
    return records, dict(audit), receipt.hexdigest()


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    alias_bytes = (ROOT / "player_names.json").read_bytes()
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    records, audit, receipt = capture(games, json.loads(alias_bytes))
    cache = ROOT / (STEM + ".json")
    cache.write_text(json.dumps(records, separators=(",", ":")) + "\n")
    report = dict(
        nativeSHA=NATIVE_SHA,
        archiveCommit=COMMIT,
        archiveReadSHA=receipt,
        aliasesSHA=hashlib.sha256(alias_bytes).hexdigest(),
        qualifiedCacheSHA=hashlib.sha256(cache.read_bytes()).hexdigest(),
        earlierNativeFixtures=len(games),
        sidesWithPairedClocks=len(records),
        audit=audit,
        stateAt60=dict(
            Counter("unknown" if r["at60"] is None else int(r["at60"] > 0) - int(r["at60"] < 0) for r in records)
        ),
        laterOutcomesEvaluated=False,
        fittedModel=False,
    )
    (REPORTS / (STEM + ".source.json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
