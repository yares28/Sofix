"""Testing only: a fuller conditional AA quantile curve and native score windows."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research.score_modal_trees import CENTRES

QUANTILES = (0.05, 0.15, 0.25, 0.35, 0.45, 0.5, 0.55, 0.65, 0.75, 0.85, 0.95)


def curve_mass(knots, level, tails):
    knots = np.asarray(knots, dtype=float)
    if knots.ndim != 2 or knots.shape[1] != len(QUANTILES) or not np.isfinite(knots).all():
        raise ValueError("Complete finite AA quantile curve required")
    if tails not in ("clamp", "extrapolate"):
        raise ValueError("Registered quantile tail policy required")
    values = np.sort(knots, axis=1)
    left, right = values[:, 0], values[:, -1]
    if tails == "extrapolate":
        left = left - (values[:, 1] - left) * 0.05 / 0.1
        right = right + (right - values[:, -2]) * 0.05 / 0.1
    points = np.column_stack((left, values, right))
    weights = np.diff(np.r_[0.0, QUANTILES, 1.0])
    floor = level if level >= 60 else 0
    low, high = CENTRES - 7, CENTRES + 7
    result = np.zeros((len(knots), len(CENTRES)))
    for k, weight in enumerate(weights):
        a, b = points[:, k, None], points[:, k + 1, None]
        width = b - a
        before = np.clip(np.divide(low[None, :] - level - a, width, out=np.zeros_like(result), where=width > 0), 0, 1)
        after = np.clip(np.divide(high[None, :] - level - a, width, out=np.zeros_like(result), where=width > 0), 0, 1)
        before = np.where(low[None, :] <= floor, 0, before)
        after = np.where(high[None, :] >= 100, 1, after)
        uniform = np.where(high[None, :] < floor, 0, np.maximum(0, after - before))
        score = np.clip(np.maximum(floor, level + a), 0, 100)
        atom = (np.abs(score - CENTRES) <= 7).astype(float)
        result += weight * np.where(width > 0, uniform, atom)
    if not np.isfinite(result).all() or (result < 0).any() or (result > 1 + 1e-12).any():
        raise ValueError("Invalid native AA quantile-curve mass")
    return result


def fit_quantiles(
    x, aa, levels, fit, target, classes, old_parts, iterations=120, cache_dir=None, prefix=None, key=None
):
    from sklearn.ensemble import HistGradientBoostingRegressor

    x, aa, levels, classes = map(np.asarray, (x, aa, levels, classes))
    fit, target = np.asarray(fit, dtype=bool), np.asarray(target, dtype=bool)
    if (
        x.ndim != 2
        or any(v.shape != (len(x),) for v in (aa, levels, fit, target))
        or np.isinf(x).any()
        or not fit.any()
        or not target.any()
        or (fit & target).any()
        or not np.isfinite(aa[fit]).all()
        or not np.isfinite(levels[fit]).all()
    ):
        raise ValueError("Available quantile-curve fit labels and complete target cases required")
    n = int(target.sum())
    shape = (n, len(classes))
    if cache_dir is not None and (not prefix or not key):
        raise ValueError("Individual quantile caches require a study prefix and fingerprint")
    reused = (0.35, 0.5, 0.65) if iterations == 120 else ()
    if any(q not in old_parts or old_parts[q].shape != shape or not np.isfinite(old_parts[q]).all() for q in reused):
        raise ValueError("Original AA quantile anchors missing or incompatible")
    result = {q: old_parts[q].copy() for q in reused}
    fit_hash = hashlib.sha256(
        np.packbits(fit).tobytes() + np.packbits(target).tobytes() + aa[fit].tobytes() + levels[fit].tobytes()
    ).hexdigest()
    fitted = []
    anchor_difference = None
    for q in QUANTILES:
        if q in reused and q != 0.5:
            continue
        path = None if cache_dir is None else cache_dir / f"{prefix}_i{iterations}_q{str(q).replace('.', 'p')}.npz"
        if path is not None and path.exists():
            with np.load(path) as f:
                if (
                    str(f["key"]) != key
                    or str(f["fitHash"]) != fit_hash
                    or not np.array_equal(f["classes"], classes)
                    or f["prediction"].shape != shape
                ):
                    raise ValueError("Individual AA quantile cache identity differs")
                predicted = f["prediction"]
        else:
            print(f"QUANTILE_CURVE_FIT {prefix or 'test'} iterations{iterations} q{q}", flush=True)
            model = HistGradientBoostingRegressor(
                loss="quantile",
                quantile=q,
                max_leaf_nodes=15,
                min_samples_leaf=60,
                max_iter=iterations,
                learning_rate=0.1,
                l2_regularization=10,
                early_stopping=False,
                random_state=20261103,
            )
            model.fit(np.column_stack((x[fit], levels[fit])), aa[fit])
            predicted = np.column_stack([model.predict(np.column_stack((x[target], np.full(n, v)))) for v in classes])
            if path is not None:
                np.savez_compressed(
                    path,
                    key=key,
                    fitHash=fit_hash,
                    classes=classes,
                    prediction=predicted,
                    quantile=q,
                    iterations=iterations,
                )
        fitted.append(q)
        if q == 0.5 and reused:
            anchor_difference = float(np.max(np.abs(predicted - old_parts[q])))
            if anchor_difference > 1e-10:
                raise ValueError("Original AA median anchor does not reproduce: " + str(anchor_difference))
        else:
            result[q] = predicted
    if set(result) != set(QUANTILES) or any(not np.isfinite(v).all() or v.shape != shape for v in result.values()):
        raise ValueError("Quantile curve lost required forecasts")
    stacked = np.stack([result[q] for q in QUANTILES])
    stats = {
        "fitCases": int(fit.sum()),
        "targetCases": n,
        "iterations": iterations,
        "quantileLevels": list(QUANTILES),
        "quantilesReused": list(reused),
        "quantilesFittedOrReloaded": fitted,
        "anchorMedianMaximumDifference": anchor_difference,
        "fitHash": fit_hash,
        "numericFeatures": x.shape[1],
        "crossingCaseClassPairsBeforeRearrangement": int(np.any(np.diff(stacked, axis=0) < 0, axis=0).sum()),
        "quantileArraySha256": hashlib.sha256(stacked.tobytes()).hexdigest(),
    }
    return result, stats


def forecast_mass(classes, probability, parts, tails):
    probability = np.asarray(probability)
    if (
        probability.ndim != 2
        or probability.shape[1] != len(classes)
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Valid unchanged decisive probability matrix required")
    knots = np.stack([parts[q] for q in QUANTILES], axis=2)
    if knots.shape != (len(probability), len(classes), len(QUANTILES)):
        raise ValueError("Complete all-case possible-class quantile profiles required")
    mass = np.zeros((len(probability), len(CENTRES)))
    for j, level in enumerate(classes):
        mass += probability[:, j, None] * curve_mass(knots[:, j], level, tails)
    return mass
