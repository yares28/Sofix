"""Independent forward arithmetic, native candidate decisions and actual refit audit."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import numpy as np

from app.research import score_identity_interactions as core
from app.research import score_identity_interactions_run as runner
from app.research import score_stability as stability
from app.research.score_search import cutoff_for, measure, moment


def independent_forward(raw, categories, stored, maps):
    raw = np.asarray(raw, dtype=float)
    valid = np.isfinite(raw)
    mean, scale, known = (stored["normaliser_" + n] for n in ("mean", "scale", "known"))
    values = np.clip((np.where(valid, raw, mean) - mean) / scale, -8, 8)
    missing = (~valid).astype(float)
    values[:, ~known] = 0
    missing[:, ~known] = 0
    x = np.column_stack((values, missing)).astype(np.float32)
    ids = np.array(
        [
            [
                maps[j].get(
                    None
                    if value is None or isinstance(value, (float, np.floating)) and not np.isfinite(value)
                    else str(value),
                    0,
                )
                for j, value in enumerate(row)
            ]
            for row in categories
        ],
        dtype=int,
    )
    w = {n[2:]: v for n, v in stored.items() if n.startswith("w_")}
    player, team, opponent = (w[n][ids[:, j]] for j, n in enumerate(("E_player", "E_team", "E_opponent")))
    hidden = x @ w["W"]
    hidden = hidden + player @ w["U_player"]
    hidden = hidden + team @ w["U_team"]
    hidden = hidden + opponent @ w["U_opponent"]
    hidden = hidden + (player * opponent) @ w["U_po"]
    hidden = hidden + (team * opponent) @ w["U_to"]
    hidden = np.tanh(hidden + w["b_hidden"])
    logits = hidden @ w["V"] + w["b_output"]
    return np.exp(-np.logaddexp(0, -logits))


def independent_forecast(base, new, weight, control, positions, scope):
    # Native mixing converts the learned float32 mass to float64 before arithmetic.
    mass = (1 - weight) * np.asarray(base, dtype=float) + weight * np.asarray(new, dtype=float)
    centres = np.arange(201) / 2
    result = []
    for row, old, pos in zip(mass, control, positions, strict=True):
        if scope == "defmid" and pos not in ("DEF", "MID"):
            result.append(old)
            continue
        indices = np.flatnonzero(abs(row - max(row)) <= 1e-12)
        middle = centres[indices].mean()
        chosen = min(indices, key=lambda k: (abs(centres[k] - middle), k))
        result.append(centres[chosen])
    return np.array(result)


def verify_bundle(path, key, x, cats, scores, mask, spec, epochs):
    with np.load(path) as f:
        data = {name: f[name] for name in f.files}
    if (
        str(data["key"]) != key
        or not np.array_equal(data["fit"], mask["fit"])
        or not np.array_equal(data["target"], mask["target"])
    ):
        raise ValueError("Interaction full native fit/target/key mismatch")
    stats = json.loads(str(data["statistics"]))
    if (
        stats["epochs"] != epochs
        or stats["fitRows"] != int(mask["fit"].sum())
        or stats["targetRows"] != int(mask["target"].sum())
    ):
        raise ValueError("Interaction epoch/population identity mismatch")
    raw = x[mask["fit"]]
    finite = np.isfinite(raw)
    count = finite.sum(axis=0)
    mean = np.divide(np.where(finite, raw, 0).sum(axis=0), count, out=np.zeros(raw.shape[1]), where=count > 0)
    variance = np.divide(
        np.where(finite, (raw - mean) ** 2, 0).sum(axis=0), count, out=np.zeros(raw.shape[1]), where=count > 0
    )
    scale = np.sqrt(variance)
    scale[scale < 1e-8] = 1
    np.testing.assert_array_equal(count > 0, data["normaliser_known"])
    np.testing.assert_array_equal(mean, data["normaliser_mean"])
    np.testing.assert_array_equal(scale, data["normaliser_scale"])
    use_ids = spec.get("use_identities", True)
    expected_maps = []
    for j in range(3):
        expected_maps.append({k: i + 1 for i, k in enumerate(sorted(set(cats[mask["fit"], j])))} if use_ids else {})
    maps = json.loads(str(data["category_maps"]))
    if maps != expected_maps:
        raise ValueError("Interaction vocabulary includes non-training identities")
    for name in ("E_player", "E_team", "E_opponent"):
        np.testing.assert_array_equal(data["w_" + name][0], 0)
    rebuilt = independent_forward(x[mask["target"]], cats[mask["target"]], data, maps)
    np.testing.assert_array_equal(rebuilt, data["mass"])
    if not use_ids:
        altered = np.full(cats[mask["target"]].shape, "arbitrary-unknown", dtype=object)
        np.testing.assert_array_equal(rebuilt, independent_forward(x[mask["target"]], altered, data, maps))
    if not np.isfinite(scores[mask["fit"]]).all():
        raise ValueError("Missing native training labels")
    return rebuilt, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    args.out = args.report
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    reports = {name: json.loads((args.report.parent / (name + ".json")).read_text()) for name in runner.shared.REPORTS}
    arrays, input_keys, identities = runner.load_inputs(args, source, reports)
    key = runner.implementation_key(source, input_keys, reports, args.report.with_suffix(".plan.json"))
    if key != report["implementationKey"] or report["sourceKey"] != source["key"]:
        raise ValueError("Interaction frozen implementation/source changed")
    games = [json.loads(line) for line in args.games.read_text().splitlines() if line.strip()]
    native = {(g["id"], player): (g, p) for g in games for player, p in g["players"].items()}
    for i, row in enumerate(source["rows"]):
        game, p = native[row["game"], row["player"]]
        opponent = game["away" if p["team"] == game["home"]["slug"] else "home"]["slug"]
        if (
            list(identities[i]) != [row["player"], p["team"], opponent, p["pos"]]
            or p["ver"] != 7
            or p["started"] != (row["cohort"] == "start")
            or not p["played"]
            or any(abs(p[k] - row[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Native source label/fixture identity differs")
    audit = dict(implementationKey=key, nativeCasesVerified=len(source["rows"]), cohorts={})
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        result = report["cohorts"][cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        positions, y = np.array([r["pos"] for r in rows]), np.array([r["score"] for r in rows])
        inputs = runner.numeric_inputs(arrays, keep, positions, cohort)
        cats, masks = identities[keep, :3], stability.phase_masks(rows)
        call = SimpleNamespace(**{**vars(args), "rows": rows})
        frozen = json.loads(args.report.with_name(args.report.stem + f".{cohort}.frozen.json").read_text())
        candidates = frozen["candidates80"]
        phase_base, bundles, checked = {}, {}, 0
        for phase, begin, end in stability.PHASES[1:-1]:
            mask = masks[phase]
            independent_target = np.array([begin <= r["date"] < end for r in rows])
            independent_fit = np.array(
                [
                    r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < cutoff_for(mask["first"])
                    for r in rows
                ]
            )
            np.testing.assert_array_equal(mask["fit"], independent_fit)
            np.testing.assert_array_equal(mask["target"], independent_target)
            base, control, _, _ = runner.reference_runner.reference(call, key, source, cohort, phase, masks, reports)
            phase_base[phase] = base, control
            for model_name in runner.MODEL_NAMES:
                for group in inputs:
                    path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{group}_{model_name}_80.npz"
                    mass, data = verify_bundle(path, key, inputs[group], cats, y, mask, core.PARAMETERS[model_name], 80)
                    bundles[phase, group, model_name, 80] = data
                    for record in [
                        r for r in candidates if r["spec"]["model"] == model_name and r["spec"]["group"] == group
                    ]:
                        spec = record["spec"]
                        prediction = independent_forecast(
                            base, mass, spec["weight"], control, positions[mask["target"]], spec["scope"]
                        )
                        if measure(y[mask["target"]], prediction) != record["periods"][phase]["metrics"]:
                            raise ValueError("Independent complete earlier candidate vector differs")
                        checked += 1
        winner80, best80 = stability.choose_stable(candidates)
        if winner80 != frozen["screenWinner80"] or best80 != frozen["screenBest80"]:
            raise ValueError("Earlier screening selection differs")
        if frozen.get("confirmationSkipped"):
            if winner80 is not None or "later" in result:
                raise ValueError("Rejected candidate silently evaluated/promoted")
        else:
            confirmed = frozen["finalCandidate"]
            spec = confirmed["spec"]
            for phase, _, _ in stability.PHASES[1:-1]:
                mask = masks[phase]
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{spec['group']}_{spec['model']}_160.npz"
                mass, data = verify_bundle(
                    path, key, inputs[spec["group"]], cats, y, mask, core.PARAMETERS[spec["model"]], 160
                )
                np.testing.assert_array_equal(
                    bundles[phase, spec["group"], spec["model"], 80]["history"], data["history"][:80]
                )
                base, control = phase_base[phase]
                pred = independent_forecast(
                    base, mass, spec["weight"], control, positions[mask["target"]], spec["scope"]
                )
                if measure(y[mask["target"]], pred) != confirmed["periods"][phase]["metrics"]:
                    raise ValueError("Independent fixed160 confirmation differs")
                checked += 1
        # Actually retrain a full real-data model with every outside-fit label absent.
        refit_spec = (frozen.get("winner") or best80)["spec"]
        refit_phase, epochs = ("later2026", 160) if frozen.get("winner") else ("spring2024", 80)
        mask = masks[refit_phase]
        if refit_phase == "later2026":
            path = (
                args.cache
                / f"{args.report.stem}_{cohort}_{refit_phase}_{refit_spec['group']}_{refit_spec['model']}_160.npz"
            )
            mass, _ = verify_bundle(
                path, key, inputs[refit_spec["group"]], cats, y, mask, core.PARAMETERS[refit_spec["model"]], epochs
            )
            base, control, _, _ = runner.reference_runner.reference(
                call, key, source, cohort, refit_phase, masks, reports
            )
            pred = independent_forecast(
                base, mass, refit_spec["weight"], control, positions[mask["target"]], refit_spec["scope"]
            )
            with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
                np.testing.assert_array_equal(f["y"], y[mask["target"]])
                np.testing.assert_array_equal(f["prediction"], pred)
                if (
                    len(pred) != {"start": 6754, "bench": 2925}[cohort]
                    or measure(y[mask["target"]], pred) != result["later"]
                ):
                    raise ValueError("Final all-case native forecast differs")
        else:
            mass = bundles[refit_phase, refit_spec["group"], refit_spec["model"], epochs]["mass"]
        hidden = y.copy()
        hidden[~mask["fit"]] = np.nan
        directory = args.cache / "interaction-native-refits" / uuid4().hex
        directory.mkdir(parents=True)
        refit, _ = runner.fitted(
            inputs[refit_spec["group"]],
            cats,
            hidden,
            mask,
            core.PARAMETERS[refit_spec["model"]],
            epochs,
            directory / "actual.npz",
            key,
        )
        np.testing.assert_array_equal(refit, mass)
        audit["cohorts"][cohort] = dict(
            nativeEarlierCandidateVectors=checked,
            fullModelBundlesVerified=len(bundles),
            actualFullOutsideFitBlankedRefit=dict(
                phase=refit_phase, epochs=epochs, fitRows=int(mask["fit"].sum()), allNativeTargetProbabilitiesExact=True
            ),
            accepted=bool(frozen.get("winner")),
            rejectedFinalNotRun="later" not in result,
        )
        print("INTERACTION_AUDITED " + json.dumps(dict(cohort=cohort, **audit["cohorts"][cohort])), flush=True)
    args.report.with_suffix(".integrity.json").write_text(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
