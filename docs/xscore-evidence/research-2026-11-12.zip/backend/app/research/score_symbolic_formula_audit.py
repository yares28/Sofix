"""Testing only: reconstruct literal formulas, fit-only preprocessing and native full-case results."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_symbolic_formula as network
from app.research import score_symbolic_formula_run as runner
from app.research.score_search import POSITIONS, cutoff_for, measure, moment


def literal_prediction(tree, matrix):
    def value(node, row):
        op = node[0]
        if op == "v":
            return float(row[node[1]])
        if op == "c":
            return float(node[1])
        a, b = value(node[1], row), value(node[2], row)
        if op == "add":
            result = a + b
        elif op == "sub":
            result = a - b
        elif op == "mul":
            result = a * b
        elif op == "div":
            result = a / (b if abs(b) >= 1 else 1)
        elif op == "min":
            result = min(a, b)
        elif op == "max":
            result = max(a, b)
        elif op == "if":
            result = b if a > 0 else value(node[3], row)
        else:
            raise ValueError("Unknown literal formula operator")
        return min(200, max(-200, result))

    return np.array([math.floor(min(100, max(0, value(tree, row))) * 2 + 0.5) / 2 for row in matrix])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    if source["key"] != report["sourceKey"]:
        raise ValueError("Symbolic audit source differs")
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_bench = map(
        read,
        ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary", "laliga_score_analogues"),
    )
    arrays, array_keys = {}, {}
    for label, file in (
        ("base", "stats.npz"),
        ("match", "match_context_features.npz"),
        ("player", "player_context_features.npz"),
        ("history", "modal_history_features.npz"),
        ("event", "event_intensity_features.npz"),
    ):
        with np.load(args.cache / file) as f:
            arrays[label] = f["x"], f["names"].tolist()
            array_keys[label] = str(f["key"])
            if label == "event" and str(f["key"]) != report["eventFeatureKey"]:
                raise ValueError("Symbolic audit causal event-feature identity differs")
    old_player, history_report, event_report, old_start = map(
        read,
        (
            "laliga_score_player_context",
            "laliga_score_modal_history",
            "laliga_score_event_intensity",
            "laliga_score_match_empirical_density",
        ),
    )
    for label, expected in (
        ("base", old_match["statKey"]),
        ("match", old_match["featureKey"]),
        ("player", old_player["featureKey"]),
        ("history", history_report["featureKey"]),
        ("event", event_report["featureKey"]),
    ):
        if array_keys[label] != expected:
            raise ValueError("Symbolic audit feature stage source differs")
    if any(
        r["sourceKey"] != source["key"]
        for r in (
            old_match,
            old_stability,
            old_ordinary,
            old_bench,
            old_player,
            history_report,
            event_report,
            old_start,
        )
    ):
        raise ValueError("Symbolic audit canonical references differ")
    combined = hashlib.sha256((array_keys["base"] + array_keys["match"]).encode()).hexdigest()
    if combined != old_player["statKey"]:
        raise ValueError("Symbolic audit stat/team combined source differs")
    key = hashlib.sha256(
        (
            source["key"]
            + array_keys["base"]
            + "".join(array_keys[label] for label in ("match", "player", "history", "event"))
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in (network, controls, ordinary, stability))
        + Path(runner.__file__).read_bytes()
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Symbolic audit complete code/plan/input identity differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, numeric_names = ordinary.ordinary_inputs(
            arrays["base"][0][keep],
            arrays["base"][1],
            arrays["player"][0][keep],
            arrays["player"][1],
            arrays["match"][0][keep],
            arrays["match"][1],
            cohort,
        )
        x = np.column_stack(
            (
                numeric,
                arrays["history"][0][keep],
                arrays["event"][0][keep],
                *[(positions == p).astype(float) for p in POSITIONS],
            )
        )
        input_names = numeric_names + arrays["history"][1] + arrays["event"][1] + ["position_" + p for p in POSITIONS]
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        if frozen["implementationKey"] != report["implementationKey"]:
            raise ValueError("Symbolic audit frozen identity differs")
        _, best = stability.choose_stable(frozen["candidates80"])
        if best["spec"] != frozen["finalCandidate"]["spec"]:
            raise ValueError("Symbolic audit earlier fixed choice changed")
        passing = min(frozen["finalCandidate"]["gains"]) > 0
        if passing != bool(frozen["winner"]) or passing != (result["selected"] == "candidate"):
            raise ValueError("Symbolic audit stability gate differs")
        cached, checked = {}, 0
        for path in sorted(args.cache.glob(f"{args.report.stem}_{cohort}_*_e*_{report['implementationKey'][:12]}.npz")):
            phase = next(p[0] for p in stability.PHASES if "_" + p[0] + "_" in path.name)
            mask = masks[phase]
            name = next(n for n in runner.MODELS if "_" + n + "_" in path.name)
            epochs = 160 if "_e160_" in path.name else 80
            with np.load(path) as f:
                if str(f["key"]) != report["implementationKey"]:
                    raise ValueError("Symbolic audit fitted cache identity differs")
                diagnostics = json.loads(str(f["statistics"]))
                if f["feature_names"].tolist() != input_names:
                    raise ValueError("Symbolic audit exact feature names differ")
                model = network.FormulaSearch(**runner.MODELS[name], generations=epochs, population=256)
                for attr in ("median", "lower", "upper", "known"):
                    setattr(model, attr + "_", f[attr])
                model.tree_ = diagnostics["bestTree"]
                fit_x = x[mask["fit"]]
                known = np.isfinite(fit_x).any(axis=0)
                median, lower, upper = (np.zeros(x.shape[1]) for _ in range(3))
                for j in np.flatnonzero(known):
                    values = fit_x[np.isfinite(fit_x[:, j]), j]
                    median[j] = np.median(values)
                    lower[j] = min(0, np.quantile(values, 0.01))
                    upper[j] = max(0, np.quantile(values, 0.99))
                if any(
                    not np.array_equal(a, b)
                    for a, b in (
                        (known, model.known_),
                        (median, model.median_),
                        (lower, model.lower_),
                        (upper, model.upper_),
                    )
                ):
                    raise ValueError("Symbolic audit fit-only preprocessing differs")
                config = runner.MODELS[name]
                fit_identity = hashlib.sha256(
                    fit_x.tobytes()
                    + y[mask["fit"]].tobytes()
                    + network.tree_key([config["max_depth"], config["penalty"], 256, 20261105, input_names]).encode()
                ).hexdigest()
                lock = cutoff_for(mask["first"])
                if any(
                    moment(r["date"]).timestamp() + 172800 >= lock.timestamp()
                    for r, yes in zip(rows, mask["fit"], strict=True)
                    if yes
                ):
                    raise ValueError("Symbolic audit training label unavailable at first lock")
                raw = literal_prediction(model.tree_, model.transform(x[mask["target"]]))
                trained = literal_prediction(model.tree_, model.transform(fit_x))
                hit = float((np.abs(y[mask["fit"]] - trained) <= 7).mean())
                mae = float(np.abs(y[mask["fit"]] - trained).mean())
                size = len(network.node_paths(model.tree_))
                expected_fitness = [hit - config["penalty"] * size, -mae, -size, hit]
                if (
                    not np.array_equal(raw, f["prediction"])
                    or not np.array_equal(raw, model.predict(x[mask["target"]]))
                    or diagnostics["fitIdentity"] != fit_identity
                    or diagnostics["trainingOnlyFitness"] != expected_fitness
                    or diagnostics["bestNodeCount"] != size
                    or size > 63
                    or network.depth(model.tree_) > config["max_depth"]
                    or diagnostics["generations"] != epochs
                    or diagnostics["fitCases"] != int(mask["fit"].sum())
                    or diagnostics["targetRows"] != int(mask["target"].sum())
                    or len(diagnostics["trainingOnlyHistory"]) != epochs
                ):
                    raise ValueError("Symbolic audit literal decisions/fitness/capacity/coverage differ")
                snapshot = path.with_name(path.stem.rsplit("_e", 1)[0] + "_" + key[:12] + ".search.json")
                state = json.loads(snapshot.read_text())
                if (
                    state["key"] != key
                    or state["fitIdentity"] != fit_identity
                    or state["done"] < epochs
                    or state["history"][:epochs] != diagnostics["trainingOnlyHistory"]
                ):
                    raise ValueError("Symbolic audit resumed generation history differs")
                cached[(phase, name, epochs)] = raw
                checked += 1
        if checked != 16:
            raise ValueError("Symbolic audit expected12screen+3confirmation+1final searches")
        control_bank = {}
        call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        for phase, _, _ in stability.PHASES[1:]:
            control_bank[phase] = controls.control_for(
                call_args,
                report["implementationKey"],
                source,
                cohort,
                phase,
                masks,
                old_match,
                old_stability,
                old_ordinary,
                old_bench,
            )
        for phase, _, _ in stability.PHASES[1:]:
            target = masks[phase]["target"]
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control_bank[phase]) != expected:
                raise ValueError("Symbolic audit exact frozen reference differs")
        for record in frozen["candidates80"]:
            for phase, _, _ in stability.PHASES[1:-1]:
                target = masks[phase]["target"]
                candidate = ordinary.scoped_prediction(
                    cached[(phase, record["spec"]["model"], 80)],
                    control_bank[phase],
                    positions[target],
                    record["spec"]["scope"],
                )
                if measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                    raise ValueError("Symbolic audit earlier screen metric differs")
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            candidate = ordinary.scoped_prediction(
                cached[(phase, best["spec"]["model"], 160)],
                control_bank[phase],
                positions[target],
                best["spec"]["scope"],
            )
            if measure(y[target], candidate) != frozen["finalCandidate"]["periods"][phase]["metrics"]:
                raise ValueError("Symbolic audit earlier confirmation metric differs")
        phase = "later2026"
        target = masks[phase]["target"]
        candidate = ordinary.scoped_prediction(
            cached[(phase, best["spec"]["model"], 160)], control_bank[phase], positions[target], best["spec"]["scope"]
        )
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != report["implementationKey"]
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], candidate)
                or not np.array_equal(f["control"], control_bank[phase])
            ):
                raise ValueError("Symbolic audit final case/forecast identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Symbolic audit final native metric differs")
            h1, h0 = np.abs(f["alternate"] - y[target]) <= 7, np.abs(f["control"] - y[target]) <= 7
        if int(target.sum()) != {"start": 6754, "bench": 2925}[cohort]:
            raise ValueError("Symbolic audit all-case denominator differs")
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "modelsReproducedWithoutOutcomeInputs": checked,
            "allFitPreprocessorsReconstructedFromEarlierCases": checked,
            "earlierSelectionAndStabilityGateVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            altered_y = y.copy()
            altered_y[~masks["later2026"]["fit"]] = np.nan
            spec = runner.MODELS[best["spec"]["model"]]
            print(f"SYMBOLIC_AUDIT_REFIT {cohort} final160", flush=True)
            repeated = network.FormulaSearch(**spec, generations=160, population=256).fit(
                x[masks["later2026"]["fit"]], altered_y[masks["later2026"]["fit"]], names=input_names
            )
            expected_stats = dict(result["finalFitDiagnostics"])
            expected_stats.pop("targetRows")
            if repeated.statistics_ != expected_stats or not np.array_equal(
                repeated.predict(x[target]), cached[("later2026", best["spec"]["model"], 160)]
            ):
                raise ValueError("Actual final symbolic search changed with all outside-fit scores blanked")
            evidence[cohort]["real160GenerationRefitWithoutOutsideFitScores"] = dict(
                outsideFitScoresBlanked=int((~masks["later2026"]["fit"]).sum()),
                exactTreeHistoryAndAllPredictionsReproduced=True,
            )
    output = {
        "scope": "Research-only native metrics, fitted-model and chronology audit, no fresh blind claim",
        "implementationKey": report["implementationKey"],
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
