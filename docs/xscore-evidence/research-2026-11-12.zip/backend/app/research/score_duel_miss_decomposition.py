"""Earlier-only miss diagnosis of duel volume versus winning-fraction swings."""

from __future__ import annotations

import argparse
import hashlib
import json
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from fractions import Fraction
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, measure, moment

PHASES = (
    ("spring2024", "2024-01-01", "2024-07-01"),
    ("season2024", "2024-07-01", "2025-07-01"),
    ("autumn2025", "2025-07-01", "2026-01-01"),
)


def decompose(baseline_volume, baseline_fraction, won, lost):
    baseline_volume, baseline_fraction, won, lost = (
        v if isinstance(v, Fraction) else Fraction(str(v)) for v in (baseline_volume, baseline_fraction, won, lost)
    )
    if baseline_volume < 0 or not 0 <= baseline_fraction <= 1 or min(won, lost) < 0:
        raise ValueError("Nonnegative counts/volume and known baseline fraction required")
    total = won + lost
    factor = Fraction(7, 2)
    baseline = baseline_volume * (factor * baseline_fraction - 2)
    actual = Fraction(3, 2) * won - 2 * lost
    volume = (factor * baseline_fraction - 2) * (total - baseline_volume)
    residual = factor * (won - baseline_fraction * total)
    if volume + residual != actual - baseline:
        raise ValueError("Exact raw duel-point identity failed")
    fraction = won / total if total else None
    winshare = factor * baseline_volume * (fraction - baseline_fraction) if total else None
    interaction = factor * (total - baseline_volume) * (fraction - baseline_fraction) if total else None
    if total and volume + winshare + interaction != actual - baseline:
        raise ValueError("Three-term duel identity failed")
    values = dict(
        actualPoints=actual,
        baselinePoints=baseline,
        pointShift=actual - baseline,
        actualDuels=total,
        baselineDuels=baseline_volume,
        actualWinningFraction=fraction,
        baselineWinningFraction=baseline_fraction,
        volume=volume,
        winshare=winshare,
        interaction=interaction,
        symmetricVolume=volume + interaction / 2 if total else volume,
        symmetricWinshare=winshare + interaction / 2 if total else None,
        winmixResidual=residual,
    )
    result = {k: float(v) if v is not None else None for k, v in values.items()}
    result.update(
        exactPointShift=str(actual - baseline),
        meaningfulPointShift=abs(actual - baseline) >= 7,
        exactBaselineDuels=str(baseline_volume),
        exactBaselineWinningFraction=str(baseline_fraction),
    )
    result["dominantThreeTerm"] = (
        max(("volume", "winshare", "interaction"), key=lambda k: abs(values[k])) if total else "zeroTargetVolumeOnly"
    )
    a, b = abs(values["symmetricVolume"]), abs(values["symmetricWinshare"]) if total else 0
    result["dominantSymmetricTerm"] = "volume" if a > b else "winningFraction" if b > a else "tie"
    return result


def aggregate(records):
    eligible = [r for r in records if r["decomposition"] is not None]
    meaningful = [r["decomposition"] for r in eligible if r["decomposition"]["meaningfulPointShift"]]
    dominant3, dominant2 = Counter(), Counter()
    for r in meaningful:
        dominant3[r["dominantThreeTerm"]] += 1
        dominant2[r["dominantSymmetricTerm"]] += 1
    return dict(
        allCases=len(records),
        eligiblePastBaseline=len(eligible),
        withoutBaseline=len(records) - len(eligible),
        zeroTargetDuels=sum(r["decomposition"]["actualDuels"] == 0 for r in eligible),
        meaningfulDuelPointSwings=len(meaningful),
        dominantThreeTerms=dict(dominant3),
        dominantSymmetricTerms=dict(dominant2),
        volumeDominatesFraction=dominant2["volume"] / len(meaningful) if meaningful else None,
        opposingSymmetricSigns=sum(
            r["symmetricWinshare"] is not None and r["symmetricVolume"] * r["symmetricWinshare"] < 0 for r in meaningful
        ),
        meanAbsoluteContributions={
            k: float(np.mean([abs(r[k]) for r in meaningful if r[k] is not None]))
            if any(r[k] is not None for r in meaningful)
            else None
            for k in ("volume", "winshare", "interaction", "symmetricVolume", "symmetricWinshare")
        },
        medianAbsoluteContributions={
            k: float(np.median([abs(r[k]) for r in meaningful if r[k] is not None]))
            if any(r[k] is not None for r in meaningful)
            else None
            for k in ("volume", "winshare", "interaction", "symmetricVolume", "symmetricWinshare")
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_duel_miss_decomposition.json")
    )
    args = parser.parse_args()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    source = json.loads((args.cache / "cases.json").read_text())
    model_report = json.loads((args.out.parent / "laliga_score_native_sot_conditioning.json").read_text())
    audit = json.loads((args.out.parent / "laliga_score_native_sot_conditioning.integrity.json").read_text())
    if audit["implementationKey"] != model_report["implementationKey"] or any(
        not audit["cohorts"][c]
        .get("actualOriginalSourcePairedRefit", {})
        .get("preservedOriginalClassesProbabilitiesQuantilesExact")
        for c in ("start", "bench")
    ):
        raise ValueError("Complete paired source/candidate/refit audit required before new diagnosis")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    rows = [r for r in source["rows"] if r["cohort"] == "start"]
    history = defaultdict(list)
    for r in rows:
        history[r["player"]].append(r)
    for rs in history.values():
        rs.sort(key=lambda r: moment(r["date"]))
    times = {p: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for p, rs in history.items()}

    def counts(r):
        p = games[r["game"]]["players"][r["player"]]
        if (
            p["ver"] != 7
            or not p["played"]
            or p["started"] is not True
            or p["mins"] != r["minutes"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Native duel diagnosis identity differs")
        if not isinstance(p.get("stats"), dict):
            raise ValueError("Native scored stats unavailable")
        count = [p["stats"].get(k, [0, 0])[0] for k in ("duel_won", "duel_lost")]
        if r["pos"] == "DEF":
            points = sum(p["stats"].get(k, [0, 0])[1] for k in ("duel_won", "duel_lost"))
            if abs(1.5 * count[0] - 2 * count[1] - points) > 1e-7:
                raise ValueError("Native DEF duel weights differ")
        return count

    report = dict(
        scope="Earlier-only hindsight variation diagnosis, NOT a forecast or achievable accuracy gain",
        implementationKey=hashlib.sha256(
            (source["key"] + model_report["implementationKey"]).encode()
            + Path(__file__).read_bytes()
            + args.out.with_suffix(".plan.json").read_bytes()
        ).hexdigest(),
        sourceKey=source["key"],
        controlImplementationKey=model_report["implementationKey"],
        warning="Baseline D/p are strict-past3 diagnostic references, not the score model's explicit component estimates. Actual future duels/minutes/DS only diagnose earlier misses. No2026association or newmodel fit.",
        periods={},
    )
    diagnostics, native_cases = [], 0
    for phase, begin, end in PHASES:
        selected = [r for r in rows if begin <= r["date"] < end]
        with np.load(
            args.cache / f"laliga_score_native_sot_conditioning_start_{phase}_native_sot_ordinary_all_prediction.npz"
        ) as f:
            if str(f["key"]) != model_report["implementationKey"]:
                raise ValueError("Frozen earlier control key differs")
            np.testing.assert_array_equal(f["y"], [r["score"] for r in selected])
            pred = f["control"]
        if (
            measure(np.array([r["score"] for r in selected]), pred)
            != model_report["cohorts"]["start"]["earlierPeriods"][phase]["control"]
        ):
            raise ValueError("Frozen original control metrics differ")
        group, all_defenders = [], 0
        for r, prediction in zip(selected, pred, strict=True):
            actual_won, actual_lost = counts(r)
            native_cases += 1
            if r["pos"] != "DEF":
                continue
            all_defenders += 1
            if r["level"] != 35:
                continue
            lock = cutoff_for(r["date"])
            end_i = bisect_left(times[r["player"]], lock.timestamp())
            past = [p for p in history[r["player"]][:end_i] if lock - moment(p["date"]) <= timedelta(days=365)][-3:]
            known = None
            if len(past) == 3:
                old = [counts(p) for p in past]
                wins, lost = np.array(old).sum(axis=0)
                minutes = sum(p["minutes"] for p in past)
                if wins + lost > 0 and minutes > 0:
                    predicted_minutes = float(np.median([p["minutes"] for p in past]))
                    exact_wins, exact_lost, exact_minutes, exact_prediction = (
                        Fraction(str(v)) for v in (wins, lost, minutes, predicted_minutes)
                    )
                    volume = (exact_wins + exact_lost) * exact_prediction / exact_minutes
                    known = decompose(volume, exact_wins / (exact_wins + exact_lost), actual_won, actual_lost)
            record = dict(
                phase=phase,
                game=r["game"],
                player=r["player"],
                date=r["date"],
                actualMinutes=r["minutes"],
                score=r["score"],
                controlPrediction=float(prediction),
                error=float(r["score"] - prediction),
                priorCases=len(past),
                decomposition=known,
            )
            group.append(record)
            diagnostics.append(record)
        missed = [r for r in group if abs(r["error"]) > 7]
        correct = [r for r in group if abs(r["error"]) <= 7]
        large = [r for r in group if abs(r["error"]) > 25]
        result = dict(
            allStarterCases=len(selected),
            allDefenderCases=all_defenders,
            ordinaryBaseDefenderCases=len(group),
            correct=aggregate(correct),
            missed=aggregate(missed),
            largeMisses=aggregate(large),
            missedPlayedAtLeast60=aggregate([r for r in missed if r["actualMinutes"] >= 60]),
        )
        report["periods"][phase] = result
        print("DUEL_MISS_PERIOD " + json.dumps(dict(phase=phase, **result)), flush=True)
    if native_cases != 16522:
        raise ValueError("Full earlier starter denominator changed")
    gate = all((v["missed"]["volumeDominatesFraction"] or 0) >= 0.5 for v in report["periods"].values())
    report.update(
        nativeEarlierCasesVerified=native_cases,
        volumeHeadroomGate=gate,
        disposition="Only headroom supported, still needs distinct prelock signal"
        if gate
        else "DECLINE volume-only shared-duel-budget formula; winning-fraction changes dominate or volume headroom not stable",
        diagnosticRecords=diagnostics,
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
    print(
        "DUEL_MISS_DIAGNOSIS "
        + json.dumps(dict(nativeEarlierCases=native_cases, volumeHeadroomGate=gate, disposition=report["disposition"])),
        flush=True,
    )


if __name__ == "__main__":
    main()
