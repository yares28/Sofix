"""Independent source, signed Gaussian context, full population, and time audit."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
from bisect import bisect_left
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta
from functools import cache
from pathlib import Path

import numpy as np

from app.research import score_spatial_context as study
from app.research.score_search import cutoff_for, moment

STREAMS = ("takeon_start", "cross_end", "long_forward_end", "third_entry_end")


def kernel(points, lane, reverse):
    if points is None:
        return np.full(6, np.nan)
    event = np.array(points, dtype=float).reshape(-1, 3)
    values = [len(event), sum(p[2] for p in points)]
    if lane is None:
        return np.array([*values, *([np.nan] * 4)])
    x = event[:, 0] if not reverse else 100.0 - event[:, 0]
    y = event[:, 1] if not reverse else 100.0 - event[:, 1]
    lateral = np.exp(-((y - lane[1]) ** 2) / 800.0)
    local = lateral * np.exp(-((x - lane[0]) ** 2) / 1250.0)
    return np.array([*values, local.sum(), (local * event[:, 2]).sum(), lateral.sum(), (lateral * event[:, 2]).sum()])


def verify_raw(repo, games, qualified, lanes, sides):
    tokens = lambda s: tuple(re.findall("[a-z]+", (s or "").lower()))
    side_lookup = {(r["game"], r["club"]): r for r in sides}
    grouped_lanes = {(r["game"], r["player"]): r for r in lanes}
    grouped_people = defaultdict(list)
    for r in qualified:
        grouped_people[r["game"]].append(r)
    facts, verified_lanes, source_fixtures, native_passes = {}, {}, set(), 0
    for r in sides:
        game_id = r["game"]
        if game_id in source_fixtures:
            continue
        raw = (repo / r["sourcePath"]).read_bytes().replace(b"\r\n", b"\n")
        if hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() != r["sourceBlob"]:
            raise ValueError("Pinned raw source changed")
        detail = json.loads(raw.decode().partition("=")[2].strip().removesuffix(";"))
        native = games[game_id]
        actor_points = defaultdict(list)
        for side in ("home", "away"):
            club = native[side]["slug"]
            cached = side_lookup[game_id, club]
            if (
                cached["date"] != native["date"]
                or cached["opponent"] != native["away" if side == "home" else "home"]["slug"]
            ):
                raise ValueError("Canonical raw-source identity differs")
            events = [e for e in detail.get("passes") or [] if e.get("team") == side]
            native_passes += len(events)
            invalid = sum(type(e.get("ok")) is not bool or type(e.get("cross")) is not bool for e in events)
            complete = lambda e, keys: all(
                type(e.get(k)) in (int, float) and math.isfinite(e[k]) and 0 < e[k] < 100 for k in keys
            )
            all_geometry = [e for e in events if complete(e, ("x", "y", "ex", "ey"))]
            good = [e for e in all_geometry if type(e.get("ok")) is bool and type(e.get("cross")) is bool]
            categories = {s: [] for s in STREAMS[1:]}
            for e in good:
                point = [e["ex"], e["ey"], int(e["ok"])]
                if e["cross"]:
                    categories["cross_end"].append(point)
                dx, dy = e["ex"] - e["x"], e["ey"] - e["y"]
                if dx >= 15 and dx**2 + dy**2 >= 900:
                    categories["long_forward_end"].append(point)
                if e["x"] < 200 / 3 and e["ex"] >= 200 / 3:
                    categories["third_entry_end"].append(point)
            pass_known = isinstance(detail.get("passes"), list)
            p = cached["passes"]
            if (
                pass_known != p["known"]
                or (len(events) if pass_known else None) != p["passCount"]
                or (invalid if pass_known else None) != p["invalidFlags"]
            ):
                raise ValueError("Raw pass source presence/count/flag differs")
            if pass_known and (
                p["unknownCoordinates"] != len(events) - len(all_geometry) or p["categories"] != categories
            ):
                raise ValueError(
                    "Raw endpoint subset differs: "
                    + json.dumps(
                        dict(
                            game=game_id,
                            club=club,
                            columns={s: [len(categories[s]), len(p["categories"][s])] for s in categories},
                            boundary=[p["unknownCoordinates"], len(events) - len(all_geometry)],
                        )
                    )
                )
            takeons = [e for e in detail.get("dribbles") or [] if e.get("team") == side]
            points = [
                [e["x"], e["y"], int(e["ok"])] for e in takeons if type(e.get("ok")) is bool and complete(e, ("x", "y"))
            ]
            if points != cached["takeons"]:
                raise ValueError("Native TakeOn points differ")
            native_successes = sum(
                person["stats"].get("won_contest", [0, 0])[0]
                for person in native["players"].values()
                if person.get("played") is True and person.get("team") == club and person.get("ver") == 7
            )
            if cached["nativeWonContest"] != native_successes:
                raise ValueError("Native TakeOn success total differs")
            tk_known = isinstance(detail.get("dribbles"), list)
            tk_invalid = sum(type(e.get("ok")) is not bool for e in takeons)
            tk_success = sum(e["ok"] for e in takeons) if not tk_invalid and tk_known else None
            if cached["countsVerified"] != (tk_success is not None and tk_success == native_successes):
                raise ValueError("Native/source TakeOn agreement differs")
            observed = pass_known and bool(events) and not invalid
            values = {s: categories[s] if observed else None for s in STREAMS[1:]}
            values["takeon_start"] = points if observed and tk_known and not tk_invalid else None
            facts[game_id, club] = dict(
                date=native["date"],
                observed=observed,
                boundary=(len(events) - len(all_geometry)) / len(events) if observed else np.nan,
                agreement=float(cached["countsVerified"]) if values["takeon_start"] is not None else np.nan,
                streams=values,
            )
            for e in events:
                if complete(e, ("x", "y")):
                    actor_points[side, tokens(e.get("player"))].append((e["x"], e["y"]))
        for person in grouped_people[game_id]:
            expected, count = None, 0
            if person["passSourceQuality"]["known"]:
                side = "home" if native["home"]["slug"] == person["club"] else "away"
                points = actor_points[side, tokens(person["geometrySource"]["player"])]
                count = len(points)
                if points:
                    mx = math.fsum(x for x, y in points) / count
                    my = math.fsum(y for x, y in points) / count
                    expected = [
                        mx,
                        my,
                        math.sqrt(math.fsum((x - mx) ** 2 for x, y in points) / count),
                        math.sqrt(math.fsum((y - my) ** 2 for x, y in points) / count),
                    ]
            cached = grouped_lanes[game_id, person["player"]]
            if (
                any(cached[k] != person[k] for k in ("date", "game", "player", "club", "cohort", "minutes"))
                or cached["sourceStarts"] != count
            ):
                raise ValueError("Native historical lane identity/count differs")
            if (expected is None) != (cached["lane"] is None):
                raise ValueError("Native historical lane presence differs")
            if expected is not None:
                np.testing.assert_allclose(expected, cached["lane"], rtol=0, atol=1e-10)
            verified_lanes[game_id, person["player"]] = expected
        source_fixtures.add(game_id)
    if len(verified_lanes) != len(qualified) or len(facts) != 2436:
        raise ValueError("Independent spatial source coverage differs")
    return verified_lanes, facts, native_passes


def reconstruct(rows, games, lanes, facts, names):
    player, club = defaultdict(list), defaultdict(list)
    for r in rows:
        player[r["player"], r["cohort"]].append(r)
    for g in games.values():
        for side in ("home", "away"):
            club[g[side]["slug"]].append(g)
    for history in (player, club):
        for records in history.values():
            records.sort(key=lambda r: moment(r["date"]))
    player_times = {
        key: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for key, rs in player.items()
    }
    club_times = {key: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for key, rs in club.items()}

    def select(history, times, key, lock, n):
        end = bisect_left(times.get(key, []), lock.timestamp())
        return [r for r in history.get(key, [])[:end] if moment(r["date"]) >= lock - timedelta(days=365)][-n:]

    @cache
    def history(team, lock, n):
        native = select(club, club_times, team, lock, n)
        observed = [facts[g["id"], team] for g in native if (g["id"], team) in facts]
        trusted = [r for r in observed if r["observed"]]
        quality = [
            len(native),
            len(trusted),
            (lock - moment(trusted[-1]["date"])).total_seconds() / 86400 if trusted else np.nan,
            math.fsum(r["boundary"] for r in trusted) / len(trusted) if trusted else np.nan,
            np.mean([r["agreement"] for r in observed if np.isfinite(r["agreement"])])
            if any(np.isfinite(r["agreement"]) for r in observed)
            else np.nan,
        ]
        streams = {s: [r["streams"][s] for r in observed if r["streams"][s] is not None] for s in STREAMS}
        return quality, streams

    @cache
    def exposure(game_id, person, stream):
        g = games[game_id]
        own = g["players"][person]["team"]
        opponent = g["away"]["slug"] if own == g["home"]["slug"] else g["home"]["slug"]
        fact = facts.get((game_id, opponent))
        points = fact["streams"][stream] if fact else None
        return kernel(points, lanes.get((game_id, person)), True)[2:]

    output = np.full((len(rows), 220), np.nan)
    for i, r in enumerate(rows):
        lock, values = cutoff_for(r["date"]), []
        g = games[r["game"]]
        own = g["players"][r["player"]]["team"]
        opponent = g["away"]["slug"] if own == g["home"]["slug"] else g["home"]["slug"]
        for n in (3, 10):
            past = select(player, player_times, (r["player"], r["cohort"]), lock, n)
            known = [p for p in past if lanes.get((p["game"], p["player"])) is not None and p["minutes"] > 0]
            weight = sum(p["minutes"] for p in known)
            lane = None
            if weight:
                lane = [
                    math.fsum(lanes[p["game"], p["player"]][j] * p["minutes"] for p in known) / weight for j in (0, 1)
                ]
                spread = [
                    math.sqrt(
                        max(
                            0,
                            math.fsum(
                                (lanes[p["game"], p["player"]][j + 2] ** 2 + lanes[p["game"], p["player"]][j] ** 2)
                                * p["minutes"]
                                for p in known
                            )
                            / weight
                            - lane[j] ** 2,
                        )
                    )
                    for j in (0, 1)
                ]
            values.extend(
                [
                    len(past),
                    len(known),
                    weight,
                    (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan,
                    *(lane + spread if lane is not None else [np.nan] * 4),
                ]
            )
            upcoming = {}
            for team, reverse in ((own, False), (opponent, True)):
                quality, streams = history(team, lock, n)
                values.extend(quality)
                for s in STREAMS:
                    groups = streams[s]
                    computed = (
                        np.mean([kernel(points, lane, reverse) for points in groups], axis=0)
                        if groups
                        else np.full(6, np.nan)
                    )
                    values.extend([len(groups), *computed])
                    if reverse:
                        upcoming[s] = computed[2:]
            past_pressure = {}
            for s in STREAMS:
                previous = [exposure(p["game"], r["player"], s) for p in past]
                valid = [p for p in previous if np.isfinite(p).all()]
                averages = np.mean(valid, axis=0) if valid else np.full(4, np.nan)
                values.extend([len(valid), *averages])
                past_pressure[s] = averages
            for s in STREAMS:
                values.extend(upcoming[s] - past_pressure[s])
        output[i] = values
        if (i + 1) % 5000 == 0:
            print(f"SPATIAL_AUDIT_ROWS {i + 1}/{len(rows)}", flush=True)
    if len(names) != output.shape[1]:
        raise ValueError("Independent feature shape differs")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--report", type=Path, default=Path("reports/experiments/laliga_score_spatial_context.json"))
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    native_raw = args.games.read_bytes()
    qualified_raw = (args.cache / "pass_source_qualified_observations.json.gz").read_bytes()
    pressure_raw = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    source = json.loads((args.cache / "cases.json").read_text())
    key = hashlib.sha256(
        source["key"].encode()
        + native_raw
        + qualified_raw
        + pressure_raw
        + Path(study.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if key != report["implementationKey"] or report["sourceKey"] != source["key"]:
        raise ValueError("Spatial core/source/plan differs")
    games = {g["id"]: g for g in (json.loads(line) for line in native_raw.decode().splitlines() if line.strip())}
    archive = (args.cache / "spatial_context_lanes.json.gz").read_bytes()
    feature_path = args.cache / "spatial_context_features.npz"
    if (
        hashlib.sha256(archive).hexdigest() != report["lanesSha256"]
        or hashlib.sha256(feature_path.read_bytes()).hexdigest() != report["featuresSha256"]
    ):
        raise ValueError("Spatial artifacts changed")
    lanes = json.loads(gzip.decompress(archive))["records"]
    qualified = json.loads(gzip.decompress(qualified_raw))["records"]
    sides = json.loads(gzip.decompress(pressure_raw))["observations"]
    raw_lanes, facts, pass_count = verify_raw(args.repo, games, qualified, lanes, sides)
    print(f"SPATIAL_RAW_VERIFIED {len(raw_lanes)} lanes {len(facts)} sides {pass_count} passes", flush=True)
    with np.load(feature_path) as f:
        x, names = f["x"], f["names"].tolist()
        if str(f["key"]) != report["featureKey"]:
            raise ValueError("Spatial feature key differs")
    independent = reconstruct(source["rows"], games, raw_lanes, facts, names)
    np.testing.assert_allclose(x, independent, rtol=0, atol=1e-9, equal_nan=True)
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    changed_lanes, changed_sides, changed_rows, changed_games = deepcopy((lanes, sides, source["rows"], games))
    lane_count, side_count, case_count = 0, 0, 0
    for r in changed_lanes:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            r["lane"], r["minutes"] = [99, 1, 90, 90], 1e6
            lane_count += 1
    for r in changed_sides:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            r["takeons"] = [[50, 20, 1]] * 100
            for s in STREAMS[1:]:
                r["passes"]["categories"][s] = [[60, 10, 0]] * 100
            r["passes"]["passCount"], r["passes"]["unknownCoordinates"] = 1, 0
            r["countsVerified"] = not r["countsVerified"]
            side_count += 1
    for r in changed_rows:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            r.update(minutes=1e6, score=100, aa=99, level=80, pos="GK")
            case_count += 1
    for g in changed_games.values():
        if moment(g["date"]) + timedelta(hours=48) >= first:
            g["homeGoals"], g["awayGoals"], g["xi"] = 9, 9, None
            for p in g["players"].values():
                p.update(stats=None, mins=1e6, score=100, aa=99, level=80, pos="GK")
    mutated, mutated_names = study.build_features(changed_rows, changed_games, changed_lanes, changed_sides)
    if mutated_names != names:
        raise ValueError("Mutated feature schema changed")
    np.testing.assert_array_equal(mutated[indices], x[indices])
    output = dict(
        implementationKey=key,
        featureKey=report["featureKey"],
        nativeLaneObservationsVerified=len(raw_lanes),
        nativeSourceSidesVerified=len(facts),
        rawPassMovementsVerified=pass_count,
        independentlyRecomputedRows=len(independent),
        independentlyRecomputedColumns=independent.shape[1],
        actualFutureMutation=dict(
            firstLock=first.isoformat(),
            rows=len(indices),
            unavailableLanesChanged=lane_count,
            unavailableSidesChanged=side_count,
            unavailableCasesChanged=case_count,
            all220columnsExact=True,
        ),
        scope="Source/feature verification only, no accuracy or50percent claim",
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("SPATIAL_CONTEXT_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
