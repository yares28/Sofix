"""Check whether earlier defender-role gains transfer to frozen xScore."""

import hashlib
import json

import numpy as np

from app.research.score_absence_role_signal import REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_defender_role_pressure import STEM as COMPONENT
from app.research.score_search import measure
from app.research.score_stats_run import paired_interval
from app.research.score_team_routine_shift import metrics
from app.research.score_windows import window_centres

STEM = "laliga_score_defender_role_bench_integration"
KEY = "04f46a9b7f9709260ec765b80c00701db41a8bc3078d7684c6c1557f33a7f610"


def main():
    component = json.loads((REPORTS / (COMPONENT + ".json")).read_bytes())
    effect_raw = (ROOT / (COMPONENT + "_bench_effect.json")).read_bytes()
    assert component["gate"]["bench"]["joint"]["passEarlier"]
    assert hashlib.sha256(effect_raw).hexdigest() == component["benchEffectSHA"]
    effect = json.loads(effect_raw)
    previous = json.loads((REPORTS / "laliga_score_mixture_shrunk.json").read_bytes())
    reference = previous["cohorts"]["bench"]["winner"]
    spec = reference["spec"]
    assert previous["implementationKey"] == KEY and spec == {"model": "k2_width32_l2verystrong", "scope": "all"}
    cases = json.loads((ROOT / "cases.json").read_bytes())
    assert previous["sourceKey"] == cases["key"]
    output = {}
    for phase, (begin, end) in PHASES.items():
        rows = [r for r in cases["rows"] if begin <= r["date"] < end and r["cohort"] == "bench"]
        y = np.array([r["score"] for r in rows])
        path = ROOT / f"laliga_score_mixture_shrunk_bench_{phase}_{spec['model']}_e160.npz"
        with np.load(path) as f:
            mass = f["mass"]
            assert mass.shape == (len(rows), 201)
        control = window_centres(mass, np.arange(0, 100.5, 0.5))
        assert measure(y, control) == reference["periods"][phase]["metrics"]
        changes = {(game, slug): value for game, slug, value in effect[phase]}
        assert len(changes) == len(effect[phase]) and set(changes) <= {
            (r["game"], r["player"]) for r in rows if r["pos"] == "DEF"
        }
        delta = np.array([changes.get((r["game"], r["player"]), 0) for r in rows])
        candidate = np.clip(control + delta, 0, 100)
        output[phase] = dict(
            **metrics(y, control, candidate),
            changed=int(np.count_nonzero(control != candidate)),
            within7Gain95=paired_interval(y, candidate, control, [r["week"] for r in rows]),
            referenceCacheSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    pooled_net = sum(r["gained"] - r["lost"] for r in output.values())
    mean_gain = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in output.values()) / sum(
        r["n"] for r in output.values()
    )
    pass_earlier = pooled_net > 0 and mean_gain > 0 and all(r["gained"] >= r["lost"] for r in output.values())
    result = dict(
        sourceKey=cases["key"],
        frozenReferenceKey=KEY,
        componentEffectSHA=component["benchEffectSHA"],
        phases=output,
        netHits=pooled_net,
        meanErrorGain=mean_gain,
        passEarlier=pass_earlier,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
