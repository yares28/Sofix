"""Testing only: verified past European XI/shape facts added to domestic team histories."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import zipfile
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_search
from app.research import score_team_shape_history as shape
from app.research.score_search import cutoff_for, moment

SOURCES = ("euro", "combined")
NAMES = tuple(f"europe_shape_{s}_" + n.removeprefix("shape_") for s in SOURCES for n in shape.NAMES)


def euro_team_records(game, labels, receipt):
    if game.get("statusTyped") != "played":
        return []
    records = []
    for side, other in (("home", "away"), ("away", "home")):
        club = (game.get(side + "Team") or {}).get("slug")
        opponent = (game.get(other + "Team") or {}).get("slug")
        if not game.get("id") or not game.get("date") or not club or not opponent or club == opponent:
            raise ValueError("Native European team-shape fixture identity/date/sides missing")
        formation = game.get(side + "Formation") or {}
        lines = formation.get("startingLineup") or []
        flat = [p.get("slug") for line in lines for p in line]
        published = (
            formation.get("startingLineupAvailable") is True and len(flat) == 11 and len(set(flat)) == 11 and all(flat)
        )
        facts = {}
        conflict = False
        for r in game.get("playerGameScores") or []:
            s = r.get("anyPlayerGameStats") or {}
            player = (r.get("anyPlayer") or {}).get("slug")
            minutes = s.get("minsPlayed")
            if (
                not player
                or s.get("playedInGame") is not True
                or (s.get("anyTeam") or {}).get("slug") != club
                or type(minutes) not in (int, float)
                or not math.isfinite(minutes)
                or not 1 <= minutes <= 120
            ):
                continue
            try:
                cohort = ordinary.observed_cohort(player, s, formation)
            except ValueError:
                conflict = True
                receipt["nativeCohortConflicts"] += 1
                continue
            value = (cohort, ordinary.POSITIONS.get(r.get("positionTyped")))
            if player in facts and facts[player] != value:
                conflict = True
                receipt["ambiguousPositiveNativeFacts"] += 1
            facts[player] = value
        starters = {p for p, (cohort, _) in facts.items() if cohort == "start"}
        xi = sorted(starters) if len(starters) == 11 and not conflict else None
        signature = (
            tuple(len(line) for line in lines[1:])
            if published
            and xi is not None
            and set(flat) == starters
            and len(lines) >= 2
            and len(lines[0]) == 1
            and all(lines)
            and facts.get(flat[0], (None, None))[1] == "GK"
            else None
        )
        points = []
        for (game_id, player), r in labels.items():
            if (
                game_id != game["id"]
                or r["club"] != club
                or r["cohort"] not in ("start", "bench")
                or r["ordinary"]["kind"] != "exact"
            ):
                continue
            value = r["ordinary"]["point"]
            if (
                r["source"] != "euro"
                or r["pos"] not in ("GK", "DEF", "MID", "FWD")
                or type(value) not in (int, float)
                or not math.isfinite(value)
            ):
                raise ValueError("European formation AA requires verified exact native-v7 label")
            points.append(dict(player=player, pos=r["pos"], cohort=r["cohort"], aa=float(value), shape=signature))
        receipt["teamSides"] += 1
        receipt["published11"] += bool(published)
        receipt["nativeVerified11"] += xi is not None
        receipt["nativeVerifiedShape"] += signature is not None
        receipt["exactKnownCohortAALabels"] += len(points)
        records.append(
            dict(
                game=game["id"],
                date=game["date"],
                club=club,
                opponent=opponent,
                source="euro",
                xi=xi,
                shape=signature,
                labels=points,
            )
        )
    return records


def features_for(rows, targets, records):
    by_game = {g["id"]: g for g in targets}
    if len(by_game) != len(targets):
        raise ValueError("Duplicate canonical European-shape target fixture")
    queue = sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["club"]))
    histories, people = defaultdict(list), defaultdict(list)
    index = 0
    output = np.full((len(rows), len(shape.NAMES)), np.nan)
    locks = [cutoff_for(r["date"]) for r in rows]
    for i in sorted(range(len(rows)), key=lambda j: locks[j]):
        row, lock = rows[i], locks[i]
        while index < len(queue) and moment(queue[index]["date"]) + timedelta(hours=48) < lock:
            record = queue[index]
            histories[record["club"]].append(record)
            for label in record["labels"]:
                people[label["player"], record["club"], label["pos"], label["cohort"]].append(
                    {**label, "date": record["date"]}
                )
            index += 1
        game = by_game.get(row["game"])
        person = (game or {}).get("players", {}).get(row["player"])
        if game is None or person is None or game["date"] != row["date"]:
            raise ValueError("Canonical European-shape target identity/date missing")
        club = person.get("team")
        if club not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Canonical European-shape actual playing side unknown")
        opponent = game["away"]["slug"] if club == game["home"]["slug"] else game["home"]["slug"]
        own = [r for r in histories[club] if moment(r["date"]) >= lock - timedelta(days=365)]
        other = [r for r in histories[opponent] if moment(r["date"]) >= lock - timedelta(days=365)]
        pool = [
            r
            for r in people[row["player"], club, row["pos"], row["cohort"]]
            if moment(r["date"]) >= lock - timedelta(days=365)
        ][-20:]
        values = {}
        for side, hist in (("own", own), ("opponent", other)):
            for n in (3, 10):
                values.update({f"shape_{side}_{n}_{f}": v for f, v in shape.team_summary(hist[-n:]).items()})
            for field, wanted in (("last_xi", "xi"), ("last_shape", "shape")):
                known = [r for r in hist if r[wanted] is not None]
                values[f"shape_{side}_{field}_days_to_lock"] = (
                    (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan
                )
        starts_all = [r for r in own if r["xi"] is not None and row["player"] in r["xi"]]
        for n in (3, 10):
            recent = own[-n:]
            known = [r for r in recent if r["xi"] is not None]
            starts = [r for r in known if row["player"] in r["xi"]]
            latest = set(known[-1]["xi"]) - {row["player"]} if known else set()
            individual = dict(
                start_fraction=len(starts) / len(known) if known else np.nan,
                latest_xi_starter=float(row["player"] in recent[-1]["xi"])
                if recent and recent[-1]["xi"] is not None
                else np.nan,
                usual_unit_overlap=float(np.mean([len((set(r["xi"]) - {row["player"]}) & latest) / 10 for r in starts]))
                if starts
                else np.nan,
                last_start_days_to_lock=(lock - moment(starts_all[-1]["date"])).total_seconds() / 86400
                if starts_all
                else np.nan,
            )
            values.update({f"shape_player_{n}_{f}": v for f, v in individual.items()})
            values.update({f"shape_aa_{n}_{f}": v for f, v in shape.aa_summary(pool, recent).items()})
        output[i] = [values[n] for n in shape.NAMES]
    return output


def build_features(rows, targets, records):
    arrays = [
        features_for(rows, targets, [r for r in records if source == "combined" or r["source"] == "euro"])
        for source in SOURCES
    ]
    result = np.column_stack(arrays)
    if result.shape != (len(rows), 204) or np.isinf(result).any():
        raise ValueError("European-shape all-case schema/finite coverage differs")
    return result


def read_sources(games, archives, corpus):
    targets, records, digest = [], [], hashlib.sha256()
    for line in games.open("rb"):
        digest.update(line)
        if not line.strip():
            continue
        g = json.loads(line)
        targets.append(
            dict(
                id=g["id"],
                date=g["date"],
                home=g["home"],
                away=g["away"],
                players={p: dict(team=r.get("team")) for p, r in g["players"].items()},
            )
        )
        records.extend({**r, "source": "laliga"} for r in shape.team_records(g))
    if digest.hexdigest() != corpus["laligaSha256"]:
        raise ValueError("European-shape canonical native LL source differs")
    by_game = defaultdict(dict)
    for r in corpus["records"]:
        if r["source"] == "euro":
            by_game[r["game"]][r["game"], r["player"]] = r
    receipts = []
    for receipt in corpus["receipts"]:
        path = archives / receipt["archive"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != receipt["sha256"]:
            raise ValueError("European-shape native archive source differs")
        counter = Counter()
        with zipfile.ZipFile(path) as z:
            for member in sorted(z.namelist()):
                if not member.startswith("games/") or not member.endswith(".json"):
                    continue
                game = json.loads(z.read(member)).get("raw") or {}
                if game.get("statusTyped") == "played":
                    records.extend(euro_team_records(game, by_game[game["id"]], counter))
        receipts.append(dict(archive=path.name, sha256=receipt["sha256"], counts=dict(counter)))
    ids = [(r["game"], r["club"]) for r in records]
    if len(set(ids)) != len(ids):
        raise ValueError("Duplicate European/LL native team-side records")
    return targets, records, receipts, digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "routine-cache", "routine-report", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    native_report = json.loads(args.routine_report.read_text())
    native_audit = json.loads(args.routine_report.with_suffix(".integrity.json").read_text())
    raw = args.routine_cache.with_suffix(".observations.json.gz").read_bytes()
    corpus = json.loads(gzip.decompress(raw))
    plan_path = args.report.with_suffix(".plan.json")
    plan = json.loads(plan_path.read_text())
    if (
        corpus["key"] != native_report["featureKey"]
        or corpus["key"] != native_audit["featureKey"]
        or not native_audit["all160ColumnsReproduced"]
        or source["key"] != native_report["sourceKey"]
        or corpus["key"] not in plan["labels"]
    ):
        raise ValueError("European-shape scored history requires fully audited native routine corpus")
    targets, records, receipts, ll_sha = read_sources(args.games, args.archives, corpus)
    if ll_sha not in plan["source"] or any(r["sha256"] not in plan["source"] for r in receipts):
        raise ValueError("European-shape raw inputs differ from registered source plan")
    raw_sha = hashlib.sha256(raw).hexdigest()
    key = hashlib.sha256(
        (source["key"] + corpus["key"] + ll_sha + raw_sha + "".join(r["sha256"] for r in receipts)).encode()
        + Path(__file__).read_bytes()
        + Path(shape.__file__).read_bytes()
        + Path(ordinary.__file__).read_bytes()
        + Path(score_search.__file__).read_bytes()
        + plan_path.read_bytes()
    ).hexdigest()
    print(
        f"EUROPE_SHAPE_BUILD sides{len(records)} labels{sum(len(r['labels']) for r in records)} cases{len(source['rows'])} features204",
        flush=True,
    )
    x = build_features(source["rows"], targets, records)
    np.savez_compressed(args.out, key=key, x=x, names=NAMES)
    payload = dict(
        key=key, targets=targets, records=records, receipts=receipts, laligaSha256=ll_sha, routineCorpusSha256=raw_sha
    )
    args.out.with_suffix(".observations.json.gz").write_bytes(
        gzip.compress(json.dumps(payload, allow_nan=False).encode())
    )
    result = dict(
        scope="Testing-only European team-shape source/feature stage, no accuracy claim",
        sourceKey=source["key"],
        featureKey=key,
        routineFeatureKey=corpus["key"],
        routineCorpusSha256=raw_sha,
        cases=len(x),
        features=204,
        nativeTeamSides=len(records),
        knownXISides=sum(r["xi"] is not None for r in records),
        knownShapeSides=sum(r["shape"] is not None for r in records),
        exactKnownCohortAALabels=sum(len(r["labels"]) for r in records),
        receipts=receipts,
        laligaSha256=ll_sha,
        limitations=plan["limitations"],
    )
    args.report.write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
