"""Frozen audit adapter: full native candidate vectors and actual model refits."""

from app.research import score_geometry_conditioning_audit as audit
from app.research import score_spatial_conditioning as study


def main():
    # The reference audit derives every decision from native clipped-score samples.
    audit.study = study
    audit.main()


if __name__ == "__main__":
    main()
