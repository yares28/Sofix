"""Test whether teammates' recent routine-point changes carry forward."""

import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from statistics import median

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment

AGE = timedelta(days=180)
DELAY = timedelta(hours=48)
POSITIONS = ("GK", "DEF", "MID", "FWD")
STEM = "laliga_score_team_routine_shift"


def own_history(pool, lock):
    eligible = [v for date, v in pool[-12:] if date >= lock - AGE]
    long = median(eligible) if eligible else 0.0
    short = median(eligible[-3:]) if eligible else long
    return long, short, len(eligible)


def team_shift(records, exclude, position, lock):
    recent = []
    for date, unit in records[-3:]:
        if date < lock - timedelta(days=45):
            continue
        changes = [change for player, pos, change in unit if player != exclude and position == pos]
        if changes:
            recent.append(median(changes))
    # One match's change is especially noisy. Two matches also receive shrinkage.
    return float(median(recent) * len(recent) / (len(recent) + 2)) if len(recent) >= 2 else 0.0


def build_earlier(rows, games):
    fixtures = {g["id"]: g for g in games}
    if len(fixtures) != len(games):
        raise ValueError("Duplicate game")
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        groups[row["game"]].append(i)
    queue = sorted(
        ((moment(fixtures[k]["date"]), k, ids) for k, ids in groups.items()),
        key=lambda entry: (entry[0], entry[1]),
    )
    persons, clubs = defaultdict(list), defaultdict(list)
    deferred, cursor = {}, 0
    features = np.empty((len(rows), 8))
    baseline = np.empty(len(rows))
    # The lock clock is monotone in kickoff order.
    for _, game, indices in queue:
        lock = cutoff_for(fixtures[game]["date"])
        while cursor < len(queue) and queue[cursor][0] + DELAY < lock:
            date, previous, _ = queue[cursor]
            observations, team_records = deferred.pop(previous)
            for key, aa in observations:
                persons[key].append((date, aa))
            for club, record in team_records.items():
                clubs[club].append((date, record))
            cursor += 1
        fixture = fixtures[game]
        home, away = (fixture[side]["slug"] for side in ("home", "away"))
        observations, team_records = [], {home: [], away: []}
        for i in indices:
            row = rows[i]
            player, pos, cohort = (row[key] for key in ("player", "pos", "cohort"))
            person = fixture["players"][player]
            club = person["team"]
            if club not in team_records or row["date"] != fixture["date"] or not person.get("played"):
                raise ValueError("Fixture or playing side differs")
            key = player, club, pos, cohort
            long, short, n = own_history(persons[key], lock)
            baseline[i] = long
            features[i] = [
                *(float(pos == p) for p in POSITIONS),
                float(club == home),
                short - long,
                np.log1p(n),
                team_shift(clubs[club], player, pos, lock),
            ]
            aa = float(row["aa"])
            if abs(aa - float(person["aa"])) > 1e-7:
                raise ValueError("Ordinary-point outcome differs")
            observations.append((key, aa))
            if cohort == "start" and n >= 4:
                team_records[club].append((player, pos, float(np.clip(aa - long, -25, 25))))
        deferred[game] = observations, team_records
    return baseline, features


def fit(x, y, train, check):
    mean, sd = x[train].mean(axis=0), x[train].std(axis=0)
    sd[sd < 1e-6] = 1
    source, target = (x[train] - mean) / sd, (x[check] - mean) / sd
    observed = np.clip(y[train], -25, 25)
    weights = np.linalg.solve(source.T @ source + 100 * np.eye(source.shape[1]), source.T @ observed)
    return observed.mean() + target @ weights


def metrics(y, control, candidate):
    old, new = abs(y - control), abs(y - candidate)
    first, second = old <= 7, new <= 7
    return dict(
        n=len(y),
        mae=[float(old.mean()), float(new.mean())],
        hits=[int(first.sum()), int(second.sum())],
        gained=int((~first & second).sum()),
        lost=int((first & ~second).sum()),
        missesOver25=[int((old > 25).sum()), int((new > 25).sum())],
    )


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    rows = [r for r in json.loads((ROOT / "cases.json").read_bytes())["rows"] if r["date"] < "2026-01-01"]
    baseline, x = build_earlier(rows, games)
    y = np.array([r["aa"] for r in rows]) - baseline
    cohort = np.array([r["cohort"] for r in rows])
    date = np.array([r["date"] for r in rows])
    ready = np.array([moment(r["date"]) + DELAY for r in rows])
    phases = {}
    for name, (begin, end) in PHASES.items():
        window = (date >= begin) & (date < end)
        earliest_lock = min(cutoff_for(r["date"]) for r, selected in zip(rows, window, strict=True) if selected)
        phases[name] = {}
        for role in ("start", "bench"):
            train = (ready < earliest_lock) & (cohort == role)
            check = window & (cohort == role)
            control = fit(x[:, :-1], y, train, check)
            candidate = fit(x, y, train, check)
            phases[name][role] = dict(
                fitCount=int(train.sum()),
                nonzeroTeamShift=int(np.count_nonzero(x[check, -1])),
                **metrics(y[check], control, candidate),
            )
    output = dict(source=NATIVE_SHA, historyCases=len(rows), periods=phases, laterOutcomesEvaluated=False, gate={})
    for role in ("start", "bench"):
        records = [group[role] for group in phases.values()]
        pooled_mae_gain = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in records) / sum(r["n"] for r in records)
        pooled_hit_gain = sum(r["gained"] - r["lost"] for r in records)
        phases_without_loss = sum(r["mae"][1] <= r["mae"][0] and r["hits"][1] >= r["hits"][0] for r in records)
        output["gate"][role] = dict(
            pooledMAEGain=pooled_mae_gain,
            pooledHitGain=pooled_hit_gain,
            phasesWithoutLoss=phases_without_loss,
            passEarlier=pooled_mae_gain > 0 and pooled_hit_gain > 0 and phases_without_loss >= 2,
        )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
