"""Testing only: score modes from similar earlier same-position performances."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

from app.research.score_search import POSITIONS, bootstrap, cutoff_for, interval_mode, measure, moment
from app.research.score_shared_windows import normalise
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def eligible(available: np.ndarray, positions: np.ndarray, cutoff: float, position: str) -> np.ndarray:
    return (available < cutoff) & (positions == position)


def prepare_windows(scores: np.ndarray, centres: np.ndarray):
    order = np.argsort(scores, axis=1, kind="stable")
    sorted_scores = np.take_along_axis(scores, order, axis=1)
    low = np.array([np.searchsorted(s, centres - 7, side="left") for s in sorted_scores])
    high = np.array([np.searchsorted(s, centres + 7, side="right") for s in sorted_scores])
    return order, low, high


def weighted_prediction(weights: np.ndarray, prepared, centres: np.ndarray, fallback: np.ndarray):
    order, low, high = prepared
    sorted_weights = np.take_along_axis(weights, order, axis=1)
    cumulative = np.column_stack((np.zeros(len(weights)), np.cumsum(sorted_weights, axis=1)))
    mass = np.take_along_axis(cumulative, high, axis=1) - np.take_along_axis(cumulative, low, axis=1)
    prediction = window_centres(mass, centres)
    total = weights.sum(axis=1)
    confidence = np.divide(mass.max(axis=1), total, out=np.zeros(len(weights)), where=total > 0)
    prediction[total <= 0] = fallback[total <= 0]
    return prediction, np.clip(confidence, 0, 1)


def descriptor_groups(rows: list[dict], names: list[str], cohort: str):
    source = np.array([r["x"] for r in rows], dtype=np.float32)
    lookup = {n: i for i, n in enumerate(names)}
    selected = [
        f"{cohort}_10_{k}"
        for k in ("score", "aa", "level", "minutes", "score_q0.2", "score_q0.8", "score_sd", "role_depth", "role_edge")
    ]
    selected += [f"{cohort}_3_{k}" for k in ("score", "aa", "minutes")]
    selected += [
        f"{cohort}_rate_{s}"
        for s in (
            "goals",
            "goal_assist",
            "ontarget_scoring_att",
            "accurate_pass",
            "duel_won",
            "duel_lost",
            "won_tackle",
        )
    ]
    form = source[:, [lookup[n] for n in selected]]
    home = source[:, lookup["home"]] > 0
    context = np.column_stack(
        (
            home,
            np.where(home, source[:, lookup["match_lam_h"]], source[:, lookup["match_lam_a"]]),
            np.where(home, source[:, lookup["match_lam_a"]], source[:, lookup["match_lam_h"]]),
            np.where(home, source[:, lookup["match_cs_h"]], source[:, lookup["match_cs_a"]]),
            np.where(home, source[:, lookup["match_cs_a"]], source[:, lookup["match_cs_h"]]),
            source[
                :,
                [
                    lookup[n]
                    for n in (
                        "style_aa_per90",
                        "style_ontarget_scoring_att",
                        "style_accurate_pass",
                        "style_duel_won",
                        "style_won_tackle",
                    )
                ],
            ],
        )
    )
    return {"form_role": form, "form_role_match": np.column_stack((form, context))}


def lookup_neighbours(features, rows, selected, fit_scale, cache, key):
    if cache.exists():
        with np.load(cache) as stored:
            if str(stored["key"]) == key:
                return stored["indices"], stored["distance"]
    positions = np.array([r["pos"] for r in rows])
    available = np.array([moment(r["date"]).timestamp() + 48 * 3600 for r in rows])
    cutoffs = np.array([cutoff_for(r["date"]).timestamp() for r in rows])
    z = np.zeros_like(features)
    for pos in POSITIONS:
        mask = positions == pos
        fitted = fit_scale & mask
        scaled = normalise(features, fitted if fitted.sum() >= 20 else fit_scale)
        z[mask] = scaled[mask]
    indices = np.full((len(rows), 500), -1, dtype=np.int32)
    distance = np.full((len(rows), 500), np.inf, dtype=np.float32)
    for at in sorted(set(cutoffs[selected])):
        for pos in POSITIONS:
            target = np.flatnonzero(selected & (cutoffs == at) & (positions == pos))
            if not len(target):
                continue
            pool = np.flatnonzero(eligible(available, positions, at, pos))
            if not len(pool):
                continue
            width = min(500, len(pool))
            d, near = cKDTree(z[pool]).query(z[target], k=width, workers=4)
            indices[target, :width] = pool[np.asarray(near).reshape(len(target), width)]
            distance[target, :width] = np.asarray(d).reshape(len(target), width)
    indices, distance = indices[selected], distance[selected]
    np.savez_compressed(cache, key=key, indices=indices, distance=distance)
    return indices, distance


def prepare_lookup(rows, selected, fit, indices, distance):
    y = np.array([r["score"] for r in rows])
    positions = np.array([r["pos"] for r in rows])
    players = np.array([r["player"] for r in rows])
    available = np.array([moment(r["date"]).timestamp() + 48 * 3600 for r in rows])
    cutoff = np.array([cutoff_for(r["date"]).timestamp() for r in rows])[selected]
    valid = indices >= 0
    safe = np.maximum(indices, 0)
    scores = np.where(valid, y[safe], np.inf)
    age = np.maximum(0, (cutoff[:, None] - available[safe]) / 86400)
    own = (players[safe] == players[selected, None]) & valid
    modes = {
        p: interval_mode(y[fit & (positions == p)].tolist())
        if (fit & (positions == p)).any()
        else (45 if rows[0]["cohort"] == "start" else 38)
        for p in POSITIONS
    }
    fallback = np.array([modes[p] for p in positions[selected]])
    centres = np.arange(0, 100.01, 0.5)
    return {
        "valid": valid,
        "distance": distance,
        "age": age,
        "own": own,
        "fallback": fallback,
        "centres": centres,
        "windows": prepare_windows(scores, centres),
    }


def predict_lookup(prepared, spec):
    weights = (prepared["valid"] & (np.arange(500)[None, :] < spec["neighbours"])).astype(float)
    weights *= (1 + prepared["distance"]) ** -spec["distancePower"]
    weights *= np.exp2(-prepared["age"] / spec["halfLifeDays"])
    weights *= np.where(prepared["own"], spec["ownPlayerWeight"], 1)
    return weighted_prediction(weights, prepared["windows"], prepared["centres"], prepared["fallback"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "cache", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    key = hashlib.sha256(source["key"].encode() + Path(__file__).read_bytes()).hexdigest()
    report = {
        "target": "Actual LaLiga score within seven, starts and played substitutes separately, all cases",
        "method": "Weighted most-probable score interval from similar earlier performances, preserving player identity",
        "evidenceLimit": "Retrospective exploratory reuse, no new blind claim",
        "sourceKey": source["key"],
        "implementationKey": key,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        groups = descriptor_groups(rows, source["features"], cohort)
        candidates = []
        for name, features in groups.items():
            indices, distance = lookup_neighbours(
                features, rows, valid, train, args.cache / f"analogues_{cohort}_{name}_selection.npz", key
            )
            prepared = prepare_lookup(rows, valid, train, indices, distance)
            for k, power, own, life in itertools.product((25, 75, 200, 500), (0, 1, 2), (1, 4, 16), (180, 730)):
                spec = {
                    "group": name,
                    "neighbours": k,
                    "distancePower": power,
                    "ownPlayerWeight": own,
                    "halfLifeDays": life,
                }
                prediction, _ = predict_lookup(prepared, spec)
                candidates.append({**spec, "selection": measure(y[valid], prediction)})
            print(f"Selected {cohort} {name}", flush=True)
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        indices, distance = lookup_neighbours(
            groups[winner["group"]],
            rows,
            test,
            ~test,
            args.cache / f"analogues_{cohort}_{winner['group']}_later.npz",
            key,
        )
        prepared = prepare_lookup(rows, test, ~test, indices, distance)
        prediction, confidence = predict_lookup(prepared, winner)
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as baseline:
            if not np.array_equal(y[test], baseline["y"]):
                raise ValueError("Comparison cases differ")
            control = baseline["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        pos = np.array([r["pos"] for r in rows])[test]
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "staticControl": measure(y[test], control),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, control, weeks),
            "fallbackCases": int((~prepared["valid"].any(axis=1)).sum()),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "meanPredictedHitChance": float(confidence.mean()),
            "positions": {p: measure(y[test][pos == p], prediction[pos == p]) for p in POSITIONS if (pos == p).any()},
            "confidenceDiagnosticsOnly": {},
        }
        for name, mask in (("atLeast50", confidence >= 0.5), ("below50", confidence < 0.5)):
            result["confidenceDiagnosticsOnly"][name] = (
                measure(y[test][mask], prediction[mask]) if mask.any() else {"n": 0}
            )
        np.savez_compressed(
            args.cache / f"analogues_predictions_{cohort}.npz",
            prediction=prediction,
            confidence=confidence,
            y=y[test],
            key=key,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
