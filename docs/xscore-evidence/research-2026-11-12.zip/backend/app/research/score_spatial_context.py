"""Offline testing: signed historical player lanes and upcoming opponent movement."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from functools import lru_cache
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

STREAMS = ("takeon_start", "cross_end", "long_forward_end", "third_entry_end")
NEAR = ("near2_attempts", "near2_successes", "neary_attempts", "neary_successes")
LANE = ("native_games", "known_games", "known_minutes", "age_days", "x", "y", "sd_x", "sd_y")
QUALITY = ("native_games", "source_games", "age_days", "pass_boundary_fraction", "native_takeon_match_fraction")
MOVEMENT = ("known_games", "attempts", "successes", *NEAR)


def feature_names():
    result = []
    for n in (3, 10):
        result.extend(f"spatial_{n}_lane_{field}" for field in LANE)
        for side in ("own", "opponent"):
            result.extend(f"spatial_{n}_{side}_{field}" for field in QUALITY)
            result.extend(f"spatial_{n}_{side}_{stream}_{field}" for stream in STREAMS for field in MOVEMENT)
        result.extend(
            f"spatial_{n}_historical_opponent_{stream}_{field}"
            for stream in STREAMS
            for field in ("known_games", *NEAR)
        )
        result.extend(f"spatial_{n}_change_{stream}_{field}" for stream in STREAMS for field in NEAR)
    return result


def pressure(points, lane, mirror):
    if points is None:
        return [np.nan] * 6
    a = np.asarray(points, dtype=float).reshape(-1, 3)
    result = [float(len(a)), float(a[:, 2].sum())]
    if lane is None:
        return result + [np.nan] * 4
    xy = 100 - a[:, :2] if mirror else a[:, :2]
    dy = (xy[:, 1] - lane[1]) / 20
    gx = np.exp(-0.5 * (((xy[:, 0] - lane[0]) / 25) ** 2 + dy**2))
    gy = np.exp(-0.5 * dy**2)
    return result + [float(gx.sum()), float(gx @ a[:, 2]), float(gy.sum()), float(gy @ a[:, 2])]


def available(records, lock, n, cohort=None):
    return sorted(
        [
            r
            for r in records
            if moment(r["date"]) + timedelta(hours=48) < lock
            and lock - moment(r["date"]) <= timedelta(days=365)
            and (cohort is None or r["cohort"] == cohort)
        ],
        key=lambda r: moment(r["date"]),
    )[-n:]


def pooled_lane(records):
    known = [r for r in records if r.get("lane") is not None and r["minutes"] > 0]
    if not known:
        return None
    a = np.array([r["lane"] for r in known])
    weight = np.array([r["minutes"] for r in known])
    mean = np.average(a[:, :2], axis=0, weights=weight)
    second = np.average(a[:, 2:] ** 2 + a[:, :2] ** 2, axis=0, weights=weight)
    return [*mean, *np.sqrt(np.maximum(0, second - mean**2))]


def stream_points(side, stream):
    if side is None:
        return None
    passes = side["passes"]
    observed = passes["known"] and passes["passCount"] > 0 and passes["invalidFlags"] == 0
    if not observed:
        return None
    if stream == "takeon_start":
        return side["takeons"] if side["summary"]["known"] and side["summary"]["invalidFlags"] == 0 else None
    return passes["categories"][stream]


def build_features(rows, games, lanes, sides):
    people, clubs = defaultdict(list), defaultdict(list)
    lane_map = {(r["game"], r["player"]): r["lane"] for r in lanes}
    side_map = {(r["game"], r["club"]): r for r in sides}
    for row in rows:
        people[row["player"], row["cohort"]].append(
            {
                "game": row["game"],
                "date": row["date"],
                "minutes": row["minutes"],
                "lane": lane_map.get((row["game"], row["player"])),
            }
        )
    for game in games.values():
        for side in ("home", "away"):
            club = game[side]["slug"]
            clubs[club].append(dict(game=game["id"], date=game["date"], club=club))
    for histories in (people, clubs):
        for records in histories.values():
            records.sort(key=lambda r: moment(r["date"]))
    times = {
        ("player", *k): [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for k, rs in people.items()
    }
    times.update(
        {("club", k): [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for k, rs in clubs.items()}
    )

    def window(kind, key, lock, n):
        histories = people if kind == "player" else clubs
        records = histories.get(key, [])
        tkey = (kind, *key) if kind == "player" else (kind, key)
        end = bisect_left(times.get(tkey, []), lock.timestamp())
        return [r for r in records[max(0, end - n) : end] if lock - moment(r["date"]) <= timedelta(days=365)]

    @lru_cache(maxsize=None)
    def club_window(club, lock, n):
        records = window("club", club, lock, n)
        source = [side_map[r["game"], club] for r in records if (r["game"], club) in side_map]
        observed = [
            r
            for r in source
            if r["passes"]["known"] and r["passes"]["passCount"] > 0 and r["passes"]["invalidFlags"] == 0
        ]
        takeons = [r for r in observed if stream_points(r, "takeon_start") is not None]
        quality = [
            len(records),
            len(observed),
            (lock - moment(observed[-1]["date"])).total_seconds() / 86400 if observed else np.nan,
            np.mean([r["passes"]["unknownCoordinates"] / r["passes"]["passCount"] for r in observed])
            if observed
            else np.nan,
            np.mean([r["countsVerified"] for r in takeons]) if takeons else np.nan,
        ]
        streams = {}
        for stream in STREAMS:
            known = [points for r in source if (points := stream_points(r, stream)) is not None]
            streams[stream] = (len(known), [p for points in known for p in points] if known else None)
        return quality, streams

    @lru_cache(maxsize=None)
    def historic(game_id, player):
        game = games[game_id]
        club = game["players"][player]["team"]
        other = game["away"]["slug"] if club == game["home"]["slug"] else game["home"]["slug"]
        lane = lane_map.get((game_id, player))
        side = side_map.get((game_id, other))
        return {stream: pressure(stream_points(side, stream), lane, True)[2:] for stream in STREAMS}

    names = feature_names()
    result = np.full((len(rows), len(names)), np.nan)
    for i, row in enumerate(rows):
        game = games[row["game"]]
        club = game["players"][row["player"]]["team"]
        opponent = game["away"]["slug"] if club == game["home"]["slug"] else game["home"]["slug"]
        lock, values = cutoff_for(row["date"]), []
        for n in (3, 10):
            group = window("player", (row["player"], row["cohort"]), lock, n)
            known = [r for r in group if r["lane"] is not None and r["minutes"] > 0]
            lane = pooled_lane(group)
            values.extend(
                [
                    len(group),
                    len(known),
                    sum(r["minutes"] for r in known),
                    (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan,
                    *(lane if lane is not None else [np.nan] * 4),
                ]
            )
            next_opponent = {}
            for side_name, team in (("own", club), ("opponent", opponent)):
                quality, streams = club_window(team, lock, n)
                values.extend(quality)
                for stream in STREAMS:
                    count, points = streams[stream]
                    p = np.array(pressure(points, lane, side_name == "opponent"))
                    p = p / count if count else p
                    values.extend([count, *p])
                    if side_name == "opponent":
                        next_opponent[stream] = p[2:]
            previous = {}
            for stream in STREAMS:
                old = [historic(r["game"], row["player"])[stream] for r in group]
                valid = [p for p in old if np.isfinite(p).all()]
                p = np.mean(valid, axis=0) if valid else np.full(4, np.nan)
                values.extend([len(valid), *p])
                previous[stream] = p
            for stream in STREAMS:
                values.extend(next_opponent[stream] - previous[stream])
        result[i] = values
        if (i + 1) % 5000 == 0:
            print(f"SPATIAL_FEATURE_ROWS {i + 1}/{len(rows)}", flush=True)
    return result, names


def build_lanes(records, repo, sides):
    index = {r["game"]: (r["sourcePath"], r["sourceBlob"]) for r in sides}

    @lru_cache(maxsize=8)
    def raw_points(game):
        path, blob = index[game]
        raw = (repo / path).read_bytes().replace(b"\r\n", b"\n")
        if hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() != blob:
            raise ValueError("Pinned source blob changed")
        grouped = defaultdict(list)
        for p in json.loads(raw.decode().partition("=")[2].strip().removesuffix(";")).get("passes") or []:
            if all(type(p.get(k)) in (int, float) and np.isfinite(p[k]) and 0 < p[k] < 100 for k in ("x", "y")):
                grouped[p.get("team"), tuple(re.findall("[a-z]+", p.get("player", "").lower()))].append(
                    [p["x"], p["y"]]
                )
        return grouped

    result = []
    for r in records:
        lane, count = None, 0
        if r["passSourceQuality"]["known"]:
            name = tuple(re.findall("[a-z]+", (r["geometrySource"]["player"] or "").lower()))
            candidates = raw_points(r["game"])
            side = r["nativeSide"]
            points = candidates[side, name]
            if points:
                a = np.array(points, dtype=float)
                lane = [*a.mean(axis=0).tolist(), *a.std(axis=0).tolist()]
                count = len(a)
        result.append(
            {
                **{k: r[k] for k in ("game", "date", "player", "club", "cohort", "minutes")},
                "lane": lane,
                "sourceStarts": count,
            }
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_spatial_context.json"))
    args = parser.parse_args()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    qualified = (args.cache / "pass_source_qualified_observations.json.gz").read_bytes()
    pressure_raw = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    if (
        hashlib.sha256(qualified).hexdigest() != "a2892cc89775820d2c4835bd5803f9054c2b1635d11607ac1e2345aae05865d4"
        or hashlib.sha256(pressure_raw).hexdigest()
        != "daba17833020e8212346bb79f8b0918b69ab5e2a36ad60cc44d3fb1a4f7d064a"
    ):
        raise ValueError("Verified spatial source changed")
    audit = json.loads((args.out.parent / "laliga_score_pass_source_qualified.integrity.json").read_text())
    if (
        audit["sourceObservationsVerified"] != 34871
        or audit["independentlyRecomputedRows"] != 38850
        or not audit["actualFutureMutation"]["all166columnsExact"]
    ):
        raise ValueError("Qualified source audit incomplete")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    records = json.loads(gzip.decompress(qualified))["records"]
    records = [
        {**r, "nativeSide": "home" if games[r["game"]]["home"]["slug"] == r["club"] else "away"} for r in records
    ]
    sides = json.loads(gzip.decompress(pressure_raw))["observations"]
    source = json.loads((args.cache / "cases.json").read_text())
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + qualified
        + pressure_raw
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    lanes = build_lanes(records, args.repo, sides)
    archive = args.cache / "spatial_context_lanes.json.gz"
    archive.write_bytes(
        gzip.compress(
            json.dumps(dict(key=key, records=lanes), separators=(",", ":"), allow_nan=False).encode(), mtime=0
        )
    )
    x, names = build_features(source["rows"], games, lanes, sides)
    if x.shape != (38850, 220) or len(set(names)) != 220:
        raise ValueError("Frozen spatial schema changed")
    feature_key = hashlib.sha256((key + hashlib.sha256(archive.read_bytes()).hexdigest()).encode()).hexdigest()
    path = args.cache / "spatial_context_features.npz"
    np.savez_compressed(path, key=feature_key, source_key=source["key"], x=x, names=names)
    coverage = {}
    for cohort in ("start", "bench"):
        chosen = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        coverage[cohort] = dict(
            allCases=int(chosen.sum()),
            lane3Known=int(np.isfinite(x[chosen, names.index("spatial_3_lane_x")]).sum()),
            lane10Known=int(np.isfinite(x[chosen, names.index("spatial_10_lane_x")]).sum()),
        )
    report = dict(
        scope="Testing-only new spatial context, no prediction-accuracy claim",
        sourceKey=source["key"],
        implementationKey=key,
        featureKey=feature_key,
        lanesSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        featuresSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        rows=len(x),
        columns=len(names),
        lanes=len(lanes),
        knownLanes=sum(r["lane"] is not None for r in lanes),
        laterCoverage=coverage,
        status="Independent raw source/all220laggedcolumns/futuremutation audit REQUIRED before fitting",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
    print("SPATIAL_CONTEXT_BUILT " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
