import copy

import numpy as np

from app.research.score_sequence import sequence_features

NAMES = ["home", "match_lam_h", "match_lam_a", "match_cs_h", "match_cs_a"]


def case(date, score, game):
    level = 60 if score >= 60 else 0 if score == 0 else 35
    return {
        "player": "p",
        "game": game,
        "date": date,
        "cohort": "start",
        "pos": "MID",
        "score": score,
        "aa": score - level,
        "level": level,
        "minutes": 90,
        "x": [1, 1.4, 1.0, 0.35, 0.2],
    }


def test_exact_past_observation_and_its_match_context_are_preserved():
    rows = [case("2025-10-01T20:00:00Z", 40, "old"), case("2025-10-12T20:00:00Z", 80, "target")]
    x, names = sequence_features(rows, NAMES, np.array([4, 6]))
    assert x[-1, names.index("lag_same_1_score")] == 40
    assert x[-1, names.index("lag_same_1_own_goals")] == 1.4
    assert x[-1, names.index("lag_same_1_role")] == 4


def test_current_and_unavailable_same_week_outcomes_never_enter_sequence():
    rows = [
        case("2025-10-01T20:00:00Z", 40, "old"),
        case("2025-10-11T20:00:00Z", 80, "same"),
        case("2025-10-12T20:00:00Z", 20, "target"),
    ]
    before, _ = sequence_features(rows, NAMES, np.array([4, 5, 6]))
    changed = copy.deepcopy(rows)
    changed[1].update(score=0, aa=-10, minutes=1)
    changed[2].update(score=100, aa=40, minutes=90)
    after, _ = sequence_features(changed, NAMES, np.array([4, 8, 8]))
    np.testing.assert_array_equal(before[-1], after[-1])


def test_zero_and_missing_history_are_different():
    rows = [case("2025-10-01T20:00:00Z", 0, "old"), case("2025-10-12T20:00:00Z", 40, "target")]
    x, names = sequence_features(rows, NAMES, np.array([9, 4]))
    assert np.isnan(x[0, names.index("lag_same_1_score")])
    assert x[-1, names.index("lag_same_1_score")] == 0
    assert np.isnan(x[-1, names.index("lag_same_1_role")])


def test_alternating_past_states_have_a_different_next_state_signal():
    rows = [case(f"2025-09-{day:02d}T20:00:00Z", score, str(day)) for day, score in ((1, 40), (8, 80), (15, 40))]
    rows += [case("2025-10-12T20:00:00Z", 80, "target")]
    x, names = sequence_features(rows, NAMES, np.array([4, 4, 4, 4]))
    assert x[-1, names.index("state_score_next_2")] > x[-1, names.index("state_score_next_1")]
