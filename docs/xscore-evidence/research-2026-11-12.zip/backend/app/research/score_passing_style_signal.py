"""Test direct routine-score windows with score-dependent passing styles."""

import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_state_signal import probabilities
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_passing_style_signal"
AGE = timedelta(days=365)
OFFSETS = np.array([0, -3, 3, -6, 6, -10, 10, -14, 14, -20, 20])


class Rates:
    def __init__(self):
        self.data = deque()
        self.exposure = np.zeros(3)
        self.counts = np.zeros((4, 3))

    def add(self, item):
        self.data.append(item)
        self.exposure += item[1]
        self.counts += item[2]

    def features(self, lock, state_time, duration, prior):
        while self.data and self.data[0][0] < lock - AGE:
            _, exposure, counts = self.data.popleft()
            self.exposure -= exposure
            self.counts -= counts
        avg = (self.counts.sum(axis=1) + 180 * prior) / (self.exposure.sum() + 180)
        per_state = (self.counts + 240 * avg[:, None]) / (self.exposure + 240)
        return avg, np.r_[duration * avg, np.log1p(len(self.data))], (per_state - avg[:, None]) @ state_time


def features(rows, games, observations, names):
    available = sorted(
        [(moment(o["date"]) + DELAY, o) for o in observations],
        key=lambda record: (record[0], record[1]["game"], record[1]["player"]),
    )
    unit, personal, allowed = defaultdict(Rates), defaultdict(Rates), defaultdict(Rates)
    point_history = defaultdict(deque)
    point_queue = sorted([(moment(r["date"]) + DELAY, i) for i, r in enumerate(rows)], key=lambda item: item[0])
    own_home, own_away = (names.index(f"match_lam_{s}") for s in ("h", "a"))
    history_minutes = {role: names.index(f"{role}_10_minutes") for role in ("start", "bench")}
    players = [games[r["game"]]["players"][r["player"]] for r in rows]
    stat_names = (
        "accurate_pass",
        "missed_pass",
        "successful_final_third_passes",
        "accurate_long_balls",
        "long_pass_own_to_opp_success",
        "big_chance_created",
    )
    actual = np.array([sum(p["stats"].get(stat, (0, 0))[1] for stat in stat_names) for p in players])
    locks = [cutoff_for(r["date"]) for r in rows]
    base, own, opponent = np.empty((len(rows), 15)), np.empty((len(rows), 8)), np.empty((len(rows), 4))
    change = np.full(len(rows), np.nan)
    cursor = point_cursor = 0
    for i in sorted(range(len(rows)), key=locks.__getitem__):
        row, lock = rows[i], locks[i]
        while cursor < len(available) and available[cursor][0] < lock:
            ready, r = available[cursor]
            obs = ready - DELAY, np.asarray(r["exposure"]), np.asarray(r["passTypes"])
            key = r["club"], r["cohort"], r["position"]
            unit[key].add(obs)
            personal[r["player"], *key].add(obs)
            allowed[r["opponent"], r["cohort"], r["position"]].add(obs)
            cursor += 1
        while point_cursor < len(point_queue) and point_queue[point_cursor][0] < lock:
            ready, previous = point_queue[point_cursor]
            r = rows[previous]
            key = r["player"], players[previous]["team"], r["cohort"]
            point_history[key].append((ready - DELAY, actual[previous]))
            if len(point_history[key]) > 10:
                point_history[key].popleft()
            point_cursor += 1
        game = games[row["game"]]
        home, away = (game[s]["slug"] for s in ("home", "away"))
        club = players[i]["team"]
        assert row["date"] == game["date"] and club in (home, away)
        other = away if club == home else home
        x, role = row["x"], row["cohort"]
        state = probabilities(x[own_home], x[own_away]) if club == home else probabilities(x[own_away], x[own_home])
        duration = int(np.clip(round(x[history_minutes[role]]), 1, 90))
        state_time = (
            np.zeros(3) if state is None else (state[:duration] if role == "start" else state[-duration:]).sum(axis=0)
        )
        key = club, role, row["pos"]
        common, club_x, club_shift = unit[key].features(lock, state_time, duration, np.zeros(4))
        _, person_x, person_shift = personal[row["player"], *key].features(lock, state_time, duration, common)
        _, opp_x, opp_shift = allowed[other, role, row["pos"]].features(lock, state_time, duration, common)
        base[i] = np.r_[club_x, person_x, opp_x]
        own[i] = np.r_[club_shift, person_shift]
        opponent[i] = opp_shift
        previous_values = [v for t, v in point_history[row["player"], club, role] if t >= lock - AGE]
        if len(previous_values) >= 3:
            change[i] = actual[i] - np.median(previous_values)
    return base, own, opponent, change


def forecast(x, y, train, test):
    fit, check = x[train], x[test]
    mean, sd = fit.mean(axis=0), fit.std(axis=0)
    sd[sd < 1e-6] = 1
    fit, check = (fit - mean) / sd, (check - mean) / sd
    event = (np.abs(y[train, None] - OFFSETS) <= 7).astype(float)
    level = event.mean(axis=0)
    coefs = np.linalg.solve(fit.T @ fit + 200 * np.eye(fit.shape[1]), fit.T @ (event - level))
    return OFFSETS[np.argmax(level + check @ coefs, axis=1)]


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    data = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in data["rows"] if r["date"] < "2026-01-01"]
    archive = (ROOT / "laliga_score_passing_style_state.json").read_bytes()
    receipt = json.loads((REPORTS / "laliga_score_passing_style_state.source.json").read_bytes())
    assert hashlib.sha256(archive).hexdigest() == receipt["archiveSHA"]
    pooled, own, opposition, swing = features(rows, games, json.loads(archive), data["features"])
    native = np.array([r["x"] for r in rows])
    control = np.column_stack((native, pooled))
    x = {
        "control": control,
        "own": np.column_stack((control, own)),
        "both": np.column_stack((control, own, opposition)),
    }
    roles = np.array([r["cohort"] for r in rows])
    date = np.array([r["date"] for r in rows])
    ready = np.array([moment(r["date"]) + DELAY for r in rows])
    locks = np.array([cutoff_for(r["date"]) for r in rows])
    points = np.array([r["aa"] for r in rows])
    result = {}
    for phase, (begin, end) in PHASES.items():
        window = (date >= begin) & (date < end)
        earlier = ready < locks[window].min()
        result[phase] = {}
        for role in ("start", "bench"):
            y = points - native[:, data["features"].index(f"{role}_10_aa")]
            train, test = earlier & (roles == role), window & (roles == role)
            p = {key: forecast(a, y, train, test) for key, a in x.items()}
            error = y[test] - p["control"]
            observed_swing = swing[test]
            big = abs(error) > 25
            same_direction = (error * observed_swing > 0) & (abs(observed_swing) >= 7)
            result[phase][role] = {
                **{key: metrics(y[test], p["control"], p[key]) for key in ("own", "both")},
                "directControlBigMisses": int(big.sum()),
                "bigMissesWithKnownHistoricalPassingPoints": int((big & np.isfinite(observed_swing)).sum()),
                "bigMissesWithSameDirectionSevenPointPassingSwing": int((big & same_direction).sum()),
            }
    gate = {}
    for role in ("start", "bench"):
        gate[role] = {}
        for key in ("own", "both"):
            group = [result[p][role][key] for p in PHASES]
            n = sum(g["n"] for g in group)
            gain = sum(g["gained"] - g["lost"] for g in group)
            mae_gain = sum(g["n"] * (g["mae"][0] - g["mae"][1]) for g in group) / n
            stable = sum(g["hits"][1] >= g["hits"][0] and g["mae"][1] <= g["mae"][0] for g in group)
            gate[role][key] = dict(
                n=n,
                hitGain=gain,
                maeGain=mae_gain,
                phasesWithoutLoss=stable,
                passEarlier=gain > 0 and mae_gain > 0 and stable >= 2,
            )
    output = dict(sourceSHA=receipt["archiveSHA"], periods=result, gate=gate, laterEvaluated=False)
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
