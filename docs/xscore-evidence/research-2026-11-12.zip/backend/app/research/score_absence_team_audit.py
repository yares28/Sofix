"""Reconstruct roster interventions before scoring the frozen goal predictions."""

import hashlib
import json
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_absence_role_audit import lock_time
from app.research.score_absence_team_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT, STEM, fit
from app.research.score_search import moment

POSITIONS = ("GK", "DEF", "MID", "FWD")


def replacement(ordinary, removed):
    known = {p: data for p, data in ordinary.items() if p not in removed}
    unknown = {}
    for role in POSITIONS:
        lost = sum(m for p, (pos, m) in ordinary.items() if pos == role and p in removed)
        if not lost:
            continue
        stay = {p: m for p, (pos, m) in known.items() if pos == role}
        capacity = sum(90 - m for m in stay.values())
        if lost >= capacity:
            for p in stay:
                known[p] = role, 90
            if lost > capacity + 1e-9:
                unknown[role] = lost - capacity
            continue
        lo, hi = 1.0, max(90 / m for m in stay.values())
        for _ in range(70):
            middle = (lo + hi) / 2
            allocated = sum(min(90, middle * m) - m for m in stay.values())
            if allocated < lost:
                lo = middle
            else:
                hi = middle
        for p, m in stay.items():
            known[p] = role, min(90.0, hi * m)
    return known, unknown


def compare_mappings(a, b):
    assert a.keys() == b.keys()
    for key in a:
        assert a[key][0] == b[key][0]
        np.testing.assert_allclose(a[key][1], b[key][1], atol=1e-9, rtol=0)


def paired(gains, weeks, selected):
    group = np.unique(weeks[selected], return_inverse=True)[1]
    counts = np.bincount(group)
    sums = np.bincount(group, weights=gains[selected])
    draws = np.random.default_rng(20261111).integers(len(counts), size=(2000, len(counts)))
    bounds = np.quantile(sums[draws].sum(axis=1) / counts[draws].sum(axis=1), [0.025, 0.975])
    return dict(gain=float(gains[selected].mean()), week95Interval=bounds.tolist())


def main():
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, raw.splitlines()), key=lambda g: (g["date"], g["id"]))
    source = json.loads((ROOT / "cases.json").read_text())
    frozen = json.loads((REPORTS / f"{STEM}.forecasts.json").read_text())
    claim_raw = (REPORTS / "laliga_score_absence_claims_pilot.json").read_bytes()
    assert hashlib.sha256(claim_raw).hexdigest() == frozen["claimSHA"]
    assert frozen["sourceKey"] == source["key"]
    claims = {
        (r["game"], r["club"]): {
            p["player"]
            for label in ("sancionados", "lesionados")
            for p in r["mentions"].get(label, [])
            if p["player"] is not None
        }
        for r in json.loads(claim_raw)["sourceClaims"]
    }
    coverage = json.loads((REPORTS / "laliga_score_absence_archive_coverage.json").read_text())
    revision = {i: moment(a["revision"]) for a in coverage["articles"] for i in a["eligibleGames"]}
    published = {g["id"]: moment(g["date"]) + timedelta(days=2) for g in games}
    target = [g for g in games if "2025-07-01" <= g["date"] < "2026-01-01"]
    earliest = min(lock_time(g["date"]) for g in target)
    fit_games = [g for g in games if published[g["id"]] < earliest and g["date"] < "2025-07-01"]
    assert [g["id"] for g in fit_games] == frozen["fitFixtures"] and len(fit_games) == 760
    index = {g["id"]: g for g in games}
    fixture_clubs = {g["id"]: (g["home"]["slug"], g["away"]["slug"]) for g in games}
    club_games = defaultdict(list)
    player_history = defaultdict(list)
    for g in games:
        for club in fixture_clubs[g["id"]]:
            club_games[club].append(g["id"])
        for p, sheet in g["players"].items():
            if sheet["played"] is True and sheet["ver"] == 7:
                player_history[p].append((g["id"], sheet["team"]))
    cols = [source["features"].index(k) for k in ("match_lam_h", "match_lam_a")]
    anchors = {}
    for r in source["rows"]:
        values = tuple(r["x"][i] for i in cols)
        assert anchors.setdefault(r["game"], values) == values
    with np.load(ROOT / f"{STEM}.npz") as z:
        assert str(z["key"]) == frozen["key"]
        beta, names, clubs, rates = (z[k] for k in ("beta", "names", "clubs", "rates"))
    # Physically exclude every outside-fit game from the refit.
    effects, refit, fitted_people, fitted_clubs, _ = fit(fit_games, {g["id"]: anchors[g["id"]] for g in fit_games})
    np.testing.assert_array_equal(refit, beta)
    np.testing.assert_array_equal(names, fitted_people)
    np.testing.assert_array_equal(clubs, fitted_clubs)
    checked_changed = 0
    for j, (g, proof) in enumerate(zip(target, frozen["vectors"], strict=True)):
        identity = g["id"]
        lock = lock_time(g["date"])
        assert identity == proof["game"] and lock.isoformat() == proof["lock"]
        check = []
        for side, club in enumerate(fixture_clubs[identity]):
            report = proof["clubs"][side]
            assert report["club"] == club
            past = [i for i in club_games[club] if published[i] < lock][-3:]
            known = defaultdict(list)
            for i in past:
                starters = sum(
                    p["started"] is True and p["played"] is True and p["team"] == club
                    for p in index[i]["players"].values()
                )
                assert starters == 11
                for name, p in index[i]["players"].items():
                    if p["played"] is True and p["team"] == club:
                        assert p["ver"] == 7
                        known[name].append((p["pos"], p["mins"]))
            ordinary = {p: (obs[-1][0], sum(m for _, m in obs) / len(past)) for p, obs in known.items()}
            compare_mappings(ordinary, report["baseline"])
            excluded = claims.get((identity, club), set()).copy()
            if excluded:
                assert revision[identity] < lock
            original_excluded = excluded.copy()
            for p in ordinary:
                past_clubs = [c for i, c in player_history[p] if published[i] < lock]
                if not past_clubs or past_clubs[-1] != club:
                    excluded.add(p)
                    original_excluded.discard(p)
            removed = {p for p in original_excluded if p in ordinary and ordinary[p][1] >= 15}
            assert sorted(removed) == proof["removed"][side]
            placebo = set()
            for name in sorted(removed, key=lambda p: (-ordinary[p][1], p)):
                role, mins = ordinary[name]
                alternatives = sorted(
                    (abs(m - mins), p)
                    for p, (pos, m) in ordinary.items()
                    if pos == role and p not in excluded | placebo and abs(m - mins) <= 15
                )
                if alternatives:
                    placebo.add(alternatives[0][1])
            assert sorted(placebo) == proof["placeboRemoved"][side]
            choices = []
            for label, anonymous, people in (
                ("proposal", "anonymousProposal", removed),
                ("placebo", "anonymousPlacebo", placebo),
            ):
                updated, unknown = replacement(ordinary, people)
                compare_mappings(updated, report[label])
                assert unknown.keys() == report[anonymous].keys()
                for role, minutes in unknown.items():
                    np.testing.assert_allclose(minutes, report[anonymous][role], rtol=0, atol=1e-8)
                effect = []
                for term in range(2):
                    old_sum = sum(m * effects.get(p, (0, 0))[term] / 90 for p, (_, m) in ordinary.items())
                    new_sum = sum(m * effects.get(p, (0, 0))[term] / 90 for p, (_, m) in updated.items())
                    effect.append(new_sum - old_sum)
                choices.append(effect)
            check.append(choices)
        anchor = np.array(anchors[identity])
        reconstructed = [anchor]
        for arm in range(2):
            h, a = check[0][arm], check[1][arm]
            reconstructed.append(np.clip(anchor * np.exp([h[0] + a[1], a[0] + h[1]]), 0.05, 8.0))
        np.testing.assert_allclose(reconstructed, rates[j], rtol=0, atol=1e-12)
        np.testing.assert_array_equal(proof["rates"], rates[j])
        checked_changed += bool(proof["removed"][0] or proof["removed"][1])
    assert checked_changed == frozen["affectedFixtures"]
    # Evaluate only the older target period, after all independently reconstructed forecasts passed.
    goals = np.array([[g["homeGoals"], g["awayGoals"]] for g in target])
    assert np.isfinite(goals).all()
    sides = np.ones(342, dtype=bool)
    weeks = np.repeat([lock_time(g["date"]).isoformat() for g in target], 2)
    matched = np.repeat([r["completelyMatchedPlacebo"] for r in frozen["vectors"]], 2)
    table = {}
    outcome = goals[:, None, :]
    scores = dict(
        poisson=rates - outcome * np.log(rates),
        cleanSheetBrier=(np.exp(-rates) - (outcome == 0)) ** 2,
        goalAbsoluteError=np.abs(rates - outcome),
    )
    for label, raw_score in scores.items():
        old, proposed, placebo = (raw_score[:, arm].ravel() for arm in range(3))
        table[label] = dict(
            frozenMean=float(old.mean()),
            absenceMean=float(proposed.mean()),
            placeboMean=float(placebo.mean()),
            absenceVsFrozen=paired(old - proposed, weeks, sides),
            matchedAbsenceVsPlacebo=paired(placebo - proposed, weeks, matched),
        )
    a, b = (table[k]["absenceVsFrozen"] for k in ("poisson", "cleanSheetBrier"))
    passed = a["gain"] > 0 and b["gain"] > 0 and max(a["week95Interval"][0], b["week95Interval"][0]) > 0
    passed &= table["poisson"]["matchedAbsenceVsPlacebo"]["gain"] > 0
    out = dict(
        key=frozen["key"],
        fixtures=len(target),
        sideOutcomes=342,
        refitExact=True,
        independentForecastReconstructions=len(target),
        affectedFixtures=checked_changed,
        matchedFixtureSides=int(matched.sum()),
        olderCases=dict(start=3762, bench=1621),
        previousPeriodsWithNoQualifiedSources=["spring2024", "season2024"],
        componentMetrics=table,
        passesEarlierGate=bool(passed),
        later2026Evaluated=False,
    )
    (REPORTS / f"{STEM}.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
