"""Testing-only chronological comparison of exact within-seven modal trees."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_matchups_run import validate_stat_identity
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres

MODELS = {
    f"{kind}_{size}": (kind, depth, leaf)
    for kind in ("tree", "forest")
    for size, depth, leaf in (("shallow", 5, 80), ("deep", 7, 120))
}


def fitted(x, scores, weeks, mask, setting, path, key):
    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) != key or len(stored["prediction"]) != int(mask["target"].sum()):
                raise ValueError("Modal prediction cache identity differs")
            return stored["prediction"], json.loads(str(stored["statistics"]))
    kind, depth, leaf = MODELS[setting]
    fit, target = mask["fit"], mask["target"]
    at = time.monotonic()
    if kind == "forest":
        model = modal.ModalForest(64, depth, leaf).fit(x[fit], scores[fit], weeks[fit])
        mass = model.predict_mass(x[target])
        prediction = window_centres(mass, modal.CENTRES)
    else:
        model = modal.ModalTree(depth, leaf).fit(x[fit], scores[fit])
        mass = model.predict_binned_mass(model.binner_.transform(x[target]))
        prediction = model.predict(x[target])
    if not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1 + 1e-12).any():
        raise ValueError("Invalid native score-window probabilities")
    chosen = (prediction * 2).astype(int)
    if not np.allclose(mass[np.arange(len(prediction)), chosen], mass.max(axis=1), rtol=0, atol=1e-12):
        raise ValueError("Modal forecast is not a winning score window")
    stats = {
        **model.statistics_,
        "fitSeconds": time.monotonic() - at,
        "fitRows": int(fit.sum()),
        "targetRows": int(target.sum()),
    }
    np.savez_compressed(path, key=key, prediction=prediction, mass=mass, statistics=json.dumps(stats))
    return prediction, stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "cases",
        "stats-cache",
        "match-cache",
        "player-cache",
        "matchup-cache",
        "matchup-report",
        "cache",
        "packages",
        "out",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    matchup_report = json.loads(args.matchup_report.read_text())
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench, matchup_report)
    ):
        raise ValueError("Modal research source cases differ")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.match_cache) as stored:
        match, match_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Team feature identity differs")
    with np.load(args.player_cache) as stored:
        player, player_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_player["featureKey"]:
            raise ValueError("Player feature identity differs")
    with np.load(args.matchup_cache) as stored:
        matchups, matchup_key = stored["x"], str(stored["key"])
        if matchup_key != matchup_report["featureKey"] or len(matchups) != len(source["rows"]):
            raise ValueError("Individual matchup feature identity differs")
    files = [
        Path(__file__),
        Path(modal.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + matchup_key
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "matchupFeatureKey": matchup_key,
        "cohorts": {},
    }
    if args.out.exists():
        previous = json.loads(args.out.read_text())
        if previous.get("implementationKey") == key:
            report = previous
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        weeks = np.array([r["week"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, compact_names = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        inputs = {"compact": numeric, "matchups": np.column_stack((numeric, matchups[keep]))}
        records = [
            {
                "spec": {"group": group, "model": model, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for group in inputs
            for model in MODELS
            for scope in ("all", "defmid")
        ]
        previous_rows, previous_old, winner, best = None, None, None, None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "warm2023":
                previous_rows, previous_old = target_rows, old
                continue
            if cohort == "start":
                control_parts = stability.starter_control(previous_old, old, previous_rows, mask["first"])
                control = empirical.empirical_predictions(
                    *control_parts[:3], positions[target], control_parts[3], 20, 0.75, 0
                )
            else:
                control = stability.analogue_control(args, key, source, old_bench, phase, mask)
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric["within7"] != expected["within7"]:
                raise ValueError("Modal frozen control did not reproduce")
            audit[phase] = {"fit": int(mask["fit"].sum()), "target": int(target.sum()), "control": metric, "models": {}}
            if phase == "later2026" and best is None:
                raise ValueError("Candidate must be frozen before later outcomes")
            active = [best] if phase == "later2026" else records
            pairs = sorted({(r["spec"]["group"], r["spec"]["model"]) for r in active})
            for group, setting in pairs:
                print(f"FITTING {cohort} {phase} {group} {setting}", flush=True)
                path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}_{setting}_{key[:12]}.npz"
                raw, stats = fitted(inputs[group], y, weeks, mask, setting, path, key)
                audit[phase]["models"][group + "/" + setting] = {
                    "forecast": measure(y[target], raw),
                    "fitDiagnostics": stats,
                }
                for record in [r for r in active if r["spec"]["group"] == group and r["spec"]["model"] == setting]:
                    candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    cm = measure(y[target], candidate)
                    if phase != "later2026":
                        gain = cm["within7"] - metric["within7"]
                        record["gains"].append(gain)
                        record["errors"].append(cm["mae"])
                        record["counts"].append(len(candidate))
                        record["periods"][phase] = {"gain": gain, "metrics": cm}
                    else:
                        alternate = candidate
                print(
                    "MODEL "
                    + json.dumps(
                        {
                            "cohort": cohort,
                            "phase": phase,
                            "group": group,
                            "setting": setting,
                            "forecast": measure(y[target], raw),
                            "fitDiagnostics": stats,
                        }
                    ),
                    flush=True,
                )
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                    "candidates": records,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            previous_rows, previous_old = target_rows, old
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "inputCounts": {g: x.shape[1] for g, x in inputs.items()},
            "compactFeatureNames": compact_names,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks[target].tolist()),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
