"""Independent PDF text-row completeness, raw metadata clock and extracted quote audit."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import UTC, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research import score_market_booklets as study


def canonical(text):
    return re.sub(r"\s+", "", unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().casefold())


def pdf_date(raw):
    m = re.fullmatch(r"D:(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})([+-])(\d{2})'(\d{2})'", raw)
    if m is None:
        raise ValueError("Unknown raw PDF timestamp, no timezone guess")
    year, month, day, hour, minute, second = map(int, m.groups()[:6])
    offset = timedelta(hours=int(m[8]), minutes=int(m[9]))
    if m[7] == "-":
        offset = -offset
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone(offset)).astimezone(UTC)


def raw_row_codes(text):
    chunks = canonical(text).split("goalscorerspainlaliga")[1:]
    return [m for chunk in chunks for m in re.findall(r"(?:po|ut|sr|ce|pe|su|ne)\d{1,2}:\d{2}(\d{4})", chunk)]


def main():
    from pypdf import PdfReader

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--folder", type=Path, default=Path("data/raw/score-foundation/player-prop-booklets"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_market_booklets.json"))
    args = parser.parse_args()
    report = json.loads(args.out.read_text())
    manifests, entries = [], {}
    for file in sorted(args.folder.glob("*manifest*.json")):
        raw = file.read_bytes()
        manifests.append(dict(file=file.name, sha256=hashlib.sha256(raw).hexdigest()))
        data = json.loads(raw.decode("utf-8-sig"))
        for entry in data if isinstance(data, list) else [data]:
            if "File" in entry and entry.get("Status", "downloaded") == "downloaded":
                entries[entry["File"]] = entry
    key = hashlib.sha256(
        Path(study.__file__).read_bytes()
        + args.out.parent.joinpath("laliga_score_market_source.plan.json").read_bytes()
        + json.dumps(manifests, sort_keys=True).encode()
    ).hexdigest()
    if key != report["implementationKey"] or manifests != report["manifests"]:
        raise ValueError("Frozen PDF extraction source/core/plan identity differs")
    checked, periods, tables = 0, {}, 0
    for book in report["booklets"]:
        path = args.folder / book["file"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entry = entries[book["file"]]
        if digest != book["sha256"] or digest != entry["SHA256"].lower() or book["url"] != entry["Url"]:
            raise ValueError("Pinned actual source PDF bytes differ")
        reader = PdfReader(path)
        created, modified = (pdf_date(reader.metadata[k]) for k in ("/CreationDate", "/ModDate"))
        raw_modified = entry["LastModified"]
        last_modified = parsedate_to_datetime(
            raw_modified[0] if isinstance(raw_modified, list) else raw_modified
        ).astimezone(UTC)
        available = max(created, modified, last_modified)
        for name, value in (
            ("creationUTC", created),
            ("documentModifiedUTC", modified),
            ("httpLastModifiedUTC", last_modified),
            ("provisionalAvailableUTC", available),
        ):
            if datetime.fromisoformat(book[name]) != value:
                raise ValueError("Independent source timestamp differs")
        start, end = datetime.fromisoformat(book["coverBegin"]).date(), datetime.fromisoformat(book["coverEnd"]).date()
        text = {i + 1: p.extract_text() or "" for i, p in enumerate(reader.pages)}
        first_dates = re.search(r"(\d{1,2})\.(\d{1,2})\.(\d{4})\s*-\s*(\d{1,2})\.(\d{1,2})\.(\d{4})", text[1])
        a, b, c, d, e, f = map(int, first_dates.groups())
        if start != datetime(c, b, a).date() or end != datetime(f, e, d).date():
            raise ValueError("Independent printed issue dates differ")
        header_pages = {i for i, t in text.items() if "goalscorerspainlaliga" in canonical(t)}
        if header_pages != {r["page"] for r in book["records"]}:
            raise ValueError("Some source player table was missed")
        expected_codes = Counter(code for i in header_pages for code in raw_row_codes(text[i]))
        if expected_codes != Counter(r["code"] for r in book["records"]):
            raise ValueError("Independent entire printed row-code coverage differs")
        for r in book["records"]:
            printed = canonical("".join(r[k] for k in ("weekday", "time", "code", "player", "club", "decimalOdds")))
            if printed not in canonical(text[r["page"]]):
                raise ValueError("Independent PDF text has different adjacent player/club/price row")
            weekdays = dict(po=0, pon=0, ut=1, uto=1, sr=2, sre=2, ce=3, cet=3, pe=4, pet=4, su=5, sub=5, ne=6, ned=6)
            day = start + timedelta(days=(weekdays[canonical(r["weekday"])] - start.weekday()) % 7)
            if day > end or day + timedelta(days=7) <= end:
                raise ValueError("Printed calendar date is not unique")
            hour, minute = map(int, r["time"].split(":"))
            # Madrid is a separate named zone from the primary parser's Belgrade.
            at = datetime(day.year, day.month, day.day, hour, minute, tzinfo=ZoneInfo("Europe/Madrid")).astimezone(UTC)
            lock = max(
                (at - timedelta(days=i)).replace(hour=14, minute=0, second=0, microsecond=0)
                for i in range(8)
                if (at - timedelta(days=i)).weekday() in (1, 4)
                and (at - timedelta(days=i)).replace(hour=14, minute=0, second=0, microsecond=0) <= at
            )
            if datetime.fromisoformat(r["listedTimeUTC"]) != at or datetime.fromisoformat(r["inferredLockUTC"]) != lock:
                raise ValueError("Independent local fixture time or inferred lock differs")
            if r["metadataBeforeLock"] != (available < lock) or r["eligibleForModel"] is not False:
                raise ValueError("Provisional timing or unresolved eligibility guard differs")
            checked += 1
        periods[book["file"]] = dict(
            cover=book["coverBegin"],
            quotes=len(book["records"]),
            printedCodesExact=True,
            rowTextExact=True,
            allSourceMetadataClocksVerified=True,
        )
        tables += len(book["tables"])
        print("MARKET_BOOKLET_AUDITED " + json.dumps(dict(file=book["file"], quotes=len(book["records"]))), flush=True)
    if checked != report["quotes"] or report["modelEligibleQuotes"] != 0:
        raise ValueError("Overall source completeness/guard differs")
    result = dict(
        implementationKey=key,
        sourcePDFs=len(report["booklets"]),
        independentPrintedRows=checked,
        sourceTables=tables,
        completeRawCodeAndRowTextVerified=True,
        independentDocumentAndPublisherTimes=True,
        independentNamedTimezoneAndLockChecks=True,
        modelEligibleQuotes=0,
        booklets=periods,
        status="COMPLETE source pilot extraction audit. Does not certify original public availability or market settlement; no forecast fit.",
    )
    args.out.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2) + "\n")
    print("MARKET_BOOKLET_AUDIT " + json.dumps({k: v for k, v in result.items() if k != "booklets"}), flush=True)


if __name__ == "__main__":
    main()
