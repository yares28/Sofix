import numpy as np

from app.research.score_specialists import position_masks, put_predictions


def test_specialist_trains_only_on_own_earlier_position():
    positions = np.array(["DEF", "MID", "DEF", "DEF", "MID"])
    fit = np.array([True, True, True, False, False])
    check = ~fit
    earlier, later = position_masks(positions, fit, check, "DEF")
    np.testing.assert_array_equal(earlier, [True, False, True, False, False])
    np.testing.assert_array_equal(later, [False, False, False, True, False])


def test_fallback_keeps_rare_positions_and_replacements_preserve_case_order():
    prediction = np.array([40.0, 35, 60, 45])
    selected = np.array([False, True, False, True])
    result = put_predictions(prediction, selected, np.array([38.0, 46]))
    np.testing.assert_array_equal(result, [40, 38, 60, 46])
    np.testing.assert_array_equal(prediction, [40, 35, 60, 45])


def test_missing_specialist_predictions_cannot_silently_drop_cases():
    import pytest

    with pytest.raises(ValueError, match="count"):
        put_predictions(np.array([40.0, 35]), np.array([True, True]), np.array([38.0]))
