import pytest

from app.research.score_unpriced_probe import compare


def fixture():
    game = {
        "id": "g",
        "date": "2023-10-29T13:00:00Z",
        "home": {"slug": "h"},
        "away": {"slug": "a"},
        "players": {
            "p": {
                "pos": "FWD",
                "team": "h",
                "played": True,
                "stats": {"duel_won": [8, 8], "duel_lost": [5, -5], "double_double": [1, 4]},
            }
        },
    }
    result = {
        "id": "g",
        "date": game["date"],
        "homeTeam": {"slug": "h"},
        "awayTeam": {"slug": "a"},
        "playerGameScores": [
            {
                "anyPlayer": {"slug": "p"},
                "anyPlayerGameStats": {
                    "anyTeam": {"slug": "h"},
                    "duelWon": 8,
                    "duelLost": 5,
                    "wonTackle": 2,
                    "interceptionWon": None,
                    "totalScoringAtt": 0,
                },
            }
        ],
    }
    return game, result


def test_full_stat_evidence_keeps_null_distinct_from_known_zero_and_cached_absence():
    game, result = fixture()
    out = compare(game, result)
    counts = out["players"][0]["counts"]
    assert counts["interception_won"] is None
    assert counts["total_scoring_att"] == 0
    assert counts["won_tackle"] == 2 and out["positiveForwardTackles"] == 1
    assert out["players"][0]["cachedTackleFieldPresent"] is False
    assert out["pricedCountMismatches"] == 0


def test_historical_identity_mismatch_is_rejected():
    game, result = fixture()
    result["id"] = "other"
    with pytest.raises(ValueError, match="identity"):
        compare(game, result)
