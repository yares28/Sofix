"""Extract explicitly dated, ordinary article 119 player decisions with two engines."""

import hashlib
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

import pdfplumber
from pypdf import PdfReader

ROOT = Path("data/raw/score-foundation/suspension-source")
REPORTS = Path("reports/experiments")
START = re.compile(r"^\d+\.\s*-\s*UN PARTIDO DE SUSPENSION,? POR ACUMULACION DE AMONESTACIONES$")
END = re.compile(r"^\d+\.\s*-|^II\s*-|^III\s*-|^\s*-?\s*RESOLUCIONES ESPECIALES")
PLAYER = re.compile(r"^I\s*[-.]?\s*JUGADORES$")
LABEL = re.compile(r"\(([^()]+)\)")


def text(value):
    return " ".join(value.split())


def norm(value):
    return unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().upper()


def footer(line):
    value = norm(line)
    return any(
        value.startswith(prefix)
        for prefix in (
            "REAL FEDERACION ESPANOLA DE FUTBOL",
            "COMUNICACION PUBLICA DE LOS ACUERDOS",
            "COMITE DE DISCIPLINA ADOPTADOS EL",
        )
    )


def prelude(lines):
    trimmed = [text(line) for line in lines if line.strip()]
    if not any(
        re.fullmatch(r"CAMPEONATO NACIONAL DE (?:LIGA DE )?PRIMERA DIVISION - LIGA REGULAR - UNICO", norm(v))
        for v in trimmed[:5]
    ):
        return None
    season = next(
        (re.fullmatch(r"Temporada:\s*(20\d{2}-20\d{2})", v) for v in trimmed if v.startswith("Temporada:")), None
    )
    round_ = next(
        (re.fullmatch(r"JORNADA:\s*(\d+)\s+\((\d{2}-\d{2}-\d{4})\)", v) for v in trimmed if v.startswith("JORNADA:")),
        None,
    )
    if not season or not round_:
        raise ValueError("Season or round missing in ordinary decision")
    return season[1], int(round_[1]), round_[2]


def section_lines(lines):
    in_players, active = False, False
    for raw in lines:
        line = text(raw)
        key = norm(line)
        if PLAYER.fullmatch(key):
            in_players = True
        elif active and END.match(key):
            return
        elif in_players and START.fullmatch(key):
            active = True
        elif active and line and not footer(line):
            yield line
        elif in_players and re.match(r"^II\s*-|^III\s*-", key):
            return


def parse_pypdf(pdf):
    lines = [s for page in pdf.pages for s in (page.extract_text() or "").splitlines()]
    context = prelude(lines)
    if context is None:
        return None, []
    body = " ".join(section_lines(lines))
    article = r"\(Art[ií]culo:\s*119\s*\)"
    *segments, tail = re.split(article, body, flags=re.I)
    if tail.strip():
        raise ValueError("Unparsed content in article 119 player block")
    result = []
    for segment in segments:
        item = re.fullmatch(
            r"\s*([^()]+?)\s*\(([^()]+?)\s*\)\s*1\s+partido de suspensi[oó]n por\s*Acumulaci[oó]n de amonestaciones en diferentes partidos\.\s*",
            segment,
            re.I,
        )
        if not item:
            raise ValueError("Unrecognized article 119 row: " + segment[:140])
        result.append((text(item[1]), text(item[2])))
    return context, result


def parse_plumber(path):
    records, right_count = [], 0
    active, in_players, ended = False, False, False
    with pdfplumber.open(path) as pdf:
        meta = prelude((pdf.pages[0].extract_text() or "").splitlines())
        if meta is None:
            return None, []
        for page in pdf.pages:
            if ended:
                break
            for line in page.extract_text_lines(return_chars=True):
                entire = text(line["text"])
                key = norm(entire)
                if PLAYER.fullmatch(key):
                    in_players = True
                elif active and END.match(key):
                    ended = True
                    break
                elif in_players and START.fullmatch(key):
                    active = True
                elif active and not footer(entire):
                    right_count += len(re.findall(r"\(Art[ií]culo:\s*119\s*\)", entire, flags=re.I))
                    left = [c for c in line["chars"] if c["x0"] < 273.3]
                    if left:
                        part = page.crop((0, line["top"] - 0.05, 273.3, line["bottom"] + 0.05)).extract_text()
                        if part:
                            records.append(text(part))
                elif in_players and re.match(r"^II\s*-|^III\s*-", key):
                    ended = True
                    break
    raw = " ".join(records)
    values = [(text(m[1]), text(m[2])) for m in re.finditer(r"([^()]+?)\s*\(([^()]+?)\s*\)", raw)]
    if len(values) != right_count or (values and not raw.rstrip().endswith(")")):
        raise ValueError("Left-column row count differs from printed article references")
    return meta, values


def main():
    request_path = ROOT / "rfef_explicit_publication_requests.json"
    requests = {r["url"]: r for r in json.loads(request_path.read_text())}
    source_path = REPORTS / "laliga_score_suspension_clocks.json"
    clock = json.loads(source_path.read_text())
    results = []
    for doc in clock["documents"]:
        req = requests[doc["url"]]
        if not any(row["kind"] == "primera" for row in req["indexRows"]):
            continue
        path = Path(req["file"])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == doc["sha256"]
        item = dict(url=doc["url"], sourceTime=doc["conservativeSourceTime"], sha256=doc["sha256"])
        try:
            context, names = parse_pypdf(PdfReader(path))
            other_context, other_names = parse_plumber(path)
            if context != other_context or names != other_names:
                raise ValueError(f"PDF engines disagree ({len(names)} versus {len(other_names)} rows)")
            if not context or not names:
                results.append(dict(item, status="no_ordinary_119_player_section"))
                continue
            season, round_, printed_date = context
            results.append(
                dict(
                    item,
                    status="both_engines",
                    season=season,
                    round=round_,
                    printedRoundDate=printed_date,
                    rows=[dict(printedName=n, printedClub=c, article=119, suspensionMatches=1) for n, c in names],
                )
            )
        except ValueError as error:
            results.append(dict(item, status="quarantined", reason=str(error)))
    report = dict(
        clockReportSHA=hashlib.sha256(source_path.read_bytes()).hexdigest(),
        documentStatuses=dict(Counter(r["status"] for r in results)),
        independentPlayerRows=sum(len(r.get("rows", [])) for r in results),
        finalPlayerFixtureBans=0,
        documents=results,
        scope="Two extraction engines. Binding outcome, name identity, next eligible fixture, and appeals still require qualification.",
    )
    (REPORTS / "laliga_score_suspension_ordinary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "documents"}, indent=2))
    for item in results:
        if item["status"] == "quarantined":
            print(item["url"], item["reason"])


if __name__ == "__main__":
    main()
