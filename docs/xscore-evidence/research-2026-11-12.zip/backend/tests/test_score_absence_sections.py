from datetime import UTC, datetime

from app.research.score_absence_sections import club_sections, histories, linked, player_mentions


def test_only_explicit_club_labels_become_claims():
    sample = """<script>Lesionados: Future</script>
    <h3>Athletic Club</h3><p><b>- Sancionados:</b> -</p>
    <ul><li><b>Lesionados:</b> A. Perez y B. Ruiz</li>
    <li>Posibles sustitutos: Ruiz podría estar sancionado</li></ul>
    <p><b>Celta:</b></p><p>- Dudas: Player X</p>
    <h3>Otro contenido</h3><p>Lesionados: Not a claim for Celta</p>"""
    actual = club_sections(sample, {"athleticclub": "ath", "celta": "cel"})
    assert actual == {
        "ath": {"sancionados": "-", "lesionados": "A. Perez y B. Ruiz"},
        "cel": {"dudas": "Player X"},
    }


def test_duplicate_claim_is_unresolved_and_other_labels_survive():
    sample = """<h3>Celta</h3><p>Lesionados: -</p><p>Lesionados: Perez</p>
    <li>Sancionados: Otro</li>"""
    assert club_sections(sample, {"celta": "cel"}) == {"cel": {"sancionados": "Otro"}}


def test_parenthetical_description_is_removed_before_splitting_names():
    assert player_mentions("Álex Sancris (molestias, baja) y Nyom.") == ["Álex Sancris", "Nyom"]
    assert player_mentions("-") == []


def test_identity_links_reject_ambiguous_surnames_and_word_fragments():
    players = ["jose-garcia-martin", "jose-garcia-gomez", "luis-perez-ruiz"]
    assert linked("José García", players) is None
    assert linked("Pérez", players) is None
    assert linked("Luis Pérez", players) == "luis-perez-ruiz"


def test_future_and_equal_availability_sheets_cannot_influence_exposure():
    lock = datetime(2026, 1, 16, 14, tzinfo=UTC)

    def fixture(date, name):
        return {
            "date": date,
            "home": {"slug": "H"},
            "away": {"slug": "A"},
            "players": {name: dict(team="H", pos="DEF", ver=7, mins=90, played=True)},
        }

    old = fixture("2026-01-14T13:59:59Z", "known")
    boundary = fixture("2026-01-14T14:00:00Z", "same")
    future = fixture("2026-01-16T20:00:00Z", "future")
    assert histories([old, boundary, future], "H", lock) == ({"known": "DEF"}, {"known": 90})
