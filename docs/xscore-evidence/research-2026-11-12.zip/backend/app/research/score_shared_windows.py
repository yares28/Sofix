"""A shared nonlinear classifier for overlapping Sorare score ranges."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import warnings
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def normalise(x: np.ndarray, fit: np.ndarray) -> np.ndarray:
    if not np.isfinite(x).all():
        raise ValueError("Unknown inputs require an explicit imputation policy")
    mean = x[fit].mean(axis=0, dtype=np.float64)
    scale = x[fit].std(axis=0, dtype=np.float64)
    scale = np.where(scale > 1e-6, scale, 1)
    return np.clip((x - mean) / scale, -6, 6).astype(np.float32)


def window_targets(y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    centres = np.arange(0, 100.01, 2.5)
    return centres, (np.abs(y[:, None] - centres) <= 7).astype(int)


def fit_probability(x, targets, fit, check, hidden, alpha, max_epochs=120):
    from sklearn.exceptions import ConvergenceWarning
    from sklearn.neural_network import MLPClassifier

    inputs = normalise(x, fit)
    model = MLPClassifier(
        hidden_layer_sizes=tuple(hidden),
        alpha=alpha,
        activation="relu",
        solver="adam",
        batch_size=256,
        learning_rate_init=0.001,
        max_iter=max_epochs,
        tol=1e-4,
        n_iter_no_change=10,
        early_stopping=False,
        shuffle=True,
        random_state=20261103,
    )
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(inputs[fit], targets[fit])
    probability = model.predict_proba(inputs[check])
    if probability.shape != (int(check.sum()), targets.shape[1]):
        raise ValueError("Unexpected multilabel probability shape")
    return probability, {
        "iterations": model.n_iter_,
        "trainingLoss": float(model.loss_),
        "convergenceWarning": any(issubclass(w.category, ConvergenceWarning) for w in caught),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    with np.load(args.stats_cache) as stored:
        allx = stored["x"]
        stat_key = str(stored["key"])
    key = hashlib.sha256((source["key"] + stat_key).encode() + Path(__file__).read_bytes()).hexdigest()
    report = {
        "target": "Choose one score range with the largest predicted chance of landing within seven; all LaLiga cases",
        "split": "Train before July2025, choose July-Dec2025, refit before Jan2026, evaluate Jan-Oct2026",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "implementationKey": key,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        x = allx[keep]
        y = np.array([r["score"] for r in rows])
        dates = np.array([r["date"][:10] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        centres, target = window_targets(y)
        candidates = []
        for hidden in ((64,), (128, 64)):
            for alpha in (1, 10):
                path = args.cache / f"shared_{cohort}_{len(hidden)}_{alpha}_selection.npz"
                cached = np.load(path) if path.exists() else None
                if cached is not None and str(cached["key"]) == key:
                    probability = cached["probability"]
                    training = json.loads(str(cached["training"]))
                    cached.close()
                else:
                    if cached is not None:
                        cached.close()
                    probability, training = fit_probability(x, target, train, valid, hidden, alpha)
                    np.savez_compressed(path, key=key, probability=probability, training=json.dumps(training))
                base = window_centres(probability, centres)
                for shift in (-3, 0, 3):
                    candidates.append(
                        {
                            "hidden": list(hidden),
                            "alpha": alpha,
                            "shift": shift,
                            "training": training,
                            "selection": measure(y[valid], np.clip(base + shift, 0, 100)),
                        }
                    )
                print(
                    f"Selected {cohort} hidden{hidden} alpha{alpha}: "
                    + json.dumps(
                        {
                            "best": max(
                                candidates[-3:], key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"])
                            )
                        }
                    ),
                    flush=True,
                )
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        probability, training = fit_probability(x, target, ~test, test, winner["hidden"], winner["alpha"])
        prediction = np.clip(window_centres(probability, centres) + winner["shift"], 0, 100)
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Control cases differ")
            baseline = stored["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        pos = np.array([r["pos"] for r in rows])[test]
        result = {
            "winner": winner,
            "laterTraining": training,
            "later": measure(y[test], prediction),
            "staticControl": measure(y[test], baseline),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, baseline, weeks),
            "meanPredictedHitChance": float(probability.max(axis=1).mean()),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {p: measure(y[test][pos == p], prediction[pos == p]) for p in POSITIONS if (pos == p).any()},
        }
        np.savez_compressed(
            args.cache / f"shared_predictions_{cohort}.npz",
            prediction=prediction,
            probability=probability,
            y=y[test],
            key=key,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
