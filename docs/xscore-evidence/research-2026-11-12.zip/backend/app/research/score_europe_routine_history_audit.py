"""Testing only: independently verify native defensive bounds and all corrected-history columns."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
import zipfile
from bisect import bisect_left
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_europe_routine as routine
from app.research import score_europe_routine_history as history
from app.research import score_search
from app.research import score_team_shape_history as modal
from app.research.score_search import cutoff_for, moment

FIELDS = (
    "observed_games",
    "last_days",
    "minutes_mean",
    "exact_games",
    "exact_minutes",
    "routine90_weighted_mean",
    "routine90_weighted_median",
    "routine90_mode",
    "routine90_mode_mass",
    "routine90_sd",
    "upper_fraction",
    "lower_fraction",
    "bounded_fraction",
    "unbounded_fraction",
    "finite_lower90_mean",
    "finite_upper90_mean",
    "euro_fraction",
    "unknown_cohort_fraction",
    "same_club_fraction",
    "inferred_gc0_fraction",
)


def close(actual, expected, context):
    if actual is None or expected is None:
        if actual is not expected:
            raise ValueError("Native unknown/zero conflation: " + context)
    elif isinstance(expected, (str, bool)):
        if actual != expected:
            raise ValueError("Native identity/flag mismatch: " + context)
    elif not np.isclose(actual, expected, rtol=0, atol=1e-10):
        raise ValueError("Native numeric mismatch: " + context)


def point_bounds(low, high):
    exact = low is not None and high is not None and low == high
    kind = (
        "exact"
        if exact
        else "bounded"
        if low is not None and high is not None
        else "upper"
        if high is not None
        else "lower"
        if low is not None
        else "unbounded"
    )
    return dict(lower=low, upper=high, point=low if exact else None, kind=kind)


def native_sources(games_path, archives, saved):
    records, targets, prices = {}, [], {}
    digest = hashlib.sha256()
    evidence = Counter()

    def compare(identity, expected, aa_low, aa_high, effect_low, effect_high, inferred):
        actual = saved.get(identity)
        if actual is None:
            raise ValueError("Native routine observation absent: " + str(identity))
        for field in ("game", "date", "player", "pos", "club", "cohort", "minutes", "source"):
            close(actual[field], expected[field], field)
        lower = aa_low - effect_high if aa_low is not None and effect_high is not None else None
        upper = aa_high - effect_low if aa_high is not None and effect_low is not None else None
        bounds = point_bounds(lower, upper)
        for field, value in bounds.items():
            close(actual["routine"][field], value, "routine " + field)
        close(actual["effect"]["lower"], effect_low, "effect lower")
        close(actual["effect"]["upper"], effect_high, "effect upper")
        close(actual["effect"]["gcInferredZero"], inferred, "GC zero deduction")
        expected.update(routine=bounds, effect=dict(gcInferredZero=inferred))
        records[identity] = expected

    for line in games_path.open("rb"):
        digest.update(line)
        if not line.strip():
            continue
        g = json.loads(line)
        targets.append(
            {k: g[k] for k in ("id", "date", "home", "away")}
            | {"players": {p: {"team": r.get("team")} for p, r in g["players"].items()}}
        )
        for player, p in g["players"].items():
            if (
                p.get("played") is not True
                or p.get("ver") != 7
                or type(p.get("started")) is not bool
                or p.get("pos") not in ("GK", "DEF", "MID", "FWD")
            ):
                continue
            aa, score, minutes = p.get("aa"), p.get("score"), p.get("mins")
            if (
                any(type(v) not in (int, float) or not math.isfinite(v) for v in (aa, score, minutes))
                or not 0 <= score <= 100
                or not 1 <= minutes <= 90
            ):
                continue
            stats = p.get("stats")
            if not isinstance(stats, dict):
                continue
            aa_sum = sum(float(v[1]) for v in stats.values())
            if abs(aa_sum - aa) > 1e-7:
                raise ValueError("Native LL full AA point sheet mismatch")
            evidence["nativeLLFullAAPointSheets"] += 1
            defensive = sum(float(stats[n][1]) for n in ("goals_conceded", "clean_sheet_60") if n in stats)
            if g["date"] < "2023-11-01":
                for name in ("goals_conceded", "clean_sheet_60"):
                    if name in stats and stats[name][0] > 0:
                        label = p["pos"] + ":" + name
                        price = stats[name][1] / stats[name][0]
                        if label in prices and abs(prices[label] - price) > 1e-9:
                            raise ValueError("Independent early price inconsistency")
                        prices[label] = price
            identity = g["id"], player
            expected = dict(
                game=g["id"],
                date=g["date"],
                player=player,
                pos=p["pos"],
                club=p["team"],
                cohort="start" if p["started"] else "bench",
                minutes=float(minutes),
                source="laliga",
            )
            compare(identity, expected, float(aa), float(aa), defensive, defensive, False)
    receipts = []
    position_map = dict(Goalkeeper="GK", Defender="DEF", Midfielder="MID", Forward="FWD")
    price_map = dict(GK=-5, DEF=-4, MID=-2, FWD=0)
    for competition in ("CL", "EL", "CONF"):
        path = archives / f"{competition}.zip"
        receipts.append(dict(archive=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        with zipfile.ZipFile(path) as archive:
            for member in sorted(archive.namelist()):
                if not member.startswith("games/") or not member.endswith(".json"):
                    continue
                g = json.loads(archive.read(member)).get("raw") or {}
                if g.get("statusTyped") != "played":
                    continue
                sides = {(g.get(s + "Team") or {}).get("slug"): s for s in ("home", "away")}
                for raw in g.get("playerGameScores") or []:
                    stats = raw.get("anyPlayerGameStats") or {}
                    player, club, pos = (
                        (raw.get("anyPlayer") or {}).get("slug"),
                        (stats.get("anyTeam") or {}).get("slug"),
                        position_map.get(raw.get("positionTyped")),
                    )
                    minutes, score, level = (
                        stats.get("minsPlayed"),
                        raw.get("score"),
                        (raw.get("decisiveScore") or {}).get("totalScore"),
                    )
                    if (
                        raw.get("scoringVersion") != 7
                        or raw.get("scoreStatus") != "FINAL"
                        or stats.get("playedInGame") is not True
                        or not player
                        or not club
                        or club not in sides
                        or pos is None
                    ):
                        continue
                    if (
                        any(type(v) not in (int, float) or not math.isfinite(v) for v in (minutes, score, level))
                        or not 1 <= minutes <= 120
                        or not 0 <= score <= 100
                        or level not in (0, 5, 15, 35, 60, 70, 80, 90, 100)
                    ):
                        continue
                    floor = level if level >= 60 else 0
                    if score < floor:
                        continue
                    side = sides[club]
                    form = g.get(side + "Formation") or {}
                    named = [p["slug"] for line in form.get("startingLineup") or [] for p in line if p.get("slug")]
                    xi = set(named)
                    bench = {p["slug"] for p in form.get("bench") or [] if p.get("slug")}
                    complete = form.get("startingLineupAvailable") is True and len(xi) == 11
                    if complete and len(named) != 11:
                        raise ValueError("Native complete XI contains duplicate named slots")
                    started = stats.get("gameStarted")
                    if started not in (None, 0, 1, False, True):
                        continue
                    explicit = None if started is None else bool(started)
                    if complete and ((explicit is True and player not in xi) or (explicit is False and player in xi)):
                        continue
                    cohort = (
                        "start"
                        if complete and player in xi
                        else "bench"
                        if complete and player in bench
                        else "start"
                        if explicit is True
                        else "bench"
                        if explicit is False
                        else None
                    )
                    evidence["nativeEuroCohort:" + str(cohort)] += 1
                    evidence["nativeEuroBenchCertifiedByXIWithNullFlag"] += cohort == "bench" and started is None
                    if level == 100:
                        aa_low = aa_high = None
                    elif score == floor:
                        aa_low, aa_high = None, float(floor - level)
                    elif score == 100:
                        aa_low, aa_high = float(100 - level), None
                    else:
                        aa_low = aa_high = float(score - level)
                    gc, clean = stats.get("goalsConceded"), stats.get("cleanSheet60")
                    total = g.get("awayGoals" if side == "home" else "homeGoals")
                    if any(
                        v is not None and (type(v) not in (int, float) or not math.isfinite(v) or v < 0 or v != int(v))
                        for v in (gc, total)
                    ):
                        continue
                    if clean is not None and not (
                        type(clean) is bool or type(clean) in (int, float) and clean in (0, 1)
                    ):
                        continue
                    if (
                        gc is not None
                        and total is not None
                        and gc > total
                        or clean == 1
                        and ((gc is not None and gc > 0) or minutes < 60)
                    ):
                        continue
                    inferred = gc is None and (total == 0 or clean == 1)
                    if inferred:
                        gc = 0
                    smallest_gc, largest_gc = (gc, gc) if gc is not None else (0, total)
                    bonus_low, bonus_high = (
                        ((clean, clean) if clean is not None else (0, 1)) if pos == "DEF" else (0, 0)
                    )
                    m_low = price_map[pos] * largest_gc + 10 * bonus_low if largest_gc is not None else None
                    m_high = price_map[pos] * smallest_gc + 10 * bonus_high
                    if pos == "FWD":
                        m_low = m_high = 0
                    identity = g["id"], player
                    if identity in records and records[identity]["source"] == "laliga":
                        evidence["crossSourceActualLLDuplicate"] += 1
                        continue
                    expected = dict(
                        game=g["id"],
                        date=g["date"],
                        player=player,
                        club=club,
                        pos=pos,
                        cohort=cohort,
                        minutes=float(minutes),
                        source="euro",
                    )
                    compare(identity, expected, aa_low, aa_high, m_low, m_high, inferred)
                    evidence["nativeEuroAAandEffectIntervals"] += 1
    if set(records) != set(saved):
        raise ValueError("Native corrected routine observation key coverage differs")
    return list(records.values()), targets, prices, receipts, digest.hexdigest(), dict(evidence)


def reference_summary(records, lock, club):
    if not records:
        return {f: 0.0 if f in ("observed_games", "exact_games", "exact_minutes") else np.nan for f in FIELDS}
    exact = [r for r in records if r["routine"]["kind"] == "exact"]
    out = dict(
        observed_games=len(records),
        last_days=(lock.timestamp() - moment(records[-1]["date"]).timestamp()) / 86400,
        minutes_mean=float(np.mean([r["minutes"] for r in records])),
        exact_games=len(exact),
        exact_minutes=sum(r["minutes"] for r in exact),
    )
    for f in (
        "routine90_weighted_mean",
        "routine90_weighted_median",
        "routine90_mode",
        "routine90_mode_mass",
        "routine90_sd",
    ):
        out[f] = np.nan
    if exact:
        points = np.array([r["routine"]["point"] for r in exact])
        exposure = np.array([r["minutes"] for r in exact])
        rates = 90 * points / exposure
        total = exposure.sum()
        centres = np.array(sorted(set([*rates, *(rates - 7), *(rates + 7)])))
        mass = ((np.abs(rates[:, None] - centres) <= 7) * exposure[:, None]).sum(axis=0)
        maximum = mass.max()
        winners = centres[np.abs(mass - maximum) <= 1e-12 * total]
        order = np.argsort(rates, kind="stable")
        median = rates[order[np.flatnonzero(np.cumsum(exposure[order]) >= total * (0.5 - 1e-12))[0]]]
        mode = min(winners, key=lambda c: (abs(c - median), c))
        mean = 90 * points.sum() / total
        out.update(
            routine90_weighted_mean=mean,
            routine90_weighted_median=median,
            routine90_mode=mode,
            routine90_mode_mass=maximum / total,
            routine90_sd=float(np.sqrt(np.sum(exposure * (rates - mean) ** 2) / total)),
        )
    for kind in ("upper", "lower", "bounded", "unbounded"):
        out[kind + "_fraction"] = sum(r["routine"]["kind"] == kind for r in records) / len(records)
    for bound in ("lower", "upper"):
        chosen = [r for r in records if r["routine"][bound] is not None]
        out["finite_" + bound + "90_mean"] = (
            90 * sum(r["routine"][bound] for r in chosen) / sum(r["minutes"] for r in chosen) if chosen else np.nan
        )
    out.update(
        euro_fraction=sum(r["source"] == "euro" for r in records) / len(records),
        unknown_cohort_fraction=sum(r["cohort"] is None for r in records) / len(records),
        same_club_fraction=sum(r["club"] == club for r in records) / len(records),
        inferred_gc0_fraction=sum(r["effect"]["gcInferredZero"] for r in records) / len(records),
    )
    return out


def independent_features(rows, records, targets):
    names = tuple(
        f"routine_{s}_{g}_{n}_{f}"
        for s in ("euro", "combined")
        for g in ("same_position", "same_cohort")
        for n in (5, 15)
        for f in FIELDS
    )
    if names != history.NAMES:
        raise ValueError("Independent routine feature schema differs")
    by_game = {g["id"]: g for g in targets}
    grouped = defaultdict(list)
    for r in sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["player"])):
        grouped[r["player"], r["pos"]].append(r)
    dates = {k: [moment(r["date"]).timestamp() for r in v] for k, v in grouped.items()}
    output = np.full((len(rows), len(names)), np.nan)
    for i, row in enumerate(rows):
        lock = cutoff_for(row["date"])
        key = row["player"], row["pos"]
        sequence, when = grouped.get(key, []), dates.get(key, [])
        previous = sequence[
            bisect_left(when, lock.timestamp() - 365 * 86400) : bisect_left(when, lock.timestamp() - 172800)
        ]
        club = by_game[row["game"]]["players"][row["player"]]["team"]
        values = {}
        for source in ("euro", "combined"):
            eligible = [r for r in previous if source == "combined" or r["source"] == "euro"]
            for group in ("same_position", "same_cohort"):
                chosen = eligible if group == "same_position" else [r for r in eligible if r["cohort"] == row["cohort"]]
                for n in (5, 15):
                    values.update(
                        {
                            f"routine_{source}_{group}_{n}_{f}": v
                            for f, v in reference_summary(chosen[-n:], lock, club).items()
                        }
                    )
        output[i] = [values[n] for n in names]
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "features", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    corpus = json.loads(gzip.decompress(args.features.with_suffix(".observations.json.gz").read_bytes()))
    saved = {(r["game"], r["player"]): r for r in corpus["records"]}
    if len(saved) != len(corpus["records"]):
        raise ValueError("Routine corpus contains duplicate player-game observations")
    records, targets, prices, receipts, ll_sha, evidence = native_sources(args.games, args.archives, saved)
    if (
        targets != corpus["targets"]
        or prices != corpus["earlyNativePrices"]
        or ll_sha != corpus["laligaSha256"]
        or ll_sha != report["laligaSha256"]
    ):
        raise ValueError("Independent native routine source/early-price identity differs")
    for native, declared in zip(receipts, corpus["receipts"], strict=True):
        if any(native[n] != declared[n] for n in ("archive", "sha256")):
            raise ValueError("Native routine archive hash differs")
    ll = {(r["game"], r["player"]): r for r in records if r["source"] == "laliga"}
    for row in source["rows"]:
        record = ll[row["game"], row["player"]]
        original = saved[row["game"], row["player"]]
        if (
            any(record[n] != row[n] for n in ("date", "pos", "cohort", "minutes"))
            or abs(original["ordinary"]["point"] - row["aa"]) > 1e-10
        ):
            raise ValueError("Native LL routine identity differs from canonical case")
    modules = (routine, ordinary, modal, score_search)
    key = hashlib.sha256(
        (source["key"] + ll_sha + "".join(r["sha256"] for r in receipts)).encode()
        + Path(history.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    with np.load(args.features) as f:
        x = f["x"]
        if str(f["key"]) != key or tuple(f["names"]) != history.NAMES or x.shape != (38850, 160):
            raise ValueError("Routine source/code/plan/cache/schema fingerprint differs")
    if report["featureKey"] != key or corpus["key"] != key or report["sourceKey"] != source["key"]:
        raise ValueError("Routine report identity differs")
    print("EURO_ROUTINE_AUDIT independent38850x160", flush=True)
    repeated = independent_features(source["rows"], records, targets)
    same = np.isclose(x, repeated, atol=1e-10, rtol=0, equal_nan=True)
    if not same.all():
        bad = np.argwhere(~same)
        details = [(int(i), history.NAMES[j], float(x[i, j]), float(repeated[i, j])) for i, j in bad[:20]]
        raise ValueError(f"Independent corrected routine features differ in{len(bad)}cells: {details}")
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    chosen = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    altered = copy.deepcopy(corpus["records"])
    changes = 0
    for r in altered:
        if moment(r["date"]).timestamp() + 172800 >= first.timestamp():
            r.update(minutes=-999, score=np.nan, level=np.nan, nativeConceded=999, nativeClean=999, cohort=None)
            r["routine"] = dict(point=np.nan, lower=np.nan, upper=np.nan, kind="exact")
            r["effect"] = dict(lower=np.nan, upper=np.nan, gcInferredZero=True)
            changes += 1
    query_rows = [
        {**source["rows"][i], "aa": np.nan, "score": np.nan, "level": np.nan, "minutes": np.nan} for i in chosen
    ]
    causal = history.build_features(query_rows, altered, targets)
    if not np.array_equal(causal, x[chosen], equal_nan=True):
        raise ValueError("Unavailable/current routine-AA/DS/minutes/GC/CS/score changed prelock features")
    result = dict(
        scope="Testing-only full native point/bounds/source/feature/time audit; no accuracy claim",
        featureKey=key,
        nativeObservationsVerified=len(records),
        sourceEvidence=evidence,
        earlyNativePricesIndependentlyVerified=prices,
        nativeLLCanonicalCasesMatched=len(source["rows"]),
        independentlyRebuiltFeatureRows=len(x),
        featureColumns=160,
        all160ColumnsReproduced=True,
        absoluteTolerance=1e-10,
        unavailableObservationOutcomesMutated=changes,
        first2026LockCasesUnchanged=len(chosen),
        all6754Starts2925PlayedSubsRetained=True,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
