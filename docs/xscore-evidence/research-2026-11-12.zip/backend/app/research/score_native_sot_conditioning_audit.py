"""Native candidate/CDF audit plus actual original-source paired refits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import numpy as np

from app.research import score_geometry_conditioning_audit as audit
from app.research import score_native_sot_conditioning as study


def main():
    audit.study = study
    audit.main()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_native_sot_conditioning.json")
    )
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    args.out = args.report
    source, reports, _, _ = study.load_inputs(args)
    report = json.loads(args.report.read_text())
    key = report["implementationKey"]
    with np.load(args.cache / "stats.npz") as f:
        base = f["x"]
    with np.load(args.cache / "match_context_features.npz") as f:
        original_inputs = np.column_stack((base, f["x"]))
    integrity = json.loads(args.report.with_suffix(".integrity.json").read_text())
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        masks = study.stability.phase_masks(rows)
        mask = masks["spring2024"]
        aa, level = (np.array([r[field] for r in rows]) for field in ("aa", "level"))
        aa[~mask["fit"]], level[~mask["fit"]] = np.nan, np.nan
        call = SimpleNamespace(**{**vars(args), "rows": rows})
        expected = study.flow.old_components(
            call,
            cohort,
            "spring2024",
            reports["laliga_score_match_context"],
            reports["laliga_score_stability"],
            reports["laliga_score_ordinary"],
        )
        root = args.cache / "native-sot-original-paired-refits" / uuid4().hex
        root.mkdir(parents=True)
        actual = study.fitted(original_inputs[keep], aa, level, mask, root / "four-original-source-models.npz", key)
        for a, b in zip(actual[:2], expected[:2], strict=True):
            np.testing.assert_array_equal(a, b)
        for q in actual[2]:
            np.testing.assert_array_equal(actual[2][q], expected[2][q])
        integrity["cohorts"][cohort]["actualOriginalSourcePairedRefit"] = dict(
            phase="spring2024",
            inputs=677,
            allOutsideFitLabelsAbsent=True,
            preservedOriginalClassesProbabilitiesQuantilesExact=True,
        )
        print(
            "NATIVE_SOT_PAIRED_ORIGINAL_AUDITED "
            + json.dumps(dict(cohort=cohort, **integrity["cohorts"][cohort]["actualOriginalSourcePairedRefit"])),
            flush=True,
        )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(integrity, indent=2))


if __name__ == "__main__":
    main()
