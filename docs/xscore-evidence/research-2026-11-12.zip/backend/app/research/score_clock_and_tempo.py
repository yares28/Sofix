"""Audit recorded match clocks and test causal histories of match tempo."""

import hashlib
import json
from collections import Counter, defaultdict, deque

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_goal_context_rebuild import CONTEXT_KEY, INTENSITY, QUALITY
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_substitution_clock import capture
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_clock_and_tempo"


def observed_clock(detail):
    clock = detail.get("maxMin")
    if type(clock) is not int or not 90 <= clock <= 125:
        return None
    lineups = detail.get("lineups") or {}
    keepers = [
        p["mins"]
        for side in ("home", "away")
        for p in (lineups.get(side) or {}).get("starters", [])
        if p.get("pos") == "GK"
        and p.get("on") is None
        and p.get("off") is None
        and p.get("rc") in (None, 0)
        and type(p.get("mins")) is int
        and p["mins"] > 0
    ]
    if not keepers or any(abs(clock - m) > 1 for m in keepers):
        return None
    return clock - 90


def observed_tempo(detail):
    passes, shots = (detail.get(k) for k in ("passes", "shots"))
    if not isinstance(passes, list) or not isinstance(shots, list):
        return None
    sides = Counter(p.get("team") for p in passes)
    if min(sides["home"], sides["away"]) < 100:
        return None
    recorded = set()
    for p in passes + shots:
        minute, second = p.get("min"), p.get("sec")
        if type(minute) is not int or type(second) is not int or not 0 <= minute <= 125 or not 0 <= second < 60:
            return None
        recorded.add(60 * minute + second)
    gaps = np.diff(sorted(recorded))
    return float(np.sum(gaps[gaps <= 8]) / 60)


def historical_summary(history, baseline):
    values = np.asarray(history, dtype=float)
    if not len(values):
        return baseline, 0
    return float((values.sum() + 5 * baseline) / (len(values) + 5)), len(values)


def histories(games, observations):
    queue = sorted(games, key=lambda g: (g["date"], g["id"]))
    ready = [moment(g["date"]) + DELAY for g in queue]
    prior = defaultdict(lambda: deque(maxlen=10))
    league = defaultdict(lambda: deque(maxlen=50))
    output, cursor = {}, 0
    for g in queue:
        lock = cutoff_for(g["date"])
        while cursor < len(queue) and ready[cursor] < lock:
            finished = queue[cursor]
            for j, value in enumerate(observations[finished["id"]]):
                if value is None:
                    continue
                league[j].append(value)
                for s in ("home", "away"):
                    prior[finished[s]["slug"], j].append(value)
            cursor += 1
        x = []
        for j, default in enumerate((5.0, 25.0)):
            baseline = float(np.mean(league[j])) if league[j] else default
            a, n = historical_summary(prior[g["home"]["slug"], j], baseline)
            b, m = historical_summary(prior[g["away"]["slug"], j], baseline)
            x += [baseline, (a + b) / 2, abs(a - b), np.log1p(n + m)]
        output[g["id"]] = np.array(x)
    return output


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    labels = {}
    clock_diagnostic = Counter()

    def observe(game, events, detail):
        labels[game["id"]] = observed_clock(detail), observed_tempo(detail)
        complete = [p for p in detail.get("passes", []) if p.get("ok") is True and type(p.get("min")) is int]
        clock_diagnostic["completedPassesWithClock"] += len(complete)
        clock_diagnostic["completedPassesFromMinute90"] += sum(p["min"] >= 90 for p in complete)
        clock_diagnostic["verifiedGoals"] += len(events)
        clock_diagnostic["goalsFromMinute90"] += sum(minute >= 90 for minute, _ in events)
        clock_diagnostic["fixturesWithGoalFromMinute90"] += any(minute >= 90 for minute, _ in events)

    aliases = json.loads((ROOT / "player_names.json").read_bytes())
    _, _, digest = capture(games, aliases, observe_fixture=observe)
    receipt = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    assert digest == receipt["archiveReadSHA"] and len(labels) == len(games)
    fixture_x = histories(games, labels)
    source = json.loads((ROOT / "cases.json").read_bytes())
    ids = [i for i, r in enumerate(source["rows"]) if r["game"] in labels]
    rows = [source["rows"][i] for i in ids]
    native = np.array([r["x"] for r in rows])
    current = np.array([fixture_x[r["game"]] for r in rows])
    cache = ROOT / "match_context_features.npz"
    with np.load(cache) as f:
        assert str(f["key"]) == CONTEXT_KEY
        names = f["names"].tolist()
        context = f["x"][ids][:, [names.index(n) for n in (*QUALITY, *INTENSITY)]]
    base = np.column_stack((native, np.nan_to_num(context), ~np.isfinite(context)))
    arms = {
        "control": base,
        "clock": np.column_stack((base, current[:, :4])),
        "clockAndTempo": np.column_stack((base, current)),
    }
    date = np.array([r["date"] for r in rows])
    cohort = np.array([r["cohort"] for r in rows])
    y = np.array([r["score"] for r in rows])
    ready = np.array([moment(r["date"]) + DELAY for r in rows])
    locks = np.array([cutoff_for(r["date"]) for r in rows])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        period = (date >= begin) & (date < end)
        train = ready < locks[period].min()
        quality = {}
        for j, label in enumerate(("clock", "tempo")):
            selected = [g["id"] for g in games if begin <= g["date"] < end and labels[g["id"]][j] is not None]
            absolute = np.array([abs(labels[key][j] - fixture_x[key][4 * j : 4 * j + 2]) for key in selected])
            quality[label] = dict(fixtures=len(selected), mae=absolute.mean(axis=0).tolist())
        periods[phase] = {"sourcePrediction": quality}
        for role in ("start", "bench"):
            fit, test = train & (cohort == role), period & (cohort == role)
            anchor = native[:, source["features"].index(f"{role}_10_score")]
            predicted = {k: np.clip(anchor[test] + forecast(a, y - anchor, fit, test), 0, 100) for k, a in arms.items()}
            periods[phase][role] = {
                key: metrics(y[test], predicted["control"], predicted[key]) for key in arms if key != "control"
            }
    gate = {}
    for role in ("start", "bench"):
        gate[role] = {}
        for key in ("clock", "clockAndTempo"):
            group = [v[role][key] for v in periods.values()]
            n = sum(v["n"] for v in group)
            hits = [v["gained"] - v["lost"] for v in group]
            mae = sum(v["n"] * (v["mae"][0] - v["mae"][1]) for v in group) / n
            gate[role][key] = dict(
                n=n,
                phaseHitGains=hits,
                netHits=sum(hits),
                maeGain=mae,
                passEarlier=sum(hits) > 0 and mae > 0 and min(hits) >= 0,
            )
    output = dict(
        sourceSHA=digest,
        verifiedEarlierFixtures=len(labels),
        knownClock=sum(a is not None for a, _ in labels.values()),
        knownTempo=sum(b is not None for _, b in labels.values()),
        retrospectiveClockCounts=dict(clock_diagnostic),
        periods=periods,
        gate=gate,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({k: v for k, v in output.items() if k != "periods"}, indent=2))


if __name__ == "__main__":
    main()
