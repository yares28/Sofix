"""Research-only league travel and recovery features for routine score errors."""

import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from math import asin, cos, log1p, radians, sin, sqrt
from zipfile import ZipFile

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, fit, metrics

STEM = "laliga_score_travel_recovery"
PLACES = ROOT / "travel-source" / "ES-places.zip"
PLACES_SHA = "b9a58b0b434125e6b5af84eac013b71301be430276d526cc4368319f8f2761d0"
PLACE_IDS = {
    "almeria-almeria": "2521886",
    "athletic-club-bilbao": "3128026",
    "atletico-madrid-madrid": "3117735",
    "barcelona-barcelona": "3128760",
    "cadiz-cadiz": "2520600",
    "celta-de-vigo-vigo": "3105976",
    "deportivo-alaves-vitoria-gasteiz": "3104499",
    "deportivo-la-coruna-a-coruna": "3119841",
    "elche-elche": "2518559",
    "espanyol-barcelona": "3124569",
    "getafe-getafe-madrid": "3121437",
    "girona-girona": "3121456",
    "granada-granada": "2517117",
    "las-palmas-las-palmas-de-gran-canaria": "2515270",
    "leganes-leganes": "3118594",
    "levante-valencia": "2509954",
    "malaga-malaga": "2514256",
    "mallorca-palma-de-mallorca": "2512989",
    "osasuna-pamplona-irunea": "3114472",
    "racing-santander-santander": "3109718",
    "rayo-vallecano-madrid": "3117735",
    "real-betis-sevilla": "2510911",
    "real-madrid-madrid": "3117735",
    "real-oviedo-oviedo": "3114711",
    "real-sociedad-donostia-san-sebastian": "3110044",
    "real-valladolid-valladolid": "3106672",
    "sevilla-sevilla-1890": "2510911",
    "valencia-valencia": "2509954",
    "villarreal-villarreal": "2509509",
}


def read_places(path):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == PLACES_SHA
    required = set(PLACE_IDS.values())
    places = {}
    with ZipFile(path) as archive, archive.open("ES.txt") as handle:
        for line in handle:
            row = line.decode("utf-8").split("\t")
            if row[0] in required:
                assert row[6] == "P" and row[8] == "ES" and row[0] not in places
                places[row[0]] = dict(name=row[1], lat=float(row[4]), lon=float(row[5]), geonameId=row[0])
    assert places.keys() == required
    return {club: places[key] for club, key in PLACE_IDS.items()}


def distance(a, b):
    lat_a, lon_a, lat_b, lon_b = [radians(p[k]) for p in (a, b) for k in ("lat", "lon")]
    area = sin((lat_a - lat_b) / 2) ** 2 + cos(lat_a) * cos(lat_b) * sin((lon_a - lon_b) / 2) ** 2
    return 2 * 6371 * asin(sqrt(min(area, 1)))


def schedule_features(history, kickoff, current_trip):
    past = [r for r in history[-6:] if r[0] >= kickoff - timedelta(days=14)]
    days = (kickoff - past[-1][0]).total_seconds() / 86400 if past else 14.0
    short = max(0.0, 5 - days) / 5
    week = [r for r in past if r[0] >= kickoff - timedelta(days=7)]
    recovery = float(bool(past)), days, len(week), len(past), short
    travel = log1p(current_trip / 100), log1p(sum(r[1] for r in past) / 100), short * log1p(current_trip / 100)
    return recovery, travel


def feature_rows(rows, games, coordinates):
    grouped = defaultdict(list)
    for i, row in enumerate(rows):
        grouped[row["game"]].append(i)
    games = sorted(games, key=lambda g: (g["date"], g["id"]))
    dates = [moment(g["date"]) for g in games]
    team_history, player_history = defaultdict(list), defaultdict(list)
    club_ids = {club: i for i, club in enumerate(sorted(coordinates))}
    identity = np.eye(len(club_ids))
    known = set()
    baseline = np.empty((len(rows), len(club_ids) * 2))
    recovery = np.empty((len(rows), 13))
    travel = np.empty((len(rows), 6))
    lengths = {}
    cursor = 0
    for kickoff, g in zip(dates, games, strict=True):
        lock = cutoff_for(g["date"])
        while cursor < len(games) and dates[cursor] + DELAY < lock:
            previous = games[cursor]
            home, away = (previous[s]["slug"] for s in ("home", "away"))
            when = dates[cursor]
            team_history[home].append((when, 0.0))
            team_history[away].append((when, lengths[previous["id"]]))
            for player, item in previous["players"].items():
                if item.get("played") and item.get("ver") == 7 and item.get("mins") is not None:
                    player_history[player, item["team"]].append((when, float(item["mins"])))
            cursor += 1
        home, away = (g[s]["slug"] for s in ("home", "away"))
        trip = distance(coordinates[home], coordinates[away])
        lengths[g["id"]] = trip
        summaries = {
            home: schedule_features(team_history[home], kickoff, 0.0),
            away: schedule_features(team_history[away], kickoff, trip),
        }
        for i in grouped[g["id"]]:
            row = rows[i]
            club = g["players"][row["player"]]["team"]
            if club not in summaries or row["date"] != g["date"] or i in known:
                raise ValueError("Forecast fixture identity differs")
            known.add(i)
            opponent = away if club == home else home
            own_r, own_t = summaries[club]
            opponent_r, opponent_t = summaries[opponent]
            previous = player_history[row["player"], club][-6:]
            minutes = [sum(v for when, v in previous if when >= kickoff - timedelta(days=days)) for days in (7, 14)]
            days = min(14, (kickoff - previous[-1][0]).total_seconds() / 86400) if previous else 14
            baseline[i] = np.r_[identity[club_ids[club]], identity[club_ids[opponent]]]
            recovery[i] = (*own_r, *opponent_r, *minutes, days)
            travel[i] = (*own_t, *opponent_t)
    if len(known) != len(rows):
        raise ValueError("Incomplete case coverage")
    return baseline, recovery, travel, lengths


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    places = read_places(PLACES)
    clubs, recovery, travel, lengths = feature_rows(rows, games, places)
    roles = np.array([r["cohort"] for r in rows])
    dates = np.array([r["date"] for r in rows])
    locks = np.array([cutoff_for(d) for d in dates])
    ready = np.array([moment(d) + DELAY for d in dates])
    x = np.array([r["x"] for r in rows])
    assert np.isfinite(x).all()
    own_aa = {role: x[:, source["features"].index(f"{role}_10_aa")] for role in ("start", "bench")}
    y = np.array([r["aa"] for r in rows]) - np.where(roles == "start", own_aa["start"], own_aa["bench"])
    base = np.column_stack((x, clubs))
    rest = np.column_stack((base, recovery))
    full = np.column_stack((rest, travel))
    periods = {}
    for phase, (begin, end) in PHASES.items():
        window = (dates >= begin) & (dates < end)
        earlier = ready < locks[window].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, check = earlier & (roles == role), window & (roles == role)
            p0, p1, p2 = [fit(a, y, train, check) for a in (base, rest, full)]
            periods[phase][role] = dict(
                recovery=metrics(y[check], p0, p1),
                travel=metrics(y[check], p1, p2),
                ownRecentClubKnown=int(np.count_nonzero(recovery[check, 0])),
            )
    gate = defaultdict(dict)
    for role in ("start", "bench"):
        for experiment in ("recovery", "travel"):
            group = [phase[role][experiment] for phase in periods.values()]
            n = sum(r["n"] for r in group)
            error_gain = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in group) / n
            hits_gain = sum(r["gained"] - r["lost"] for r in group)
            large_miss_change = sum(r["missesOver25"][1] - r["missesOver25"][0] for r in group)
            retained = sum(r["mae"][1] <= r["mae"][0] and r["hits"][1] >= r["hits"][0] for r in group)
            gate[role][experiment] = dict(
                n=n,
                maeGain=error_gain,
                hitGain=hits_gain,
                largeMissChange=large_miss_change,
                phasesWithoutLoss=retained,
                passEarlier=error_gain > 0 and hits_gain > 0 and retained >= 2,
            )
    result = dict(
        nativeSHA=NATIVE_SHA,
        coordinatesSHA=PLACES_SHA,
        coordinatesAttribution="GeoNames CC BY 4.0",
        homeCities=places,
        earlierFixtures=len(lengths),
        maxTripKm=max(lengths.values()),
        periods=periods,
        gate=gate,
        laterOutcomesEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
