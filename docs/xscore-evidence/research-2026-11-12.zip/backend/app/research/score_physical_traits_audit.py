"""Independent raw-source, identity, all35columns and future-mutation research audit."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from bisect import bisect_left
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_physical_traits as study
from app.research.score_search import cutoff_for, moment


def independent(source, games, data, aliases, mapping, cached, names):
    def clean(s):
        s = unicodedata.normalize("NFKD", s.casefold())
        s = "".join(c for c in s if unicodedata.category(c) != "Mn")
        return " ".join(re.findall(r"[a-z0-9]+", s))

    canonical = {}
    for row in data:
        pid = int(row["ID"])
        if pid in canonical and row != canonical[pid]:
            raise ValueError("Independent conflicting source identity")
        canonical[pid] = row
    index = defaultdict(set)
    for pid, record in canonical.items():
        for field in ("FullName", "Name"):
            n = clean(record[field])
            tokens = n.split()
            if len(tokens) > 1 and min(map(len, tokens)) > 1:
                index[n].add(pid)
    expected = {}
    for p in sorted({p for g in games for p in g["players"]}):
        labels = {clean(p.replace("-", " ")), *(clean(a) for a in aliases.get(p, []))}
        evidence = {a: sorted(index[a]) for a in sorted(labels) if index[a]}
        possible = sorted({pid for ids in evidence.values() for pid in ids})
        expected[p] = dict(
            id=possible[0] if len(possible) == 1 else None,
            status="exact_name" if len(possible) == 1 else "ambiguous" if possible else "unmatched",
            candidates=possible,
            evidence=evidence,
        )
    count = Counter(r["id"] for r in expected.values() if r["id"] is not None)
    for record in expected.values():
        if record["id"] is not None and count[record["id"]] > 1:
            record.update(id=None, status="duplicate_identity")
    if expected != mapping:
        raise ValueError("Independent entire player identity map differs")

    fields = [
        "Height",
        "Weight",
        "Strength",
        "Jumping",
        "HeadingAccuracy",
        "Acceleration",
        "SprintSpeed",
        "Balance",
        "StandingTackle",
        "Dribbling",
    ]
    raw_ability = {}
    for p, record in expected.items():
        raw_ability[p] = np.full(10, np.nan)
        if record["id"] is None:
            continue
        for col, field in enumerate(fields):
            try:
                v = float(canonical[record["id"]][field])
            except (KeyError, ValueError, TypeError):
                continue
            lo, hi = (130, 230) if col == 0 else (35, 150) if col == 1 else (1, 99)
            if lo <= v <= hi:
                raw_ability[p][col] = v
    indexed = {g["id"]: g for g in games}
    dates, clubs = defaultdict(list), defaultdict(list)
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        for side in ("home", "away"):
            club = g[side]["slug"]
            dates[club].append(moment(g["date"]))
            clubs[club].append(g)
    depth = dict(GK=0.0, DEF=0.2, MID=0.6, FWD=1.0)
    home_col = source["features"].index("home")
    built, checked = [], 0
    for row in source["rows"]:
        g = indexed[row["game"]]
        p = g["players"][row["player"]]
        if (
            g["date"] != row["date"]
            or p.get("ver") != 7
            or p.get("played") is not True
            or bool(p["started"]) != (row["cohort"] == "start")
            or p["pos"] != row["pos"]
            or any(abs(p[k] - row[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Independent full native case identity/outcome check failed")
        checked += 1
        home = row["x"][home_col] > 0
        if p["team"] != g["home" if home else "away"]["slug"]:
            raise ValueError("Native forecast side differs")
        club = g["away" if home else "home"]["slug"]
        lock = cutoff_for(row["date"])
        end = bisect_left(dates[club], lock - timedelta(hours=48))
        start = bisect_left(dates[club], lock - timedelta(days=365))
        recent = clubs[club][max(start, end - 3) : end]
        members, position = defaultdict(float), {}
        for old in recent:
            for who, detail in old["players"].items():
                m = detail.get("mins")
                if (
                    detail.get("played") is True
                    and detail.get("team") == club
                    and detail.get("pos") in depth
                    and detail["pos"] != "GK"
                    and type(m) in (int, float)
                    and np.isfinite(m)
                    and m > 0
                ):
                    members[who] += m / len(recent)
                    position[who] = detail["pos"]
        values, weights = [], []
        for who in sorted(members):
            values.append(raw_ability[who])
            weights.append(members[who] / (0.25 + abs(depth[row["pos"]] + depth[position[who]] - 1.2)))
        values = np.array(values).reshape(-1, 10)
        weights = np.array(weights)
        means = []
        for c in range(10):
            ok = np.isfinite(values[:, c])
            means.append(float(np.dot(values[ok, c], weights[ok]) / weights[ok].sum()) if weights[ok].sum() else np.nan)
        means = np.array(means)
        good = np.isfinite(values).all(axis=1)
        covered = float(weights[good].sum() / weights.sum()) if weights.sum() else 0.0
        known = int(good.sum())
        own = raw_ability[row["player"]]
        if lock <= moment("2022-11-02T19:07:54Z"):
            own, means, covered, known = np.full(10, np.nan), np.full(10, np.nan), 0.0, 0
        built.append(
            np.r_[
                own,
                means,
                own - means,
                float(np.isfinite(own).all()),
                covered,
                sum(members.values()),
                known,
                len(recent),
            ]
        )
    built = np.array(built)
    np.testing.assert_allclose(built, cached, atol=1e-10, rtol=1e-12, equal_nan=True)
    expected_names = [prefix + field for prefix in ("own_", "opponent_", "gap_") for field in fields] + [
        "own_known",
        "opponent_known_fraction",
        "opponent_exposure",
        "opponent_known_players",
        "opponent_games",
    ]
    if names != expected_names or cached.shape != (38850, 35):
        raise ValueError("Independent complete schema/case coverage differs")
    return dict(
        nativeCasesVerified=checked,
        independentIdentityDecisions=len(expected),
        sourceRows=len(data),
        uniqueSourcePlayers=len(canonical),
        exactDuplicateSourceRows=len(data) - len(canonical),
        independentColumns=35,
        completeArrayVerified=True,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_physical_traits.integrity.json")
    )
    args = parser.parse_args()
    source = json.loads((args.cache / "cases.json").read_text())
    folder = args.cache / "physical-traits"
    raw, csv_raw = args.games.read_bytes(), (folder / "players_fifa23.csv").read_bytes()
    if hashlib.sha256(raw).hexdigest() != study.NATIVE_SHA or hashlib.sha256(csv_raw).hexdigest() != study.CSV_SHA:
        raise ValueError("Independent native/physical raw hashes differ")
    report = json.loads((args.out.parent / "laliga_score_physical_traits.json").read_text())
    plan = (args.out.parent / "laliga_score_physical_traits.plan.json").read_bytes()
    aliases_raw = (args.cache / "player_names.json").read_bytes()
    key = hashlib.sha256(
        source["key"].encode() + raw + csv_raw + aliases_raw + Path(study.__file__).read_bytes() + plan
    ).hexdigest()
    with np.load(args.cache / "physical_trait_features.npz") as f:
        if str(f["key"]) != key or report["featureKey"] != key or str(f["source_key"]) != source["key"]:
            raise ValueError("Physical feature implementation/source identity differs")
        x, names = f["x"], f["names"].tolist()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    data = list(csv.DictReader(csv_raw.decode("utf-8-sig").splitlines()))
    aliases, mapping = json.loads(aliases_raw), json.loads((folder / "identities.json").read_text())
    if hashlib.sha256((folder / "identities.json").read_bytes()).hexdigest() != report["identitySha256"]:
        raise ValueError("Pinned full identity mapping differs")
    audit = independent(source, games, data, aliases, mapping, x, names)
    lock = cutoff_for(next(r["date"] for r in source["rows"] if r["date"] >= "2026-01-01"))
    selected = [r for r in source["rows"] if cutoff_for(r["date"]) == lock]
    changed, count = deepcopy(games), 0
    for g in changed:
        if moment(g["date"]) + timedelta(hours=48) >= lock:
            count += 1
            g["xi"] = "UNAVAILABLE FUTURE XI"
            for p in g["players"].values():
                p.update(mins=99999, pos="MID", stats={"duel_won": [99999, 99999]})
    mutated, _, _ = study.build_features(selected, changed, mapping, data, source["features"])
    actual = x[[cutoff_for(r["date"]) == lock for r in source["rows"]]]
    np.testing.assert_array_equal(mutated, actual)
    coverage = {}
    for cohort in ("start", "bench"):
        for period, begin, end in (("earlier", "2024-01-01", "2026-01-01"), ("later", "2026-01-01", "9999")):
            keep = np.array([r["cohort"] == cohort and begin <= r["date"] < end for r in source["rows"]])
            coverage[cohort + "_" + period] = dict(
                n=int(keep.sum()),
                ownKnown=int(x[keep, 30].sum()),
                opponentKnown=int(np.isfinite(x[keep, 10]).sum()),
                medianOpponentCoveredWeight=float(np.median(x[keep, 31])),
            )
    audit.update(
        featureKey=key,
        csvSha256=study.CSV_SHA,
        actualFutureMutation=dict(unavailableFixtures=count, targetRows=len(selected), all35columnsExact=True),
        coverage=coverage,
        status="COMPLETE source/identity/35columns/nativecase/time audit; no accuracy claim",
    )
    args.out.write_text(json.dumps(audit, indent=2, allow_nan=False) + "\n")
    print("PHYSICAL_TRAITS_AUDIT " + json.dumps(audit), flush=True)


if __name__ == "__main__":
    main()
