"""Testing only: additive player/context effects on exact score-window likelihoods."""

from __future__ import annotations

import numpy as np

from app.research.score_local_errors import FitNormaliser

CENTRES = np.arange(101, dtype=float)
PARAMETERS = {
    f"{group}_numeric{numeric}_identity{identity}": (group, numeric, identity)
    for group in ("basic", "contextual")
    for numeric in (1, 100)
    for identity in (5, 50)
}


class AdditiveWindows:
    def categorical_matrix(self, categories):
        from scipy import sparse

        categories = np.asarray(categories, dtype=object)
        if categories.ndim != 2 or categories.shape[1] != len(self.category_maps_):
            raise ValueError("Identity column shape differs")
        row_indices, col_indices = [], []
        offset = 0
        for j, mapping in enumerate(self.category_maps_):
            for i, value in enumerate(categories[:, j]):
                key = "<missing>" if value is None else str(value)
                if key in mapping:
                    row_indices.append(i)
                    col_indices.append(offset + mapping[key])
            offset += len(mapping)
        return sparse.csr_matrix(
            (np.ones(len(row_indices)), (row_indices, col_indices)), shape=(len(categories), offset)
        )

    def design(self, numeric, categories):
        from scipy import sparse

        normalised = self.normaliser_.transform(numeric)
        categorical = self.categorical_matrix(categories)
        if len(normalised) != categorical.shape[0]:
            raise ValueError("Numeric and identity case counts differ")
        return sparse.hstack((sparse.csr_matrix(normalised), categorical), format="csr")

    def fit(self, numeric, categories, scores):
        numeric, categories, scores = (
            np.asarray(numeric, dtype=float),
            np.asarray(categories, dtype=object),
            np.asarray(scores, dtype=float),
        )
        if (
            scores.ndim != 1
            or not len(scores)
            or len(numeric) != len(scores)
            or len(categories) != len(scores)
            or not np.isfinite(scores).all()
            or ((scores < 0) | (scores > 100)).any()
            or categories.ndim != 2
        ):
            raise ValueError("Complete valid native labels and matched input rows required")
        self.normaliser_ = FitNormaliser().fit(numeric)
        self.category_maps_ = []
        for j in range(categories.shape[1]):
            keys = sorted({"<missing>" if value is None else str(value) for value in categories[:, j]})
            self.category_maps_.append({value: i for i, value in enumerate(keys)})
        x = self.design(numeric, categories)
        target = (np.abs(scores[:, None] - CENTRES[None, :]) <= 7).astype(float)
        self.input_mean_ = np.asarray(x.mean(axis=0)).ravel()
        self.target_mean_ = target.mean(axis=0)
        self.gram_ = (x.T @ x).toarray() - len(scores) * np.outer(self.input_mean_, self.input_mean_)
        self.rhs_ = np.asarray(x.T @ target) - len(scores) * np.outer(self.input_mean_, self.target_mean_)
        self.numeric_columns_ = numeric.shape[1] * 2
        self.coef_ = {}
        self.statistics_ = {
            "fitRows": len(scores),
            "numericColumnsWithMissingFlags": self.numeric_columns_,
            "identityColumns": x.shape[1] - self.numeric_columns_,
            "totalColumns": x.shape[1],
        }
        return self

    def predict(self, numeric, categories, numeric_penalty=1, identity_penalty=50):
        from scipy.linalg import cho_factor, cho_solve

        if min(numeric_penalty, identity_penalty) <= 0:
            raise ValueError("Positive shrinkage needed for unique additive solution")
        setting = numeric_penalty, identity_penalty
        if setting not in self.coef_:
            gram = self.gram_.copy()
            penalties = np.full(len(gram), float(identity_penalty))
            penalties[: self.numeric_columns_] = numeric_penalty
            gram.flat[:: len(gram) + 1] += penalties
            self.coef_[setting] = cho_solve(
                cho_factor(gram, lower=True, check_finite=False), self.rhs_, check_finite=False
            )
        coef = self.coef_[setting]
        x = self.design(numeric, categories)
        return np.clip(np.asarray(x @ coef) + self.target_mean_ - self.input_mean_ @ coef, 0, 1)
