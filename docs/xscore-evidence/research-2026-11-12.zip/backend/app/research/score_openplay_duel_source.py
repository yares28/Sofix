"""Qualify recorded opponent links in a pinned LaLiga event archive."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import subprocess
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research.score_match_context import CLUBS
from app.research.score_player_context import link_names
from app.research.score_prior_chances import words
from app.research.score_search import cutoff_for, moment
from app.research.score_shared_error_recovery import NATIVE_SHA
from app.research.score_stability import PHASES

SHA = {
    "events_esp_2324.parquet": "f84e37f19c9320262d24e704fcc8ff2a85bfcbc5f5ba579cbabfe2b99f28f15c",
    "events_esp_2425.parquet": "2b71c009ba14a1b7d4d7ce8380229b50772f3d0817eecc6c0455c9e4b329a24f",
    "events_esp_2526.parquet": "f6edf68199be3e79aa4ba1a44caed1b67f5ed259b38bb4b9a92b8a0a29794885",
    "matches.parquet": "99017d55a38c1c03eda15ffc500e23be7c6e5a380839809732f48e531f8526ac",
    "data_issues.csv": "d2e61f67a60547b1fd47d35f1bac9282a591fa63d4a189b6f8b81e388b2dced3",
}
CLUB_NAMES = CLUBS | {"Atletico": CLUBS["Atletico Madrid"]}
EVENT_TYPES = ("Aerial", "Challenge", "Dispossessed", "Foul", "Tackle", "TakeOn", "Smother")
ALIAS_SHA = "f18f198044791fa7d7598b46d1c4ca7fd959e79e01ab674e6b625cdd19eb8db0"


def query(directory, sql):
    return list(
        csv.DictReader(
            io.StringIO(
                subprocess.run(
                    [str(directory.resolve() / "duckdb.exe"), "-batch", "-csv", "-c", sql],
                    cwd=directory,
                    check=True,
                    capture_output=True,
                    encoding="utf-8",
                ).stdout
            )
        )
    )


def source_fixtures(directory, games):
    madrid = ZoneInfo("Europe/Madrid")
    native = defaultdict(list)
    for game in games:
        key = (
            moment(game["date"]).astimezone(madrid).date().isoformat(),
            game["home"]["slug"],
            game["away"]["slug"],
            str(game["homeGoals"]),
            str(game["awayGoals"]),
        )
        native[key].append(game)
    fixtures = query(
        directory,
        """SELECT match_id, CAST(date AS DATE) AS date, home_team, away_team, home_team_id, away_team_id,
        home_score, away_score, season FROM read_parquet('matches.parquet')
        WHERE comp='esp' AND season IN ('2324','2425','2526')""",
    )
    with (directory / "data_issues.csv").open(encoding="utf-8", newline="") as fp:
        flagged = {r["match_id"] for r in csv.DictReader(fp) if r["comp"] == "esp"}
    linked, by_game, failures = {}, {}, Counter()
    for fixture in fixtures:
        key = (
            fixture["date"],
            CLUB_NAMES[fixture["home_team"]],
            CLUB_NAMES[fixture["away_team"]],
            fixture["home_score"],
            fixture["away_score"],
        )
        candidates = native[key]
        match = fixture["match_id"]
        if match in flagged or len(candidates) != 1:
            failures["publisherIssue" if match in flagged else "noUniqueNativeDateSideAndScore"] += 1
            continue
        game = candidates[0]
        if game["id"] in by_game or match in linked:
            raise ValueError("Nonunique fixture identity")
        linked[match] = (game, fixture)
        by_game[game["id"]] = match
    return linked, by_game, {"archiveRows": len(fixtures), "matched": len(linked), "skippedArchiveRows": dict(failures)}


def pair_kind(a, b):
    kinds = a["type"], b["type"]
    winner, loser = "Successful", "Unsuccessful"
    outcomes = a["outcome"], b["outcome"]
    if kinds == ("Aerial", "Aerial") and outcomes == (winner, loser):
        return "aerial"
    if kinds == ("TakeOn", "Challenge") and outcomes == (winner, loser):
        return "dribblePast"
    if a["type"] in ("Tackle", "Smother") and (
        b["type"] == "Dispossessed" or (b["type"] == "TakeOn" and b["outcome"] == loser)
    ):
        # A tackle can take the ball away without the tackler's team keeping it.
        return "tackleOrSmother"
    if kinds == ("Foul", "Foul") and outcomes == (winner, loser):
        return "foul"
    return None


def opposing_actor(event, events, opposite):
    if event["opponent_key"] in ("", "NULL") or event["duplicates"] != "1":
        return None
    other = events.get((event["match_id"], opposite, event["opponent_key"]))
    if other is None or other["duplicates"] != "1":
        return None
    if other["opponent_key"] != event["team_event_id"] or other["period"] != event["period"]:
        return None
    if (
        event["player_id"] in ("", "NULL", "0")
        or other["player_id"] in ("", "NULL", "0")
        or event["player_id"] == other["player_id"]
    ):
        return None
    time = lambda x: int(x["minute"]) * 60 + int(x["second"])
    return other if abs(time(event) - time(other)) <= 1 else None


def events_for(directory, season):
    names = ", ".join(f"'{name}'" for name in EVENT_TYPES)
    return query(
        directory,
        f"""SELECT * FROM (
        SELECT match_id, team_id, team_event_id, player_id, player, type, outcome, x, y, minute, second, period,
               q_OppositeRelatedEvent AS opponent_key,
               count(*) OVER (PARTITION BY match_id, team_id, team_event_id) AS duplicates
        FROM read_parquet('events_esp_{season}.parquet')
        ) WHERE type IN ({names}) AND period IN ('FirstHalf', 'SecondHalf')
        """,
    )


def qualify(directory, linked, out):
    seasons = {}
    with gzip.open(out, "wt", encoding="utf-8", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            (
                "nativeGame",
                "sourceMatch",
                "kind",
                "minute",
                "second",
                "period",
                "x",
                "y",
                "winnerClub",
                "winnerId",
                "winnerName",
                "winnerEvent",
                "loserClub",
                "loserId",
                "loserName",
                "loserEvent",
            )
        )
        for season in ("2324", "2425", "2526"):
            events = [e for e in events_for(directory, season) if e["match_id"] in linked]
            if any(linked[e["match_id"]][1]["season"] != season for e in events):
                raise ValueError("Source event season differs from fixture")
            keys = {(e["match_id"], e["team_id"], e["team_event_id"]): e for e in events if e["duplicates"] == "1"}
            raw, paired, unusable_links = Counter(), Counter(), Counter()
            pair_matches = defaultdict(set)
            max_aerial_mirror = 0.0
            for e in events:
                game, match = linked[e["match_id"]]
                home, away = match["home_team_id"], match["away_team_id"]
                team = e["team_id"]
                if team not in (home, away):
                    raise ValueError("Event side absent from fixture")
                raw[e["type"], e["outcome"]] += 1
                opposite = away if team == home else home
                other = opposing_actor(e, keys, opposite)
                if other is None:
                    unusable_links[e["type"], e["outcome"]] += 1
                    continue
                kind = pair_kind(e, other)
                if kind is None:
                    continue
                own_side, opponent_side = ("home", "away") if team == home else ("away", "home")
                x, y = float(e["x"]), float(e["y"])
                if not (0 <= x <= 100 and 0 <= y <= 100):
                    raise ValueError("Event coordinates out of range")
                if kind == "aerial":
                    mirror = max(abs(x + float(other["x"]) - 100), abs(y + float(other["y"]) - 100))
                    max_aerial_mirror = max(max_aerial_mirror, mirror)
                writer.writerow(
                    (
                        game["id"],
                        e["match_id"],
                        kind,
                        e["minute"],
                        e["second"],
                        e["period"],
                        x,
                        y,
                        game[own_side]["slug"],
                        e["player_id"],
                        e["player"],
                        e["team_event_id"],
                        game[opponent_side]["slug"],
                        other["player_id"],
                        other["player"],
                        other["team_event_id"],
                    )
                )
                paired[kind] += 1
                pair_matches[kind].add(game["id"])
            seasons[season] = {
                "rawEventRowsByTypeOutcome": {"/".join(k): v for k, v in sorted(raw.items())},
                "rowsWithoutQualifiedReciprocalLink": {"/".join(k): v for k, v in sorted(unusable_links.items())},
                "qualifiedPairs": dict(paired),
                "fixturesWithPairType": {k: len(v) for k, v in pair_matches.items()},
                "maxMirroredAerialCoordinateDifference": max_aerial_mirror,
            }
    return seasons


def qualify_players(pairs, linked, alias_path, identity_path):
    raw = alias_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != ALIAS_SHA:
        raise ValueError("Player alias cache differs")
    aliases = json.loads(raw)
    with gzip.open(pairs, "rt", encoding="utf-8", newline="") as stream:
        contests = list(csv.DictReader(stream))
    actors = defaultdict(lambda: defaultdict(set))
    for contest in contests:
        for side in ("winner", "loser"):
            actors[contest["sourceMatch"], contest[side + "Club"]][contest[side + "Id"]].add(contest[side + "Name"])
    resolved = {}
    report = Counter()
    with identity_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("nativeGame", "sourceMatch", "club", "sourcePlayer", "nativePlayer"))
        for (match, club), players in sorted(actors.items()):
            game, _ = linked[match]
            candidates = {p for p, r in game["players"].items() if r["team"] == club and r["played"] is True}
            single_names = {p: next(iter(names)) for p, names in players.items() if len(names) == 1 and all(names)}
            links, _ = link_names(list(single_names.values()), candidates, aliases)
            report["sourcePlayerGameSides"] += len(players)
            for p, name in single_names.items():
                if player := links.get(words(name)):
                    resolved[match, club, p] = player
                    writer.writerow((game["id"], match, club, p, player))
    report["mappedPlayerGameSides"] = len(resolved)
    native_counts = defaultdict(Counter)
    for contest in contests:
        match = contest["sourceMatch"]
        winner, loser = (resolved.get((match, contest[s + "Club"], contest[s + "Id"])) for s in ("winner", "loser"))
        kind = contest["kind"]
        report["allPairs"] += 1
        report["bothActorsMapped"] += int(bool(winner and loser))
        report[f"{kind}BothActorsMapped"] += int(bool(winner and loser))
        if winner:
            native_counts[match, winner]["duel_won"] += 1
        if loser:
            native_counts[match, loser]["duel_lost"] += 1
    clock = defaultdict(list)
    for (match, player), counts in native_counts.items():
        game, _ = linked[match]
        native = game["players"][player]
        clock[player].append(moment(game["date"]) + timedelta(hours=48))
        if native["ver"] != 7 or native["pos"] == "GK" or not isinstance(native.get("stats"), dict):
            continue
        report["nativeCountComparisons"] += 1
        report["bothNativeDuelCountsEqual"] += int(
            all(counts[field] == native["stats"].get(field, [0])[0] for field in ("duel_won", "duel_lost"))
        )
    return clock, dict(report)


def coverage(source, games, linked, by_game, players):
    clocks = defaultdict(list)
    for game, _ in linked.values():
        for side in ("home", "away"):
            clocks[game[side]["slug"]].append(moment(game["date"]) + timedelta(hours=48))
    for values in clocks.values():
        values.sort()
    for values in players.values():
        values.sort()
    histories = {}
    for game in games:
        lock = cutoff_for(game["date"])
        old = lock - timedelta(days=120) + timedelta(hours=48)
        histories[game["id"]] = min(
            bisect_left(clocks[club], lock) - bisect_left(clocks[club], old)
            for club in (game["home"]["slug"], game["away"]["slug"])
        )
    result = {}
    for phase, begin, end in PHASES:
        result[phase] = {}
        for cohort in ("start", "bench"):
            rows = [r for r in source["rows"] if r["cohort"] == cohort and begin <= r["date"] < end]
            own_history = 0
            for row in rows:
                lock = cutoff_for(row["date"])
                past = players.get(row["player"], [])
                first = lock - timedelta(days=120) + timedelta(hours=48)
                own_history += bisect_left(past, lock) - bisect_left(past, first) >= 3
            result[phase][cohort] = {
                "all": len(rows),
                "fixtureHasEvents": sum(r["game"] in by_game for r in rows),
                "bothClubsHaveAtLeast3PriorMatchedFixturesWithin120Days": sum(histories[r["game"]] >= 3 for r in rows),
                "playerHasAtLeast3PriorAppearancesWithMappedContestsWithin120Days": own_history,
            }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_duel_source.json"))
    args = parser.parse_args()
    directory = args.cache / "openplay-data-v0.1.0"
    for name, expected in SHA.items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Source asset fingerprint differs: {name}")
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Native fixture fingerprint differs")
    games = [json.loads(line) for line in raw.splitlines() if line.strip()]
    source = json.loads((args.cache / "cases.json").read_text())
    linked, by_game, matches = source_fixtures(directory, games)
    pairs = directory / "qualified_pairs.csv.gz"
    identities = directory / "qualified_players.csv"
    seasons = qualify(directory, linked, pairs)
    players, identity_report = qualify_players(pairs, linked, args.cache / "player_names.json", identities)
    report = {
        "source": "openplay (Noah Bair), CC BY 4.0",
        "release": "https://github.com/nlbair/openplay/releases/tag/data-v0.1.0",
        "assetSha256": SHA,
        "sourceKey": source["key"],
        "nativeSha256": NATIVE_SHA,
        "fixtures": matches,
        "coverage": coverage(source, games, linked, by_game, players),
        "seasons": seasons,
        "playerIdentity": identity_report,
        "playerAliasSha256": ALIAS_SHA,
        "playerIdentityArtifactSha256": hashlib.sha256(identities.read_bytes()).hexdigest(),
        "pairedArtifactSha256": hashlib.sha256(pairs.read_bytes()).hexdigest(),
        "scope": "Historical data source qualification only. No model or xScore forecasts evaluated.",
    }
    args.out.write_text(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
