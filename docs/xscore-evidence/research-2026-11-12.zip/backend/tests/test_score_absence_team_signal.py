import pytest

from app.research.score_absence_team_signal import matched_placebo, redistribute


def test_redistribution_caps_people_and_keeps_roles_separate():
    roster = {"out": ("DEF", 75), "near_cap": ("DEF", 85), "spare": ("DEF", 25), "other": ("MID", 40)}
    updated, anonymous = redistribute(roster, {"out"})
    assert updated == {"near_cap": ("DEF", 90), "spare": ("DEF", 90), "other": ("MID", 40)}
    assert anonymous == {"DEF": 5}
    assert roster["out"] == ("DEF", 75)


def test_proportional_replacement_and_unknown_replacement_are_distinct():
    roster = {"out": ("GK", 80), "g2": ("GK", 10), "a": ("DEF", 40), "b": ("DEF", 20)}
    updated, anonymous = redistribute(roster, {"out"})
    assert updated["g2"][1] == pytest.approx(90)
    assert anonymous == {}
    updated, anonymous = redistribute({"only": ("GK", 90)}, {"only"})
    assert updated == {}
    assert anonymous == {"GK": 90}


def test_placebo_matches_position_usage_and_never_removes_named_absence():
    roster = {"out": ("DEF", 60), "a": ("DEF", 55), "b": ("DEF", 65), "mid": ("MID", 60), "far": ("DEF", 30)}
    assert matched_placebo(roster, {"out"}, {"out", "a"}) == {"b"}
    assert matched_placebo(roster, {"out"}, {"out", "a", "b"}) == set()
