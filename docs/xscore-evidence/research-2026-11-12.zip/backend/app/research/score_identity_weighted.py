"""Testing only: identity penalties averaged over the training population."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research import score_identity_interactions as base

CENTRES = base.CENTRES
window_centres = base.window_centres
PARAMETERS = {name: base.PARAMETERS[name].copy() for name in ("rank4_penaltystrong", "numeric_penaltystrong")}


def importance(ids, sizes, prior=20):
    if prior < 0 or not np.isfinite(prior):
        raise ValueError("Finite nonnegative identity prior required")
    result = {}
    for j, (name, size) in enumerate(zip(base.EMBEDDINGS, sizes, strict=True)):
        counts = np.bincount(ids[:, j], minlength=size + 1).astype(np.float64)
        values = np.zeros(size + 1)
        if size:
            values[1:] = (counts[1:] + prior) / (counts[1:].sum() + size * prior)
        result[name] = values.astype(np.float32)
    return result


def loss_gradient(x, ids, labels, weights, ridge, embedding_ridge, penalties):
    loss, grad = base.loss_gradient(x, ids, labels, weights, ridge, 0)
    for name in base.EMBEDDINGS:
        frequency = penalties[name][:, None]
        loss += float(0.5 * embedding_ridge * (frequency * weights[name] ** 2).sum())
        grad[name] += embedding_ridge * frequency * weights[name]
        grad[name][0] = 0
    return loss, grad


class InteractionNetwork(base.InteractionNetwork):
    def __init__(self, *args, identity_prior=20, **kwargs):
        super().__init__(*args, **kwargs)
        self.identity_prior = identity_prior

    def fit(self, raw, categories, scores):
        raw, categories = np.asarray(raw, dtype=float), np.asarray(categories, dtype=object)
        if not self.use_identities:
            categories = np.full(categories.shape, None, dtype=object)
        if self.epochs <= 0 or self.batch <= 0 or self.rank <= 0 or self.width <= 0:
            raise ValueError("Positive training dimensions required")
        self.normaliser_ = base.Normaliser().fit(raw, np.ones(len(raw)))
        self.encoder_ = base.CategoryEncoder().fit(categories)
        x, ids = self.normaliser_.transform(raw), self.encoder_.transform(categories)
        labels = base.targets(scores).astype(np.float32)
        if len(x) != len(ids) or len(x) != len(labels):
            raise ValueError("Matched training population required")
        sizes = [len(m) for m in self.encoder_.maps_]
        penalties = importance(ids, sizes, self.identity_prior)
        self.weights_ = base.initial_weights(x.shape[1], sizes, self.rank, self.width, self.seed)
        self.weights_["b_output"] = base.initial_output_bias(scores)
        first = {n: np.zeros_like(w) for n, w in self.weights_.items()}
        second = {n: np.zeros_like(w) for n, w in self.weights_.items()}
        rng = np.random.default_rng(self.seed)
        history, step = [], 0
        for epoch in range(self.epochs):
            order, total = rng.permutation(len(x)), 0.0
            for begin in range(0, len(x), self.batch):
                at = order[begin : begin + self.batch]
                loss, gradients = loss_gradient(
                    x[at], ids[at], labels[at], self.weights_, self.ridge, self.embedding_ridge, penalties
                )
                if not np.isfinite(loss) or any(not np.isfinite(g).all() for g in gradients.values()):
                    raise ValueError("Nonfinite population-weighted identity fit")
                step += 1
                for name, gradient in gradients.items():
                    first[name] = 0.9 * first[name] + 0.1 * gradient
                    second[name] = 0.999 * second[name] + 0.001 * gradient**2
                    self.weights_[name] -= (
                        0.001 * (first[name] / (1 - 0.9**step)) / (np.sqrt(second[name] / (1 - 0.999**step)) + 1e-8)
                    )
                for name in base.EMBEDDINGS:
                    self.weights_[name][0] = 0
                total += loss * len(at)
            history.append(total / len(x))
            if (epoch + 1) % 40 == 0:
                print(f"WEIGHTED_IDENTITY_EPOCH {epoch + 1}/{self.epochs} loss{history[-1]:.6f}", flush=True)
        self.history_ = np.array(history)
        self.statistics_ = dict(
            epochs=self.epochs,
            fitRows=len(x),
            rawFeatures=raw.shape[1],
            normalisedFeatures=x.shape[1],
            rank=self.rank,
            width=self.width,
            ridge=self.ridge,
            embeddingRidge=self.embedding_ridge,
            identityPrior=self.identity_prior,
            seed=self.seed,
            batch=self.batch,
            categorySizes=sizes,
            useIdentities=self.use_identities,
            steps=step,
            lossFirst=history[0],
            lossLast=history[-1],
            lossLastTenMean=float(np.mean(history[-10:])),
            embeddingPenaltyWeightsSha256=hashlib.sha256(
                b"".join(penalties[n].tobytes() for n in base.EMBEDDINGS)
            ).hexdigest(),
            identityVectorNorms={n: float(np.linalg.norm(self.weights_[n])) for n in base.EMBEDDINGS},
        )
        return self
