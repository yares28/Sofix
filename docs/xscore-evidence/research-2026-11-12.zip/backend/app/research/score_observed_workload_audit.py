"""Testing only: independent native-minute and all-case workload reconstruction."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
import zipfile
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_observed_workload as workload
from app.research import score_search
from app.research.score_search import cutoff_for, moment


def verified_minutes(value, flag, limit, side_known):
    if not side_known or isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not math.isfinite(value) or value < 0 or value > limit:
        return None
    if (value > 0 and flag is True) or (value == 0 and flag is False):
        return float(value)
    return None


def native_sources(archives, games):
    fixtures, records, receipts, laliga = {}, {}, [], []

    def add_fixture(game, date, home, away, source, players):
        if not game or not home or not away or home == away:
            raise ValueError("Independent source fixture identity invalid")
        header = dict(game=game, date=moment(date).isoformat(), home=home, away=away, source=source)
        extra = False
        for player, club, value, flag in players:
            if not player:
                continue
            known = club in (home, away)
            minutes = verified_minutes(value, flag, 120 if source == "euro" else 90, known)
            extra |= minutes is not None and minutes > 90
            r = dict(
                game=game,
                player=player,
                date=header["date"],
                club=club if known else None,
                minutes=minutes,
                source=source,
            )
            identity = game, player
            if identity in records:
                previous = records[identity]
                for field in ("date", "source", "club", "minutes"):
                    if previous[field] is not None and r[field] is not None and previous[field] != r[field]:
                        raise ValueError("Independent native duplicate conflict")
                r = {k: r[k] if r[k] is not None else previous[k] for k in r}
            records[identity] = r
        header["extraObserved"] = extra
        if game in fixtures and fixtures[game] != header:
            raise ValueError("Independent fixture conflict")
        fixtures[game] = header

    for name in ("CL", "EL", "CONF"):
        path = archives / f"{name}.zip"
        counts = Counter()
        with zipfile.ZipFile(path) as archive:
            for member in sorted(archive.namelist()):
                if not member.startswith("games/") or not member.endswith(".json"):
                    continue
                raw = json.loads(archive.read(member)).get("raw") or {}
                if raw.get("statusTyped") != "played":
                    continue
                players = []
                home, away = raw["homeTeam"]["slug"], raw["awayTeam"]["slug"]
                for r in raw.get("playerGameScores") or []:
                    p, s = (r.get("anyPlayer") or {}).get("slug"), r.get("anyPlayerGameStats") or {}
                    club = (s.get("anyTeam") or {}).get("slug")
                    m = verified_minutes(s.get("minsPlayed"), s.get("playedInGame"), 120, club in (home, away))
                    counts["unknownPlayer" if not p else "unknown" if m is None else "positive" if m else "zero"] += 1
                    players.append((p, club, s.get("minsPlayed"), s.get("playedInGame")))
                add_fixture(raw["id"], raw["date"], home, away, "euro", players)
                counts["playedFixtures"] += 1
        receipts.append(
            dict(archive=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(), counts=dict(counts))
        )
    digest = hashlib.sha256()
    with games.open("rb") as source:
        for line in source:
            digest.update(line)
            if not line.strip():
                continue
            g = json.loads(line)
            slim = {k: g[k] for k in ("id", "date", "home", "away")}
            slim["players"] = {p: {k: r.get(k) for k in ("team", "mins", "played")} for p, r in g["players"].items()}
            laliga.append(slim)
            if any(r.get("played") is True for r in g["players"].values()):
                add_fixture(
                    g["id"],
                    g["date"],
                    g["home"]["slug"],
                    g["away"]["slug"],
                    "laliga",
                    [(p, r.get("team"), r.get("mins"), r.get("played")) for p, r in g["players"].items()],
                )
    return fixtures, records, receipts, laliga, digest.hexdigest()


def independent_features(rows, laliga, fixtures, records):
    windows = (3, 7, 14, 28)
    groups = ("euro", "covered")
    pf = (
        "known_rows",
        "positive_rows",
        "zero_rows",
        "unknown_rows",
        "known_minutes",
        "complete_observed_minutes",
        "minutes_over90",
    )
    rf = (
        "last_known_minutes",
        "last_known_days_to_target",
        "last_positive_days_to_target",
        "known_rows365",
        "unknown_rows365",
    )
    names = (
        [f"load_{g}_player_{w}_{f}" for g in groups for w in windows for f in pf]
        + [f"load_{g}_player_{f}" for g in groups for f in rf]
        + [
            f"load_{g}_club_{w}_{f}"
            for g in groups
            for w in windows
            for f in ("observed_fixtures", "observed_extra_time")
        ]
        + [f"load_{g}_club_last_observed_days_to_target" for g in groups]
        + ["load_euro_global_last_observed_days_to_lock", "load_euro_global_fixtures365"]
    )
    if tuple(names) != workload.NAMES:
        raise ValueError("Independent feature schema differs")
    people, clubs = defaultdict(list), defaultdict(list)
    for r in records.values():
        people[r["player"]].append((moment(r["date"]).timestamp(), r))
    eu = []
    for f in fixtures.values():
        when = moment(f["date"]).timestamp()
        for club in (f["home"], f["away"]):
            clubs[club].append((when, f))
        if f["source"] == "euro":
            eu.append(when)
    for bucket in (people, clubs):
        for items in bucket.values():
            items.sort(key=lambda v: (v[0], v[1]["game"]))
    eu.sort()
    by_game = {g["id"]: g for g in laliga}
    output = np.full((len(rows), len(names)), np.nan)
    for i, row in enumerate(rows):
        lock = cutoff_for(row["date"]).timestamp()
        date = moment(row["date"]).timestamp()
        earliest, last = lock - 365 * 86400, lock - 48 * 3600
        club = by_game[row["game"]]["players"][row["player"]]["team"]
        ph = [(t, r) for t, r in people[row["player"]] if earliest <= t < last]
        ch = [(t, f) for t, f in clubs[club] if earliest <= t < last]
        values = {}
        for g in groups:
            p = [(t, r) for t, r in ph if g == "covered" or r["source"] == "euro"]
            c = [(t, f) for t, f in ch if g == "covered" or f["source"] == "euro"]
            known = [(t, r["minutes"]) for t, r in p if r["minutes"] is not None]
            positive = [(t, m) for t, m in known if m > 0]
            for w in windows:
                recent = [r for t, r in p if t >= lock - w * 86400]
                mins = [r["minutes"] for r in recent if r["minutes"] is not None]
                unknown = len(recent) - len(mins)
                numbers = [
                    len(mins),
                    sum(m > 0 for m in mins),
                    sum(m == 0 for m in mins),
                    unknown,
                    sum(mins) if mins else np.nan,
                    sum(mins) if mins and not unknown else np.nan,
                    sum(max(m - 90, 0) for m in mins) if mins else np.nan,
                ]
                for field, value in zip(pf, numbers, strict=True):
                    values[f"load_{g}_player_{w}_{field}"] = value
                recent_f = [f for t, f in c if t >= lock - w * 86400]
                values[f"load_{g}_club_{w}_observed_fixtures"] = len(recent_f)
                values[f"load_{g}_club_{w}_observed_extra_time"] = sum(f["extraObserved"] for f in recent_f)
            for field, value in zip(
                rf,
                [
                    known[-1][1] if known else np.nan,
                    (date - known[-1][0]) / 86400 if known else np.nan,
                    (date - positive[-1][0]) / 86400 if positive else np.nan,
                    len(known),
                    len(p) - len(known),
                ],
                strict=True,
            ):
                values[f"load_{g}_player_{field}"] = value
            values[f"load_{g}_club_last_observed_days_to_target"] = (date - c[-1][0]) / 86400 if c else np.nan
        end = bisect_left(eu, last)
        values["load_euro_global_last_observed_days_to_lock"] = (lock - eu[end - 1]) / 86400 if end else np.nan
        values["load_euro_global_fixtures365"] = end - bisect_left(eu, earliest)
        output[i] = [values[n] for n in names]
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "cache", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    corpus = json.loads(gzip.decompress(args.cache.with_suffix(".observations.json.gz").read_bytes()))
    fixtures, records, receipts, laliga, ll_sha = native_sources(args.archives, args.games)
    eu_fixtures = {k: f for k, f in fixtures.items() if f["source"] == "euro"}
    eu_records = {k: r for k, r in records.items() if r["source"] == "euro"}
    if (
        eu_fixtures != {f["game"]: f for f in corpus["fixtures"]}
        or eu_records != {(r["game"], r["player"]): r for r in corpus["records"]}
        or ll_sha != corpus["laligaSha256"]
        or ll_sha != report["laligaSha256"]
    ):
        raise ValueError("Full native workload observations differ")
    for receipt, saved in zip(receipts, corpus["receipts"], strict=True):
        if (
            receipt["sha256"] != saved["sha256"]
            or receipt["counts"].get("positive", 0) != saved["counts"].get("knownPositiveMinutes", 0)
            or receipt["counts"].get("zero", 0) != saved["counts"].get("knownZeroMinutes", 0)
            or receipt["counts"].get("unknown", 0) != saved["counts"].get("unknownMinutes", 0)
        ):
            raise ValueError("Independent source minute counts differ")
    key = hashlib.sha256(
        (source["key"] + ll_sha + "".join(r["sha256"] for r in receipts)).encode()
        + Path(workload.__file__).read_bytes()
        + Path(score_search.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    with np.load(args.cache) as f:
        x = f["x"]
        if str(f["key"]) != key or tuple(f["names"]) != workload.NAMES:
            raise ValueError("Workload source/code/plan identity differs")
    if key != report["featureKey"] or key != corpus["key"] or report["sourceKey"] != source["key"]:
        raise ValueError("Workload receipt identity differs")
    print("OBSERVED_WORKLOAD_AUDIT all38850 independent86columns", flush=True)
    repeated = independent_features(source["rows"], laliga, fixtures, records)
    if not np.array_equal(x, repeated, equal_nan=True):
        changed = np.argwhere(~(np.isclose(x, repeated, rtol=0, atol=1e-12) | (np.isnan(x) & np.isnan(repeated))))
        raise ValueError("Independent workload reconstruction differs: " + str(changed[:10].tolist()))
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    chosen = [i for i, r in enumerate(source["rows"]) if cutoff_for(r["date"]) == first and r["date"] >= "2026-01-01"]
    mutated = copy.deepcopy(corpus["records"])
    unavailable = 0
    for r in mutated:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            r["minutes"] = 117.0 if r["minutes"] is None else None
            unavailable += 1
    altered_ll = copy.deepcopy(laliga)
    for g in altered_ll:
        if moment(g["date"]) + timedelta(hours=48) >= first:
            for r in g["players"].values():
                r.update(mins=89 if r["played"] is True else 0, score=-999, aa=999, level=999)
    altered_rows = [{**source["rows"][i], "score": -999, "aa": 999, "level": 999, "minutes": -999} for i in chosen]
    refit, _ = workload.build_features(altered_rows, altered_ll, corpus["fixtures"], mutated)
    if not np.array_equal(refit, x[chosen], equal_nan=True):
        raise ValueError("Unavailable/current outcome mutation changes workload")
    result = dict(
        scope="Testing-only all-case feature integrity, no prediction accuracy claim",
        featureKey=key,
        cases=len(x),
        features=x.shape[1],
        independentNativeRecords=len(records),
        independentFixtures=len(fixtures),
        independentReceipts=receipts,
        everyFeatureExactlyReproducedIncludingMissing=True,
        unavailableMinuteRecordsMutated=unavailable,
        sameLockCurrentOutcomeCasesMutated=len(chosen),
        first2026Lock=first.isoformat(),
        futureAndCurrentMutationUnchanged=True,
        caution=report["sourceCaution"],
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
