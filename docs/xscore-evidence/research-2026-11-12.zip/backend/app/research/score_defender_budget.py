"""Compare individual defending forecasts with a predicted unit workload."""

import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_goal_context_rebuild import CONTEXT_KEY, INTENSITY, QUALITY
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, fit, metrics

STEM = "laliga_score_defender_budget"
AGE = timedelta(days=240)
GROUPS = (
    ("effective_clearance", "blocked_cross", "outfielder_block"),
    ("interception_won", "poss_won"),
    ("duel_won", "duel_lost", "won_tackle", "won_contest"),
)


def components(player):
    stats = player["stats"]
    groups = [[float(stats.get(k, (0, 0))[1]) for k in group] for group in GROUPS]
    return np.array([sum(group) for group in groups] + [sum(max(0, v) for v in group) for group in groups])


def recent(history, lock):
    return [r[1] for r in history if r[0] >= lock - AGE]


def allocate(person, own, forced, expected_minutes):
    known = bool(person and own and forced)
    player_total = np.sum(person, axis=0) if person else np.zeros(7)
    player_rate = player_total[1:] / (player_total[0] + 180)
    personal = expected_minutes * player_rate
    if not known:
        return personal, np.zeros(6), np.zeros(6)
    own_total, force_total = np.sum(own, axis=0), np.sum(forced, axis=0)
    own_rate = own_total[1:] / own_total[0]
    forced_rate = force_total[1:] / force_total[0]
    pooled = (own_rate + forced_rate) / 2
    # Relative opportunity comes from nonnegative action points. Keep negative duel points.
    ratio = (pooled[3:] + 0.04) / (own_rate[3:] + 0.04)
    ratio = np.clip(ratio, 0.6, 1.6)
    confidence = min(len(own), len(forced), len(person))
    change = personal * np.tile(ratio - 1, 2) * confidence / (confidence + 5)
    return personal, pooled * expected_minutes, change


def inputs(rows, games, names):
    keys = {g["id"]: g for g in games}
    appearances = defaultdict(list)
    for i, r in enumerate(rows):
        appearances[r["game"]].append(i)
    order = sorted(games, key=lambda g: (g["date"], g["id"]))
    historical = {}
    team, opponent, player = (defaultdict(lambda: deque(maxlen=15)) for _ in range(3))
    clocks = [moment(g["date"]) for g in order]
    minutes_idx = {role: names.index(f"{role}_10_minutes") for role in ("start", "bench")}
    base, candidate, y = np.empty((len(rows), 7)), np.empty((len(rows), 13)), np.empty((len(rows), 3))
    cursor = 0
    insufficient = 0
    for g in order:
        lock = cutoff_for(g["date"])
        while cursor < len(order) and clocks[cursor] + DELAY < lock:
            records, individuals = historical.pop(order[cursor]["id"])
            for club, other, info in records:
                team[club].append((clocks[cursor], info))
                opponent[other].append((clocks[cursor], info))
            for key, info in individuals:
                player[key].append((clocks[cursor], info))
            cursor += 1
        home, away = (g[side]["slug"] for side in ("home", "away"))
        totals = {home: np.zeros(7), away: np.zeros(7)}
        individuals = []
        for i in appearances[g["id"]]:
            r = rows[i]
            p = keys[r["game"]]["players"][r["player"]]
            club = p["team"]
            assert r["pos"] == p["pos"] == "DEF" and r["date"] == g["date"] and p["ver"] == 7 and club in totals
            other = away if club == home else home
            key = r["player"], club, r["cohort"]
            played = recent(player[key], lock)
            own, forced = recent(team[club], lock), recent(opponent[other], lock)
            expected_minutes = r["x"][minutes_idx[r["cohort"]]]
            personal, average, adjustment = allocate(played, own, forced, expected_minutes)
            base[i] = np.r_[personal, np.log1p(len(played))]
            candidate[i] = np.r_[average, adjustment, np.log1p(min(len(own), len(forced)))]
            points = components(p)
            observed = np.r_[p["mins"], points]
            totals[club] += observed
            individuals.append((key, observed))
            y[i] = points[:3]
        records = [
            (club, other, totals[club]) for club, other in ((home, away), (away, home)) if totals[club][0] >= 180
        ]
        insufficient += 2 - len(records)
        historical[g["id"]] = records, individuals
    return base, candidate, y, insufficient


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    ids = [i for i, r in enumerate(source["rows"]) if r["date"] < "2026-01-01" and r["pos"] == "DEF"]
    rows = [source["rows"][i] for i in ids]
    base, add, labels, insufficient = inputs(rows, games, source["features"])
    native = np.array([r["x"] for r in rows])
    cache = ROOT / "match_context_features.npz"
    with np.load(cache) as f:
        assert str(f["key"]) == CONTEXT_KEY
        names = f["names"].tolist()
        context = f["x"][ids][:, [names.index(n) for n in (*QUALITY, *INTENSITY)]]
    common = np.column_stack((native, base, np.nan_to_num(context), ~np.isfinite(context)))
    extended = np.column_stack((common, add))
    dates = np.array([r["date"] for r in rows])
    roles = np.array([r["cohort"] for r in rows])
    readiness = np.array([moment(d) + DELAY for d in dates])
    locks = np.array([cutoff_for(d) for d in dates])
    aa = np.array([r["aa"] for r in rows])
    defense = labels.sum(axis=1)
    individual_defense = base[:, :3].sum(axis=1)
    phases = {}
    for phase, (begin, end) in PHASES.items():
        period = (dates >= begin) & (dates < end)
        available = readiness < locks[period].min()
        phases[phase] = {}
        for role in ("start", "bench"):
            train, test = available & (roles == role), period & (roles == role)
            anchor = native[:, source["features"].index(f"{role}_10_aa")]
            forecast_points = [forecast(x, aa - anchor, train, test) for x in (common, extended)]
            p_def = [fit(x, defense - individual_defense, train, test) for x in (common, extended)]
            phases[phase][role] = dict(
                ordinary=metrics((aa - anchor)[test], *forecast_points),
                defensiveMAE=[float(np.mean(abs((defense - individual_defense)[test] - p))) for p in p_def],
                workloadKnown=int(np.count_nonzero(add[test, -1])),
            )
    gates = {}
    for role in ("start", "bench"):
        selected = [phases[phase][role] for phase in PHASES]
        n = sum(s["ordinary"]["n"] for s in selected)
        differences = np.array(
            [
                [
                    s["defensiveMAE"][0] - s["defensiveMAE"][1],
                    s["ordinary"]["mae"][0] - s["ordinary"]["mae"][1],
                    (s["ordinary"]["gained"] - s["ordinary"]["lost"]) / s["ordinary"]["n"],
                ]
                for s in selected
            ]
        )
        totals = np.average(differences, axis=0, weights=[s["ordinary"]["n"] for s in selected])
        stable = int(np.sum((differences >= 0).all(axis=1)))
        gates[role] = dict(
            n=n,
            defensiveMAEGain=float(totals[0]),
            routineMAEGain=float(totals[1]),
            routineHitGain=sum(s["ordinary"]["gained"] - s["ordinary"]["lost"] for s in selected),
            phasesWithoutLoss=stable,
            passEarlier=bool((totals > 0).all() and stable >= 2),
        )
    report = dict(
        nativeSHA=NATIVE_SHA,
        contextSHA=hashlib.sha256(cache.read_bytes()).hexdigest(),
        periods=phases,
        historicalSidesBelowMinimumDefenderMinutes=insufficient,
        gate=gates,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(gates, indent=2))


if __name__ == "__main__":
    main()
