"""Native-data audit and one fixed final evaluation of error-memory correction."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import defaultdict
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_event_probability as event
from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research import score_team_error_memory as study
from app.research.score_matchups_run import bank_from
from app.research.score_search import cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval


def independent_predict(classes, probability, location, positions, bank):
    """Integrate explicit clipped native score samples, not residual thresholds."""
    centres = np.arange(201) / 2
    result = []
    for i, pos in enumerate(positions):
        pooled = bank["positions"].get(pos, bank["global"])
        mass = np.zeros(201)
        for j, level in enumerate(classes):
            if probability[i, j] == 0:
                continue
            floor = level if level >= 60 else 0

            def contribution(errors, score_location=level + location[i, j], lower=floor):
                samples = np.clip(score_location + 0.75 * errors, lower, 100)
                return (
                    np.searchsorted(samples, centres + 7, side="right")
                    - np.searchsorted(samples, centres - 7, side="left")
                ) / len(samples)

            group = bank["levels"].get((pos, float(level)))
            component = contribution(pooled)
            if group is not None and len(group):
                component = (len(group) * contribution(group) + 20 * component) / (len(group) + 20)
            mass += probability[i, j] * component
        winners = np.flatnonzero(np.abs(mass - max(mass)) <= 1e-12)
        result.append(centres[min(winners, key=lambda k: (abs(centres[k] - centres[winners].mean()), k))])
    return np.array(result)


def native_records(rows, bundle, native, sides):
    classes, _, parts = bundle
    aggregate = defaultdict(list)
    unsupported = 0
    for i, row in enumerate(rows):
        person = native[row["game"], row["player"]]
        if person["level"] not in classes:
            unsupported += 1
            continue
        column = list(classes).index(person["level"])
        predicted = sorted(float(parts[q][i, column]) for q in (0.35, 0.5, 0.65))[1]
        club, other = sides[row["game"], row["player"]]
        aggregate[row["game"], row["date"], club, other, person["pos"], row["cohort"]].append(
            float(person["aa"]) - predicted
        )
    result = []
    for (game, date, club, other, pos, cohort), errors in aggregate.items():
        result.append(
            dict(
                game=game,
                available=(moment(date) + timedelta(hours=48)).timestamp(),
                club=club,
                opponent=other,
                pos=pos,
                cohort=cohort,
                residual=math.fsum(errors) / len(errors),
                members=len(errors),
            )
        )
    result.sort(key=lambda r: (r["available"], r["game"], r["club"], r["pos"], r["cohort"]))
    return result, unsupported


def direct_signals(rows, records, sides):
    """Independent eligible-record filtering and arithmetic; no study memory helpers."""
    grouped = defaultdict(list)
    for record in records:
        grouped[record["pos"], record["cohort"]].append(record)
    for values in grouped.values():
        values.sort(key=lambda r: (r["available"], r["game"], r["club"], r["pos"], r["cohort"]))
    by_query, values = {}, []
    for row in rows:
        club, opponent = sides[row["game"], row["player"]]
        lock = cutoff_for(row["date"]).timestamp()
        key = club, opponent, row["pos"], row["cohort"], lock
        if key not in by_query:
            eligible = [r for r in grouped[row["pos"], row["cohort"]] if r["available"] < lock]
            pool = eligible[-100:]
            baseline = math.fsum(r["residual"] for r in pool) / len(pool) if pool else 0
            own, against = (
                [r for r in eligible if r["club"] == club],
                [r for r in eligible if r["opponent"] == opponent],
            )
            signal = {}
            for name, history in (("own", own), ("opponent", against)):
                for size in (3, 10):
                    recent = history[-size:]
                    signal[f"{name}{size}"] = (
                        (math.fsum(r["residual"] for r in recent) - len(recent) * baseline) / (len(recent) + 5)
                        if recent
                        else 0
                    )
            signal["combined10"] = (signal["own10"] + signal["opponent10"]) / 2
            by_query[key] = [signal[s] for s in study.SIGNALS]
        values.append(by_query[key])
    return np.array(values)


def comparison(y, candidate, control, rows):
    new, old = np.abs(y - candidate) <= 7, np.abs(y - control) <= 7
    error_new, error_old = np.abs(y - candidate), np.abs(y - control)
    return {
        "metrics": measure(y, candidate),
        "correct": int(new.sum()),
        "rescued": int((new & ~old).sum()),
        "spoiled": int((old & ~new).sum()),
        "net": int(new.sum() - old.sum()),
        "largeMissesAbove25": int((error_new > 25).sum()),
        "controlLargeMissesAbove25": int((error_old > 25).sum()),
        "positions": {
            p: measure(y[np.array([r["pos"] == p for r in rows])], candidate[np.array([r["pos"] == p for r in rows])])
            for p in ("GK", "DEF", "MID", "FWD")
        },
        "rescuedByActualEvent": {
            name: int((new & ~old & np.array([test(r["level"]) for r in rows])).sum())
            for name, test in (
                ("neutral", lambda v: v == 35),
                ("positive", lambda v: v >= 60),
                ("negative", lambda v: v < 35),
            )
        },
        "gain95Gameweek": paired_interval(y, candidate, control, [r["week"] for r in rows]),
    }


def effective_share_probability(cache, phase, current, positions, bank, control, parent):
    with np.load(cache / f"laliga_score_team_share_start_{phase}_quality_half.npz") as f:
        if str(f["key"]) != parent["implementationKey"]:
            raise ValueError("Retained team-share rate key differs")
        rates = f["rates"]
    classes, old_probability, parts = current
    probability = event.event_probabilities(classes, rates[:, 0], rates[:, 1], "counts", old_probability)
    proposed = empirical.empirical_predictions(classes, probability, parts, positions, bank, 20, 0.75, 0)
    change = (positions != "GK") & ((proposed >= 60) != (control >= 60))
    effective = np.where(change[:, None], probability, old_probability)
    retained = np.where(change, proposed, control)
    np.testing.assert_array_equal(
        empirical.empirical_predictions(classes, effective, parts, positions, bank, 20, 0.75, 0), retained
    )
    return effective, retained


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--reports", type=Path, default=Path("reports/experiments"))
    parser.add_argument("--games", type=Path, required=True)
    args = parser.parse_args()
    prefix = "laliga_score_team_error_memory"
    source = json.loads((args.cache / "cases.json").read_text())
    read = lambda name: json.loads((args.reports / (name + ".json")).read_text())
    report = read(prefix)
    old_match, old_stability, old_ordinary, share = map(
        read,
        ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary", "laliga_score_team_share"),
    )
    key = hashlib.sha256(
        (
            source["key"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
        ).encode()
        + Path(study.__file__).read_bytes()
        + (args.reports / (prefix + ".plan.json")).read_bytes()
    ).hexdigest()
    if key != report["implementationKey"] or any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, share)
    ):
        raise ValueError("Frozen study fingerprint/source differs")
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    native, sides = {}, {}
    for game in (json.loads(line) for line in raw.decode().splitlines() if line.strip()):
        for player, p in game["players"].items():
            native[game["id"], player] = p
            sides[game["id"], player] = (
                p["team"],
                game["away" if p["team"] == game["home"]["slug"] else "home"]["slug"],
            )
    for r in source["rows"]:
        p = native[r["game"], r["player"]]
        if (
            p["ver"] != 7
            or not p["played"]
            or p["started"] != (r["cohort"] == "start")
            or p["pos"] != r["pos"]
            or p["mins"] != r["minutes"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("aa", "level", "score"))
        ):
            raise ValueError("Native case mismatch")
    audit = {"implementationKey": key, "nativeCasesVerified": len(source["rows"]), "cohorts": {}}
    starter_context = None
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache)
        bundles, phase_rows, records = {}, {}, []
        for phase, _, _ in stability.PHASES[:-1]:
            bundles[phase] = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            phase_rows[phase] = [r for r, yes in zip(rows, masks[phase]["target"], strict=True) if yes]
            independent, unsupported = native_records(phase_rows[phase], bundles[phase], native, sides)
            expected = report["cohorts"][cohort]["pastRecordReceipts"][phase]
            if len(independent) != expected["teamRoleRecords"] or unsupported != expected["unsupportedPastLevels"]:
                raise ValueError("Native grouping coverage mismatch")
            records.extend(independent)
        frozen = read(prefix + f".{cohort}.frozen")
        candidates = frozen["candidates"]
        for candidate in candidates:
            for phase in ("spring2024", "season2024", "autumn2025"):
                spec = candidate["spec"]
                with np.load(
                    args.cache / f"{prefix}_{cohort}_{phase}_{spec['signal']}_w{spec['weight']}_{spec['scope']}.npz"
                ) as f:
                    if (
                        str(f["key"]) != key
                        or measure(np.array([r["score"] for r in phase_rows[phase]]), f["prediction"])
                        != candidate["periods"][phase]["metrics"]
                    ):
                        raise ValueError("Earlier candidate native metrics mismatch")
        independent_best = max(
            candidates,
            key=lambda r: (
                min(r["gains"]),
                sum(g * n for g, n in zip(r["gains"], r["counts"], strict=True)) / sum(r["counts"]),
                -sum(e * n for e, n in zip(r["maes"], r["counts"], strict=True)) / sum(r["counts"]),
            ),
        )
        if independent_best != frozen["best"] or ((min(independent_best["gains"]) > 0) != bool(frozen["winner"])):
            raise ValueError("Independent earlier selection mismatch")
        feature_rows, selected_predictions = 0, 0
        earlier = {}
        for phase, prior in (("spring2024", "warm2023"), ("season2024", "spring2024"), ("autumn2025", "season2024")):
            target_rows = phase_rows[phase]
            signals = direct_signals(target_rows, records, sides)
            with np.load(args.cache / f"{prefix}_{cohort}_{phase}_signals.npz") as f:
                if str(f["key"]) != key:
                    raise ValueError("Earlier signal cache key mismatch")
                np.testing.assert_allclose(signals, f["x"], rtol=0, atol=1e-10)
                control = f["control"]
            feature_rows += len(signals)
            if cohort != "start":
                continue
            current = bundles[phase]
            pos = np.array([r["pos"] for r in target_rows])
            bank = bank_from(bundles[prior], phase_rows[prior], masks[phase]["first"])
            classes, probability, parts = current
            location, _ = empirical.location_scale(parts, "raw")
            np.testing.assert_array_equal(independent_predict(classes, probability, location, pos, bank), control)
            spec = frozen["winner"]["spec"]
            delta = np.clip(signals[:, study.SIGNALS.index(spec["signal"])] * spec["weight"], -12, 12)
            delta[pos != "DEF"] = 0
            shifted_location = location + delta[:, None]
            selected = independent_predict(classes, probability, shifted_location, pos, bank)
            with np.load(
                args.cache / f"{prefix}_{cohort}_{phase}_{spec['signal']}_w{spec['weight']}_{spec['scope']}.npz"
            ) as f:
                np.testing.assert_array_equal(selected, f["prediction"])
            selected_predictions += len(selected)
            effective, retained = effective_share_probability(args.cache, phase, current, pos, bank, control, share)
            y = np.array([r["score"] for r in target_rows])
            parent_freeze = read("laliga_score_team_share.start.frozen")
            if measure(y, retained) != parent_freeze["winner"]["periods"][phase]["metrics"]:
                raise ValueError("Retained earlier best does not reproduce")
            combined = independent_predict(classes, effective, shifted_location, pos, bank)
            combined[pos != "DEF"] = retained[pos != "DEF"]
            earlier[phase] = comparison(y, combined, retained, target_rows)
        audit["cohorts"][cohort] = {
            "allEarlierNativeMetricVectorsVerified": len(candidates) * 3,
            "independentMemoryFeatureRows": feature_rows,
            "independentNativeSampleForecastRows": selected_predictions,
            "frozenSelectionVerified": True,
        }
        if cohort == "start":
            accepted = all(v["net"] > 0 for v in earlier.values())
            compatibility = {
                "parentKey": key,
                "teamShareKey": share["implementationKey"],
                "fixedSpec": frozen["winner"]["spec"],
                "earlier": earlier,
                "accepted": accepted,
                "registeredPlanSha256": hashlib.sha256(
                    (args.reports / (prefix + ".compatibility.plan.json")).read_bytes()
                ).hexdigest(),
            }
            (args.reports / (prefix + ".compatibility.frozen.json")).write_text(
                json.dumps(compatibility, indent=2, allow_nan=False)
            )
            starter_context = (rows, masks, call, bundles, phase_rows, records, compatibility, frozen)
            print(
                "COMPATIBILITY_FROZEN "
                + json.dumps({"accepted": accepted, "netByPeriod": {p: r["net"] for p, r in earlier.items()}}),
                flush=True,
            )
    (args.reports / (prefix + ".integrity.json")).write_text(json.dumps(audit, indent=2, allow_nan=False))
    rows, masks, call, bundles, phase_rows, records, compatibility, frozen = starter_context
    current = flow.old_components(call, "start", "later2026", old_match, old_stability, old_ordinary)
    target_rows = [r for r, yes in zip(rows, masks["later2026"]["target"], strict=True) if yes]
    later_records, _ = native_records(target_rows, current, native, sides)
    signals = direct_signals(target_rows, records + later_records, sides)
    classes, probability, parts = current
    pos = np.array([r["pos"] for r in target_rows])
    bank = bank_from(bundles["autumn2025"], phase_rows["autumn2025"], masks["later2026"]["first"])
    location, _ = empirical.location_scale(parts, "raw")
    control = independent_predict(classes, probability, location, pos, bank)
    effective, retained = effective_share_probability(args.cache, "later2026", current, pos, bank, control, share)
    with np.load(args.cache / "laliga_score_team_share_predictions_start.npz") as f:
        y = np.array([r["score"] for r in target_rows])
        if str(f["key"]) != share["implementationKey"] or len(y) != 6754:
            raise ValueError("Final retained source key/count differs")
        np.testing.assert_array_equal(y, f["y"])
        np.testing.assert_array_equal(control, f["control"])
        np.testing.assert_array_equal(retained, f["prediction"])
    spec = frozen["winner"]["spec"]
    delta = np.clip(signals[:, study.SIGNALS.index(spec["signal"])] * spec["weight"], -12, 12)
    delta[pos != "DEF"] = 0
    prediction = independent_predict(classes, probability, location + delta[:, None], pos, bank)
    # Cross-check the frozen native-sample method against the original threshold implementation.
    shifted = {q: values + delta[:, None] for q, values in parts.items()}
    np.testing.assert_array_equal(
        prediction, empirical.empirical_predictions(classes, probability, shifted, pos, bank, 20, 0.75, 0)
    )
    final = {
        "sourceKey": source["key"],
        "implementationKey": key,
        "scope": "All6754 starts; fixed earlier-selected correction; actual outcomes never forecast inputs. Reused historical data, not fresh blind proof.",
        "originalCorrection": comparison(y, prediction, control, target_rows),
        "againstRetainedBest": comparison(y, prediction, retained, target_rows),
        "substitutes": "Earlier gate failed; keep accepted2201/2925, no new final bench candidate evaluated",
        "compatibility": compatibility,
    }
    np.savez_compressed(
        args.cache / (prefix + "_predictions_start.npz"),
        key=key,
        y=y,
        prediction=prediction,
        control=control,
        retained=retained,
        delta=delta,
        signals=signals,
    )
    if compatibility["accepted"]:
        combined = independent_predict(classes, effective, location + delta[:, None], pos, bank)
        combined[pos != "DEF"] = retained[pos != "DEF"]
        final["combinedCorrection"] = comparison(y, combined, retained, target_rows)
        np.savez_compressed(
            args.cache / (prefix + "_combined_predictions_start.npz"),
            key=key,
            y=y,
            prediction=combined,
            control=retained,
        )
    (args.reports / (prefix + ".final.json")).write_text(json.dumps(final, indent=2, allow_nan=False))
    print(
        "FINAL "
        + json.dumps(
            {
                k: {
                    field: v[field]
                    for field in ("correct", "rescued", "spoiled", "net", "largeMissesAbove25", "gain95Gameweek")
                }
                for k, v in final.items()
                if k in ("originalCorrection", "againstRetainedBest", "combinedCorrection")
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
