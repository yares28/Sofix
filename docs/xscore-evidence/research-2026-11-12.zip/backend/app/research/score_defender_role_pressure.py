"""Screen empirical within-role defensive score histories against matchup pressure."""

import hashlib
import json
from collections import defaultdict, deque

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_defender_slots import AGE, ROLES, Slots, history_features
from app.research.score_failure_review import activity_groups
from app.research.score_goal_context_rebuild import CONTEXT_KEY
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_substitution_clock import capture
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_defender_role_pressure"
CENTRES = np.arange(-24, 49, 2)


def window_summary(values, weights):
    if len(values) == 0:
        return np.zeros(3)
    mass = (np.abs(np.array(values)[:, None] - CENTRES) <= 7).T @ weights
    mass = mass / weights.sum()
    selected = np.flatnonzero(np.abs(mass - mass.max()) <= 1e-12)
    mean = float(weights @ values / weights.sum())
    winner = selected[np.argmin(abs(CENTRES[selected] - mean))]
    return np.array([CENTRES[winner], mass[winner], mean])


def pressure_weight(past, current):
    comparable = np.isfinite(past) & np.isfinite(current)
    gap = np.where(comparable, np.abs(past - current), 0)
    return np.exp(-gap.sum(axis=1) / np.maximum(comparable.sum(axis=1), 1))


def summarize(history, role_mix, pressure):
    if not history:
        return np.zeros((4, 3))
    slots, values, past = zip(*history, strict=True)
    slots, values, past = np.array(slots), np.array(values), np.array(past)
    weights_by_role = (1 + role_mix[slots]) / (1 + np.bincount(slots, minlength=3)[slots] / len(slots))
    weights_by_pressure = pressure_weight(past, pressure)
    weights = (np.ones(len(slots)), weights_by_role, weights_by_pressure, weights_by_role * weights_by_pressure)
    return np.array([window_summary(values, w) for w in weights])


def generate(rows, games, roles, pressure, names):
    locks = [cutoff_for(row["date"]) for row in rows]
    queue = sorted(
        (moment(r["date"]) + DELAY, i, roles[(r["game"], r["player"])])
        for i, r in enumerate(rows)
        if (r["game"], r["player"]) in roles
    )
    people = defaultdict(lambda: deque(maxlen=30))
    units = defaultdict(lambda: deque(maxlen=160))
    outputs = np.zeros((len(rows), 4, 3))
    metadata = np.zeros((len(rows), 6))
    diagnostics, cursor = [], 0
    aa_idx = {r: names.index(f"{r}_10_aa") for r in ("start", "bench")}
    for i in sorted(range(len(rows)), key=locks.__getitem__):
        r, lock = rows[i], locks[i]
        while cursor < len(queue) and queue[cursor][0] < lock:
            ready, j, observation = queue[cursor]
            code = ROLES.index(observation["slot"])
            key = observation["club"], observation["cohort"]
            assert observation["aa"] == rows[j]["aa"]
            people[observation["player"], *key].append((ready - DELAY, code, observation["aa"], pressure[j], j))
            units[key].append((ready - DELAY, code, observation["aa"]))
            cursor += 1
        club = games[r["game"]]["players"][r["player"]]["team"]
        key = club, r["cohort"]
        history = [entry for entry in people[r["player"], *key] if entry[0] >= lock - AGE]
        previous = [(slot, aa, p) for _, slot, aa, p, _ in history]
        pooled = [(slot, aa) for t, slot, aa in units[key] if t >= lock - AGE]
        fallback = r["x"][aa_idx[r["cohort"]]]
        anchor, role = history_features([(slot, aa) for slot, aa, _ in previous], pooled, fallback)
        outputs[i] = summarize(previous, role[:3], pressure[i])
        if not previous:
            outputs[i, :, 0] = fallback
            outputs[i, :, 2] = fallback
        metadata[i] = anchor, np.log1p(len(previous)), np.log1p(len(pooled)), *role[:3]
        actual = roles.get((r["game"], r["player"]))
        if actual and previous:
            code = ROLES.index(actual["slot"])
            last, aa, _ = previous[-1]
            diagnostics.append((i, history[-1][-1], last == code, abs(aa - r["aa"])))
    return metadata, outputs, diagnostics


def miss_components(rows, games, diagnostics):
    biggest = defaultdict(int)
    margin = []
    matched = 0
    for i, previous, same_role, difference in diagnostics:
        row, past = rows[i], rows[previous]
        if not same_role or row["cohort"] != "start" or difference <= 25 or row["date"] < "2024-01-01":
            continue
        current = games[row["game"]]["players"][row["player"]]
        old = games[past["game"]]["players"][past["player"]]
        a, b = (activity_groups(p["stats"]) for p in (current, old))
        shifts = {k: a[k] - b[k] for k in a}
        signed = row["aa"] - past["aa"]
        assert abs(sum(shifts.values()) - signed) < 1e-6
        direction = 1 if signed > 0 else -1
        key = max(shifts, key=lambda k: direction * shifts[k])
        biggest[key] += 1
        if abs(row["minutes"] - past["minutes"]) <= 10:
            matched += 1
        margin.append(abs(signed - shifts["cleanSheetAndConceded"]))
    return dict(
        largeSameRoleChanges=len(margin),
        withMinutesWithinTen=matched,
        largestSameDirectionGroup=dict(biggest),
        stillOver25AfterRemovingCleanSheetAndConceded=sum(v > 25 for v in margin),
        scope="Same-player same-club earlier starter appearance pairs. Past stat breakdowns used only for diagnosis.",
    )


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    source = json.loads((ROOT / "cases.json").read_bytes())
    indices = [i for i, r in enumerate(source["rows"]) if r["game"] in games and r["pos"] == "DEF"]
    rows = [source["rows"][i] for i in indices]
    native = np.array([r["x"] for r in rows])
    names = source["features"]
    cache = ROOT / "match_context_features.npz"
    with np.load(cache) as f:
        assert str(f["key"]) == CONTEXT_KEY
        ctx = f["names"].tolist()
        historical = f["x"][indices][
            :, [ctx.index(k) for k in ("opponent_10_sot_for_mean", "opponent_10_box_for_mean")]
        ]
    home, away, side = (names.index(k) for k in ("match_lam_h", "match_lam_a", "home"))
    pressure = np.column_stack((np.where(native[:, side] > 0, native[:, away], native[:, home]), historical / [2, 4]))
    pressure[pressure < 0] = np.nan
    alias = json.loads((ROOT / "player_names.json").read_bytes())
    slots = Slots(alias)
    _, _, digest = capture(list(games.values()), alias, observe=slots.observe)
    receipt = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    assert digest == receipt["archiveReadSHA"]
    metadata, windows, diagnostics = generate(rows, games, slots.records, pressure, names)
    base = np.column_stack((native, np.nan_to_num(pressure), ~np.isfinite(pressure), metadata, windows[:, 0]))
    arms = {
        "control": base,
        "role": np.column_stack((base, windows[:, 1])),
        "pressure": np.column_stack((base, windows[:, 2])),
        "joint": np.column_stack((base, windows[:, 1:].reshape(len(rows), 9))),
    }
    cohort = np.array([r["cohort"] for r in rows])
    dates = np.array([r["date"] for r in rows])
    ready = np.array([moment(r["date"]) + DELAY for r in rows])
    locks = np.array([cutoff_for(r["date"]) for r in rows])
    y = np.array([r["aa"] for r in rows]) - metadata[:, 0]
    periods = {}
    bench_effect = {}
    for phase, (begin, end) in PHASES.items():
        selected = (dates >= begin) & (dates < end)
        available = ready < locks[selected].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, test = available & (cohort == role), selected & (cohort == role)
            predictions = {name: forecast(x, y, train, test) for name, x in arms.items()}
            if role == "bench":
                chosen = np.flatnonzero(test)
                bench_effect[phase] = [
                    [rows[i]["game"], rows[i]["player"], float(np.clip(delta, -3, 3))]
                    for i, delta in zip(chosen, predictions["joint"] - predictions["control"], strict=True)
                    if metadata[i, 1] >= np.log1p(3)
                ]
            group = {}
            for match in (True, False):
                values = [v for i, _, same, v in diagnostics if test[i] and same == match]
                group["same" if match else "changed"] = dict(
                    n=len(values),
                    medianAbs=float(np.median(values)) if values else None,
                    differencesOver25=sum(v > 25 for v in values),
                )
            periods[phase][role] = dict(
                **{
                    name: metrics(y[test], predictions["control"], predictions[name])
                    for name in arms
                    if name != "control"
                },
                historicalRoleDiagnostics=group,
            )
    gates = {}
    for role in ("start", "bench"):
        gates[role] = {}
        for name in ("role", "pressure", "joint"):
            data = [v[role][name] for v in periods.values()]
            n = sum(p["n"] for p in data)
            net = sum(p["gained"] - p["lost"] for p in data)
            mae = sum(p["n"] * (p["mae"][0] - p["mae"][1]) for p in data) / n
            stable = sum(p["hits"][1] >= p["hits"][0] and p["mae"][1] <= p["mae"][0] for p in data)
            outperforms = name != "joint" or all(net > r["net"] and mae > r["maeGain"] for r in gates[role].values())
            gates[role][name] = dict(
                n=n,
                net=net,
                maeGain=mae,
                phasesWithoutLoss=stable,
                passEarlier=net > 0 and mae > 0 and stable >= 2 and outperforms,
            )
    result = dict(nativeSHA=NATIVE_SHA, roleSourceSHA=digest, periods=periods, gate=gates, laterEvaluated=False)
    result["largeSameRoleDiagnostics"] = miss_components(rows, games, diagnostics)
    effect_bytes = (json.dumps(bench_effect, separators=(",", ":")) + "\n").encode()
    (ROOT / (STEM + "_bench_effect.json")).write_bytes(effect_bytes)
    result["benchEffectSHA"] = hashlib.sha256(effect_bytes).hexdigest()
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(gates, indent=2))


if __name__ == "__main__":
    main()
