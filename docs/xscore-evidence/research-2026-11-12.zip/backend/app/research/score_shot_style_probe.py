"""Offline source-only shot style and goal/SOT consistency probe."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research.score_match_context import CLUBS, normalise
from app.research.score_prior_chances import words


def provider_quality(shot):
    values = [shot.get(k) for k in ("xg_fotmob", "xg_understat")]
    valid = [v for v in values if type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1]
    return sum(valid) / len(valid) if valid else None


def interior(shot):
    return all(type(shot.get(k)) in (int, float) and math.isfinite(shot[k]) and 0 < shot[k] < 100 for k in ("x", "y"))


def summarize(events, side):
    if side not in ("home", "away"):
        raise ValueError("Canonical side required")
    if not isinstance(events, list):
        return dict(
            streamPresent=False,
            shots=None,
            goalCount=None,
            onTargetCount=None,
            usableCoordinates=None,
            body={},
            situation={},
            providerQualityKnown=None,
            invalidGoalFlags=None,
            invalidOnTargetFlags=None,
        )
    own = [e for e in events if e.get("team") == side]
    goals = [e.get("goal") for e in own]
    target = [e.get("onTarget") for e in own]
    return dict(
        streamPresent=True,
        shots=len(own),
        goalCount=sum(goals) if all(type(v) is bool for v in goals) else None,
        onTargetCount=sum(target) if all(type(v) is bool for v in target) else None,
        usableCoordinates=sum(interior(e) for e in own),
        body=dict(Counter(e.get("body") if isinstance(e.get("body"), str) else "__UNKNOWN__" for e in own)),
        situation=dict(Counter(e.get("sit") if isinstance(e.get("sit"), str) else "__UNKNOWN__" for e in own)),
        providerQualityKnown=sum(provider_quality(e) is not None for e in own),
        invalidGoalFlags=sum(type(v) is not bool for v in goals),
        invalidOnTargetFlags=sum(type(v) is not bool for v in target),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_shot_style_probe.json"))
    args = parser.parse_args()
    raw = args.games.read_bytes()
    pressure = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    qualified = (args.cache / "pass_source_qualified_observations.json.gz").read_bytes()
    if (
        hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(pressure).hexdigest() != "daba17833020e8212346bb79f8b0918b69ab5e2a36ad60cc44d3fb1a4f7d064a"
        or hashlib.sha256(qualified).hexdigest() != "a2892cc89775820d2c4835bd5803f9054c2b1635d11607ac1e2345aae05865d4"
    ):
        raise ValueError("Pinned source identity changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    sides = json.loads(gzip.decompress(pressure))["observations"]
    people = defaultdict(list)
    for r in json.loads(gzip.decompress(qualified))["records"]:
        people[r["game"], r["club"]].append(r)
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        {
            normalise(k): CLUBS[v]
            for k, v in (
                ("Alaves", "Deportivo Alaves"),
                ("Celta", "Celta Vigo"),
                ("Deportivo La Coruna", "Deportivo A Coruna"),
            )
        }
    )
    counts, body, situation, gaps, person_counts = Counter(), Counter(), Counter(), Counter(), Counter()
    orientation, samples, records, person_records = defaultdict(list), [], [], []
    last_game, detail = None, None
    for r in sides:
        g = games[r["game"]]
        if g["id"] != last_game:
            canonical = (args.repo / r["sourcePath"]).read_bytes().replace(b"\r\n", b"\n")
            if hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest() != r["sourceBlob"]:
                raise ValueError("Raw shot source changed")
            detail = json.loads(canonical.decode().partition("=")[2].strip().removesuffix(";"))
            if any(
                clubs.get(normalise(detail[s].get("name", ""))) != g[s]["slug"]
                or detail[s].get("score") != g[s + "Goals"]
                for s in ("home", "away")
            ):
                raise ValueError("Canonical fixture header differs")
            counts["verifiedFixtures"] += 1
            last_game = g["id"]
        side = "home" if g["home"]["slug"] == r["club"] else "away"
        if r["date"] != g["date"] or r["opponent"] != g["away" if side == "home" else "home"]["slug"]:
            raise ValueError("Canonical shot side identity differs")
        events = detail.get("shots")
        summary = summarize(events, side)
        own = [e for e in events if e.get("team") == side] if isinstance(events, list) else None
        native = [
            p
            for p in g["players"].values()
            if p.get("played") is True and p.get("team") == r["club"] and p.get("ver") == 7
        ]
        fields = {}
        for stat, source_field in (
            ("goals", "goalCount"),
            ("ontarget_scoring_att", "onTargetCount"),
            ("total_scoring_att", "shots"),
        ):
            observed = [p["stats"][stat][0] for p in native if stat in p.get("stats", {})]
            total = sum(observed) if observed else None
            fields[stat] = dict(
                explicitNativeRecords=len(observed), observedNativeTotal=total, sourceTotal=summary[source_field]
            )
            if observed and summary[source_field] is not None:
                gaps[stat + "_observedTotalAgrees"] += int(total == summary[source_field])
                gaps[stat + "_sourceBelowObservedNative"] += int(summary[source_field] < total)
                gaps[stat + "_comparableSides"] += 1
        counts["sides"] += 1
        counts["streamPresentSides"] += summary["streamPresent"]
        if own is not None:
            for key in (
                "shots",
                "usableCoordinates",
                "providerQualityKnown",
                "invalidGoalFlags",
                "invalidOnTargetFlags",
            ):
                counts[key] += summary[key]
            body.update(summary["body"])
            situation.update(summary["situation"])
            orientation[side].extend(e["x"] for e in own if interior(e))
            orientation[side + "_goal"].extend(e["x"] for e in own if interior(e) and e.get("goal") is True)
        indexed = defaultdict(list)
        for e in own or []:
            indexed[words(e.get("player", ""))].append(e)
        for p in people[g["id"], r["club"]]:
            name = p["geometrySource"]["player"]
            own_shots = indexed[words(name)] if name is not None and own is not None else None
            pp = g["players"][p["player"]]
            old_rate = p["values"].get("chance_shots90")
            old_count = old_rate * p["minutes"] / 90 if old_rate is not None else None
            count_consistent = (
                own_shots is not None and old_count is not None and abs(len(own_shots) - old_count) < 1e-8
            )
            ps = (
                summarize([{**e, "team": "home"} for e in own_shots], "home")
                if own_shots is not None
                else summarize(None, "home")
            )
            reasons = []
            if own_shots is None:
                reasons.append("actor_or_stream_unavailable")
            if not count_consistent:
                reasons.append("previously_verified_actor_count_unavailable_or_differs")
            for stat, field in (("goals", "goalCount"), ("ontarget_scoring_att", "onTargetCount")):
                count = pp.get("stats", {}).get(stat, [None])[0]
                if count is not None and ps[field] is not None and count > ps[field]:
                    reasons.append("source_below_native_" + stat)
            person_counts["records"] += 1
            person_counts["actorAttributed"] += own_shots is not None
            person_counts["knownRawCountMatchesPrior"] += count_consistent
            person_counts["qualifiedKnown"] += not reasons
            person_counts.update(reasons)
            if reasons and len(samples) < 15:
                samples.append(dict(game=g["id"], player=p["player"], sourcePlayer=name, reasons=reasons))
            person_records.append(
                dict(
                    game=g["id"],
                    date=g["date"],
                    player=p["player"],
                    club=r["club"],
                    cohort=p["cohort"],
                    minutes=p["minutes"],
                    sourcePlayer=name,
                    known=not reasons,
                    reasons=reasons,
                    summary=ps,
                )
            )
        records.append(
            {
                **{k: r[k] for k in ("game", "date", "club", "opponent", "sourcePath", "sourceBlob")},
                "shotSource": summary,
                "nativeComparisons": fields,
                "shots": own,
            }
        )
    if counts["verifiedFixtures"] != 1218 or counts["sides"] != 2436 or person_counts["records"] != 34871:
        raise ValueError("Shot source coverage changed")
    key = hashlib.sha256(
        raw + pressure + qualified + Path(__file__).read_bytes() + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    archive = args.cache / "shot_style_observations.json.gz"
    archive.write_bytes(
        gzip.compress(
            json.dumps(
                dict(key=key, sides=records, players=person_records), separators=(",", ":"), allow_nan=False
            ).encode(),
            mtime=0,
        )
    )
    output = dict(
        scope="Source-only qualification, not accuracy improvement",
        implementationKey=key,
        observationsSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        counts=dict(counts),
        literalBodyLabels=dict(body),
        literalSituationLabels=dict(situation),
        nativeCountComparisons=dict(gaps),
        playerAttribution=dict(person_counts),
        frameX={k: dict(n=len(v), mean=float(np.mean(v))) for k, v in orientation.items()},
        unknownPlayerSamples=samples,
        limitation="Recorded subsets and field-level count checks do not prove complete failed-shot coverage. Unknown actor profiles retained, never forecast exclusions. No model fitting or scoring accuracy evaluated.",
    )
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print(
        "SHOT_STYLE_SOURCE " + json.dumps({k: v for k, v in output.items() if k != "unknownPlayerSamples"}), flush=True
    )


if __name__ == "__main__":
    main()
