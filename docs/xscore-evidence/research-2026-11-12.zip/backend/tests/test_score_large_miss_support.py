import numpy as np

from app.research import score_large_miss_support as support


def test_similarity_includes_seven_and_unknown_is_not_zero():
    assert support.similar_count([33.0, 47.0, 32.9, 47.1], 40.0) == 2
    assert support.history_summary([], 40.0, 10.0)["similarScore10"] is None
    assert support.history_summary([{"score": 0.0, "aa": 0.0}], 0.0, 0.0)["similarScore10"] == 1


def test_history_excludes_exact_availability_boundary_and_wrong_cohort():
    rows = [
        dict(game="a", player="p", cohort="start", date="2023-12-01T14:00:00Z", score=40.0, aa=5.0),
        dict(game="b", player="p", cohort="bench", date="2023-12-02T14:00:00Z", score=80.0, aa=20.0),
        dict(game="c", player="p", cohort="start", date="2023-12-31T14:00:00Z", score=90.0, aa=30.0),
        dict(game="d", player="p", cohort="start", date="2024-01-02T20:00:00Z", score=60.0, aa=25.0),
    ]
    h = support.player_histories(rows)
    assert [r["game"] for r in h[-1]] == ["a"]
    assert support.history_summary(h[-1], 60.0, 25.0)["count"] == 1
    assert not np.isnan(support.history_summary(h[-1], 60.0, 25.0)["maxAA10"])


def test_same_total_from_goals_is_not_evidence_of_same_ordinary_performance():
    target = [dict(score=80.0, aa=45.0, level=35.0)]
    previous = [[dict(score=80.0, aa=20.0, level=60.0) for _ in range(5)]]
    result = support.support_stats(target, previous, np.array([True]))["previous10"]
    assert result["actualScoreHadSimilarPastScore"] == 1
    assert result["actualScoreHadSimilarPastScoreSameEventState"] == 0
    assert result["anyPastSameEventState"] == 0
