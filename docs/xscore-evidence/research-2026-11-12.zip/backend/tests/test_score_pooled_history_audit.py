"""Testing only: independently checked shared history preserves modes and censored AA."""

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_pooled_history_audit as audit
from app.research.score_search import cutoff_for


def test_shared_score_reference_keeps_one_peak_and_censored_observations():
    records = []
    for i, (score, level) in enumerate(((0, 35), (0, 15), (90, 60), (90, 35), (100, 60))):
        records.append(
            dict(
                date=f"2024-01-0{i + 1}T12:00:00Z",
                score=score,
                level=level,
                minutes=90,
                ordinary=ordinary.ordinary_bounds(score, level),
            )
        )
    lock = cutoff_for("2024-02-03T20:00:00Z")
    expected = audit.score_summary(records, lock)
    actual = ordinary.summarise(records, 15, lock)
    np.testing.assert_allclose(expected, actual, atol=1e-12, rtol=0)
    assert sum(abs(r["score"] - expected[4]) <= 7 for r in records) == 3
    assert expected[9] == 2
    assert expected[12] == 2 / 5
    assert expected[13] == 1 / 5


def test_shared_score_reference_cold_start_retains_missing_rates():
    lock = cutoff_for("2024-02-03T20:00:00Z")
    np.testing.assert_array_equal(audit.score_summary([], lock), ordinary.summarise([], 15, lock))
