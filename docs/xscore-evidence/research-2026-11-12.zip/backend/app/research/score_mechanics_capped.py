"""Testing-only adapter: enforce the observed full-match Sorare exposure ceiling."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from app.research import score_mechanics as mechanics
from app.research import score_mechanics_run as runner


def bounded_locations(pieces, indices, minute_errors, minute_spread):
    minutes = np.clip(pieces["minutes"][:, None] + minute_errors * minute_spread, 1, 90)
    # Training exposure never exceeds90. Every split is below that maximum,
    # so the existing tree prediction at95 equals its prediction at90.
    grid = np.concatenate((mechanics.MINUTE_GRID[:-1], [90]))
    clipped = np.clip(minutes, grid[0], grid[-1])
    high = np.searchsorted(grid, clipped, side="left")
    low = np.maximum(0, high - 1)
    width = grid[high] - grid[low]
    ratio = np.divide(clipped - grid[low], width, out=np.zeros_like(clipped), where=width > 0)
    rows = np.arange(len(minutes))[:, None]
    left, right = pieces["locations"][rows, low, indices], pieces["locations"][rows, high, indices]
    return minutes, left * (1 - ratio) + right * ratio


def main():
    parser = argparse.ArgumentParser(add_help=False)
    for name in ("out", "cache", "cases"):
        parser.add_argument("--" + name, type=Path, required=True)
    args, _ = parser.parse_known_args()
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    digest = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if plan["adapterSourceSha256"] != digest:
        raise ValueError("Bounded-exposure adapter differs from registered plan")
    reference = json.loads((args.out.parent / "laliga_score_mechanics.json").read_text())
    source = json.loads(args.cases.read_text())
    if source["key"] != reference["sourceKey"]:
        raise ValueError("Reused mechanics models have different source cases")
    reused = []

    def cached_pieces(frame, cats, base_aa, base_net, minutes, mask, path, key):
        if np.max(minutes[mask["fit"]]) > 90:
            raise ValueError("Original tree exposure exceeds the declared ceiling")
        original = args.cache / path.name.replace(args.out.stem, "laliga_score_mechanics", 1)
        with np.load(original) as stored:
            if str(stored["key"]) != reference["implementationKey"]:
                raise ValueError("Reused mechanics component identity differs")
            pieces = {
                name: stored[name] for name in ("classes", "probability", "locations", "minutes", "factual_location")
            }
        if len(pieces["minutes"]) != mask["target"].sum():
            raise ValueError("Reused mechanics target count differs")
        pieces["minutes"] = np.minimum(pieces["minutes"], 90)
        reused.append(original.name)
        return pieces

    # These process-local adapters leave the original research results reproducible.
    mechanics.fitted_pieces = cached_pieces
    mechanics.sampled_base_locations = bounded_locations
    runner.main()
    report = json.loads(args.out.read_text())
    report.update(
        {
            "minuteCeiling": 90,
            "adapterSourceSha256": digest,
            "componentModelKey": reference["implementationKey"],
            "reusedComponentFiles": reused,
        }
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
