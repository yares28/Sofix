import numpy as np

from app.research.score_analogues import (
    eligible,
    lookup_neighbours,
    predict_lookup,
    prepare_lookup,
    prepare_windows,
    weighted_prediction,
)


def test_lookup_cannot_use_the_target_or_unavailable_same_week_result():
    available = np.array([10, 20, 30, 40])
    positions = np.array(["MID", "MID", "FWD", "MID"])
    assert eligible(available, positions, 20, "MID").tolist() == [True, False, False, False]


def test_modes_choose_a_real_high_probability_window_instead_of_mean():
    centres = np.arange(0, 101, 0.5)
    scores = np.array([[40, 80], [40, 80]])
    prepared = prepare_windows(scores, centres)
    prediction, confidence = weighted_prediction(
        np.array([[0.6, 0.4], [0.3, 0.7]]), prepared, centres, np.array([45, 45])
    )
    assert abs(prediction[0] - 40) <= 7
    assert abs(prediction[1] - 80) <= 7
    np.testing.assert_allclose(confidence, [0.6, 0.7])


def test_no_history_keeps_the_case_and_uses_earlier_fallback():
    centres = np.arange(0, 101, 0.5)
    prepared = prepare_windows(np.array([[np.inf, np.inf]]), centres)
    prediction, confidence = weighted_prediction(np.zeros((1, 2)), prepared, centres, np.array([38]))
    assert prediction.tolist() == [38]
    assert confidence.tolist() == [0]


def test_a_recorded_zero_is_a_score_not_a_missing_neighbour():
    centres = np.arange(0, 101, 0.5)
    prepared = prepare_windows(np.array([[0.0, np.inf]]), centres)
    prediction, confidence = weighted_prediction(np.array([[1.0, 0]]), prepared, centres, np.array([45]))
    assert prediction[0] <= 7
    assert confidence[0] == 1


def test_same_week_and_target_scores_cannot_change_the_prediction(tmp_path):
    rows = [
        {"date": d, "score": score, "player": "p", "cohort": "start", "pos": "MID"}
        for d, score in (("2025-10-01T20:00:00Z", 40), ("2025-10-11T20:00:00Z", 90), ("2025-10-12T20:00:00Z", 20))
    ]
    selected = np.array([False, False, True])
    fit = np.array([True, False, False])
    indices, distance = lookup_neighbours(np.zeros((3, 1)), rows, selected, fit, tmp_path / "neighbours.npz", "test")
    assert indices[0, 0] == 0
    assert (indices[0, 1:] == -1).all()
    spec = {"neighbours": 25, "distancePower": 0, "ownPlayerWeight": 1, "halfLifeDays": 730}
    before = predict_lookup(prepare_lookup(rows, selected, fit, indices, distance), spec)
    rows[1]["score"], rows[2]["score"] = 0, 100
    after = predict_lookup(prepare_lookup(rows, selected, fit, indices, distance), spec)
    np.testing.assert_array_equal(before, after)
