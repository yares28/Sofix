"""Testing-only coherent mixture decisions without averaging incompatible scores."""

import numpy as np
import pytest

from app.research import score_density_blend as blend
from app.research import score_empirical_density as empirical
from app.research.score_analogues import predict_lookup, prepare_windows
from app.research.score_modal_trees import CENTRES
from app.research.score_windows import window_centres


def test_mixed_disjoint_outcomes_choose_one_peak_and_zero_weight_keeps_exact_reference():
    base = (np.abs(CENTRES - 40) <= 7)[None, :].astype(float)
    new = (np.abs(CENTRES - 80) <= 7)[None, :].astype(float)
    control, position = np.array([40.0]), np.array(["MID"])
    for weight in (0.05, 0.1, 0.25, 0.5, 0.75, 1):
        score, mass = blend.forecast(base, new, weight, control, position, "all")
        assert abs(score[0] - 40) <= 7 or abs(score[0] - 80) <= 7
        assert mass[0, CENTRES == 60] == 0
    np.testing.assert_array_equal(blend.forecast(base, new, 0, control, position, "all")[0], control)
    np.testing.assert_array_equal(blend.forecast(base, new, 1, control, np.array(["FWD"]), "defmid")[0], control)


def test_reference_empirical_mass_reconstructs_original_all_case_decision_and_cold_position():
    classes = np.array([35.0, 60.0])
    p = np.array([[0.7, 0.3], [0.2, 0.8], [1, 0]])
    parts = {q: np.full((3, 2), (q - 0.5) * 20) for q in (0.35, 0.5, 0.65)}
    positions = np.array(["MID", "DEF", "GK"])
    residuals = np.array([-15.0, -8, -7, -2, 0, 1, 7, 14, 50])
    bank = dict(mode="raw", global_=residuals, positions={"MID": residuals}, levels={("MID", 35.0): residuals[:4]})
    bank["global"] = bank.pop("global_")
    np.testing.assert_array_equal(
        window_centres(blend.empirical_mass(classes, p, parts, positions, bank), CENTRES),
        empirical.empirical_predictions(classes, p, parts, positions, bank, 20, 0.75, 0),
    )


def test_neighbour_density_keeps_original_weighted_mode_and_explicit_cold_fallback():
    scores = np.full((2, 500), np.inf)
    scores[0, :3] = [40, 40, 80]
    valid = np.isfinite(scores)
    prepared = dict(
        valid=valid,
        distance=np.where(valid, 0.0, np.inf),
        age=np.zeros((2, 500)),
        own=np.zeros((2, 500), dtype=bool),
        fallback=np.array([38.0, 38]),
        windows=prepare_windows(scores, CENTRES),
        centres=CENTRES,
    )
    spec = dict(neighbours=500, distancePower=2, halfLifeDays=730, ownPlayerWeight=4)
    mass, original, audit = blend.lookup_mass(prepared, spec)
    np.testing.assert_array_equal(original, predict_lookup(prepared, spec)[0])
    np.testing.assert_array_equal(original, [40, 38])
    assert mass[0, CENTRES == 40] == 2 / 3
    assert audit["noNeighbourFallbackCases"] == 1
    assert np.isfinite(mass).all()


def test_invalid_density_or_weight_cannot_drop_forecast_cases():
    base = np.ones((2, 201)) / 10
    with pytest.raises(ValueError, match="probabilities"):
        blend.forecast(base * -1, base, 0.5, np.array([40, 40]), np.array(["MID", "MID"]), "all")
    with pytest.raises(ValueError, match="Matched"):
        blend.forecast(base, base, 1.1, np.array([40, 40]), np.array(["MID", "MID"]), "all")
