"""Independent native-record check of spatial source probe; no model fitting."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import os
import re
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_spatial_pressure_probe.json")
    )
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    compressed = Path(report["observationsFile"]).read_bytes()
    if hashlib.sha256(compressed).hexdigest() != report["observationsSha256"]:
        raise ValueError("Spatial observation archive changed")
    observations = json.loads(gzip.decompress(compressed))["observations"]
    native_raw = args.games.read_bytes()
    if hashlib.sha256(native_raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native games changed")
    games = {g["id"]: g for g in (json.loads(line) for line in native_raw.decode().splitlines() if line.strip())}
    env = {**os.environ, "GIT_NO_LAZY_FETCH": "1"}
    head = subprocess.check_output(["git", "-C", str(args.repo), "rev-parse", "HEAD"], text=True, env=env).strip()
    if head != report["sourceCommit"]:
        raise ValueError("Spatial source commit changed")
    listing = subprocess.check_output(["git", "-C", str(args.repo), "ls-tree", "-r", "HEAD"], text=True, env=env)
    blobs = {line.split("\t")[1]: line.split()[2] for line in listing.splitlines()}
    details, seen, counts = {}, set(), Counter()
    coordinate_groups = {s: {k: [] for k in ("shotX", "leftPassY", "rightPassY")} for s in ("home", "away")}
    for record in observations:
        game = games[record["game"]]
        identity = record["game"], record["club"]
        if identity in seen:
            raise ValueError("Duplicate observed team-side")
        seen.add(identity)
        if record["date"] != game["date"]:
            raise ValueError("Source event availability would use wrong date")
        side = next((s for s in ("home", "away") if game[s]["slug"] == record["club"]), None)
        if side is None or record["opponent"] != game["away" if side == "home" else "home"]["slug"]:
            raise ValueError("Native opponent identity mismatch")
        path = record["sourcePath"]
        if path not in details:
            raw = (args.repo / path).read_bytes().replace(b"\r\n", b"\n")
            digest = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            if digest != record["sourceBlob"] or digest != blobs[path]:
                raise ValueError("Canonical spatial source bytes mismatch")
            details[path] = json.loads(raw.decode().partition("=")[2].strip().removesuffix(";"))
        detail = details[path]
        if (detail["home"]["score"], detail["away"]["score"]) != (game["homeGoals"], game["awayGoals"]):
            raise ValueError("Source fixture score mismatch")
        stream = detail.get("dribbles")
        if not isinstance(stream, list):
            if record["summary"]["known"]:
                raise ValueError("Unknown stream changed into zero")
            continue
        own = [e for e in stream if e.get("team") == side]
        known = [e for e in own if e.get("ok") in (True, False) and isinstance(e.get("ok"), bool)]
        valid = [
            e
            for e in known
            if all(type(e.get(k)) in (int, float) and math.isfinite(e[k]) and 0 < e[k] < 100 for k in ("x", "y"))
        ]
        grid = [[0, 0, 0] for _ in range(3)]
        for event in valid:
            grid[math.floor(event["x"] / (100 / 3))][math.floor(event["y"] / (100 / 3))] += 1
        expected = {
            "known": True,
            "attempts": len(own),
            "successes": sum(e["ok"] for e in known) if len(own) == len(known) else None,
            "spatialKnown": len(valid),
            "ambiguousCoordinates": len(known) - len(valid),
            "invalidFlags": len(own) - len(known),
            "grid": grid,
        }
        if expected != record["summary"] or record["takeons"] != [[e["x"], e["y"], int(e["ok"])] for e in valid]:
            raise ValueError("Independent spatial coordinates/counts disagree")
        participants = [
            p for p in game["players"].values() if p.get("played") is True and p.get("team") == record["club"]
        ]
        expected_native = (
            math.fsum(p["stats"].get("won_contest", [0, 0])[0] for p in participants)
            if all(p.get("ver") == 7 and isinstance(p.get("stats"), dict) for p in participants)
            else None
        )
        verified = (
            expected_native is not None
            and expected["successes"] is not None
            and expected_native == expected["successes"]
        )
        if expected_native != record["nativeWonContest"] or record["countsVerified"] != verified:
            raise ValueError("Independent native contest sums disagree")
        counts["teamSides"] += 1
        counts["successTotalsMatchNative"] += int(verified)
        for field in ("attempts", "spatialKnown", "ambiguousCoordinates", "invalidFlags"):
            counts[field] += expected[field]
        counts["successes"] += expected["successes"] or 0
        coordinate_groups[side]["shotX"].extend(
            e["x"]
            for e in detail.get("shots", [])
            if e.get("team") == side and type(e.get("x")) in (int, float) and 0 < e["x"] < 100
        )
        pass_y = defaultdict(list)
        token = lambda name: tuple(re.findall("[a-z]+", str(name).lower()))
        for event in detail.get("passes", []):
            if event.get("team") == side and type(event.get("y")) in (int, float) and 0 < event["y"] < 100:
                pass_y[token(event.get("player", ""))].append(event["y"])
        for person in (detail.get("lineups") or {}).get(side, {}).get("starters", []):
            role = str(person.get("pos", "")).rstrip(")")
            if not role or role[-1] not in ("L", "R"):
                continue
            values = pass_y.get(token(person.get("name", "")), [])
            if values:
                coordinate_groups[side]["leftPassY" if role[-1] == "L" else "rightPassY"].append(
                    math.fsum(values) / len(values)
                )
    for key, value in counts.items():
        if value != report["counts"][key]:
            raise ValueError("Independent full-source tally mismatch: " + key)
    if len(details) != report["counts"]["verifiedFixtures"] or len(games) != report["nativeFixtures"]:
        raise ValueError("Full fixture coverage mismatch")
    for side, group in coordinate_groups.items():
        for field, values in group.items():
            expected = report["orientation"][side][field]
            if len(values) != expected["n"]:
                raise ValueError("Independent orientation sample count differs")
            np.testing.assert_allclose(
                [math.fsum(values) / len(values), float(np.median(values))],
                [expected["mean"], expected["median"]],
                rtol=0,
                atol=1e-10,
            )
    output = {
        "scope": "Independent all-record source audit, not score accuracy",
        "sourceCommit": head,
        "observationsSha256": report["observationsSha256"],
        "nativeFixtures": len(games),
        "verifiedSourceFixtures": len(details),
        "verifiedTeamSideRecords": len(observations),
        "verifiedTakeOnStartPoints": counts["spatialKnown"],
        "nativeSuccessAgreements": counts["successTotalsMatchNative"],
        "disagreementRecordsKeptExplicit": counts["teamSides"] - counts["successTotalsMatchNative"],
        "independentOrientationAndGridCounts": True,
        "noFeatureOrForecastFitting": True,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("SPATIAL_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
