"""Testing only: learn score distributions with explicit player/club identity."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def score_bins(scores: np.ndarray) -> np.ndarray:
    if not np.isfinite(scores).all() or ((scores < 0) | (scores > 100)).any():
        raise ValueError("Score targets must be known and in [0,100]")
    return np.clip(np.floor((scores + 2.5) / 5), 0, 20).astype(int)


def density_choice(probability: np.ndarray, classes: np.ndarray) -> np.ndarray:
    centres = np.arange(0, 100.01, 0.5)
    low, high = np.maximum(0, classes * 5 - 2.5), np.minimum(100, classes * 5 + 2.5)
    overlap = np.maximum(0, np.minimum(high[:, None], centres + 7) - np.maximum(low[:, None], centres - 7))
    mass = probability @ (overlap / (high - low)[:, None])
    return window_centres(mass, centres)


def category_values(rows: list[dict], games: list[dict]) -> np.ndarray:
    indexed = {g["id"]: g for g in games}
    values = []
    for row in rows:
        game = indexed[row["game"]]
        team = game["players"][row["player"]]["team"]
        if team not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Playing side is not a side of this fixture")
        opponent = game["away"]["slug"] if team == game["home"]["slug"] else game["home"]["slug"]
        values.append([row["player"], team, opponent, row["pos"]])
    return np.array(values)


def fit_distribution(frame, labels, fit, check, cat_names, depth, penalty):
    from catboost import CatBoostClassifier, Pool

    model = CatBoostClassifier(
        loss_function="MultiClass",
        iterations=300,
        depth=depth,
        l2_leaf_reg=penalty,
        learning_rate=0.05,
        random_seed=20261103,
        thread_count=4,
        task_type="CPU",
        border_count=64,
        max_ctr_complexity=1,
        allow_writing_files=False,
        verbose=False,
    )
    # The check pool has no labels; categorical statistics use the earlier fit pool only.
    training = Pool(frame.loc[fit], label=labels[fit], cat_features=cat_names)
    checking = Pool(frame.loc[check], cat_features=cat_names)
    model.fit(training)
    return model.predict_proba(checking), np.asarray(model.classes_, dtype=int), model


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "games", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import catboost
    import pandas as pd
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    raw = args.games.read_bytes()
    games = [json.loads(s) for s in raw.decode("utf-8").splitlines() if s.strip()]
    with np.load(args.stats_cache) as stored:
        allx = stored["x"]
        stat_key = str(stored["key"])
    key = hashlib.sha256(
        (source["key"] + stat_key + catboost.__version__).encode() + raw + Path(__file__).read_bytes()
    ).hexdigest()
    identities = category_values(source["rows"], games)
    report = {
        "scope": "Testing only; no application/production changes",
        "target": "Actual LaLiga score within7 on all starts and played substitutes separately",
        "split": "Train beforeJuly2025; selectJuly-Dec2025; refitbeforeJan2026; compareJan-Oct2026",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "implementationKey": key,
        "libraryVersion": catboost.__version__,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        labels = score_bins(y)
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        numeric = pd.DataFrame(allx[keep], columns=[f"n{i}" for i in range(allx.shape[1])])
        named = numeric.copy()
        cat_names = ["player_id", "playing_side", "opponent_side", "card_position"]
        for i, name in enumerate(cat_names):
            named[name] = identities[keep, i]
        groups = {"numeric": (numeric, []), "identity": (named, cat_names)}
        candidates = []
        for group, (frame, cats) in groups.items():
            for depth in (4, 6):
                for penalty in (10, 50):
                    path = args.cache / f"identity_{cohort}_{group}_{depth}_{penalty}_selection.npz"
                    cached = np.load(path) if path.exists() else None
                    if cached is not None and str(cached["key"]) == key:
                        probability, classes = cached["probability"], cached["classes"]
                        cached.close()
                    else:
                        if cached is not None:
                            cached.close()
                        probability, classes, model = fit_distribution(
                            frame, labels, train, valid, cats, depth, penalty
                        )
                        del model
                        np.savez_compressed(path, key=key, probability=probability, classes=classes)
                    prediction = density_choice(probability, classes)
                    for shift in (-3, 0, 3):
                        candidates.append(
                            {
                                "group": group,
                                "depth": depth,
                                "penalty": penalty,
                                "shift": shift,
                                "selection": measure(y[valid], np.clip(prediction + shift, 0, 100)),
                            }
                        )
                    print(
                        f"Selected {cohort} {group} depth{depth} L2{penalty}: "
                        + json.dumps(
                            max(candidates[-3:], key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
                        ),
                        flush=True,
                    )
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        frame, cats = groups[winner["group"]]
        probability, classes, model = fit_distribution(
            frame, labels, ~test, test, cats, winner["depth"], winner["penalty"]
        )
        model.save_model(str(args.cache / f"identity_{cohort}_selected.cbm"))
        prediction = np.clip(density_choice(probability, classes) + winner["shift"], 0, 100)
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(y[test], stored["y"]):
                raise ValueError("Control cases differ")
            baseline = stored["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        positions = np.array([r["pos"] for r in rows])[test]
        known = set(identities[keep, 0][~test])
        cold = np.array([p not in known for p in identities[keep, 0][test]])
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "control": measure(y[test], baseline),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, baseline, weeks),
            "newPlayerCases": int(cold.sum()),
            "newPlayerScores": measure(y[test][cold], prediction[cold]) if cold.any() else {"n": 0},
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {
                p: measure(y[test][positions == p], prediction[positions == p])
                for p in POSITIONS
                if (positions == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"identity_predictions_{cohort}.npz",
            prediction=prediction,
            probability=probability,
            classes=classes,
            y=y[test],
            key=key,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
