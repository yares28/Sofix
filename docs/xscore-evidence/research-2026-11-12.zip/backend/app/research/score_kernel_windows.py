"""Testing only: regularised random-feature estimates of exact score-window hits."""

from __future__ import annotations

import numpy as np

CENTRES = np.arange(101, dtype=float)
PARAMETERS = {
    f"features{m}_width{width}_ridge{ridge}": (m, width, ridge)
    for m in (256, 512)
    for width in (0.25, 1, 4)
    for ridge in (1, 100)
}


class KernelWindows:
    def __init__(self, features=256, width=1, ridge=1, seed=20261104):
        self.features, self.width, self.ridge, self.seed = features, width, ridge, seed

    def normalise(self, x):
        known = np.isfinite(x)
        raw = np.clip((np.where(known, x, self.mean_) - self.mean_) / self.scale_, -6, 6)
        missing = np.clip((~known - self.missing_mean_) / self.missing_scale_, -6, 6)
        return np.column_stack((raw, missing))

    def map_features(self, x):
        z = self.normalise(np.asarray(x, dtype=float))
        return np.column_stack(
            (z / np.sqrt(z.shape[1]), np.sqrt(2 / self.features) * np.cos(z @ self.weights_ + self.phase_))
        )

    def fit(self, x, scores):
        from scipy.linalg import cho_factor, cho_solve

        x, scores = np.asarray(x, dtype=float), np.asarray(scores, dtype=float)
        if (
            x.ndim != 2
            or len(scores) != len(x)
            or not len(x)
            or not np.isfinite(scores).all()
            or ((scores < 0) | (scores > 100)).any()
            or np.isinf(x).any()
        ):
            raise ValueError("Kernel fit needs complete valid labels and finite-or-missing inputs")
        known = np.isfinite(x)
        count = known.sum(axis=0)
        self.mean_ = np.divide(np.where(known, x, 0).sum(axis=0), count, out=np.zeros(x.shape[1]), where=count > 0)
        var = np.divide(
            np.where(known, (x - self.mean_) ** 2, 0).sum(axis=0), count, out=np.ones(x.shape[1]), where=count > 0
        )
        self.scale_ = np.where(var > 1e-12, np.sqrt(var), 1)
        self.missing_mean_ = (~known).mean(axis=0)
        missing_var = self.missing_mean_ * (1 - self.missing_mean_)
        self.missing_scale_ = np.where(missing_var > 1e-12, np.sqrt(missing_var), 1)
        rng = np.random.default_rng(self.seed)
        self.weights_ = rng.normal(size=(2 * x.shape[1], self.features)) * np.sqrt(2 * self.width / (2 * x.shape[1]))
        self.phase_ = rng.uniform(0, 2 * np.pi, self.features)
        phi = self.map_features(x)
        self.phi_mean_ = phi.mean(axis=0)
        phi -= self.phi_mean_
        targets = (np.abs(scores[:, None] - CENTRES[None, :]) <= 7).astype(float)
        self.target_mean_ = targets.mean(axis=0)
        gram = phi.T @ phi
        gram.flat[:: len(gram) + 1] += self.ridge
        self.coef_ = cho_solve(
            cho_factor(gram, lower=True, check_finite=False), phi.T @ (targets - self.target_mean_), check_finite=False
        )
        return self

    def predict(self, x):
        x = np.asarray(x, dtype=float)
        if x.ndim != 2 or x.shape[1] != len(self.mean_) or np.isinf(x).any():
            raise ValueError("Kernel target input shape or infinity differs")
        return np.clip((self.map_features(x) - self.phi_mean_) @ self.coef_ + self.target_mean_, 0, 1)
