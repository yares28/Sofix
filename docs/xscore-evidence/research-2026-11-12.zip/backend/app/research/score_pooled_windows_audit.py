"""Testing only: native all-case direct-window forecasts, source weights and actual final refits."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_density_blend as density
from app.research import score_density_blend_run as reference_runner
from app.research import score_pooled_conditioning as source_groups
from app.research import score_pooled_conditioning_run as shared
from app.research import score_pooled_windows as network
from app.research import score_pooled_windows_run as runner
from app.research import score_stability as stability
from app.research.score_search import cutoff_for, measure, moment


def native_fit(queries, cohort, begin, first, weight):
    lock = cutoff_for(first).timestamp()
    fit = np.array(
        [
            q["cohort"] == cohort
            and q["date"] < begin
            and moment(q["date"]).timestamp() + 172800 < lock
            and (q["source"] == "laliga" or weight > 0)
            for q in queries
        ]
    )
    weights = np.array([1.0 if q["source"] == "laliga" else weight for q in queries])
    return fit, weights


def reconstructed_mass(raw, fit, weights, target, stored):
    train = raw[fit]
    sample = weights[fit]
    valid = np.isfinite(train)
    count = (valid * sample[:, None]).sum(axis=0)
    known = count > 0
    mean = np.divide(
        (np.where(valid, train, 0) * sample[:, None]).sum(axis=0), count, out=np.zeros(train.shape[1]), where=known
    )
    scale = np.sqrt(
        np.divide(
            (np.where(valid, (train - mean) ** 2, 0) * sample[:, None]).sum(axis=0),
            count,
            out=np.zeros(train.shape[1]),
            where=known,
        )
    )
    scale[scale < 1e-8] = 1
    if (
        not np.array_equal(stored["normaliser_known"], known)
        or not np.allclose(stored["normaliser_mean"], mean, atol=1e-10, rtol=0)
        or not np.allclose(stored["normaliser_scale"], scale, atol=1e-10, rtol=0)
    ):
        raise ValueError("Independent weighted training-only window normalization differs")
    check = raw[target]
    valid = np.isfinite(check)
    transformed = np.clip((np.where(valid, check, mean) - mean) / scale, -8, 8)
    missing = (~valid).astype(float)
    transformed[:, ~known] = 0
    missing[:, ~known] = 0
    x = np.concatenate((transformed, missing), axis=1).astype(np.float32)
    hidden = np.tanh(x @ stored["w0"] + stored["w1"])
    logits = hidden @ stored["w2"] + stored["w3"]
    mass = np.exp(-np.logaddexp(0, -logits))
    if not np.array_equal(mass, stored["mass"]):
        raise ValueError("Independent actual saved-parameter window probabilities differ")
    return density.validate_mass(mass)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "history-cache", "history-report", "routine-cache", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    args.out = args.report
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    feature, x, canonical_all, queries, _, _ = shared.load_shared(args, source)
    corpus = json.loads(gzip.decompress(args.routine_cache.with_suffix(".observations.json.gz").read_bytes()))
    lookup = {(r["game"], r["player"]): r["score"] for r in corpus["records"]}
    native_y = np.array([lookup[q["game"], q["player"]] for q in queries])
    reports = {n: json.loads((args.report.parent / (n + ".json")).read_text()) for n in shared.REPORTS}
    key = runner.implementation_key(source, feature["featureKey"], reports, args.report.with_suffix(".plan.json"))
    if key != report["implementationKey"]:
        raise ValueError("Direct-window source/code/plan identity differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        canonical = canonical_all[keep]
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        if not np.array_equal(native_y[canonical], y):
            raise ValueError("Direct-window audited native target scores changed")
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        screen = json.loads(args.report.with_name(args.report.stem + f".{cohort}.screening.json").read_text())
        winner80, best80 = stability.choose_stable(frozen["candidates80"])
        fixed = winner80 or best80
        confirmed = frozen["finalCandidate"]
        winner = confirmed if min(confirmed["gains"]) > 0 else None
        if (
            frozen["implementationKey"] != key
            or screen["implementationKey"] != key
            or len(frozen["candidates80"]) != 72
            or winner80 != frozen["screenWinner80"]
            or best80 != frozen["screenBest80"]
            or fixed["spec"] != confirmed["spec"]
            or screen["fixedConfirmationSpec"] != fixed["spec"]
            or confirmed != result["candidate"]
            or winner != result["winner"]
            or winner != frozen["winner"]
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Direct-window frozen80selection/fixed160confirmation gate differs")
        paths = {}
        models = 0
        reconstructed = 0
        for phase, begin, _ in stability.PHASES[1:]:
            mask = masks[phase]
            target = mask["target"]
            base, control, _, _ = reference_runner.reference(call, key, source, cohort, phase, masks, reports)
            expected = (
                reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else reports["laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"][
                    "cohorts"
                ][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Direct-window original all-case reference changed")
            specs = [(r, 80) for r in frozen["candidates80"]] if phase != "later2026" else []
            specs.append((confirmed, 160))
            mass_cache = {}
            for name, group, epochs in sorted({(r["spec"]["model"], r["spec"]["group"], e) for r, e in specs}):
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{group}_{name}_{epochs}.npz"
                fit, weights = native_fit(queries, cohort, begin, mask["first"], source_groups.GROUPS[group])
                with np.load(path) as f:
                    stats = json.loads(str(f["statistics"]))
                    receipt = json.loads(str(f["receipt"]))
                    if (
                        str(f["key"]) != key
                        or not np.array_equal(fit, f["fit"])
                        or not np.array_equal(weights, f["weights"])
                        or not np.array_equal(f["target_indices"], canonical[target])
                        or not np.array_equal(fit[canonical], mask["fit"])
                        or stats["epochs"] != epochs
                        or stats["fitRows"] != int(fit.sum())
                        or stats["sourceWeightSum"] != weights[fit].sum()
                        or receipt["fitLaLiga"]
                        != int((fit & np.array([q["source"] == "laliga" for q in queries])).sum())
                    ):
                        raise ValueError("Direct-window independent native sample/weight/epoch metadata differs")
                    mass = reconstructed_mass(x, fit, weights, canonical[target], f)
                    if not np.array_equal(f["prediction"], network.window_centres(mass, network.CENTRES)):
                        raise ValueError("Direct-window native saved max-window prediction differs")
                    if epochs == 160 and phase != "later2026":
                        short = args.cache / f"{args.report.stem}_{cohort}_{phase}_{group}_{name}_80.npz"
                        with np.load(short) as s:
                            if not np.array_equal(f["history"][:80], s["history"]):
                                raise ValueError("Direct-window fixed160 lost original80 optimization prefix")
                mass_cache[name, group, epochs] = mass
                paths[phase, name, group, epochs] = path
                models += 1
            for record, epochs in specs:
                spec = record["spec"]
                mass = mass_cache[spec["model"], spec["group"], epochs]
                candidate, _ = density.forecast(base, mass, spec["weight"], control, positions[target], spec["scope"])
                if phase == "later2026":
                    alternate = candidate
                elif measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                    raise ValueError("Direct-window native earlier forecast/confirmation metrics changed")
                reconstructed += 1
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Direct-window final full native population changed")
            for field, metric in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[metric]:
                    raise ValueError("Direct-window final native hit counts/metrics changed")
            h1, h0 = abs(f["alternate"] - y[target]) <= 7, abs(f["control"] - y[target]) <= 7
        receipt = dict(
            n=int(target.sum()),
            candidateCorrect=int(h1.sum()),
            controlCorrect=int(h0.sum()),
            gained=int((h1 & ~h0).sum()),
            lost=int((h0 & ~h1).sum()),
            modelBundlesIndependentlyRebuilt=models,
            candidateForecastsReconstructed=reconstructed,
            weightedFitNormalizationAndNativeMasksVerified=True,
            allFixed160PrefixesVerified=True,
            freezeSha256=hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        )
        if args.refit_final:
            spec = confirmed["spec"]
            phase, begin, _ = stability.PHASES[-1]
            fit, weights = native_fit(
                queries, cohort, begin, masks[phase]["first"], source_groups.GROUPS[spec["group"]]
            )
            hidden = native_y.copy()
            hidden[~fit] = np.nan
            params = network.PARAMETERS[spec["model"]]
            print(f"DIRECT_WINDOW_AUDIT_REFIT {cohort} {spec['group']} {spec['model']} epochs160", flush=True)
            model = network.WindowNetwork(**params, epochs=160).fit(x[fit], hidden[fit], weights[fit])
            mass = model.predict_mass(x[canonical[target]])
            path = paths[phase, spec["model"], spec["group"], 160]
            with np.load(path) as f:
                if (
                    not np.array_equal(mass, f["mass"])
                    or not np.array_equal(model.history_, f["history"])
                    or any(not np.array_equal(w, f[f"w{j}"]) for j, w in enumerate(model.weights_))
                ):
                    raise ValueError("Actual selected160 direct-window refit changed without outside-fit scores")
            receipt["realRefitWithoutOutsideScores"] = dict(
                all160EpochsParametersAndPredictionsReproduced=True,
                outsideFitScoresBlanked=int((~fit).sum()),
                fitCases=int(fit.sum()),
                forecastCases=int(target.sum()),
            )
        evidence[cohort] = receipt
    output = dict(
        scope="Testing-only independent native direct-window probabilities/normalizers/weights/freeze/refits, no fresh blind claim",
        implementationKey=key,
        cohorts=evidence,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
