"""Testing only: monthly updates within the strongest conditional-score architecture."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_rolling as calendar
from app.research import score_rolling_strong as rolling
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional
from app.research.score_matchups_run import validate_stat_identity
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def cached_parts(x, rows, aa, levels, selected, window, cache, key, stem, cohort, phase):
    path = cache / f"{stem}_components_{cohort}_{phase}_w{window}_{key[:12]}.npz"
    if path.exists():
        with np.load(path) as f:
            if str(f["key"]) != key or len(f["probability"]) != int(selected.sum()):
                raise ValueError("Monthly strongest phase cache differs")
            return (
                (f["classes"], f["probability"], {q: f[f"q{q}"] for q in rolling.QUANTILES}),
                f["known"],
                json.loads(str(f["receipt"])),
            )
    pieces, known, receipt = rolling.rolling_parts(
        x, rows, aa, levels, selected, window, cache, key, stem + "_month_" + cohort
    )
    np.savez_compressed(
        path,
        key=key,
        classes=pieces[0],
        probability=pieces[1],
        known=known,
        receipt=json.dumps(receipt),
        **{f"q{q}": values for q, values in pieces[2].items()},
    )
    return pieces, known, receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Monthly strongest source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"] or len(f["x"]) != len(source["rows"]):
            raise ValueError("Monthly strongest team features differ")
        all_x = np.column_stack((base, f["x"]))
    if all_x.shape != (len(source["rows"]), 677):
        raise ValueError("Monthly strongest677feature coverage differs")
    modules = (rolling, calendar, conditional, empirical, flow, controls, ordinary, stability)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    report = {
        "scope": "Research only, monthly strong models, no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        previous_report = json.loads(args.out.read_text())
        if previous_report["implementationKey"] == key:
            report = previous_report
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        x = all_x[keep]
        y, aa, levels, positions = (np.array([r[field] for r in rows]) for field in ("score", "aa", "level", "pos"))
        masks = stability.phase_masks(rows)
        records = [
            {
                "spec": {"window": window, "policy": policy, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for window in (0, 365)
            for policy in ("ordinary", "events", "both")
            for scope in ("all", "defmid")
        ]
        previous, winner, best, audit = None, None, None, {}
        for phase, _, _ in stability.PHASES:
            target = masks[phase]["target"]
            current_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old, old_known = rolling.aligned(
                flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            )
            if phase == "later2026" and best is None:
                raise ValueError("Monthly strongest model must freeze before final period")
            active = [best] if phase == "later2026" else records
            new = {}
            for window in sorted({r["spec"]["window"] for r in active}):
                print(f"STRONG_FITTING {cohort} {phase} window{window}", flush=True)
                new[window] = cached_parts(
                    x, rows, aa, levels, target, window, args.cache, key, args.out.stem, cohort, phase
                )
            if phase == "warm2023":
                previous = current_rows, old, old_known, new
                continue
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric != expected:
                raise ValueError("Monthly strongest exact control differs")
            previous_rows, previous_old, previous_old_known, previous_new = previous
            audit[phase] = {
                "target": int(target.sum()),
                "control": metric,
                "windows": {str(w): values[2] for w, values in new.items()},
                "banks": {},
            }
            for window in sorted(new):
                for policy in sorted({r["spec"]["policy"] for r in active if r["spec"]["window"] == window}):
                    current, _ = rolling.combine(old, old_known, new[window][0], new[window][1], policy)
                    past, past_known = rolling.combine(
                        previous_old, previous_old_known, previous_new[window][0], previous_new[window][1], policy
                    )
                    bank, bank_stats = rolling.bank_from(past, past_known, previous_rows, masks[phase]["first"])
                    audit[phase]["banks"][str(window) + "/" + policy] = bank_stats
                    raw = empirical.empirical_predictions(*current, positions[target], bank, 20, 0.75, 0)
                    for record in [
                        r for r in active if r["spec"]["window"] == window and r["spec"]["policy"] == policy
                    ]:
                        candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                        measured = measure(y[target], candidate)
                        if phase == "later2026":
                            alternate = candidate
                        else:
                            gain = measured["within7"] - metric["within7"]
                            record["gains"].append(gain)
                            record["errors"].append(measured["mae"])
                            record["counts"].append(len(candidate))
                            record["periods"][phase] = {"gain": gain, "metrics": measured}
                    print(
                        "STRONG_TESTED "
                        + json.dumps(
                            {
                                "cohort": cohort,
                                "phase": phase,
                                "window": window,
                                "policy": policy,
                                "rawForecast": measure(y[target], raw),
                            }
                        ),
                        flush=True,
                    )
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
                    json.dumps(
                        {
                            "implementationKey": key,
                            "winner": winner,
                            "best": best,
                            "candidates": records,
                            "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                        },
                        indent=2,
                    )
                )
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            previous = current_rows, old, old_known, new
        prediction = alternate if winner else control.copy()
        h0, h1 = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": metric,
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(y[target], alternate, control, [r["week"] for r in current_rows]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
