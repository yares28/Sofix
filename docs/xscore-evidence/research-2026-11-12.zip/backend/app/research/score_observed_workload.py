"""Testing only: verified playing time survives missing formations and score versions."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import zipfile
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_search
from app.research.score_search import cutoff_for, moment

WINDOWS = (3, 7, 14, 28)
GROUPS = ("euro", "covered")
PLAYER_FIELDS = (
    "known_rows",
    "positive_rows",
    "zero_rows",
    "unknown_rows",
    "known_minutes",
    "complete_observed_minutes",
    "minutes_over90",
)
REST_FIELDS = (
    "last_known_minutes",
    "last_known_days_to_target",
    "last_positive_days_to_target",
    "known_rows365",
    "unknown_rows365",
)
NAMES = tuple(
    [f"load_{g}_player_{w}_{field}" for g in GROUPS for w in WINDOWS for field in PLAYER_FIELDS]
    + [f"load_{g}_player_{field}" for g in GROUPS for field in REST_FIELDS]
    + [
        f"load_{g}_club_{w}_{field}"
        for g in GROUPS
        for w in WINDOWS
        for field in ("observed_fixtures", "observed_extra_time")
    ]
    + [f"load_{g}_club_last_observed_days_to_target" for g in GROUPS]
    + ["load_euro_global_last_observed_days_to_lock", "load_euro_global_fixtures365"]
)


def minute_value(value, played, maximum):
    valid = type(value) in (int, float) and math.isfinite(value) and 0 <= value <= maximum
    if valid and ((value > 0 and played is True) or (value == 0 and played is False)):
        return float(value)
    return None


def fixture(game, date, home, away, source):
    if not game or not date or not home or not away or home == away:
        raise ValueError("Known fixture identity/date/actual sides required for observed workload")
    return {
        "game": game,
        "date": moment(date).isoformat(),
        "home": home,
        "away": away,
        "source": source,
        "extraObserved": False,
    }


def euro_game(raw, competition):
    counts = Counter()
    if raw.get("statusTyped") != "played":
        return None, [], {"unplayed": 1}
    f = fixture(
        raw.get("id"),
        raw.get("date"),
        (raw.get("homeTeam") or {}).get("slug"),
        (raw.get("awayTeam") or {}).get("slug"),
        "euro",
    )
    records = []
    for row in raw.get("playerGameScores") or []:
        counts["rawRows"] += 1
        player = (row.get("anyPlayer") or {}).get("slug")
        if not player:
            counts["unknownPlayer"] += 1
            continue
        stats = row.get("anyPlayerGameStats") or {}
        club = (stats.get("anyTeam") or {}).get("slug")
        valid_side = club in (f["home"], f["away"])
        minutes = minute_value(stats.get("minsPlayed"), stats.get("playedInGame"), 120) if valid_side else None
        if not valid_side:
            club = None
            counts["unknownActualSide"] += 1
        kind = "unknownMinutes" if minutes is None else "knownPositiveMinutes" if minutes > 0 else "knownZeroMinutes"
        counts[kind] += 1
        f["extraObserved"] |= minutes is not None and minutes > 90
        records.append(
            {"game": f["game"], "player": player, "date": f["date"], "club": club, "minutes": minutes, "source": "euro"}
        )
    counts["playedFixtures"] += 1
    return f, records, dict(counts)


def laliga_game(raw):
    if not any(r.get("played") is True for r in raw.get("players", {}).values()):
        return None, [], {"noConfirmedPlayedFixture": 1}
    f = fixture(
        raw.get("id"),
        raw.get("date"),
        (raw.get("home") or {}).get("slug"),
        (raw.get("away") or {}).get("slug"),
        "laliga",
    )
    records = []
    counts = Counter()
    for player, row in raw["players"].items():
        counts["rawRows"] += 1
        club = row.get("team")
        valid_side = club in (f["home"], f["away"])
        minutes = minute_value(row.get("mins"), row.get("played"), 90) if valid_side else None
        if not valid_side:
            club = None
            counts["unknownActualSide"] += 1
        counts[
            "unknownMinutes" if minutes is None else "knownPositiveMinutes" if minutes > 0 else "knownZeroMinutes"
        ] += 1
        records.append(
            {
                "game": f["game"],
                "player": player,
                "date": f["date"],
                "club": club,
                "minutes": minutes,
                "source": "laliga",
            }
        )
    counts["playedFixtures"] += 1
    return f, records, dict(counts)


def merge_records(records):
    found = {}
    for raw in records:
        r = dict(raw)
        r["date"] = moment(r["date"]).isoformat()
        if r["minutes"] is not None and not np.isfinite(r["minutes"]):
            r["minutes"] = None
        identity = r["game"], r["player"]
        if identity not in found:
            found[identity] = r
            continue
        old = found[identity]
        if (
            old["date"] != r["date"]
            or old["source"] != r["source"]
            or (old["club"] is not None and r["club"] is not None and old["club"] != r["club"])
            or (old["minutes"] is not None and r["minutes"] is not None and old["minutes"] != r["minutes"])
        ):
            raise ValueError("Conflicting native observed workload identity/minutes")
        if old["minutes"] is None and r["minutes"] is not None:
            found[identity] = r
        elif old["club"] is None and r["club"] is not None:
            found[identity] = {**old, "club": r["club"]}
    return sorted(found.values(), key=lambda r: (r["date"], r["game"], r["player"]))


def player_fields(history, lock, date):
    out = {}
    for w in WINDOWS:
        recent = [r for when, r in history if when >= lock - timedelta(days=w)]
        known = [r["minutes"] for r in recent if r["minutes"] is not None]
        unknown = len(recent) - len(known)
        values = (
            len(known),
            sum(m > 0 for m in known),
            sum(m == 0 for m in known),
            unknown,
            sum(known) if known else np.nan,
            sum(known) if known and not unknown else np.nan,
            sum(max(0, m - 90) for m in known) if known else np.nan,
        )
        out.update({f"{w}_{field}": float(v) for field, v in zip(PLAYER_FIELDS, values, strict=True)})
    known = [(when, r) for when, r in history if r["minutes"] is not None]
    positive = [(when, r) for when, r in known if r["minutes"] > 0]
    out.update(
        {
            "last_known_minutes": known[-1][1]["minutes"] if known else np.nan,
            "last_known_days_to_target": (date - known[-1][0]).total_seconds() / 86400 if known else np.nan,
            "last_positive_days_to_target": (date - positive[-1][0]).total_seconds() / 86400 if positive else np.nan,
            "known_rows365": float(len(known)),
            "unknown_rows365": float(len(history) - len(known)),
        }
    )
    return out


def club_fields(history, lock, date):
    out = {}
    for w in WINDOWS:
        recent = [f for when, f in history if when >= lock - timedelta(days=w)]
        out[f"{w}_observed_fixtures"] = float(len(recent))
        out[f"{w}_observed_extra_time"] = float(sum(f["extraObserved"] for f in recent))
    out["last_observed_days_to_target"] = (date - history[-1][0]).total_seconds() / 86400 if history else np.nan
    return out


def build_features(rows, laliga, euro_fixtures, euro_records):
    targets = {g["id"]: g for g in laliga}
    if len(targets) != len(laliga):
        raise ValueError("Duplicate LaLiga target fixture")
    fixtures = {}
    records = list(euro_records)
    for raw in laliga:
        f, r, _ = laliga_game(raw)
        if f is not None:
            fixtures[f["game"]] = f
            records.extend(r)
    for f in euro_fixtures:
        if f is None:
            continue
        f = dict(f)
        f["date"] = moment(f["date"]).isoformat()
        if f["game"] in fixtures and fixtures[f["game"]] != f:
            raise ValueError("Conflicting observed fixture header")
        fixtures[f["game"]] = f
    records = merge_records(records)
    for r in records:
        f = fixtures.get(r["game"])
        if f is None or r["date"] != f["date"] or (r["club"] is not None and r["club"] not in (f["home"], f["away"])):
            raise ValueError("Observed minute row does not match its actual fixture")
        if r["minutes"] is not None and r["club"] is None:
            raise ValueError("Known minutes require a verified actual side")
    record_queue = sorted(((moment(r["date"]), r) for r in records), key=lambda v: (v[0], v[1]["game"], v[1]["player"]))
    fixture_queue = sorted(((moment(f["date"]), f) for f in fixtures.values()), key=lambda v: (v[0], v[1]["game"]))
    people, clubs = defaultdict(list), defaultdict(list)
    eu_dates = []
    rp = fp = 0
    cutoffs = [cutoff_for(r["date"]) for r in rows]
    result = np.full((len(rows), len(NAMES)), np.nan)
    for i in sorted(range(len(rows)), key=lambda j: cutoffs[j]):
        row = rows[i]
        lock = cutoffs[i]
        date = moment(row["date"])
        while rp < len(record_queue) and record_queue[rp][0] + timedelta(hours=48) < lock:
            when, r = record_queue[rp]
            people[r["player"]].append((when, r))
            rp += 1
        while fp < len(fixture_queue) and fixture_queue[fp][0] + timedelta(hours=48) < lock:
            when, f = fixture_queue[fp]
            for club in (f["home"], f["away"]):
                clubs[club].append((when, f))
            if f["source"] == "euro":
                eu_dates.append(when)
            fp += 1
        game = targets.get(row["game"])
        person = (game or {}).get("players", {}).get(row["player"])
        if game is None or person is None or game["date"] != row["date"]:
            raise ValueError("Canonical workload target identity/date missing")
        club = person.get("team")
        if club not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Canonical workload target actual side missing")
        player_history = [r for r in people[row["player"]] if r[0] >= lock - timedelta(days=365)]
        club_history = [f for f in clubs[club] if f[0] >= lock - timedelta(days=365)]
        features = {}
        for group in GROUPS:
            ph = [r for r in player_history if group == "covered" or r[1]["source"] == "euro"]
            ch = [f for f in club_history if group == "covered" or f[1]["source"] == "euro"]
            features.update({f"load_{group}_player_{name}": v for name, v in player_fields(ph, lock, date).items()})
            features.update({f"load_{group}_club_{name}": v for name, v in club_fields(ch, lock, date).items()})
        features["load_euro_global_last_observed_days_to_lock"] = (
            (lock - eu_dates[-1]).total_seconds() / 86400 if eu_dates else np.nan
        )
        features["load_euro_global_fixtures365"] = float(
            len(eu_dates) - bisect_left(eu_dates, lock - timedelta(days=365))
        )
        result[i] = [features[n] for n in NAMES]
    if np.isinf(result).any() or np.any(result[np.isfinite(result)] < 0):
        raise ValueError("Invalid observed workload feature value")
    return result, {
        "cases": len(rows),
        "features": len(NAMES),
        "minuteRows": len(records),
        "observedFixtures": len(fixtures),
        "futureCurrentOutcomesNeverUsed": True,
        "availabilityHours": 48,
        "calendarCaution": "Observed fixtures only, not complete official football calendar",
    }


def read_sources(archives, games_path):
    euro_fixtures = []
    euro_records = []
    receipts = []
    for name in ("CL", "EL", "CONF"):
        path = archives / (name + ".zip")
        raw = path.read_bytes()
        counts = Counter()
        with zipfile.ZipFile(path) as z:
            cov = json.loads(z.read("coverage.json"))
            if cov.get("sourceComplete") is not True:
                raise ValueError("Cached archive source index incomplete")
            for member in sorted(z.namelist()):
                if not member.startswith("games/") or not member.endswith(".json"):
                    continue
                f, r, c = euro_game(json.loads(z.read(member)).get("raw") or {}, name)
                counts.update(c)
                if f is not None:
                    euro_fixtures.append(f)
                    euro_records.extend(r)
        receipts.append(
            {
                "archive": path.name,
                "sha256": hashlib.sha256(raw).hexdigest(),
                "counts": dict(counts),
                "sourceComplete": cov.get("sourceComplete"),
                "uefaAligned": cov.get("uefaAligned"),
                "modelEligible": cov.get("modelEligible"),
                "missingStartingXICount": len(cov.get("missingStartingXI") or []),
            }
        )
    laliga = []
    digest = hashlib.sha256()
    with games_path.open("rb") as f:
        for line in f:
            digest.update(line)
            if not line.strip():
                continue
            g = json.loads(line)
            laliga.append(
                {
                    "id": g["id"],
                    "date": g["date"],
                    "home": g["home"],
                    "away": g["away"],
                    "players": {p: {k: r.get(k) for k in ("team", "mins", "played")} for p, r in g["players"].items()},
                }
            )
    return laliga, euro_fixtures, merge_records(euro_records), receipts, digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    plan_path = args.report.with_suffix(".plan.json")
    plan = json.loads(plan_path.read_text())
    laliga, fixtures, records, receipts, ll_sha = read_sources(args.archives, args.games)
    if any(r["sha256"] not in plan["sources"] for r in receipts):
        raise ValueError("Observed workload archive hashes differ")
    x, audit = build_features(source["rows"], laliga, fixtures, records)
    key = hashlib.sha256(
        (source["key"] + ll_sha + "".join(r["sha256"] for r in receipts)).encode()
        + Path(__file__).read_bytes()
        + Path(score_search.__file__).read_bytes()
        + plan_path.read_bytes()
    ).hexdigest()
    np.savez_compressed(args.out, key=key, x=x, names=NAMES)
    args.out.with_suffix(".observations.json.gz").write_bytes(
        gzip.compress(
            json.dumps(
                {"key": key, "fixtures": fixtures, "records": records, "receipts": receipts, "laligaSha256": ll_sha},
                allow_nan=False,
            ).encode()
        )
    )
    coverage = {}
    for cohort in ("start", "bench"):
        chosen = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        coverage[cohort] = {
            "n": int(chosen.sum()),
            "knownEuroMinutes7": int(np.isfinite(x[chosen, NAMES.index("load_euro_player_7_known_minutes")]).sum()),
            "explicitZeroEuroMinutes7": int((x[chosen, NAMES.index("load_euro_player_7_known_minutes")] == 0).sum()),
            "observedClubEuroFixture14": int((x[chosen, NAMES.index("load_euro_club_14_observed_fixtures")] > 0).sum()),
        }
    output = {
        "scope": "Testing-only observed workload features; no accuracy claim",
        "sourceKey": source["key"],
        "featureKey": key,
        "receipts": receipts,
        "laligaSha256": ll_sha,
        "audit": audit,
        "laterCoverage": coverage,
        "sourceCaution": plan["limitations"],
    }
    args.report.write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
