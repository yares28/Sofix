"""Check the fixed new-club correction against frozen full xScore."""

import hashlib
import json

import numpy as np

from app.research.score_absence_role_signal import REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_defender_role_bench_integration import KEY
from app.research.score_relative_player import STEM as SOURCE
from app.research.score_search import measure
from app.research.score_team_routine_shift import metrics
from app.research.score_windows import window_centres

STEM = "laliga_score_relative_player_frozen"


def main():
    report = json.loads((REPORTS / (SOURCE + ".json")).read_bytes())
    assert report["gate"]["bench"]["relativeNewClubAgainstTeam"]["passEarlier"]
    moves = (ROOT / (SOURCE + "_new_club.json")).read_bytes()
    assert hashlib.sha256(moves).hexdigest() == report["moveSHA"]
    entries = json.loads(moves)
    source = json.loads((ROOT / "cases.json").read_bytes())
    reference = json.loads((REPORTS / "laliga_score_mixture_shrunk.json").read_bytes())
    assert reference["implementationKey"] == KEY and reference["sourceKey"] == report["sourceKey"] == source["key"]
    winner = reference["cohorts"]["bench"]["winner"]
    assert winner["spec"]["scope"] == "all"
    phases = {}
    for phase, (begin, end) in PHASES.items():
        rows = [r for r in source["rows"] if r["cohort"] == "bench" and begin <= r["date"] < end]
        outcomes = np.array([r["score"] for r in rows])
        path = ROOT / f"laliga_score_mixture_shrunk_bench_{phase}_{winner['spec']['model']}_e160.npz"
        with np.load(path) as f:
            raw = f["mass"]
            assert raw.shape == (len(rows), 201)
            control = window_centres(raw, np.arange(0, 100.5, 0.5))
        assert measure(outcomes, control) == winner["periods"][phase]["metrics"]
        by_identity = {(g, p): v for g, p, v in entries[phase]}
        assert len(by_identity) == len(entries[phase]) and set(by_identity) <= {(r["game"], r["player"]) for r in rows}
        delta = np.array([by_identity.get((r["game"], r["player"]), 0) for r in rows])
        candidate = np.clip(control + delta, 0, 100)
        phases[phase] = dict(
            **metrics(outcomes, control, candidate),
            eligible=len(by_identity),
            changed=int(np.count_nonzero(candidate != control)),
            frozenCacheSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    hits = [p["gained"] - p["lost"] for p in phases.values()]
    mae = sum(p["n"] * (p["mae"][0] - p["mae"][1]) for p in phases.values()) / sum(p["n"] for p in phases.values())
    output = dict(
        freezeKey=KEY,
        correctionSHA=report["moveSHA"],
        phases=phases,
        netHits=sum(hits),
        maeGain=mae,
        passEarlier=sum(hits) > 0 and min(hits) >= 0 and mae > 0,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
