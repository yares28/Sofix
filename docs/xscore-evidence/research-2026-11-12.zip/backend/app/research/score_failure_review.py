"""Offline error review of frozen forecasts; no training or application writes."""

from __future__ import annotations

import argparse
import hashlib
import json
from bisect import bisect_left
from collections import defaultdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research.score_search import cutoff_for, measure, moment

ACTIVITY_GROUPS = {
    "cleanSheetAndConceded": {"goals_conceded", "clean_sheet_60"},
    "duelsTacklesRecoveries": {"duel_won", "duel_lost", "won_contest", "won_tackle", "poss_won", "interception_won"},
    "passingAndControl": {
        "accurate_pass",
        "missed_pass",
        "accurate_long_balls",
        "long_pass_own_to_opp_success",
        "successful_final_third_passes",
        "pen_area_entries",
        "poss_lost_ctrl",
    },
    "shotsAndChances": {"big_chance_created", "adjusted_total_att_assist", "ontarget_scoring_att", "big_chance_missed"},
    "keeperActions": {
        "saves",
        "saved_ibox",
        "accurate_keeper_sweeper",
        "dive_save",
        "gk_smother",
        "good_high_claim",
        "punches",
        "dive_catch",
        "cross_not_claimed",
    },
}


def activity_groups(stats):
    result = {name: 0.0 for name in (*ACTIVITY_GROUPS, "otherActionsAndBonuses")}
    for stat, (_, points) in stats.items():
        group = next((name for name, names in ACTIVITY_GROUPS.items() if stat in names), "otherActionsAndBonuses")
        result[group] += points
    return result


def summary(actual, prediction):
    actual, prediction = np.asarray(actual), np.asarray(prediction)
    if actual.shape != prediction.shape or not np.isfinite([actual, prediction]).all():
        raise ValueError("Finite matching outcome and forecast vectors required")
    error = actual - prediction
    absolute = np.abs(error)
    n = len(actual)
    return {
        "n": n,
        "correct": int((absolute <= 7).sum()),
        "misses": int((absolute > 7).sum()),
        "percent": float(100 * (absolute <= 7).mean()) if n else None,
        "underByMoreThan7": int((error > 7).sum()),
        "overByMoreThan7": int((error < -7).sum()),
        "error7to14": int(((absolute > 7) & (absolute <= 14)).sum()),
        "error14to25": int(((absolute > 14) & (absolute <= 25)).sum()),
        "errorAbove25": int((absolute > 25).sum()),
        "mae": float(absolute.mean()) if n else None,
        "meanPredictionMinusActual": float(-error.mean()) if n else None,
    }


def native_score(aa, levels):
    aa, levels = np.asarray(aa), np.asarray(levels)
    return np.clip(levels + aa, np.where(levels >= 60, levels, 0), 100)


def partition(actual, prediction, known_event, known_activity):
    hit = np.abs(np.asarray(actual) - prediction) <= 7
    event = np.abs(np.asarray(actual) - known_event) <= 7
    activity = np.abs(np.asarray(actual) - known_activity) <= 7
    return {
        "originalMisses": int((~hit).sum()),
        "eventOnly": int((~hit & event & ~activity).sum()),
        "activityOnly": int((~hit & ~event & activity).sum()),
        "eitherAlone": int((~hit & event & activity).sum()),
        "neitherAlone": int((~hit & ~event & ~activity).sum()),
        "knownEventRescuedMisses": int((~hit & event).sum()),
        "knownEventSpoiledHits": int((hit & ~event).sum()),
        "knownActivityRescuedMisses": int((~hit & activity).sum()),
        "knownActivitySpoiledHits": int((hit & ~activity).sum()),
    }


def historical_context(rows, native):
    history = defaultdict(list)
    for row in rows:
        history[row["player"], row["cohort"]].append(row)
    for values in history.values():
        values.sort(key=lambda r: (r["date"], r["game"]))
    availability = {key: [moment(r["date"]) + timedelta(hours=48) for r in values] for key, values in history.items()}
    contexts = []
    for row in rows:
        key = row["player"], row["cohort"]
        count = bisect_left(availability[key], cutoff_for(row["date"]))
        recent = history[key][max(0, count - 3) : count]
        contexts.append(
            {
                "count": count,
                "meanMinutes3": float(np.mean([r["minutes"] for r in recent])) if recent else None,
                "meanDefensiveAA3": float(np.mean([native[r["game"], r["player"]]["defensiveAA"] for r in recent]))
                if recent
                else None,
            }
        )
        if recent and "activityGroups" in native[recent[0]["game"], recent[0]["player"]]:
            contexts[-1]["meanActivityGroups3"] = {
                name: float(np.mean([native[r["game"], r["player"]]["activityGroups"][name] for r in recent]))
                for name in native[recent[0]["game"], recent[0]["player"]]["activityGroups"]
            }
    return contexts


def groups(actual, prediction, masks):
    return {name: summary(actual[mask], prediction[mask]) for name, mask in masks.items()}


def reconstruct_starters(source, rows, saved, cache, reports):
    # All inputs below are previously cached forecasts. No model fitting is called.
    from app.research import score_empirical_density as empirical
    from app.research import score_event_probability as event
    from app.research import score_flow as flow
    from app.research import score_stability as stability
    from app.research.score_matchups_run import bank_from
    from app.research.score_windows import window_centres

    read = lambda name: json.loads((reports / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary = map(
        read, ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary")
    )
    if any(r["sourceKey"] != source["key"] for r in (old_match, old_stability, old_ordinary)):
        raise ValueError("Component source mismatch")
    masks = stability.phase_masks(rows)
    call = SimpleNamespace(rows=rows, cache=cache)
    previous = flow.old_components(call, "start", "autumn2025", old_match, old_stability, old_ordinary)
    current = flow.old_components(call, "start", "later2026", old_match, old_stability, old_ordinary)
    previous_rows = [r for r, yes in zip(rows, masks["autumn2025"]["target"], strict=True) if yes]
    bank = bank_from(previous, previous_rows, masks["later2026"]["first"])
    target = masks["later2026"]["target"]
    later_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
    positions = np.array([r["pos"] for r in later_rows])
    classes, old_probability, parts = current
    control = empirical.empirical_predictions(classes, old_probability, parts, positions, bank, 20, 0.75, 0)
    np.testing.assert_array_equal(control, saved["control"])
    best = read("laliga_score_team_share")
    with np.load(cache / "laliga_score_team_share_start_later2026_quality_half.npz") as f:
        if str(f["key"]) != best["implementationKey"]:
            raise ValueError("Best forecast rates fingerprint differs")
        rates = f["rates"]
    probability = event.event_probabilities(classes, rates[:, 0], rates[:, 1], "counts", old_probability)
    candidate = empirical.empirical_predictions(classes, probability, parts, positions, bank, 20, 0.75, 0)
    forecast = event.forecast_policy(candidate, control, positions, "state_changes", "outfield")
    np.testing.assert_array_equal(forecast, saved["prediction"])
    changed = (positions != "GK") & ((candidate >= 60) != (control >= 60))
    probability = np.where(changed[:, None], probability, old_probability)
    rebuilt = empirical.empirical_predictions(classes, probability, parts, positions, bank, 20, 0.75, 0)
    np.testing.assert_array_equal(rebuilt, forecast)
    levels = np.array([r["level"] for r in later_rows])
    aa = np.array([r["aa"] for r in later_rows])
    y = np.array([r["score"] for r in later_rows])
    if not np.isin(levels, classes).all():
        raise ValueError("Unsupported actual event level: no silent replacement")
    known_probability = (levels[:, None] == classes[None, :]).astype(float)
    known_event = empirical.empirical_predictions(classes, known_probability, parts, positions, bank, 20, 0.75, 0)
    centres = np.arange(0, 100.01, 0.5)
    conditional_score = native_score(aa[:, None], classes[None, :])
    mass = np.zeros((len(y), len(centres)))
    for j in range(len(classes)):
        mass += probability[:, j, None] * (np.abs(conditional_score[:, j, None] - centres) <= 7)
    known_activity = window_centres(mass, centres)
    np.testing.assert_allclose(native_score(aa, levels), y, rtol=0, atol=1e-7)
    positive = probability[:, classes >= 60].sum(axis=1)
    calibration = {}
    for lo, hi in ((0, 0.1), (0.1, 0.2), (0.2, 0.3), (0.3, 0.4), (0.4, 0.6), (0.6, 1.000001)):
        selected = (positive >= lo) & (positive < hi)
        if selected.any():
            calibration[f"{lo:.1f}to{min(hi, 1):.1f}"] = {
                "n": int(selected.sum()),
                "meanForecastProbability": float(positive[selected].mean()),
                "actualPositiveRate": float((levels[selected] >= 60).mean()),
            }
    diagnostic = {
        "warning": "Actual same-match events or activity points are hindsight inputs, not possible forecasts. Component association is not proof of a causal or achievable gain.",
        "exactSavedPointsReconstructed": len(y),
        "knownEventOnly": summary(y, known_event),
        "knownActivityOnly": summary(y, known_activity),
        "knownBoth": summary(y, native_score(aa, levels)),
        "missPartition": partition(y, forecast, known_event, known_activity),
        "positiveEventCalibration": calibration,
        "positiveEventAverageProbability": float(positive.mean()),
        "positiveEventActualRate": float((levels >= 60).mean()),
        "forecastDistribution": {
            "below30": int((forecast < 30).sum()),
            "30to59": int(((forecast >= 30) & (forecast < 60)).sum()),
            "60plus": int((forecast >= 60).sum()),
            "mean": float(forecast.mean()),
            "actualMean": float(y.mean()),
        },
        "byPosition": {},
    }
    for pos in ("GK", "DEF", "MID", "FWD"):
        keep = positions == pos
        diagnostic["byPosition"][pos] = partition(y[keep], forecast[keep], known_event[keep], known_activity[keep])
    return diagnostic


def prune_reports(source_key, reports):
    entries = []
    for path in sorted(reports.glob("laliga_score_*.json")):
        if "." in path.stem or any(x in path.stem for x in ("checkpoint", "failure_review", "diagnostic", "probe")):
            continue
        report = json.loads(path.read_text())
        start = report.get("cohorts", {}).get("start", {})
        result = next((start[k] for k in ("candidateLater", "empiricalLater", "later") if k in start), None)
        if not isinstance(result, dict) or result.get("n") != 6754 or "within7" not in result:
            continue
        if report.get("sourceKey") != source_key:
            continue
        status = "retire_further_parameter_search"
        if path.stem == "laliga_score_team_share":
            status = "retain_frozen_best_starter_reference"
        elif path.stem == "laliga_score_match_empirical_density":
            status = "retain_frozen_original_starter_control"
        elif path.stem == "laliga_score_mixture_shrunk":
            status = "retire_starter_search_retain_frozen_best_bench_reference"
        elif path.stem == "laliga_score_analogues":
            status = "retire_starter_search_retain_frozen_original_bench_control"
        entries.append(
            {
                "report": path.name,
                "starterCorrect": int(round(result["within7"] * 6754)),
                "starterPercent": 100 * result["within7"],
                "earlierDecision": start.get("selected", "legacy_selection_protocol_see_report"),
                "status": status,
            }
        )
    return {
        "rule": "Insufficient demonstrated gain to justify more parameter variations; not proof of mathematical impossibility. Preserve every result and cache. Frozen best and controls remain references.",
        "completedComparableReports": len(entries),
        "retiredStarterParameterSearches": sum(e["status"].startswith("retire") for e in entries),
        "reports": entries,
        "stoppedIncomplete": ["laliga_score_direct_windows", "laliga_score_direct_windows_bench_safe"],
        "shelvedUntested": ["laliga_score_identity_interactions"],
        "noTrainingOrAutomaticFollowup": True,
    }


def run(args):
    source = json.loads((args.cache / "cases.json").read_text())
    raw = args.games.read_bytes()
    expected = "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("Native source changed; do not silently change cases")
    native = {}
    for game in [json.loads(line) for line in raw.decode().splitlines() if line.strip()]:
        for player, person in game["players"].items():
            if person.get("ver") != 7 or not person.get("played"):
                continue
            key = game["id"], player
            if key in native:
                raise ValueError("Duplicate native identity")
            native[key] = {
                **person,
                "date": game["date"],
                "defensiveAA": sum(
                    person.get("stats", {}).get(k, [0, 0])[1] for k in ("goals_conceded", "clean_sheet_60")
                ),
                "activityGroups": activity_groups(person.get("stats", {})),
            }
    for row in source["rows"]:
        person = native[row["game"], row["player"]]
        for name in ("score", "aa", "level"):
            if abs(person[name] - row[name]) > 1e-7:
                raise ValueError("Native outcome differs")
        if (
            person["date"] != row["date"]
            or person["pos"] != row["pos"]
            or person["started"] != (row["cohort"] == "start")
            or person["mins"] != row["minutes"]
            or abs(sum(v[1] for v in person["stats"].values()) - row["aa"]) > 1e-7
            or abs(sum(person["activityGroups"].values()) - row["aa"]) > 1e-7
        ):
            raise ValueError("Native case identity or detailed activity points differ")
    context = historical_context(source["rows"], native)
    for row, history in zip(source["rows"], context, strict=True):
        prefix = row["cohort"]
        if history["count"] != row["x"][source["features"].index(prefix + "_history_count")]:
            raise ValueError("Prelock history count differs")
        if (
            history["count"]
            and abs(history["meanMinutes3"] - row["x"][source["features"].index(prefix + "_3_minutes")]) > 1e-7
        ):
            raise ValueError("Prelock recent minutes differ")
    output = {
        "scope": "Testing-only error review. Autonomous search paused. No new fitting, provider calls or application changes.",
        "createdAt": datetime.now(UTC).isoformat(),
        "sourceKey": source["key"],
        "nativeSha256": expected,
        "nativeCasesVerified": len(source["rows"]),
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind proof. Actual events, minutes and point breakdowns only explain past misses; never prediction inputs.",
        "pruning": prune_reports(source["key"], args.reports),
        "cohorts": {},
    }
    for cohort, name, expected_correct in (
        ("start", "laliga_score_team_share", 2765),
        ("bench", "laliga_score_mixture_shrunk", 2201),
    ):
        all_rows = [r for r in source["rows"] if r["cohort"] == cohort]
        indices = [i for i, r in enumerate(source["rows"]) if r["cohort"] == cohort and r["date"] >= "2026-01-01"]
        rows = [source["rows"][i] for i in indices]
        histories = [context[i] for i in indices]
        report = json.loads((args.reports / (name + ".json")).read_text())
        if report["sourceKey"] != source["key"]:
            raise ValueError("Retained forecast source differs")
        with np.load(args.cache / (name + "_predictions_" + cohort + ".npz")) as f:
            saved = {k: f[k] for k in f.files}
        if str(saved["key"]) != report["implementationKey"]:
            raise ValueError("Retained forecast implementation key differs")
        y, aa, level, minutes = (np.array([r[k] for r in rows]) for k in ("score", "aa", "level", "minutes"))
        np.testing.assert_array_equal(y, saved["y"])
        np.testing.assert_allclose(native_score(aa, level), y, rtol=0, atol=1e-7)
        pred = saved["prediction"]
        if measure(y, pred) != report["cohorts"][cohort]["later"]:
            raise ValueError("Retained forecast metrics differ")
        overall = summary(y, pred)
        if overall["correct"] != expected_correct or len(y) != {"start": 6754, "bench": 2925}[cohort]:
            raise ValueError("Retained cohort coverage differs")
        pos = np.array([r["pos"] for r in rows])
        count = np.array([h["count"] for h in histories])
        previous_minutes = np.array([h["meanMinutes3"] if h["count"] else np.nan for h in histories])
        previous_defense = np.array([h["meanDefensiveAA3"] if h["count"] else np.nan for h in histories])
        defense = np.array([native[r["game"], r["player"]]["defensiveAA"] for r in rows])
        unexpected_short = (count >= 3) & (previous_minutes >= 75) & (minutes <= 60)
        result = {
            "overall": overall,
            "positions": groups(y, pred, {p: pos == p for p in ("GK", "DEF", "MID", "FWD")}),
            "actualEventLevel": groups(
                y, pred, {"negative": level < 35, "neutral": level == 35, "positive": level >= 60}
            ),
            "actualScore": groups(y, pred, {"below30": y < 30, "30to59": (y >= 30) & (y < 60), "60plus": y >= 60}),
            "actualMinutes": groups(
                y,
                pred,
                {
                    "1to45": minutes <= 45,
                    "46to60": (minutes > 45) & (minutes <= 60),
                    "61to75": (minutes > 60) & (minutes <= 75),
                    "76to89": (minutes > 75) & (minutes < 90),
                    "90plus": minutes >= 90,
                },
            ),
            "prelockHistoryCount": groups(
                y,
                pred,
                {
                    "none": count == 0,
                    "1to4": (count >= 1) & (count <= 4),
                    "5to14": (count >= 5) & (count <= 14),
                    "15plus": count >= 15,
                },
            ),
            "unexpectedShortAppearanceProxy": summary(y[unexpected_short], pred[unexpected_short]),
            "unexpectedShortProxyLimit": "Last three LaLiga appearances in this cohort averaged at least75 minutes and current minutes<=60, at least3 eligible histories. Historical mean is not an explicit minutes forecast; actual short appearance is hindsight.",
            "positiveEventButForecastBelow53": summary(
                y[(level >= 60) & (pred < 53)], pred[(level >= 60) & (pred < 53)]
            ),
            "ordinaryActivityByEvent": {
                "neutralAAminusForecastImpliedAA": float((aa[level == 35] - (pred[level == 35] - 35)).mean())
            },
            "defensivePointsSwingProxy": groups(
                y,
                pred,
                {
                    "unknownHistory": count == 0,
                    "downAtLeast7": defense - previous_defense <= -7,
                    "within7": np.abs(defense - previous_defense) < 7,
                    "upAtLeast7": defense - previous_defense >= 7,
                },
            ),
            "repeatedPlayers": [],
        }
        activity_names = [*ACTIVITY_GROUPS, "otherActionsAndBonuses"]
        swing = np.full((len(rows), len(activity_names)), np.nan)
        for i, (row, history) in enumerate(zip(rows, histories, strict=True)):
            if history["count"]:
                swing[i] = [
                    native[row["game"], row["player"]]["activityGroups"][name] - history["meanActivityGroups3"][name]
                    for name in activity_names
                ]
        missed = np.abs(y - pred) > 7
        neutral_miss = missed & (level == 35) & (count >= 3)
        # This is a past-history comparison, NOT a decomposition of model-predicted AA.
        biggest = np.argmax(np.nan_to_num(np.abs(swing), nan=-1), axis=1)
        result["neutralMissActionSwingProxy"] = {
            "warning": "Actual points minus player's last three strictly available same-cohort LaLiga appearances; largest absolute group change, not the model's explicit action prediction or proven error cause. All named groups are disjoint and sum to native activity points. At least three past cases required.",
            "eligibleNeutralMisses": int(neutral_miss.sum()),
            "allPositions": {name: int((neutral_miss & (biggest == j)).sum()) for j, name in enumerate(activity_names)},
            "defenders": {
                name: int((neutral_miss & (pos == "DEF") & (biggest == j)).sum())
                for j, name in enumerate(activity_names)
            },
            "neutralMissesLargestGroupSwingAtLeast7": int(
                (neutral_miss & (np.nan_to_num(np.abs(swing), nan=-1).max(axis=1) >= 7)).sum()
            ),
        }
        players = np.array([r["player"] for r in rows])
        for player in sorted(set(players)):
            keep = players == player
            if keep.sum() >= 10:
                result["repeatedPlayers"].append({"player": player, **summary(y[keep], pred[keep])})
        result["repeatedPlayers"].sort(key=lambda r: (-r["misses"], r["player"]))
        if cohort == "start":
            result["hindsightComponents"] = reconstruct_starters(source, all_rows, saved, args.cache, args.reports)
        output["cohorts"][cohort] = result
        print("REVIEW " + json.dumps({"cohort": cohort, "overall": overall}), flush=True)
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print("SAVED " + str(args.out), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--reports", type=Path, default=Path("reports/experiments"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_failure_review.json"))
    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
