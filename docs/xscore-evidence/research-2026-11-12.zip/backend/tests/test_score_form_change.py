import numpy as np

from app.research.score_form_change import estimates


def test_stable_routine_leaves_the_mean_in_place():
    base, change, probability = estimates(np.full(16, 10.0), 10, 13)
    assert base == 10
    assert abs(change) < 1e-12
    assert probability < 0.1


def test_recent_routine_shift_and_independent_rare_event_history():
    old = np.r_[np.full(12, -10), np.full(8, 35)]
    _, change, probability = estimates(old, 10, 13)
    assert change > 8 and probability > 0.9
    _, _, event_break = estimates(np.zeros(len(old)), 0.15, 13, binary=True)
    assert event_break < 0.15


def test_short_history_cannot_infer_a_break():
    assert estimates(np.array([1, 0]), 0.1, 7, binary=True) == (1.5 / 7, 0, 0)
