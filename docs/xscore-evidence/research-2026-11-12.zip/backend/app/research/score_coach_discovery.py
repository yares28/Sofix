"""Locate candidate coach announcements. Discovery dates never become model inputs."""

import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime
from html import unescape
from pathlib import Path
from urllib.parse import urlsplit

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_match_context import CLUBS
from app.research.score_referee_archive import club_key

ROOT_COACH = ROOT / "coach-source"
ALIASES = {
    "Athletic Bilbao": "Athletic Club",
    "Alavés": "Deportivo Alaves",
    "Valladolid": "Real Valladolid",
    "Celta": "Celta Vigo",
    "Oviedo": "Real Oviedo",
    "Racing": "Racing Santander",
    "Deportivo": "Deportivo A Coruna",
}


def flatten(source):
    no_notes = re.sub(r"<sup\b[^>]*>.*?</sup>", "", source, flags=re.S)
    no_notes = re.sub(r"<br\b[^>]*>", " ", no_notes)
    return " ".join(unescape(re.sub(r"<[^>]+>", "", no_notes)).split())


def rows(table):
    carry = {}
    for raw in re.findall(r"<tr\b[^>]*>(.*?)</tr>", table, re.S):
        cells = re.findall(r"<td\b([^>]*)>(.*?)</td>", raw, re.S)
        if not cells:
            continue
        current = []
        pos = 0
        while len(current) < 7:
            col = len(current)
            if col in carry:
                value, count = carry[col]
                current.append(value)
                if count > 1:
                    carry[col] = value, count - 1
                else:
                    del carry[col]
                continue
            if pos == len(cells):
                raise ValueError("Short discovery row after expanding row spans")
            attrs, value = cells[pos]
            pos += 1
            current.append(value)
            span = re.search(r'\browspan="(\d+)"', attrs)
            if span and int(span[1]) > 1:
                carry[col] = value, int(span[1]) - 1
        if pos != len(cells):
            raise ValueError("Long discovery row after expanding row spans")
        yield current


def inventory(html, item):
    _, section = html.split('id="Managerial_changes"', 1)
    _, table = section.split("<table", 1)
    table = table.split("</table>", 1)[0]
    assert "Incoming manager" in table and "Date of appointment" in flatten(table)
    references = {
        unescape(key): value
        for key, value in re.findall(r'<li\b[^>]*id="(cite_note-[^"]+)"[^>]*>(.*?)</li>', html, re.S)
    }
    club_slugs = {club_key(c): s for c, s in CLUBS.items()}
    club_slugs.update({club_key(k): CLUBS[v] for k, v in ALIASES.items()})
    result = []
    for cells in rows(table):
        team, coach, appointment = (flatten(cells[i]) for i in (0, 5, 6))
        day = None
        date_match = re.fullmatch(r"(\d{1,2} [A-Za-z]+ 20\d{2})", appointment)
        if date_match:
            day = datetime.strptime(date_match[1], "%d %B %Y").date().isoformat()
        urls = set()
        for note in re.findall(r'href="#(cite_note-[^"]+)"', cells[5] + cells[6]):
            for url in re.findall(r'href="(https?://[^"]+)"', references.get(unescape(note), "")):
                url = unescape(url)
                host = (urlsplit(url).hostname or "").lower()
                if host.endswith("wikipedia.org") or "transfermarkt" in host:
                    continue
                urls.add(url)
        result.append(
            dict(
                season=int(item["season"]),
                team=team,
                club=club_slugs.get(club_key(team)),
                incomingCoach=coach,
                appointmentText=appointment,
                candidateDate=day,
                referenceLinks=sorted(urls),
                locator=item["url"],
            )
        )
    return result


def main():
    path = ROOT_COACH / "discovery_manifest.json"
    records = json.loads(path.read_text(encoding="utf-8-sig"))
    assert {int(r["season"]) for r in records} == {2023, 2024, 2025, 2026}
    changes = []
    for item in records:
        data = Path(item["file"]).read_bytes()
        assert item["status"] == 200 and hashlib.sha256(data).hexdigest() == item["sha256"]
        changes.extend(inventory(data.decode("utf-8"), item))
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, raw.splitlines()), key=lambda g: (g["date"], g["id"]))
    outcomes = json.loads((ROOT / "cases.json").read_text())["rows"]
    windows = defaultdict(set)
    for change in changes:
        club, day = change["club"], change["candidateDate"]
        if not club or not day:
            continue
        season = change["season"]
        begin = max(f"{season}-07-01", day)
        eligible = [
            g
            for g in games
            if begin <= g["date"] < f"{season + 1}-07-01" and club in (g["home"]["slug"], g["away"]["slug"])
        ][:6]
        change["candidateFixtures"] = [g["id"] for g in eligible]
        for g in eligible:
            windows["all"].add(g["id"])
            if change["referenceLinks"]:
                windows["withReference"].add(g["id"])
    scope = {}
    for phase, (begin, end) in dict(PHASES, later2026=("2026-01-01", "2027-01-01")).items():
        group = [r for r in outcomes if begin <= r["date"] < end]
        scope[phase] = {
            category: dict(
                fixtures=len({r["game"] for r in group if r["game"] in window}),
                start=sum(r["cohort"] == "start" and r["game"] in window for r in group),
                bench=sum(r["cohort"] == "bench" and r["game"] in window for r in group),
            )
            for category, window in windows.items()
        }
    report = dict(
        manifestSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        changes=len(changes),
        bySeason=dict(Counter(x["season"] for x in changes)),
        candidateClubAndDate=sum(bool(x["club"] and x["candidateDate"]) for x in changes),
        withReferences=sum(bool(x["referenceLinks"]) for x in changes),
        provisionalCoverage=scope,
        currentOrFutureMatchLabelsEvaluated=False,
        approvedInputs=0,
        limit="Secondary locator only. Dates and linked URLs need original source and version verification before modelling.",
        appointments=changes,
    )
    (REPORTS / "laliga_score_coach_discovery.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "appointments"}, indent=2))


if __name__ == "__main__":
    main()
