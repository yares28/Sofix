import copy

import numpy as np

from app.research.score_prior_chances import link_players, prior_features


def record(year=2024, name="Test Player", identity="1", **extra):
    return {
        "id": identity,
        "player_name": name,
        "year": str(year),
        "league": "La_Liga",
        "games": "10",
        "time": "900",
        "scrape_timestamp": "2025-09-01T12:00:00",
        **extra,
    }


def test_unique_names_and_full_slug_subsets_link_but_ambiguous_names_do_not():
    data = [record(), record(name="Common Name", identity="2"), record(name="Common Name", identity="3")]
    links = link_players(["test-player-extra", "common-name", "unseen"], {}, data)
    assert links == {"test-player-extra": "1"}


def test_current_future_and_target_scores_cannot_change_previous_season_inputs():
    data = [record(xG="4"), record(year=2025, xG="90"), record(year=2026, xG="100")]
    rows = [{"player": "test-player", "date": "2025-10-01T20:00:00Z", "score": 80}]
    before, names, _ = prior_features(rows, {"test-player": "1"}, data)
    changed = copy.deepcopy(data)
    changed[1]["xG"] = "1"
    changed[2]["xG"] = "0"
    rows[0]["score"] = 0
    after, _, _ = prior_features(rows, {"test-player": "1"}, changed)
    np.testing.assert_array_equal(before, after)
    assert before[0, names.index("prior_xG_per90")] == 0.4


def test_missing_and_observed_zero_differ_and_unmatched_cases_are_kept():
    rows = [{"player": p, "date": "2025-10-01T20:00:00Z"} for p in ("known", "unknown")]
    x, names, _ = prior_features(rows, {"known": "1"}, [record(xG="0")])
    assert len(x) == 2
    assert x[0, names.index("prior_xG_per90")] == 0
    assert np.isnan(x[1, names.index("prior_xG_per90")])
    assert x[1, names.index("prior_found")] == 0


def test_partial_prior_snapshot_and_separate_league_spells_are_explicit():
    data = [record(year=2025, xG="2"), record(year=2025, xG="3", league="EPL")]
    rows = [{"player": "known", "date": "2026-08-14T20:00:00Z"}]
    x, names, _ = prior_features(rows, {"known": "1"}, data)
    assert x[0, names.index("prior_xG_per90")] == 0.25
    assert x[0, names.index("prior_partial_snapshot")] == 1
    assert x[0, names.index("prior_laliga_minutes_share")] == 0.5


def test_duplicate_same_league_identity_is_rejected():
    import pytest

    with pytest.raises(ValueError, match="Duplicate"):
        prior_features([], {}, [record(), record()])
