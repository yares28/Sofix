import numpy as np
import pytest

from app.research.score_defensive_residuals import (
    draw_conceded,
    fit_exposure,
    forecast_effect,
    monotone,
    paired_draws,
    point_effect,
)


def test_native_defensive_points_obey_clean_sheet_threshold_and_conceded_weights():
    goals = np.array([[0, 0, 1, 2], [0, 0, 1, 2]])
    minutes = np.array([[59, 60, 90, 90], [59, 60, 90, 90]])
    np.testing.assert_equal(point_effect(goals, minutes, ["DEF", "MID"]), [[0, 10, -4, -8], [0, 0, -2, -4]])
    with pytest.raises(ValueError, match="minute range"):
        point_effect([0], [91], ["DEF"])


def test_exposure_curve_uses_only_fit_labels_and_zero_denominator_keeps_prior():
    minutes = np.array([20, 60, 90, 45])
    player = np.array([1, 3, 5, 999.0])
    team = np.array([4, 4, 5, 1.0])
    positions = np.array(["DEF"] * 4)
    fit = np.array([True, True, True, False])
    a, _ = fit_exposure(minutes, player, team, positions, fit)
    player[-1] = np.nan
    team[-1] = np.nan
    b, _ = fit_exposure(minutes, player, team, positions, fit)
    np.testing.assert_equal(a, b)
    assert a[0] == 0 and a[90] == 1 and (np.diff(a) >= -1e-12).all()
    cold, _ = fit_exposure([20], [0], [0], ["DEF"], [True])
    np.testing.assert_allclose(cold, np.arange(91) / 90)


def test_mean_and_median_effects_cover_plain_and_zero_adjusted_distributions():
    mean = forecast_effect(
        np.array([1.0]), np.array([0.8]), np.array([90.0]), np.array(["DEF"]), None, "lambda", "mean"
    )
    assert mean[0] == pytest.approx(-4 + 10 / np.e)
    median = forecast_effect(
        np.array([1.0]), np.array([0.8]), np.array([90.0]), np.array(["DEF"]), None, "lambda", "median"
    )
    assert median[0] == -4
    calibrated = forecast_effect(
        np.array([1.0]), np.array([0.8]), np.array([90.0]), np.array(["DEF"]), None, "calibratedCS", "median"
    )
    assert calibrated[0] == 10


def test_zero_lambda_and_zero_or_one_clean_probability_never_drop_draws():
    u = np.linspace(0, 0.999, 1000)
    for clean in (0.0, 1.0):
        goals = draw_conceded(np.array([0.0]), np.array([clean]), np.full((1, 1000), 90.0), None, "calibratedCS", u)
        assert goals.shape == (1, 1000) and np.isfinite(goals).all()
    no_goals = draw_conceded(np.array([0.0]), np.array([0.5]), np.full((1, 1000), 90.0), None, "lambda", u)
    assert not no_goals.any()


def test_pair_sampling_preserves_routine_error_and_minute_error_association():
    pool = np.array([[-10, -20], [10, 20]], dtype=float)
    u = np.linspace(0, 0.999, 1000)
    pairs = paired_draws(pool, np.empty((0, 2)), u, u)
    assert (pairs[:, 0] * pairs[:, 1] > 0).all()
    np.testing.assert_equal(pairs[:, 1], pairs[:, 0] * 2)


def test_monotone_exposure_pools_adjacent_conflicting_bins_by_their_goal_weights():
    np.testing.assert_allclose(monotone([0, 0.8, 0.2, 0.9], [1, 3, 1, 1]), [0, 0.65, 0.65, 0.9])
