import copy
import sys
from types import SimpleNamespace

import numpy as np

from app.research.score_role_minutes import conditional_forecasts, role_arrays
from tests.test_score_style import row, source_game


def test_current_formation_is_a_label_and_cannot_change_prelock_role():
    past = source_game("2025-09-20T18:00:00Z", "past")
    target = source_game("2025-10-12T18:00:00Z", "target")
    before = role_arrays([past, target], [row(target)])
    changed = copy.deepcopy(target)
    lines = changed["xi"]["home"]["start"]
    lines[0].remove("player")
    lines[-1].append("player")
    after = role_arrays([past, changed], [row(changed)])
    assert before[0][0] != after[0][0]
    np.testing.assert_array_equal(before[1], after[1])


def test_bench_without_a_known_starting_role_stays_unknown():
    target = source_game("2025-10-12T18:00:00Z", "target")
    r = {**row(target), "cohort": "bench"}
    actual, previous = role_arrays([target], [r])
    assert actual.tolist() == previous.tolist() == [9]


def test_forecasts_do_not_read_actual_check_minutes_role_level_or_points(monkeypatch):
    class Classifier:
        def __init__(self, **kwargs):
            pass

        def fit(self, x, y):
            self.classes_ = np.unique(y)
            return self

        def predict(self, x):
            return np.full(len(x), self.classes_[0])

        def predict_proba(self, x):
            return np.full((len(x), len(self.classes_)), 1 / len(self.classes_))

    class Regressor:
        def __init__(self, **kwargs):
            pass

        def fit(self, x, y):
            self.value = y.mean()
            return self

        def predict(self, x):
            return self.value + x[:, -1] * 0.01

    monkeypatch.setitem(
        sys.modules,
        "sklearn.ensemble",
        SimpleNamespace(HistGradientBoostingClassifier=Classifier, HistGradientBoostingRegressor=Regressor),
    )
    x = np.zeros((2, 2))
    fit = np.array([True, False])
    roles, minutes, aa, levels = (
        np.array([4, 4]),
        np.array([90.0, 80.0]),
        np.array([10.0, 20.0]),
        np.array([35.0, 60.0]),
    )
    previous = np.array([4, 4])
    before = conditional_forecasts(x, roles, previous, minutes, aa, levels, fit, ~fit, "start")
    roles[1], minutes[1], aa[1], levels[1] = 9, 1, 99, 100
    after = conditional_forecasts(x, roles, previous, minutes, aa, levels, fit, ~fit, "start")
    for key in before:
        for field in ("classes", "probability", "role", "minutes"):
            np.testing.assert_array_equal(before[key][field], after[key][field])
        for q in before[key]["ordinary"]:
            np.testing.assert_array_equal(before[key]["ordinary"][q], after[key]["ordinary"][q])
