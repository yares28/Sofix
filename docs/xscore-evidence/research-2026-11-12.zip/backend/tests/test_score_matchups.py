import copy

import numpy as np

from app.research.score_matchups import adjusted_duel_fraction, build_matchups


def fixture(identity, date, won=4, minutes=90):
    return {
        "id": identity,
        "date": date,
        "home": {"slug": "h"},
        "away": {"slug": "a"},
        "players": {
            "p": {
                "team": "h",
                "pos": "DEF",
                "played": True,
                "ver": 7,
                "mins": minutes,
                "stats": {"duel_won": [won, won * 1.5]},
            },
            "q": {
                "team": "a",
                "pos": "FWD",
                "played": True,
                "ver": 7,
                "mins": 90,
                "stats": {"duel_won": [2, 2], "duel_lost": [2, -2]},
            },
        },
    }


def test_future_actual_lineup_and_actions_do_not_enter_matchups():
    games = [fixture("old", "2025-10-20T20:00:00Z"), fixture("target", "2025-11-01T18:00:00Z")]
    rows = [{"game": "target", "date": games[-1]["date"], "player": "p", "pos": "DEF", "x": [1]}]
    first, names, _ = build_matchups(rows, games, [], ["home"])
    changed = copy.deepcopy(games)
    changed[-1]["players"] = {}
    changed[-1]["xi"] = {"home": {"start": [["future-secret-player"]]}}
    second, other_names, _ = build_matchups(rows, changed, [], ["home"])
    assert names == other_names
    np.testing.assert_array_equal(first, second)


def test_unavailable_result_is_not_an_earlier_opponent_record_and_cold_case_is_kept():
    games = [fixture("late", "2025-10-31T20:00:00Z"), fixture("target", "2025-11-01T18:00:00Z")]
    rows = [{"game": "target", "date": games[-1]["date"], "player": "p", "pos": "DEF", "x": [1]}]
    values, names, audit = build_matchups(rows, games, [], ["home"])
    assert len(values) == audit["rows"] == 1
    assert values[0, names.index("opponent_recent_games")] == 0
    assert np.isnan(values[0, names.index("opponent_total_duel_won")])


def test_known_zero_action_is_distinct_from_no_complete_player_stats():
    old = fixture("old", "2025-10-20T20:00:00Z", won=0)
    target = fixture("target", "2025-11-01T18:00:00Z")
    rows = [{"game": "target", "date": target["date"], "player": "p", "pos": "DEF", "x": [1]}]
    known, names, _ = build_matchups(rows, [old, target], [], ["home"])
    missing = copy.deepcopy(old)
    missing["players"]["p"]["stats"] = None
    unknown, _, _ = build_matchups(rows, [missing, target], [], ["home"])
    assert known[0, names.index("own_duel_won90")] == 0
    assert np.isnan(unknown[0, names.index("own_duel_won90")])
    assert unknown[0, names.index("own_known_games")] == 0


def test_future_native_role_is_inert_until_its_fixture_is_available():
    games = [fixture("old", "2025-10-20T20:00:00Z"), fixture("target", "2025-11-01T18:00:00Z")]
    rows = [{"game": "target", "date": games[-1]["date"], "player": "p", "pos": "DEF", "x": [1]}]
    observed = [
        {
            "game": g["id"],
            "date": g["date"],
            "player": "p",
            "club": "h",
            "values": {"usage_role_depth": 0.2, "usage_role_edge": 0},
        }
        for g in games
    ]
    first, names, _ = build_matchups(rows, games, observed, ["home"])
    changed = copy.deepcopy(observed)
    changed[-1]["values"] = {"usage_role_depth": 1.0, "usage_role_edge": 1}
    second, _, _ = build_matchups(rows, games, changed, ["home"])
    np.testing.assert_array_equal(first, second)
    assert first[0, names.index("own_role_depth")] == 0.2


def test_duel_adjustment_is_neutral_for_average_opponents_and_reacts_to_quality():
    assert np.isclose(adjusted_duel_fraction(0.6, 0.4, 0.4), 0.6)
    assert adjusted_duel_fraction(0.6, 0.7, 0.4) < 0.6
    assert adjusted_duel_fraction(0.6, 0.3, 0.4) > 0.6
    assert np.isnan(adjusted_duel_fraction(0.6, np.nan, 0.4))
