from app.research.score_history_components import feature_groups


def test_mode_only_ablation_keeps_tackle_bounds_and_bonus_frequencies_separate():
    names = [
        "modal_history_low_mode",
        "modal_history_high_fraction",
        "tackle_minimum90",
        "tackle_maximum90",
        "bonus_12_fraction",
    ]
    groups = feature_groups(names)
    assert groups["score_modes"].tolist() == [True, True, False, False, False]
    assert groups["modes_and_bonus_bounds"].all()
