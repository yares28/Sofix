"""Research-only error accounting must not confuse hindsight with forecasts."""

import numpy as np

from app.research import score_failure_review as review


def test_activity_groups_count_each_native_point_once_and_preserve_unclassified_stats():
    names = [stat for values in review.ACTIVITY_GROUPS.values() for stat in values]
    assert len(names) == len(set(names))
    stats = {"duel_won": [4, 4], "goals_conceded": [1, -4], "accurate_pass": [10, 1], "unexpected_stat": [1, 3]}
    grouped = review.activity_groups(stats)
    assert sum(grouped.values()) == sum(v[1] for v in stats.values()) == 4
    assert grouped["duelsTacklesRecoveries"] == 4
    assert grouped["otherActionsAndBonuses"] == 3


def test_failure_summary_keeps_inclusive_seven_and_direction():
    result = review.summary(np.array([40.0, 40.0, 40.0, 40.0]), np.array([33.0, 47.0, 32.5, 48.0]))
    assert result["n"] == 4 and result["correct"] == 2 and result["misses"] == 2
    assert result["underByMoreThan7"] == result["overByMoreThan7"] == 1


def test_native_scoring_preserves_zero_cap_and_positive_decisive_floor():
    np.testing.assert_array_equal(
        review.native_score(np.array([-40.0, 0.0, -20.0, 100.0, -50.0]), np.array([35.0, 35.0, 60.0, 35.0, 100.0])),
        [0.0, 35.0, 60.0, 100.0, 100.0],
    )


def test_hindsight_miss_categories_are_disjoint_and_count_spoiled_hits():
    actual = np.array([40.0, 80.0, 40.0, 80.0, 40.0])
    pred = np.array([40.0, 40.0, 80.0, 40.0, 80.0])
    known_event = np.array([80.0, 80.0, 80.0, 80.0, 80.0])
    known_activity = np.array([40.0, 40.0, 40.0, 80.0, 80.0])
    result = review.partition(actual, pred, known_event, known_activity)
    assert result["originalMisses"] == 4
    assert result["eventOnly"] == result["activityOnly"] == result["eitherAlone"] == result["neitherAlone"] == 1
    assert result["knownEventSpoiledHits"] == 1
    assert sum(result[k] for k in ("eventOnly", "activityOnly", "eitherAlone", "neitherAlone")) == 4


def test_historical_context_excludes_equal_48h_boundary_and_unknown_defaults():
    rows = [
        dict(game="old", player="p", date="2023-12-01T14:00:00Z", cohort="start", minutes=90),
        dict(game="edge", player="p", date="2023-12-31T14:00:00Z", cohort="start", minutes=10),
        dict(game="current", player="p", date="2024-01-02T20:00:00Z", cohort="start", minutes=20),
    ]
    native = {
        ("old", "p"): {"defensiveAA": 0},
        ("edge", "p"): {"defensiveAA": -8},
        ("current", "p"): {"defensiveAA": 10},
    }
    context = review.historical_context(rows, native)
    assert context[0]["count"] == 0 and context[0]["meanMinutes3"] is None
    assert context[2]["count"] == 1 and context[2]["meanMinutes3"] == 90
    assert context[2]["meanDefensiveAA3"] == 0
