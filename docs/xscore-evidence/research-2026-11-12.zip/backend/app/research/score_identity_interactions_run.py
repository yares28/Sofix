"""Testing only: nonlinear identity interactions for native LaLiga score-window predictions."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_density_blend as density
from app.research import score_density_blend_run as reference_runner
from app.research import score_identity as identity
from app.research import score_identity_interactions as network
from app.research import score_ordinary as ordinary
from app.research import score_pooled_conditioning_run as shared
from app.research import score_pooled_windows as normalisation
from app.research import score_stability as stability
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval
from app.research.score_team_shape_conditioning_run import validate_stat_identity

MODEL_NAMES = ("rank4_penaltystrong", "numeric_penaltystrong")


def load_inputs(args, source, reports):
    arrays, keys = {}, {}
    for name, file in (
        ("base", "stats.npz"),
        ("match", "match_context_features.npz"),
        ("player", "player_context_features.npz"),
    ):
        with np.load(args.cache / file) as f:
            arrays[name] = f["x"], f["names"].tolist()
            keys[name] = str(f["key"])
            if len(f["x"]) != len(source["rows"]):
                raise ValueError("Interaction native numeric case coverage differs")
    validate_stat_identity(
        keys["base"],
        reports["laliga_score_match_context"],
        json.loads((args.out.parent / "laliga_score_player_context.json").read_text()),
    )
    player_report = json.loads((args.out.parent / "laliga_score_player_context.json").read_text())
    if (
        keys["match"] != reports["laliga_score_match_context"]["featureKey"]
        or keys["player"] != player_report["featureKey"]
        or player_report["sourceKey"] != source["key"]
    ):
        raise ValueError("Interaction native player/team numeric provenance differs")
    raw = args.games.read_bytes()
    keys["nativeGamesSha256"] = hashlib.sha256(raw).hexdigest()
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    if keys["nativeGamesSha256"] not in plan["inputs"]:
        raise ValueError("Interaction native fixture source differs from registered plan")
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    categories = identity.category_values(source["rows"], games)
    if not np.array_equal(categories[:, 3], [r["pos"] for r in source["rows"]]):
        raise ValueError("Interaction native current card-position identities differ")
    return arrays, keys, categories


def numeric_inputs(arrays, keep, positions, cohort):
    compact, _ = ordinary.ordinary_inputs(
        arrays["base"][0][keep],
        arrays["base"][1],
        arrays["player"][0][keep],
        arrays["player"][1],
        arrays["match"][0][keep],
        arrays["match"][1],
        cohort,
    )
    strong = np.column_stack((arrays["base"][0][keep], arrays["match"][0][keep]))
    flags = np.column_stack([(positions == p).astype(float) for p in POSITIONS])
    if compact.shape[1] != 137 or strong.shape[1] != 677:
        raise ValueError("Interaction registered numeric input schema differs")
    return {"compact": np.column_stack((compact, flags)), "strong": np.column_stack((strong, flags))}


def implementation_key(source, input_keys, reports, plan):
    auxiliary = hashlib.sha256(json.dumps(input_keys, sort_keys=True).encode()).hexdigest()
    inherited = shared.implementation_key(
        source, auxiliary, reports, plan, "numpy-identity-interactions:" + np.__version__
    )
    return hashlib.sha256(
        inherited.encode()
        + Path(__file__).read_bytes()
        + plan.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in (network, identity, normalisation))
    ).hexdigest()


def fitted(x, categories, y, mask, spec, epochs, path, key):
    if path.exists():
        with np.load(path) as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["fit"], mask["fit"])
                or not np.array_equal(f["target"], mask["target"])
                or f["mass"].shape != (int(mask["target"].sum()), 201)
            ):
                raise ValueError("Interaction model cache identity or full population differs")
            density.validate_mass(f["mass"])
            return f["mass"], json.loads(str(f["statistics"]))
    model = network.InteractionNetwork(**spec, epochs=epochs).fit(
        x[mask["fit"]], categories[mask["fit"]], y[mask["fit"]]
    )
    mass = model.predict_mass(x[mask["target"]], categories[mask["target"]])
    stats = {**model.statistics_, "targetRows": int(mask["target"].sum())}
    np.savez_compressed(
        path,
        key=key,
        mass=mass,
        prediction=network.window_centres(mass, network.CENTRES),
        fit=mask["fit"],
        target=mask["target"],
        statistics=json.dumps(stats, sort_keys=True),
        category_maps=json.dumps(model.encoder_.maps_, sort_keys=True),
        history=model.history_,
        normaliser_mean=model.normaliser_.mean_,
        normaliser_scale=model.normaliser_.scale_,
        normaliser_known=model.normaliser_.known_,
        **{"w_" + n: w for n, w in model.weights_.items()},
    )
    return mass, stats


def fresh(spec):
    return dict(spec=spec, gains=[], errors=[], counts=[], periods={})


def add_metric(record, phase, y, prediction, control, statistics):
    metric = measure(y, prediction)
    gain = metric["within7"] - measure(y, control)["within7"]
    record["gains"].append(gain)
    record["errors"].append(metric["mae"])
    record["counts"].append(len(y))
    record["periods"][phase] = dict(gain=gain, metrics=metric, fitDiagnostics=statistics)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    reports = {n: json.loads((args.out.parent / (n + ".json")).read_text()) for n in shared.REPORTS}
    if any(r["sourceKey"] != source["key"] for r in reports.values()):
        raise ValueError("Interaction original reference source cases differ")
    arrays, input_keys, identities = load_inputs(args, source, reports)
    key = implementation_key(source, input_keys, reports, args.out.with_suffix(".plan.json"))
    report = dict(
        scope="Testing only; no application changes",
        sourceKey=source["key"],
        implementationKey=key,
        inputKeys=input_keys,
        evidenceLimit="Repeated retrospective reuse, exploratory not fresh blind proof",
        cohorts={},
    )
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] != key:
            raise ValueError("Existing interaction report has a different frozen implementation")
        report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        if cohort in report["cohorts"]:
            continue
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        categories = identities[keep, :3]
        y, positions, weeks = (np.array([r[n] for r in rows]) for n in ("score", "pos", "week"))
        masks = stability.phase_masks(rows)
        inputs = numeric_inputs(arrays, keep, positions, cohort)
        references = {}

        def reference(phase, references=references, cohort=cohort, masks=masks, y=y):
            if phase not in references:
                mass, control, _, receipt = reference_runner.reference(args, key, source, cohort, phase, masks, reports)
                expected = (
                    reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                    if phase != "later2026"
                    else reports[
                        "laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"
                    ]["cohorts"][cohort]["later"]
                )
                if measure(y[masks[phase]["target"]], control) != expected:
                    raise ValueError("Identity-interaction original all-case control did not reproduce")
                references[phase] = mass, control, receipt
            return references[phase]

        def get_mass(
            phase, model_name, group, epochs, masks=masks, cohort=cohort, inputs=inputs, categories=categories, y=y
        ):
            mask = masks[phase]
            spec = network.PARAMETERS[model_name]
            path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}_{model_name}_{epochs}.npz"
            print(f"INTERACTION_FIT {cohort} {phase} {group} {model_name} epochs{epochs}", flush=True)
            mass, stats = fitted(inputs[group], categories, y, mask, spec, epochs, path, key)
            if epochs == 160 and phase != "later2026":
                previous = args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}_{model_name}_80.npz"
                with np.load(previous) as a, np.load(path) as b:
                    if not np.array_equal(a["history"], b["history"][:80]) or any(
                        not np.array_equal(a[n], b[n])
                        for n in (
                            "normaliser_mean",
                            "normaliser_scale",
                            "normaliser_known",
                            "fit",
                            "target",
                            "category_maps",
                        )
                    ):
                        raise ValueError("160-epoch identity-interaction confirmation lost fixed80 training prefix")
            return mass, stats

        records = [
            fresh(dict(model=n, group=g, weight=w, scope=c))
            for n in MODEL_NAMES
            for g in inputs
            for w in (0.25, 0.5, 1)
            for c in ("all", "defmid")
        ]
        audit = {}
        for phase, _, _ in stability.PHASES[1:-1]:
            mask = masks[phase]
            target = mask["target"]
            base, control, receipt = reference(phase)
            audit[phase] = dict(control=measure(y[target], control), reference=receipt, models={})
            for name in MODEL_NAMES:
                for group in inputs:
                    mass, stats = get_mass(phase, name, group, 80)
                    audit[phase]["models"][name + ":" + group] = stats
                    for record in [r for r in records if r["spec"]["model"] == name and r["spec"]["group"] == group]:
                        spec = record["spec"]
                        prediction, _ = density.forecast(
                            base, mass, spec["weight"], control, positions[target], spec["scope"]
                        )
                        add_metric(record, phase, y[target], prediction, control, stats)
                    print(f"INTERACTION_SCREEN {cohort} {phase} {group} {name}", flush=True)
        winner80, best80 = stability.choose_stable(records)
        fixed = winner80 or best80
        args.out.with_name(args.out.stem + f".{cohort}.screening.json").write_text(
            json.dumps(
                dict(
                    implementationKey=key,
                    winner80=winner80,
                    best80=best80,
                    fixedConfirmationSpec=fixed["spec"],
                    candidates80=records,
                ),
                indent=2,
            )
        )
        if winner80 is None:
            frozen = dict(
                implementationKey=key,
                winner=None,
                screenWinner80=None,
                screenBest80=best80,
                candidates80=records,
                passingCandidates80=0,
                confirmationSkipped=True,
                reason="No candidate improved all three earlier periods; retire without final fits",
            )
            args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
            report["cohorts"][cohort] = dict(
                selected="control",
                candidateCount=len(records) + 1,
                earlierPeriods=audit,
                candidate=best80,
                laterStatus="Not evaluated; earlier gate failed",
                confirmationSkipped=True,
            )
            args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
            print("INTERACTION_REJECTED_EARLIER " + json.dumps(dict(cohort=cohort, candidate=best80)), flush=True)
            continue
        confirmed = fresh(fixed["spec"].copy())
        for phase, _, _ in stability.PHASES[1:-1]:
            target = masks[phase]["target"]
            spec = fixed["spec"]
            mass, stats = get_mass(phase, spec["model"], spec["group"], 160)
            base, control, _ = reference(phase)
            prediction, _ = density.forecast(base, mass, spec["weight"], control, positions[target], spec["scope"])
            add_metric(confirmed, phase, y[target], prediction, control, stats)
        winner = confirmed if min(confirmed["gains"]) > 0 else None
        frozen = dict(
            implementationKey=key,
            winner=winner,
            finalCandidate=confirmed,
            screenWinner80=winner80,
            screenBest80=best80,
            candidates80=records,
            passingCandidates80=sum(min(r["gains"]) > 0 for r in records),
        )
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
        print("INTERACTION_FROZEN " + json.dumps(dict(cohort=cohort, winner=winner, candidate=confirmed)), flush=True)
        if winner is None:
            report["cohorts"][cohort] = dict(
                selected="control",
                candidateCount=len(records) + 1,
                earlierPeriods=audit,
                candidate=confirmed,
                laterStatus="Not evaluated; fixed longer confirmation failed",
                confirmationSkipped=False,
            )
            args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
            continue
        phase = "later2026"
        target = masks[phase]["target"]
        spec = fixed["spec"]
        mass, stats = get_mass(phase, spec["model"], spec["group"], 160)
        base, control, _ = reference(phase)
        alternate, _ = density.forecast(base, mass, spec["weight"], control, positions[target], spec["scope"])
        prediction = alternate if winner else control.copy()
        h0, h1 = abs(y[target] - control) <= 7, abs(y[target] - alternate) <= 7
        result = dict(
            selected="candidate" if winner else "control",
            winner=winner,
            candidate=confirmed,
            candidateCount=len(records) + 1,
            earlierPeriods=audit,
            later=measure(y[target], prediction),
            candidateLater=measure(y[target], alternate),
            control=measure(y[target], control),
            candidateGainedCorrect=int((h1 & ~h0).sum()),
            candidateLostCorrect=int((h0 & ~h1).sum()),
            candidateGain95=paired_interval(y[target], alternate, control, weeks[target].tolist()),
            finalFitDiagnostics=stats,
            positions={
                p: dict(
                    candidate=measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    control=measure(y[target][positions[target] == p], control[positions[target] == p]),
                )
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        )
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "INTERACTION_RESULT "
            + json.dumps(
                dict(
                    cohort=cohort,
                    selected=result["selected"],
                    later=result["later"],
                    candidateLater=result["candidateLater"],
                )
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
