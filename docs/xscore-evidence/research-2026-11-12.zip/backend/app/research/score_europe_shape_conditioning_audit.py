"""Testing only: reconstruct European shape formula choices and native metrics."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_europe_shape_conditioning as conditioning
from app.research import score_europe_shape_conditioning_run as runner
from app.research import score_europe_shape_history as history
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional
from app.research import score_team_shape_history as primitive
from app.research.score_joint_density import components
from app.research.score_search import measure


def refit_without_outside_labels(x, rows, mask, saved):
    aa = np.array([r["aa"] for r in rows], dtype=float)
    levels = np.array([r["level"] for r in rows], dtype=float)
    aa[~mask["fit"]], levels[~mask["fit"]] = np.nan, np.nan
    repeated = conditional.conditional_components(x, aa, levels, mask["fit"], mask["target"])
    if (
        not np.array_equal(saved[0], repeated[0])
        or not np.allclose(saved[1], repeated[1], rtol=0, atol=1e-12)
        or any(not np.allclose(saved[2][q], repeated[2][q], rtol=0, atol=1e-10) for q in saved[2])
    ):
        raise ValueError("European shape real refit changed after blanking outside-fit outcomes")
    return {
        "fitCases": int(mask["fit"].sum()),
        "forecastCases": int(mask["target"].sum()),
        "outsideFitOutcomeRowsBlanked": int((~mask["fit"]).sum()),
        "all4FittedModelsReproduced": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda name: json.loads((args.report.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    feature_report = read("laliga_score_europe_shape_features")
    feature_audit = read("laliga_score_europe_shape_features.integrity")
    if (
        any(
            r["sourceKey"] != source["key"]
            for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench, feature_report)
        )
        or feature_audit["featureKey"] != report["historyFeatureKey"]
        or feature_audit["independentFeatureRows"] != len(source["rows"])
        or not feature_audit["all204ColumnsReproduced"]
        or not feature_audit["allOriginalLLOnly102ColumnsBitExactlyReproduced"]
    ):
        raise ValueError("European shape formula audit source/feature identity differs")
    with np.load(args.cache / "stats.npz") as f:
        stat_key = str(f["key"])
    files = [
        Path(runner.__file__),
        Path(history.__file__),
        Path(primitive.__file__),
        Path(conditioning.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        Path(conditional.__file__),
        args.report.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + report["historyFeatureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("European shape formula audit code/plan fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, levels, positions = (
            np.array([r["score"] for r in rows]),
            np.array([r["level"] for r in rows]),
            np.array([r["pos"] for r in rows]),
        )
        masks = stability.phase_masks(rows)
        call_args = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or winner != frozen["winner"]
            or best != frozen["best"]
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("European shape formula audit earlier choice/gate differs")
        old = {
            phase: flow.old_components(call_args, cohort, phase, old_match, old_stability, old_ordinary)
            for phase, _, _ in stability.PHASES
        }
        bundles = {}
        for phase, _, _ in stability.PHASES:
            groups = (
                [best["spec"]["group"]] if phase == "later2026" else tuple(conditioning.feature_groups(history.NAMES))
            )
            for group in groups:
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{group}.npz"
                pieces = components(path, key)
                if (
                    len(pieces[1]) != int(masks[phase]["target"].sum())
                    or not np.array_equal(pieces[0], np.unique(levels[masks[phase]["fit"]]))
                    or not np.isfinite(pieces[1]).all()
                    or not np.allclose(pieces[1].sum(axis=1), 1)
                    or any(not np.isfinite(v).all() for v in pieces[2].values())
                ):
                    raise ValueError("European shape formula audit fitted class support/coverage differs")
                bundles[(phase, group)] = pieces
        reconstructed, mutated_labels = 0, 0
        for phase_index, (phase, _, _) in enumerate(stability.PHASES[1:], start=1):
            target = masks[phase]["target"]
            previous_phase = stability.PHASES[phase_index - 1][0]
            previous_rows = [r for r, yes in zip(rows, masks[previous_phase]["target"], strict=True) if yes]
            control = controls.control_for(
                call_args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected_control = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected_control:
                raise ValueError("European shape formula strongest control differs")
            active = [best] if phase == "later2026" else frozen["candidates"]
            groups = {
                (r["spec"]["group"], r["spec"]["policy"], r["spec"]["spread"], r["spec"]["shift"]) for r in active
            }
            for group, policy, spread, shift in sorted(groups):
                current = runner.component_policy(old[phase], bundles[(phase, group)], policy)
                previous = runner.component_policy(old[previous_phase], bundles[(previous_phase, group)], policy)
                bank = runner.bank_from(previous, previous_rows, masks[phase]["first"])
                raw = empirical.empirical_predictions(*current, positions[target], bank, 20, spread, shift)
                if phase == "later2026":
                    changed_rows = copy.deepcopy(previous_rows)
                    unavailable = ~stability.previous_bank_mask(previous_rows, masks[phase]["first"])
                    for i in np.flatnonzero(unavailable):
                        changed_rows[i].update(aa=np.nan, level=90.0)
                    changed_bank = runner.bank_from(previous, changed_rows, masks[phase]["first"])
                    repeated = empirical.empirical_predictions(
                        *current, positions[target], changed_bank, 20, spread, shift
                    )
                    if not np.array_equal(raw, repeated):
                        raise ValueError("Unavailable European shape formula calibration labels changed forecasts")
                    mutated_labels = int(unavailable.sum())
                for record in [
                    r
                    for r in active
                    if (r["spec"]["group"], r["spec"]["policy"], r["spec"]["spread"], r["spec"]["shift"])
                    == (group, policy, spread, shift)
                ]:
                    candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    if phase == "later2026":
                        alternate = candidate
                    elif measure(y[target], candidate) != record["periods"][phase]["metrics"]:
                        raise ValueError("European shape formula earlier score choices did not reconstruct")
                    reconstructed += 1
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("European shape formula final all-case identity differs")
            for field, metric in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[metric]:
                    raise ValueError("European shape formula final native metrics differ")
            h1, h0 = np.abs(f["alternate"] - y[target]) <= 7, np.abs(f["control"] - y[target]) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "candidateForecastsReconstructed": reconstructed,
            "unavailablePastCalibrationLabelsMutated": mutated_labels,
            "featureAuditVerified": True,
            "earlierSelectionVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            keep = np.array([r["cohort"] == cohort for r in source["rows"]])
            with np.load(args.cache / "stats.npz") as f:
                base = f["x"][keep]
            with np.load(args.cache / "match_context_features.npz") as f:
                match = f["x"][keep]
            with np.load(args.cache / "europe_shape_features.npz") as f:
                if str(f["key"]) != report["historyFeatureKey"]:
                    raise ValueError("European shape formula refit feature key differs")
                columns = conditioning.feature_groups(f["names"].tolist())[best["spec"]["group"]]
                x = np.column_stack((base, match, f["x"][keep][:, columns]))
            print(f"EUROPE_SHAPE_AUDIT_REFIT {cohort} {best['spec']['group']}", flush=True)
            evidence[cohort]["realRefitWithoutOutsideOutcomes"] = refit_without_outside_labels(
                x, rows, masks["later2026"], bundles[("later2026", best["spec"]["group"])]
            )
    output = {
        "scope": "Research-only independent native all-case/caches/freeze/score reconstruction, no fresh blind claim",
        "implementationKey": key,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
