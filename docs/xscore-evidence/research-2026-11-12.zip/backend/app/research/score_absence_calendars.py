"""Parse static federation calendars for schedule-only preview joins."""

import hashlib
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

from pypdf import PdfReader

DIRECTORY = Path("data/raw/score-foundation/suspension-source")


def normalize(s):
    plain = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub("[^a-z0-9]", "", plain.lower())


def parse(pages, club_names):
    keys = {}
    for home, h in club_names.items():
        for away, a in club_names.items():
            if h != a:
                keys.setdefault(normalize(home + away), set()).add((h, a))
    results, by_round = {}, {}
    for text in pages:
        current = None
        for line in text.splitlines():
            found = re.fullmatch(r"\s*Jornada (\d+) \(\d{2}/\d{2}/\d{4}\)\s*", line)
            if found:
                current = int(found[1])
                continue
            options = keys.get(normalize(line), ())
            if not options:
                continue
            if current is None or len(options) != 1:
                raise ValueError(f"Unknown round or ambiguous fixture: {line}")
            (pair,) = options
            if pair in results:
                raise ValueError("Repeated ordered club pair")
            results[pair] = current
            by_round.setdefault(current, []).extend(pair)
    assert len(results) == 380
    assert set(by_round) == set(range(1, 39))
    clubs = {p for pair in results for p in pair}
    assert len(clubs) == 20
    assert all(Counter(sides) == Counter(clubs) for sides in by_round.values())
    return results


def main():
    import pdfplumber

    manifest = json.loads((DIRECTORY / "calendar_manifest.json").read_text(encoding="utf-8-sig"))
    names = json.loads((DIRECTORY / "official_club_registry.json").read_text())
    report = {}
    for item in manifest:
        path = Path(item["file"])
        raw = path.read_bytes()
        assert raw.startswith(b"%PDF-") and hashlib.sha256(raw).hexdigest() == item["sha256"]
        season = path.stem.removeprefix("calendar_")
        reader = PdfReader(path)
        pairs = parse((page.extract_text() for page in reader.pages), names)
        with pdfplumber.open(path) as second:
            audited = parse((page.extract_text() for page in second.pages), names)
        if pairs != audited:
            raise ValueError("Calendar engines disagree")
        report[season] = dict(
            url=item["url"],
            sha256=item["sha256"],
            pages=len(reader.pages),
            independentEnginesAgree=True,
            pairs=[dict(home=h, away=a, round=n) for (h, a), n in sorted(pairs.items())],
        )
        print(season, len(pairs), "fixture rounds confirmed", flush=True)
    (DIRECTORY / "calendar_rounds.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
