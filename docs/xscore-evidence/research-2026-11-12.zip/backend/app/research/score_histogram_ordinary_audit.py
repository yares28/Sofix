"""Testing only: verify mixture training confirmation, native scores and real refits."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_flow as flow
from app.research import score_histogram_ordinary as mixture
from app.research import score_histogram_ordinary_run as runner
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import measure


def native_atom_checks(rows):
    aa = np.array([r["aa"] for r in rows], dtype=float)
    levels = np.array([r["level"] for r in rows], dtype=float)
    positions = np.array([r["pos"] for r in rows])
    checked = 0
    for width in (5, 10):
        edges = np.arange(-30, 60.01, width)
        labels = np.searchsorted(edges, aa, side="right")
        observed, _ = mixture.aa_bands(aa, width)
        if not np.array_equal(labels, observed):
            raise ValueError("Independent native AA band edges differ")
        for level in (0, 5, 15, 35, 60, 70, 80, 90, 100):
            native = np.clip(aa + level, 0, 100)
            if level >= 60:
                native = np.maximum(native, level)
            for position in ("GK", "DEF", "MID", "FWD"):
                for band in np.unique(labels):
                    base = (positions == position) & (labels == band)
                    if not base.any():
                        base = labels == band
                    expected = (np.abs(native[base, None] - modal.CENTRES) <= 7).mean(axis=0)
                    specific = (positions == position) & (levels == level) & (labels == band)
                    n = int(specific.sum())
                    if n:
                        extra = (np.abs(native[specific, None] - modal.CENTRES) <= 7).mean(axis=0)
                        expected = (n * extra + 20 * expected) / (n + 20)
                    actual = mixture.conditional_band_mass(aa, levels, positions, labels, position, level, band)
                    if not np.allclose(actual, expected, atol=1e-14, rtol=0):
                        raise ValueError("Independent native AA band shape/floor/cap differs")
                    checked += 1
    return {
        "nativeAALabelsNumericallyChecked": len(aa),
        "nativeAtomCurvesChecked": checked,
        "scope": "Numerical checks only, no forecast accuracy claimed",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda n: json.loads((args.report.parent / (n + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Mixture audit source identity differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Mixture audit match feature identity differs")
        all_x = np.column_stack((base, f["x"]))
    modules = (mixture, flow, matched, controls, modal, ordinary, stability, windows)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
            + np.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Mixture audit formula fingerprint differs")
    atom_evidence = native_atom_checks(source["rows"])
    evidence = {}
    for cohort, result in report["cohorts"].items():
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        x = all_x[keep]
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        aa, levels, y = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        selection_path = args.report.with_name(args.report.stem + f".{cohort}.selection120.json")
        frozen, selection = (json.loads(p.read_text()) for p in (frozen_path, selection_path))
        initial_winner, initial_best = stability.choose_stable(frozen["candidates120"])
        confirmed = frozen["best"]
        if (
            frozen["implementationKey"] != key
            or selection["implementationKey"] != key
            or initial_winner != frozen["initialWinner120"]
            or initial_best != frozen["initialBest120"]
            or initial_best != selection["best"]
            or initial_winner != selection["winner"]
            or selection["candidates"] != frozen["candidates120"]
            or confirmed["spec"] != initial_best["spec"]
            or (min(confirmed["gains"]) > 0) != (frozen["winner"] is not None)
            or (frozen["winner"] is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Mixture audit initial/fixed-confirmed selection differs")
        caches, reconstructed = 0, 0
        for phase, _, _ in stability.PHASES[1:]:
            fit, target = masks[phase]["fit"], masks[phase]["target"]
            old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Mixture audit strongest control differs")
            train = mixture.design(x[fit], positions[fit], levels[fit])
            active = (
                [(confirmed, 240)]
                if phase == "later2026"
                else [(r, 120) for r in frozen["candidates120"]] + [(confirmed, 240)]
            )
            grouped = sorted({(r["spec"]["model"], iterations) for r, iterations in active})
            for model, iterations in grouped:
                labels, edges = mixture.aa_bands(aa[fit], mixture.SETTINGS[model]["width"])
                data_key = hashlib.sha256(train.tobytes() + labels.tobytes() + aa[fit].tobytes()).hexdigest()
                bins = np.unique(labels)
                with np.load(args.cache / f"{args.report.stem}_{cohort}_{phase}_{model}_e{iterations}.npz") as f:
                    mass, stats = f["mass"], json.loads(str(f["statistics"]))
                    if (
                        str(f["key"]) != key
                        or not np.array_equal(f["classes"], old[0])
                        or not np.array_equal(f["probability"], old[1])
                        or stats["iterations"] != iterations
                        or stats["settings"] != mixture.SETTINGS[model]
                        or stats["fitCases"] != int(fit.sum())
                        or stats["targetCases"] != int(target.sum())
                        or stats["fitDesignAndLabelsSha256"] != data_key
                        or stats["bandEdges"] != edges.tolist()
                        or stats["observedBands"] != bins.tolist()
                        or stats["bandFitCounts"] != {str(b): int((labels == b).sum()) for b in bins}
                        or stats["constantBand"] != (len(bins) == 1)
                        or stats["fittedIterations"] != (0 if len(bins) == 1 else iterations)
                        or not stats["eventProbabilitiesUnchanged"]
                        or mass.shape != (int(target.sum()), 201)
                        or not np.isfinite(mass).all()
                        or (mass < 0).any()
                        or (mass > 1 + 1e-12).any()
                    ):
                        raise ValueError("Mixture audit cached training/mass/feature/event identity differs")
                caches += 1
                raw = windows.window_centres(mass, modal.CENTRES)
                for record, _record_iterations in [
                    a for a in active if a[0]["spec"]["model"] == model and a[1] == iterations
                ]:
                    forecast = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    if phase == "later2026":
                        alternate = forecast
                        final_mass = mass
                        final_stats = stats
                    elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                        raise ValueError("Mixture audit earlier forecast metric differs")
                    reconstructed += 1
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Mixture audit native final all-case score identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Mixture audit native final metric differs")
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "massCachesVerified": caches,
            "candidateForecastsReconstructed": reconstructed,
            "fixedLongerTrainingConfirmationVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            aa[~fit] = np.nan
            levels[~fit] = np.nan
            print(f"HISTOGRAM_AA_AUDIT_REFIT {cohort} {confirmed['spec']['model']}", flush=True)
            repeated, stats = mixture.fit_forecasts(
                x, aa, levels, positions, fit, target, old[0], old[1], mixture.SETTINGS[confirmed["spec"]["model"]], 240
            )
            if not np.array_equal(repeated, final_mass) or stats != final_stats:
                raise ValueError("Mixture actual final refit changes when outside-fit AA/DS blanked")
            evidence[cohort]["realRefitAfterOutsideFitLabelsBlanked"] = {
                "outsideFitAAandDSRowsBlanked": int((~fit).sum()),
                "all201MassesAndExactWeightsReproduced": True,
            }
    output = {
        "scope": "Testing-only full native audit; exploratory reuse not fresh blind proof",
        "implementationKey": key,
        "nativeAtomChecks": atom_evidence,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
