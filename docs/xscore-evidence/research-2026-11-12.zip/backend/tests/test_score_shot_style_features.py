import numpy as np

from app.research import score_shot_style_features as style


def shot(body="Header", sit="Open Play", x=90, y=50):
    return dict(body=body, sit=sit, x=x, y=y)


def test_profiles_preserve_missing_zero_explicit_penalties_and_unknown_mass():
    assert not style.profile(None, False)["known"]
    empty = style.profile([], True)
    assert empty["known"] and empty["nonpen"] == 0 and empty["body"] == [0, 0, 0]
    p = style.profile([shot(), shot("Unknown"), shot("Left Foot", "Penalty"), shot("Right Foot", x=100.2)], True)
    assert p["attempts"] == 4 and p["nonpen"] == 3
    assert p["body"] == [1, 0, 1] and p["unknownBody"] == 1
    assert p["zones"] == [2, 0] and p["unknownZone"] == 1


def test_conceded_shots_use_attacking_frame_without_opponent_mirroring():
    p = style.profile([shot(x=90, y=50), shot(x=70, y=50)], True)
    assert p["zones"] == [1, 1]


def test_lift_rewards_matching_style_without_inventing_cold_or_missing_style():
    prior = np.array([0.3, 0.35, 0.35])
    head = style.style_lift([1, 0, 0], [12, 1, 1], prior)
    foot = style.style_lift([0, 0, 1], [12, 1, 1], prior)
    assert head > 1 and foot < 1
    assert np.isnan(style.style_lift([np.nan] * 3, [12, 1, 1], prior))
    assert np.isnan(style.style_lift([1, 0, 0], [0, 0, 0], prior))
    assert np.isnan(style.style_lift([1, 0, 0], [12, 1, 1], [0, 0.5, 0.5]))


def test_fixed_feature_schema_has46unique_columns():
    names = style.feature_names()
    assert len(names) == len(set(names)) == 46


def source_fixture(middle_date="2025-12-28T12:00:00Z"):
    dates = ["2025-12-10T12:00:00Z", middle_date, "2026-01-03T12:00:00Z"]
    rows = [dict(game=f"g{i}", player="p", date=d, minutes=90, cohort="start") for i, d in enumerate(dates)]
    games = {
        f"g{i}": dict(
            id=f"g{i}", date=d, home=dict(slug="A"), away=dict(slug="B"), players=dict(p=dict(team="A", stats={}))
        )
        for i, d in enumerate(dates)
    }
    a = [shot()] * 8 + [shot("Left Foot"), shot("Right Foot")]
    b = [shot(), shot("Left Foot")] + [shot("Right Foot")] * 5
    sides = [
        dict(
            game=f"g{i}",
            date=d,
            club=club,
            opponent="B" if club == "A" else "A",
            profile=style.profile(a if club == "A" else b, not (i == 1 and club == "A")),
        )
        for i, d in enumerate(dates)
        for club in ("A", "B")
    ]
    people = [
        dict(
            game=f"g{i}",
            date=d,
            player="p",
            club="A",
            cohort="start",
            minutes=90,
            profile=style.profile([shot()], i != 1),
        )
        for i, d in enumerate(dates)
    ]
    return rows, games, sides, people


def test_complete_workflow_keeps_cold_rows_native_gaps_and_actual_opponent_identity():
    args = source_fixture()
    x, names = style.build_features(*args)
    assert x.shape == (3, 46)
    assert x[0, names.index("shotstyle_player_native_games")] == 0
    assert np.isnan(x[0, names.index("shotstyle_match_body_lift")])
    assert x[-1, names.index("shotstyle_player_native_games")] == 2
    assert x[-1, names.index("shotstyle_player_known_games")] == 1
    assert x[-1, names.index("shotstyle_opponent_known_games")] == 1
    assert x[-1, names.index("shotstyle_opponent_header_fraction")] == 0.8
    assert x[-1, names.index("shotstyle_match_body_lift")] > 1


def test_exact48h_is_unavailable_and_current_outcomes_profiles_minutes_do_not_leak():
    from copy import deepcopy

    args = source_fixture("2025-12-31T14:00:00Z")
    x, names = style.build_features(*args)
    assert x[-1, names.index("shotstyle_player_native_games")] == 1
    changed = deepcopy(args)
    changed[0][-1]["minutes"] = 10000
    changed[1]["g2"]["players"]["p"]["stats"] = {"goals": [99, 0], "goal_assist": [99, 0]}
    changed[2][-1]["profile"] = style.profile([shot("Left Foot")] * 50, True)
    changed[3][-1]["profile"] = style.profile([shot("Right Foot")] * 40, True)
    altered, _ = style.build_features(*changed)
    np.testing.assert_array_equal(altered, x)


def test_independent_all46_columns_match_on_native_source_gaps():
    from app.research.score_shot_style_audit import reconstruct

    rows, games, sides, people = source_fixture()
    expected, _ = style.build_features(rows, games, sides, people)
    actual = reconstruct(
        rows, games, {(r["game"], r["club"]): r for r in sides}, {(r["game"], r["player"]): r for r in people}
    )
    np.testing.assert_allclose(expected, actual, rtol=0, atol=1e-12, equal_nan=True)
