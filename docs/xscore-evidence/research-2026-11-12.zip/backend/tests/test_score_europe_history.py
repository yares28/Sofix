import numpy as np
import pytest

from app.research.score_europe_history import europe_features
from tests.test_score_search import game


def test_same_week_or_future_european_minutes_are_not_known_before_lock():
    target = game("2025-10-12T20:00:00Z", 40)
    rows = [{"player": "player", "game": "a", "date": target["date"]}]
    earlier = {
        "id": "e1",
        "date": "2025-10-01T20:00:00Z",
        "home": "home",
        "away": "other",
        "complete": True,
        "players": {"player": {"minutes": 90, "score": 0, "started": True}},
    }
    late = {
        "id": "e2",
        "date": "2025-10-08T20:00:00Z",
        "home": "home",
        "away": "other",
        "complete": True,
        "players": {"player": {"minutes": 80, "score": 90, "started": True}},
    }
    x, names = europe_features(rows, [target], [earlier, late])
    assert x[0, names.index("euro_minutes_14")] == 90
    assert x[0, names.index("euro_last_score")] == 0


def test_outside_archive_window_is_missing_not_zero():
    target = game("2026-10-12T20:00:00Z", 40)
    x, names = europe_features([{"player": "player", "game": "a", "date": target["date"]}], [target], [])
    assert x[0, names.index("euro_coverage")] == 0
    assert np.isnan(x[0, names.index("euro_minutes_14")])


def test_incomplete_recent_team_game_does_not_become_zero_workload():
    target = game("2025-10-12T20:00:00Z", 40)
    event = {
        "id": "e",
        "date": "2025-10-01T20:00:00Z",
        "home": "home",
        "away": "other",
        "complete": False,
        "players": {},
    }
    x, names = europe_features([{"player": "player", "game": "a", "date": target["date"]}], [target], [event])
    assert x[0, names.index("euro_complete_recent_team_games")] == 0
    assert np.isnan(x[0, names.index("euro_minutes_14")])


def test_quicker_workload_assumption_does_not_make_unsettled_score_available():
    target = game("2025-10-12T20:00:00Z", 40)
    event = {
        "id": "e",
        "date": "2025-10-08T20:00:00Z",
        "home": "home",
        "away": "other",
        "complete": True,
        "players": {"player": {"minutes": 80, "score": 90, "started": True}},
    }
    x, names = europe_features(
        [{"player": "player", "game": "a", "date": target["date"]}], [target], [event], workload_hours=3
    )
    assert x[0, names.index("euro_minutes_14")] == 80
    assert np.isnan(x[0, names.index("euro_last_score")])
    assert np.isnan(x[0, names.index("euro_recent_score_mean")])


def test_backwards_rows_cannot_consume_future_history():
    first = game("2025-10-12T20:00:00Z", 40)
    earlier = {**first, "id": "b", "date": "2025-09-12T20:00:00Z"}
    rows = [{"player": "player", "game": g["id"], "date": g["date"]} for g in (first, earlier)]
    with pytest.raises(ValueError, match="chronological"):
        europe_features(rows, [first, earlier], [])
