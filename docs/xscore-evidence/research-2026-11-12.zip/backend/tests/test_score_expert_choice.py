import numpy as np

from app.research.score_expert_choice import choose_expert, expert_history


def test_choice_returns_one_whole_forecast_with_control_fallback():
    forecasts = np.array([[40, 80, 55], [40, 80, 55], [40, 80, 55]])
    gain = np.array([[-0.1, -0.2], [0.2, -0.1], [-0.1, 0.3]])
    pred, selected = choose_expert(forecasts, gain, 0)
    np.testing.assert_array_equal(pred, [40, 80, 55])
    np.testing.assert_array_equal(selected, [0, 1, 2])


def test_expert_history_uses_only_available_previous_results():
    rows = [
        {"date": d, "player": "p", "score": s}
        for d, s in [("2025-10-01T20:00:00Z", 40), ("2025-10-11T20:00:00Z", 80), ("2025-10-12T20:00:00Z", 50)]
    ]
    forecasts = np.array([[40, 80], [40, 80], [40, 80]])
    before = expert_history(rows, forecasts)
    rows[1]["score"] = 0
    rows[2]["score"] = 0
    after = expert_history(rows, forecasts)
    np.testing.assert_array_equal(before[-1], after[-1])
    assert before[-1, 0] == 1
    assert before[-1, 1] == 1
    assert before[-1, 2] == 0


def test_unknown_history_is_missing_and_observed_zero_error_is_zero():
    rows = [{"date": d, "player": "p", "score": 40} for d in ("2025-10-01T20:00:00Z", "2025-10-12T20:00:00Z")]
    x = expert_history(rows, np.full((2, 1), 40.0))
    assert x[0, 0] == 0
    assert np.isnan(x[0, 1])
    assert x[1, 2] == 0
