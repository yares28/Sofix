"""Testing only: ordinary-point models without decisive-label inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_unconditional_ordinary as unconditional
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def fitted(x, aa, positions, mask, old, mode, path, key):
    if path.exists():
        pieces = components(path, key)
        with np.load(path) as f:
            stats = json.loads(str(f["statistics"]))
        if not np.array_equal(pieces[0], old[0]) or not np.array_equal(pieces[1], old[1]):
            raise ValueError("Unconditional AA changed original class probabilities")
        return pieces, stats
    quantiles, stats = unconditional.fit_quantiles(x, aa, positions, mask["fit"], mask["target"], old[0], mode)
    np.savez_compressed(
        path,
        key=key,
        classes=old[0],
        probability=old[1],
        statistics=json.dumps(stats),
        **{f"q{q}": value for q, value in quantiles.items()},
    )
    return (old[0], old[1], quantiles), stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Unconditional AA study source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
        matched.validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Unconditional AA study fixture features differ")
        all_x = np.column_stack((base, f["x"]))
    if all_x.shape != (len(source["rows"]), 677):
        raise ValueError("Unconditional AA study input coverage differs")
    modules = (unconditional, empirical, flow, matched, controls, ordinary, stability)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    report = {
        "scope": "Testing only, unconditional AA, no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated historical reuse, exploratory not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        previous_report = json.loads(args.out.read_text())
        if previous_report["implementationKey"] == key:
            report = previous_report
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        x = all_x[keep]
        aa, y, positions = (
            np.array([r["aa"] for r in rows]),
            np.array([r["score"] for r in rows]),
            np.array([r["pos"] for r in rows]),
        )
        masks = stability.phase_masks(rows)
        records = [
            {
                "spec": {"model": mode, "spread": spread, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for mode in ("pooled", "position")
            for spread in (0.75, 1, 1.25)
            for scope in ("all", "defmid")
        ]
        previous, winner, best, audit = None, None, None, {}
        for phase, _, _ in stability.PHASES:
            target = masks[phase]["target"]
            current_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "later2026" and best is None:
                raise ValueError("Unconditional AA choice must freeze before final outcomes")
            active = [best] if phase == "later2026" else records
            current = {}
            audit[phase] = {"fit": int(masks[phase]["fit"].sum()), "target": int(target.sum()), "models": {}}
            for mode in sorted({r["spec"]["model"] for r in active}):
                print(f"UNCONDITIONAL_FITTING {cohort} {phase} {mode}", flush=True)
                current[mode], stats = fitted(
                    x,
                    aa,
                    positions,
                    masks[phase],
                    old,
                    mode,
                    args.cache / f"{args.out.stem}_{cohort}_{phase}_{mode}.npz",
                    key,
                )
                audit[phase]["models"][mode] = stats
            if previous is None:
                previous = current_rows, current
                continue
            previous_rows, previous_parts = previous
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Unconditional AA strongest control differs")
            audit[phase]["control"] = expected
            for mode in sorted(current):
                bank = matched.bank_from(previous_parts[mode], previous_rows, masks[phase]["first"])
                audit[phase]["models"][mode]["bankCases"] = bank["cases"]
                audit[phase]["models"][mode]["unknownBankClassLabels"] = bank["unknownLevels"]
                for spread in sorted({r["spec"]["spread"] for r in active if r["spec"]["model"] == mode}):
                    raw = empirical.empirical_predictions(*current[mode], positions[target], bank, 20, spread, 0)
                    for record in [r for r in active if r["spec"]["model"] == mode and r["spec"]["spread"] == spread]:
                        candidate = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                        measured = measure(y[target], candidate)
                        if phase == "later2026":
                            alternate = candidate
                        else:
                            gain = measured["within7"] - expected["within7"]
                            record["gains"].append(gain)
                            record["errors"].append(measured["mae"])
                            record["counts"].append(len(candidate))
                            record["periods"][phase] = {"gain": gain, "metrics": measured}
                    print(f"UNCONDITIONAL_TESTED {cohort} {phase} {mode} spread{spread}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
                    json.dumps(
                        {
                            "implementationKey": key,
                            "winner": winner,
                            "best": best,
                            "candidates": records,
                            "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                        },
                        indent=2,
                    )
                )
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            previous = current_rows, current
        prediction = alternate if winner else control.copy()
        h0, h1 = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": expected,
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(y[target], alternate, control, [r["week"] for r in current_rows]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
