"""Local coverage ceiling for four historical absence previews."""

import hashlib
import json
import re
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for

ROOT = Path("data/raw/score-foundation")
NATIVE = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
NATIVE_SHA = "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
# Round windows checked against LaLiga's official round pages. The native data
# ends on 25 October 2026, before the last fixture of that round.
ROUNDS = {
    "ser_2025_26_round01.html": ("2025-26", 1, "2025-08-15", "2025-08-19", 10),
    "ser_2025_26_round10.html": ("2025-26", 10, "2025-10-24", "2025-10-27", 10),
    "ser_2025_26_round20.html": ("2025-26", 20, "2026-01-16", "2026-01-19", 10),
    "ser_2026_27_round10.html": ("2026-27", 10, "2026-10-23", "2026-10-26", 9),
}


class ArticleMeta(HTMLParser):
    def __init__(self):
        super().__init__()
        self.clocks = {}
        self.canonical = None

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        kind = values.get("property")
        if tag == "meta" and kind in ("article:published_time", "article:modified_time"):
            if kind in self.clocks:
                raise ValueError(f"Duplicate article clock: {kind}")
            self.clocks[kind] = datetime.fromisoformat(values["content"])
        if tag == "link" and values.get("rel") == "canonical":
            self.canonical = values["href"]


def available_clock(text):
    meta = ArticleMeta()
    meta.feed(text)
    for name, og in (("datePublished", "article:published_time"), ("dateModified", "article:modified_time")):
        (other,) = set(re.findall(rf'"{name}"\s*:\s*"([^"]+)"', text))
        x, y = datetime.fromisoformat(other), meta.clocks[og]
        if x.tzinfo is None or y.tzinfo is None or abs((x - y).total_seconds()) >= 1:
            raise ValueError(f"Article clocks disagree: {name}")
    published, modified = (meta.clocks[n] for n in ("article:published_time", "article:modified_time"))
    if modified < published or not meta.canonical:
        raise ValueError("Invalid page identity or revision clock")
    return meta.canonical, published, modified


def main():
    raw = NATIVE.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Unexpected native data")
    games = [json.loads(line) for line in raw.splitlines()]
    rows = json.loads((ROOT / "cases.json").read_text())["rows"]
    directory = ROOT / "suspension-source"
    manifest = json.loads((directory / "pilot_representative_manifest.json").read_text(encoding="utf-8-sig"))
    files = {Path(r["file"]).name: r for r in manifest}
    covered = set()
    report = dict(
        scope="Page clock and optimistic coverage only. No player absence features, model fits or scores predicted.",
        nativeSHA=NATIVE_SHA,
        previousGoalTurnClassification="progress: six opposition fits reconstructed and evaluated; route retired",
        articles={},
    )
    for name, (season, round_no, begin, end, expected_games) in ROUNDS.items():
        path = directory / name
        item = files[name]
        assert item["status"] == 200 and hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"]
        canonical, published, modified = available_clock(path.read_text(encoding="utf-8"))
        assert canonical.rstrip("/") == item["url"].rstrip("/")
        fixtures = [g for g in games if begin <= g["date"][:10] <= end]
        sides = [g[side]["slug"] for g in fixtures for side in ("home", "away")]
        assert len(fixtures) == expected_games and len(set(sides)) == 2 * expected_games
        before = [g for g in fixtures if modified < cutoff_for(g["date"])]
        assert all(g["id"] not in covered for g in before)
        covered.update(g["id"] for g in before)
        report["articles"][name] = dict(
            canonical=canonical,
            sha256=item["sha256"],
            schedule=f"https://www.laliga.com/laliga-easports/resultados/{season}/jornada-{round_no}",
            published=published.isoformat(),
            modified=modified.isoformat(),
            nativeFixtures=len(fixtures),
            revisionStrictlyBeforeInferredLock=len(before),
            firstLock=min(cutoff_for(g["date"]) for g in fixtures).isoformat(),
            eligibleFixtureIds=[g["id"] for g in before],
        )
    report["earlierCasesOnEligibleFixtures"] = {
        c: sum(r["cohort"] == c and r["date"] < "2026-01-01" and r["game"] in covered for r in rows)
        for c in ("start", "bench")
    }
    report["laterCoverageCeiling"] = coverage_ceiling(rows, covered)
    report["evidenceLimit"] = (
        "Publisher clocks support reconstructed availability, not archived receipt. The bound grants perfect fixes "
        "on every page-clock-eligible match while fixing all other forecasts in place. It overstates usable coverage "
        "because individual club claims, reported absences and identity mappings have not yet been validated."
    )
    out = Path("reports/experiments/laliga_score_absence_clock_pilot.json")
    out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


def coverage_ceiling(rows, covered):
    result = {}
    for cohort, stem, key, n, hits in (
        ("start", "team_share", "d66dd32e242a419580610b05ab06eea8dd29c873c76a7d30cd9bb0a374f3190a", 6754, 2765),
        ("bench", "mixture_shrunk", "04f46a9b7f9709260ec765b80c00701db41a8bc3078d7684c6c1557f33a7f610", 2925, 2201),
    ):
        selected = [r for r in rows if r["cohort"] == cohort and r["date"] >= "2026-01-01"]
        assert len(selected) == n
        with np.load(ROOT / f"laliga_score_{stem}_predictions_{cohort}.npz") as z:
            assert str(z["key"]) == key
            np.testing.assert_array_equal(z["y"], [r["score"] for r in selected])
            hit = np.abs(z["prediction"] - z["y"]) <= 7
            assert hit.sum() == hits
        present = np.array([r["game"] in covered for r in selected])
        misses = int(np.sum(~hit & present))
        result[cohort] = dict(
            allCases=n,
            bestExistingHits=hits,
            casesOnEligibleFixtures=int(present.sum()),
            existingMissesOnEligibleFixtures=misses,
            perfectOnlyOnTheseFixturesHits=hits + misses,
            perfectOnlyOnTheseFixturesPct=100 * (hits + misses) / n,
        )
    return result


if __name__ == "__main__":
    main()
