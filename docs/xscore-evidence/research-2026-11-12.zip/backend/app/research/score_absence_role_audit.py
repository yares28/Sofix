"""Independent native time and name audit, then evaluate autumn minutes."""

import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from datetime import UTC, datetime, timedelta

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT, STEM, evaluate


def lock_time(iso):
    at = datetime.fromisoformat(iso).astimezone(UTC)
    lock = at.replace(hour=14, minute=0, second=0, microsecond=0)
    while lock > at or lock.weekday() not in (1, 4):
        lock -= timedelta(days=1)
    return lock


def ascii_tokens(name):
    return re.findall(r"[a-z0-9]+", unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower())


def independent_identity(label, pool):
    query = ascii_tokens(label)
    exact = " ".join(query)
    can_match_partial = len(query) > 1 and min(map(len, query)) > 1
    matches = []
    for identity in pool:
        name = " ".join(ascii_tokens(identity))
        if name == exact or (can_match_partial and f" {exact} " in f" {name} "):
            matches.append(identity)
    return matches[0] if len(matches) == 1 else None


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, raw.splitlines()), key=lambda g: (g["date"], g["id"]))
    index = {g["id"]: g for g in games}
    kickoff = {g["id"]: datetime.fromisoformat(g["date"]).astimezone(UTC) for g in games}
    known_after = {i: t + timedelta(days=2) for i, t in kickoff.items()}
    locks = {i: lock_time(g["date"]) for i, g in index.items()}
    by_club, by_person, own_prior = defaultdict(list), defaultdict(list), defaultdict(list)
    for g in games:
        i = g["id"]
        for side in ("home", "away"):
            by_club[g[side]["slug"]].append(i)
        for person, sheet in g["players"].items():
            if sheet["played"] is True and sheet["ver"] == 7:
                by_person[person].append((i, sheet))
                group = person, sheet["team"], sheet["pos"], "start" if sheet["started"] else "bench"
                own_prior[group].append((i, sheet["mins"]))
    source = json.loads((ROOT / "cases.json").read_text())
    forecast = json.loads((REPORTS / f"{STEM}.forecasts.json").read_text())
    claims_raw = (REPORTS / "laliga_score_absence_claims_pilot.json").read_bytes()
    assert hashlib.sha256(claims_raw).hexdigest() == forecast["claimReportSHA"]
    claims = json.loads(claims_raw)
    coverage_raw = (REPORTS / "laliga_score_absence_archive_coverage.json").read_bytes()
    assert hashlib.sha256(coverage_raw).hexdigest() == claims["coverageReportSHA"]
    revisions = {
        i: datetime.fromisoformat(a["revision"])
        for a in json.loads(coverage_raw)["articles"]
        for i in a["eligibleGames"]
    }
    absent, checked, seen = {}, 0, set()
    for r in claims["sourceClaims"]:
        game_id, club = r["game"], r["club"]
        key = game_id, club
        assert key not in seen
        seen.add(key)
        assert index[game_id][r["side"]]["slug"] == club and index[game_id]["date"] == r["date"]
        lock = locks[game_id]
        assert revisions[game_id] < lock <= kickoff[game_id] and kickoff[game_id] - revisions[game_id] <= timedelta(
            days=7
        )
        history = [i for i in by_club[club] if known_after[i] < lock]
        recent_ids = history[-3:]
        pool = {
            person
            for i in history
            if lock - kickoff[i] <= timedelta(days=365)
            for person, sheet in index[i]["players"].items()
            if sheet["played"] is True and sheet["ver"] == 7 and sheet["team"] == club
        }
        linked = {}
        for label, mentions in r["mentions"].items():
            for entry in mentions:
                name = independent_identity(entry["mention"], pool)
                assert name == entry["player"]
                spent = [index[i]["players"].get(name, {}) for i in recent_ids]
                total = sum(p["mins"] for p in spent if p.get("played") is True and p["team"] == club)
                projected = total / len(recent_ids) if recent_ids else 0
                np.testing.assert_allclose(projected, entry["projectedPriorMinutes"], rtol=0, atol=1e-12)
                checked += 1
                if name and label in ("lesionados", "sancionados"):
                    linked[name] = projected
        if "2025-07-01" <= r["date"] < "2026-01-01":
            absent[key] = linked
    assert len(seen) == 728
    assert checked == sum(
        claims["statistics"][k] for k in ("lesionadosMentions", "sancionadosMentions", "dudasMentions")
    )
    proofs = {(p["game"], p["player"]): p for p in forecast["changes"]}
    home_idx = source["features"].index("home")
    cold = {c: source["features"].index(c + "_3_minutes") for c in ("start", "bench")}
    with np.load(ROOT / f"{STEM}.npz") as z:
        assert str(z["key"]) == forecast["implementationKey"]
        target, full = z["autumn_target"], z["full_forecasts"]
    expected, nonzero, prior_contributions = [], 0, 0
    for r in source["rows"]:
        i, subject, cohort, pos = (r[k] for k in ("game", "player", "cohort", "pos"))
        club = index[i]["home" if r["x"][home_idx] else "away"]["slug"]
        eligible = [
            (p, m)
            for p, m in own_prior[subject, club, pos, cohort]
            if known_after[p] < locks[i] and locks[i] - kickoff[p] <= timedelta(days=365)
        ][-30:]
        base = np.clip(np.mean([m for _, m in eligible]) if eligible else r["x"][cold[cohort]], 0, 100)
        new, support = base, 0
        names = absent.get((i, club), {})
        if subject not in names:
            candidates = []
            for name, minutes in names.items():
                history = [(p, s) for p, s in by_person[name] if known_after[p] < locks[i]]
                if minutes >= 15 and history and (history[-1][1]["team"], history[-1][1]["pos"]) == (club, pos):
                    candidates.append((name, minutes))
            if candidates:
                peer, _ = sorted(candidates, key=lambda p: (-p[1], p[0]))[0]
                p0 = min(known_after[p] for p, s in by_person[peer] if s["team"] == club)
                before, after = [], []
                for p, m in eligible:
                    if p0 < locks[p]:
                        group = after if index[p]["players"].get(peer, {}).get("played") is True else before
                        group.append((p, m))
                support = min(len(before), len(after))
                if support >= 2:
                    difference = (
                        (np.mean([m for _, m in before]) - np.mean([m for _, m in after])) * support / (support + 8)
                    )
                    new = np.clip(base + difference, 0, 100)
                    if base != new:
                        proof = proofs[i, subject]
                        assert proof["peer"] == peer
                        assert proof["missing"] == [list(v) for v in before]
                        assert proof["present"] == [list(v) for v in after]
                        prior_contributions += len(before) + len(after)
                        nonzero += 1
        expected.append((base, new, support))
    assert nonzero == len(proofs)
    np.testing.assert_allclose(expected, full, rtol=0, atol=2e-14)
    np.testing.assert_array_equal(target, ["2025-07-01" <= r["date"] < "2026-01-01" for r in source["rows"]])
    autumn = [r for r, yes in zip(source["rows"], target, strict=True) if yes]
    actual = np.array([index[r["game"]]["players"][r["player"]]["mins"] for r in autumn])
    np.testing.assert_array_equal(actual, [r["minutes"] for r in autumn])
    result = dict(
        implementationKey=forecast["implementationKey"],
        provisionalNameDecisionsRebuilt=checked,
        sourceSideRowsRebuilt=len(seen),
        forecastRowsRebuilt=len(expected),
        nonzeroCasesRebuilt=nonzero,
        historicalContributionsRebuilt=prior_contributions,
        modelFitOrScoreEvaluation=False,
        laterOutcomesEvaluated=False,
        autumn=evaluate(actual, full[target], autumn),
    )
    (REPORTS / f"{STEM}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
