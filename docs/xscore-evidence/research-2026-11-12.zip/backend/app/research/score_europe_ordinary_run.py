"""Testing only: native European ordinary histories added to the strongest score model."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_europe_ordinary as europe
from app.research import score_flow as flow
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def feature_groups(names):
    return {
        "ordinary": np.array(
            ["_aa" in n or n.endswith(("_retained_games", "_last_days", "_minutes_mean")) for n in names]
        ),
        "all": np.ones(len(names), dtype=bool),
    }


def component_policy(old, new, policy):
    if not np.array_equal(old[0], new[0]):
        raise ValueError("Old/new decisive classes differ")
    if policy == "both":
        return new
    if policy == "ordinary":
        return new[0], old[1], new[2]
    if policy == "events":
        return new[0], new[1], old[2]
    raise ValueError("Unknown component policy")


def validate_stat_identity(stat_key, match_report, player_report):
    if stat_key != match_report["statKey"]:
        raise ValueError("Raw stat feature identity differs")
    combined = hashlib.sha256((stat_key + match_report["featureKey"]).encode()).hexdigest()
    if player_report["statKey"] != combined:
        raise ValueError("Combined stat/team feature identity differs")


def fitted(x, aa, levels, mask, path, key):
    if path.exists():
        return components(path, key)
    classes, probability, parts = conditional.conditional_components(x, aa, levels, mask["fit"], mask["target"])
    np.savez_compressed(
        path, key=key, classes=classes, probability=probability, **{f"q{q}": a for q, a in parts.items()}
    )
    return classes, probability, parts


def bank_from(parts, previous_rows, first):
    return empirical.fit_bank(
        parts[0],
        parts[2],
        np.array([r["aa"] for r in previous_rows]),
        np.array([r["level"] for r in previous_rows]),
        np.array([r["pos"] for r in previous_rows]),
        stability.previous_bank_mask(previous_rows, first),
        "raw",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "cases",
        "stats-cache",
        "match-cache",
        "history-cache",
        "history-report",
        "cache",
        "packages",
        "out",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    history_report = json.loads(args.history_report.read_text())
    feature_audit = json.loads(args.history_report.with_suffix(".integrity.json").read_text())
    if (
        feature_audit["featureKey"] != history_report["featureKey"]
        or feature_audit["independentFeatureRowsReconstructed"] != len(source["rows"])
        or not feature_audit["all6754Starts2925BenchRetained"]
    ):
        raise ValueError("European native-history feature audit missing or different")
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    if history_report["featureKey"] not in plan["featureStage"]:
        raise ValueError("European native-history inputs differ from registered plan")
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench, history_report)
    ):
        raise ValueError("History evaluation source cases differ")
    with np.load(args.stats_cache) as stored:
        base, stat_key = stored["x"], str(stored["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.match_cache) as stored:
        match = stored["x"]
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Team feature identity differs")
    with np.load(args.history_cache) as stored:
        historys, history_names, history_key = stored["x"], stored["names"].tolist(), str(stored["key"])
        if history_key != history_report["featureKey"] or len(historys) != len(source["rows"]):
            raise ValueError("Chance-history feature identity differs")
    if history_names != list(europe.NAMES):
        raise ValueError("European native-history feature names differ")
    groups = feature_groups(history_names)
    files = [
        Path(__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        Path(conditional.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + history_key
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "historyFeatureKey": history_key,
        "historyCoverage": history_report["laterCoverage"],
        "featureAuditVerified": True,
        "cohorts": {},
    }
    if args.out.exists():
        previous = json.loads(args.out.read_text())
        if previous.get("implementationKey") == key:
            report = previous
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        aa, levels, y = (np.array([r[n] for r in rows]) for n in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        full = np.column_stack((base[keep], match[keep]))
        inputs = {g: np.column_stack((full, historys[keep][:, select])) for g, select in groups.items()}
        records = [
            {
                "spec": {"group": group, "policy": policy, "spread": spread, "shift": shift, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for group in groups
            for policy in ("both", "ordinary", "events")
            for spread in (0.75, 1)
            for shift in (0,)
            for scope in ("all", "defmid")
        ]
        prior, winner, best = None, None, None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "later2026" and best is None:
                raise ValueError("Candidate must be frozen before later outcomes")
            active = [best] if phase == "later2026" else records
            current = {}
            for group in sorted({r["spec"]["group"] for r in active}):
                print(f"FITTING {cohort} {phase} {group} inputs{inputs[group].shape[1]}", flush=True)
                current[group] = fitted(
                    inputs[group], aa, levels, mask, args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}.npz", key
                )
            audit[phase] = {"fit": int(mask["fit"].sum()), "target": int(target.sum())}
            if prior is None:
                prior = (target_rows, old, current)
                continue
            previous_rows, previous_old, previous_new = prior
            if cohort == "start":
                control_parts = stability.starter_control(previous_old, old, previous_rows, mask["first"])
                control = empirical.empirical_predictions(
                    *control_parts[:3], positions[target], control_parts[3], 20, 0.75, 0
                )
            else:
                control = stability.analogue_control(args, key, source, old_bench, phase, mask)
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric != expected:
                raise ValueError("History frozen control did not reproduce")
            audit[phase]["control"] = metric
            audit[phase]["errorBanks"] = {}
            for group in sorted({r["spec"]["group"] for r in active}):
                for policy in sorted({r["spec"]["policy"] for r in active if r["spec"]["group"] == group}):
                    pieces = component_policy(old, current[group], policy)
                    previous_pieces = component_policy(previous_old, previous_new[group], policy)
                    bank = bank_from(previous_pieces, previous_rows, mask["first"])
                    audit[phase]["errorBanks"][group + "/" + policy] = {k: bank[k] for k in ("cases", "unknownLevels")}
                    predictions = {}
                    for record in [r for r in active if r["spec"]["group"] == group and r["spec"]["policy"] == policy]:
                        spec = record["spec"]
                        identity = spec["spread"], spec["shift"]
                        if identity not in predictions:
                            predictions[identity] = empirical.empirical_predictions(
                                *pieces, positions[target], bank, 20, spec["spread"], spec["shift"]
                            )
                        candidate = ordinary.scoped_prediction(
                            predictions[identity], control, positions[target], spec["scope"]
                        )
                        cm = measure(y[target], candidate)
                        if phase != "later2026":
                            gain = cm["within7"] - metric["within7"]
                            record["gains"].append(gain)
                            record["errors"].append(cm["mae"])
                            record["counts"].append(len(candidate))
                            record["periods"][phase] = {"gain": gain, "metrics": cm}
                        else:
                            alternate = candidate
                    print(f"TESTED {cohort} {phase} {group} {policy}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                    "candidates": records,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            prior = (target_rows, old, current)
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        weeks = [r["week"] for r in target_rows]
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "groupFeatures": {g: int(select.sum()) for g, select in groups.items()},
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
