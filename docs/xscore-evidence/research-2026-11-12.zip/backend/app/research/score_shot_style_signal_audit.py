"""Independent covariates, native labels, all24 event vectors, actual blinded refits."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np
from scipy.special import expit

from app.research import score_shot_style_signal as study
from app.research.score_search import cutoff_for, moment


def native_losses(y, p):
    clipped = np.maximum(1e-12, np.minimum(1 - 1e-12, p))
    return dict(
        n=len(y),
        positives=int(sum(y)),
        logloss=float(
            np.mean([-math.log(clipped[i]) if value else -math.log(1 - clipped[i]) for i, value in enumerate(y)])
        ),
        brier=float(np.mean([(value - p[i]) ** 2 for i, value in enumerate(y)])),
    )


def compare_metrics(left, right):
    if (
        left["n"] != right["n"]
        or left["positives"] != right["positives"]
        or any(abs(left[k] - right[k]) > 1e-13 for k in ("logloss", "brier"))
    ):
        raise ValueError("Independent all-native probability loss differs")


def independent_inputs(source, cache):
    with np.load(cache / "shot_style_features.npz") as f:
        x, names = f["x"], f["names"].tolist()
    with np.load(cache / "pass_source_qualified_features.npz") as f:
        q, qnames = f["x"], f["names"].tolist()
    fields = [
        "player_native_games",
        "player_known_games",
        "player_known_minutes",
        "player_nonpen_shots90",
        "player_native_goalassist_fraction",
        "player_native_goals90",
        "player_native_assists90",
        "player_source_fraction",
        "player_age_days",
        "opponent_native_games",
        "opponent_known_games",
        "opponent_nonpen_allowed_pergame",
        "opponent_source_fraction",
        "opponent_age_days",
    ]
    transformed_indices = {2, 3, 5, 6, 8, 11, 13}
    columns = []
    for i, name in enumerate(fields):
        v = x[:, names.index("shotstyle_" + name)]
        columns.append(np.log1p(v) if i in transformed_indices else v)
    columns += [
        np.log1p(q[:, qnames.index("same_10_chance_npxg90_mean")]),
        q[:, qnames.index("same_10_chance_npxg90_count")],
    ]
    original = np.array([r["x"] for r in source["rows"]])
    ix = {name: i for i, name in enumerate(source["features"])}
    for name in ("home", "position_GK", "position_DEF", "position_MID", "position_FWD"):
        columns.append(original[:, ix[name]])
    own = np.array([v[ix["match_lam_h"]] if v[ix["home"]] > 0 else v[ix["match_lam_a"]] for v in original])
    columns.append(np.log1p(own))
    log_style = []
    for name in ("body_lift", "zone_lift", "combined_lift"):
        v = x[:, names.index("shotstyle_match_" + name)]
        known = np.isfinite(v) & (v > 0)
        columns.append(known.astype(float))
        log_style.append(np.array([math.log(value) if yes else np.nan for value, yes in zip(v, known, strict=True)]))
    base = np.column_stack(columns)
    return dict(baseline=base, matched_style=np.column_stack((base, *log_style)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--report", type=Path, default=Path("reports/experiments/laliga_score_shot_style_signal.json"))
    args = parser.parse_args()
    args.out = args.report
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, actual_inputs, _, provenance = study.load_inputs(args)
    inputs = independent_inputs(source, args.cache)
    for group in inputs:
        np.testing.assert_allclose(inputs[group], actual_inputs[group], rtol=0, atol=1e-14, equal_nan=True)
    report = json.loads(args.report.read_text())
    key = hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + sklearn.__version__).encode()
        + Path(study.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if key != report["implementationKey"] or report["sourceKey"] != source["key"]:
        raise ValueError("Frozen signal core/plan/source key differs")
    games = {g["id"]: g for g in (json.loads(line) for line in args.games.read_text().splitlines() if line.strip())}
    native_y = dict(goal=[], goalassist=[])
    for r in source["rows"]:
        p = games[r["game"]]["players"][r["player"]]
        goals, assists = p["stats"].get("goals", [0, 0])[0], p["stats"].get("goal_assist", [0, 0])[0]
        native_y["goal"].append(float(goals > 0))
        native_y["goalassist"].append(float(goals > 0 or assists > 0))
    output = dict(
        implementationKey=key,
        featureKey=provenance["featureKey"],
        independentlyRebuiltCovariateRows=len(source["rows"]),
        nativeLabelsVerified=len(source["rows"]),
        cohorts={},
        scope="Earlier-only probability signal audit, NOT scorewithin7accuracy",
    )
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        observed = report["cohorts"][cohort]
        pooled = {o: dict(y=[], old=[], new=[], weeks=[]) for o in native_y}
        gains = {o: [] for o in native_y}
        models_checked, refits = 0, 0
        for phase, begin, end in (
            ("spring2024", "2024-01-01", "2024-07-01"),
            ("season2024", "2024-07-01", "2025-07-01"),
            ("autumn2025", "2025-07-01", "2026-01-01"),
        ):
            target = np.array([begin <= r["date"] < end for r in rows])
            first = min(r["date"] for r, yes in zip(rows, target, strict=True) if yes)
            lock = cutoff_for(first)
            fit = np.array([r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
            if any(r["date"] >= "2026-01-01" and (f or t) for r, f, t in zip(rows, fit, target, strict=True)):
                raise ValueError("Forbidden2026signal fit/evaluation")
            if observed["periods"][phase]["fit"] != int(fit.sum()) or observed["periods"][phase]["target"] != int(
                target.sum()
            ):
                raise ValueError("Full native signal period counts differ")
            for outcome, all_labels in native_y.items():
                y = np.array(all_labels)[keep]
                metrics, probabilities, base_transform = {}, {}, None
                for group, all_x in inputs.items():
                    x = all_x[keep]
                    with np.load(args.cache / f"{args.report.stem}_{cohort}_{phase}_{outcome}_{group}.npz") as f:
                        if str(f["key"]) != key or int(f["missing_width"]) != 25:
                            raise ValueError("Frozen model key/availability features differ")
                        np.testing.assert_array_equal(f["fit"], fit)
                        np.testing.assert_array_equal(f["target"], target)
                        np.testing.assert_array_equal(f["actual"], y[target])
                        med = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in x[fit].T])
                        complete = np.where(np.isfinite(x), x, med)
                        mean = complete[fit].mean(axis=0)
                        scale = np.sqrt(np.mean((complete[fit] - mean) ** 2, axis=0))
                        scale = np.where(scale > 1e-8, scale, 1.0)
                        for name, v in (("median", med), ("mean", mean), ("scale", scale)):
                            np.testing.assert_allclose(v, f[name], rtol=0, atol=1e-13)
                        if base_transform is None:
                            base_transform = tuple(f[name][:25].copy() for name in ("median", "mean", "scale"))
                        else:
                            for expected, name in zip(base_transform, ("median", "mean", "scale"), strict=True):
                                np.testing.assert_array_equal(expected, f[name][:25])
                        z = np.column_stack(
                            ((complete - f["mean"]) / f["scale"], (~np.isfinite(x[:, :25])).astype(float))
                        )
                        probability = expit(z[target] @ f["coefficient"] + f["intercept"])
                        np.testing.assert_allclose(probability, f["probability"], rtol=0, atol=1e-13)
                        saved = {
                            name: f[name].copy()
                            for name in ("probability", "coefficient", "intercept", "median", "mean", "scale")
                        }
                        probabilities[group] = f["probability"].copy()
                    metric = native_losses(y[target], probabilities[group])
                    compare_metrics(metric, observed["periods"][phase]["outcomes"][outcome]["metrics"][group])
                    metrics[group] = metric
                    blanked = y.copy()
                    blanked[~fit] = np.nan
                    # Use exactly the registered input arithmetic for a bit-exact real refit.
                    actual = study.fitted(actual_inputs[group][keep], blanked, fit, target, missing_width=25)
                    for name in saved:
                        np.testing.assert_array_equal(actual[name], saved[name])
                    models_checked += 1
                    refits += 1
                gain = dict(
                    logloss=metrics["baseline"]["logloss"] - metrics["matched_style"]["logloss"],
                    brier=metrics["baseline"]["brier"] - metrics["matched_style"]["brier"],
                )
                for loss_name in gain:
                    if (
                        abs(
                            gain[loss_name] - observed["periods"][phase]["outcomes"][outcome][loss_name + "Improvement"]
                        )
                        > 1e-13
                    ):
                        raise ValueError("Native signal improvement differs")
                gains[outcome].append(gain)
                p = pooled[outcome]
                p["y"].extend(y[target])
                p["old"].extend(probabilities["baseline"])
                p["new"].extend(probabilities["matched_style"])
                p["weeks"].extend(r["week"] for r, yes in zip(rows, target, strict=True) if yes)
        gates = {}
        for outcome, values in pooled.items():
            y, old, new = (np.array(values[k]) for k in ("y", "old", "new"))
            weeks = sorted(set(values["weeks"]))
            data = {week: [] for week in weeks}
            for a, b, c, week in zip(y, old, new, values["weeks"], strict=True):
                data[week].append((a - b) ** 2 - (a - c) ** 2)
            rng, draws = np.random.default_rng(20261105), []
            for _ in range(2000):
                selected = [data[weeks[i]] for i in rng.integers(len(weeks), size=len(weeks))]
                draws.append(math.fsum(math.fsum(group) for group in selected) / sum(len(group) for group in selected))
            bounds = np.quantile(draws, [0.025, 0.975])
            np.testing.assert_allclose(bounds, observed["pooled"][outcome]["brierImprovement95"], rtol=0, atol=1e-13)
            for group, probability in (("baseline", old), ("matchedStyle", new)):
                compare_metrics(native_losses(y, probability), observed["pooled"][outcome][group])
            gate = all(g["logloss"] > 0 and g["brier"] > 0 for g in gains[outcome]) and bounds[0] > 0
            if bool(gate) != observed["pooled"][outcome]["passesSignalGate"]:
                raise ValueError("Independent preregistered signal gate differs")
            gates[outcome] = bool(gate)
        if gates["goal"] != observed["passesPrimaryGoalGate"]:
            raise ValueError("Primary goal signal decision differs")
        output["cohorts"][cohort] = dict(
            nativeForwardProbabilityVectorsVerified=models_checked,
            actualOutsideFitBlankedFullRefits=refits,
            independentNativeLossesAndBootstrap=True,
            sameBaselineAvailabilityTransformsAcrossArms=True,
            no2026fitOrEvaluation=True,
            primaryGoalGate=gates["goal"],
            secondaryGoalAssistGate=gates["goalassist"],
        )
        print("SHOT_STYLE_SIGNAL_AUDITED " + json.dumps(dict(cohort=cohort, **output["cohorts"][cohort])), flush=True)
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
