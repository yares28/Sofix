import numpy as np
import pytest

from app.research.score_hidden_states import HiddenScores, padded, score_bins


def test_forward_backward_handles_unequal_lengths_and_counts_each_transition_once():
    sequences = [[35, 40, 44, 80], [0], [75, 80, 88]]
    model = HiddenScores(states=2, max_iter=10).fit(sequences)
    observed, valid = padded(sequences)
    posterior, transitions, likelihood = model.expectation(observed, valid)
    np.testing.assert_allclose(posterior[valid].sum(axis=1), 1)
    assert (posterior[~valid] == 0).all()
    assert transitions.sum() == pytest.approx(5)
    assert np.isfinite(likelihood)
    np.testing.assert_allclose(model.transition_.sum(axis=1), 1)
    np.testing.assert_allclose(model.emission_.sum(axis=1), 1)


def test_persistent_high_low_sequences_change_next_forecast_without_averaging_modes():
    sequences = [[40] * 15 for _ in range(30)] + [[80] * 15 for _ in range(20)]
    model = HiddenScores(states=2, transition_prior=1).fit(sequences)
    low, high = model.predict([[40] * 5, [80] * 5])
    assert low[40] > low[80] and high[80] > high[40]
    assert low[56] == high[56] == 0
    assert low[40] > 0.8 and high[80] > 0.8
    fixed = model.transition_.copy()
    model.predict([[80] * 20, []])
    np.testing.assert_equal(model.transition_, fixed)


def test_zero_is_known_missing_is_rejected_and_native_window_edges_are_exact():
    np.testing.assert_equal(score_bins([0, 100]), [0, 20])
    with pytest.raises(ValueError, match="known"):
        score_bins([None])
    model = HiddenScores(states=1, max_iter=10).fit([[33, 47, 47.001]] * 10)
    assert model.windows_[0, 40] == pytest.approx(2 / 3)
    assert np.isfinite(model.predict([[], [0]])).all()


def test_independent_scores_do_not_invent_strong_persistence_from_recent_high_scores():
    rng = np.random.default_rng(20261104)
    sequences = [rng.choice([40, 80], size=40, p=[0.6, 0.4]).tolist() for _ in range(100)]
    model = HiddenScores(states=2, transition_prior=20).fit(sequences)
    low, high = model.predict([[40] * 5, [80] * 5])
    assert abs(low[40] - high[40]) < 0.1
    assert low[40] > low[80] and high[40] > high[80]


def test_runner_never_reads_target_labels_and_keeps_no_history_or_no_position_fit(tmp_path):
    import json

    import pandas as pd

    from app.research.score_hidden_states_run import fit_windows

    frame = pd.DataFrame(
        {
            "player_id": ["a", "a", "b", "b", "c", "c", "a", "keeper"],
            "card_position": ["FWD"] * 7 + ["GK"],
            "past_scores": [[], [40], [], [80], [], [0], [40, 45], []],
        }
    )
    mask = {"fit": np.array([True] * 6 + [False] * 2), "target": np.array([False] * 6 + [True] * 2)}
    scores = np.array([40, 45, 80, 85, 0, 35, 50, 70], dtype=float)
    left = tmp_path / "left_states2_prior1_history5.npz"
    first = fit_windows(frame, [], scores, mask, "states2_prior1_history5", left, "test-key")
    scores[-2:] = np.nan
    second = fit_windows(
        frame, [], scores, mask, "states2_prior1_history5", tmp_path / "right_states2_prior1_history5.npz", "test-key"
    )
    np.testing.assert_allclose(first, second)
    assert first.shape == (2, 101) and np.isfinite(first).all()
    with np.load(left) as stored:
        stats = json.loads(str(stored["statistics"]))
        assert stats["GK"]["pooledFallback"] is True
        assert stats["FWD"]["pooledFallback"] is False
