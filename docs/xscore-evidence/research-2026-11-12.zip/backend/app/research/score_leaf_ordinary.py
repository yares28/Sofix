"""Testing only: full conditional ordinary-point distributions in regression leaves."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research.score_modal_trees import CENTRES, interval_histogram, score_intervals

POSITIONS = ("GK", "DEF", "MID", "FWD")
SETTINGS = {
    "sqrt_leaf40": {"trees": 64, "depth": 12, "leaf": 40, "features": "sqrt"},
    "sqrt_leaf100": {"trees": 64, "depth": 12, "leaf": 100, "features": "sqrt"},
    "quarter_leaf40": {"trees": 64, "depth": 12, "leaf": 40, "features": 0.25},
}


class FitImputer:
    def fit(self, x):
        if x.ndim != 2 or not len(x) or np.isinf(x).any():
            raise ValueError("Available finite-or-missing fit inputs required")
        self.median_ = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in x.T])
        return self

    def transform(self, x):
        if x.ndim != 2 or x.shape[1] != len(self.median_) or np.isinf(x).any():
            raise ValueError("Ordinary-leaf input schema differs")
        return np.column_stack((np.where(np.isnan(x), self.median_, x), np.isnan(x))).astype(np.float32)


def leaf_window_histograms(aa, leaves, node_count, level):
    aa, leaves = np.asarray(aa, dtype=float), np.asarray(leaves, dtype=int)
    if aa.ndim != 1 or aa.shape != leaves.shape or not np.isfinite(aa).all():
        raise ValueError("Available native AA and leaf identities required")
    scores = np.clip(np.maximum(level if level >= 60 else 0, level + aa), 0, 100)
    low, high = score_intervals(scores)
    return interval_histogram(leaves, low, high, np.ones(len(aa)), node_count), np.bincount(
        leaves, minlength=node_count
    )


def design(numeric, positions, levels):
    levels = np.broadcast_to(levels, len(numeric))
    return np.column_stack(
        (numeric, *[(np.asarray(positions) == p).astype(np.float32) for p in POSITIONS], levels)
    ).astype(np.float32)


def fit_distribution(x, aa, levels, positions, fit, target, classes, probability, setting, priors=(20, 100)):
    from sklearn.ensemble import ExtraTreesRegressor

    x, aa, levels, positions = map(np.asarray, (x, aa, levels, positions))
    fit, target = np.asarray(fit, dtype=bool), np.asarray(target, dtype=bool)
    classes, probability = np.asarray(classes), np.asarray(probability)
    if (
        x.ndim != 2
        or any(a.shape != (len(x),) for a in (aa, levels, positions, fit, target))
        or not fit.any()
        or (fit & target).any()
        or not np.isfinite(aa[fit]).all()
        or not np.isfinite(levels[fit]).all()
        or not np.isin(levels[fit], [0, 5, 15, 35, 60, 70, 80, 90, 100]).all()
        or not np.isin(positions, POSITIONS).all()
        or probability.shape != (int(target.sum()), len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
        or any(p < 0 for p in priors)
    ):
        raise ValueError("Conditional ordinary-leaf fit/probability contract differs")
    imputer = FitImputer().fit(x[fit])
    train_numeric = imputer.transform(x[fit])
    target_numeric = imputer.transform(x[target])
    train = design(train_numeric, positions[fit], levels[fit])
    model = ExtraTreesRegressor(
        n_estimators=setting["trees"],
        max_depth=setting["depth"],
        min_samples_leaf=setting["leaf"],
        max_features=setting["features"],
        criterion="squared_error",
        bootstrap=False,
        n_jobs=2,
        random_state=20261104,
    )
    model.fit(train, aa[fit])
    train_leaves = model.apply(train)
    masses = {prior: np.zeros((int(target.sum()), len(CENTRES))) for prior in priors}
    target_positions = positions[target]
    sparse = 0
    for j, level in enumerate(classes):
        native_scores = np.clip(np.maximum(level if level >= 60 else 0, level + aa[fit]), 0, 100)
        low, high = score_intervals(native_scores)
        target_leaves = model.apply(design(target_numeric, target_positions, level))
        # Position/class shrinkage contains only available fit labels, never target AA/DS.
        pooled = np.zeros((int(target.sum()), len(CENTRES)))
        for pos in set(target_positions):
            own = (positions[fit] == pos) & (levels[fit] == level)
            if own.sum() < 20:
                sparse += 1
                own = positions[fit] == pos
            if not own.any():
                own = np.ones(int(fit.sum()), dtype=bool)
            hist, counts = leaf_window_histograms(aa[fit][own], np.zeros(int(own.sum()), dtype=int), 1, level)
            pooled[target_positions == pos] = hist[0] / counts[0]
        for t, tree in enumerate(model.estimators_):
            counts = np.bincount(train_leaves[:, t], minlength=tree.tree_.node_count)
            hist = interval_histogram(train_leaves[:, t], low, high, np.ones(int(fit.sum())), tree.tree_.node_count)
            chosen = target_leaves[:, t]
            if (counts[chosen] <= 0).any():
                raise ValueError("Target reached an empty fitted ordinary leaf")
            for prior in priors:
                conditional = (hist[chosen] + prior * pooled) / (counts[chosen, None] + prior)
                masses[prior] += probability[:, j, None] * conditional / len(model.estimators_)
    for value in masses.values():
        if not np.isfinite(value).all() or (value < 0).any() or (value > 1 + 1e-12).any():
            raise ValueError("Conditional ordinary window mass invalid")
    stats = {
        "fitCases": int(fit.sum()),
        "targetCases": int(target.sum()),
        "settings": setting,
        "priors": list(priors),
        "numericFeatures": x.shape[1],
        "designFeatures": train.shape[1],
        "coldTargetPositions": sorted(set(target_positions) - set(positions[fit])),
        "sparsePositionClassPriors": sparse,
        "eventProbabilitiesUnchanged": True,
        "meanLeaves": float(np.mean([t.get_n_leaves() for t in model.estimators_])),
        "fitImputerSha256": hashlib.sha256(imputer.median_.tobytes()).hexdigest(),
    }
    return masses, stats
