from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_spatial_conditioning as study
from app.research.score_spatial_context import feature_names


def test_arms_preserve_full_population_strong_inputs_and_unknown_lanes():
    base = np.zeros((38850, 677))
    context = np.full((38850, 220), np.nan)
    context[:, 0] = 3
    arms = study.feature_arms(base, context, feature_names())
    assert arms["spatial_context"].shape == (38850, 897)
    assert arms["individual_lane"].shape == (38850, 693)
    for x in arms.values():
        np.testing.assert_array_equal(x[:, :677], base)
        assert x[0, 677] == 3
        assert np.isnan(x[0, 678])


def test_actual_four_conditional_models_ignore_all_outsidefit_outcomes(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(73)
    x = rng.normal(size=(480, 7))
    x[::4, -1] = np.nan
    aa = rng.normal(10, 6, 480)
    levels = np.where(np.arange(480) % 3 == 0, 60.0, 35.0)
    mask = {"fit": np.arange(480) < 400, "target": np.arange(480) >= 400}
    root = Path(__file__).parents[1] / "data/raw/spatial-fit-tests" / uuid4().hex
    root.mkdir(parents=True)
    before = study.fitted(x, aa, levels, mask, root / "before.npz", "fixture")
    aa[~mask["fit"]], levels[~mask["fit"]] = np.nan, np.nan
    after = study.fitted(x, aa, levels, mask, root / "after.npz", "fixture")
    for a, b in zip(before[:2], after[:2], strict=True):
        np.testing.assert_array_equal(a, b)
    for q in before[2]:
        np.testing.assert_array_equal(before[2][q], after[2][q])
