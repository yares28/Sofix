"""Test past within-team score differences as portable player information."""

import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_relative_player"
AGE = timedelta(days=365)


def deviations(players):
    if len(players) < 2:
        return {}
    values = np.array([points for _, points in players])
    peer = (values.sum(axis=0) - values) / (len(players) - 1)
    return {slug: v for (slug, _), v in zip(players, values - peer, strict=True)}


def prior(history, lock, target):
    eligible = [values for when, values in history if when >= lock - AGE]
    if not eligible:
        return target, 0
    return (np.sum(eligible, axis=0) + 5 * target) / (len(eligible) + 5), len(eligible)


def build(rows, games, names):
    matched = {g["id"]: g for g in games}
    by_game = defaultdict(list)
    for i, r in enumerate(rows):
        by_game[r["game"]].append(i)
    prepared = []
    for game in sorted(games, key=lambda g: (g["date"], g["id"])):
        unit = defaultdict(list)
        sides = (game["home"]["slug"], game["away"]["slug"])
        for i in by_game[game["id"]]:
            r = rows[i]
            p = game["players"][r["player"]]
            assert p["team"] in sides and r["date"] == game["date"]
            unit[p["team"], r["pos"], r["cohort"]].append((r["player"], (r["aa"], r["score"])))
        prepared.append((moment(game["date"]) + DELAY, sides, unit))
    clocks = [cutoff_for(r["date"]) for r in rows]
    own, opposing, portable, club_player = (defaultdict(lambda: deque(maxlen=20)) for _ in range(4))
    last_club = {}
    own_count = defaultdict(lambda: deque(maxlen=3))
    baseline, individual = np.empty((len(rows), 6)), np.empty((len(rows), 6))
    new_club = np.zeros(len(rows), dtype=bool)
    cursor = 0
    for i in sorted(range(len(rows)), key=clocks.__getitem__):
        row, lock = rows[i], clocks[i]
        while cursor < len(prepared) and prepared[cursor][0] < lock:
            ready, sides, unit = prepared[cursor]
            time = ready - DELAY
            for (club, pos, cohort), players in unit.items():
                other = sides[1] if club == sides[0] else sides[0]
                average = np.mean([y for _, y in players], axis=0)
                own[club, pos, cohort].append((time, average))
                opposing[other, pos, cohort].append((time, average))
                for slug, _ in players:
                    last_club[slug] = time, club
                    own_count[slug, club].append(time)
                for slug, delta in deviations(players).items():
                    portable[slug, pos, cohort].append((time, delta))
                    club_player[slug, club, pos, cohort].append((time, delta))
            cursor += 1
        game = matched[row["game"]]
        slug, pos, cohort = (row[k] for k in ("player", "pos", "cohort"))
        club = game["players"][slug]["team"]
        other = game["away"]["slug"] if club == game["home"]["slug"] else game["home"]["slug"]
        anchor = np.array([row["x"][names.index(f"{cohort}_10_{k}")] for k in ("aa", "score")])
        own_mean, n = prior(own[club, pos, cohort], lock, anchor)
        opp_mean, m = prior(opposing[other, pos, cohort], lock, anchor)
        team = (own_mean + opp_mean) / 2
        zero = np.zeros(2)
        historical, p = prior(portable[slug, pos, cohort], lock, zero)
        personal, q = prior(club_player[slug, club, pos, cohort], lock, historical)
        baseline[i] = np.r_[own_mean - anchor, opp_mean - anchor, np.log1p(n), np.log1p(m)]
        individual[i] = np.r_[team + personal - anchor, personal - historical, np.log1p(p), np.log1p(q)]
        if slug in last_club:
            time, previous = last_club[slug]
            past_games = sum(v >= lock - AGE for v in own_count[slug, club])
            new_club[i] = time >= lock - AGE and previous != club and past_games == 0
    return baseline, individual, new_club


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    native = np.array([r["x"] for r in rows])
    team, relative, moved = build(rows, games, source["features"])
    b = np.column_stack((native, team))
    model = {"original": native, "team": b, "relative": np.column_stack((b, relative))}
    score = np.array([r["score"] for r in rows])
    aa = np.array([r["aa"] for r in rows])
    date = np.array([r["date"] for r in rows])
    cohort = np.array([r["cohort"] for r in rows])
    ready = np.array([moment(d) + DELAY for d in date])
    locks = np.array([cutoff_for(d) for d in date])
    periods = {}
    moves = {}
    for phase, (begin, end) in PHASES.items():
        window = (date >= begin) & (date < end)
        available = ready < locks[window].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            fit, test = available & (cohort == role), window & (cohort == role)
            prediction = {}
            for outcome, metric, clip in ((score, "score", True), (aa, "aa", False)):
                anchor = native[:, source["features"].index(f"{role}_10_{metric}")]
                values = {k: anchor[test] + forecast(x, outcome - anchor, fit, test) for k, x in model.items()}
                values["relativeNewClub"] = np.where(moved[test], values["relative"], values["team"])
                if clip:
                    values = {k: np.clip(v, 0, 100) for k, v in values.items()}
                if clip and role == "bench":
                    ids = np.flatnonzero(test)
                    moves[phase] = [
                        [rows[i]["game"], rows[i]["player"], float(np.clip(change, -3, 3))]
                        for i, change in zip(ids, values["relativeNewClub"] - values["team"], strict=True)
                        if moved[i]
                    ]
                prediction[metric] = {
                    "teamAgainstOriginal": metrics(outcome[test], values["original"], values["team"]),
                    "relativeAgainstTeam": metrics(outcome[test], values["team"], values["relative"]),
                    "relativeNewClubAgainstTeam": metrics(outcome[test], values["team"], values["relativeNewClub"]),
                    "relativeAgainstOriginal": metrics(outcome[test], values["original"], values["relative"]),
                }
            periods[phase][role] = dict(
                **prediction,
                newClub=int(moved[test].sum()),
                relativeHistoryKnown=int(np.count_nonzero(relative[test, -2])),
            )
    gate = {}
    for role in ("start", "bench"):
        gate[role] = {}
        for k in periods["spring2024"][role]["score"]:
            group = [p[role]["score"][k] for p in periods.values()]
            n = sum(r["n"] for r in group)
            hits = [r["gained"] - r["lost"] for r in group]
            mae = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in group) / n
            gate[role][k] = dict(
                n=n,
                netHits=sum(hits),
                phaseHitGains=hits,
                maeGain=mae,
                passEarlier=sum(hits) > 0 and min(hits) >= 0 and mae > 0,
            )
    effect_bytes = (json.dumps(moves, separators=(",", ":")) + "\n").encode()
    (ROOT / (STEM + "_new_club.json")).write_bytes(effect_bytes)
    output = dict(
        nativeSHA=NATIVE_SHA,
        sourceKey=source["key"],
        periods=periods,
        gate=gate,
        laterEvaluated=False,
        moveSHA=hashlib.sha256(effect_bytes).hexdigest(),
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
