"""Independent official PDF row/clock checks for the small referee source pilot."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research import score_referee_source as primary
from app.research.score_market_booklets_audit import pdf_date


class Published(HTMLParser):
    def __init__(self):
        super().__init__()
        self.active = False
        self.content = []

    def handle_starttag(self, tag, attrs):
        if tag == "div" and "news__header__date" in dict(attrs).get("class", "").split():
            self.active = True

    def handle_data(self, data):
        if self.active:
            self.content.append(data)

    def handle_endtag(self, tag):
        if tag == "div":
            self.active = False


def main():
    import pdfplumber
    from pypdf import PdfReader

    folder = Path("data/raw/score-foundation/referee-source")
    reports = Path("reports/experiments")
    result = json.loads((reports / "laliga_score_referee_source.json").read_text())
    for file, digest in result["manifests"].items():
        path = reports / file if file.endswith(".plan.json") else folder / file
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError("Frozen source manifest/plan changed")
    key = hashlib.sha256(
        Path(primary.__file__).read_bytes()
        + json.dumps(result["manifests"], sort_keys=True).encode()
        + result["nativeSHA"].encode()
    ).hexdigest()
    if key != result["implementationKey"]:
        raise ValueError("Frozen source implementation differs")
    entries = {e["File"]: e for e in json.loads((folder / "pilot_pdf_manifest.json").read_text(encoding="utf-8-sig"))}
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    if hashlib.sha256(native.read_bytes()).hexdigest() != result["nativeSHA"]:
        raise ValueError("Frozen native bytes differ")
    # Deliberately discard every participant, score and actual lineup before linkage.
    games = {
        g["id"]: {k: g[k] for k in ["id", "date", "home", "away"]}
        for g in map(json.loads, native.read_text(encoding="utf-8").splitlines())
    }
    checked, prelock, changed = 0, 0, 0
    for doc in result["documents"]:
        raw = (folder / doc["file"]).read_bytes()
        article = (folder / doc["page"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != doc["sha256"] or hashlib.sha256(article).hexdigest() != doc["articleSHA"]:
            raise ValueError("Source document bytes differ")
        parser = Published()
        parser.feed(article.decode("utf-8"))
        text = "".join(parser.content).strip().split(", ", 1)[1]
        publication = (
            datetime.strptime(text, "%d/%m/%Y - %H:%M").replace(tzinfo=ZoneInfo("Europe/Madrid")).astimezone(UTC)
        )
        metadata = PdfReader(folder / doc["file"]).metadata
        created, modified = pdf_date(metadata["/CreationDate"]), pdf_date(metadata["/ModDate"])
        http = parsedate_to_datetime(entries[doc["file"]]["LastModified"][0])
        available = max(publication, created, modified, http)
        if any(
            datetime.fromisoformat(doc[k]) != value
            for k, value in [
                ("publicationUTC", publication),
                ("creationUTC", created),
                ("modificationUTC", modified),
                ("httpLastModifiedUTC", http),
                ("availableUTC", available),
            ]
        ):
            raise ValueError("Independent raw publication/document/server clock differs")
        changed += modified > publication
        with pdfplumber.open(folder / doc["file"]) as pdf:
            texts = {i + 1: page.extract_text() for i, page in enumerate(pdf.pages)}
        # Different PDF engine; count ALL match headers and referee labels, no per-fixture selected extraction.
        raw_headers = Counter(
            v for t in texts.values() for v in re.findall(r"(?m)^\d{2}-\d{2}-\d{4} .+ \d{2}:\d{2}$", t)
        )
        expected_headers = Counter()
        for row in doc["assignments"]:
            day = datetime.fromisoformat(row["localDate"])
            line = day.strftime("%d-%m-%Y") + " " + row["home"] + " " + row["away"] + " " + row["time"]
            expected_headers[line] += 1
            text = texts[row["page"]]
            if not re.search(re.escape(line) + r"\nÁrbitro:\s*" + re.escape(row["referee"]) + r"\s+4º Árbitro:", text):
                raise ValueError("Independent complete printed fixture/main-referee row differs")
            at = (
                datetime.fromisoformat(row["localDate"] + "T" + row["time"])
                .replace(tzinfo=ZoneInfo("Europe/Madrid"))
                .astimezone(UTC)
            )
            g = games[row["game"]]
            if (
                datetime.fromisoformat(g["date"].replace("Z", "+00:00")) != at
                or g["home"]["slug"] != primary.OFFICIAL_CLUBS[row["home"]]
                or g["away"]["slug"] != primary.OFFICIAL_CLUBS[row["away"]]
            ):
                raise ValueError("Independent schedule-only fixture linkage differs")
            lock = max(
                (at - timedelta(days=i)).replace(hour=14, minute=0, second=0, microsecond=0)
                for i in range(8)
                if (at - timedelta(days=i)).weekday() in (1, 4)
                and (at - timedelta(days=i)).replace(hour=14, minute=0, second=0, microsecond=0) <= at
            )
            known = available < lock
            if row["metadataBeforeLock"] != known or row["refereeInput"] != (row["referee"] if known else None):
                raise ValueError("Late referee assignment was not kept unknown")
            if (
                datetime.fromisoformat(row["inferredLockUTC"]) != lock
                or datetime.fromisoformat(row["kickoffUTC"]) != at
            ):
                raise ValueError("Independent forecast clock differs")
            checked += 1
            prelock += known
        if expected_headers != raw_headers or sum(
            t.count("Árbitro:") - t.count("4º Árbitro:") for t in texts.values()
        ) != len(doc["assignments"]):
            raise ValueError("Source-wide appointment row coverage differs")
    if checked != result["assignments"] or prelock != result["availableAssignments"]:
        raise ValueError("Source total differs")
    receipt = dict(
        status="COMPLETE independent pilot source audit; not a formula accuracy result",
        implementationKey=key,
        documents=len(result["documents"]),
        printedAssignments=checked,
        metadataPrelock=prelock,
        lateOrRevisedKeptUnknown=checked - prelock,
        independentlyParsedPageAndPDFClocks=True,
        secondPDFEngineAllRowsVerified=True,
        noParticipantOrScoreDataUsed=True,
        modelFits=0,
    )
    (reports / "laliga_score_referee_source.integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("REFEREE_SOURCE_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
