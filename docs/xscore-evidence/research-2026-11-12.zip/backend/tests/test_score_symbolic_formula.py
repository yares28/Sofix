"""Testing-only native arithmetic, causal preprocessing and deterministic fit recovery."""

from pathlib import Path
from uuid import uuid4

import numpy as np
import pytest

from app.research import score_symbolic_formula as symbolic


def test_conditional_formula_picks_distinct_outcomes_and_native_boundaries():
    tree = ["if", ["v", 0], ["c", 80], ["c", 40]]
    np.testing.assert_array_equal(symbolic.native_prediction(tree, np.array([[-1], [1], [0]])), [40, 80, 40])
    np.testing.assert_array_equal(
        symbolic.native_prediction(["div", ["c", 40], ["v", 0]], np.array([[0], [2]])), [40, 20]
    )
    np.testing.assert_array_equal(
        symbolic.native_prediction(["v", 0], np.array([[-50], [101], [40.25]])), [0, 100, 40.5]
    )
    assert symbolic.depth(tree) == 1
    assert len(symbolic.node_paths(tree)) == 4


def test_fit_only_missing_transform_preserves_zero_and_ignores_future_query_outliers():
    x = np.array([[0, np.nan], [1, np.nan], [2, np.nan], [0, np.nan]])
    scores = np.array([40, 40, 80, 40])
    model = symbolic.FormulaSearch(2, 0.001, generations=3, population=32).fit(x, scores)
    before = model.median_.copy(), model.lower_.copy(), model.upper_.copy(), model.tree_
    transformed = model.transform(np.array([[0, 99999], [np.nan, np.nan], [1e20, -1e20]]))
    assert transformed[0, 0] == 0
    assert transformed[1, 2] == 1
    assert (transformed[:, [1, 3]] == 0).all()
    model.predict(np.array([[1e20, -1e20], [np.nan, np.nan]]))
    for actual, expected in zip((model.median_, model.lower_, model.upper_), before[:3], strict=True):
        np.testing.assert_array_equal(actual, expected)
    assert model.tree_ == before[3]


def test_snapshot_resume_matches_uninterrupted_search_and_rejects_changed_labels():
    x = np.arange(32, dtype=float)[:, None] / 10
    scores = np.where(x[:, 0] < 1.6, 40, 80)
    directory = Path("data/raw/symbolic-tests") / uuid4().hex
    directory.mkdir(parents=True, exist_ok=True)
    snapshot = directory / "symbolic.json"
    args = dict(max_depth=3, penalty=0.001, population=32, seed=7)
    fresh = symbolic.FormulaSearch(**args, generations=8).fit(x, scores)
    symbolic.FormulaSearch(**args, generations=4).fit(x, scores, snapshot=snapshot, key="toy-only")
    resumed = symbolic.FormulaSearch(**args, generations=8).fit(x, scores, snapshot=snapshot, key="toy-only")
    assert fresh.statistics_ == resumed.statistics_
    np.testing.assert_array_equal(fresh.predict(x), resumed.predict(x))
    with pytest.raises(ValueError, match="snapshot"):
        symbolic.FormulaSearch(**args, generations=8).fit(x, scores + 1, snapshot=snapshot, key="toy-only")


def test_unknown_targets_cannot_become_zero_and_all_query_cases_remain():
    with pytest.raises(ValueError, match="Known native"):
        symbolic.FormulaSearch(2, 0.001, generations=1, population=32).fit(np.zeros((3, 2)), np.array([40, np.nan, 80]))
    model = symbolic.FormulaSearch(2, 0.001, generations=1, population=32).fit(np.zeros((3, 2)), np.array([40, 40, 80]))
    prediction = model.predict(np.array([[0, 0], [np.nan, np.nan], [999, 0]]))
    assert len(prediction) == 3
    assert np.isfinite(prediction).all()
