"""Testing only: conditional AA mixture search with fixed longer-training confirmation."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_flow as flow
from app.research import score_histogram_ordinary as mixture
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def fitted(x, aa, levels, positions, mask, old, model, iterations, path, key):
    if path.exists():
        with np.load(path) as f:
            stats = json.loads(str(f["statistics"]))
            if (
                str(f["key"]) != key
                or not np.array_equal(f["classes"], old[0])
                or not np.array_equal(f["probability"], old[1])
                or stats["iterations"] != iterations
            ):
                raise ValueError("Mixture AA cached source/events/iterations differ")
            return f["mass"], stats
    mass, stats = mixture.fit_forecasts(
        x, aa, levels, positions, mask["fit"], mask["target"], old[0], old[1], mixture.SETTINGS[model], iterations
    )
    np.savez_compressed(path, key=key, classes=old[0], probability=old[1], mass=mass, statistics=json.dumps(stats))
    return mass, stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda n: json.loads((args.out.parent / (n + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Mixture AA source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
        matched.validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Mixture AA match features differ")
        all_x = np.column_stack((base, f["x"]))
    if all_x.shape != (len(source["rows"]), 677):
        raise ValueError("Mixture AA input coverage differs")
    modules = (mixture, flow, matched, controls, modal, ordinary, stability, windows)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
            + np.__version__
        ).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    report = {
        "scope": "Testing only, conditional ordinary-point band probabilities; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated historical reuse, exploratory not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] == key:
            report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        x = all_x[keep]
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        aa, levels, y = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        candidates = [
            {"spec": {"model": m, "scope": s}, "gains": [], "errors": [], "counts": [], "periods": {}}
            for m in mixture.SETTINGS
            for s in ("all", "defmid")
        ]
        audit = {}

        def phase_inputs(phase, masks=masks, cohort=cohort, y=y):
            target = masks[phase]["target"]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Mixture AA strongest control differs")
            return target, old, control, expected

        def cached(
            phase, model, iterations, old, cohort=cohort, x=x, aa=aa, levels=levels, positions=positions, masks=masks
        ):
            print(f"HISTOGRAM_AA_FITTING {cohort} {phase} {model} iterations{iterations}", flush=True)
            return fitted(
                x,
                aa,
                levels,
                positions,
                masks[phase],
                old,
                model,
                iterations,
                args.cache / f"{args.out.stem}_{cohort}_{phase}_{model}_e{iterations}.npz",
                key,
            )

        for phase, _, _ in stability.PHASES[1:-1]:
            target, old, control, expected = phase_inputs(phase)
            audit[phase] = {"fit": int(masks[phase]["fit"].sum()), "target": int(target.sum()), "models120": {}}
            for model in mixture.SETTINGS:
                mass, stats = cached(phase, model, 120, old)
                audit[phase]["models120"][model] = stats
                raw = windows.window_centres(mass, modal.CENTRES)
                for record in [r for r in candidates if r["spec"]["model"] == model]:
                    forecast = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    metric = measure(y[target], forecast)
                    gain = metric["within7"] - expected["within7"]
                    record["gains"].append(gain)
                    record["errors"].append(metric["mae"])
                    record["counts"].append(len(forecast))
                    record["periods"][phase] = {"gain": gain, "metrics": metric}
        initial_winner, initial_best = stability.choose_stable(candidates)
        confirmation = {"spec": initial_best["spec"], "gains": [], "errors": [], "counts": [], "periods": {}}
        args.out.with_name(args.out.stem + f".{cohort}.selection120.json").write_text(
            json.dumps(
                {"implementationKey": key, "winner": initial_winner, "best": initial_best, "candidates": candidates},
                indent=2,
            )
        )
        print("HISTOGRAM_AA_CONFIRM " + json.dumps({"cohort": cohort, "spec": initial_best["spec"]}), flush=True)
        for phase, _, _ in stability.PHASES[1:-1]:
            target, old, control, expected = phase_inputs(phase)
            mass, stats = cached(phase, initial_best["spec"]["model"], 240, old)
            audit[phase]["confirmation240"] = stats
            raw = windows.window_centres(mass, modal.CENTRES)
            forecast = ordinary.scoped_prediction(raw, control, positions[target], initial_best["spec"]["scope"])
            metric = measure(y[target], forecast)
            gain = metric["within7"] - expected["within7"]
            confirmation["gains"].append(gain)
            confirmation["errors"].append(metric["mae"])
            confirmation["counts"].append(len(forecast))
            confirmation["periods"][phase] = {"gain": gain, "metrics": metric}
        winner = confirmation if min(confirmation["gains"]) > 0 else None
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
            json.dumps(
                {
                    "implementationKey": key,
                    "winner": winner,
                    "best": confirmation,
                    "initialWinner120": initial_winner,
                    "initialBest120": initial_best,
                    "candidates120": candidates,
                },
                indent=2,
            )
        )
        print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": confirmation}), flush=True)
        target, old, control, expected = phase_inputs("later2026")
        mass, stats = cached("later2026", confirmation["spec"]["model"], 240, old)
        audit["later2026"] = stats
        alternate = ordinary.scoped_prediction(
            windows.window_centres(mass, modal.CENTRES), control, positions[target], confirmation["spec"]["scope"]
        )
        prediction = alternate if winner else control.copy()
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "candidate": confirmation,
            "winner": winner,
            "initialBest120": initial_best,
            "candidateCount120": len(candidates) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": expected,
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(
                y[target], alternate, control, [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
            ),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            alternate=alternate,
            prediction=prediction,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, "selected": result["selected"], "candidateLater": result["candidateLater"]}
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
