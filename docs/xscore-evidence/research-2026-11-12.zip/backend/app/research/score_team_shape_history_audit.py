"""Testing only: independent native XI/AA parsing and every causal team-shape feature."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
from bisect import bisect_left
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research import score_search
from app.research import score_team_shape_history as shape
from app.research.score_search import cutoff_for, moment


def parse_native(games):
    records = []
    for g in games:
        if not any(p.get("played") is True for p in g["players"].values()):
            continue
        for side, other in (("home", "away"), ("away", "home")):
            club = g[side]["slug"]
            starters = sorted(
                p
                for p, r in g["players"].items()
                if r.get("team") == club and r.get("played") is True and r.get("started") is True
            )
            native_xi = starters if len(starters) == 11 else None
            published = (g.get("xi") or {}).get(side) or {}
            lines = published.get("start") or []
            names = [p for line in lines for p in line]
            signature = None
            if (
                published.get("available") is True
                and native_xi is not None
                and len(names) == len(set(names)) == 11
                and set(names) == set(starters)
                and len(lines) >= 2
                and len(lines[0]) == 1
                and all(lines)
                and g["players"][lines[0][0]].get("pos") == "GK"
            ):
                signature = [len(line) for line in lines[1:]]
            labels = []
            for player, r in g["players"].items():
                aa, score = r.get("aa"), r.get("score")
                if (
                    r.get("team") != club
                    or r.get("played") is not True
                    or r.get("ver") != 7
                    or type(r.get("started")) is not bool
                    or r.get("pos") not in ("GK", "DEF", "MID", "FWD")
                ):
                    continue
                if (
                    type(aa) not in (int, float)
                    or type(score) not in (int, float)
                    or not math.isfinite(aa)
                    or not math.isfinite(score)
                    or not 0 <= score <= 100
                ):
                    continue
                labels.append(
                    dict(
                        player=player,
                        pos=r["pos"],
                        cohort="start" if r["started"] else "bench",
                        aa=float(aa),
                        shape=signature,
                    )
                )
            records.append(
                dict(
                    game=g["id"],
                    date=g["date"],
                    club=club,
                    opponent=g[other]["slug"],
                    xi=native_xi,
                    shape=signature,
                    labels=labels,
                )
            )
    return records


def reference_team(history):
    n = len(history)
    signatures = [tuple(r["shape"]) for r in history if r["shape"] is not None]
    lineups = [frozenset(r["xi"]) for r in history if r["xi"] is not None]
    counts = Counter(signatures)
    changes, retained = [], []
    for i in range(1, n):
        a, b = history[i - 1], history[i]
        if a["shape"] is not None and b["shape"] is not None:
            changes.append(tuple(a["shape"]) != tuple(b["shape"]))
        if a["xi"] is not None and b["xi"] is not None:
            retained.append(len(set(a["xi"]).intersection(b["xi"])) / 11)
    last = (
        len(set(history[-2]["xi"]).intersection(history[-1]["xi"])) / 11
        if n > 1 and history[-2]["xi"] is not None and history[-1]["xi"] is not None
        else np.nan
    )
    result = dict(
        observed_games=n,
        xi_known_count=len(lineups),
        shape_known_count=len(signatures),
        shape_unique_count=len(counts),
        shape_mode_fraction=max(counts.values()) / len(signatures) if signatures else np.nan,
        shape_last_fraction=counts[signatures[-1]] / len(signatures) if signatures else np.nan,
        shape_entropy=sum(-(c / len(signatures)) * math.log(c / len(signatures)) for c in counts.values())
        if signatures
        else np.nan,
        shape_switch_rate=float(np.mean(changes)) if changes else np.nan,
        xi_unique_players=len(frozenset().union(*lineups)) if lineups else np.nan,
        xi_last_retained_fraction=last,
        xi_retained_mean=float(np.mean(retained)) if retained else np.nan,
        xi_retained_sd=float(np.std(retained)) if retained else np.nan,
        xi_core_fraction=sum(len(s.intersection(lineups[-1])) for s in lineups) / (11 * len(lineups))
        if lineups
        else np.nan,
    )
    for field, data in (
        ("backline", [s[0] for s in signatures]),
        ("frontline", [s[-1] for s in signatures]),
        ("outfield_lines", [len(s) for s in signatures]),
    ):
        result[field + "_mean"] = float(np.mean(data)) if data else np.nan
        result[field + "_sd"] = float(np.std(data)) if data else np.nan
    return result


def reference_aa(pool, history):
    fields = ("known_shape_weight", "mean", "sd", "mode", "window_mass", "effective_n")
    if not pool:
        return dict(pool_count=0, **{f: np.nan for f in fields})
    count = len(pool)
    observed = Counter(tuple(r["shape"]) for r in history if r["shape"] is not None)
    weights = np.zeros(count)
    support = 0.0
    for signature, frequency in observed.items():
        selected = [i for i, r in enumerate(pool) if r["shape"] is not None and tuple(r["shape"]) == signature]
        probability = frequency / sum(observed.values())
        support += probability * bool(selected)
        for i in range(count):
            weights[i] += probability * ((3 / count + (i in selected)) / (len(selected) + 3))
    if not observed:
        weights.fill(1 / count)
    weights /= weights.sum()
    values = np.array([r["aa"] for r in pool])
    centres = sorted(set([*values, *(values - 7), *(values + 7)]))
    masses = [sum(w for v, w in zip(values, weights, strict=True) if abs(v - c) <= 7) for c in centres]
    largest = max(masses)
    winners = [c for c, m in zip(centres, masses, strict=True) if abs(m - largest) <= 1e-12]
    order = np.argsort(values, kind="stable")
    median = values[order[np.searchsorted(np.cumsum(weights[order]) + 1e-12, 0.5, side="left")]]
    mode = min(winners, key=lambda c: (abs(c - median), c))
    mean = float(sum(v * w for v, w in zip(values, weights, strict=True)))
    variance = sum(w * (v - mean) ** 2 for v, w in zip(values, weights, strict=True))
    return dict(
        pool_count=count,
        known_shape_weight=support if observed else np.nan,
        mean=mean,
        sd=float(np.sqrt(variance)),
        mode=float(mode),
        window_mass=float(largest),
        effective_n=float(1 / sum(weights**2)),
    )


def independent_features(rows, games, records):
    by_game = {g["id"]: g for g in games}
    clubs, people = defaultdict(list), defaultdict(list)
    for r in sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["club"])):
        clubs[r["club"]].append(r)
        for label in r["labels"]:
            people[label["player"], r["club"], label["pos"], label["cohort"]].append({**label, "date": r["date"]})
    club_dates = {k: [moment(r["date"]).timestamp() for r in v] for k, v in clubs.items()}
    people_dates = {k: [moment(r["date"]).timestamp() for r in v] for k, v in people.items()}
    output = np.full((len(rows), len(shape.NAMES)), np.nan)
    for i, row in enumerate(rows):
        lock = cutoff_for(row["date"]).timestamp()
        first, end = lock - 365 * 86400, lock - 172800
        g = by_game[row["game"]]
        own = g["players"][row["player"]]["team"]
        other = g["away"]["slug"] if own == g["home"]["slug"] else g["home"]["slug"]
        histories, features = {}, {}
        for side, club in (("own", own), ("opponent", other)):
            dates = club_dates.get(club, [])
            history = clubs.get(club, [])[bisect_left(dates, first) : bisect_left(dates, end)]
            histories[side] = history
            for n in (3, 10):
                features.update({f"shape_{side}_{n}_{f}": v for f, v in reference_team(history[-n:]).items()})
            for name, field in (("last_xi", "xi"), ("last_shape", "shape")):
                known = [r for r in history if r[field] is not None]
                features[f"shape_{side}_{name}_days_to_lock"] = (
                    (lock - moment(known[-1]["date"]).timestamp()) / 86400 if known else np.nan
                )
        identity = row["player"], own, row["pos"], row["cohort"]
        dates = people_dates.get(identity, [])
        pool = people.get(identity, [])[bisect_left(dates, first) : bisect_left(dates, end)][-20:]
        all_starts = [r for r in histories["own"] if r["xi"] is not None and row["player"] in r["xi"]]
        for n in (3, 10):
            recent = histories["own"][-n:]
            xis = [r for r in recent if r["xi"] is not None]
            starts = [r for r in xis if row["player"] in r["xi"]]
            latest = set(xis[-1]["xi"]) - {row["player"]} if xis else set()
            overlap = [len((set(r["xi"]) - {row["player"]}).intersection(latest)) / 10 for r in starts]
            individual = dict(
                start_fraction=len(starts) / len(xis) if xis else np.nan,
                latest_xi_starter=int(row["player"] in recent[-1]["xi"])
                if recent and recent[-1]["xi"] is not None
                else np.nan,
                usual_unit_overlap=float(np.mean(overlap)) if overlap else np.nan,
                last_start_days_to_lock=(lock - moment(all_starts[-1]["date"]).timestamp()) / 86400
                if all_starts
                else np.nan,
            )
            features.update({f"shape_player_{n}_{f}": v for f, v in individual.items()})
            features.update({f"shape_aa_{n}_{f}": v for f, v in reference_aa(pool, recent).items()})
        output[i] = [features[n] for n in shape.NAMES]
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "features", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    games, digest = [], hashlib.sha256()
    for line in args.games.open("rb"):
        digest.update(line)
        if line.strip():
            g = json.loads(line)
            slim = {k: g[k] for k in ("id", "date", "home", "away", "xi")}
            slim["players"] = {
                p: {k: r.get(k) for k in ("team", "pos", "played", "started", "ver", "aa", "score")}
                for p, r in g["players"].items()
            }
            games.append(slim)
    corpus = json.loads(gzip.decompress(args.features.with_suffix(".observations.json.gz").read_bytes()))
    records = parse_native(games)
    if (
        corpus["records"] != records
        or digest.hexdigest() != corpus["sourceSha256"]
        or digest.hexdigest() != report["sourceSha256"]
    ):
        raise ValueError("Independent native team-shape/AA source differs")
    label_map = {(r["game"], label["player"]): label for r in records for label in r["labels"]}
    if len(label_map) != len(source["rows"]):
        raise ValueError("Native AA known-case coverage differs")
    for row in source["rows"]:
        label = label_map[row["game"], row["player"]]
        if any(label[f] != row[f] for f in ("aa", "pos", "cohort")):
            raise ValueError("Independent native AA/cohort/card-position identity differs")
    key = hashlib.sha256(
        (source["key"] + digest.hexdigest()).encode()
        + Path(shape.__file__).read_bytes()
        + Path(score_search.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    with np.load(args.features) as f:
        x = f["x"]
        if str(f["key"]) != key or tuple(f["names"]) != shape.NAMES or x.shape != (38850, 102):
            raise ValueError("Team-shape cache/schema/fingerprint differs")
    if report["featureKey"] != key or corpus["key"] != key or report["sourceKey"] != source["key"]:
        raise ValueError("Team-shape report source identity differs")
    print("TEAM_SHAPE_AUDIT independent38850x102", flush=True)
    repeated = independent_features(source["rows"], games, records)
    same = np.isclose(x, repeated, equal_nan=True, atol=1e-10, rtol=0)
    if not same.all():
        changed = np.argwhere(~same)
        details = [(int(i), shape.NAMES[j], float(x[i, j]), float(repeated[i, j])) for i, j in changed[:20]]
        raise ValueError(f"Independent team-shape features differ in{len(changed)}cells: {details}")
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    selected = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    mutated = copy.deepcopy(games)
    changed_games = changed_labels = 0
    for g in mutated:
        if moment(g["date"]).timestamp() + 172800 >= first.timestamp():
            g["xi"] = {}
            changed_games += 1
            for p in g["players"].values():
                p.update(aa=np.nan, score=np.nan, started=None, minutes=-999, level=999)
                changed_labels += 1
    rows = [{**source["rows"][i], "aa": np.nan, "score": np.nan, "level": np.nan, "minutes": np.nan} for i in selected]
    causal = shape.build_features(rows, mutated)
    if not np.array_equal(causal, x[selected], equal_nan=True):
        raise ValueError("Unavailable/current shape/AA/score/XI mutation changes prelock features")
    result = dict(
        scope="Testing-only full native source/feature/time audit, no prediction accuracy claim",
        featureKey=key,
        nativeTeamSides=len(records),
        verifiedNativeXISides=sum(r["xi"] is not None for r in records),
        verifiedNativeShapeSides=sum(r["shape"] is not None for r in records),
        nativeAALabelsExactlyMatched=len(label_map),
        independentFeatureRows=len(x),
        featureColumns=102,
        all102ColumnsReproduced=True,
        absoluteTolerance=1e-10,
        currentFutureFixtureXIsMutated=changed_games,
        currentFutureOutcomeRecordsMutated=changed_labels,
        sameFirstLockCasesUnchanged=len(selected),
        all6754Starts2925PlayedSubsRetained=True,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
