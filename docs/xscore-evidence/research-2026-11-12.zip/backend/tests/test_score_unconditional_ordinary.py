from pathlib import Path

import numpy as np
import pytest

from app.research.score_unconditional_ordinary import fit_quantiles


def test_real_unconditional_quantiles_exclude_future_aa_and_repeat_across_classes(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    x = np.column_stack((np.arange(220) % 17, np.arange(220) % 3)).astype(float)
    aa = np.sin(x[:, 0]) * 5 + x[:, 1] * 2
    positions = np.array(["DEF"] * 220)
    fit, target = np.arange(220) < 160, np.arange(220) >= 160
    first, diagnostics = fit_quantiles(x, aa, positions, fit, target, np.array([35, 60]), "pooled")
    aa[target] = np.nan
    repeated, _ = fit_quantiles(x, aa, positions, fit, target, np.array([35, 60]), "pooled")
    for q in first:
        np.testing.assert_equal(first[q], repeated[q])
        np.testing.assert_equal(first[q][:, 0], first[q][:, 1])
    assert not diagnostics["DSLabelsPassedToAARegressor"] and diagnostics["targetCases"] == 60


def test_sparse_and_cold_position_fallback_retains_every_forecast(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    x = np.arange(150.0)[:, None]
    aa = x[:, 0] % 13
    positions = np.array(["DEF"] * 60 + ["MID"] * 60 + ["FWD"] * 30)
    fit, target = np.arange(150) < 120, np.arange(150) >= 120
    output, diagnostics = fit_quantiles(x, aa, positions, fit, target, np.array([35, 60, 70]), "position")
    assert diagnostics["pooledFallbackPositions"] == ["FWD"]
    assert diagnostics["fitCasesByTargetPosition"]["FWD"] == 0
    assert all(a.shape == (30, 3) and np.isfinite(a).all() for a in output.values())
    with pytest.raises(ValueError, match="Declared"):
        fit_quantiles(x, aa, positions, fit, target, np.array([35]), "unknown")
