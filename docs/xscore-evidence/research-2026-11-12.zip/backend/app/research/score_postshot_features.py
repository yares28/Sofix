"""Testing-only strictly lagged native history and provider finishing quality."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

BASE = (
    "native_games",
    "native_minutes",
    "native_sot90",
    "native_goals90",
    "known_games",
    "known_minutes",
    "source_minutes_fraction",
    "qualified_sot90",
    "paired_preshot_per_sot",
    "age_days",
)
EXTRA = ("postshot_per_sot", "postshot90")


def build_features(rows, games, records):
    source = {(r["game"], r["player"]): r for r in records}
    if len(source) != len(records) or len({g["id"] for g in games}) != len(games):
        raise ValueError("Duplicate source/native observation")
    schedule = sorted(games, key=lambda g: (g["date"], g["id"]))
    histories = defaultdict(list)
    names = [f"postshot_{n}_{field}" for n in (3, 10) for field in (*BASE, *EXTRA)]
    x, cursor, previous = [], 0, None
    profiles = {}
    audit = dict(rows=len(rows), nativePastObservations=0, unknownPastSource=0, coldRows=0)
    for row in rows:
        lock = cutoff_for(row["date"])
        if previous is not None and lock < previous:
            raise ValueError("Post-shot target rows must be chronological")
        if lock != previous:
            profiles.clear()
            previous = lock
        while cursor < len(schedule) and moment(schedule[cursor]["date"]) + timedelta(hours=48) < lock:
            g = schedule[cursor]
            for player, p in g["players"].items():
                minutes = p.get("mins")
                if (
                    p.get("played") is not True
                    or p.get("pos") not in ("GK", "DEF", "MID", "FWD")
                    or p.get("ver") != 7
                    or not isinstance(p.get("stats"), dict)
                    or type(minutes) not in (int, float)
                    or not np.isfinite(minutes)
                    or minutes < 0
                ):
                    continue
                r = source.get((g["id"], player))
                sot, goals = (float(p["stats"].get(k, [0, 0])[0]) for k in ("ontarget_scoring_att", "goals"))
                known = r is not None and r["known"]
                if known and (r["date"] != g["date"] or r["minutes"] != minutes or r["nativeSOT"] != sot):
                    raise ValueError("Qualified past source/native exposure differs")
                histories[player].append(
                    dict(date=moment(g["date"]), minutes=minutes, sot=sot, goals=goals, source=r if known else None)
                )
                audit["nativePastObservations"] += 1
                audit["unknownPastSource"] += not known
            cursor += 1
        player = row["player"]
        if player not in profiles:
            recent = [r for r in histories[player] if lock - r["date"] <= timedelta(days=365)]
            value = []
            for size in (3, 10):
                selected = recent[-size:]
                known = [r for r in selected if r["source"] is not None]
                minutes = sum(r["minutes"] for r in selected)
                sot = sum(r["sot"] for r in selected)
                goals = sum(r["goals"] for r in selected)
                known_minutes = sum(r["minutes"] for r in known)
                known_sot = sum(r["sot"] for r in known)
                quality = sum(r["source"]["postshotTotal"] for r in known)
                pairs = [r for r in known if r["source"]["matchedPreshotTotal"] is not None]
                paired_sot = sum(r["sot"] for r in pairs)
                before = sum(r["source"]["matchedPreshotTotal"] for r in pairs)
                positive = [r for r in known if r["sot"] > 0]
                value.extend(
                    [
                        len(selected),
                        minutes,
                        sot * 90 / minutes if minutes else np.nan,
                        goals * 90 / minutes if minutes else np.nan,
                        len(known),
                        known_minutes,
                        known_minutes / minutes if minutes else 0.0,
                        known_sot * 90 / known_minutes if known_minutes else np.nan,
                        before / paired_sot if paired_sot else np.nan,
                        (lock - positive[-1]["date"]).total_seconds() / 86400 if positive else np.nan,
                        quality / known_sot if known_sot else np.nan,
                        quality * 90 / known_minutes if known_minutes else np.nan,
                    ]
                )
            profiles[player] = value
        audit["coldRows"] += profiles[player][0] == 0
        x.append(profiles[player])
    return np.array(x), names, audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_postshot_features.json"))
    args = parser.parse_args()
    source = json.loads((args.cache / "cases.json").read_text())
    raw, observations = args.games.read_bytes(), (args.cache / "postshot_observations.json.gz").read_bytes()
    if (
        hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(observations).hexdigest()
        != "8aed062f076105d35eb99a9e3234321d840b05dbe960702ed6ed68dd0a1c1bcf"
    ):
        raise ValueError("Pinned post-shot/native input changed")
    audit_path = args.out.parent / "laliga_score_postshot_probe.integrity.json"
    receipt = json.loads(audit_path.read_text())
    if receipt["independentPlayerQualification"] != 34871 or receipt["everyRawShotVerified"] != 29915:
        raise ValueError("Independent complete source qualification required")
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    observed = json.loads(gzip.decompress(observations))
    if observed["key"] != receipt["implementationKey"]:
        raise ValueError("Qualified source identity differs")
    x, names, audit = build_features(source["rows"], games, observed["records"])
    if x.shape != (38850, 24):
        raise ValueError("Full native post-shot case/feature coverage changed")
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + observations
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    path = args.cache / "postshot_features.npz"
    np.savez_compressed(path, key=key, source_key=source["key"], x=x, names=names)
    report = dict(
        scope="Lagged finishing-quality input stage, no target-outcome comparisons",
        featureKey=key,
        sourceKey=source["key"],
        qualifiedSourceKey=observed["key"],
        qualifiedSourceSHA=hashlib.sha256(observations).hexdigest(),
        featuresSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        sourceAuditSHA=hashlib.sha256(audit_path.read_bytes()).hexdigest(),
        rows=len(x),
        columns=len(names),
        baselineColumns=20,
        newQualityColumns=4,
        audit=audit,
        knownByColumn={n: int(np.isfinite(x[:, j]).sum()) for j, n in enumerate(names)},
        next="Independent all24column/strict availability/future mutation audit before goal signal fits",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print("POSTSHOT_FEATURES " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
