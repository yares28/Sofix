import numpy as np

from app.research import score_empirical_density as empirical
from app.research.score_openplay_shared_flow import CENTRES, score_mass
from app.research.score_openplay_shared_flow_features import fixture_runs, team_modes
from app.research.score_windows import window_centres


def test_open_play_runs_do_not_cross_stoppages_ties_or_halves():
    def event(t, kind="complete", team="home", period="FirstHalf", x=50, end=70):
        return {"tick": str(t), "kind": kind, "team": team, "period": period, "x": str(x), "end_x": str(end)}

    source = [
        event(0),
        event(3),
        event(6),
        event(7, "shot"),
        event(11),
        event(13),
        event(14, "break"),
        event(15, "shot"),
        event(17),
        event(19),
        event(19, team="away"),
        event(20, "shot"),
        event(22),
        event(25),
        event(26, "shot", period="SecondHalf"),
    ]
    values, audit = fixture_runs(source, "home", "away")
    np.testing.assert_array_equal(values["home"][1:], [1, 1, 1, 3])
    assert audit["ambiguousActionTicks"] == 1
    assert team_modes(9, 9) == (1, 1)
    assert team_modes(60, 2) == (2, 0)


def test_single_scenario_preserves_reference_scoring_and_decisive_floor():
    classes = np.array([35, 60])
    p = np.array([[0.95, 0.05], [0, 1]])
    parts = {q: np.array([[8.0, 4.0], [3.0, -12.0]]) for q in (0.35, 0.5, 0.65)}
    pool = np.array([-10.0, 0.0, 2.0, 12.0])
    bank = {"mode": "raw", "global": pool, "positions": {}, "levels": {("DEF", 35.0): pool}}
    positions = np.array(["DEF", "MID"])
    mass = score_mass(classes, p, parts, positions, bank)
    np.testing.assert_array_equal(
        window_centres(mass, CENTRES),
        empirical.empirical_predictions(classes, p, parts, positions, bank, 20, 0.75, 0),
    )
    assert not mass[1, CENTRES < 53].any()
