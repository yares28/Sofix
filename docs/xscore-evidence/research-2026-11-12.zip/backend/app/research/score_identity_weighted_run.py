"""Testing-only frozen adapter for population-weighted identity interaction study."""

import hashlib
from pathlib import Path

from app.research import score_identity_interactions as base
from app.research import score_identity_interactions_run as template
from app.research import score_identity_weighted as network

original_key = template.implementation_key


def implementation_key(*args):
    return hashlib.sha256(
        original_key(*args).encode() + Path(__file__).read_bytes() + Path(base.__file__).read_bytes()
    ).hexdigest()


def configure():
    template.network = network
    template.implementation_key = implementation_key
    return template


if __name__ == "__main__":
    configure().main()
