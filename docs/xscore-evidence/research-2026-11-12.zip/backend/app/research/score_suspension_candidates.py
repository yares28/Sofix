"""Schedule and identity linkage for ordinary archived suspension candidates."""

import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import timedelta

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_referee_archive import OFFICIAL_CLUBS, club_key
from app.research.score_search import cutoff_for, moment


def words(value):
    return re.findall(r"[a-z0-9]+", unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower())


def identity_from_record(name, pool):
    base, *aliases = re.split(r'"([^"]+)"', name)
    if "," in base:
        surname, given = base.split(",", 1)
        base = given.strip() + " " + surname.strip()
    names = [words(base), *(words(a) for a in aliases[::2])]
    exact, partial = set(), set()
    for slug in pool:
        tokens = words(slug)
        if any(tokens == n or (len(n) > 1 and sorted(tokens) == sorted(n)) for n in names if n):
            exact.add(slug)
        if any(len(n) >= 2 and min(map(len, n)) >= 2 and " ".join(n) in " ".join(tokens) for n in names):
            for n in names:
                if (
                    len(n) >= 2
                    and min(map(len, n)) >= 2
                    and any(tokens[j : j + len(n)] == n for j in range(len(tokens)))
                ):
                    partial.add(slug)
    if len(exact) == 1:
        return next(iter(exact)), "whole_name"
    if not exact and len(partial) == 1:
        return next(iter(partial)), "unique_multiple_name_tokens"
    return None, "ambiguous_or_missing"


def main():
    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, native.splitlines()), key=lambda g: (g["date"], g["id"]))
    reports = REPORTS / "laliga_score_suspension_ordinary.json"
    ordinary = json.loads(reports.read_text())
    rounds_path = ROOT / "suspension-source/calendar_early_rounds.json"
    calendars = json.loads(rounds_path.read_text())
    games_by_season = {}
    for season, data in calendars.items():
        year = int(season[:4])
        schedule = [g for g in games if f"{year}-07-01" <= g["date"] < f"{year + 1}-07-01"]
        lookup = {(r["home"], r["away"]): r["round"] for r in data["pairs"]}
        assert len(schedule) == len(lookup) == 380
        pairs = {g["id"]: (g["home"]["slug"], g["away"]["slug"]) for g in schedule}
        assert set(pairs.values()) == set(lookup)
        games_by_season[season] = [(g, pairs[g["id"]], lookup[pairs[g["id"]]]) for g in schedule]
    clubs = {club_key(k): v for k, v in OFFICIAL_CLUBS.items()}
    rows = []
    for doc in ordinary["documents"]:
        if doc["status"] != "both_engines":
            continue
        season = doc["season"][:5] + doc["season"][-2:]
        schedule = games_by_season[season]
        issue = moment(doc["sourceTime"])
        for item in doc["rows"]:
            club = clubs.get(club_key(item["printedClub"]))
            base = dict(
                item,
                season=season,
                originRound=doc["round"],
                source=doc["url"],
                sourceAvailable=doc["sourceTime"],
                club=club,
            )
            prior = [(g, rnd) for g, sides, rnd in schedule if club in sides]
            origin = [g for g, rnd in prior if rnd == doc["round"]]
            if len(origin) != 1 or moment(origin[0]["date"]) >= issue:
                rows.append(dict(base, status="origin_fixture_unresolved"))
                continue
            next_game = next((g for g, _ in prior if g["date"] > origin[0]["date"]), None)
            if next_game is None:
                rows.append(dict(base, status="no_later_league_fixture"))
                continue
            lock = cutoff_for(next_game["date"])
            base.update(
                origin=origin[0]["id"],
                originKickoff=origin[0]["date"],
                target=next_game["id"],
                targetKickoff=next_game["date"],
                targetLock=lock.isoformat(),
            )
            if issue >= lock:
                rows.append(dict(base, status="current_document_late"))
                continue
            history = [g for g in games if moment(g["date"]) + timedelta(hours=48) < lock]
            known = {}
            for past in history:
                if lock - moment(past["date"]) > timedelta(days=365):
                    continue
                for p, sheet in past["players"].items():
                    if sheet["played"] is True and sheet["ver"] == 7:
                        known[p] = sheet["team"]
            pool = {p for p, c in known.items() if c == club}
            linked, reason = identity_from_record(item["printedName"], pool)
            if not linked:
                rows.append(dict(base, status="identity_unresolved", identityMethod=reason))
                continue
            rows.append(dict(base, status="pending_amendment_and_appeal_check", player=linked, identityMethod=reason))
    assert len(rows) == ordinary["independentPlayerRows"] == 45
    status = Counter(r["status"] for r in rows)
    result = dict(
        nativeSHA=NATIVE_SHA,
        ordinaryReportSHA=hashlib.sha256(reports.read_bytes()).hexdigest(),
        scheduleSHA=hashlib.sha256(rounds_path.read_bytes()).hexdigest(),
        matchSchedulesVerified=760,
        rows=len(rows),
        statuses=dict(status),
        pendingBySeason=dict(Counter(r["season"] for r in rows if r["status"] == "pending_amendment_and_appeal_check")),
        modelEligible=0,
        limitation="No target participant, score or minutes used in source linkage. Timing and exact schedule joins are provisional "
        "until amendment and appeal evidence is reconciled. No model forecast uses this file yet.",
        candidates=rows,
    )
    (REPORTS / "laliga_score_suspension_candidates.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "candidates"}, indent=2))


if __name__ == "__main__":
    main()
