import copy

import numpy as np

from app.research.score_empirical_density import calibration_split, empirical_predictions, fit_bank


def parts(n):
    return {0.35: np.full((n, 1), -2.0), 0.5: np.zeros((n, 1)), 0.65: np.full((n, 1), 2.0)}


def test_last_october_results_unavailable_at_november_lock_are_embargoed():
    rows = [{"date": date} for date in ("2025-10-25T20:00:00Z", "2025-10-31T20:00:00Z", "2025-11-01T20:00:00Z")]
    fit, select = calibration_split(rows)
    np.testing.assert_array_equal(fit, [True, False, False])
    np.testing.assert_array_equal(select, [False, False, True])


def test_only_calibration_labels_enter_the_error_bank():
    aa = np.array([0.0, 4, 100])
    fit = np.array([True, True, False])
    bank = fit_bank(np.array([35]), parts(3), aa, np.full(3, 35), np.full(3, "MID"), fit, "raw")
    changed = copy.deepcopy(aa)
    changed[2] = -100
    other = fit_bank(np.array([35]), parts(3), changed, np.full(3, 35), np.full(3, "MID"), fit, "raw")
    np.testing.assert_array_equal(bank["global"], other["global"])
    np.testing.assert_array_equal(bank["global"], [0, 4])


def test_asymmetric_residual_peak_does_not_turn_into_its_mean():
    n = 10
    bank = fit_bank(
        np.array([35]),
        parts(n),
        np.array([0] * 7 + [40] * 3),
        np.full(n, 35),
        np.full(n, "MID"),
        np.ones(n, dtype=bool),
        "raw",
    )
    prediction = empirical_predictions(np.array([35]), np.ones((1, 1)), parts(1), np.array(["MID"]), bank, 20, 1, 0)
    assert abs(prediction[0] - 35) <= 7
    assert prediction[0] < 45


def test_unseen_position_and_level_fall_back_without_dropping_a_case():
    bank = fit_bank(
        np.array([35]), parts(3), np.zeros(3), np.full(3, 35), np.full(3, "MID"), np.ones(3, dtype=bool), "raw"
    )
    p = empirical_predictions(np.array([60]), np.ones((1, 1)), parts(1), np.array(["GK"]), bank, 20, 1, 0)
    assert len(p) == 1
    assert 60 - 7 <= p[0] <= 60 + 7


def test_100_floor_clipping_retains_all_probability():
    bank = fit_bank(
        np.array([35]), parts(3), np.full(3, 40), np.full(3, 35), np.full(3, "MID"), np.ones(3, dtype=bool), "raw"
    )
    p = empirical_predictions(np.array([100]), np.ones((1, 1)), parts(1), np.array(["MID"]), bank, 100, 1, 0)
    assert 93 <= p[0] <= 100
