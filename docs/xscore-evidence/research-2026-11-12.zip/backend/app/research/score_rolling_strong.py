"""Testing only: monthly original conditional components with explicit class support."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_stability as stability
from app.research.score_rolling import month_folds
from app.research.score_stats_hybrid import conditional_components

CLASSES = np.array([0, 5, 15, 35, 60, 70, 80, 90, 100], dtype=float)
QUANTILES = (0.35, 0.5, 0.65)


def aligned(parts):
    classes, p, quantiles = parts
    if (
        not np.isin(classes, CLASSES).all()
        or len(np.unique(classes)) != len(classes)
        or p.shape[1] != len(classes)
        or not np.isfinite(p).all()
        or (p < 0).any()
        or not np.allclose(p.sum(axis=1), 1)
    ):
        raise ValueError("Supported ordered finite conditional classes required")
    probability = np.zeros((len(p), len(CLASSES)))
    known = np.zeros_like(probability, dtype=bool)
    columns = np.searchsorted(CLASSES, classes)
    probability[:, columns] = p
    known[:, columns] = True
    output = {}
    for q in QUANTILES:
        values = quantiles[q]
        if values.shape != p.shape or not np.isfinite(values).all():
            raise ValueError("Known supported AAquantile values required")
        output[q] = np.zeros_like(probability)
        output[q][:, columns] = values
    return (CLASSES.copy(), probability, output), known


def rolling_parts(x, rows, aa, levels, selected, window, cache, key, label):
    probability = np.zeros((len(rows), len(CLASSES)))
    quantiles = {q: np.zeros_like(probability) for q in QUANTILES}
    known = np.zeros_like(probability, dtype=bool)
    coverage = np.zeros(len(rows), dtype=int)
    receipt = []
    for fit, check, anchor in month_folds(rows, selected, window):
        identity = hashlib.sha256(np.packbits(fit).tobytes() + np.packbits(check).tobytes()).hexdigest()
        path = cache / f"{label}_{anchor[:10]}_{identity[:12]}_{key[:12]}.npz"
        if path.exists():
            with np.load(path) as f:
                if str(f["key"]) != key or str(f["maskKey"]) != identity:
                    raise ValueError("Monthly strong component cache identity differs")
                parts = f["classes"], f["probability"], {q: f[f"q{q}"] for q in QUANTILES}
        else:
            parts = conditional_components(x, aa, levels, fit, check)
            np.savez_compressed(
                path,
                key=key,
                maskKey=identity,
                classes=parts[0],
                probability=parts[1],
                **{f"q{q}": value for q, value in parts[2].items()},
            )
        padded, supported = aligned(parts)
        if len(padded[1]) != int(check.sum()):
            raise ValueError("Monthly strong forecast coverage differs")
        probability[check], known[check] = padded[1], supported
        for q in QUANTILES:
            quantiles[q][check] = padded[2][q]
        coverage[check] += 1
        receipt.append(
            {
                "anchor": anchor,
                "fit": int(fit.sum()),
                "target": int(check.sum()),
                "classes": parts[0].tolist(),
                "maskKey": identity,
                "cache": path.name,
            }
        )
        print(f"STRONG_MONTH {label} window{window} {anchor[:10]} fit{fit.sum()} target{check.sum()}", flush=True)
    if (
        not np.all(coverage[selected] == 1)
        or coverage[~selected].any()
        or not np.isfinite(probability[selected]).all()
        or not np.allclose(probability[selected].sum(axis=1), 1)
    ):
        raise ValueError("Monthly strong cases lost, duplicated or invalid")
    return (
        (CLASSES.copy(), probability[selected], {q: values[selected] for q, values in quantiles.items()}),
        known[selected],
        receipt,
    )


def combine(old, old_known, new, new_known, policy):
    if policy not in ("ordinary", "events", "both") or not np.array_equal(old[0], new[0]):
        raise ValueError("Aligned class supports and declared component policy required")
    probability = new[1] if policy in ("events", "both") else old[1]
    chosen, fallback = (new, old) if policy in ("ordinary", "both") else (old, new)
    chosen_known, fallback_known = (new_known, old_known) if policy in ("ordinary", "both") else (old_known, new_known)
    quantiles = {q: np.where(chosen_known, chosen[2][q], fallback[2][q]) for q in QUANTILES}
    known = chosen_known | fallback_known
    if ((probability > 0) & ~known).any():
        raise ValueError("Positive forecast class has no supported AA model")
    return (old[0], probability, quantiles), known


def bank_from(parts, known, rows, first):
    if known.shape != parts[1].shape or len(rows) != len(known):
        raise ValueError("Monthly calibration support identity differs")
    levels = np.array([r["level"] for r in rows])
    actual_columns = np.searchsorted(CLASSES, levels)
    if not np.isin(levels, CLASSES).all():
        raise ValueError("Unknown native score level")
    supported = known[np.arange(len(rows)), actual_columns]
    available = stability.previous_bank_mask(rows, first)
    mask = supported & available
    bank = empirical.fit_bank(
        parts[0], parts[2], np.array([r["aa"] for r in rows]), levels, np.array([r["pos"] for r in rows]), mask, "raw"
    )
    return bank, {"cases": int(mask.sum()), "unknownAvailableClassLabels": int((available & ~supported).sum())}
