"""Independent raw pass-coordinate and complete lagged-feature verification."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from functools import lru_cache
from pathlib import Path

import numpy as np

from app.research import score_pass_geometry_corrected as repaired
from app.research.score_search import cutoff_for, moment

FIELDS = (
    "usage_progressive90",
    "usage_box_passes90",
    "usage_pass_x",
    "usage_pass_edge",
    "usage_pass_x_sd",
    "usage_attacking_fraction",
    "usage_central_fraction",
)


def raw_geometry(events, minutes):
    result = dict.fromkeys(FIELDS)
    if events is None:
        return result
    valid = []
    for event in events:
        coordinate = [event.get(name) for name in ("x", "y", "ex", "ey")]
        if all(type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 100 for value in coordinate):
            valid.append(coordinate)
    if len(valid) == len(events) and minutes > 0:
        result["usage_progressive90"] = 90 * sum(p[2] - p[0] >= 15 for p in valid) / minutes
        result["usage_box_passes90"] = 90 * sum(p[2] >= 83 and 21 <= p[3] <= 79 for p in valid) / minutes
    if valid:
        xmean = math.fsum(p[0] for p in valid) / len(valid)
        result.update(
            usage_pass_x=xmean,
            usage_pass_edge=math.fsum(2 * abs(p[1] - 50) for p in valid) / len(valid),
            usage_pass_x_sd=math.sqrt(math.fsum((p[0] - xmean) ** 2 for p in valid) / len(valid)),
            usage_attacking_fraction=sum(p[0] >= 200 / 3 for p in valid) / len(valid),
            usage_central_fraction=sum(abs(p[1] - 50) <= 20 for p in valid) / len(valid),
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_pass_geometry_corrected.json")
    )
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    source = json.loads((args.cache / "cases.json").read_text())
    compressed = (args.cache / "pass_geometry_corrected_observations.json.gz").read_bytes()
    if hashlib.sha256(compressed).hexdigest() != report["observationsSha256"]:
        raise ValueError("Repaired observations changed")
    decoded = json.loads(gzip.decompress(compressed))
    expected = hashlib.sha256(
        report["legacyKey"].encode()
        + Path(repaired.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if decoded["key"] != expected or report["implementationKey"] != expected or source["key"] != report["sourceKey"]:
        raise ValueError("Repaired source/implementation key differs")
    observations = decoded["records"]
    old = json.loads(gzip.decompress((args.cache / "player_context_observations.json.gz").read_bytes()))["records"]
    pressure = json.loads(gzip.decompress((args.cache / "spatial_pressure_observations.json.gz").read_bytes()))
    file_index = {r["game"]: (r["sourcePath"], r["sourceBlob"]) for r in pressure["observations"]}

    @lru_cache(maxsize=8)
    def source_passes(game_id):
        path, blob = file_index[game_id]
        canonical = (args.repo / path).read_bytes().replace(b"\r\n", b"\n")
        digest = hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest()
        if digest != blob:
            raise ValueError("Raw pass-source blob changed")
        detail = json.loads(canonical.decode().partition("=")[2].strip().removesuffix(";"))
        grouped = defaultdict(list)
        events = detail.get("passes")
        if isinstance(events, list):
            for event in events:
                name = tuple(re.findall("[a-z]+", event.get("player", "").lower()))
                grouped[event.get("team"), name].append(event)
        return events is not None, grouped

    raw_values, raw_checked = {}, 0
    if len(observations) != len(old) or len(observations) != 34871:
        raise ValueError("Source observation coverage changed")
    for record, original in zip(observations, old, strict=True):
        if any(record[k] != original[k] for k in ("game", "date", "player", "club", "cohort", "minutes")):
            raise ValueError("Original native source identities changed")
        game = games[record["game"]]
        person = game["players"][record["player"]]
        if (
            person["ver"] != 7
            or not person["played"]
            or person["started"] != (record["cohort"] == "start")
            or person["team"] != record["club"]
            or person["mins"] != record["minutes"]
            or game["date"] != record["date"]
        ):
            raise ValueError("Native repaired-source identity differs")
        meta = record["geometrySource"]
        side = "home" if game["home"]["slug"] == record["club"] else "away"
        known, by_person = source_passes(record["game"])
        name = tuple(re.findall("[a-z]+", (meta["player"] or "").lower()))
        events = by_person[side, name] if known else None
        if known != meta["passStreamKnown"] or (len(events) if known else None) != meta["passCount"]:
            raise ValueError("Native source pass-list attribution differs")
        independent = raw_geometry(events, record["minutes"])
        for field in FIELDS:
            left, right = independent[field], record["values"][field]
            if (left is None) != (right is None) or (left is not None and abs(left - right) > 1e-10):
                raise ValueError("Independent native pass geometry differs: " + field)
        for field in set(original["values"]) - set(FIELDS):
            if record["values"][field] != original["values"][field]:
                raise ValueError("An unaffected native value changed")
        raw_values[record["game"], record["player"]] = independent
        raw_checked += 1
    path = args.cache / "pass_geometry_corrected_features.npz"
    if hashlib.sha256(path.read_bytes()).hexdigest() != report["featuresSha256"]:
        raise ValueError("Repaired feature archive changed")
    with np.load(path) as f:
        if str(f["key"]) != report["featureKey"]:
            raise ValueError("Repaired feature key differs")
        x, names, selected = f["x"], f["names"].tolist(), f["geometry"]
    by_player = defaultdict(list)
    for record in observations:
        by_player[record["player"]].append(record)
    for records in by_player.values():
        records.sort(key=lambda r: r["date"])
    times = {
        p: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in records] for p, records in by_player.items()
    }
    independent = np.full((len(source["rows"]), int(selected.sum())), np.nan)
    columns = np.flatnonzero(selected)
    subindex = {names[column]: j for j, column in enumerate(columns)}
    for i, row in enumerate(source["rows"]):
        lock = cutoff_for(row["date"])
        n = bisect_left(times.get(row["player"], []), lock.timestamp())
        history = [
            r for r in by_player.get(row["player"], [])[:n] if (lock - moment(r["date"])).total_seconds() <= 365 * 86400
        ]
        same = [r for r in history if r["cohort"] == row["cohort"]]
        for prefix, group in (("same_3", same[-3:]), ("same_10", same[-10:]), ("all_3", history[-3:])):
            for field in FIELDS:
                known = [
                    (raw_values[r["game"], r["player"]][field], r["minutes"])
                    for r in group
                    if raw_values[r["game"], r["player"]][field] is not None and r["minutes"] > 0
                ]
                total = sum(minutes for _, minutes in known)
                mean = math.fsum(value * minutes for value, minutes in known) / total if total else np.nan
                independent[i, subindex[prefix + "_" + field + "_mean"]] = mean
                independent[i, subindex[prefix + "_" + field + "_count"]] = len(known)
    np.testing.assert_allclose(independent, x[:, selected], rtol=0, atol=1e-10, equal_nan=True)
    with np.load(args.cache / "player_context_features.npz") as f:
        np.testing.assert_array_equal(x[:, ~selected], f["x"][:, ~selected])
    later = [r for r in source["rows"] if r["date"] >= "2026-01-01"]
    first_lock = min(cutoff_for(r["date"]) for r in later)
    test_indices = [
        i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first_lock
    ]
    changed = []
    mutations = 0
    for record in observations:
        copy = {**record, "values": record["values"].copy()}
        if moment(record["date"]) + timedelta(hours=48) >= first_lock:
            for field in FIELDS:
                copy["values"][field] = 1e6
            mutations += 1
        changed.append(copy)
    subset = [source["rows"][i] for i in test_indices]
    mutated, mutated_names, _ = repaired.recent_features(subset, changed, games)
    if mutated_names != names:
        raise ValueError("Future-label mutation changed source schema")
    np.testing.assert_array_equal(mutated, x[test_indices])
    output = dict(
        implementationKey=expected,
        featureKey=report["featureKey"],
        nativeSourceObservationsVerified=raw_checked,
        independentlyRecomputedRawGeometryFields=len(FIELDS),
        independentlyRecomputedFeatureRows=len(source["rows"]),
        independentlyRecomputedGeometryColumns=int(selected.sum()),
        unchangedOtherFeatureColumns=int((~selected).sum()),
        actualFutureMutation=dict(
            firstLock=first_lock.isoformat(),
            targetRows=len(test_indices),
            unavailableObservationsChanged=mutations,
            all166columnsExact=True,
        ),
        scope="Repaired input math/source/lag verification only; no formula accuracy or50percent claim",
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("GEOMETRY_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
