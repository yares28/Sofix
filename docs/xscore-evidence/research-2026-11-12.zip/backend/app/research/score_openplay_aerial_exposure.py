"""Forecast likely aerial opponents from earlier paired contest locations."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_duel_game_spread import intervals
from app.research.score_openplay_duel_features import chance, rating_at, read_contests, zone
from app.research.score_openplay_duel_signal import native_archive
from app.research.score_opposition_strength import DEPTH, PHASES
from app.research.score_search import cutoff_for, moment

ROLES = {p: i for i, p in enumerate(DEPTH)}
ARMS = ("broadRoster", "learnedRoleAndZone", "personalAerialInvolvement")
OTHER = ""


def normalized(values):
    return values / values.sum(axis=-1, keepdims=True)


class History:
    def __init__(self):
        self.lineups = defaultdict(lambda: deque(maxlen=3))
        self.appearances = defaultdict(lambda: deque(maxlen=30))
        self.pairs_by_role_zone = np.zeros((3, 3, 3))
        self.role_counts = np.zeros((3, 3))
        self.role_minutes = np.zeros(3)
        self.ratings = {}

    def observe(self, game, records, available):
        members = {
            player: (p["team"], p["pos"], p["mins"])
            for player, p in game["players"].items()
            if p.get("played") is True and p.get("pos") in ROLES and p.get("mins") is not None and p["mins"] > 0
        }
        for side in ("home", "away"):
            club = game[side]["slug"]
            self.lineups[club].append(
                (available, [(p, pos, mins) for p, (team, pos, mins) in members.items() if team == club])
            )
        observed = {}
        updates = defaultdict(lambda: [0.0, 0])
        for kind, x, _clubs, (winner, loser) in records:
            for actor in (winner, loser):
                if actor in members:
                    observed.setdefault(actor, np.zeros(3))
            if kind != 0:
                continue
            for actor, opponent, coordinate in ((winner, loser, x), (loser, winner, 100 - x)):
                if actor not in members:
                    continue
                third = zone(coordinate)
                observed[actor][third] += 1
                role = ROLES[members[actor][1]]
                if opponent in members:
                    self.pairs_by_role_zone[role, third, ROLES[members[opponent][1]]] += 1
            if winner in members and loser in members:
                left = rating_at(self.ratings, winner, available) or 0.0
                right = rating_at(self.ratings, loser, available) or 0.0
                change = 1 - chance(left - right)
                for actor, delta in ((winner, change), (loser, -change)):
                    updates[actor][0] += delta
                    updates[actor][1] += 1
        for actor, (change, n) in updates.items():
            previous = rating_at(self.ratings, actor, available) or 0.0
            self.ratings[actor] = previous + 0.22 * change / np.sqrt(n), available
        for actor, count in observed.items():
            _, role, minutes = members[actor]
            self.appearances[actor].append((available, count, minutes))
            self.role_counts[ROLES[role]] += count
            self.role_minutes[ROLES[role]] += minutes

    def player_history(self, player, after):
        past = [(count, minutes) for at, count, minutes in self.appearances[player] if at >= after]
        return (np.sum([c for c, _ in past], axis=0), sum(m for _, m in past)) if past else (np.zeros(3), 0)

    def forecast(self, player, pos, opponent, lock):
        if pos not in ROLES:
            return None
        after = lock - timedelta(days=120) + timedelta(hours=48)
        roster = defaultdict(lambda: np.zeros(3))
        for available, participants in self.lineups[opponent]:
            if available >= after:
                for rival, role, minutes in participants:
                    if rival != player:
                        roster[rival][ROLES[role]] += minutes
        if not roster:
            return None
        identities = list(roster)
        minutes = np.stack(list(roster.values()))
        idx = ROLES[pos]
        broad = minutes @ (1 / (0.25 + np.abs(DEPTH[pos] + np.array(list(DEPTH.values())) - 1.2)))
        p_broad = normalized(broad)
        role_rate = (self.role_counts + 10) / (self.role_minutes[:, None] + 900)
        focal_counts, exposure = self.player_history(player, after)
        location = normalized(focal_counts + 8 * normalized(role_rate[idx]))
        background = normalized(self.pairs_by_role_zone.sum(axis=0) + 12)
        opponent_roles = normalized(self.pairs_by_role_zone[idx] + 30 * background)
        lift = (opponent_roles / background).T
        zonal_rates = role_rate[:, ::-1] * lift
        roles = minutes @ zonal_rates
        typical = minutes @ role_rate[:, ::-1]
        individual = []
        for rival, row, mean_rate in zip(identities, minutes, typical, strict=True):
            counts, total = self.player_history(rival, after)
            prior = mean_rate / row.sum()
            rate = (counts[::-1] + prior * 450) / (total + 450)
            individual.append(rate / prior)
        by_role = location @ normalized(roles.T)
        by_person = location @ normalized((roles * np.stack(individual)).T)
        if not self.pairs_by_role_zone[idx].any():
            by_role = by_person = p_broad
        weights = np.column_stack((p_broad, by_role, by_person))
        probabilities = np.vstack((0.9 * weights, np.full(3, 0.1)))
        own_rating = rating_at(self.ratings, player, lock) or 0.0
        rival_ratings = [rating_at(self.ratings, p, lock) or 0.0 for p in identities] + [0.0]
        predicted_win = chance(own_rating - np.array(rival_ratings)) @ probabilities
        rates = (focal_counts.sum() + role_rate[idx].sum() * 450) / (exposure + 450)
        return identities + [OTHER], probabilities, predicted_win, rates * 90


def rolling_forecasts(rows, games, contests):
    schedule = sorted((moment(g["date"]) + timedelta(hours=48), key) for key, g in games.items())
    indices = sorted((cutoff_for(row["date"]), i) for i, row in enumerate(rows))
    result = [None] * len(rows)
    history, cursor = History(), 0
    for lock, index in indices:
        while cursor < len(schedule) and schedule[cursor][0] < lock:
            available, game_id = schedule[cursor]
            history.observe(games[game_id], contests.get(game_id, ()), available)
            cursor += 1
        row = rows[index]
        game = games[row["game"]]
        club = game["players"][row["player"]]["team"]
        sides = game["home"]["slug"], game["away"]["slug"]
        if club not in sides or row["date"] != game["date"]:
            raise ValueError("Target side or fixture differs")
        opponent = sides[1 - sides.index(club)]
        result[index] = history.forecast(row["player"], row["pos"], opponent, lock)
    return result


def row_vectors(forecasts):
    return np.array([np.r_[f[2], f[3]] if f is not None else np.full(4, np.nan) for f in forecasts])


def earlier_metrics(rows, games, contests, forecasts):
    native = {(row["game"], row["player"]): (row, f) for row, f in zip(rows, forecasts, strict=True)}
    seasons = {}
    all_gains, all_weeks, phase_gains = defaultdict(list), defaultdict(list), defaultdict(list)
    for phase, begin, end in PHASES:
        counts, groups = Counter(), defaultdict(list)
        for game_id, events in contests.items():
            if not begin <= games[game_id]["date"] < end:
                continue
            for kind, _x, _clubs, actors in events:
                if kind != 0:
                    continue
                counts["allPairs"] += 1
                if None in actors:
                    counts["unknownParticipantPairs"] += 1
                    continue
                for lost, (actor, other) in enumerate(zip(actors, actors[::-1], strict=True)):
                    entry = native.get((game_id, actor))
                    if entry is None or entry[0]["pos"] not in ROLES:
                        counts["missingOutfieldCase"] += 1
                        continue
                    row, forecast = entry
                    if forecast is None:
                        counts["noRoster"] += 1
                        ids = [OTHER]
                        probability, wins = np.ones((1, 3)), np.full(3, 0.5)
                    else:
                        ids, probability, wins, _ = forecast
                    hit = ids.index(other) if other in ids else len(ids) - 1
                    counts["outsideRoster"] += hit == len(ids) - 1
                    counts["scoredActorPairs"] += 1
                    metrics = np.vstack(
                        (-np.log(probability[hit]), probability.argmax(axis=0) == hit, (wins - (1 - lost)) ** 2)
                    ).T
                    scopes = [row["cohort"] + "AllOutfield"]
                    if row["pos"] == "DEF" or row["cohort"] == "bench":
                        scopes.append(row["cohort"] + "Primary")
                    for name in scopes:
                        groups[name].append((row["week"], metrics))
        report = {}
        for group, cases in groups.items():
            weeks = np.array([week for week, _ in cases])
            array = np.stack([stats for _, stats in cases])
            gain = array[:, :1, [0, 2]] - array[:, 1:, [0, 2]]
            all_gains[group].append(gain.reshape(-1, 4))
            all_weeks[group].append(weeks)
            phase_gains[group].append(gain.mean(axis=0))
            report[group] = {
                "actorPairs": len(array),
                "rivalLogLossTop1WinnerBrier": dict(zip(ARMS, array.mean(axis=0).tolist(), strict=True)),
            }
        seasons[phase] = {"coverage": dict(counts), "scores": report}
    pooled = {}
    for group, gains in all_gains.items():
        band = intervals(np.concatenate(gains), np.concatenate(all_weeks[group])).reshape(2, 2, 2)
        pooled[group] = {
            "pairedRivalLogLossAndWinnerBrierGain95": dict(zip(ARMS[1:], band.tolist(), strict=True)),
            "passes": {
                name: bool(np.all(band[i, :, 0] > 0) and all(p[i, 0] > 0 for p in phase_gains[group]))
                for i, name in enumerate(ARMS[1:])
            },
        }
    return seasons, pooled


def run(args):
    source = json.loads((args.cache / "cases.json").read_text())
    source_report = json.loads((args.out.parent / "laliga_score_openplay_duel_source.json").read_text())
    if source_report["sourceKey"] != source["key"]:
        raise ValueError("Qualified contest case identity differs")
    rows = source["rows"]
    games = native_archive(args.games)
    directory = args.cache / "openplay-data-v0.1.0"
    contests = read_contests(directory, source_report, games)
    forecasts = rolling_forecasts(rows, games, contests)
    full = row_vectors(forecasts)
    lock = min(cutoff_for(r["date"]) for r in rows if r["date"] >= "2026-01-01")
    selected = [i for i, r in enumerate(rows) if cutoff_for(r["date"]) == lock]
    available = {key for key, game in games.items() if moment(game["date"]) + timedelta(hours=48) < lock}
    filtered = {key: games[key] for key in available}
    for i in selected:
        row = rows[i]
        game = games[row["game"]]
        stub = filtered.setdefault(game["id"], {k: game[k] for k in ("id", "date", "home", "away")} | {"players": {}})
        stub["players"][row["player"]] = {"team": game["players"][row["player"]]["team"]}
    rerun = rolling_forecasts(
        [rows[i] for i in selected], filtered, {k: v for k, v in contests.items() if k in available}
    )
    for i, ref in zip(selected, rerun, strict=True):
        actual = forecasts[i]
        if ref is None:
            assert actual is None
        else:
            assert actual is not None and ref[0] == actual[0]
            np.testing.assert_array_equal(ref[1], actual[1])
    np.testing.assert_array_equal(full[selected], row_vectors(rerun))
    periods, pooled = earlier_metrics(rows, games, contests, forecasts)
    np.savez_compressed(
        directory / "aerial_exposure_forecasts.npz",
        x=full,
        names=(*ARMS, "attemptsPer90"),
        sourceKey=source["key"],
        pairSha=source_report["pairedArtifactSha256"],
    )
    report = {
        "scope": "Historical pairing and conditional contest outcome diagnostics. No current opponent used for forecasts.",
        "sourceKey": source["key"],
        "featureRows": len(rows),
        "first2026LockCasesExactAfterRemovingTargetAndFutureFacts": len(selected),
        "phases": periods,
        "pooled": pooled,
        "laterCoverage": {
            cohort: {
                "all": sum(r["date"] >= "2026-01-01" and r["cohort"] == cohort for r in rows),
                "projectedRoster": sum(
                    r["date"] >= "2026-01-01" and r["cohort"] == cohort and f is not None
                    for r, f in zip(rows, forecasts, strict=True)
                ),
            }
            for cohort in ("start", "bench")
        },
    }
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_aerial_exposure.json")
    )
    run(parser.parse_args())


if __name__ == "__main__":
    main()
