"""Testing only: lock-safe context neighbours for conditional ordinary-point errors."""

from __future__ import annotations

import numpy as np

from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)
CONTEXT = (
    "home",
    "days_since_appearance",
    "{c}_history_count",
    "{c}_3_aa",
    "{c}_3_minutes",
    "{c}_3_score_sd",
    "{c}_10_aa",
    "{c}_10_minutes",
    "{c}_10_score_sd",
    "{c}_3_role_depth",
    "{c}_10_role_depth",
    "{c}_10_role_edge",
    "{c}_rate_accurate_pass",
    "{c}_rate_duel_won",
    "{c}_rate_won_tackle",
    "{c}_rate_saves",
    "own_model_goals",
    "other_model_goals",
    "own_model_cs",
    "expected_possession",
    "adjusted_passes90",
    "adjusted_duels90",
    "adjusted_tackles90",
    "adjusted_clearances90",
    "same_3_source_games",
    "same_3_source_age",
    "same_3_usage_completed90_mean",
)
SETTINGS = {
    **{f"pooled_spread{s}": {"kind": "pooled", "spread": s} for s in (0.75, 1)},
    **{
        f"local_k{k}_own{own}_prior{prior}_spread{spread}": {
            "kind": "local",
            "k": k,
            "own": own,
            "prior": prior,
            "spread": spread,
        }
        for k in (50, 200)
        for own in (1, 8)
        for prior in (20, 100)
        for spread in (0.75, 1)
    },
}


class FitNormaliser:
    def fit(self, values):
        values = np.asarray(values, dtype=float)
        if values.ndim != 2 or not len(values) or np.isinf(values).any():
            raise ValueError("Earlier residual context needed")
        known = np.isfinite(values)
        count = known.sum(axis=0)
        self.mean_ = np.divide(
            np.where(known, values, 0).sum(axis=0), count, out=np.zeros(values.shape[1]), where=count > 0
        )
        variance = np.divide(
            np.where(known, (values - self.mean_) ** 2, 0).sum(axis=0),
            count,
            out=np.ones(values.shape[1]),
            where=count > 0,
        )
        self.scale_ = np.where(variance > 1e-12, np.sqrt(variance), 1)
        return self

    def transform(self, values):
        values = np.asarray(values, dtype=float)
        if values.ndim != 2 or values.shape[1] != len(self.mean_) or np.isinf(values).any():
            raise ValueError("Residual context input shape or infinity differs")
        known = np.isfinite(values)
        raw = np.clip((np.where(known, values, self.mean_) - self.mean_) / self.scale_, -6, 6)
        return np.column_stack((raw, (~known).astype(float)))


def effective(weights):
    weights = np.asarray(weights, dtype=float)
    return weights.sum(axis=-1) ** 2 / np.square(weights).sum(axis=-1)


def mass(errors, weights, locations, level, spread):
    """Exact weighted native-score window mass after the actual floor and cap."""
    errors, weights = np.asarray(errors, dtype=float), np.asarray(weights, dtype=float)
    locations = np.atleast_1d(np.asarray(locations, dtype=float))
    if (
        errors.ndim != 1
        or errors.shape != weights.shape
        or not len(errors)
        or not np.isfinite(errors).all()
        or not np.isfinite(weights).all()
        or (weights < 0).any()
        or weights.sum() <= 0
        or not np.isfinite(locations).all()
        or not np.isfinite(spread)
        or spread <= 0
    ):
        raise ValueError("Known errors, positive total weight and valid location/spread needed")
    order = np.argsort(errors, kind="stable")
    ordered = errors[order]
    cumulative = np.r_[0, np.cumsum(weights[order]) / weights.sum()]
    low = (CENTRES[None, :] - 7 - level - locations[:, None]) / spread
    high = (CENTRES[None, :] + 7 - level - locations[:, None]) / spread
    lower = cumulative[np.searchsorted(ordered, low, side="left")]
    upper = cumulative[np.searchsorted(ordered, high, side="right")]
    floor = level if level >= 60 else 0
    lower[:, floor >= CENTRES - 7] = 0
    upper[:, CENTRES + 7 >= 100] = 1
    result = np.maximum(0, upper - lower)
    result[:, floor > CENTRES + 7] = 0
    return result


def row_mass(errors, weights, locations, level, spread):
    return np.vstack(
        [mass(e, w, [loc], level, spread)[0] for e, w, loc in zip(errors, weights, locations, strict=True)]
    )


class LocalErrors:
    """Records may include future labels; only available records enter any query."""

    def __init__(self, records, first_lock):
        self.records = records
        self.first_lock = first_lock
        before = np.asarray(records["available"]) < first_lock
        self.normaliser = FitNormaliser().fit(np.asarray(records["x"])[before])
        self.context = self.normaliser.transform(records["x"])

    def predict_group(self, context, classes, probability, parts, position, players, lock, settings):
        from scipy.spatial.distance import cdist

        n = len(players)
        if lock < self.first_lock:
            raise ValueError("Query lock precedes fit normalisation")
        if (
            probability.shape != (n, len(classes))
            or not np.isfinite(probability).all()
            or (probability < 0).any()
            or not np.allclose(probability.sum(axis=1), 1)
        ):
            raise ValueError("Invalid decisive-class probabilities")
        eligible = np.asarray(self.records["available"]) < lock
        same_position = eligible & (np.asarray(self.records["position"]) == position)
        pooled_fallback = not same_position.any()
        pool = np.flatnonzero(eligible if pooled_fallback else same_position)
        if not len(pool):
            raise ValueError("No earlier out-of-fit errors; cases cannot be dropped")
        errors = np.asarray(self.records["error"])[pool]
        if not np.isfinite(errors).all():
            raise ValueError("Unknown available residual cannot become zero")
        times = np.asarray(self.records["available"])[pool]
        decay = np.exp2(-(lock - times) / (365 * 86400))
        levels = np.asarray(self.records["level"])[pool]
        owners = np.asarray(self.records["player"])[pool]
        locations = np.sort(np.stack([parts[q] for q in (0.35, 0.5, 0.65)]), axis=0)
        masses = {name: np.zeros((n, len(CENTRES))) for name in settings}
        spreads = sorted({s["spread"] for s in settings.values()})
        local = {name: spec for name, spec in settings.items() if spec["kind"] == "local"}
        level_fallbacks = 0
        for j, level in enumerate(classes):
            ordinary = locations[1, :, j]
            conditional = np.flatnonzero(levels == level)
            level_fallbacks += int(not len(conditional))
            if not len(conditional):
                conditional = np.arange(len(pool))
            base = {}
            strength = float(effective(decay[conditional]))
            for spread in spreads:
                pooled = mass(errors, decay, ordinary, level, spread)
                specific = mass(errors[conditional], decay[conditional], ordinary, level, spread)
                base[spread] = (strength * specific + 20 * pooled) / (strength + 20)
            if local:
                query = np.column_stack((context, ordinary, locations[2, :, j] - locations[0, :, j], probability[:, j]))
                distance = cdist(self.normaliser.transform(query), self.context[pool[conditional]]) / np.sqrt(
                    self.context.shape[1]
                )
                count = min(max(s["k"] for s in local.values()), len(conditional))
                nearest = np.argsort(distance, axis=1, kind="stable")[:, :count]
                d = np.take_along_axis(distance, nearest, axis=1)
                neighbours = conditional[nearest]
                local_cache = {}
                for name, spec in local.items():
                    identity = spec["k"], spec["own"], spec["spread"]
                    if identity not in local_cache:
                        at = neighbours[:, : spec["k"]]
                        weights = decay[at] / (d[:, : spec["k"]] + 0.1)
                        weights *= np.where(owners[at] == np.asarray(players)[:, None], spec["own"], 1)
                        local_cache[identity] = (
                            row_mass(errors[at], weights, ordinary, level, spec["spread"]),
                            effective(weights),
                        )
                    local_mass, support = local_cache[identity]
                    alpha = support[:, None] / (support[:, None] + spec["prior"])
                    masses[name] += probability[:, j, None] * (alpha * local_mass + (1 - alpha) * base[spec["spread"]])
            for name, spec in settings.items():
                if spec["kind"] == "pooled":
                    masses[name] += probability[:, j, None] * base[spec["spread"]]
        if any(not np.isfinite(m).all() or (m < -1e-12).any() or (m > 1 + 1e-12).any() for m in masses.values()):
            raise ValueError("Invalid conditional residual window probabilities")
        predictions = {name: window_centres(m, CENTRES) for name, m in masses.items()}
        return predictions, {
            "earlierErrors": len(pool),
            "positionFallback": pooled_fallback,
            "emptyLevelFallbacks": level_fallbacks,
        }
