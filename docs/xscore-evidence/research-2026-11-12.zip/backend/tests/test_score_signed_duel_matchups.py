import numpy as np

from app.research import score_matchups as legacy
from app.research import score_signed_duel_matchups as signed


def role(depth, edges):
    return dict(depth=depth, edge=float(np.mean(np.abs(edges))) if edges else np.nan, role_edges=tuple(edges))


def test_left_defender_faces_right_opponent_in_each_attacking_frame():
    own = role(0.2, [-1])
    others = [role(1.0, [1]), role(1.0, [-1])]
    weight = signed.role_weights(own, others, True)
    assert weight[0] > weight[1]
    assert legacy.role_weights(own, others, True)[0] == legacy.role_weights(own, others, True)[1]


def test_two_wings_are_a_mixture_not_an_invented_centre():
    own = role(0.2, [-1, 1])
    opponent = [role(1.0, [1])]
    value = signed.role_weights(own, opponent, True)[0]
    expected = (
        signed.role_weights(role(0.2, [-1]), opponent, True)[0] + signed.role_weights(role(0.2, [1]), opponent, True)[0]
    ) / 2
    assert value == expected
    assert value != signed.role_weights(role(0.2, [0]), opponent, True)[0]


def test_missing_roles_and_all_same_team_weights_preserve_legacy_exactly():
    own = role(0.2, [-1])
    others = [role(0.6, [1]), role(1.0, [])]
    np.testing.assert_array_equal(signed.role_weights(own, others, False), legacy.role_weights(own, others, False))
    assert signed.role_weights(own, [others[1]], True)[0] == legacy.role_weights(own, [others[1]], True)[0]


def native_fixture():
    dates = ["2025-12-10T12:00:00Z", "2025-12-18T12:00:00Z", "2025-12-28T12:00:00Z", "2026-01-03T12:00:00Z"]
    games, records, rows = [], [], []
    for i, date in enumerate(dates):
        game = dict(id=f"g{i}", date=date, home=dict(slug="A"), away=dict(slug="B"), players={})
        for player, club, pos, depth, edge, won, lost in [
            ("p", "A", "DEF", 0.2, -1, 6, 4),
            ("r", "B", "FWD", 1, 1, 8, 2),
            ("l", "B", "FWD", 1, -1, 2, 8),
        ]:
            game["players"][player] = dict(
                team=club, pos=pos, played=True, ver=7, mins=90, stats={"duel_won": [won, 0], "duel_lost": [lost, 0]}
            )
            records.append(
                dict(
                    game=f"g{i}",
                    date=date,
                    club=club,
                    player=player,
                    values=dict(usage_role_depth=depth, usage_role_edge=edge),
                )
            )
        games.append(game)
        rows.append(dict(game=f"g{i}", date=date, player="p", pos="DEF", x=[1]))
    return rows, games, records, ["home"]


def test_signed_counterparty_predicts_stronger_opponent_without_changing_other82fields():
    args = native_fixture()
    old, names, _ = legacy.build_matchups(*args)
    new, new_names, _ = signed.build_matchups(*args)
    assert names == new_names and new.shape == (4, 104)
    assert new[-1, names.index("opponent_duel_fraction")] > old[-1, names.index("opponent_duel_fraction")]
    assert new[-1, names.index("expected_duel_fraction")] < old[-1, names.index("expected_duel_fraction")]
    allowed = {
        "opponent_baseline_duel_fraction",
        "opponent_duel_fraction",
        "duel_fraction_gap",
        "expected_duel_fraction",
        "duel_point_change90",
    }
    keep = np.array([not (n.startswith("opponent_matchup_") or n in allowed) for n in names])
    assert keep.sum() == 82
    np.testing.assert_array_equal(old[:, keep], new[:, keep])


def test_actual_current_stats_minutes_roles_and_lineups_are_unavailable():
    from copy import deepcopy

    args = native_fixture()
    expected, _, _ = signed.build_matchups(*args)
    altered = deepcopy(args)
    altered[1][-1]["xi"] = "future-lineup"
    for person in altered[1][-1]["players"].values():
        person.update(stats=None, mins=100000)
    for record in altered[2]:
        if record["game"] == "g3":
            record["values"].update(usage_role_edge=1, usage_role_depth=0.8)
    changed, _, _ = signed.build_matchups(*altered)
    np.testing.assert_array_equal(changed, expected)
