"""Testing only: all-case native mass/choice checks and genuine ordinary-forest refits."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_flow as flow
from app.research import score_leaf_ordinary as leaf
from app.research import score_leaf_ordinary_run as runner
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import measure


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda n: json.loads((args.report.parent / (n + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Ordinary leaf audit source differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Ordinary leaf audit match features differ")
        all_x = np.column_stack((base, f["x"]))
    modules = (leaf, flow, matched, controls, modal, ordinary, stability, windows)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Ordinary leaf audit formula fingerprint differs")
    # Direct comparisons to native +/-7 arithmetic, independent of difference histograms.
    all_aa = np.array([r["aa"] for r in source["rows"]])
    leaves = np.arange(len(all_aa)) % 127
    for level in (0, 5, 15, 35, 60, 70, 80, 90, 100):
        hist, counts = leaf.leaf_window_histograms(all_aa, leaves, 127, level)
        native = np.clip(np.maximum(level if level >= 60 else 0, level + all_aa), 0, 100)
        for node in range(127):
            brute = (np.abs(native[leaves == node, None] - modal.CENTRES) <= 7).sum(axis=0)
            if not np.array_equal(hist[node], brute) or counts[node] != (leaves == node).sum():
                raise ValueError("Ordinary leaf all-native histogram boundaries differ")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        aa, levels, y = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or winner != frozen["winner"]
            or best != frozen["best"]
            or (winner is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Ordinary leaf earlier selection differs")
        reconstructed, caches = 0, 0
        for phase, _, _ in stability.PHASES[1:]:
            target = masks[phase]["target"]
            fit = masks[phase]["fit"]
            old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Ordinary leaf strongest control differs")
            imputer = leaf.FitImputer().fit(all_x[keep][fit])
            active = [best] if phase == "later2026" else frozen["candidates"]
            for setting in sorted({r["spec"]["model"] for r in active}):
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{setting}.npz"
                with np.load(path) as f:
                    stats = json.loads(str(f["statistics"]))
                    if (
                        str(f["key"]) != key
                        or not np.array_equal(f["classes"], old[0])
                        or not np.array_equal(f["probability"], old[1])
                        or stats["settings"] != leaf.SETTINGS[setting]
                        or stats["fitCases"] != int(fit.sum())
                        or stats["targetCases"] != int(target.sum())
                        or stats["fitImputerSha256"] != hashlib.sha256(imputer.median_.tobytes()).hexdigest()
                        or not stats["eventProbabilitiesUnchanged"]
                    ):
                        raise ValueError("Ordinary leaf cached fit/imputer/event identity differs")
                    masses = {p: f[f"mass{p}"] for p in (20, 100)}
                caches += 1
                for prior, mass in masses.items():
                    if (
                        mass.shape != (int(target.sum()), 201)
                        or not np.isfinite(mass).all()
                        or (mass < 0).any()
                        or (mass > 1 + 1e-12).any()
                    ):
                        raise ValueError("Ordinary leaf native all-case window masses invalid")
                    raw = windows.window_centres(mass, modal.CENTRES)
                    for record in [r for r in active if r["spec"]["model"] == setting and r["spec"]["prior"] == prior]:
                        forecast = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                        if phase == "later2026":
                            alternate = forecast
                            final_masses = masses
                        elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                            raise ValueError("Ordinary leaf earlier score forecasts do not reconstruct")
                        reconstructed += 1
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Ordinary leaf all-case final identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Ordinary leaf final native metric differs")
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "massCachesVerified": caches,
            "candidateForecastsReconstructed": reconstructed,
            "earlierSelectionVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            aa[~fit] = np.nan
            levels[~fit] = np.nan
            print(f"LEAF_AA_AUDIT_REFIT {cohort} {best['spec']['model']}", flush=True)
            repeated, _ = leaf.fit_distribution(
                all_x[keep], aa, levels, positions, fit, target, old[0], old[1], leaf.SETTINGS[best["spec"]["model"]]
            )
            if any(not np.array_equal(repeated[p], final_masses[p]) for p in repeated):
                raise ValueError("Ordinary leaf real refit changes when outside-fit AA/DS blanked")
            evidence[cohort]["realRefitAfterOutsideFitLabelsBlanked"] = {
                "outsideFitAAandDSRowsBlanked": int((~fit).sum()),
                "all201WindowMassesBothPriorsReproduced": True,
            }
    output = {
        "scope": "Testing-only full native audit; exploratory reuse not fresh blind proof",
        "implementationKey": key,
        "nativeHistogramCases": len(all_aa),
        "possibleLevelsChecked": 9,
        "centresPerCase": 201,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
