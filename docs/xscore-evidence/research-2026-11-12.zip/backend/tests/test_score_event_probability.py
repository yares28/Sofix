import numpy as np
import pytest

from app.research.score_event_probability import event_probabilities, fit_intensities, forecast_policy


def test_count_probabilities_include_cancellations_zero_rates_and_supported_tails():
    from scipy.stats import skellam

    classes = np.array([15, 35, 60, 70, 80])
    p = event_probabilities(classes, np.array([0.8, 0, 2]), np.array([0.3, 0, 0]), "counts", None)
    np.testing.assert_allclose(p.sum(axis=1), 1)
    assert np.isfinite(p).all() and (p >= 0).all()
    assert p[0, 1] == pytest.approx(skellam.pmf(0, 0.8, 0.3))
    assert p[1, 1] == 1 and p[2, -1] > 0
    # Net-negative tails fold into the only supported negative class.
    negative = event_probabilities(np.array([15, 35, 60]), np.array([0]), np.array([2]), "counts", None)
    assert negative[0, 0] == pytest.approx(1 - np.exp(-2))


def test_state_totals_preserve_old_within_state_class_shape():
    classes = np.array([5, 15, 35, 60, 70])
    old = np.array([[0.02, 0.08, 0.7, 0.15, 0.05]])
    count = event_probabilities(classes, np.array([0.6]), np.array([0.04]), "counts", old)
    shaped = event_probabilities(classes, np.array([0.6]), np.array([0.04]), "state_totals", old)
    assert shaped[0, 1] / shaped[0, 0] == pytest.approx(4)
    assert shaped[0, 3] / shaped[0, 4] == pytest.approx(3)
    assert shaped[0, :2].sum() == pytest.approx(count[0, :2].sum())
    assert shaped[0, 3:].sum() == pytest.approx(count[0, 3:].sum())


def test_future_event_labels_cannot_enter_calibration_and_cold_position_keeps_cases():
    size = 242
    positive = np.linspace(0.05, 0.8, size)
    negative = np.full(size, 0.03)
    ypos = np.tile([0, 0, 1, 0, 2, 0], 41)[:size].astype(float)
    yneg = np.tile([0, 0, 0, 1], 61)[:size].astype(float)
    positions = np.array(["FWD"] * 120 + ["MID"] * 120 + ["DEF", "FWD"])
    fit = np.arange(size) < 240
    target = ~fit
    first, stats = fit_intensities(positive, negative, ypos, yneg, positions, fit, target, "position20")
    ypos[target] = np.nan
    yneg[target] = np.nan
    second, _ = fit_intensities(positive, negative, ypos, yneg, positions, fit, target, "position20")
    np.testing.assert_allclose(first, second)
    assert first.shape == (2, 2) and np.isfinite(first).all()
    assert stats["models"]["positive"]["positions"]["DEF"]["globalFallback"] is True
    assert stats["models"]["positive"]["positions"]["FWD"]["globalFallback"] is False


def test_joint_probability_mode_selects_low_or_high_and_never_their_average():
    from app.research.score_empirical_density import empirical_predictions

    classes = np.array([35, 60])
    prior = np.array([[0.5, 0.5], [0.5, 0.5]])
    p = event_probabilities(classes, np.array([0.1, 1]), np.zeros(2), "counts", prior)
    parts = {q: np.array([[5, 20], [5, 20]], dtype=float) for q in (0.35, 0.5, 0.65)}
    bank = {"mode": "raw", "global": np.array([0.0]), "positions": {"FWD": np.array([0.0])}, "levels": {}}
    prediction = empirical_predictions(classes, p, parts, np.array(["FWD", "FWD"]), bank, 20, 1, 0)
    assert 33 <= prediction[0] <= 47 and 73 <= prediction[1] <= 87
    assert not np.isin(prediction, [56]).any()


def test_decision_and_scope_keep_full_control_for_other_states_and_goalkeepers():
    candidate = np.array([80, 45, 30, 70])
    control = np.array([40, 40, 80, 40])
    positions = np.array(["FWD", "MID", "DEF", "GK"])
    result = forecast_policy(candidate, control, positions, "state_changes", "outfield")
    np.testing.assert_equal(result, [80, 40, 30, 40])
    np.testing.assert_equal(forecast_policy(candidate, control, positions, "full", "forward"), [80, 40, 80, 40])
