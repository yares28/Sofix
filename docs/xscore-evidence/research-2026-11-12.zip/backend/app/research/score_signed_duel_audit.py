"""Independent native counterparty profiles and all22 signed-matchup columns."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from bisect import bisect_left
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta
from functools import cache
from pathlib import Path

import numpy as np

from app.research import score_signed_duel_matchups as study
from app.research.score_search import cutoff_for, moment


def reconstruct(rows, games, source_roles, names):
    events = (
        "duel_won",
        "duel_lost",
        "won_tackle",
        "interception_won",
        "effective_clearance",
        "won_contest",
        "accurate_pass",
        "missed_pass",
        "ontarget_scoring_att",
        "goals",
        "goal_assist",
        "fouls",
        "was_fouled",
        "poss_lost_ctrl",
        "poss_won",
        "pen_area_entries",
        "successful_final_third_passes",
    )
    role_map = {(r["game"], r["player"]): r["values"] for r in source_roles}
    people, clubs, by_position = defaultdict(list), defaultdict(list), defaultdict(list)
    for g in sorted(games.values(), key=lambda g: (g["date"], g["id"])):
        available = moment(g["date"]) + timedelta(hours=48)
        members = {g[s]["slug"]: [] for s in ("home", "away")}
        for player, p in g["players"].items():
            if p.get("played") is not True or p.get("pos") not in ("GK", "DEF", "MID", "FWD"):
                continue
            minutes = p.get("mins")
            if (
                p.get("team") not in members
                or type(minutes) not in (int, float)
                or not math.isfinite(minutes)
                or minutes < 0
            ):
                continue
            known = p.get("ver") == 7 and isinstance(p.get("stats"), dict)
            counts = [p["stats"].get(e, [0, 0])[0] for e in events] if known else None
            record = dict(
                available=available,
                club=p["team"],
                minutes=minutes,
                counts=counts,
                role=role_map.get((g["id"], player)),
            )
            people[player].append(record)
            members[p["team"]].append((player, minutes, p["pos"]))
            if known and minutes > 0:
                by_position[p["pos"]].append(record)
        for team, players in members.items():
            clubs[team].append((available, players))
    player_times = {p: [r["available"].timestamp() for r in rs] for p, rs in people.items()}
    club_times = {p: [r[0].timestamp() for r in rs] for p, rs in clubs.items()}
    cumulative, prior_times = {}, {}
    for pos, rs in by_position.items():
        prior_times[pos] = [r["available"].timestamp() for r in rs]
        cumulative[pos] = np.vstack((np.zeros(18), np.cumsum([[*r["counts"], r["minutes"]] for r in rs], axis=0)))

    @cache
    def profile(player, team, position, lock):
        end = bisect_left(player_times.get(player, []), lock.timestamp())
        history = [r for r in people.get(player, [])[:end] if r["available"] >= lock - timedelta(days=365)]
        same = [r for r in history if r["club"] == team]
        recent = (same or history)[-10:]
        known = [r for r in recent if r["counts"] is not None and r["minutes"] > 0]
        counts = np.array([math.fsum(r["counts"][j] for r in known) for j in range(17)])
        minutes = math.fsum(r["minutes"] for r in known)
        index = bisect_left(prior_times.get(position, []), lock.timestamp())
        prior = cumulative[position][index] if position in cumulative else np.zeros(18)
        if prior[-1] > 0:
            rate = (counts + 300 * prior[:17] / prior[-1]) * 90 / (minutes + 300)
        else:
            rate = counts * 90 / minutes if minutes else np.full(17, np.nan)
        roles = [r["role"] for r in recent[-3:] if r["role"] is not None]
        depths = [r["usage_role_depth"] for r in roles if r.get("usage_role_depth") is not None]
        edges = [
            float(r["usage_role_edge"])
            for r in roles
            if r.get("usage_role_edge") is not None and math.isfinite(r["usage_role_edge"])
        ]
        depth = math.fsum(depths) / len(depths) if depths else {"GK": 0, "DEF": 0.2, "MID": 0.6, "FWD": 1}[position]
        baseline = prior[0] / (prior[0] + prior[1]) if prior[0] + prior[1] > 0 else np.nan
        return dict(rate=rate, depth=depth, edges=edges, prior=baseline)

    @cache
    def members(team, lock):
        end = bisect_left(club_times.get(team, []), lock.timestamp())
        recent = clubs.get(team, [])[:end][-3:]
        exposure, positions = defaultdict(float), {}
        for _, lineup in recent:
            for player, minutes, pos in lineup:
                exposure[player] += minutes / len(recent)
                positions[player] = pos
        return [(profile(player, team, positions[player], lock), weight) for player, weight in exposure.items()]

    selected_names = [
        n
        for n in names
        if n.startswith("opponent_matchup_")
        or n
        in {
            "opponent_baseline_duel_fraction",
            "opponent_duel_fraction",
            "duel_fraction_gap",
            "expected_duel_fraction",
            "duel_point_change90",
        }
    ]
    result = np.full((len(rows), len(selected_names)), np.nan)
    for i, r in enumerate(rows):
        lock = cutoff_for(r["date"])
        g = games[r["game"]]
        own_club = g["players"][r["player"]]["team"]
        other_club = g["away"]["slug"] if own_club == g["home"]["slug"] else g["home"]["slug"]
        own = profile(r["player"], own_club, r["pos"], lock)
        opponent = members(other_club, lock)
        weighted = []
        for person, exposure in opponent:
            depth = 1 / (0.25 + abs(own["depth"] + person["depth"] - 1.2))
            if own["edges"] and person["edges"]:
                lateral = math.fsum(0.5 + 1 / (1 + abs(a + b)) for a in own["edges"] for b in person["edges"]) / (
                    len(own["edges"]) * len(person["edges"])
                )
            else:
                lateral = 1.0
            weighted.append((person, exposure * depth * lateral))
        matched = []
        for j in range(17):
            known = [(p["rate"][j], w) for p, w in weighted if math.isfinite(p["rate"][j])]
            denominator = math.fsum(w for _, w in known)
            matched.append(math.fsum(value * w for value, w in known) / denominator if denominator else np.nan)
        baseline_values = [
            (p["prior"], w * (p["rate"][0] + p["rate"][1]))
            for p, w in weighted
            if math.isfinite(p["prior"]) and math.isfinite(w * (p["rate"][0] + p["rate"][1]))
        ]
        denominator = math.fsum(w for _, w in baseline_values)
        baseline = math.fsum(p * w for p, w in baseline_values) / denominator if denominator > 0 else np.nan
        own_d = own["rate"][0] + own["rate"][1]
        opponent_d = matched[0] + matched[1]
        own_p = own["rate"][0] / own_d if own_d > 0 else np.nan
        opponent_p = matched[0] / opponent_d if opponent_d > 0 else np.nan
        expected = np.nan
        if np.isfinite([own_p, opponent_p, baseline]).all():
            a, b, c = [min(1 - 1e-5, max(1e-5, p)) for p in (own_p, opponent_p, baseline)]
            odds = a / (1 - a) / (b / (1 - b)) * (c / (1 - c))
            expected = odds / (1 + odds)
        values = {f"opponent_matchup_{name}": matched[j] for j, name in enumerate(events)}
        values.update(
            opponent_baseline_duel_fraction=baseline,
            opponent_duel_fraction=opponent_p,
            duel_fraction_gap=own_p - opponent_p,
            expected_duel_fraction=expected,
            duel_point_change90={"DEF": 3.5, "MID": 1.6, "FWD": 2}.get(r["pos"], np.nan) * own_d * (expected - own_p),
        )
        result[i] = [values[n] for n in selected_names]
        if (i + 1) % 10000 == 0:
            print(f"SIGNED_DUEL_AUDIT_ROWS {i + 1}/{len(rows)}", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_signed_duel_matchups.json")
    )
    args = parser.parse_args()
    source, report = json.loads((args.cache / "cases.json").read_text()), json.loads(args.report.read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native signed matchup source changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    roles_raw = (args.cache / "player_context_observations.json.gz").read_bytes()
    roles = json.loads(gzip.decompress(roles_raw))["records"]
    parent_key = hashlib.sha256(
        source["key"].encode()
        + raw
        + roles_raw
        + Path(study.legacy.__file__).read_bytes()
        + (args.report.parent / "laliga_score_matchups.plan.json").read_bytes()
    ).hexdigest()
    key = hashlib.sha256(
        parent_key.encode() + Path(study.__file__).read_bytes() + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if parent_key != report["originalFeatureKey"] or key != report["featureKey"]:
        raise ValueError("Frozen signed matchup source/core/plan changed")
    path = args.cache / "signed_duel_matchup_features.npz"
    if hashlib.sha256(path.read_bytes()).hexdigest() != report["featuresSha256"]:
        raise ValueError("Signed feature artifact changed")
    for r in source["rows"]:
        g, p = games[r["game"]], games[r["game"]]["players"][r["player"]]
        if (
            p["ver"] != 7
            or not p["played"]
            or p["started"] != (r["cohort"] == "start")
            or g["date"] != r["date"]
            or p["mins"] != r["minutes"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Full native signed-matchup case identity differs")
    with np.load(path) as f:
        x, names, selected = f["x"], f["names"].tolist(), f["selected"]
        if str(f["key"]) != key or str(f["source_key"]) != source["key"]:
            raise ValueError("Signed feature identity differs")
    rebuilt = reconstruct(source["rows"], games, roles, names)
    np.testing.assert_allclose(x[:, selected], rebuilt, rtol=0, atol=1e-10, equal_nan=True)
    with np.load(args.cache / "matchup_features.npz") as f:
        np.testing.assert_array_equal(x[:, ~selected], f["x"][:, ~selected])
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    changed_games, changed_roles = deepcopy((games, roles))
    game_changes, role_changes = 0, 0
    for g in changed_games.values():
        if moment(g["date"]) + timedelta(hours=48) >= first:
            g["xi"] = "unavailable-future-lineup"
            for p in g["players"].values():
                p.update(stats=None, mins=100000)
            game_changes += 1
    for r in changed_roles:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            r["values"].update(usage_role_depth=0.8, usage_role_edge=1)
            role_changes += 1
    changed, changed_names, _ = study.build_matchups(
        [source["rows"][i] for i in indices], list(changed_games.values()), changed_roles, source["features"]
    )
    if changed_names != names:
        raise ValueError("Mutated signed matchup schema changed")
    np.testing.assert_array_equal(changed, x[indices])
    output = dict(
        featureKey=key,
        nativeCasesVerified=len(source["rows"]),
        sourceRoleRecords=len(roles),
        independentlyRebuiltRows=len(rebuilt),
        independentlyRebuiltColumns=22,
        unchangedOtherColumns=82,
        actualFutureMutation=dict(
            firstLock=first.isoformat(),
            targetRows=len(indices),
            unavailableNativeFixturesChanged=game_changes,
            unavailableSourceRolesChanged=role_changes,
            all104columnsExact=True,
        ),
        scope="Source/feature verification only, no model or accuracy gain claim",
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("SIGNED_DUEL_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
