"""Research-only pre-lock yellow accumulation candidates."""

import hashlib
import json
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS
from app.research.score_absence_sections import histories
from app.research.score_search import cutoff_for, moment

STEM = "laliga_score_card_cycle"
DELAY = timedelta(hours=48)
PHASES = {
    "spring2024": ("2024-01-01", "2024-07-01"),
    "season2024": ("2024-07-01", "2025-07-01"),
    "autumn2025": ("2025-07-01", "2026-01-01"),
}


def season_of(date):
    return int(date[:4]) - int(date[5:7] < "07")


def card_value(stats, event):
    value = stats.get(event, [0, 0])[0]
    if type(value) not in (float, int) or value not in (0, 1):
        raise ValueError("Unknown native card value")
    return int(value)


def generate(games):
    ordered = sorted(games, key=lambda g: (g["date"], g["id"]))
    next_game, last = {}, {}
    for game in reversed(ordered):
        season = season_of(game["date"])
        for side in ("home", "away"):
            club = game[side]["slug"]
            next_game[game["id"], club] = last.get((season, club))
            last[season, club] = game
    cycles, counts = defaultdict(list), Counter()
    evidence = []
    for game in ordered:
        season = season_of(game["date"])
        available = moment(game["date"]) + DELAY
        for name, p in sorted(game.get("players", {}).items()):
            if p.get("ver") != 7 or not isinstance(p.get("stats"), dict):
                continue
            yellow, red = (card_value(p["stats"], k) for k in ("yellow_card", "red_card"))
            if not yellow:
                continue
            if red:
                counts["excludedRedYellow"] += 1
                continue
            counts["singleYellow"] += 1
            counts["unusedBenchYellow"] += p.get("played") is not True
            cards = cycles[season, name]
            cards.append(game["id"])
            if len(cards) % 5:
                continue
            target = next_game[game["id"], p["team"]]
            lock = cutoff_for(target["date"]) if target is not None else None
            state = "end_of_available_season" if lock is None else "timely" if available < lock else "late"
            evidence.append(
                dict(
                    season=season,
                    player=name,
                    club=p["team"],
                    origin=game["id"],
                    originDate=game["date"],
                    available=available.isoformat(),
                    countedCards=len(cards),
                    cycleCards=cards[-5:],
                    target=target["id"] if target else None,
                    targetDate=target["date"] if target else None,
                    lock=lock.isoformat() if lock else None,
                    status=state,
                )
            )
    return evidence, dict(counts)


def freeze(games):
    records, counts = generate(games)
    latest = defaultdict(list)
    for g in games:
        ready = moment(g["date"]) + DELAY
        for name, p in g.get("players", {}).items():
            if p.get("played") is True and p.get("ver") == 7:
                latest[name].append((ready, p["team"]))
    cache = {}
    out = []
    for r in records:
        phase = next((k for k, (a, b) in PHASES.items() if a <= (r["targetDate"] or "") < b), None)
        if phase is None:
            continue
        r = dict(r, phase=phase)
        if r["status"] == "timely":
            lock, club = moment(r["lock"]), r["club"]
            appearances = [v for v in latest[r["player"]] if v[0] < lock]
            if not appearances or max(appearances)[1] != club:
                r["status"] = "no_eligible_current_club"
            else:
                if (club, lock) not in cache:
                    cache[club, lock] = histories(games, club, lock)[1]
                r["projectedPriorMinutes"] = float(cache[club, lock].get(r["player"], 0))
        out.append(r)
    return out, counts


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    # The first probe has no 2026 participant data in its input.
    games = sorted(
        (g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"),
        key=lambda g: (g["date"], g["id"]),
    )
    assert len(games) == 931
    season_counts = Counter(season_of(g["date"]) for g in games)
    assert season_counts == {2023: 380, 2024: 380, 2025: 171}
    assert all(
        sum(p.get("played") is True and p.get("started") is True for p in g["players"].values()) == 22 for g in games
    )
    rows, counts = freeze(games)
    encoded = json.dumps(rows, sort_keys=True).encode()
    plan = (REPORTS / f"{STEM}.plan.json").read_bytes()
    key = hashlib.sha256(Path(__file__).read_bytes() + plan + NATIVE_SHA.encode() + encoded).hexdigest()
    report = dict(
        key=key,
        nativeSHA=NATIVE_SHA,
        earlierGames=len(games),
        countedEvents=counts,
        statusCounts=dict(Counter(r["status"] for r in rows)),
        targetLabelsEvaluated=False,
        predictions=rows,
    )
    (REPORTS / f"{STEM}.forecasts.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "predictions"}, indent=2))


if __name__ == "__main__":
    main()
