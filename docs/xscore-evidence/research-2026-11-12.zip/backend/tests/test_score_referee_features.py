from copy import deepcopy

import numpy as np

from app.research import score_referee_features as source


def game(identity, date):
    players = {}
    for club in ["H", "A"]:
        for i in range(11):
            players[club + str(i)] = dict(
                played=True,
                started=True,
                team=club,
                pos="GK" if i == 0 else "DEF",
                ver=7,
                mins=90,
                stats={} if i == 0 else dict(duel_won=[2, 3], duel_lost=[1, -2], fouls=[1, -1], was_fouled=[1, 0.5]),
            )
    return dict(id=identity, date=date, home=dict(slug="H"), away=dict(slug="A"), players=players)


def inputs():
    old = game("old", "2024-01-13T13:00:00Z")
    target = game("new", "2024-01-17T20:00:00Z")
    before = dict(referee="Munuera Montero, José Luis", availableUTC="2024-01-12T10:00:00+00:00")
    now = dict(referee="José Luis Munuera", availableUTC="2024-01-16T12:00:00+00:00")
    archive = dict(
        fixtureChoices=[dict(game="old", pregame=before, prelock=before), dict(game="new", pregame=now, prelock=now)]
    )
    rows = [dict(game="new", date=target["date"], x=[1])]
    return rows, [old, target], archive


def test_published_name_groups_are_explicit_categories_not_fuzzy_person_matches():
    groups = source.name_groups(["Munuera Montero, José Luis", "José Luis Munuera", "José Luis Guzmán"])
    assert groups["Munuera Montero, José Luis"] == groups["José Luis Munuera"]
    assert groups["José Luis Guzmán"] != groups["José Luis Munuera"]


def test_known_zero_is_different_from_unavailable_native_history():
    rows, games, archive = inputs()
    x, _, _ = source.feature_rows(rows, games, archive, ["home"])
    assert x.shape == (1, 13)
    assert x[0, 0:3].tolist() == [1, 1, 1]
    assert x[0, 4] == 1 and x[0, 9] == 2 / 3
    assert x[0, 6] == 0
    games[0]["players"]["H1"]["ver"] = None
    unknown, _, _ = source.feature_rows(rows, games, archive, ["home"])
    assert unknown[0, 0:3].tolist() == [1, 1, 0]
    assert np.isnan(unknown[0, 4:]).all()


def test_all_future_participants_and_stat_sheets_can_be_removed():
    rows, games, archive = inputs()
    x, _, _ = source.feature_rows(rows, games, archive, ["home"])
    changed = deepcopy(games)
    changed[1]["players"] = {}
    actual, _, _ = source.feature_rows(rows, changed, archive, ["home"])
    np.testing.assert_array_equal(x, actual)


def test_exact_48hour_boundary_and_late_current_appointment_stay_unknown():
    rows, games, archive = inputs()
    games[0]["date"] = "2024-01-14T14:00:00Z"
    x, _, _ = source.feature_rows(rows, games, archive, ["home"])
    assert x[0, 0:3].tolist() == [1, 0, 0]
    assert np.isnan(x[0, 4:]).all()
    archive["fixtureChoices"][1]["prelock"] = None
    y, _, _ = source.feature_rows(rows, games, archive, ["home"])
    assert y[0, 0:3].tolist() == [0, 0, 0]
    assert np.isnan(y[0, 4:]).all()
