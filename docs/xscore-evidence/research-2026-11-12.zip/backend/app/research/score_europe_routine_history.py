"""Testing only: causal corrected routine-point history from existing native caches."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import zipfile
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_europe_routine as routine
from app.research import score_search
from app.research import score_team_shape_history as modal
from app.research.score_search import cutoff_for, moment

SOURCES = ("euro", "combined")
GROUPS = ("same_position", "same_cohort")
WINDOWS = (5, 15)
NAMES = tuple(f"routine_{s}_{g}_{n}_{f}" for s in SOURCES for g in GROUPS for n in WINDOWS for f in routine.FIELDS)


def laliga_records(game, receipt, prices):
    records = []
    for player, p in game["players"].items():
        pos, aa, minutes, score = (p.get(n) for n in ("pos", "aa", "mins", "score"))
        if (
            p.get("played") is not True
            or p.get("ver") != 7
            or type(p.get("started")) is not bool
            or pos not in routine.GC_PRICE
            or type(aa) not in (int, float)
            or not math.isfinite(aa)
            or type(score) not in (int, float)
            or not math.isfinite(score)
            or not 0 <= score <= 100
            or type(minutes) not in (int, float)
            or not math.isfinite(minutes)
            or not 1 <= minutes <= 90
        ):
            continue
        club = p.get("team")
        if club not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Native LaLiga routine source actual side unknown")
        stats = p.get("stats")
        if not isinstance(stats, dict):
            receipt["unknownNativeAASheet"] += 1
            continue
        values = [v for v in stats.values()]
        if any(
            not isinstance(v, (tuple, list)) or len(v) != 2 or type(v[1]) not in (int, float) or not math.isfinite(v[1])
            for v in values
        ):
            raise ValueError("Native LaLiga AA points are incomplete")
        summed = sum(v[1] for v in values)
        error = abs(summed - aa)
        receipt["maximumNativeAAError"] = max(receipt.get("maximumNativeAAError", 0), error)
        if error > 1e-7:
            raise ValueError("Native LaLiga AA point sheet does not reconstruct actual AA")
        effect = sum(stats[n][1] for n in ("goals_conceded", "clean_sheet_60") if n in stats)
        for name in ("goals_conceded", "clean_sheet_60"):
            if name not in stats:
                continue
            count, points = stats[name]
            if type(count) not in (int, float) or not math.isfinite(count) or count < 0:
                raise ValueError("Native defensive count invalid")
            expected = routine.GC_PRICE[pos] if name == "goals_conceded" else 10 if pos == "DEF" else 0
            if abs(points - count * expected) > 1e-9:
                raise ValueError("Native defensive price differs from certified v7 rule")
            if game["date"] < "2023-11-01" and count > 0:
                identity = pos + ":" + name
                ratio = float(points / count)
                if identity in prices and abs(prices[identity] - ratio) > 1e-9:
                    raise ValueError("Early native defensive price inconsistent")
                prices[identity] = ratio
        point = float(aa - effect)
        bounds = dict(point=point, lower=point, upper=point, kind="exact")
        records.append(
            dict(
                game=game["id"],
                player=player,
                date=game["date"],
                club=club,
                pos=pos,
                cohort="start" if p["started"] else "bench",
                minutes=float(minutes),
                score=float(score),
                level=p.get("level"),
                source="laliga",
                ordinary=dict(point=float(aa), lower=float(aa), upper=float(aa), kind="exact"),
                routine=bounds,
                effect=dict(
                    lower=float(effect),
                    upper=float(effect),
                    gcInferredZero=False,
                    gcSource="native_named_AA_points",
                    gcUnknown=None,
                ),
            )
        )
        receipt["nativeAALabelsReconstructed"] += 1
    return records


def read_sources(games_path, archives):
    records, targets, digest, prices = {}, [], hashlib.sha256(), {}
    ll_receipt = Counter()
    with games_path.open("rb") as source:
        for line in source:
            digest.update(line)
            if not line.strip():
                continue
            game = json.loads(line)
            targets.append(
                {k: game[k] for k in ("id", "date", "home", "away")}
                | {"players": {p: {"team": r.get("team")} for p, r in game["players"].items()}}
            )
            for record in laliga_records(game, ll_receipt, prices):
                identity = record["game"], record["player"]
                if identity in records:
                    raise ValueError("Duplicate native LaLiga routine observation")
                records[identity] = record
    for pos in ("GK", "DEF", "MID"):
        if prices.get(pos + ":goals_conceded") != routine.GC_PRICE[pos]:
            raise ValueError("Before-Nov2023 goal-conceded price certificate missing")
    if prices.get("DEF:clean_sheet_60") != 10 or prices.get("GK:clean_sheet_60") != 0:
        raise ValueError("Before-Nov2023 clean-sheet AA price certificate missing")
    receipts = []
    for competition in ("CL", "EL", "CONF"):
        path = archives / f"{competition}.zip"
        receipt = Counter()
        with zipfile.ZipFile(path) as archive:
            coverage = json.loads(archive.read("coverage.json"))
            if coverage.get("sourceComplete") is not True:
                raise ValueError("Cached European source index incomplete")
            for member in sorted(archive.namelist()):
                if not member.startswith("games/") or not member.endswith(".json"):
                    continue
                game = json.loads(archive.read(member)).get("raw") or {}
                for record in routine.euro_records(game, receipt):
                    identity = record["game"], record["player"]
                    if identity in records:
                        old = records[identity]
                        if old["source"] == "laliga":
                            if any(old[n] != record[n] for n in ("date", "club", "pos", "score")):
                                raise ValueError("Cross-source routine fixture identity differs")
                            point = old["routine"]["point"]
                            lo, hi = record["routine"]["lower"], record["routine"]["upper"]
                            if lo is not None and point < lo - 1e-7 or hi is not None and point > hi + 1e-7:
                                raise ValueError("Cross-source routine native interval contradicts exact AA")
                            receipt["duplicateActualLaLigaRetainedOnce"] += 1
                            continue
                        if old != record:
                            raise ValueError("Conflicting native routine observations")
                        receipt["identicalEuropeanDuplicate"] += 1
                    else:
                        records[identity] = record
        receipts.append(
            dict(
                archive=path.name,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                counts=dict(receipt),
                sourceComplete=coverage.get("sourceComplete"),
                uefaAligned=coverage.get("uefaAligned"),
                modelEligible=coverage.get("modelEligible"),
                missingStartingXICount=len(coverage.get("missingStartingXI") or []),
            )
        )
    return (
        sorted(records.values(), key=lambda r: (moment(r["date"]), r["game"], r["player"])),
        targets,
        dict(ll_receipt),
        prices,
        receipts,
        digest.hexdigest(),
    )


def build_features(rows, records, targets):
    by_game = {g["id"]: g for g in targets}
    if len(by_game) != len(targets):
        raise ValueError("Duplicate canonical routine target fixture")
    records = sorted(records, key=lambda r: (moment(r["date"]), r["game"], r["player"]))
    if len({(r["game"], r["player"]) for r in records}) != len(records):
        raise ValueError("Routine source observations must be deduplicated")
    histories = defaultdict(list)
    index = 0
    locks = [cutoff_for(r["date"]) for r in rows]
    result = np.full((len(rows), len(NAMES)), np.nan)
    for i in sorted(range(len(rows)), key=lambda j: locks[j]):
        row, lock = rows[i], locks[i]
        while index < len(records) and moment(records[index]["date"]) + timedelta(hours=48) < lock:
            r = records[index]
            histories[r["player"], r["pos"]].append(r)
            index += 1
        g = by_game.get(row["game"])
        player = (g or {}).get("players", {}).get(row["player"])
        if g is None or player is None or row["date"] != g["date"]:
            raise ValueError("Canonical routine query identity/date missing")
        club = player.get("team")
        if club not in (g["home"]["slug"], g["away"]["slug"]):
            raise ValueError("Canonical routine query actual playing side missing")
        previous = [r for r in histories[row["player"], row["pos"]] if moment(r["date"]) >= lock - timedelta(days=365)]
        values = {}
        for source in SOURCES:
            eligible = [r for r in previous if source == "combined" or r["source"] == "euro"]
            for group in GROUPS:
                chosen = [r for r in eligible if group == "same_position" or r["cohort"] == row["cohort"]]
                for n in WINDOWS:
                    summary = routine.summary(chosen[-n:], lock, club)
                    values.update({f"routine_{source}_{group}_{n}_{field}": value for field, value in summary.items()})
        result[i] = [values[n] for n in NAMES]
    if np.isinf(result).any():
        raise ValueError("Infinite routine-history feature")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    plan_path = args.report.with_suffix(".plan.json")
    plan = json.loads(plan_path.read_text())
    records, targets, ll_receipt, prices, receipts, ll_sha = read_sources(args.games, args.archives)
    if ll_sha not in plan["sources"] or any(r["sha256"] not in plan["sources"] for r in receipts):
        raise ValueError("Registered native routine source hashes differ")
    modules = (routine, ordinary, modal, score_search)
    key = hashlib.sha256(
        (source["key"] + ll_sha + "".join(r["sha256"] for r in receipts)).encode()
        + Path(__file__).read_bytes()
        + plan_path.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    print(
        f"ROUTINE_HISTORY_BUILD observations{len(records)} cases{len(source['rows'])} features{len(NAMES)}", flush=True
    )
    x = build_features(source["rows"], records, targets)
    np.savez_compressed(args.out, key=key, x=x, names=NAMES)
    corpus = dict(
        key=key,
        records=records,
        targets=targets,
        receipts=receipts,
        laligaSha256=ll_sha,
        earlyNativePrices=prices,
        laligaReceipt=ll_receipt,
    )
    args.out.with_suffix(".observations.json.gz").write_bytes(
        gzip.compress(json.dumps(corpus, allow_nan=False).encode())
    )
    coverage = {}
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        coverage[cohort] = dict(
            n=int(selected.sum()),
            withExactEuroRoutineHistory=int(
                (x[selected, NAMES.index("routine_euro_same_position_15_exact_games")] > 0).sum()
            ),
            withKnownSameCohortEuroRoutineHistory=int(
                (x[selected, NAMES.index("routine_euro_same_cohort_15_exact_games")] > 0).sum()
            ),
        )
    output = dict(
        scope="Testing-only corrected routine history source/feature stage; no accuracy claim",
        sourceKey=source["key"],
        featureKey=key,
        cases=len(x),
        features=len(NAMES),
        observations=len(records),
        receipts=receipts,
        laligaSha256=ll_sha,
        laligaReceipt=ll_receipt,
        earlyNativePrices=prices,
        laterCoverage=coverage,
        routineKinds=dict(Counter(r["routine"]["kind"] for r in records)),
        limitations=plan["limitations"],
    )
    args.report.write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
