"""Testing-only conservative public quote linkage and hindsight coverage bound."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_match_context import CLUBS
from app.research.score_search import cutoff_for, moment


def words(value):
    return re.findall("[a-z]+", unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower())


def candidates(printed, names):
    tokens = words(printed)
    if not tokens:
        return []
    found = []
    for player, aliases in names.items():
        for alias in [player.replace("-", " "), *aliases]:
            available = words(alias)
            if len(tokens) == 1:
                match = tokens == available
            else:
                full = [t for t in tokens if len(t) > 1]
                initials = [t for t in tokens if len(t) == 1]
                remaining = list(available)
                match = bool(full)
                for token in full:
                    if token not in remaining:
                        match = False
                        break
                    remaining.remove(token)
                for initial in initials:
                    hit = next((t for t in remaining if t.startswith(initial)), None)
                    if hit is None:
                        match = False
                        break
                    remaining.remove(hit)
            if match:
                found.append(player)
                break
    return sorted(found)


def club_slug(value):
    aliases = {
        "athletic bilbao": "Athletic Club",
        "atl madrid": "Atletico Madrid",
        "alaves": "Deportivo Alaves",
        "betis": "Real Betis",
        "celta": "Celta Vigo",
        "valladolid": "Real Valladolid",
        "oviedo": "Real Oviedo",
    }
    key = " ".join(words(value))
    return {" ".join(words(k)): v for k, v in CLUBS.items()}.get(" ".join(words(aliases.get(key, value))))


def fixture_candidates(quote, games):
    club, listed = club_slug(quote["club"]), moment(quote["listedTimeUTC"])
    if club is None:
        return []
    return sorted(
        g["id"]
        for g in games
        if club in (g["home"]["slug"], g["away"]["slug"])
        and timedelta(0) <= moment(g["date"]) - listed <= timedelta(minutes=5)
    )


def past_club_candidates(possible, club, lock, games):
    latest = {}
    for game in sorted(games, key=lambda g: (g["date"], g.get("id", ""))):
        date = moment(game["date"])
        if date + timedelta(hours=48) >= lock or lock - date > timedelta(days=365):
            continue
        for player in possible:
            p = game.get("players", {}).get(player, {})
            if p.get("played") is True:
                latest[player] = p.get("team")
    return sorted(p for p in possible if latest.get(p) == club)


def optimistic_bound(correct, total, misses, unresolved):
    maximum = min(total, correct + misses + unresolved)
    return dict(
        baselineCorrect=correct,
        allCases=total,
        mappedCoveredMisses=misses,
        unresolvedPossibleQuotes=unresolved,
        optimisticCorrect=maximum,
        optimisticPercent=maximum / total * 100,
        strictlyAbove50Possible=2 * maximum > total,
    )


def link(quote, games, names):
    possible_games = fixture_candidates(quote, games)
    possible_players = candidates(quote["player"], names)
    result = dict(
        fixtureCandidates=possible_games,
        nameCandidates=possible_players,
        game=None,
        player=None,
        metadataBeforeNativeLock=False,
    )
    if len(possible_games) != 1:
        return result | dict(status="unknown_fixture")
    game = next(g for g in games if g["id"] == possible_games[0])
    lock = cutoff_for(game["date"])
    result.update(game=game["id"], metadataBeforeNativeLock=moment(quote["provisionalAvailableUTC"]) < lock)
    if len(possible_players) > 1:
        possible_players = past_club_candidates(possible_players, club_slug(quote["club"]), lock, games)
    result["pastClubCandidates"] = possible_players
    if len(possible_players) != 1:
        return result | dict(status="unknown_player")
    return result | dict(player=possible_players[0], status="linked")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pilot", type=Path, default=Path("reports/experiments/laliga_score_market_booklets.json"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_market_identity.json"))
    args = parser.parse_args()
    root = Path("data/raw/score-foundation")
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    if (
        hashlib.sha256(native.read_bytes()).hexdigest()
        != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
    ):
        raise ValueError("Frozen native source changed")
    games = [json.loads(line) for line in native.read_text(encoding="utf-8").splitlines()]
    players = {p for g in games for p in g["players"]}
    aliases = json.loads((root / "player_names.json").read_text())
    names = {p: aliases.get(p, []).copy() for p in sorted(players)}
    identities = json.loads((root / "physical-traits/identities.json").read_text())
    with (root / "physical-traits/players_fifa23.csv").open(encoding="utf-8-sig", newline="") as handle:
        fifa = {int(r["ID"]): r for r in csv.DictReader(handle)}
    for p, evidence in identities.items():
        if evidence["id"] is not None and p in names:
            r = fifa[evidence["id"]]
            names[p].extend([r["Name"], r["FullName"]])
    pilot_path = args.pilot
    pilot = json.loads(pilot_path.read_text())
    records = []
    for booklet in pilot["booklets"]:
        for quote in booklet["records"]:
            records.append(dict(file=booklet["file"], quote=quote, **link(quote, games, names)))
    cases = json.loads((root / "cases.json").read_text())["rows"]
    bounds = {}
    for cohort, filename, expected in [
        ("start", "laliga_score_team_share_predictions_start.npz", 2765),
        ("bench", "laliga_score_mixture_shrunk_predictions_bench.npz", 2201),
    ]:
        rows = [r for r in cases if r["cohort"] == cohort and r["date"] >= "2026-01-01"]
        saved = np.load(root / filename)
        y = np.array([r["score"] for r in rows])
        if not np.array_equal(y, saved["y"]):
            raise ValueError("Saved prediction row identity mismatch")
        hit = np.abs(y - saved["prediction"]) <= 7
        if hit.sum() != expected or len(rows) != {"start": 6754, "bench": 2925}[cohort]:
            raise ValueError("Frozen denominator/control changed")
        index = {(r["game"], r["player"]): i for i, r in enumerate(rows)}
        covered = {
            index[r["game"], r["player"]]
            for r in records
            if r["status"] == "linked" and r["metadataBeforeNativeLock"] and (r["game"], r["player"]) in index
        }
        unresolved = [
            r
            for r in records
            if r["status"] != "linked"
            and r["quote"]["listedTimeUTC"] >= "2026-01-01"
            and r["quote"]["metadataBeforeLock"]
        ]
        bounds[cohort] = optimistic_bound(expected, len(rows), sum(not hit[i] for i in covered), len(unresolved))
        bounds[cohort].update(mappedCoveredCases=len(covered), quotedAlreadyCorrect=sum(bool(hit[i]) for i in covered))
    inputs = [
        pilot_path,
        root / "player_names.json",
        root / "physical-traits/identities.json",
        root / "physical-traits/players_fifa23.csv",
        root / "cases.json",
        native,
    ]
    hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    report = dict(
        scope="Source pilot only; hindsight ceiling for own current match quotes only",
        sourceHashes=hashes,
        implementationKey=hashlib.sha256(
            Path(__file__).read_bytes() + json.dumps(hashes, sort_keys=True).encode()
        ).hexdigest(),
        quotes=len(records),
        linkageCounts=dict(Counter(r["status"] for r in records)),
        modelEligibleQuotes=0,
        records=records,
        ownCurrentQuoteOnlyBounds=bounds,
        limitation="Original publication receipt and market settlement unresolved; no fair probability or formula fitted. Pilot coverage bound does not describe a full archive or team/past-price models.",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(
        "MARKET_IDENTITY", json.dumps({k: report[k] for k in ["quotes", "linkageCounts", "ownCurrentQuoteOnlyBounds"]})
    )


if __name__ == "__main__":
    main()
