import numpy as np

from app.research import score_shot_style_probe as probe


def test_missing_array_differs_from_recorded_empty_side():
    assert not probe.summarize(None, "home")["streamPresent"]
    empty = probe.summarize([], "home")
    assert empty["streamPresent"] and empty["shots"] == 0
    assert empty["goalCount"] == empty["onTargetCount"] == 0


def test_unknown_flags_and_boundary_coordinates_do_not_become_false_or_known():
    events = [
        dict(team="home", x=0, y=50, goal=None, onTarget=True, body="Header", sit="Open Play"),
        dict(team="away", x=90, y=50, goal=True, onTarget=True, body="Right Foot", sit="Open Play"),
    ]
    result = probe.summarize(events, "home")
    assert result["shots"] == 1 and result["usableCoordinates"] == 0
    assert result["goalCount"] is None and result["onTargetCount"] == 1
    assert result["body"] == {"Header": 1}


def test_provider_quality_never_uses_publisher_model_fallback():
    assert probe.provider_quality(dict(xg=0.7, xgot_model=0.8)) is None
    assert probe.provider_quality(dict(xg_fotmob=0.2, xg_understat=0.4)) == np.mean([0.2, 0.4])
    assert probe.provider_quality(dict(xg_fotmob=-0.1, xg_understat=0.5)) == 0.5
