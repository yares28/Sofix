"""Count already-recorded misses on first-six coach fixture candidates."""

import hashlib
import json

from app.research.score_absence_clock_pilot import coverage_ceiling
from app.research.score_absence_role_signal import REPORTS, ROOT


def main():
    evidence = REPORTS / "laliga_score_coach_clocks.json"
    report = json.loads(evidence.read_bytes())
    rows = json.loads((ROOT / "cases.json").read_bytes())["rows"]
    groups = {}
    for key in ("timelyClockAndTitleFixtureCandidates", "candidateFixtures"):
        games = {g for appointment in report["appointments"] for g in appointment[key]}
        groups[key] = coverage_ceiling(rows, games)
    result = dict(
        sourceSHA=hashlib.sha256(evidence.read_bytes()).hexdigest(),
        diagnostic=groups,
        note="Hindsight ceiling on these listed fixture sets. Grants perfect forecasts on both teams and leaves all "
        "other forecasts fixed. The sets are provisional, especially the locator-only group. No model was fitted.",
    )
    (REPORTS / "laliga_score_coach_coverage.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
