"""Offline source audit of unused take-on start coordinates and pitch frames."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import re
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research.score_match_context import CLUBS, normalise, season_year
from app.research.score_prior_chances import words

COMMIT = "20281026b7d3e948e8b25196fcfcf6d7c29ffe90"


def opposing_frame(points):
    points = np.asarray(points, dtype=float)
    if (
        points.ndim != 2
        or points.shape[1] != 2
        or not np.isfinite(points).all()
        or ((points < 0) | (points > 100)).any()
    ):
        raise ValueError("Known native0to100 point coordinates required")
    return 100 - points


def stream_summary(events, side):
    if side not in ("home", "away"):
        raise ValueError("Actual fixture side required")
    if not isinstance(events, list):
        return dict(
            known=False,
            attempts=None,
            successes=None,
            spatialKnown=None,
            ambiguousCoordinates=None,
            invalidFlags=None,
            grid=None,
        )
    selected = [e for e in events if e.get("team") == side]
    known = [e for e in selected if type(e.get("ok")) is bool]
    coordinates = []
    for event in known:
        values = [event.get("x"), event.get("y")]
        if all(type(v) in (int, float) and np.isfinite(v) and 0 < v < 100 for v in values):
            coordinates.append(values)
    grid = np.zeros((3, 3), dtype=int)
    for x, y in coordinates:
        grid[int(x * 3 / 100), int(y * 3 / 100)] += 1
    return dict(
        known=True,
        attempts=len(selected),
        successes=sum(e["ok"] for e in known) if len(known) == len(selected) else None,
        spatialKnown=len(coordinates),
        ambiguousCoordinates=len(known) - len(coordinates),
        invalidFlags=len(selected) - len(known),
        grid=grid.tolist(),
    )


def source_index(repo):
    env = {**os.environ, "GIT_NO_LAZY_FETCH": "1"}
    head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], env=env, text=True).strip()
    if head != COMMIT:
        raise ValueError("Spatial source revision differs")
    tree = subprocess.check_output(["git", "-C", str(repo), "ls-tree", "-r", "HEAD"], env=env, text=True)
    return {line.split("\t", 1)[1]: line.split()[2] for line in tree.splitlines()}


def read_verified(repo, relative, blobs, local=None):
    path = repo / relative if local is None else local
    if relative not in blobs or not path.exists():
        return None, None
    raw = path.read_bytes().replace(b"\r\n", b"\n")
    digest = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    if digest != blobs[relative]:
        raise ValueError("Spatial source blob differs: " + relative)
    return json.loads(raw.decode().split("=", 1)[1].strip().rstrip(";")), raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=Path("data/raw/score-foundation/match-context/data.txt"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_spatial_pressure_probe.json")
    )
    args = parser.parse_args()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native fixtures source changed")
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    native = defaultdict(list)
    for game in games:
        native[season_year(game["date"]), game["home"]["slug"], game["away"]["slug"]].append(game)
    blobs = source_index(args.repo)
    schedule, _ = read_verified(args.repo, "laliga_dashboard/data.js", blobs, local=args.manifest)
    if schedule is None:
        raise ValueError("The verified source manifest is not materialized in the specified cache")
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        {
            normalise(k): v
            for k, v in (
                ("Alaves", CLUBS["Deportivo Alaves"]),
                ("Celta", CLUBS["Celta Vigo"]),
                ("Deportivo La Coruna", CLUBS["Deportivo A Coruna"]),
            )
        }
    )
    counts, source_hash = Counter(), hashlib.sha256()
    seen, records = set(), []
    orientation = {side: {"shotX": [], "leftPassY": [], "rightPassY": []} for side in ("home", "away")}
    disagreements = []
    for season in schedule["seasons"].values():
        for entry in season["matches"]:
            if entry.get("played") is not True:
                continue
            identity = (
                season_year(entry["date"]),
                clubs.get(normalise(entry["home"])),
                clubs.get(normalise(entry["away"])),
            )
            matching = native.get(identity, [])
            if len(matching) != 1:
                counts["noUniqueLocalFixture"] += 1
                continue
            game = matching[0]
            if game["id"] in seen:
                raise ValueError("Duplicate native source fixture")
            seen.add(game["id"])
            relative = f"laliga_dashboard/matches_detail/{entry['id']}.js"
            detail, canonical = read_verified(args.repo, relative, blobs)
            if detail is None:
                counts["missingDetail"] += 1
                continue
            source_hash.update(canonical)
            if tuple(clubs.get(normalise(detail[s].get("name", ""))) for s in ("home", "away")) != identity[
                1:
            ] or tuple(detail[s].get("score") for s in ("home", "away")) != (game["homeGoals"], game["awayGoals"]):
                counts["headerConflict"] += 1
                continue
            counts["verifiedFixtures"] += 1
            for side in ("home", "away"):
                club, opponent = game[side]["slug"], game["away" if side == "home" else "home"]["slug"]
                summary = stream_summary(detail.get("dribbles"), side)
                people = [p for p in game["players"].values() if p.get("team") == club and p.get("played") is True]
                native_known = all(p.get("ver") == 7 and isinstance(p.get("stats"), dict) for p in people)
                native_won = sum(p["stats"].get("won_contest", [0, 0])[0] for p in people) if native_known else None
                same = (
                    native_won is not None and summary["successes"] is not None and native_won == summary["successes"]
                )
                counts["teamSides"] += 1
                counts["successTotalsMatchNative"] += int(same)
                if summary["known"]:
                    for name in ("attempts", "spatialKnown", "ambiguousCoordinates", "invalidFlags"):
                        counts[name] += summary[name]
                    counts["successes"] += summary["successes"] or 0
                if not same and len(disagreements) < 20:
                    disagreements.append(
                        dict(
                            game=game["id"], club=club, nativeWonContest=native_won, sourceSuccess=summary["successes"]
                        )
                    )
                takeons = [
                    [e["x"], e["y"], int(e["ok"])]
                    for e in detail.get("dribbles", [])
                    if e.get("team") == side
                    and type(e.get("ok")) is bool
                    and all(type(e.get(v)) in (int, float) and np.isfinite(e[v]) and 0 < e[v] < 100 for v in ("x", "y"))
                ]
                records.append(
                    dict(
                        game=game["id"],
                        date=game["date"],
                        club=club,
                        opponent=opponent,
                        sourcePath=relative,
                        sourceBlob=blobs[relative],
                        summary=summary,
                        nativeWonContest=native_won,
                        countsVerified=same,
                        takeons=takeons,
                    )
                )
                shots = detail.get("shots") or []
                orientation[side]["shotX"].extend(
                    e["x"]
                    for e in shots
                    if e.get("team") == side and type(e.get("x")) in (int, float) and 0 < e["x"] < 100
                )
                pass_y = defaultdict(list)
                for e in detail.get("passes") or []:
                    if e.get("team") == side and type(e.get("y")) in (int, float) and 0 < e["y"] < 100:
                        pass_y[words(e.get("player", ""))].append(e["y"])
                lineup = (detail.get("lineups") or {}).get(side) or {}
                for person in lineup.get("starters", []):
                    role = str(person.get("pos", ""))
                    match = re.search(r"(?:\(|^|[A-Z])([LR])\)?$", role)
                    y = pass_y.get(words(person.get("name", "")), [])
                    if match and y:
                        orientation[side]["leftPassY" if match[1] == "L" else "rightPassY"].append(float(np.mean(y)))
    old = json.loads((args.out.parent / "laliga_score_player_context.json").read_text())["metadata"]["sourceAudit"]
    if source_hash.hexdigest() != old["sourceContentSha256"] or counts["verifiedFixtures"] != old["verifiedFixtures"]:
        raise ValueError("Probe did not reproduce original verified source fixture coverage")
    out = dict(
        scope="New source audit only, not prediction accuracy",
        nativeFixtures=len(games),
        sourceCommit=COMMIT,
        sourceContentSha256=source_hash.hexdigest(),
        counts=dict(counts),
        disagreementSamples=disagreements,
        orientation={
            side: {
                key: dict(
                    n=len(values),
                    mean=float(np.mean(values)) if values else None,
                    median=float(np.median(values)) if values else None,
                )
                for key, values in group.items()
            }
            for side, group in orientation.items()
        },
        limitations="Native start coordinates only. Boundary0/100 ambiguous due publisher default0; no inferred endpoints/receivers. Known matched successes do not prove failed-attempt completeness; source stream validation remains separate. Historical spatial facts need strict prelock lag before any feature use.",
    )
    path = Path("data/raw/score-foundation/spatial_pressure_observations.json.gz")
    path.write_bytes(
        gzip.compress(
            json.dumps(dict(source=out, observations=records), separators=(",", ":"), allow_nan=False).encode(), mtime=0
        )
    )
    out["observationsFile"] = str(path)
    out["observationsSha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    args.out.write_text(json.dumps(out, indent=2, allow_nan=False))
    print("SPATIAL_SOURCE " + json.dumps(out), flush=True)


if __name__ == "__main__":
    main()
