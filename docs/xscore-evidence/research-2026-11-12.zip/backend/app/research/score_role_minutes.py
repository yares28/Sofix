"""Testing only: predict role/minutes, then a conditional Sorare score."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_stats_hybrid import choose_level
from app.research.score_stats_run import paired_interval


def geometry_group(game, player, position):
    if position == "GK":
        return 0
    team = game["players"][player]["team"]
    side = "home" if team == game["home"]["slug"] else "away"
    form = (game.get("xi") or {}).get(side) or {}
    if form.get("available") is not True:
        return 9
    lines = form.get("start") or []
    for i, line in enumerate(lines):
        if player not in line:
            continue
        depth = i / max(1, len(lines) - 1)
        edge = abs(line.index(player) / (len(line) - 1) - 0.5) * 2 if len(line) > 1 else 0
        if position == "DEF":
            return 3 if depth >= 0.5 else 2 if len(line) >= 4 and edge >= 0.66 else 1
        if position == "MID":
            return 6 if depth >= 0.65 else 5 if len(line) >= 3 and edge >= 0.66 else 4
        if position == "FWD":
            return 8 if len(line) >= 3 and edge >= 0.66 else 7
    return 9


def role_arrays(games, rows):
    indexed = {g["id"]: g for g in games}
    queue = sorted(games, key=lambda g: (g["date"], g["id"]))
    last = {}
    labels, previous = [], []
    seen = 0
    prior_cutoff = None
    for row in rows:
        cutoff = cutoff_for(row["date"])
        if prior_cutoff is not None and cutoff < prior_cutoff:
            raise ValueError("Rows must be chronological")
        prior_cutoff = cutoff
        while seen < len(queue) and moment(queue[seen]["date"]) + timedelta(hours=48) < cutoff:
            game = queue[seen]
            for player, p in game["players"].items():
                if p.get("played") is True and p.get("started") is True and p.get("ver") == 7:
                    group = geometry_group(game, player, p["pos"])
                    if group != 9:
                        last[player] = p["pos"], group
            seen += 1
        known_pos, known = last.get(row["player"], (None, 9))
        known = known if known_pos == row["pos"] else 9
        previous.append(known)
        labels.append(
            geometry_group(indexed[row["game"]], row["player"], row["pos"]) if row["cohort"] == "start" else known
        )
    return np.array(labels), np.array(previous)


def conditional_forecasts(x, roles, previous, minutes, aa, levels, fit, check, cohort):
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

    classifier_params = dict(
        max_leaf_nodes=7,
        min_samples_leaf=80,
        max_iter=120,
        learning_rate=0.06,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )
    regression_params = dict(
        max_leaf_nodes=15,
        min_samples_leaf=60,
        max_iter=120,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )
    if cohort == "start":
        role_model = HistGradientBoostingClassifier(**classifier_params).fit(x[fit], roles[fit])
        estimated = role_model.predict(x[check])
        variants = {"classified": estimated, "last": np.where(previous[check] == 9, estimated, previous[check])}
    else:
        variants = {"last": previous[check]}
    role_column = x.shape[1]
    training_role = np.column_stack((x[fit], roles[fit]))
    training_minutes = np.column_stack((training_role, minutes[fit]))
    training_level = np.column_stack((training_minutes, levels[fit]))
    decisive = HistGradientBoostingClassifier(**classifier_params, categorical_features=[role_column]).fit(
        training_minutes, levels[fit].astype(int)
    )
    ordinary_models = {
        q: HistGradientBoostingRegressor(
            loss="quantile", quantile=q, **regression_params, categorical_features=[role_column, role_column + 2]
        ).fit(training_level, aa[fit])
        for q in (0.35, 0.5, 0.65)
    }
    out = {}
    for mq in (0.35, 0.5, 0.65):
        min_model = HistGradientBoostingRegressor(
            loss="quantile", quantile=mq, **regression_params, categorical_features=[role_column]
        ).fit(training_role, minutes[fit])
        for variant, role in variants.items():
            predicted_role = np.column_stack((x[check], role))
            mins = np.clip(min_model.predict(predicted_role), 0, 100)
            predicted_minutes = np.column_stack((predicted_role, mins))
            probability = decisive.predict_proba(predicted_minutes)
            parts = {
                q: np.column_stack(
                    [
                        model.predict(np.column_stack((predicted_minutes, np.full(check.sum(), v))))
                        for v in decisive.classes_
                    ]
                )
                for q, model in ordinary_models.items()
            }
            out[variant, mq] = {
                "classes": decisive.classes_,
                "probability": probability,
                "ordinary": parts,
                "role": role,
                "minutes": mins,
            }
    return out


def predict_score(bundle, q, threshold, shift):
    level = choose_level(bundle["probability"], bundle["classes"], threshold)
    index = np.searchsorted(bundle["classes"], level)
    ordinary = bundle["ordinary"][q][np.arange(len(index)), index] + shift
    return np.clip(level + ordinary, np.where(level >= 60, level, 0), 100), ordinary


def save_bundles(path, key, bundles):
    arrays = {"key": key, "options": json.dumps(list(bundles))}
    for i, bundle in enumerate(bundles.values()):
        for name in ("classes", "probability", "role", "minutes"):
            arrays[f"b{i}_{name}"] = bundle[name]
        for q, ordinary in bundle["ordinary"].items():
            arrays[f"b{i}_q{q}"] = ordinary
    np.savez_compressed(path, **arrays)


def load_bundles(path, key):
    if not path.exists():
        return None
    with np.load(path) as arrays:
        if str(arrays["key"]) != key:
            return None
        bundles = {}
        for i, option in enumerate(json.loads(str(arrays["options"]))):
            bundles[tuple(option)] = {
                name: arrays[f"b{i}_{name}"] for name in ("classes", "probability", "role", "minutes")
            }
            bundles[tuple(option)]["ordinary"] = {q: arrays[f"b{i}_q{q}"] for q in (0.35, 0.5, 0.65)}
        return bundles


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "games", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    raw = args.games.read_bytes()
    games = [json.loads(s) for s in raw.decode("utf-8").splitlines() if s.strip()]
    with np.load(args.stats_cache) as stored:
        x = stored["x"]
        stat_key = str(stored["key"])
    roles, previous = role_arrays(games, source["rows"])
    key = hashlib.sha256((source["key"] + stat_key).encode() + raw + Path(__file__).read_bytes()).hexdigest()
    report = {
        "target": "All LaLiga scores within seven, if starting and if coming on separately",
        "method": "Forecast formation geometry and minutes, then choose a conditional decisive/ordinary score",
        "evidenceLimit": "Retrospective exploratory reuse; actual check role/minutes/level never used to predict",
        "sourceKey": source["key"],
        "implementationKey": key,
        "benchRolePolicy": "Last known starting geometry is a proxy; actual on-field substitute role is not observed",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        aa = np.array([r["aa"] for r in rows])
        levels = np.array([r["level"] for r in rows])
        minutes = np.array([r["minutes"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        path = args.cache / f"role_minutes_{cohort}_selection.npz"
        earlier = load_bundles(path, key)
        if earlier is None:
            earlier = conditional_forecasts(
                x[keep], roles[keep], previous[keep], minutes, aa, levels, train, valid, cohort
            )
            save_bundles(path, key, earlier)
        candidates = []
        for (variant, mq), bundle in earlier.items():
            for q in (0.35, 0.5, 0.65):
                for threshold in np.arange(0.1, 0.951, 0.025):
                    for shift in (-3, 0, 3):
                        prediction, _ = predict_score(bundle, q, float(threshold), shift)
                        candidates.append(
                            {
                                "roleForecast": variant,
                                "minuteQuantile": mq,
                                "ordinaryQuantile": q,
                                "threshold": float(threshold),
                                "shift": shift,
                                "selection": measure(y[valid], prediction),
                            }
                        )
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        path = args.cache / f"role_minutes_{cohort}_later.npz"
        later = load_bundles(path, key)
        if later is None:
            later = conditional_forecasts(
                x[keep], roles[keep], previous[keep], minutes, aa, levels, ~test, test, cohort
            )
            save_bundles(path, key, later)
        bundle = later[winner["roleForecast"], winner["minuteQuantile"]]
        prediction, ordinary = predict_score(bundle, winner["ordinaryQuantile"], winner["threshold"], winner["shift"])
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(y[test], stored["y"]):
                raise ValueError("Control cases differ")
            control = stored["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        pos = np.array([r["pos"] for r in rows])[test]
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "staticControl": measure(y[test], control),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, control, weeks),
            "minutesMiss": float(np.mean(abs(minutes[test] - bundle["minutes"]))),
            "ordinaryPoints": measure(aa[test], ordinary),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {p: measure(y[test][pos == p], prediction[pos == p]) for p in POSITIONS if (pos == p).any()},
        }
        if cohort == "start":
            known = roles[keep][test] != 9
            result["geometryGroupAccuracy"] = float(np.mean(bundle["role"][known] == roles[keep][test][known]))
            result["missingActualGeometry"] = int((~known).sum())
        np.savez_compressed(
            args.cache / f"role_minutes_predictions_{cohort}.npz",
            prediction=prediction,
            y=y[test],
            role=bundle["role"],
            minutes=bundle["minutes"],
            key=key,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
