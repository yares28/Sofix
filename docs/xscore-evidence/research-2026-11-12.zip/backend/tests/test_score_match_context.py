import copy

import numpy as np

from app.research.score_match_context import context_features, parse_source, read_calendar


def raw_game(date, **extra):
    return {
        "id": date,
        "date": date[:10],
        "kickoff": date,
        "played": True,
        "home": "Barcelona",
        "away": "Real Madrid",
        "hs": 1,
        "as": 0,
        "xg_home_understat": 0,
        "xg_away_understat": 1.2,
        "stats": {},
        **extra,
    }


def target(date):
    return {
        "id": date,
        "date": date,
        "home": {"slug": "barcelona-barcelona"},
        "away": {"slug": "real-madrid-madrid"},
        "players": {"p": {"team": "barcelona-barcelona"}},
        "homeGoals": 1,
        "awayGoals": 0,
    }


def case(date):
    return {"game": date, "player": "p", "date": date}


def payload(*games):
    return {"seasons": {"s": {"matches": list(games)}}}


def test_only_named_provider_chance_values_are_used_and_observed_zero_is_kept():
    source = raw_game("2025-10-01T20:00:00Z", xg_home=99, xg_away=99, xg_estimated=False)
    external, _ = parse_source(payload(source), [])
    row = case("2025-10-12T20:00:00Z")
    x, names, _ = context_features([row], [target(row["date"])], external)
    assert x[0, names.index("own_3_xg_for_mean")] == 0
    assert x[0, names.index("own_3_xg_against_mean")] == 1.2
    source.update(xg_home_understat=None, xg_away_understat=None)
    external, _ = parse_source(payload(source), [])
    missing, _, _ = context_features([row], [target(row["date"])], external)
    assert np.isnan(missing[0, names.index("own_3_xg_for_mean")])


def test_current_and_same_week_games_cannot_enter_the_forecast():
    old = raw_game("2025-10-01T20:00:00Z")
    same_week = raw_game("2025-10-11T20:00:00Z", away="Getafe", xg_home_understat=7)
    current = raw_game("2025-10-12T20:00:00Z", away="Valencia", xg_home_understat=9)
    row = case(current["kickoff"])
    a, _ = parse_source(payload(old, same_week, current), [])
    before, _, _ = context_features([row], [target(row["date"])], a)
    changed = copy.deepcopy(same_week)
    changed.update(xg_home_understat=0, ppda_home=100)
    b, _ = parse_source(payload(old, changed), [])
    after, _, _ = context_features([row], [target(row["date"])], b)
    np.testing.assert_array_equal(before, after)


def test_absent_kickoff_uses_end_of_day_and_48_hour_delay():
    external, _ = parse_source(payload(raw_game("2025-10-08T01:00:00Z", kickoff="")), [])
    row = case("2025-10-10T20:00:00Z")
    x, names, _ = context_features([row], [target(row["date"])], external)
    assert x[0, names.index("own_recent_games")] == 0


def test_conflicting_score_and_unknown_club_source_rows_are_not_forced():
    source = raw_game("2025-10-01T20:00:00Z", hs=9)
    other = raw_game("2025-10-02T20:00:00Z", home="Unknown club")
    external, audit = parse_source(payload(source, other), [target(source["kickoff"])])
    assert external == []
    assert audit["scoreConflicts"] == 1
    assert audit["unknownClub"] == 1


def test_cold_and_stale_cases_are_kept_with_unknown_values():
    external, _ = parse_source(payload(raw_game("2025-04-01T20:00:00Z")), [])
    rows = [case("2025-03-01T20:00:00Z"), case("2025-10-12T20:00:00Z")]
    x, names, _ = context_features(rows, [target(r["date"]) for r in rows], external)
    assert len(x) == 2
    assert np.isnan(x[:, names.index("own_3_xg_for_mean")]).all()


def test_opponent_values_and_missing_box_intensity_remain_separate():
    external, _ = parse_source(payload(raw_game("2025-10-01T20:00:00Z", ppda_home=8, ppda_away=12)), [])
    row = case("2025-10-12T20:00:00Z")
    x, names, _ = context_features([row], [target(row["date"])], external)
    assert x[0, names.index("own_3_ppda_mean")] == 8
    assert x[0, names.index("opponent_3_ppda_mean")] == 12
    assert np.isnan(x[0, names.index("own_3_box_for_mean")])


def test_postponed_fixture_uses_played_date_and_cannot_leak_on_original_date():
    postponed = raw_game("2025-09-01T20:00:00Z", xg_home_understat=4)
    actual = target("2025-10-20T20:00:00Z")
    row = case("2025-10-12T20:00:00Z")
    query = target(row["date"])
    query["away"]["slug"] = "getafe-getafe-madrid"
    external, audit = parse_source(payload(postponed), [actual, query])
    assert external[0]["date"] == actual["date"]
    assert audit["correctedDates"] == 1
    x, names, _ = context_features([row], [target(row["date"])], external)
    assert x[0, names.index("own_recent_games")] == 0


def test_ambiguous_season_fixture_is_rejected_instead_of_choosing_a_date():
    external, audit = parse_source(
        payload(raw_game("2025-09-01T20:00:00Z")), [target("2025-10-10T20:00:00Z"), target("2025-10-20T20:00:00Z")]
    )
    assert external == []
    assert audit["ambiguousFixture"] == 1


def test_multiple_players_on_same_side_keep_all_cases_and_same_team_context():
    external, _ = parse_source(payload(raw_game("2025-10-01T20:00:00Z")), [])
    game = target("2025-10-12T20:00:00Z")
    game["players"]["q"] = {"team": "barcelona-barcelona"}
    rows = [case(game["date"]), {**case(game["date"]), "player": "q"}]
    x, _, _ = context_features(rows, [game], external)
    assert len(x) == 2
    np.testing.assert_array_equal(x[0], x[1])


def test_unverified_fixture_in_a_covered_season_cannot_enter_history():
    source = raw_game("2025-09-01T20:00:00Z", away="Getafe")
    external, audit = parse_source(payload(source), [target("2025-10-01T20:00:00Z")])
    assert external == []
    assert audit["unmatchedCoveredSeason"] == 1


def test_historical_calendar_retains_zero_goals_and_ignores_odds(tmp_path):
    path = tmp_path / "calendar.csv"
    path.write_text("Date,HomeTeam,AwayTeam,FTHG,FTAG,PSCH\n18/09/2022,Ath Madrid,Real Madrid,0,0,9.9\n")
    first = read_calendar(path)
    assert first[0]["homeGoals"] == 0
    assert first[0]["date"] == "2022-09-18T23:59:59Z"
    path.write_text(path.read_text().replace("9.9", "1.1"))
    assert first == read_calendar(path)
