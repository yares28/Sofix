"""Qualified short-window context around historical recovery and interception events."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
from collections import Counter, defaultdict, deque
from datetime import timedelta
from itertools import groupby
from pathlib import Path

import numpy as np

from app.research.score_openplay_duel_features import zone
from app.research.score_openplay_duel_signal import native_archive
from app.research.score_openplay_duel_source import SHA, query, source_fixtures
from app.research.score_search import cutoff_for, moment

ANCHORS = {"BallRecovery": 0, "Interception": 1}
FIELDS = ("raw", "previousPass", "previousOpponentPass", "followingPass", "retained")


def empty_stats():
    return np.zeros((2, 3, len(FIELDS)), dtype=float)


def pass_context(groups, index, direction):
    nearby = index + direction
    if nearby < 0 or nearby >= len(groups) or abs(groups[nearby][0] - groups[index][0]) > 8:
        return None
    group = groups[nearby][1]
    types = {(e["kind"], e["team"], e["outcome"]) for e in group}
    if len(types) != 1:
        return None
    kind, team, outcome = next(iter(types))
    return (team, outcome) if kind == "Pass" else None


def fixture_context(events, home, away, names):
    players, sides = defaultdict(empty_stats), {p: empty_stats() for p in (home, away)}
    allowed = {p: np.zeros((2, 3)) for p in (home, away)}
    passes, tally = Counter(), Counter()
    for _, half in groupby(events, lambda e: e["period"]):
        ticks = [(int(tick), list(group)) for tick, group in groupby(half, lambda e: e["tick"])]
        if [t for t, _ in ticks] != sorted(t for t, _ in ticks):
            raise ValueError("Source event order differs")
        for i, (_, group) in enumerate(ticks):
            for e in group:
                team, kind = e["team"], e["kind"]
                if team not in sides:
                    raise ValueError("Event side differs from source fixture")
                if kind == "Pass":
                    passes[team] += 1
                if kind not in ANCHORS:
                    continue
                event_type = ANCHORS[kind]
                coordinate = float(e["x"])
                if not 0 <= coordinate <= 100:
                    raise ValueError("Anchor coordinate out of range")
                third = zone(coordinate)
                tally["anchors"] += 1
                values = np.zeros(len(FIELDS))
                values[0] = 1
                if len(group) == 1:
                    previous, following = pass_context(ticks, i, -1), pass_context(ticks, i, 1)
                    if previous:
                        values[1] = 1
                        if previous[0] != team:
                            values[2] = 1
                            allowed[previous[0]][event_type, third] += 1
                    if following:
                        values[3] = 1
                        values[4] = following == (team, "Successful")
                else:
                    tally["sameSecondAmbiguousAnchors"] += 1
                sides[team][event_type, third] += values
                actor = names.get((team, e["player"]))
                if actor is not None:
                    players[actor][event_type, third] += values
                    tally["mappedAnchors"] += 1
    if not all(passes[team] > 0 for team in sides):
        raise ValueError("Missing open-play passes for a matched side")
    for index, key in enumerate(FIELDS[1:], 1):
        tally[key] = int(sum(v[:, :, index].sum() for v in sides.values()))
    return players, sides, allowed, passes, tally


def fixture_events(directory):
    sql = """
      SELECT match_id, team_id AS team, player_id AS player, period, 60 * minute + second AS tick,
             outcome, x, CASE
               WHEN type='Pass' AND NOT (coalesce(q_ThrowIn,false) OR coalesce(q_FreekickTaken,false)
                 OR coalesce(q_GoalKick,false) OR coalesce(q_CornerTaken,false)
                 OR coalesce(q_IndirectFreekickTaken,false)) THEN 'Pass'
               WHEN type IN ('BallRecovery','Interception') AND outcome='Successful' THEN type
               ELSE 'Stop' END AS kind
      FROM read_parquet('events_esp_*.parquet',union_by_name=true)
      WHERE period IN ('FirstHalf','SecondHalf')
        AND (type IN ('Pass','BallRecovery','Interception','Foul','OffsidePass','CornerAwarded','End','Start',
                      'SubstitutionOn','SubstitutionOff','Card') OR is_shot)
      ORDER BY match_id, period, tick
    """
    with subprocess.Popen(
        [str(directory.resolve() / "duckdb.exe"), "-batch", "-csv", "-c", sql],
        cwd=directory,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
    ) as process:
        if process.stdout is None or process.stderr is None:
            raise ValueError("Source reader pipes unavailable")
        for match_id, events in groupby(csv.DictReader(process.stdout), lambda e: e["match_id"]):
            yield match_id, list(events)
        error = process.stderr.read()
        if process.wait():
            raise ValueError(f"Source reader failed: {error}")


def offside_clock_audit(directory):
    result = query(
        directory,
        """
        WITH e AS (
          SELECT match_id,event_id,team_id,type,period,minute,second,team_event_id
          FROM read_parquet('events_esp_*.parquet',union_by_name=true) WHERE type IN ('OffsideGiven','OffsidePass')
        ), links AS (
          SELECT a.match_id,a.team_id,a.team_event_id,count(b.event_id) AS n FROM e a
          LEFT JOIN e b ON a.match_id=b.match_id AND a.team_id=b.team_id AND a.period=b.period AND a.minute=b.minute
            AND a.team_event_id=b.team_event_id+11000 AND a.event_id=b.event_id+11000
            AND b.second IS NOT NULL AND b.type='OffsidePass'
          WHERE a.type='OffsideGiven' GROUP BY ALL
        )
        SELECT count(*) AS offside_given, count(*) FILTER(WHERE n=1) AS unique_timed_markers,
          (SELECT count(*) FROM e WHERE type='OffsidePass') AS offside_passes FROM links
        """,
    )[0]
    counts = {k: int(v) for k, v in result.items()}
    if not counts["offside_given"] or len(set(counts.values())) != 1:
        raise ValueError("A clockless offside marker has no unique timed companion")
    return counts


def source_observations(directory, games, receipt):
    for name, expected in SHA.items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Source asset differs: {name}")
    identities = directory / "qualified_players.csv"
    if hashlib.sha256(identities.read_bytes()).hexdigest() != receipt["playerIdentityArtifactSha256"]:
        raise ValueError("Known mapped players differ")
    fixtures, _, _ = source_fixtures(directory, list(games.values()))
    mapped = defaultdict(dict)
    with identities.open(encoding="utf-8", newline="") as stream:
        for r in csv.DictReader(stream):
            game, f = fixtures[r["sourceMatch"]]
            if game["id"] != r["nativeGame"] or game["players"][r["nativePlayer"]]["team"] != r["club"]:
                raise ValueError("Past player fixture identity differs")
            side = "home" if r["club"] == game["home"]["slug"] else "away"
            mapped[r["sourceMatch"]][f[side + "_team_id"], r["sourcePlayer"]] = r["nativePlayer"]
    records, counts = {}, Counter()
    for key, events in fixture_events(directory):
        if key not in fixtures:
            continue
        game, fixture = fixtures[key]
        home, away = fixture["home_team_id"], fixture["away_team_id"]
        players, sides, allowed, passes, tally = fixture_context(events, home, away, mapped[key])
        counts.update(tally)
        player_records = {}
        for (team, _), native in mapped[key].items():
            p = game["players"][native]
            stats = players.get(native, empty_stats())
            player_records[native] = (stats, sides[team])
            if p["ver"] == 7 and p["pos"] in ("DEF", "MID"):
                for i, name in enumerate(("poss_won", "interception_won")):
                    count = stats[i, :, 0].sum()
                    counts[name + "Compared"] += 1
                    counts[name + "Exact"] += count == p["stats"].get(name, [0])[0]
        records[game["id"]] = (
            player_records,
            {
                game[side]["slug"]: (sides[team], allowed[team], passes[team])
                for side, team in (("home", home), ("away", away))
            },
        )
    if len(records) != len(fixtures):
        raise ValueError("A matched fixture has no usable event stream")
    return records, {k: int(v) for k, v in counts.items()} | offside_clock_audit(directory)


def collect(history, lower):
    return [parts for date, parts in history if date >= lower]


def summaries(own, team, opponent):
    p = sum(x[0] for x in own) if own else np.full((2, 3, len(FIELDS)), np.nan)
    played_team = sum(x[1] for x in own) if own else np.full_like(p, np.nan)
    t = sum(x[0] for x in team) if team else np.full_like(p, np.nan)
    opp = sum(x[0] for x in opponent) if opponent else np.full_like(p, np.nan)
    allowed = sum(x[1] for x in opponent) if opponent else np.full((2, 3), np.nan)
    raw = [
        (p[:, :, 0] / max(1, len(own))).ravel(),
        (t[:, :, 0] / max(1, len(team))).ravel(),
        (opp[:, :, 0] / max(1, len(opponent))).ravel(),
        [len(own), len(team), len(opponent)],
    ]
    workload = 0.5 * (t[:, :, 2] / max(1, len(team)) + allowed / max(1, len(opponent)))
    player_share = (p[:, :, 2] + 0.3) / (played_team[:, :, 2] + 6)
    context = [
        (p[:, :, 2] / max(1, len(own))).ravel(),
        ((p[:, :, 4] + 1) / (p[:, :, 3] + 2)).ravel(),
        (t[:, :, 2] / max(1, len(team))).ravel(),
        (allowed / max(1, len(opponent))).ravel(),
        (workload * player_share).ravel(),
        [np.mean([x[2] for x in h]) if h else np.nan for h in (team, opponent)],
    ]
    return np.concatenate(raw), np.concatenate(context)


def rolling_features(rows, games, observations):
    schedule = sorted((moment(games[k]["date"]) + timedelta(hours=48), k) for k in observations)
    players = defaultdict(lambda: deque(maxlen=10))
    clubs = defaultdict(lambda: deque(maxlen=8))
    raw, context = [], []
    cursor = 0
    order = sorted((cutoff_for(r["date"]), i) for i, r in enumerate(rows))
    for lock, i in order:
        while cursor < len(schedule) and schedule[cursor][0] < lock:
            available, game = schedule[cursor]
            cursor += 1
            a, b = observations[game]
            for player, data in a.items():
                players[player].append((available, data))
            for club, data in b.items():
                clubs[club].append((available, data))
        row = rows[i]
        game = games[row["game"]]
        player = row["player"]
        side = game["players"][player]["team"]
        teams = game["home"]["slug"], game["away"]["slug"]
        if row["date"] != game["date"] or side not in teams:
            raise ValueError("Target fixture identity differs")
        other = teams[1 - teams.index(side)]
        age = lock - timedelta(days=120) + timedelta(hours=48)
        a, b = summaries(collect(players[player], age), collect(clubs[side], age), collect(clubs[other], age))
        raw.append(a)
        context.append(b)
    restore = np.argsort([i for _, i in order])
    return np.array(raw)[restore], np.array(context)[restore]


def run(args):
    source = json.loads((args.cache / "cases.json").read_text())
    receipt = json.loads((args.out.parent / "laliga_score_openplay_duel_source.json").read_text())
    if source["key"] != receipt["sourceKey"]:
        raise ValueError("Qualified source case fingerprint differs")
    games = native_archive(args.games)
    directory = args.cache / "openplay-data-v0.1.0"
    observations, audit = source_observations(directory, games, receipt)
    rows = source["rows"]
    raw, context = rolling_features(rows, games, observations)
    lock = min(cutoff_for(r["date"]) for r in rows if r["date"] >= "2026-01-01")
    first = [i for i, r in enumerate(rows) if cutoff_for(r["date"]) == lock]
    eligible = {
        key: value for key, value in observations.items() if moment(games[key]["date"]) + timedelta(hours=48) < lock
    }
    stubs = {key: games[key] for key in eligible}
    for i in first:
        row = rows[i]
        game = games[row["game"]]
        stub = stubs.setdefault(game["id"], {k: game[k] for k in ("date", "home", "away")} | {"players": {}})
        stub["players"][row["player"]] = {"team": game["players"][row["player"]]["team"]}
    masked_raw, masked_context = rolling_features([rows[i] for i in first], stubs, eligible)
    np.testing.assert_array_equal(masked_raw, raw[first])
    np.testing.assert_array_equal(masked_context, context[first])
    out = directory / "regain_workload_features.npz"
    np.savez_compressed(out, sourceKey=source["key"], raw=raw, context=context)
    report = {
        "sourceKey": source["key"],
        "scope": "Historical event context and causal feature audit only",
        "fixtures": len(observations),
        "sourceEventAudit": audit,
        "rows": len(rows),
        "columnsRawAndContext": [raw.shape[1], context.shape[1]],
        "first2026LockCasesExactWithOutcomesRemoved": len(first),
        "unavailableFixturesRemoved": len(observations) - len(eligible),
        "featureSha256": hashlib.sha256(out.read_bytes()).hexdigest(),
    }
    args.out.write_text(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_regain_features.json")
    )
    run(parser.parse_args())


if __name__ == "__main__":
    main()
