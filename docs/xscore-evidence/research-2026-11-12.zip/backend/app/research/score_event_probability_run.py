"""Testing only: replace event probabilities while keeping frozen routine-point forecasts."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_event_probability as events
from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def fitted(data, names, positive, negative, positions, masks, setting, path, key):
    if path.exists():
        with np.load(path) as f:
            if str(f["key"]) != key or f["rates"].shape != (int(masks["target"].sum()), 2):
                raise ValueError("Event intensity calibration cache differs")
            return f["rates"], json.loads(str(f["statistics"]))
    group, mode = events.MODELS[setting]
    positive_raw = data[:, names.index("event_mu_" + group)]
    negative_raw = data[:, names.index("event_mu_negative")]
    rates, stats = events.fit_intensities(
        positive_raw, negative_raw, positive, negative, positions, masks["fit"], masks["target"], mode
    )
    np.savez_compressed(path, key=key, rates=rates, statistics=json.dumps(stats))
    return rates, stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "event-cache", "event-report", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import scipy
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    event_report = json.loads(args.event_report.read_text())
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary = map(
        read, ("laliga_score_match_context", "laliga_score_stability", "laliga_score_ordinary")
    )
    old_start, old_bench = map(read, ("laliga_score_match_empirical_density", "laliga_score_analogues"))
    if any(
        r["sourceKey"] != source["key"]
        for r in (event_report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Event comparison source cases differ")
    with np.load(args.event_cache) as f:
        data, names, feature_key = f["x"], f["names"].tolist(), str(f["key"])
        positive, negative = f["positive"], f["negative"]
        if (
            feature_key != event_report["featureKey"]
            or feature_key not in plan["inputs"]
            or len(data) != len(source["rows"])
        ):
            raise ValueError("Frozen event feature identity differs")
    files = [
        Path(__file__),
        Path(events.__file__),
        Path(matched.__file__),
        Path(controls.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + feature_key
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + scipy.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "eventFeatureKey": feature_key,
        "evidenceLimit": "Reused historical outcomes, exploratory not fresh blind proof",
        "cohorts": {},
    }
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        selected = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        actual_levels = np.array([r["level"] for r in rows])
        masks = stability.phase_masks(rows)
        candidates = [
            {
                "spec": {"model": model, "event_policy": event_policy, "decision": decision, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for model in events.MODELS
            for event_policy in ("counts", "state_totals")
            for decision in ("full", "state_changes")
            for scope in ("outfield", "defmid", "forward")
        ]
        previous = None
        winner = None
        best = None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            current_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            current = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "warm2023":
                previous = (current_rows, current)
                continue
            if phase == "later2026" and best is None:
                raise ValueError("Event comparison must freeze before final outcomes")
            active = [best] if phase == "later2026" else candidates
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric != expected:
                raise ValueError("Event comparison strongest control differs")
            previous_rows, previous_parts = previous
            bank = matched.bank_from(previous_parts, previous_rows, mask["first"])
            audit[phase] = {
                "fit": int(mask["fit"].sum()),
                "target": int(target.sum()),
                "control": metric,
                "errorBankCases": bank["cases"],
                "unknownBankLevels": bank["unknownLevels"],
                "models": {},
            }
            for model in sorted({r["spec"]["model"] for r in active}):
                rates, stats = fitted(
                    data[selected],
                    names,
                    positive[selected],
                    negative[selected],
                    positions,
                    mask,
                    model,
                    args.cache / f"{args.out.stem}_{cohort}_{phase}_{model}.npz",
                    key,
                )
                audit[phase]["models"][model] = {"fitDiagnostics": stats, "policies": {}}
                for policy in sorted({r["spec"]["event_policy"] for r in active if r["spec"]["model"] == model}):
                    probability = events.event_probabilities(current[0], rates[:, 0], rates[:, 1], policy, current[1])
                    candidate = empirical.empirical_predictions(
                        current[0], probability, current[2], positions[target], bank, 20, 0.75, 0
                    )
                    outfield = positions[target] != "GK"
                    ppositive = probability[:, current[0] >= 60].sum(axis=1)
                    audit[phase]["models"][model]["policies"][policy] = {
                        "outfieldPositiveEventProbabilityError": float(
                            np.mean((ppositive[outfield] - (actual_levels[target][outfield] >= 60)) ** 2)
                        )
                    }
                    for record in [
                        r for r in active if r["spec"]["model"] == model and r["spec"]["event_policy"] == policy
                    ]:
                        spec = record["spec"]
                        forecast = events.forecast_policy(
                            candidate, control, positions[target], spec["decision"], spec["scope"]
                        )
                        measured = measure(y[target], forecast)
                        if phase == "later2026":
                            alternate = forecast
                        else:
                            gain = measured["within7"] - metric["within7"]
                            record["gains"].append(gain)
                            record["errors"].append(measured["mae"])
                            record["counts"].append(len(forecast))
                            record["periods"][phase] = {"gain": gain, "metrics": measured}
                    print(f"EVENT_TESTED {cohort} {phase} {model} {policy}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(candidates)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in candidates),
                    "candidates": candidates,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            previous = current_rows, current
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(candidates) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": metric,
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateGain95": paired_interval(y[target], alternate, control, [r["week"] for r in current_rows]),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "candidateLater": result["candidateLater"],
                    "later": result["later"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
