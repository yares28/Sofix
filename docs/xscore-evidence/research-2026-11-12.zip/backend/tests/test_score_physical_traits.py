from copy import deepcopy

import numpy as np
import pytest

from app.research import score_physical_traits as traits


def person(pid, full, short=None, **values):
    defaults = dict(Height=180, Weight=75)
    return dict(
        ID=str(pid),
        FullName=full,
        Name=short or full,
        **{k: str(values.get(k, defaults.get(k, 60))) for k in traits.FIELDS},
    )


def test_exact_full_names_and_accents_but_no_short_nickname_guess():
    data = [person(1, "Loïc Badé"), person(2, "José García"), person(3, "Alex Silva", "Alex")]
    mapping = traits.identities(["loic-bade", "jose-garcia", "alex"], {}, data)
    assert mapping["loic-bade"]["id"] == 1
    assert mapping["jose-garcia"]["id"] == 2
    assert mapping["alex"]["id"] is None


def test_ambiguous_alias_or_duplicate_identity_remains_unknown():
    data = [person(1, "André Silva"), person(2, "André Silva"), person(3, "John Doe")]
    mapping = traits.identities(["andre-silva", "john-doe", "john-other"], {"john-other": ["John Doe"]}, data)
    assert mapping["andre-silva"]["status"] == "ambiguous"
    assert mapping["john-doe"]["status"] == mapping["john-other"]["status"] == "duplicate_identity"


def test_identical_duplicate_source_rows_are_safe_but_conflicting_id_is_rejected():
    p = person(1, "John Doe")
    assert traits.identities(["john-doe"], {}, [p, dict(p)])["john-doe"]["id"] == 1
    with pytest.raises(ValueError, match="Conflicting duplicate"):
        traits.identities(["john-doe"], {}, [p, dict(p, Strength="90")])


def test_missing_and_invalid_ability_are_not_zero():
    data = [person(1, "John Doe", Strength="", Jumping="0")]
    mapping = traits.identities(["john-doe", "unknown-player"], {}, data)
    assert np.isnan(traits.ability(mapping["john-doe"], data)[traits.FIELDS.index("Strength")])
    assert np.isnan(traits.ability(mapping["john-doe"], data)[traits.FIELDS.index("Jumping")])
    assert np.isnan(traits.ability(mapping["unknown-player"], data)).all()


def fixture():
    games = []
    for i, date in enumerate(["2025-12-10T12:00:00Z", "2025-12-27T12:00:00Z", "2026-01-03T12:00:00Z"]):
        games.append(
            dict(
                id=f"g{i}",
                date=date,
                home=dict(slug="A"),
                away=dict(slug="B"),
                players={
                    "john-doe": dict(team="A", played=True, mins=90, pos="DEF"),
                    "right-wing": dict(team="B", played=True, mins=60, pos="FWD"),
                    "unknown-player": dict(team="B", played=True, mins=30, pos="FWD"),
                    "unused-player": dict(team="B", played=False, mins=0, pos="FWD"),
                },
            )
        )
    rows = [dict(game=g["id"], date=g["date"], player="john-doe", pos="DEF", x=[1]) for g in games]
    data = [person(1, "John Doe", Strength=80), person(2, "Right Wing", Strength=40)]
    mapping = traits.identities(["john-doe", "right-wing", "unknown-player"], {}, data)
    return rows, games, mapping, data, ["home"]


def test_projected_opponent_uses_past_minutes_and_keeps_unknown_exposure():
    x, names, _ = traits.build_features(*fixture())
    assert x.shape == (3, 35)
    assert np.isnan(x[0, names.index("opponent_Strength")])
    assert x[0, names.index("opponent_known_fraction")] == 0
    assert x[-1, names.index("opponent_known_fraction")] == 2 / 3
    assert x[-1, names.index("opponent_Strength")] == 40
    assert x[-1, names.index("gap_Strength")] == 40


def test_future_stats_minutes_xi_and_snapshot_before_publication_are_unavailable():
    args = fixture()
    expected, _, _ = traits.build_features(*args)
    changed = deepcopy(args)
    changed[1][-1]["xi"] = "future actual XI"
    for player in changed[1][-1]["players"].values():
        player.update(mins=99999, pos="MID", stats={"duel_won": [1000, 1000]})
    actual, _, _ = traits.build_features(*changed)
    np.testing.assert_array_equal(actual, expected)
    early = deepcopy(args)
    early[0][0]["date"] = early[1][0]["date"] = "2022-11-01T12:00:00Z"
    x, names, _ = traits.build_features(*early)
    assert x[0, names.index("own_known")] == 0
    assert np.isnan(x[0, :30]).all()
