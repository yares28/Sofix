"""Testing only: corrected activity history keeps Europe and combined histories distinct."""

import numpy as np
import pytest

from app.research import score_europe_routine_history as history
from app.research import score_routine_conditioning as conditioning


def test_routine_groups_cover_all160_columns_without_source_conflation():
    groups = conditioning.feature_groups(history.NAMES)
    assert groups["euro"].sum() == 80
    assert groups["combined"].sum() == 80
    assert groups["all"].sum() == 160
    assert not (groups["euro"] & groups["combined"]).any()
    np.testing.assert_array_equal(groups["euro"] | groups["combined"], groups["all"])
    for name in ("euro", "combined"):
        assert all(
            n.startswith("routine_" + name + "_") for n, yes in zip(history.NAMES, groups[name], strict=True) if yes
        )
    with pytest.raises(ValueError, match="schema"):
        conditioning.feature_groups(list(history.NAMES)[::-1])
