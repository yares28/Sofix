"""Testing only: conditional ordinary-point band probabilities and exact native atoms."""

from __future__ import annotations

import hashlib

import numpy as np

from app.research.score_modal_trees import CENTRES

POSITIONS = ("GK", "DEF", "MID", "FWD")
SETTINGS = {
    f"width{width}_leaves{leaves}": {"width": width, "leaves": leaves, "minimum": minimum}
    for width in (5, 10)
    for leaves, minimum in ((7, 80), (15, 60))
}


def aa_bands(aa, width):
    aa = np.asarray(aa, dtype=float)
    if aa.ndim != 1 or not np.isfinite(aa).all():
        raise ValueError("Known finite ordinary-point labels required")
    if width not in (5, 10):
        raise ValueError("Registered ordinary-point band width required")
    edges = np.arange(-30, 60.01, width)
    return np.searchsorted(edges, aa, side="right"), edges


def conditional_band_mass(aa, levels, positions, labels, position, level, band):
    aa, levels, positions, labels = map(np.asarray, (aa, levels, positions, labels))
    base = (positions == position) & (labels == band)
    if not base.any():
        base = labels == band
    if not base.any():
        raise ValueError("No available native atoms for fitted AA band")
    scores = np.clip(np.maximum(level if level >= 60 else 0, level + aa), 0, 100)
    pooled = (np.abs(scores[base, None] - CENTRES) <= 7).mean(axis=0)
    specific = (positions == position) & (levels == level) & (labels == band)
    n = int(specific.sum())
    if n:
        own = (np.abs(scores[specific, None] - CENTRES) <= 7).mean(axis=0)
        pooled = (n * own + 20 * pooled) / (n + 20)
    return pooled


def design(x, positions, levels):
    return np.column_stack((x, *[(positions == p).astype(float) for p in POSITIONS], np.broadcast_to(levels, len(x))))


def fit_forecasts(x, aa, levels, positions, fit, target, classes, probability, setting, iterations=120):
    from sklearn.ensemble import HistGradientBoostingClassifier

    x, aa, levels, positions, fit, target, classes, probability = map(
        np.asarray, (x, aa, levels, positions, fit, target, classes, probability)
    )
    if (
        x.ndim != 2
        or any(v.shape != (len(x),) for v in (aa, levels, positions, fit, target))
        or np.isinf(x).any()
        or not fit.any()
        or (fit & target).any()
        or not np.isfinite(aa[fit]).all()
        or not np.isfinite(levels[fit]).all()
        or not np.isin(positions, POSITIONS).all()
        or probability.shape != (int(target.sum()), len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Ordinary band fit/probability/case contract differs")
    labels, edges = aa_bands(aa[fit], setting["width"])
    bins = np.unique(labels)
    train = design(x[fit], positions[fit], levels[fit])
    constant = len(bins) == 1
    if not constant:
        model = HistGradientBoostingClassifier(
            loss="log_loss",
            max_leaf_nodes=setting["leaves"],
            min_samples_leaf=setting["minimum"],
            max_iter=iterations,
            learning_rate=0.06,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261103,
        ).fit(train, labels)
        if not np.array_equal(model.classes_, bins):
            raise ValueError("Conditional ordinary-band class support differs")
    mass = np.zeros((int(target.sum()), len(CENTRES)))
    current_positions = positions[target]
    for j, level in enumerate(classes):
        predicted = (
            np.ones((int(target.sum()), 1))
            if constant
            else model.predict_proba(design(x[target], current_positions, level))
        )
        if not np.isfinite(predicted).all() or (predicted < 0).any() or not np.allclose(predicted.sum(axis=1), 1):
            raise ValueError("Conditional ordinary-band probabilities invalid")
        for position in sorted(set(current_positions)):
            at = np.flatnonzero(current_positions == position)
            conditional = np.zeros((len(at), len(CENTRES)))
            for k, band in enumerate(bins):
                atoms = conditional_band_mass(aa[fit], levels[fit], positions[fit], labels, position, level, band)
                conditional += predicted[at, k, None] * atoms
            mass[at] += probability[at, j, None] * conditional
    if not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1 + 1e-12).any():
        raise ValueError("Conditional ordinary-band all-case mass invalid")
    stats = {
        "fitCases": int(fit.sum()),
        "targetCases": int(target.sum()),
        "settings": setting,
        "iterations": iterations,
        "fittedIterations": 0 if constant else int(model.n_iter_),
        "constantBand": constant,
        "bandEdges": edges.tolist(),
        "observedBands": bins.tolist(),
        "bandFitCounts": {str(b): int((labels == b).sum()) for b in bins},
        "numericFeatures": x.shape[1],
        "designFeatures": train.shape[1],
        "eventProbabilitiesUnchanged": True,
        "meanPredictedWinningMass": float(mass.max(axis=1).mean()),
        "fitDesignAndLabelsSha256": hashlib.sha256(train.tobytes() + labels.tobytes() + aa[fit].tobytes()).hexdigest(),
    }
    return mass, stats
