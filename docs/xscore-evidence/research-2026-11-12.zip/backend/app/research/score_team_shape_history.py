"""Testing only: strictly past team shapes, starting-unit turnover and conditional AA history."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_search
from app.research.score_search import cutoff_for, moment

WINDOWS = (3, 10)
TEAM_FIELDS = (
    "observed_games",
    "xi_known_count",
    "shape_known_count",
    "shape_unique_count",
    "shape_mode_fraction",
    "shape_last_fraction",
    "shape_entropy",
    "shape_switch_rate",
    "backline_mean",
    "backline_sd",
    "frontline_mean",
    "frontline_sd",
    "outfield_lines_mean",
    "outfield_lines_sd",
    "xi_unique_players",
    "xi_last_retained_fraction",
    "xi_retained_mean",
    "xi_retained_sd",
    "xi_core_fraction",
)
PLAYER_FIELDS = ("start_fraction", "latest_xi_starter", "usual_unit_overlap", "last_start_days_to_lock")
AA_FIELDS = ("pool_count", "known_shape_weight", "mean", "sd", "mode", "window_mass", "effective_n")
NAMES = tuple(
    [f"shape_{side}_{n}_{field}" for side in ("own", "opponent") for n in WINDOWS for field in TEAM_FIELDS]
    + [f"shape_player_{n}_{field}" for n in WINDOWS for field in PLAYER_FIELDS]
    + [f"shape_{side}_{field}_days_to_lock" for side in ("own", "opponent") for field in ("last_xi", "last_shape")]
    + [f"shape_aa_{n}_{field}" for n in WINDOWS for field in AA_FIELDS]
)


def team_records(game):
    if not any(p.get("played") is True for p in game.get("players", {}).values()):
        return []
    output = []
    for side, other in (("home", "away"), ("away", "home")):
        club = (game.get(side) or {}).get("slug")
        opponent = (game.get(other) or {}).get("slug")
        if not club or not opponent or club == opponent:
            raise ValueError("Verified native team sides required")
        starters = {
            p
            for p, r in game["players"].items()
            if r.get("team") == club and r.get("played") is True and r.get("started") is True
        }
        known_xi = len(starters) == 11
        native = (game.get("xi") or {}).get(side) or {}
        lines = native.get("start") or []
        flat = [p for line in lines for p in line]
        known_shape = (
            known_xi
            and native.get("available") is True
            and len(flat) == 11
            and len(set(flat)) == 11
            and set(flat) == starters
            and len(lines) >= 2
            and len(lines[0]) == 1
            and game["players"][lines[0][0]].get("pos") == "GK"
            and all(len(line) > 0 for line in lines)
        )
        shape = tuple(len(line) for line in lines[1:]) if known_shape else None
        labels = []
        for player, r in game["players"].items():
            value = r.get("aa")
            if (
                r.get("team") == club
                and r.get("played") is True
                and r.get("ver") == 7
                and type(r.get("started")) is bool
                and r.get("pos") in ("GK", "DEF", "MID", "FWD")
                and type(value) in (float, int)
                and math.isfinite(value)
                and type(r.get("score")) in (int, float)
                and math.isfinite(r["score"])
                and 0 <= r["score"] <= 100
            ):
                labels.append(
                    dict(
                        player=player,
                        pos=r["pos"],
                        cohort="start" if r["started"] else "bench",
                        aa=float(value),
                        shape=shape,
                    )
                )
        output.append(
            dict(
                game=game["id"],
                date=game["date"],
                club=club,
                opponent=opponent,
                xi=sorted(starters) if known_xi else None,
                shape=shape,
                labels=labels,
            )
        )
    return output


def team_summary(history):
    shapes = [tuple(h["shape"]) for h in history if h["shape"] is not None]
    xis = [set(h["xi"]) for h in history if h["xi"] is not None]
    frequencies = Counter(shapes)
    p = np.array(list(frequencies.values()), dtype=float) / len(shapes) if shapes else np.array([])
    switches = [
        tuple(a["shape"]) != tuple(b["shape"])
        for a, b in zip(history, history[1:], strict=False)
        if a["shape"] is not None and b["shape"] is not None
    ]
    retention = [
        len(set(a["xi"]) & set(b["xi"])) / 11
        for a, b in zip(history, history[1:], strict=False)
        if a["xi"] is not None and b["xi"] is not None
    ]
    last_retention = (
        len(set(history[-2]["xi"]) & set(history[-1]["xi"])) / 11
        if len(history) >= 2 and history[-2]["xi"] is not None and history[-1]["xi"] is not None
        else np.nan
    )
    output = dict(
        observed_games=len(history),
        xi_known_count=len(xis),
        shape_known_count=len(shapes),
        shape_unique_count=len(frequencies),
        shape_mode_fraction=max(frequencies.values()) / len(shapes) if shapes else np.nan,
        shape_last_fraction=frequencies[shapes[-1]] / len(shapes) if shapes else np.nan,
        shape_entropy=float(-np.sum(p * np.log(p))) if shapes else np.nan,
        shape_switch_rate=float(np.mean(switches)) if switches else np.nan,
        xi_unique_players=len(set.union(*xis)) if xis else np.nan,
        xi_last_retained_fraction=last_retention,
        xi_retained_mean=float(np.mean(retention)) if retention else np.nan,
        xi_retained_sd=float(np.std(retention)) if retention else np.nan,
        xi_core_fraction=sum(len(s & xis[-1]) for s in xis) / (11 * len(xis)) if xis else np.nan,
    )
    for field, values in (
        ("backline", [s[0] for s in shapes]),
        ("frontline", [s[-1] for s in shapes]),
        ("outfield_lines", [len(s) for s in shapes]),
    ):
        output[field + "_mean"] = float(np.mean(values)) if values else np.nan
        output[field + "_sd"] = float(np.std(values)) if values else np.nan
    return output


def weighted_mode(values, weights):
    values, weights = np.asarray(values, dtype=float), np.asarray(weights, dtype=float)
    if (
        values.ndim != 1
        or not len(values)
        or values.shape != weights.shape
        or not np.isfinite([values, weights]).all()
        or (weights < 0).any()
        or not np.isclose(weights.sum(), 1)
    ):
        raise ValueError("Known native AA atoms and normalized nonnegative weights required")
    centres = np.unique(np.r_[values, values - 7, values + 7])
    mass = ((np.abs(values[:, None] - centres) <= 7) * weights[:, None]).sum(axis=0)
    winners = centres[np.abs(mass - mass.max()) <= 1e-12]
    order = np.argsort(values, kind="stable")
    median = values[order[np.flatnonzero(np.cumsum(weights[order]) >= 0.5 - 1e-12)[0]]]
    mode = float(winners[np.argmin(np.abs(winners - median))])
    return mode, float(mass.max())


def aa_summary(pool, history):
    if not pool:
        return dict(pool_count=0, **{f: np.nan for f in AA_FIELDS if f != "pool_count"})
    values = np.array([r["aa"] for r in pool])
    shapes = Counter(tuple(r["shape"]) for r in history if r["shape"] is not None)
    weights = np.zeros(len(pool))
    supported = 0.0
    for shape, count in shapes.items():
        matches = np.array([r["shape"] is not None and tuple(r["shape"]) == shape for r in pool])
        n, probability = int(matches.sum()), count / sum(shapes.values())
        weights += probability * (3 / (n + 3) / len(pool) + matches.astype(float) / (n + 3))
        supported += probability * (n > 0)
    if not shapes:
        weights[:] = 1 / len(pool)
    weights /= weights.sum()
    mean = float(weights @ values)
    mode, mass = weighted_mode(values, weights)
    return dict(
        pool_count=len(pool),
        known_shape_weight=supported if shapes else np.nan,
        mean=mean,
        sd=float(np.sqrt(weights @ ((values - mean) ** 2))),
        mode=mode,
        window_mass=mass,
        effective_n=float(1 / (weights @ weights)),
    )


def build_features(rows, games):
    by_game = {g["id"]: g for g in games}
    if len(by_game) != len(games):
        raise ValueError("Duplicate team-shape fixture")
    queue = sorted([r for g in games for r in team_records(g)], key=lambda r: (moment(r["date"]), r["game"], r["club"]))
    histories, people = defaultdict(list), defaultdict(list)
    index = 0
    output = np.full((len(rows), len(NAMES)), np.nan)
    locks = [cutoff_for(r["date"]) for r in rows]
    for i in sorted(range(len(rows)), key=lambda j: locks[j]):
        row, lock = rows[i], locks[i]
        while index < len(queue) and moment(queue[index]["date"]) + timedelta(hours=48) < lock:
            record = queue[index]
            histories[record["club"]].append(record)
            for label in record["labels"]:
                people[label["player"], record["club"], label["pos"], label["cohort"]].append(
                    {**label, "date": record["date"]}
                )
            index += 1
        g = by_game.get(row["game"])
        person = (g or {}).get("players", {}).get(row["player"])
        if g is None or person is None or g["date"] != row["date"]:
            raise ValueError("Canonical team-shape target identity/date missing")
        club = person.get("team")
        if club not in (g["home"]["slug"], g["away"]["slug"]):
            raise ValueError("Canonical team-shape actual playing side missing")
        opponent = g["away"]["slug"] if club == g["home"]["slug"] else g["home"]["slug"]
        own = [r for r in histories[club] if moment(r["date"]) >= lock - timedelta(days=365)]
        other = [r for r in histories[opponent] if moment(r["date"]) >= lock - timedelta(days=365)]
        pool = [
            r
            for r in people[row["player"], club, row["pos"], row["cohort"]]
            if moment(r["date"]) >= lock - timedelta(days=365)
        ][-20:]
        features = {}
        for side, history in (("own", own), ("opponent", other)):
            for n in WINDOWS:
                features.update(
                    {f"shape_{side}_{n}_{field}": value for field, value in team_summary(history[-n:]).items()}
                )
            for field, wanted in (("last_xi", "xi"), ("last_shape", "shape")):
                known = [r for r in history if r[wanted] is not None]
                features[f"shape_{side}_{field}_days_to_lock"] = (
                    (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan
                )
        all_starts = [r for r in own if r["xi"] is not None and row["player"] in r["xi"]]
        for n in WINDOWS:
            recent = own[-n:]
            known = [r for r in recent if r["xi"] is not None]
            starts = [r for r in known if row["player"] in r["xi"]]
            latest = set(known[-1]["xi"]) - {row["player"]} if known else set()
            individual = dict(
                start_fraction=len(starts) / len(known) if known else np.nan,
                latest_xi_starter=float(row["player"] in recent[-1]["xi"])
                if recent and recent[-1]["xi"] is not None
                else np.nan,
                usual_unit_overlap=float(np.mean([len((set(r["xi"]) - {row["player"]}) & latest) / 10 for r in starts]))
                if starts
                else np.nan,
                last_start_days_to_lock=(lock - moment(all_starts[-1]["date"])).total_seconds() / 86400
                if all_starts
                else np.nan,
            )
            features.update({f"shape_player_{n}_{field}": value for field, value in individual.items()})
            features.update({f"shape_aa_{n}_{field}": value for field, value in aa_summary(pool, recent).items()})
        output[i] = [features[n] for n in NAMES]
    if np.isinf(output).any():
        raise ValueError("Nonfinite team-shape feature")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    games, digest = [], hashlib.sha256()
    for line in args.games.open("rb"):
        digest.update(line)
        if line.strip():
            g = json.loads(line)
            slim = {k: g[k] for k in ("id", "date", "home", "away", "xi")}
            slim["players"] = {
                p: {k: r.get(k) for k in ("team", "pos", "played", "started", "ver", "aa", "score")}
                for p, r in g["players"].items()
            }
            games.append(slim)
    plan_path = args.report.with_suffix(".plan.json")
    plan = json.loads(plan_path.read_text())
    if digest.hexdigest() not in plan["sources"]:
        raise ValueError("Registered team-shape source hash differs")
    key = hashlib.sha256(
        (source["key"] + digest.hexdigest()).encode()
        + Path(__file__).read_bytes()
        + Path(score_search.__file__).read_bytes()
        + plan_path.read_bytes()
    ).hexdigest()
    print(f"TEAM_SHAPE_BUILD cases{len(source['rows'])} features{len(NAMES)}", flush=True)
    x = build_features(source["rows"], games)
    records = [r for g in games for r in team_records(g)]
    np.savez_compressed(args.out, key=key, names=NAMES, x=x)
    corpus = dict(key=key, sourceSha256=digest.hexdigest(), records=records)
    args.out.with_suffix(".observations.json.gz").write_bytes(
        gzip.compress(json.dumps(corpus, allow_nan=False).encode())
    )
    output = dict(
        scope="Testing-only source/feature stage, no prediction accuracy claim",
        sourceKey=source["key"],
        featureKey=key,
        sourceSha256=digest.hexdigest(),
        cases=len(x),
        features=len(NAMES),
        nativeTeamSides=len(records),
        knownXISides=sum(r["xi"] is not None for r in records),
        knownShapeSides=sum(r["shape"] is not None for r in records),
        nativeAALabels=sum(len(r["labels"]) for r in records),
        limitations=plan["limitations"],
    )
    args.report.write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
