import copy

import numpy as np
import pytest

from app.research.score_europe_ordinary import (
    NAMES,
    build_features,
    game_records,
    observed_cohort,
    ordinary_bounds,
    summarise,
)
from app.research.score_search import cutoff_for


def observation(date="2024-01-09T20:00:00Z", score=35, level=35, minutes=90, cohort="start"):
    return {
        "game": date,
        "date": date,
        "player": "p",
        "pos": "DEF",
        "cohort": cohort,
        "score": score,
        "level": level,
        "minutes": minutes,
        "ordinary": ordinary_bounds(score, level),
    }


def test_ordinary_bounds_keep_censored_points_unknown_and_100level_unbounded():
    assert ordinary_bounds(35, 35) == {"point": 0, "lower": 0, "upper": 0, "kind": "exact"}
    assert ordinary_bounds(60, 60) == {"point": None, "lower": None, "upper": 0, "kind": "upper"}
    assert ordinary_bounds(0, 35)["upper"] == -35
    assert ordinary_bounds(100, 60) == {"point": None, "lower": 40, "upper": None, "kind": "lower"}
    assert ordinary_bounds(100, 100) == {"point": None, "lower": None, "upper": None, "kind": "unbounded"}
    with pytest.raises(ValueError, match="floor"):
        ordinary_bounds(59, 60)


def test_native_numeric_start_one_and_unknown_null_are_not_boolean_guesses():
    assert observed_cohort("p", {"gameStarted": 1}, {}) == "start"
    assert observed_cohort("p", {"gameStarted": None}, {}) is None
    formation = {
        "startingLineupAvailable": True,
        "startingLineup": [[{"slug": f"x{i}"} for i in range(11)]],
        "bench": [{"slug": "p"}],
    }
    assert observed_cohort("p", {"gameStarted": None}, formation) == "bench"
    with pytest.raises(ValueError, match="disagrees"):
        observed_cohort("p", {"gameStarted": 1}, formation)


def test_native_source_rejects_wrong_version_and_side_without_fabricating_zero():
    from collections import Counter

    g = {
        "id": "g",
        "date": "2024-01-01T20:00:00Z",
        "statusTyped": "played",
        "homeTeam": {"slug": "h"},
        "awayTeam": {"slug": "a"},
        "playerGameScores": [
            {
                "score": 40,
                "scoreStatus": "FINAL",
                "scoringVersion": 7,
                "positionTyped": "Defender",
                "anyPlayer": {"slug": "p"},
                "decisiveScore": {"totalScore": 35},
                "anyPlayerGameStats": {
                    "playedInGame": True,
                    "gameStarted": 1,
                    "minsPlayed": 90,
                    "anyTeam": {"slug": "h"},
                },
            }
        ],
    }
    receipt = Counter()
    result = game_records(g, receipt)
    assert len(result) == 1 and result[0]["ordinary"]["point"] == 5
    g["playerGameScores"][0]["scoringVersion"] = 6
    assert game_records(g, receipt) == [] and receipt["notFinalV7Played"] == 1
    g["playerGameScores"][0]["scoringVersion"] = 7
    g["playerGameScores"][0]["anyPlayerGameStats"]["anyTeam"]["slug"] = "wrong"
    assert game_records(g, receipt) == [] and receipt["unknownIdentityPositionSideOrMinutes"] == 1


def test_exact48hour_and_future_labels_are_excluded_but_zero_and_120minutes_retained():
    rows = [{"date": "2024-01-12T20:00:00Z", "player": "p", "pos": "DEF", "cohort": "start"}]
    observations = [
        observation("2024-01-10T13:59:59Z", score=35, minutes=120),
        observation("2024-01-10T14:00:00Z", score=80, level=60),
        observation("2024-01-12T20:00:00Z", score=100, level=60),
    ]
    before = build_features(rows, observations)
    assert before.shape == (1, 60)
    assert before[0, NAMES.index("euro_same_position_15_retained_games")] == 1
    assert before[0, NAMES.index("euro_same_position_15_aa90_mean")] == 0
    changed = copy.deepcopy(observations)
    for item in changed[1:]:
        item.update(
            score=np.nan, level=100, minutes=np.nan, cohort="bench", ordinary={"point": np.nan, "kind": "exact"}
        )
    rows[0].update(score=999999, aa=np.nan, minutes=-999, level=100)
    np.testing.assert_equal(before, build_features(rows, changed))
    summary = summarise([observation(score=55, minutes=120)], 15, cutoff_for(rows[0]["date"]))
    assert summary[10] == 15  # Twenty native ordinary points in120published minutes.


def test_empty_history_differs_from_known_zero_score_and_censored_ordinary_points():
    row = {"date": "2024-01-12T20:00:00Z", "player": "p", "pos": "DEF", "cohort": "bench"}
    empty = build_features([row], [])
    known = build_features([row], [observation(score=0, cohort=None)])
    count = NAMES.index("euro_same_position_15_retained_games")
    mean = NAMES.index("euro_same_position_15_score_mean")
    exact = NAMES.index("euro_same_position_15_aa_exact_games")
    assert empty[0, count] == 0 and np.isnan(empty[0, mean])
    assert known[0, count] == 1 and known[0, mean] == 0 and known[0, exact] == 0
    assert known[0, NAMES.index("euro_same_position_15_aa_upper_rate")] == 1
    assert known[0, NAMES.index("euro_same_cohort_15_retained_games")] == 0


def test_history_position_and365day_window_do_not_change_target_coverage():
    row = {"date": "2025-01-17T20:00:00Z", "player": "p", "pos": "MID", "cohort": "start"}
    records = [observation("2023-01-01T20:00:00Z"), observation("2025-01-10T20:00:00Z")]
    values = build_features([row, {**row, "pos": "DEF"}], records)
    assert values.shape == (2, 60)
    assert values[0, NAMES.index("euro_same_position_15_retained_games")] == 0
    assert values[1, NAMES.index("euro_same_position_15_retained_games")] == 1
