"""Testing-only official announcement clocks and literal linked-document catalogue."""

from __future__ import annotations

import hashlib
import html
import json
import re
from pathlib import Path
from urllib.parse import urljoin, urlparse
from zoneinfo import ZoneInfo

from app.research.score_referee_source import publication


def article(text, catalogue_date):
    published = publication(text)
    if published.astimezone(ZoneInfo("Europe/Madrid")).date().isoformat() != catalogue_date:
        raise ValueError("Article publication differs from catalogue date")
    urls = set()
    for match in re.findall(r'href="([^"]*\.pdf[^\"]*)"', text, re.I):
        url = urljoin("https://rfef.es/", html.unescape(match))
        parsed = urlparse(url)
        if (
            parsed.scheme != "https"
            or parsed.hostname not in ["rfef.es", "www.rfef.es"]
            or not parsed.path.startswith("/sites/default/files/")
        ):
            raise ValueError("Unexpected linked document host/path")
        urls.add(url)
    return dict(
        publicationUTC=published.isoformat(), pdfURLs=sorted(urls), status="linked_pdf" if urls else "no_linked_pdf"
    )


def main():
    folder = Path("data/raw/score-foundation/referee-source")
    reports = Path("reports/experiments")
    manifest = folder / "archive_article_manifest.json"
    raw = manifest.read_bytes()
    entries = json.loads(raw.decode("utf-8-sig"))
    expected = json.loads((folder / "archive_article_requests.json").read_text())
    if len(entries) != len(expected) or {e["Url"] for e in entries} != {e["Url"] for e in expected}:
        raise ValueError("Official announcement collection still incomplete; do not restart live reader")
    index = json.loads((reports / "laliga_score_referee_index.integrity.json").read_text())
    if index["sourceArticleRequests"] != len(expected) or index["independentlyParsedCards"] != 374:
        raise ValueError("Completed independent index audit required")
    rows, requests = [], {}
    for entry in entries:
        if entry["Status"] != "downloaded":
            rows.append(entry | dict(status="unreadable_article", pdfURLs=[]))
            continue
        page = (folder / entry["File"]).read_bytes()
        sha = hashlib.sha256(page).hexdigest()
        if sha != entry["SHA256"].lower():
            raise ValueError("Official article bytes changed")
        parsed = article(page.decode("utf-8"), entry["CatalogueDate"])
        rows.append(
            dict(file=entry["File"], url=entry["Url"], sha256=sha, catalogueDate=entry["CatalogueDate"], **parsed)
        )
        for url in parsed["pdfURLs"]:
            if url not in requests:
                requests[url] = dict(
                    File="archive_document_" + hashlib.sha256(url.encode()).hexdigest()[:16] + ".pdf",
                    Url=url,
                    Parents=[],
                )
            requests[url]["Parents"].append(
                dict(File=entry["File"], SHA256=sha, PublicationUTC=parsed["publicationUTC"], URL=entry["Url"])
            )
    pilot = {
        e["Url"]: e
        for e in json.loads((folder / "pilot_pdf_manifest.json").read_text(encoding="utf-8-sig"))
        if e["Status"] == "downloaded"
    }
    reused, pending = [], []
    for url, record in sorted(requests.items()):
        if url in pilot:
            p = pilot[url]
            reused.append(
                record
                | dict(
                    File=p["File"],
                    SHA256=p["SHA256"],
                    LastModified=p["LastModified"],
                    ContentType=p["ContentType"],
                    Status="downloaded",
                    Reused=True,
                )
            )
        else:
            pending.append(record)
    (folder / "archive_pdf_requests.json").write_text(json.dumps(list(requests.values()), indent=2) + "\n")
    (folder / "archive_pdf_requests_pending.json").write_text(json.dumps(pending, indent=2) + "\n")
    destination = folder / "archive_pdf_manifest.json"
    if destination.exists():
        raise ValueError("PDF collection manifest already exists; do not overwrite progress")
    destination.write_text(json.dumps(reused, indent=2) + "\n")
    report = dict(
        scope="Literal official source document request catalogue; no forecast fit",
        implementationKey=hashlib.sha256(
            Path(__file__).read_bytes() + raw + index["implementationKey"].encode()
        ).hexdigest(),
        articleManifestSHA=hashlib.sha256(raw).hexdigest(),
        indexKey=index["implementationKey"],
        articles=len(rows),
        linkedArticles=sum(r["status"] == "linked_pdf" for r in rows),
        documents=len(requests),
        reusedDocuments=len(reused),
        pendingDocuments=len(pending),
        records=rows,
        limitation="Each actual document version and fixture timing still must be verified. Source publication dates reconstruct availability, not original independent captured receipts.",
    )
    (reports / "laliga_score_referee_articles.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        "REFEREE_ARTICLE_CATALOGUE",
        json.dumps(
            {k: report[k] for k in ["articles", "linkedArticles", "documents", "reusedDocuments", "pendingDocuments"]}
        ),
    )


if __name__ == "__main__":
    main()
