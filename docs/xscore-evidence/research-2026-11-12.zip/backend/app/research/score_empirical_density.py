"""Testing only: joint score windows from earlier out-of-fit asymmetric AA errors."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def calibration_split(rows):
    select = np.array([r["date"] >= "2025-11-01" for r in rows])
    first_lock = min(cutoff_for(r["date"]) for r, yes in zip(rows, select, strict=True) if yes)
    fit = np.array([moment(r["date"]) + timedelta(hours=48) < first_lock for r in rows])
    return fit, select


def location_scale(parts, mode):
    q = np.sort(np.stack([parts[v] for v in (0.35, 0.5, 0.65)]), axis=0)
    scale = np.clip((q[2] - q[0]) / 0.7706409328151355, 2, 40) if mode == "scaled" else np.ones_like(q[1])
    return q[1], scale


def fit_bank(classes, parts, aa, levels, positions, fit, mode):
    if not np.isfinite(aa[fit]).all():
        raise ValueError("Unknown calibration points cannot become zero")
    location, scale = location_scale(parts, mode)
    known = np.isin(levels, classes)
    selected = np.flatnonzero(fit & known)
    if not len(selected):
        raise ValueError("No earlier calibration residuals")
    indices = np.searchsorted(classes, levels[selected])
    residual = (aa[selected] - location[selected, indices]) / scale[selected, indices]
    pos, lev = positions[selected], levels[selected]
    return {
        "mode": mode,
        "global": np.sort(residual),
        "positions": {p: np.sort(residual[pos == p]) for p in set(pos)},
        "levels": {
            (p, float(v)): np.sort(residual[(pos == p) & (lev == v)]) for p, v in set(zip(pos, lev, strict=True))
        },
        "cases": len(selected),
        "unknownLevels": int((fit & ~known).sum()),
    }


def window_mass(samples, low, high, lower_clipped, upper_clipped, below_floor):
    lower = np.searchsorted(samples, low, side="left") / len(samples)
    upper = np.searchsorted(samples, high, side="right") / len(samples)
    lower = np.where(lower_clipped, 0, lower)
    upper = np.where(upper_clipped, 1, upper)
    return np.where(below_floor, 0, np.maximum(0, upper - lower))


def empirical_predictions(classes, probability, parts, positions, bank, prior, multiplier, shift):
    if not np.isfinite(probability).all() or (probability < 0).any() or not np.allclose(probability.sum(axis=1), 1):
        raise ValueError("Invalid probability")
    location, scale = location_scale(parts, bank["mode"])
    scale *= multiplier
    location += shift
    centres = np.arange(0, 100.01, 0.5)
    mass = np.zeros((len(probability), len(centres)))
    for pos in set(positions):
        selected = np.flatnonzero(positions == pos)
        pooled = bank["positions"].get(pos, bank["global"])
        for j, level in enumerate(classes):
            floor = level if level >= 60 else 0
            low, high = centres[None, :] - 7, centres[None, :] + 7
            lo = (low - level - location[selected, j, None]) / scale[selected, j, None]
            hi = (high - level - location[selected, j, None]) / scale[selected, j, None]
            clipping = low <= floor, high >= 100, high < floor
            base = window_mass(pooled, lo, hi, *clipping)
            conditional = bank["levels"].get((pos, float(level)))
            if conditional is not None and len(conditional):
                group = window_mass(conditional, lo, hi, *clipping)
                base = (len(conditional) * group + prior * base) / (len(conditional) + prior)
            mass[selected] += probability[selected, j, None] * base
    return window_centres(mass, centres)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "component-report", "control", "selector", "cache", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--group", required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    component_report = json.loads(args.component_report.read_text(encoding="utf-8"))
    selector = json.loads(args.selector.read_text(encoding="utf-8"))
    if component_report["sourceKey"] != source["key"] or selector["sourceKey"] != source["key"]:
        raise ValueError("Source cases differ")
    key = hashlib.sha256(
        (source["key"] + component_report["implementationKey"]).encode() + Path(__file__).read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "implementationKey": key,
        "componentGroup": args.group,
        "componentReport": str(args.component_report),
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"] for r in rows])
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        y, aa, levels = (np.array([r[n] for r in rows]) for n in ("score", "aa", "level"))
        positions = np.array([r["pos"] for r in rows])
        fit, select = calibration_split([r for r, yes in zip(rows, valid, strict=True) if yes])
        prefix = f"feature_{args.component_report.stem}_{cohort}_{args.group}"
        classes, probability, parts = components(
            args.cache / (prefix + "_selection.npz"), component_report["implementationKey"]
        )
        with np.load(args.cache / f"selector_{cohort}_control_earlier.npz") as stored:
            if str(stored["key"]) != selector["implementationKey"]:
                raise ValueError("Control cache differs")
            control_earlier = stored["prediction"]
        candidates = [{"kind": "control", "selection": measure(y[valid][select], control_earlier[select])}]
        banks = {
            mode: fit_bank(classes, parts, aa[valid], levels[valid], positions[valid], fit, mode)
            for mode in ("raw", "scaled")
        }
        for mode, bank in banks.items():
            for prior in (20, 100):
                for multiplier in (0.75, 1, 1.25):
                    for shift in (-3, 0, 3):
                        subset = {q: v[select] for q, v in parts.items()}
                        pred = empirical_predictions(
                            classes,
                            probability[select],
                            subset,
                            positions[valid][select],
                            bank,
                            prior,
                            multiplier,
                            shift,
                        )
                        candidates.append(
                            {
                                "kind": "empirical",
                                "mode": mode,
                                "prior": prior,
                                "multiplier": multiplier,
                                "shift": shift,
                                "selection": measure(y[valid][select], pred),
                            }
                        )
        winner = max(candidates, key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Later cases differ")
            baseline = stored["control"]
        empirical_spec = max(candidates[1:], key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
        bank = fit_bank(
            classes,
            parts,
            aa[valid],
            levels[valid],
            positions[valid],
            np.ones(int(valid.sum()), dtype=bool),
            empirical_spec["mode"],
        )
        classes, probability, parts = components(
            args.cache / (prefix + "_later.npz"), component_report["implementationKey"]
        )
        alternate = empirical_predictions(
            classes,
            probability,
            parts,
            positions[test],
            bank,
            empirical_spec["prior"],
            empirical_spec["multiplier"],
            empirical_spec["shift"],
        )
        prediction = baseline.copy() if winner["kind"] == "control" else alternate
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {
            "winner": winner,
            "empiricalSpec": empirical_spec,
            "candidateCount": len(candidates),
            "calibrationCases": bank["cases"],
            "calibrationUnknownLevels": bank["unknownLevels"],
            "later": measure(y[test], prediction),
            "empiricalLater": measure(y[test], alternate),
            "control": measure(y[test], baseline),
            "gain95": paired_interval(y[test], alternate, baseline, weeks),
            "weekly95": bootstrap(y[test], alternate, weeks),
            "positions": {
                p: measure(y[test][positions[test] == p], alternate[positions[test] == p])
                for p in POSITIONS
                if (positions[test] == p).any()
            },
            "highScoreGames": measure(y[test][y[test] >= 60], alternate[y[test] >= 60]),
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[test],
            prediction=prediction,
            alternate=alternate,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
