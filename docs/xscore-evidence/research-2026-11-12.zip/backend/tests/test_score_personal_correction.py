import numpy as np
import pytest

from app.research.score_personal_correction import online_corrections


def row(date, score):
    return {"player": "p", "pos": "MID", "date": date, "score": score, "home": True}


def test_current_or_unavailable_result_cannot_change_a_correction():
    rows = [row("2025-10-01T20:00:00Z", 40), row("2025-10-11T20:00:00Z", 90), row("2025-10-12T20:00:00Z", 60)]
    spec = {"group": "player", "priorStrength": 5, "halfLifeDays": 90}
    before = online_corrections(rows, np.array([30.0, 40.0, 40.0]), spec)
    rows[1]["score"], rows[2]["score"] = 0, 100
    after = online_corrections(rows, np.array([30.0, 40.0, 40.0]), spec)
    for cap in (5, 15, 30):
        assert before[cap][-1] == after[cap][-1]
        assert before[cap][-1] > 40


def test_cold_start_keeps_original_forecast_and_zero_is_observed():
    rows = [row("2025-10-01T20:00:00Z", 0), row("2025-10-12T20:00:00Z", 40)]
    predictions = online_corrections(
        rows, np.array([20.0, 20.0]), {"group": "player", "priorStrength": 5, "halfLifeDays": 90}
    )
    assert predictions[30][0] == 20
    assert predictions[30][-1] <= 7


def test_unknown_actual_is_not_silently_treated_as_zero():
    with pytest.raises(ValueError, match="known"):
        online_corrections(
            [row("2025-10-01T20:00:00Z", np.nan)],
            np.array([40.0]),
            {"group": "player", "priorStrength": 5, "halfLifeDays": 90},
        )
