from datetime import UTC, datetime

import numpy as np

from app.research.score_goal_context_rebuild import design, poisson_fit
from app.research.score_goal_timing_context import fit_history, goal_bands, profiles, state_probability
from app.research.score_joint_goal_flow import joint_parts, marginal, three_way


def test_goal_bands_are_split_by_benefiting_side_and_boundary():
    events = [(29, "home"), (30, "away"), (59, "away"), (60, "home"), (92, "away")]
    np.testing.assert_array_equal(goal_bands(events), [[1, 0, 1], [0, 2, 1]])


def test_timing_profiles_cannot_use_games_exactly_at_availability_boundary():
    games = [
        ("2025-01-02T14:00:00Z", ("a", "b"), np.array([[1, 2, 0], [0, 0, 2]])),
        ("2025-01-03T14:00:00Z", ("a", "b"), np.array([[0, 0, 100], [100, 0, 0]])),
    ]
    bank = fit_history(games, datetime(2025, 1, 5, 14, tzinfo=UTC))
    assert bank[-1] == 1
    reference, candidate = profiles(("a", "b"), bank)
    np.testing.assert_allclose(reference.sum(axis=1), 1)
    np.testing.assert_allclose(candidate.sum(axis=1), 1)
    np.testing.assert_allclose(profiles(("unknown", "unknown"), bank)[1], reference, rtol=0, atol=1e-15)


def test_state_probability_reverses_and_zero_rates_are_a_draw():
    np.testing.assert_allclose(state_probability(1.2, 0.4), state_probability(0.4, 1.2)[::-1])
    np.testing.assert_array_equal(state_probability(0, 0), [0, 1, 0])


def test_goal_rate_design_uses_only_fit_rows_for_missing_values():
    fit = np.array([True, True, False])
    base = np.zeros((3, 1))
    first = design(base, np.array([[1], [3], [100]]), fit)
    second = design(base, np.array([[1], [3], [np.nan]]), fit)
    np.testing.assert_array_equal(first[fit], second[fit])
    predicted = poisson_fit(np.empty((3, 0)), np.array([1, 2, 3]), np.zeros(3), np.empty((1, 0)), np.zeros(1))
    np.testing.assert_allclose(predicted, [2])


def test_dependent_goals_preserve_marginals_and_reverse_result():
    base, delta = joint_parts(1.6, 0.7)
    for weight in (-0.8, 0.8):
        joint = base + weight * delta
        assert (joint >= 0).all()
        np.testing.assert_allclose(joint.sum(axis=1), marginal(1.6), atol=1e-15)
        np.testing.assert_allclose(joint.sum(axis=0), marginal(0.7), atol=1e-15)
        np.testing.assert_allclose(three_way(joint), three_way(joint.T)[::-1], atol=1e-15)
