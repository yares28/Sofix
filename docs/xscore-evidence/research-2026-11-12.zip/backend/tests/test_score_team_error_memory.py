"""Error memory must contain only completed, available games."""

import numpy as np

from app.research import score_team_error_memory as memory


def row(game, player, date, aa=10):
    return dict(game=game, player=player, date=date, cohort="start", pos="DEF", aa=aa, level=35)


def test_group_records_use_one_team_side_and_past_observed_class_only():
    rows = [row("g", "p", "2024-01-01T12:00:00Z", 11), row("g", "q", "2024-01-01T12:00:00Z", 15)]
    sides = {("g", "p"): ("a", "b"), ("g", "q"): ("a", "b")}
    records, receipt = memory.records_from(rows, sides, np.array([35, 60]), np.array([[5.0, 999.0], [7.0, 999.0]]))
    assert len(records) == 1 and records[0]["residual"] == 7
    assert records[0]["members"] == 2 and receipt["unsupportedPastLevels"] == 0


def test_boundary_and_opponent_and_missing_vs_zero():
    records = [
        dict(game="old", available=10.0, club="a", opponent="b", pos="DEF", cohort="start", residual=0.0, members=2),
        dict(game="edge", available=20.0, club="a", opponent="b", pos="DEF", cohort="start", residual=100.0, members=2),
    ]
    signals = memory.signal_for(records, "a", "b", "DEF", "start", 20.0)
    assert signals["own3Count"] == signals["opponent3Count"] == 1
    assert signals["own3"] == signals["opponent3"] == 0
    missing = memory.signal_for(records, "c", "d", "DEF", "start", 20.0)
    assert missing["own3Count"] == 0 and missing["own3"] == 0
    records[1]["residual"] = -999
    assert memory.signal_for(records, "a", "b", "DEF", "start", 20.0) == signals


def test_unknown_observed_class_is_not_zero_residual():
    rows = [row("g", "p", "2024-01-01T12:00:00Z")]
    rows[0]["level"] = 15
    records, receipt = memory.records_from(rows, {("g", "p"): ("a", "b")}, np.array([35, 60]), np.array([[2.0, 8.0]]))
    assert records == [] and receipt["unsupportedPastLevels"] == 1


def test_correction_preserves_forecast_population_and_bounds_shift():
    parts = {
        0.35: np.array([[1.0, 2.0], [3.0, 4.0]]),
        0.5: np.array([[2.0, 3.0], [4.0, 5.0]]),
        0.65: np.array([[3.0, 4.0], [5.0, 6.0]]),
    }
    shifted = memory.shift_parts(parts, np.array([100.0, -5.0]), np.array([True, False]), 1)
    np.testing.assert_array_equal(shifted[0.5], [[14.0, 15.0], [4.0, 5.0]])
    np.testing.assert_array_equal(parts[0.5], [[2.0, 3.0], [4.0, 5.0]])


def test_indexed_memory_matches_direct_and_future_labels_cannot_change_earlier_inputs():
    records = [
        dict(
            game=str(i),
            available=float(i),
            club="a" if i % 2 else "c",
            opponent="b",
            pos="DEF",
            cohort="start",
            residual=float(i),
            members=1,
        )
        for i in range(30)
    ]
    before = memory.Memory(records).query("a", "b", "DEF", "start", 15.0)
    assert before == memory.signal_for(records, "a", "b", "DEF", "start", 15.0)
    for record in records:
        if record["available"] >= 15:
            record["residual"] = 999999
    assert memory.Memory(records).query("a", "b", "DEF", "start", 15.0) == before


def test_independent_native_sample_prediction_picks_one_mode_and_respects_floor():
    from app.research.score_team_error_memory_audit import independent_predict

    bank = {"global": np.array([0.0]), "positions": {"DEF": np.array([0.0])}, "levels": {}}
    pred = independent_predict(
        np.array([35.0, 60.0]),
        np.array([[0.6, 0.4], [0.4, 0.6]]),
        np.array([[5.0, 5.0], [5.0, -20.0]]),
        np.array(["DEF", "DEF"]),
        bank,
    )
    np.testing.assert_array_equal(pred, [40.0, 60.0])
