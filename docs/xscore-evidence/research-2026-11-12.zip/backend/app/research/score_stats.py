"""Lagged stat-count inputs and locally verified score reconstruction for research."""

from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from typing import Any

import numpy as np

from app.research.score_search import POSITIONS, cutoff_for, moment

POSITIVE = ("goals", "goal_assist", "assist_penalty_won", "clearance_off_line", "last_man_tackle", "penalty_save")
NEGATIVE = ("red_card", "own_goals", "penalty_conceded", "error_lead_to_goal")


def fit_weights(games: list[dict[str, Any]], names: list[str], before: str) -> tuple[np.ndarray, dict[str, Any]]:
    found: dict[tuple[str, str], float] = {}
    for g in games:
        if g["date"][:10] >= before:
            continue
        for r in g["players"].values():
            if not r.get("played") or r.get("ver") != 7:
                continue
            for stat, (count, points) in r["stats"].items():
                if count:
                    key = r["pos"], stat
                    ratio = float(points / count)
                    if key in found and abs(found[key] - ratio) > 1e-7:
                        raise ValueError(f"inconsistent stat-point rule: {key}")
                    found[key] = ratio
    weights = np.zeros((4, len(names)))
    shared, unknown = [], []
    for i, pos in enumerate(POSITIONS):
        for j, stat in enumerate(names):
            if (pos, stat) in found:
                weights[i, j] = found[pos, stat]
                continue
            observed = {round(v, 7) for (_, s), v in found.items() if s == stat}
            if len(observed) == 1:
                # A declared shared-rule hypothesis from earlier observations, audited later.
                weights[i, j] = next(iter(observed))
                shared.append([pos, stat, weights[i, j]])
            else:
                unknown.append([pos, stat])
    return weights, {
        "before": before,
        "observedPairs": len(found),
        "sharedRuleAssumptions": shared,
        "unpricedPairs": unknown,
        "unpricedPolicy": "No observed priced event for this position; predicted point contribution zero, actual reconstruction failures are counted",
    }


def point_totals(counts: np.ndarray, positions: np.ndarray, weights: np.ndarray) -> np.ndarray:
    index = np.array([POSITIONS.index(p) for p in positions])
    return (counts * weights[index]).sum(axis=-1)


def decisive_level(counts: np.ndarray, names: list[str], positions: np.ndarray) -> np.ndarray:
    def stat(name: str) -> np.ndarray:
        return counts[..., names.index(name)] if name in names else np.zeros(counts.shape[:-1])

    net = sum((stat(s) for s in POSITIVE), np.zeros(counts.shape[:-1]))
    net -= sum((stat(s) for s in NEGATIVE), np.zeros(counts.shape[:-1]))
    keepers = positions == "GK"
    while keepers.ndim < net.ndim:
        keepers = keepers[..., None]
    net += stat("clean_sheet_60") * keepers
    table = np.array([0, 5, 15, 35, 60, 70, 80, 90, 100])
    return table[np.clip(net, -3, 5).astype(int) + 3]


def add_stat_features(
    games: list[dict[str, Any]], rows: list[dict[str, Any]], base_names: list[str], names: list[str]
) -> tuple[np.ndarray, np.ndarray, list[str]]:
    records = []
    by_identity = {}
    for g in games:
        for player, r in g["players"].items():
            if not r.get("played") or type(r.get("started")) is not bool or r.get("ver") != 7:
                continue
            if r.get("mins") is None or not isinstance(r.get("stats"), dict):
                raise ValueError("Missing minutes or full stats cannot be treated as zero")
            count = np.array([r.get("stats", {}).get(s, [0, 0])[0] for s in names], dtype=float)
            record = {
                "available": moment(g["date"]) + timedelta(hours=48),
                "pos": r["pos"],
                "cohort": "start" if r["started"] else "bench",
                "player": player,
                "other": g["away" if r["team"] == g["home"]["slug"] else "home"]["slug"],
                "count": count,
                "minutes": r.get("mins") or 0,
            }
            records.append(record)
            by_identity[g["id"], player] = record
    records.sort(key=lambda r: r["available"])
    history: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    opposing: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    prior: dict[tuple[str, str], tuple[np.ndarray, float]] = {}
    seen = 0
    values, targets = [], []
    feature_names = [*base_names]
    for role in ("same", "other"):
        for n in (3, 10, 30):
            feature_names.extend(f"counts_{role}_{n}_{s}" for s in names)
    feature_names.extend(f"counts_opponent_{s}" for s in names)
    game_by_id = {g["id"]: g for g in games}
    for row in rows:
        cutoff = cutoff_for(row["date"])
        while seen < len(records) and records[seen]["available"] < cutoff:
            r = records[seen]
            history[r["player"], r["cohort"]].append(r)
            opposing[r["other"], r["pos"]].append(r)
            key = r["pos"], r["cohort"]
            counts, minutes = prior.get(key, (np.zeros(len(names)), 0.0))
            prior[key] = counts + r["count"], minutes + r["minutes"]
            seen += 1
        parts = [np.asarray(row["x"])]
        for cohort in (row["cohort"], "bench" if row["cohort"] == "start" else "start"):
            total, minutes = prior.get((row["pos"], cohort), (np.zeros(len(names)), 0.0))
            prior_rate = total * 90 / max(1, minutes)
            own = history[row["player"], cohort]
            for n in (3, 10, 30):
                recent = own[-n:]
                counts = sum((r["count"] for r in recent), np.zeros(len(names)))
                minutes = sum(r["minutes"] for r in recent)
                parts.append((counts + prior_rate * 300 / 90) * 90 / (minutes + 300))
        g = game_by_id[row["game"]]
        actual = g["players"][row["player"]]
        other = g["away" if actual["team"] == g["home"]["slug"] else "home"]["slug"]
        recent = opposing[other, row["pos"]][-150:]
        counts = sum((r["count"] for r in recent), np.zeros(len(names)))
        minutes = sum(r["minutes"] for r in recent)
        parts.append(counts * 90 / max(1, minutes))
        values.append(np.concatenate(parts))
        targets.append(by_identity[row["game"], row["player"]]["count"])
    return np.asarray(values, dtype=np.float32), np.asarray(targets, dtype=np.float32), feature_names


def sample_mode(samples: np.ndarray, centres: np.ndarray) -> np.ndarray:
    out = []
    for values in np.sort(samples, axis=1):
        count = np.searchsorted(values, centres + 7, side="right") - np.searchsorted(values, centres - 7, side="left")
        winners = centres[count == count.max()]
        out.append(winners[np.argmin(np.abs(winners - np.median(values)))])
    return np.asarray(out)


def simulate_counts(
    rates: np.ndarray,
    minutes: np.ndarray,
    residuals: np.ndarray,
    residual_minutes: np.ndarray,
    calibration_minutes: np.ndarray,
    calibration_positions: np.ndarray,
    positions: np.ndarray,
    weights: np.ndarray,
    names: list[str],
    goals_against: np.ndarray,
    scale: float,
    draws: int = 512,
) -> tuple[np.ndarray, np.ndarray]:
    """Joint empirical stat residuals; Poisson rare actions; coherent on-field goals/clean sheets.

    Approximation assumptions are experimental, never a validated match simulator.
    """
    rng = np.random.default_rng(20261103)
    aa_out, score_out = [], []
    for start in range(0, len(rates), 128):
        end = min(len(rates), start + 128)
        sampled = np.empty((end - start, draws), dtype=int)
        for i, pos in enumerate(positions[start:end]):
            eligible = np.flatnonzero(calibration_positions == pos)
            if not len(eligible):
                raise ValueError(f"No earlier residuals for position {pos}")
            sampled[i] = rng.choice(eligible, draws)
        sim_minutes = np.clip(minutes[start:end, None] + residual_minutes[sampled] * scale, 0, 100)
        exposure = np.sqrt(sim_minutes / np.maximum(1, calibration_minutes[sampled]))
        counts = rates[start:end, None, :] * sim_minutes[..., None] / 90
        counts += residuals[sampled] * exposure[..., None] * scale
        counts = np.rint(np.maximum(0, counts))
        for stat in (*POSITIVE, *NEGATIVE, "penalty_kick_missed"):
            if stat in names:
                j = names.index(stat)
                counts[..., j] = rng.poisson(np.maximum(0, rates[start:end, None, j] * sim_minutes / 90))
        if "goals_conceded" in names:
            ga = rng.poisson(np.maximum(0, goals_against[start:end, None] * sim_minutes / 90))
            counts[..., names.index("goals_conceded")] = ga
            if "clean_sheet_60" in names:
                counts[..., names.index("clean_sheet_60")] = (sim_minutes >= 60) & (ga == 0)
        for prerequisite, child in (
            ("ontarget_scoring_att", "goals"),
            ("penalty_won", "assist_penalty_won"),
            ("saves", "penalty_save"),
        ):
            if prerequisite in names and child in names:
                j, k = names.index(prerequisite), names.index(child)
                counts[..., j] = np.maximum(counts[..., j], counts[..., k])
        pos_index = np.array([POSITIONS.index(p) for p in positions[start:end]])
        aa = (counts * weights[pos_index, None, :]).sum(axis=2)
        level = decisive_level(counts, names, positions[start:end])
        scores = np.clip(level + aa, np.where(level >= 60, level, 0), 100)
        aa_out.extend(sample_mode(aa, np.arange(-50, 101)))
        score_out.extend(sample_mode(scores, np.arange(101)))
    return np.asarray(score_out), np.asarray(aa_out)
