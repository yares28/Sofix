"""Testing only: strip deterministic defensive effects before learning action points."""

from __future__ import annotations

import numpy as np

from app.research.score_stats import NEGATIVE, POSITIVE

CONCEDED_WEIGHTS = {"GK": -5.0, "DEF": -4.0, "MID": -2.0, "FWD": 0.0}
LEVELS = np.array([0, 5, 15, 35, 60, 70, 80, 90, 100])
MINUTE_GRID = np.arange(5, 96, 10, dtype=float)


def expanded_positions(positions, dimensions):
    positions = np.asarray(positions)
    while positions.ndim < dimensions:
        positions = positions[..., None]
    return positions


def stripped_targets(aa, net, conceded, clean, positions):
    if any(not np.isfinite(a).all() for a in (aa, net, conceded, clean)):
        raise ValueError("Stripped scoring targets must be known")
    if not np.isin(clean, (0, 1)).all() or (conceded < 0).any():
        raise ValueError("Invalid conceded-goal/clean-sheet counts")
    weights = np.array([CONCEDED_WEIGHTS[p] for p in positions])
    base_aa = aa - weights * conceded - (positions == "DEF") * clean * 10
    base_net = net - (positions == "GK") * clean
    return base_aa, base_net


def apply_mechanics(base_aa, base_net, minutes, conceded, positions):
    if any(not np.isfinite(a).all() for a in (base_aa, base_net, minutes, conceded)):
        raise ValueError("Mechanical score inputs must be known")
    pos = expanded_positions(positions, base_aa.ndim)
    weights = np.array([CONCEDED_WEIGHTS[p] for p in positions])
    while weights.ndim < base_aa.ndim:
        weights = weights[..., None]
    clean = (minutes >= 60) & (conceded == 0)
    aa = base_aa + weights * conceded + (pos == "DEF") * clean * 10
    net = base_net + (pos == "GK") * clean
    level = LEVELS[np.clip(net, -3, 5).astype(int) + 3]
    score = np.clip(np.maximum(np.where(level >= 60, level, 0), level + aa), 0, 100)
    return score, aa, net


def conceded_samples(lam, clean_chance, minutes, uniform, method):
    from scipy.stats import poisson

    if any(not np.isfinite(a).all() for a in (lam, clean_chance, minutes, uniform)):
        raise ValueError("Conceded-goal probabilities and exposure must be known")
    if (lam <= 0).any() or ((clean_chance < 0) | (clean_chance > 1)).any() or (minutes <= 0).any():
        raise ValueError("Invalid conceded-goal distribution")
    rate = lam[:, None] * minutes / 90
    if method == "lambda":
        return poisson.ppf(uniform, rate)
    if method != "calibratedCS":
        raise ValueError("Unknown conceded-goal method")
    zero = clean_chance[:, None] ** (minutes / 90)
    positive_quantile = np.clip((uniform - zero) / np.maximum(1e-15, 1 - zero), 0, 1)
    cdf = np.exp(-rate) + (-np.expm1(-rate)) * positive_quantile
    positive = np.maximum(1, poisson.ppf(np.minimum(cdf, 1 - 1e-12), rate))
    return np.where(uniform <= zero, 0, positive)


def observed_components(rows, games):
    """Factual labels only; callers must embargo training/calibration before forecast use."""
    by_game = {g["id"]: g for g in games}
    net, conceded, clean, positions, aa, minutes, scores = [], [], [], [], [], [], []
    prices, counter, absent = {}, 0, 0
    for row in rows:
        record = by_game[row["game"]]["players"][row["player"]]
        stats = record.get("stats")
        if record.get("ver") != 7 or not isinstance(stats, dict) or record.get("mins") is None:
            raise ValueError("Unknown complete v7 stats")

        def count(name, stats=stats):
            return float(stats.get(name, [0, 0])[0])

        pos = row["pos"]
        net.append(
            sum(count(n) for n in POSITIVE) - sum(count(n) for n in NEGATIVE) + (pos == "GK") * count("clean_sheet_60")
        )
        conceded.append(count("goals_conceded"))
        clean.append(count("clean_sheet_60"))
        positions.append(pos)
        aa.append(row["aa"])
        minutes.append(row["minutes"])
        scores.append(row["score"])
        # These exact rules are certified using data before the earliest fit cutoff.
        if row["date"] < "2023-11-01":
            for name in ("goals_conceded", "clean_sheet_60"):
                value = stats.get(name)
                if value and value[0]:
                    price = float(value[1] / value[0])
                    identity = pos, name
                    if identity in prices and abs(prices[identity] - price) > 1e-9:
                        raise ValueError("Inconsistent early scoring rule")
                    prices[identity] = price
                    counter += 1
                absent += value is None
    pos = np.array(positions)
    aa, net, conceded, clean, minutes, scores = map(np.array, (aa, net, conceded, clean, minutes, scores))
    for p in ("GK", "DEF", "MID"):
        if prices.get((p, "goals_conceded")) != CONCEDED_WEIGHTS[p]:
            raise ValueError("Conceded-goal price lacks earlier evidence")
    if prices.get(("DEF", "clean_sheet_60")) != 10 or prices.get(("GK", "clean_sheet_60")) != 0:
        raise ValueError("Clean-sheet price lacks earlier evidence")
    base_aa, base_net = stripped_targets(aa, net, conceded, clean, pos)
    reconstructed, _, _ = apply_mechanics(base_aa, base_net, minutes, conceded, pos)
    mismatch = np.abs(reconstructed - scores) > 1e-7
    if mismatch.any():
        raise ValueError(f"Mechanical reconstruction fails for {int(mismatch.sum())} cases")
    return (
        base_aa,
        base_net,
        {
            "cases": len(rows),
            "earlyPriceObservations": counter,
            "earlyOmittedZeroFields": absent,
            "reconstructionFailures": 0,
            "maxScoreDifference": float(np.max(np.abs(reconstructed - scores))),
            "baseNetCounts": {str(v): int((base_net == v).sum()) for v in sorted(set(base_net))},
        },
    )


def fitted_pieces(frame, cats, base_aa, base_net, minutes, mask, path, key):
    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) == key:
                return {
                    name: stored[name]
                    for name in ("classes", "probability", "locations", "minutes", "factual_location")
                }
    from catboost import CatBoostClassifier, Pool

    from app.research import score_ordinary as ordinary
    from app.research.score_flow import predict_batched

    fit, target = mask["fit"], mask["target"]
    train = frame.loc[fit].copy()
    minute_model = ordinary.regressor("MAE", minutes=True)
    minute_model.fit(Pool(train, label=minutes[fit], cat_features=cats))
    decisive = CatBoostClassifier(
        loss_function="MultiClass",
        iterations=300,
        depth=4,
        l2_leaf_reg=20,
        learning_rate=0.05,
        random_seed=20261104,
        thread_count=4,
        task_type="CPU",
        border_count=64,
        max_ctr_complexity=1,
        allow_writing_files=False,
        verbose=False,
    )
    decisive.fit(Pool(train, label=base_net[fit], cat_features=cats))
    train["exposure"] = minutes[fit]
    train["candidate_net"] = base_net[fit]
    aa_model = ordinary.regressor("MAE")
    aa_model.fit(Pool(train, label=base_aa[fit], cat_features=cats))
    future = frame.loc[target].reset_index(drop=True)
    predicted_minutes = np.clip(predict_batched(minute_model, future, cats), 1, 100)
    probability = predict_batched(decisive, future, cats, probability=True)
    classes = np.asarray(decisive.classes_, dtype=float)
    # Actual target exposure/net appear in this separate calibration output only.
    factual = future.copy()
    factual["exposure"] = minutes[target]
    factual["candidate_net"] = base_net[target]
    factual_location = predict_batched(aa_model, factual, cats)
    locations = np.empty((len(future), len(MINUTE_GRID), len(classes)), dtype=np.float32)
    for i, exposure in enumerate(MINUTE_GRID):
        future["exposure"] = exposure
        for j, net in enumerate(classes):
            future["candidate_net"] = net
            locations[:, i, j] = predict_batched(aa_model, future, cats)
    result = {
        "classes": classes,
        "probability": probability,
        "locations": locations,
        "minutes": predicted_minutes,
        "factual_location": factual_location,
    }
    np.savez_compressed(path, key=key, **result)
    return result


def paired_bank(rows, base_aa, base_net, pieces, first):
    from app.research.score_stability import previous_bank_mask

    available = previous_bank_mask(rows, first)
    positions = np.array([r["pos"] for r in rows])
    minutes = np.array([r["minutes"] for r in rows])
    residual = np.column_stack((minutes - pieces["minutes"], base_aa - pieces["factual_location"]))
    if not available.any() or not np.isfinite(residual[available]).all():
        raise ValueError("Earlier paired calibration residuals must be known")
    return {
        "global": residual[available],
        "positions": {p: residual[available & (positions == p)] for p in set(positions[available])},
        "levels": {
            (p, float(v)): residual[available & (positions == p) & (base_net == v)]
            for p, v in set(zip(positions[available], base_net[available], strict=True))
        },
        "cases": int(available.sum()),
        "unavailable": int((~available).sum()),
    }


def paired_draws(pieces, positions, bank, count=2048, seed=20261104):
    from scipy.stats import qmc

    if count <= 0 or count & (count - 1):
        raise ValueError("Draw count must be a power of two")
    uniform = qmc.Sobol(d=4, scramble=True, seed=seed).random_base2(int(np.log2(count)))
    probability = pieces["probability"]
    indices = np.sum(uniform[None, :, 0, None] > np.cumsum(probability, axis=1)[:, None, :], axis=2)
    indices = np.minimum(indices, len(pieces["classes"]) - 1)
    errors = np.zeros((*indices.shape, 2))
    for pos in set(positions):
        selected = np.flatnonzero(positions == pos)
        pooled = bank["positions"].get(pos, bank["global"])
        base = pooled[np.minimum((uniform[:, 2] * len(pooled)).astype(int), len(pooled) - 1)]
        for j, value in enumerate(pieces["classes"]):
            conditional = bank["levels"].get((pos, float(value)))
            sampled = base
            if conditional is not None and len(conditional):
                other = conditional[np.minimum((uniform[:, 2] * len(conditional)).astype(int), len(conditional) - 1)]
                sampled = np.where((uniform[:, 1] < len(conditional) / (len(conditional) + 20))[:, None], other, base)
            errors[selected] = np.where((indices[selected] == j)[:, :, None], sampled[None, :, :], errors[selected])
    return indices, errors[..., 0], errors[..., 1], uniform[:, 3][None, :]


def sampled_base_locations(pieces, indices, minute_errors, minute_spread):
    minutes = np.clip(pieces["minutes"][:, None] + minute_errors * minute_spread, 1, 100)
    coordinate = np.clip((minutes - MINUTE_GRID[0]) / 10, 0, len(MINUTE_GRID) - 1)
    low = np.floor(coordinate).astype(int)
    high = np.ceil(coordinate).astype(int)
    rows = np.arange(len(minutes))[:, None]
    left, right = pieces["locations"][rows, low, indices], pieces["locations"][rows, high, indices]
    location = left * (1 - (coordinate - low)) + right * (coordinate - low)
    return minutes, location


def mechanistic_prediction(base_aa, base_net, minutes, conceded, positions):
    from app.research.score_flow import sample_prediction

    score, _, _ = apply_mechanics(base_aa, base_net, minutes, conceded, positions)
    # The score distribution is already assembled; window selection does not alter it.
    return sample_prediction(np.zeros_like(score), score, np.zeros_like(score), 1, 0)
