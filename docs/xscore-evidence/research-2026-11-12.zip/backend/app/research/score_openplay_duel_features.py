"""Historical type, pitch location, and paired aerial opponent profiles."""

from __future__ import annotations

import csv
import gzip
import hashlib
from collections import defaultdict, deque
from datetime import timedelta

import numpy as np

from app.research.score_opposition_strength import DEPTH
from app.research.score_search import cutoff_for, moment

KIND = {"aerial": 0, "dribblePast": 1, "tackleOrSmother": 1, "foul": 2}
ZONE_WIDTH = 100 / 3
TYPE_FIELDS = tuple(
    f"{kind}_{third}_{stat}"
    for kind in ("aerial", "ground", "foul")
    for third in ("defence", "middle", "attack")
    for stat in ("win_share", "player_rate", "opponent_mix")
)
TEAM_FIELDS = ("player_games", "opponent_games", "mix_adjusted_share", "mix_own_share", "opponent_contests_per_game")
PAIR_FIELDS = ("aerial_ability", "aerial_rivals_ability", "aerial_projected_win", "aerial_roster_known_weight")
FEATURES = TYPE_FIELDS + TEAM_FIELDS + PAIR_FIELDS


def read_contests(directory, report, games):
    pairs = directory / "qualified_pairs.csv.gz"
    identities = directory / "qualified_players.csv"
    for file, key in ((pairs, "pairedArtifactSha256"), (identities, "playerIdentityArtifactSha256")):
        if hashlib.sha256(file.read_bytes()).hexdigest() != report[key]:
            raise ValueError(f"Unqualified source file: {file.name}")
    mapping = {}
    with identities.open(encoding="utf-8", newline="") as fp:
        for row in csv.DictReader(fp):
            game = games[row["nativeGame"]]
            club = row["club"]
            p = row["nativePlayer"]
            if game["players"][p]["team"] != club or not game["players"][p]["played"]:
                raise ValueError("Mapped contest actor is not a played native participant")
            key = row["sourceMatch"], club, row["sourcePlayer"]
            if key in mapping:
                raise ValueError("Duplicate mapped actor")
            mapping[key] = p
    recorded = defaultdict(list)
    with gzip.open(pairs, "rt", encoding="utf-8", newline="") as fp:
        for r in csv.DictReader(fp):
            game = games[r["nativeGame"]]
            clubs = r["winnerClub"], r["loserClub"]
            if set(clubs) != {game["home"]["slug"], game["away"]["slug"]}:
                raise ValueError("Contest sides differ from native fixture")
            winner, loser = (mapping.get((r["sourceMatch"], r[s + "Club"], r[s + "Id"])) for s in ("winner", "loser"))
            x = float(r["x"])
            if not 0 <= x <= 100:
                raise ValueError("Pitch coordinates out of range")
            recorded[game["id"]].append((KIND[r["kind"]], x, clubs, (winner, loser)))
    if sum(map(len, recorded.values())) != report["playerIdentity"]["allPairs"]:
        raise ValueError("Contest coverage differs")
    return dict(recorded)


def zone(x):
    return min(2, int(x / ZONE_WIDTH))


def chance(gap):
    return 1 / (1 + np.exp(-gap))


def rating_at(ratings, player, at):
    if player not in ratings:
        return None
    level, last = ratings[player]
    age = (at - last).total_seconds() / 86400
    if age < 0:
        raise ValueError("Rating chronology differs")
    return level * 2 ** (-age / 120) if age <= 120 else None


def summaries(matches, after):
    usable = [value for available, value in matches if available >= after]
    return (sum(usable), len(usable)) if usable else (None, 0)


def type_profile(own, own_games, opposition, opponent_games):
    if own is None:
        share = rate = np.full((3, 3), np.nan)
        prior = np.nan
    else:
        attempts = own.sum(axis=-1)
        prior = (own[:, :, 0].sum() + 3) / (attempts.sum() + 6)
        share = (own[:, :, 0] + 6 * prior) / (attempts + 6)
        rate = attempts / own_games
    if opposition is None:
        mix, adjusted, volume = np.full((3, 3), np.nan), np.nan, np.nan
    else:
        attempts = opposition.sum(axis=-1)[:, ::-1]
        mix = attempts / attempts.sum()
        adjusted = np.sum(share * mix)
        volume = attempts.sum() / opponent_games
    return [*np.stack((share, rate, mix), axis=-1).ravel(), own_games, opponent_games, adjusted, prior, volume]


def pair_profile(player, pos, club_history, ratings, lock):
    own = rating_at(ratings, player, lock)
    rivals = defaultdict(float)
    for played in club_history:
        for rival, role, minutes in played:
            if role in DEPTH and rival != player:
                rivals[rival] += minutes / (0.25 + abs(DEPTH[pos] + DEPTH[role] - 1.2))
    rivals_total = sum(rivals.values())
    known = {p: (weight, rating_at(ratings, p, lock)) for p, weight in rivals.items()}
    rated = [(weight, level) for weight, level in known.values() if level is not None]
    denominator = sum(weight for weight, _ in rated)
    if not denominator:
        return [np.nan if own is None else own, np.nan, np.nan, 0.0]
    average = sum(weight * level for weight, level in rated) / denominator
    win = sum(weight * chance(own - level) for weight, level in rated) / denominator if own is not None else np.nan
    return [np.nan if own is None else own, average, win, denominator / rivals_total]


def features_for(rows, games, contests):
    schedule = sorted((moment(g["date"]) + timedelta(hours=48), key) for key, g in games.items())
    order = sorted((cutoff_for(row["date"]), i) for i, row in enumerate(rows))
    out = np.full((len(rows), len(FEATURES)), np.nan)
    player_history = defaultdict(lambda: deque(maxlen=25))
    club_history = defaultdict(lambda: deque(maxlen=25))
    lineups = defaultdict(lambda: deque(maxlen=3))
    ratings = {}
    cursor = 0
    for lock, i in order:
        while cursor < len(schedule) and schedule[cursor][0] < lock:
            available, key = schedule[cursor]
            cursor += 1
            game = games[key]
            own_stats = defaultdict(lambda: np.zeros((3, 3, 2)))
            club_stats = defaultdict(lambda: np.zeros((3, 3, 2)))
            changes = defaultdict(lambda: [0.0, 0])
            for kind, x, clubs, actors in contests.get(key, ()):
                for lost, (club, actor) in enumerate(zip(clubs, actors, strict=True)):
                    third = zone(x if lost == 0 else 100 - x)
                    club_stats[club][kind, third, lost] += 1
                    if actor:
                        own_stats[actor][kind, third, lost] += 1
                won, lost = actors
                if kind == 0 and won and lost:
                    a, b = (rating_at(ratings, p, available) or 0.0 for p in actors)
                    error = 1 - chance(a - b)
                    for player, delta in ((won, error), (lost, -error)):
                        changes[player][0] += delta
                        changes[player][1] += 1
            for player, (change, n) in changes.items():
                previous = rating_at(ratings, player, available) or 0.0
                ratings[player] = previous + 0.22 * change / np.sqrt(n), available
            for actor, values in own_stats.items():
                player_history[actor].append((available, values))
            for club, values in club_stats.items():
                club_history[club].append((available, values))
            for side in ("home", "away"):
                club = game[side]["slug"]
                lineups[club].append(
                    (
                        available,
                        [
                            (player, person["pos"], person["mins"])
                            for player, person in game["players"].items()
                            if person.get("team") == club
                            and person.get("played") is True
                            and person.get("mins") is not None
                        ],
                    )
                )
        row = rows[i]
        game = games[row["game"]]
        player, pos = row["player"], row["pos"]
        own = game["players"][player]["team"]
        home, away = game["home"]["slug"], game["away"]["slug"]
        if own not in (home, away) or row["date"] != game["date"]:
            raise ValueError("Source target identity differs")
        opponent = away if own == home else home
        after = lock - timedelta(days=120) + timedelta(hours=48)
        a, ac = summaries(player_history[player], after)
        b, bc = summaries(club_history[opponent], after)
        prospective = [members for available, members in lineups[opponent] if available >= after]
        pair = pair_profile(player, pos, prospective, ratings, lock) if pos in DEPTH else [np.nan] * len(PAIR_FIELDS)
        out[i] = type_profile(a, ac, b, bc) + pair
    return out
