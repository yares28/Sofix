import pytest

from app.research import score_referee_articles as source


def body(links):
    return '<div class="news__header__date mt-4">Vie, 23/01/2026 - 13:00</div>' + "".join(
        f'<a href="{v}">DESIGNACIÓN COMPLETA</a>' for v in links
    )


def test_unique_official_pdf_links_preserve_query_and_publication_clock():
    result = source.article(body(["/sites/default/files/one.pdf?cb=x&amp;a=1"] * 2), "2026-01-23")
    assert result["pdfURLs"] == ["https://rfef.es/sites/default/files/one.pdf?cb=x&a=1"]
    assert result["publicationUTC"] == "2026-01-23T12:00:00+00:00"


def test_multiple_official_documents_are_all_retained():
    result = source.article(
        body(["/sites/default/files/one.pdf", "https://www.rfef.es/sites/default/files/two.PDF"]), "2026-01-23"
    )
    assert len(result["pdfURLs"]) == 2


def test_nonofficial_pdf_and_catalogue_date_conflicts_are_explicit():
    with pytest.raises(ValueError, match="host"):
        source.article(body(["https://example.com/one.pdf"]), "2026-01-23")
    with pytest.raises(ValueError, match="catalogue"):
        source.article(body(["/sites/default/files/one.pdf"]), "2026-01-22")


def test_no_pdf_is_an_explicit_source_gap_without_fabricated_assignment():
    result = source.article(body([]), "2026-01-23")
    assert result["pdfURLs"] == []
    assert result["status"] == "no_linked_pdf"
