"""Predict the most probable fourteen-point interval from lagged LaLiga stats."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval


def window_centres(probability: np.ndarray, centres: np.ndarray) -> np.ndarray:
    winners = np.abs(probability - probability.max(axis=1, keepdims=True)) <= 1e-12
    middle = (winners * centres).sum(axis=1) / winners.sum(axis=1)
    distances = np.where(winners, np.abs(centres - middle[:, None]), np.inf)
    return centres[distances.argmin(axis=1)]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import ExtraTreesRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    stored = np.load(args.stats_cache)
    allx = stored["x"]
    report = {
        "target": "Choose score with greatest predicted chance of actual score within seven; separate starts/substitutes",
        "split": "Train before July2025, choose July-Dec2025, refit before Jan2026, same Jan-Oct2026 evaluation",
        "evidenceLimit": "Exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "statKey": str(stored["key"]),
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        x = allx[keep]
        y = np.array([r["score"] for r in rows])
        dates = np.array([r["date"][:10] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        centres = np.arange(0, 100.01, 0.5)
        targets = (np.abs(y[:, None] - centres) <= 7).astype(np.float32)
        candidates = []

        def model_for(minimum: int):
            return ExtraTreesRegressor(
                n_estimators=100,
                min_samples_leaf=minimum,
                max_features=0.7,
                max_depth=16,
                n_jobs=4,
                random_state=20261103,
            )

        for group, width in (("base", len(source["features"])), ("counts", x.shape[1])):
            for minimum in (15, 30, 100):
                model = model_for(minimum).fit(x[train, :width], targets[train])
                prediction = window_centres(model.predict(x[valid, :width]), centres)
                spec = {
                    "group": group,
                    "width": width,
                    "minimumLeaf": minimum,
                    "selection": measure(y[valid], prediction),
                }
                candidates.append(spec)
                del model
                print(f"Selected {cohort}: " + json.dumps(spec), flush=True)
        winner = max(candidates, key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        model = model_for(winner["minimumLeaf"]).fit(x[~test, : winner["width"]], targets[~test])
        prediction = window_centres(model.predict(x[test, : winner["width"]]), centres)
        baseline_cache = np.load(args.cache / f"europe_predictions_{cohort}.npz")
        if not np.array_equal(y[test], baseline_cache["y"]):
            raise ValueError("Baseline comparison cases differ")
        baseline = baseline_cache["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        positions = np.array([r["pos"] for r in rows])[test]
        result = {
            "winner": winner,
            "candidates": candidates,
            "later": measure(y[test], prediction),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "conditionalControl": measure(y[test], baseline),
            "gain95": paired_interval(y[test], prediction, baseline, weeks),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {
                pos: measure(y[test][positions == pos], prediction[positions == pos])
                for pos in POSITIONS
                if (positions == pos).any()
            },
        }
        np.savez_compressed(args.cache / f"window_predictions_{cohort}.npz", prediction=prediction, y=y[test])
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
