"""Testing only: fixed previous error-shape settings with new player information."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from app.research.score_empirical_density import empirical_predictions, fit_bank
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "component-report", "reference", "cache", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    component = json.loads(args.component_report.read_text(encoding="utf-8"))
    reference = json.loads(args.reference.read_text(encoding="utf-8"))
    if source["key"] != component["sourceKey"] or source["key"] != reference["sourceKey"]:
        raise ValueError("Comparison source differs")
    key = hashlib.sha256(
        (source["key"] + component["implementationKey"] + reference["implementationKey"]).encode()
        + Path(__file__).read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "implementationKey": key,
        "settings": "Exact previous40.9procedure; nonewsettingselection",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"] for r in rows])
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        y, aa, levels = (np.array([r[n] for r in rows]) for n in ("score", "aa", "level"))
        positions = np.array([r["pos"] for r in rows])
        spec = reference["cohorts"][cohort]["empiricalSpec"]
        with np.load(args.cache / f"laliga_score_match_empirical_density_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]) or str(stored["key"]) != reference["implementationKey"]:
                raise ValueError("Previous empirical reference differs")
            baseline = stored["alternate"]
        predictions = {}
        for group in ("team_context", "player_chances", "player_chances_usage"):
            prefix = f"feature_{args.component_report.stem}_{cohort}_{group}"
            classes, _, parts = components(args.cache / (prefix + "_selection.npz"), component["implementationKey"])
            bank = fit_bank(
                classes,
                parts,
                aa[valid],
                levels[valid],
                positions[valid],
                np.ones(int(valid.sum()), dtype=bool),
                spec["mode"],
            )
            classes, probability, parts = components(
                args.cache / (prefix + "_later.npz"), component["implementationKey"]
            )
            predictions[group] = empirical_predictions(
                classes, probability, parts, positions[test], bank, spec["prior"], spec["multiplier"], spec["shift"]
            )
        if not np.allclose(predictions["team_context"], baseline, atol=1e-10, rtol=1e-10):
            raise ValueError("Team-only frozen procedure did not reproduce")
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {"spec": spec, "reference": measure(y[test], baseline), "groups": {}}
        for group, prediction in predictions.items():
            result["groups"][group] = {
                "later": measure(y[test], prediction),
                "gain95": paired_interval(y[test], prediction, baseline, weeks),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
                "positions": {
                    p: measure(y[test][positions[test] == p], prediction[positions[test] == p])
                    for p in POSITIONS
                    if (positions[test] == p).any()
                },
            }
        np.savez_compressed(args.cache / f"{args.out.stem}_predictions_{cohort}.npz", key=key, y=y[test], **predictions)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT " + json.dumps({"cohort": cohort, "groups": {g: v["later"] for g, v in result["groups"].items()}}),
            flush=True,
        )


if __name__ == "__main__":
    main()
