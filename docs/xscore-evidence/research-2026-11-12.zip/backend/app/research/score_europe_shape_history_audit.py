"""Testing only: independent European XI/shape facts and all domestic forecast descriptors."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research import score_europe_routine_history_audit as native_audit
from app.research import score_europe_shape_history as history
from app.research import score_pooled_history_audit as labels_audit
from app.research import score_search
from app.research import score_team_shape_history as shape
from app.research import score_team_shape_history_audit as shape_audit
from app.research.score_search import cutoff_for, moment


def independent_euro(g, points, receipt):
    result = []
    for side, opposite in (("home", "away"), ("away", "home")):
        club = g[side + "Team"]["slug"]
        other = g[opposite + "Team"]["slug"]
        formation = g.get(side + "Formation") or {}
        lines = formation.get("startingLineup") or []
        named = [p.get("slug") for line in lines for p in line]
        complete = (
            formation.get("startingLineupAvailable") is True
            and len(named) == 11
            and len(set(named)) == 11
            and all(named)
        )
        xi_set = set(named)
        bench = {p.get("slug") for p in formation.get("bench") or []}
        facts = {}
        conflict = False
        positions = dict(Goalkeeper="GK", Defender="DEF", Midfielder="MID", Forward="FWD")
        for raw in g.get("playerGameScores") or []:
            stats = raw.get("anyPlayerGameStats") or {}
            p = (raw.get("anyPlayer") or {}).get("slug")
            mins = stats.get("minsPlayed")
            if (
                not p
                or (stats.get("anyTeam") or {}).get("slug") != club
                or stats.get("playedInGame") is not True
                or type(mins) not in (int, float)
                or not math.isfinite(mins)
                or not 1 <= mins <= 120
            ):
                continue
            flag = stats.get("gameStarted")
            if flag not in (None, 0, 1, False, True):
                conflict = True
                receipt["nativeCohortConflicts"] += 1
                continue
            explicit = None if flag is None else bool(flag)
            if complete and ((explicit is True and p not in xi_set) or (explicit is False and p in xi_set)):
                conflict = True
                receipt["nativeCohortConflicts"] += 1
                continue
            cohort = ("start" if p in xi_set else "bench" if p in bench else None) if complete else None
            if cohort is None:
                cohort = "start" if explicit is True else "bench" if explicit is False else None
            fact = cohort, positions.get(raw.get("positionTyped"))
            if p in facts and facts[p] != fact:
                conflict = True
                receipt["ambiguousPositiveNativeFacts"] += 1
            facts[p] = fact
        starts = sorted(p for p, (cohort, _) in facts.items() if cohort == "start")
        native_xi = starts if len(starts) == 11 and not conflict else None
        signature = None
        if (
            complete
            and native_xi is not None
            and set(starts) == xi_set
            and len(lines) >= 2
            and len(lines[0]) == 1
            and all(lines)
            and facts.get(named[0], (None, None))[1] == "GK"
        ):
            signature = [len(line) for line in lines[1:]]
        labels = []
        for r in points:
            if r["club"] == club and r["cohort"] in ("start", "bench") and r["ordinary"]["kind"] == "exact":
                labels.append(
                    dict(
                        player=r["player"], pos=r["pos"], cohort=r["cohort"], aa=r["ordinary"]["point"], shape=signature
                    )
                )
        receipt["teamSides"] += 1
        receipt["published11"] += bool(complete)
        receipt["nativeVerified11"] += native_xi is not None
        receipt["nativeVerifiedShape"] += signature is not None
        receipt["exactKnownCohortAALabels"] += len(labels)
        result.append(
            dict(
                game=g["id"],
                date=g["date"],
                club=club,
                opponent=other,
                source="euro",
                xi=native_xi,
                shape=signature,
                labels=labels,
            )
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "archives", "routine-cache", "features", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    raw = args.routine_cache.with_suffix(".observations.json.gz").read_bytes()
    corpus = json.loads(gzip.decompress(raw))
    saved = {(r["game"], r["player"]): r for r in corpus["records"]}
    points, targets, prices, receipts, ll_sha, _ = native_audit.native_sources(args.games, args.archives, saved)
    if targets != corpus["targets"] or prices != corpus["earlyNativePrices"] or ll_sha != corpus["laligaSha256"]:
        raise ValueError("Independent European-shape native scored source differs")
    points, _ = labels_audit.native_labels(args.games, args.archives, points, saved)
    groups = defaultdict(list)
    for r in points:
        if r["source"] == "euro":
            groups[r["game"]].append(r)
    games = [json.loads(line) for line in args.games.open("rb") if line.strip()]
    records = [{**r, "source": "laliga"} for r in shape_audit.parse_native(games)]
    independent_receipts = []
    for receipt in receipts:
        path = args.archives / receipt["archive"]
        counter = Counter()
        with zipfile.ZipFile(path) as z:
            for name in sorted(z.namelist()):
                if not name.startswith("games/") or not name.endswith(".json"):
                    continue
                g = json.loads(z.read(name)).get("raw") or {}
                if g.get("statusTyped") == "played":
                    records.extend(independent_euro(g, groups[g["id"]], counter))
        independent_receipts.append(dict(archive=path.name, sha256=receipt["sha256"], counts=dict(counter)))
    payload = json.loads(gzip.decompress(args.features.with_suffix(".observations.json.gz").read_bytes()))
    native_by_id = {(r["game"], r["club"]): r for r in records}
    stored_by_id = {(r["game"], r["club"]): r for r in payload["records"]}
    if (
        len(native_by_id) != len(records)
        or set(native_by_id) != set(stored_by_id)
        or targets != payload["targets"]
        or independent_receipts != payload["receipts"]
        or independent_receipts != report["receipts"]
    ):
        raise ValueError("Independent native European-shape side/source coverage differs")
    for identity, r in native_by_id.items():
        actual = stored_by_id[identity]
        for field in ("game", "date", "club", "opponent", "source", "xi", "shape"):
            if actual[field] != r[field]:
                raise ValueError("Native European XI/shape identity mismatch: " + str(identity) + field)
        sort = lambda labels: sorted(labels, key=lambda q: (q["player"], q["pos"], q["cohort"]))
        if sort(actual["labels"]) != sort(r["labels"]):
            raise ValueError("Native exact-v7 formation AA labels/cohorts differ: " + str(identity))
    ll_labels = {(r["game"], p["player"]): p for r in records if r["source"] == "laliga" for p in r["labels"]}
    for row in source["rows"]:
        p = ll_labels[row["game"], row["player"]]
        if p["pos"] != row["pos"] or p["cohort"] != row["cohort"] or abs(p["aa"] - row["aa"]) > 1e-10:
            raise ValueError("Independent European-shape native canonical score-case identity differs")
    raw_sha = hashlib.sha256(raw).hexdigest()
    key = hashlib.sha256(
        (source["key"] + corpus["key"] + ll_sha + raw_sha + "".join(r["sha256"] for r in receipts)).encode()
        + Path(history.__file__).read_bytes()
        + Path(shape.__file__).read_bytes()
        + Path(ordinary.__file__).read_bytes()
        + Path(score_search.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    with np.load(args.features) as f:
        x = f["x"]
        if str(f["key"]) != key or tuple(f["names"]) != history.NAMES or x.shape != (38850, 204):
            raise ValueError("European-shape source/code/plan/schema/cache identity differs")
    if (
        report["featureKey"] != key
        or payload["key"] != key
        or report["sourceKey"] != source["key"]
        or raw_sha != payload["routineCorpusSha256"]
    ):
        raise ValueError("European-shape report/corpus identity differs")
    print("EUROPE_SHAPE_AUDIT independent38850x204", flush=True)
    repeated = np.column_stack(
        [
            shape_audit.independent_features(
                source["rows"], targets, [r for r in records if name == "combined" or r["source"] == "euro"]
            )
            for name in ("euro", "combined")
        ]
    )
    same = np.isclose(x, repeated, atol=1e-10, rtol=0, equal_nan=True)
    if not same.all():
        bad = np.argwhere(~same)
        details = [(int(i), history.NAMES[j], float(x[i, j]), float(repeated[i, j])) for i, j in bad[:16]]
        raise ValueError(f"Independent European-shape204features differ {len(bad)}cells: {details}")
    ll_only = [r for r in payload["records"] if r["source"] == "laliga"]
    domestic = history.features_for(source["rows"], targets, ll_only)
    with np.load(args.features.parent / "team_shape_features.npz") as f:
        if str(f["key"]) != "090cc6a58bb5bc1769128c7c330c4bc9253aac6ae9eee6cd82d8ea54b3f48ec5" or not np.array_equal(
            domestic, f["x"], equal_nan=True
        ):
            raise ValueError("European-shape LL-only ablation lost exact original102descriptors")
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    chosen = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    altered = copy.deepcopy(payload["records"])
    changed = 0
    for r in altered:
        if moment(r["date"]).timestamp() + 172800 >= first.timestamp():
            r["xi"] = ["unavailable" + str(i) for i in range(11)]
            r["shape"] = [1, 2, 7]
            for p in r["labels"]:
                p.update(aa=np.nan, shape=[1, 2, 7])
            changed += 1
    query = [{**source["rows"][i], "aa": np.nan, "score": np.nan, "minutes": -999, "level": np.nan} for i in chosen]
    changed_targets = copy.deepcopy(targets)
    for g in changed_targets:
        g["xi"] = {"home": {"available": False}, "away": {"available": False}}
        for p in g["players"].values():
            p.update(aa=np.nan, score=np.nan, minutes=-999)
    causal = history.build_features(query, changed_targets, altered)
    if not np.array_equal(causal, x[chosen], equal_nan=True):
        raise ValueError("Unavailable European/LL XI/shape/AA or current outcomes changed prelock inputs")
    result = dict(
        scope="Testing-only full independent European shape source/features/time audit, no accuracy claim",
        featureKey=key,
        nativeTeamSidesVerified=len(records),
        nativeExactAALabelsVerified=sum(len(r["labels"]) for r in records),
        canonicalCasesMatched=38850,
        independentFeatureRows=len(x),
        featureColumns=204,
        all204ColumnsReproduced=True,
        absoluteTolerance=1e-10,
        allOriginalLLOnly102ColumnsBitExactlyReproduced=True,
        unavailableFutureTeamSidesMutated=changed,
        first2026LockCasesUnchanged=len(chosen),
        all6754Starts2925PlayedSubsRetained=True,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
