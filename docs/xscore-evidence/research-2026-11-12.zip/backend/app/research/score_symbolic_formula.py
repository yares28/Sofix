"""Testing only: deterministic evolution of small arithmetic and conditional score formulas."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

CONSTANTS = (-20, -10, -7, -5, -3, -1, 0, 1, 3, 5, 7, 10, 15, 25, 35, 40, 50, 60, 70, 80, 90)
OPERATORS = ("add", "sub", "mul", "div", "min", "max", "if")


def tree_key(tree):
    return json.dumps(tree, separators=(",", ":"), allow_nan=False)


def node_paths(tree, prefix=()):
    result = [prefix]
    if tree[0] not in ("v", "c"):
        for i in range(1, len(tree)):
            result.extend(node_paths(tree[i], (*prefix, i)))
    return result


def depth(tree):
    return 0 if tree[0] in ("v", "c") else 1 + max(depth(t) for t in tree[1:])


def subtree(tree, path):
    for i in path:
        tree = tree[i]
    return tree


def replace(tree, path, value):
    if not path:
        return value
    result = list(tree)
    result[path[0]] = replace(tree[path[0]], path[1:], value)
    return result


def evaluate(tree, x):
    op = tree[0]
    if op == "v":
        return x[:, tree[1]]
    if op == "c":
        return np.full(len(x), tree[1], dtype=float)
    children = [evaluate(t, x) for t in tree[1:]]
    a, b = children[:2]
    if op == "add":
        result = a + b
    elif op == "sub":
        result = a - b
    elif op == "mul":
        result = a * b
    elif op == "div":
        result = a / np.where(np.abs(b) >= 1, b, 1)
    elif op == "min":
        result = np.minimum(a, b)
    elif op == "max":
        result = np.maximum(a, b)
    elif op == "if":
        result = np.where(a > 0, b, children[2])
    else:
        raise ValueError("Unknown symbolic score operation")
    return np.clip(result, -200, 200)


def native_prediction(tree, x):
    return np.floor(np.clip(evaluate(tree, x), 0, 100) * 2 + 0.5) / 2


class FormulaSearch:
    def __init__(self, max_depth, penalty, generations=80, population=256, seed=20261105):
        self.max_depth, self.penalty = max_depth, penalty
        self.generations, self.population, self.seed = generations, population, seed

    def transform(self, raw):
        raw = np.asarray(raw, dtype=float)
        if raw.ndim != 2 or raw.shape[1] != len(self.median_) or np.isinf(raw).any():
            raise ValueError("Matched symbolic numeric inputs with explicit NaN missingness required")
        finite = np.isfinite(raw)
        values = np.clip(np.where(finite, raw, self.median_), self.lower_, self.upper_)
        missing = (~finite).astype(float)
        values[:, ~self.known_] = 0
        missing[:, ~self.known_] = 0
        return np.column_stack((values, missing))

    def fit(self, raw, scores, names=None, snapshot=None, key=None):
        raw, scores = np.asarray(raw, dtype=float), np.asarray(scores, dtype=float)
        if (
            raw.ndim != 2
            or not len(raw)
            or raw.shape[1] < 1
            or np.isinf(raw).any()
            or scores.shape != (len(raw),)
            or not np.isfinite(scores).all()
            or ((scores < 0) | (scores > 100)).any()
            or self.generations < 1
            or self.population < 16
            or self.max_depth < 1
            or self.penalty < 0
        ):
            raise ValueError("Known native score labels, fit-only numeric inputs and positive search capacity required")
        self.known_ = np.isfinite(raw).any(axis=0)
        self.median_, self.lower_, self.upper_ = (np.zeros(raw.shape[1]) for _ in range(3))
        for j in np.flatnonzero(self.known_):
            values = raw[np.isfinite(raw[:, j]), j]
            self.median_[j] = np.median(values)
            self.lower_[j] = min(0, np.quantile(values, 0.01))
            self.upper_[j] = max(0, np.quantile(values, 0.99))
        x = self.transform(raw)
        identity = hashlib.sha256(
            raw.tobytes()
            + scores.tobytes()
            + tree_key([self.max_depth, self.penalty, self.population, self.seed, names]).encode()
        ).hexdigest()
        if snapshot is not None and not key:
            raise ValueError("Resumable symbolic search requires a study fingerprint")
        rng = np.random.default_rng(self.seed)

        def terminal():
            return ["v", int(rng.integers(x.shape[1]))] if rng.random() < 0.7 else ["c", float(rng.choice(CONSTANTS))]

        def random_tree(remaining):
            if remaining == 0 or rng.random() < 0.3:
                return terminal()
            op = str(rng.choice(OPERATORS))
            return [op, *[random_tree(remaining - 1) for _ in range(3 if op == "if" else 2)]]

        cache, history, done = {}, [], 0
        if snapshot is not None and Path(snapshot).exists():
            saved = json.loads(Path(snapshot).read_text())
            if saved["key"] != key or saved["fitIdentity"] != identity or saved["done"] > self.generations:
                raise ValueError("Symbolic snapshot source/configuration/capacity differs")
            population, cache, history, done = (
                saved["population"],
                saved["fitnessCache"],
                saved["history"],
                saved["done"],
            )
            rng.bit_generator.state = saved["randomState"]
            self.tree_ = saved["bestTree"]
        else:
            population = [["c", float(c)] for c in CONSTANTS]
            if names is not None:
                if len(names) != raw.shape[1]:
                    raise ValueError("Symbolic feature names differ")
                for j, name in enumerate(names):
                    if any(v in name for v in ("score", "mode")) and "mass" not in name:
                        population.append(["v", j])
                    if "aa" in name and "rate" not in name:
                        population.append(["add", ["c", 35.0], ["v", j]])
            population = population[: self.population]
            while len(population) < self.population:
                tree = random_tree(int(rng.integers(1, self.max_depth + 1)))
                if len(node_paths(tree)) <= 63:
                    population.append(tree)

        def fitness(tree):
            k = tree_key(tree)
            if k not in cache:
                prediction = native_prediction(tree, x)
                hit = float((np.abs(scores - prediction) <= 7).mean())
                mae = float(np.abs(scores - prediction).mean())
                size = len(node_paths(tree))
                cache[k] = [hit - self.penalty * size, -mae, -size, hit]
            return (*cache[k][:3], k)

        def choose():
            return max((population[int(rng.integers(len(population)))] for _ in range(4)), key=fitness)

        for generation in range(done, self.generations):
            ranked = sorted(population, key=fitness, reverse=True)
            self.tree_ = ranked[0]
            history.append(cache[tree_key(self.tree_)])
            next_population = ranked[:8]
            while len(next_population) < self.population:
                first = choose()
                paths = node_paths(first)
                path = paths[int(rng.integers(len(paths)))]
                if rng.random() < 0.6:
                    second = choose()
                    other_paths = node_paths(second)
                    value = subtree(second, other_paths[int(rng.integers(len(other_paths)))])
                else:
                    selected = subtree(first, path)
                    if selected[0] == "c" and rng.random() < 0.5:
                        value = [
                            "c",
                            float(np.clip(np.floor((selected[1] + rng.normal(0, 3)) * 2 + 0.5) / 2, -100, 100)),
                        ]
                    else:
                        value = random_tree(int(rng.integers(0, min(2, self.max_depth) + 1)))
                child = replace(first, path, value)
                if depth(child) <= self.max_depth and len(node_paths(child)) <= 63:
                    next_population.append(child)
                else:
                    next_population.append(terminal())
            population = next_population
            if snapshot is not None and ((generation + 1) % 10 == 0 or generation + 1 == self.generations):
                saved = dict(
                    key=key,
                    fitIdentity=identity,
                    done=generation + 1,
                    population=population,
                    fitnessCache=cache,
                    history=history,
                    randomState=rng.bit_generator.state,
                    bestTree=self.tree_,
                )
                temporary = Path(snapshot).with_suffix(".tmp.json")
                temporary.write_text(json.dumps(saved, separators=(",", ":"), allow_nan=False))
                temporary.replace(snapshot)
            if (generation + 1) % 20 == 0:
                print(
                    f"SYMBOLIC_GENERATION {generation + 1}/{self.generations} trainingOnlyWithin7{history[-1][3]:.6f} uniqueFormulas{len(cache)}",
                    flush=True,
                )
        self.statistics_ = dict(
            fitCases=len(raw),
            numericFeatures=raw.shape[1],
            generations=self.generations,
            population=self.population,
            uniqueFormulasEvaluated=len(cache),
            maxDepth=self.max_depth,
            penalty=self.penalty,
            bestTree=self.tree_,
            bestNodeCount=len(node_paths(self.tree_)),
            trainingOnlyFitness=history[-1],
            trainingOnlyHistory=history,
            fitIdentity=identity,
        )
        return self

    def predict(self, raw):
        return native_prediction(self.tree_, self.transform(raw))
