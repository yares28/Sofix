"""Testing only: retain the frozen predictor except for confident high-score cases."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_small_regimes as small
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def replace_high(old, high, confidence, threshold):
    if not np.isfinite(confidence).all() or (confidence < 0).any() or (confidence > 1).any():
        raise ValueError("Invalid high-score confidence")
    changed = (confidence > threshold) & (high > old + 7)
    return np.where(changed, high, old), changed


def load_parts(cache, stem, label, phase, key):
    with np.load(cache / f"{stem}_{label}_{phase}.npz") as stored:
        if str(stored["key"]) != key:
            raise ValueError("Small-model component identity differs")
        return stored["parts"], stored["gates"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "component-report", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    source = json.loads(args.cases.read_text())
    component = json.loads(args.component_report.read_text())
    if component["sourceKey"] != source["key"]:
        raise ValueError("Small-model source differs")
    key = hashlib.sha256(
        (source["key"] + component["implementationKey"]).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no live changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "componentKey": component["implementationKey"],
        "evidenceLimit": "Retrospective repeatedly reused outcomes; not fresh blind evidence",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y = np.array([r["score"] for r in rows])
        pos = np.array([r["pos"] for r in rows])
        split = small.split_masks(rows)
        valid, select, test = split["valid"], split["select"], split["test"]
        earlier, baseline = small.controls(source, rows, cohort, split, args.cache, args.out.parent)
        old_select = earlier[select[valid]]
        candidates = [{"kind": "control", "selection": measure(y[select], old_select)}]
        for group in ("form", "chances", "usage"):
            for cutoff in (50, 60):
                label = f"{cohort}_{group}_{cutoff}"
                parts, gates = load_parts(
                    args.cache, args.component_report.stem, label, "selection", component["implementationKey"]
                )
                bank = small.error_bank(y[valid], parts, pos[valid], split["bank"][valid], cutoff)
                for spread in (0.75, 1, 1.25):
                    _, high, fallback = small.conditional_masses(
                        parts[select[valid]], pos[select], bank, cutoff, spread
                    )
                    high_prediction = window_centres(high, small.CENTRES)
                    high_hit_probability = high.max(axis=1)
                    for j, gate in enumerate(small.GATES):
                        confidence = gates[select[valid], j] * high_hit_probability
                        for threshold in np.arange(0.05, 0.45001, 0.025):
                            prediction, changed = replace_high(
                                old_select, high_prediction, confidence, float(threshold)
                            )
                            candidates.append(
                                {
                                    "kind": "rescue",
                                    "group": group,
                                    "cutoff": cutoff,
                                    "spread": spread,
                                    "gate": gate,
                                    "threshold": float(threshold),
                                    "pooledFallbackCases": fallback,
                                    "changedEarlier": int(changed.sum()),
                                    "selection": measure(y[select], prediction),
                                }
                            )
                print(f"SELECTED {cohort} {group} {cutoff}", flush=True)
        rank = lambda s: (s["selection"]["within7"], -s["selection"]["mae"])
        winner = max(candidates, key=rank)
        candidate = max(candidates[1:], key=rank)
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidate": candidate, "candidates": candidates}, indent=2)
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        group, cutoff = candidate["group"], candidate["cutoff"]
        label = f"{cohort}_{group}_{cutoff}"
        earlier_parts, _ = load_parts(
            args.cache, args.component_report.stem, label, "selection", component["implementationKey"]
        )
        parts, gates = load_parts(
            args.cache, args.component_report.stem, label, "later", component["implementationKey"]
        )
        bank = small.error_bank(y[valid], earlier_parts, pos[valid], split["refit"][valid], cutoff)
        _, high, fallback = small.conditional_masses(parts, pos[test], bank, cutoff, candidate["spread"])
        high_prediction = window_centres(high, small.CENTRES)
        confidence = gates[:, small.GATES.index(candidate["gate"])] * high.max(axis=1)
        alternate, changed = replace_high(baseline, high_prediction, confidence, candidate["threshold"])
        prediction = baseline.copy() if winner["kind"] == "control" else alternate
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        old_hit = np.abs(y[test] - baseline) <= 7
        new_hit = np.abs(y[test] - alternate) <= 7
        result = {
            "winner": winner,
            "candidate": candidate,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "candidateLater": measure(y[test], alternate),
            "control": measure(y[test], baseline),
            "changedLater": int(changed.sum()),
            "gainedCorrect": int((new_hit & ~old_hit).sum()),
            "lostCorrect": int((old_hit & ~new_hit).sum()),
            "gain95": paired_interval(y[test], alternate, baseline, weeks),
            "weekly95": bootstrap(y[test], alternate, weeks),
            "highScoreGames": measure(y[test][y[test] >= 60], alternate[y[test] >= 60]),
            "pooledFallbackCases": fallback,
            "positions": {
                p: measure(y[test][pos[test] == p], alternate[pos[test] == p])
                for p in POSITIONS
                if (pos[test] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[test],
            prediction=prediction,
            alternate=alternate,
            control=baseline,
            changed=changed,
            confidence=confidence,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
