"""Separate source-only quote linkage checks, including removal of all unavailable players."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path

import numpy as np

from app.research import score_market_identity as primary


def tokens(value):
    ascii_text = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return re.findall("[a-z]+", ascii_text.lower())


def date(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def lock_for(value):
    now = date(value)
    return max(
        datetime.combine(now.date() - timedelta(days=i), datetime.min.time(), UTC).replace(hour=14)
        for i in range(8)
        if (now.date() - timedelta(days=i)).weekday() in (1, 4)
        and datetime.combine(now.date() - timedelta(days=i), datetime.min.time(), UTC).replace(hour=14) <= now
    )


def matches(printed, alias):
    wanted, available = tokens(printed), tokens(alias)
    if len(wanted) == 1:
        return wanted == available
    full = Counter(w for w in wanted if len(w) > 1)
    remaining = Counter(available) - full
    if not full or not full <= Counter(available):
        return False
    initials = Counter(w for w in wanted if len(w) == 1)
    return initials <= Counter(w[0] for w in remaining.elements())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, default=Path("reports/experiments/laliga_score_market_identity.json"))
    args = parser.parse_args()
    folder = Path("data/raw/score-foundation")
    report_path = args.report
    report = json.loads(report_path.read_text())
    key = hashlib.sha256(
        Path(primary.__file__).read_bytes() + json.dumps(report["sourceHashes"], sort_keys=True).encode()
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Source-linkage implementation key differs")
    for path, sha in report["sourceHashes"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != sha:
            raise ValueError("Source bytes changed")
    games = [
        json.loads(v)
        for v in Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
    ]
    by_id = {g["id"]: g for g in games}
    names = {p: [] for g in games for p in g["players"]}
    aliases = json.loads((folder / "player_names.json").read_text())
    ids = json.loads((folder / "physical-traits/identities.json").read_text())
    with (folder / "physical-traits/players_fifa23.csv").open(encoding="utf-8-sig", newline="") as handle:
        fifa = {int(r["ID"]): [r["Name"], r["FullName"]] for r in csv.DictReader(handle)}
    for p in names:
        names[p] = [p.replace("-", " "), *aliases.get(p, []), *fifa.get(ids.get(p, {}).get("id"), [])]
    poisoned = {}
    for r in report["records"]:
        q = r["quote"]
        possible = sorted(p for p, values in names.items() if any(matches(q["player"], a) for a in values))
        if possible != r["nameCandidates"]:
            raise ValueError("Independent identity possibilities differ")
        # The club translation is a reviewed fixed dictionary, never outcome-dependent.
        club = primary.club_slug(q["club"])
        fixtures = sorted(
            g["id"]
            for g in games
            if club in [g["home"]["slug"], g["away"]["slug"]]
            and 0 <= (date(g["date"]) - date(q["listedTimeUTC"])).total_seconds() <= 300
        )
        if fixtures != r["fixtureCandidates"]:
            raise ValueError("Independent fixture match differs")
        cutoff = lock_for(by_id[fixtures[0]]["date"]) if len(fixtures) == 1 else lock_for(q["listedTimeUTC"])
        if len(fixtures) == 1:
            eligible = date(q["provisionalAvailableUTC"]) < cutoff
            if eligible != r["metadataBeforeNativeLock"]:
                raise ValueError("Independent native lock differs")
            if len(possible) > 1:
                last = {}
                for g in sorted(games, key=lambda g: (g["date"], g["id"])):
                    elapsed = (cutoff - date(g["date"])).total_seconds()
                    if not 48 * 3600 < elapsed <= 365 * 86400:
                        continue
                    for p in possible:
                        if g["players"].get(p, {}).get("played") is True:
                            last[p] = g["players"][p]["team"]
                possible = sorted(p for p in possible if last.get(p) == club)
            if possible != r["pastClubCandidates"] or r["player"] != (possible[0] if len(possible) == 1 else None):
                raise ValueError("Independent past club disambiguation differs")
        if cutoff not in poisoned:
            poisoned[cutoff] = [
                dict(
                    id=g["id"],
                    date=g["date"],
                    home=g["home"],
                    away=g["away"],
                    players={}
                    if date(g["date"]) + timedelta(hours=48) >= cutoff
                    else {p: {"played": v.get("played"), "team": v.get("team")} for p, v in g["players"].items()},
                )
                for g in games
            ]
        actual = primary.link(q, poisoned[cutoff], names)
        if any(actual[k] != r[k] for k in actual):
            raise ValueError("Unavailable player records or stat sheets affected source linkage")
    rows = json.loads((folder / "cases.json").read_text())["rows"]
    for cohort, file in [
        ("start", "laliga_score_team_share_predictions_start.npz"),
        ("bench", "laliga_score_mixture_shrunk_predictions_bench.npz"),
    ]:
        selected = [r for r in rows if r["cohort"] == cohort and r["date"] >= "2026-01-01"]
        z = np.load(folder / file)
        np.testing.assert_array_equal(z["y"], [r["score"] for r in selected])
        lookup = {(r["game"], r["player"]): i for i, r in enumerate(selected)}
        covered = {
            lookup[r["game"], r["player"]]
            for r in report["records"]
            if r["status"] == "linked" and r["metadataBeforeNativeLock"] and (r["game"], r["player"]) in lookup
        }
        correct = np.abs(z["y"] - z["prediction"]) <= 7
        bound = report["ownCurrentQuoteOnlyBounds"][cohort]
        unresolved = sum(
            r["status"] != "linked" and r["quote"]["listedTimeUTC"] >= "2026-01-01" and r["quote"]["metadataBeforeLock"]
            for r in report["records"]
        )
        misses = sum(not correct[i] for i in covered)
        maximum = min(len(selected), int(correct.sum()) + misses + unresolved)
        if (
            bound["mappedCoveredMisses"] != misses
            or bound["unresolvedPossibleQuotes"] != unresolved
            or bound["optimisticCorrect"] != maximum
        ):
            raise ValueError("Independent hindsight upper bound differs")
    receipt = dict(
        status="COMPLETE source-only linkage and pilot bound audit; no forecast fitted",
        quotes=len(report["records"]),
        independentNames=True,
        independentFixtures=True,
        independentPastClub=True,
        independentNativeLock=True,
        allUnavailablePlayerDataRemovedInvariant=True,
        independentFullDenominatorCeiling=True,
        implementationKey=report["implementationKey"],
        modelEligibleQuotes=0,
    )
    report_path.with_suffix(".integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("MARKET_IDENTITY_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
