"""Testing-only passing-source qualification; preserve all parent artifacts."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np

from app.research.score_pass_geometry_corrected import recent_features

PASS_FIELDS = (
    "chance_key_passes90",
    "usage_passes90",
    "usage_completed90",
    "usage_progressive90",
    "usage_box_passes90",
    "usage_crosses90",
    "usage_through90",
    "usage_pass_x",
    "usage_pass_edge",
    "usage_pass_x_sd",
    "usage_attacking_fraction",
    "usage_central_fraction",
)


def qualify(record, native_accurate, side_observed):
    metadata = record["geometrySource"]
    count = metadata.get("passCount")
    reasons = []
    if not metadata.get("passStreamKnown") or count is None:
        reasons.append("actor_pass_stream_unavailable")
    if not side_observed:
        reasons.append("side_pass_stream_unobserved")
    if count is not None and native_accurate is not None and count < native_accurate:
        reasons.append("native_completed_exceeds_source_attempts")
    values = dict(record["values"])
    if reasons:
        values.update(dict.fromkeys(PASS_FIELDS))
    return {
        **record,
        "values": values,
        "passSourceQuality": dict(
            known=not reasons,
            reasons=reasons,
            sourceAttempts=count,
            nativeAccurate=native_accurate,
            sideObserved=side_observed,
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_pass_source_qualified.json"))
    args = parser.parse_args()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    parent_bytes = (args.cache / "pass_geometry_corrected_observations.json.gz").read_bytes()
    pressure_bytes = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    if hashlib.sha256(parent_bytes).hexdigest() != "c9f7aa7dcb3c47cdcaed6da79defd0703be920ced00f1d764e0ed3965d0d367b":
        raise ValueError("Audited corrected parent changed")
    if hashlib.sha256(pressure_bytes).hexdigest() != "daba17833020e8212346bb79f8b0918b69ab5e2a36ad60cc44d3fb1a4f7d064a":
        raise ValueError("Pinned spatial source changed")
    parent = json.loads(gzip.decompress(parent_bytes))
    sides = {
        (r["game"], r["club"]): bool(r["passes"]["known"] and r["passes"]["passCount"] > 0)
        for r in json.loads(gzip.decompress(pressure_bytes))["observations"]
    }
    records, reasons = [], Counter()
    for old in parent["records"]:
        person = games[old["game"]]["players"][old["player"]]
        if person.get("ver") != 7 or not isinstance(person.get("stats"), dict):
            raise ValueError("Native completed-pass qualification unavailable")
        count = person["stats"].get("accurate_pass", [0, 0])[0]
        new = qualify(old, count, sides.get((old["game"], old["club"]), False))
        reasons.update(new["passSourceQuality"]["reasons"])
        records.append(new)
    source = json.loads((args.cache / "cases.json").read_text())
    key = hashlib.sha256(
        parent_bytes
        + pressure_bytes
        + raw
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    archive = args.cache / "pass_source_qualified_observations.json.gz"
    archive.write_bytes(
        gzip.compress(
            json.dumps(
                dict(key=key, records=records, receipt=parent["receipt"]), separators=(",", ":"), allow_nan=False
            ).encode(),
            mtime=0,
        )
    )
    x, names, metadata = recent_features(source["rows"], records, games)
    selected = np.array([any(field + "_" in name for field in PASS_FIELDS) for name in names])
    with np.load(args.cache / "pass_geometry_corrected_features.npz") as f:
        if (
            str(f["key"]) != "e259f15c5210ab457cbf5b0e9331d0f5ce30b2d3a9377f50a2d874846a726b3e"
            or names != f["names"].tolist()
        ):
            raise ValueError("Corrected parent feature identity changed")
        parent_x = f["x"]
    if x.shape != (38850, 166) or selected.sum() != 72 or len(records) != 34871:
        raise ValueError("Qualified source population/schema changed")
    np.testing.assert_array_equal(x[:, ~selected], parent_x[:, ~selected])
    changed = ~np.isclose(x, parent_x, rtol=0, atol=1e-10, equal_nan=True)
    feature_key = hashlib.sha256(
        (key + source["key"] + hashlib.sha256(archive.read_bytes()).hexdigest()).encode()
    ).hexdigest()
    feature_path = args.cache / "pass_source_qualified_features.npz"
    np.savez_compressed(feature_path, key=feature_key, x=x, names=names, qualified=selected, source_key=source["key"])
    output = dict(
        scope="Research source qualification only; no app change or accuracy claim",
        implementationKey=key,
        featureKey=feature_key,
        sourceKey=source["key"],
        observationsSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        featuresSha256=hashlib.sha256(feature_path.read_bytes()).hexdigest(),
        metadata=metadata,
        observations=len(records),
        unknownObservations=sum(not r["passSourceQuality"]["known"] for r in records),
        unknownReasons=dict(reasons),
        qualifiedColumns=int(selected.sum()),
        unchangedColumns=int((~selected).sum()),
        changedColumns=int(changed.any(axis=0).sum()),
        changedCells=int(changed.sum()),
        changedRows=int(changed.any(axis=1).sum()),
        status="Independent qualification and lag audit REQUIRED before spatial feature/model use",
    )
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print("PASS_SOURCE_QUALIFIED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
