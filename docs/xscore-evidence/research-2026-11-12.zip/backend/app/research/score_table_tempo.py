"""Test table context on team shots and goals with more complete past seasons."""

import csv
import hashlib
import json
from collections import defaultdict, deque
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS
from app.research.score_card_cycle import PHASES
from app.research.score_match_context import read_calendar
from app.research.score_search import cutoff_for, moment
from app.research.score_table_pressure import table_features, update
from app.research.score_team_routine_shift import DELAY

STEM = "laliga_score_table_tempo"
SEASONS = ("1920", "2021", "2122", "2223", "2324", "2425", "2526")


def read_all(directory, native):
    output, hashes = [], {}
    for season in SEASONS:
        path = directory / f"SP1_{season}.csv"
        hashes[season] = hashlib.sha256(path.read_bytes()).hexdigest()
        with path.open(encoding="utf-8-sig", newline="") as stream:
            rows = [
                r
                for r in csv.DictReader(stream)
                if r.get("Date") and r.get("FTHG") not in (None, "") and r.get("FTAG") not in (None, "")
            ]
        assert len(rows) == 380
        canonical = read_calendar(path) if season >= "2324" else [None] * len(rows)
        for r, normalized in zip(rows, canonical, strict=True):
            if r.get("Time"):
                at = (
                    datetime.strptime(r["Date"] + " " + r["Time"], "%d/%m/%Y %H:%M")
                    .replace(tzinfo=ZoneInfo("Europe/London"))
                    .isoformat()
                )
            else:
                at = (
                    datetime.strptime(r["Date"], "%d/%m/%Y")
                    .replace(hour=23, minute=59, tzinfo=ZoneInfo("Europe/London"))
                    .isoformat()
                )
            fixture = None
            if normalized:
                fixture = native.get((normalized["date"][:10], normalized["home"]["slug"], normalized["away"]["slug"]))
            if fixture:
                at = fixture["date"]
                assert (int(r["FTHG"]), int(r["FTAG"])) == (fixture["homeGoals"], fixture["awayGoals"])
            labels = [int(r[n]) if r.get(n) not in (None, "") else None for n in ("FTHG", "FTAG", "HST", "AST")]
            output.append((at, season, r["HomeTeam"], r["AwayTeam"], labels, bool(fixture)))
    return output, hashes


def make_examples(fixtures):
    participants = defaultdict(set)
    for _, season, home, away, _, _ in fixtures:
        participants[season].update((home, away))
    assert all(len(v) == 20 for v in participants.values())
    tables = {s: {c: np.zeros(4) for c in v} for s, v in participants.items()}
    history = defaultdict(lambda: deque(maxlen=8))
    ordered = sorted(fixtures, key=lambda game: moment(game[0]))
    available = [moment(r[0]) + DELAY for r in ordered]
    output = []
    cursor = 0
    for g in ordered:
        date, season, home, away, labels, observed = g
        lock = cutoff_for(date)
        while cursor < len(ordered) and available[cursor] < lock:
            _, s, h, a, (hg, ag, home_shots, away_shots), _ = ordered[cursor]
            update(tables[s], h, a, hg, ag)
            history[s, h].append((hg, ag, home_shots, away_shots))
            history[s, a].append((ag, hg, away_shots, home_shots))
            cursor += 1
        for side, own, other in ((0, home, away), (1, away, home)):
            team, pressure = table_features(tables[season], own)
            rival, other_pressure = table_features(tables[season], other)
            rolling = []
            for key in ((season, own), (season, other)):
                prior = list(history[key])
                for j, default in enumerate((1.3, 1.3, 4.2, 4.2)):
                    values = [r[j] for r in prior if r[j] is not None]
                    rolling.append(np.mean(values) if values else default)
            x = np.r_[side == 0, team, rival, rolling]
            output.append((date, observed, [labels[side], labels[side + 2]], x, np.r_[pressure, other_pressure]))
    return output


def model(x, y, fit, check):
    avg, scale = x[fit].mean(axis=0), x[fit].std(axis=0)
    scale[scale < 1e-8] = 1
    train = (x[fit] - avg) / scale
    test = np.clip((x[check] - avg) / scale, -5, 5)
    centre = y[fit].mean()
    weights = np.linalg.solve(train.T @ train + 150 * np.eye(train.shape[1]), train.T @ (y[fit] - centre))
    return np.maximum(centre + test @ weights, 0)


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    source = {
        (g["date"][:10], g["home"]["slug"], g["away"]["slug"]): g
        for g in map(json.loads, raw.splitlines())
        if g["date"] < "2026-01-01"
    }
    data, hashes = read_all(NATIVE.parent / "football-data-co-uk", source)
    # Retain only dates needed for prior fitting or the earlier evaluation.
    rows = make_examples([r for r in data if r[0][:10] < "2026-01-01"])
    assert sum(r[1] for r in rows) == 2 * len(source)
    dates = np.array([r[0] for r in rows])
    date = np.array([d[:10] for d in dates])
    native = np.array([r[1] for r in rows])
    x = np.array([r[3] for r in rows])
    candidate = np.column_stack((x, [r[4] for r in rows]))
    labels = np.array([r[2] for r in rows], dtype=float)
    locks = np.array([cutoff_for(d) for d in dates])
    ready = np.array([moment(d) + DELAY for d in dates])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        window = native & (date >= begin) & (date < end)
        training = ready < locks[window].min()
        result = {}
        for i, name in enumerate(("goals", "shotsOnTarget")):
            y = labels[:, i]
            check = window & np.isfinite(y)
            fit = training & np.isfinite(y)
            forecasts = [model(values, y, fit, check) for values in (x, candidate)]
            result[name] = dict(
                sides=int(check.sum()),
                train=int(fit.sum()),
                mae=[float(np.mean(abs(y[check] - p))) for p in forecasts],
            )
        periods[phase] = result
    gains = {}
    for key in ("goals", "shotsOnTarget"):
        eligible = [v[key] for v in periods.values()]
        gains[key] = sum(r["sides"] * (r["mae"][0] - r["mae"][1]) for r in eligible) / sum(r["sides"] for r in eligible)
    stable = sum(all(r["mae"][1] <= r["mae"][0] for r in v.values()) for v in periods.values())
    report = dict(
        nativeSHA=NATIVE_SHA,
        csvSHA=hashes,
        periods=periods,
        meanErrorGain=gains,
        phasesWithoutLoss=stable,
        passEarlier=min(gains.values()) > 0 and stable >= 2,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("nativeSHA", "csvSHA")}, indent=2))


if __name__ == "__main__":
    main()
