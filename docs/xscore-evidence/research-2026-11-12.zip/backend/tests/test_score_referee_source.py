from datetime import UTC, datetime

import pytest

from app.research import score_referee_source as source


def test_published_local_time_uses_named_zone_in_both_seasons():
    assert source.publication('<div class="news__header__date mt-4">Vie, 23/01/2026 - 13:00</div>') == datetime(
        2026, 1, 23, 12, tzinfo=UTC
    )
    assert source.publication('<div class="news__header__date mt-4">Jue, 14/08/2025 - 10:22</div>') == datetime(
        2025, 8, 14, 8, 22, tzinfo=UTC
    )
    with pytest.raises(ValueError, match="publication"):
        source.publication("<div>23/01/2026 - 13:00</div>")


def test_match_referee_is_not_fourth_referee_or_var():
    text = (
        "Competición: Campeonato Nacional de Liga de Primera División - Primera División Jornada - 21\n"
        "24-01-2026 Rayo Vallecano de Madrid Club Atlético Osasuna 14:00\n"
        "Árbitro:Miguel Sesma 4º Árbitro:Sergio Escriche\n"
        "A. Asistente 1: Ion Rodríguez VAR: Juan Luis Pulido\n"
    )
    rows = source.assignment_rows(text)
    assert rows == [
        dict(
            localDate="2026-01-24",
            time="14:00",
            home="Rayo Vallecano de Madrid",
            away="Club Atlético Osasuna",
            referee="Miguel Sesma",
        )
    ]


def test_wrong_competition_and_unrecognized_clubs_are_not_silently_linked():
    with pytest.raises(ValueError, match="competition"):
        source.assignment_rows("Primera Federación\n24-01-2026 Club A Club B 14:00\nÁrbitro:X 4º Árbitro:Y")
    with pytest.raises(ValueError, match="club"):
        source.assignment_rows(
            "Competición: Campeonato Nacional de Liga de Primera División - Primera División\n24-01-2026 Club A Club B 14:00\nÁrbitro:X 4º Árbitro:Y"
        )


def test_new_pdf_version_after_lock_cannot_use_old_article_date():
    lock = datetime(2025, 1, 31, 14, tzinfo=UTC)
    published = datetime(2025, 1, 30, 10, 20, tzinfo=UTC)
    modified = datetime(2025, 1, 31, 19, 8, 59, tzinfo=UTC)
    assert source.availability(published, published, modified) > lock
    with pytest.raises(ValueError, match="timestamp"):
        source.availability(published, None, modified)
