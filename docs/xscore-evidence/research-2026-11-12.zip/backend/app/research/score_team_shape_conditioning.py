"""Testing only: separate team structure from formation-conditioned personal AA history."""

import numpy as np

from app.research import score_team_shape_history as shape


def feature_groups(names):
    if list(names) != list(shape.NAMES):
        raise ValueError("Team-shape feature schema differs")
    aa = np.array([n.startswith("shape_aa_") for n in names])
    return {"structural": ~aa, "aa": aa, "all": np.ones(len(names), dtype=bool)}
