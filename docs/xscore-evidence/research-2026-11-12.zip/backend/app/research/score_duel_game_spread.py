"""Test whether pre-lock information predicts unusually good or poor duel games."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_component_replacement import EVENT_KEY, native_values
from app.research.score_opposition_strength import MATCHUP_KEY, PHASES
from app.research.score_physical_duel_signal import fitted
from app.research.score_search import POSITIONS, cutoff_for, moment
from app.research.score_shared_error_recovery import NATIVE_SHA


def past_surprises(rows, sides, counts, p, availability, locks):
    total = counts.sum(axis=1)
    error = counts[:, 0] - total * p
    variance = total * p * (1 - p)
    details = np.column_stack((error, total, error**2 - variance, variance * (total - 1)))
    fixtures = defaultdict(list)
    for i in np.flatnonzero(np.isfinite(total) & (total > 0)):
        fixtures[availability[i], rows[i]["game"], sides[i][1], rows[i]["pos"]].append(i)
    pending = iter(sorted(fixtures.items()))
    event = next(pending, None)
    player = defaultdict(lambda: deque(maxlen=6))
    allowed = defaultdict(lambda: deque(maxlen=8))
    values = np.zeros((len(rows), 6))
    for i in np.argsort(locks, kind="stable"):
        while event is not None and event[0][0] < locks[i]:
            (_, _, opponent, pos), ids = event
            allowed[opponent, pos].append(details[ids].mean(axis=0))
            for j in ids:
                player[rows[j]["player"], pos].append(details[j])
            event = next(pending, None)
        pos = rows[i]["pos"]
        groups = player[rows[i]["player"], pos], allowed[sides[i][1], pos]
        for k, group in enumerate(groups):
            if group:
                miss, trials, excess, denominator = np.sum(group, axis=0)
                values[i, k * 3 : (k + 1) * 3] = miss / (trials + 20), excess / (denominator + 30), len(group)
    return values


def log_mass(w, n, p, rho):
    from scipy.special import betaln, gammaln

    valid = (w >= 0) & (w <= n)
    w = np.clip(w, 0, n)
    choose = gammaln(n + 1) - gammaln(w + 1) - gammaln(n - w + 1)
    if rho is None:
        return np.where(valid, choose + w * np.log(p) + (n - w) * np.log1p(-p), -np.inf)
    concentration = (1 - rho) / rho
    a, b = p * concentration, (1 - p) * concentration
    return np.where(valid, choose + betaln(w + a, n - w + b) - betaln(a, b), -np.inf)


def dispersion(x_train, x_test, w, n, p):
    from scipy.optimize import minimize
    from scipy.special import expit

    def design(x, centre, scale):
        standardized = np.clip((x - centre) / scale, -5, 5)
        return np.column_stack((np.ones(len(x)), np.where(np.isfinite(standardized), standardized, 0)))

    centre = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in x_train.T])
    scale = np.where(np.isfinite(x_train), x_train, centre).std(axis=0)
    scale = np.where(scale > 1e-8, scale, 1)
    train, target = design(x_train, centre, scale), design(x_test, centre, scale)

    def transform(logit):
        return 0.0001 + 0.5999 * expit(logit)

    def objective(coefficients):
        rho = transform(train @ coefficients)
        return -log_mass(w, n, p, rho).sum() + 30 * np.dot(coefficients[1:], coefficients[1:])

    initial = np.zeros(train.shape[1])
    initial[0] = -3
    bounds = [(-10, 5)] + [(-4, 4)] * (train.shape[1] - 1)
    opt = minimize(objective, initial, method="L-BFGS-B", bounds=bounds, options={"ftol": 1e-11, "maxiter": 300})
    if not opt.success or not np.isfinite(opt.fun):
        raise ValueError(f"Spread fit did not converge: {opt.message}")
    return transform(target @ opt.x)


def observation_losses(w, n, p, rho, historical_p):
    axis = np.arange(int(n.max()) + 1)
    rv = None if rho is None else rho[:, None]
    mass = np.exp(log_mass(axis, n[:, None], p[:, None], rv))
    np.testing.assert_allclose(mass.sum(axis=1), 1, rtol=0, atol=1e-9)
    reference = (historical_p * n)[:, None]
    # At fixed volume, two extra or missing wins move a defender's duel score seven points.
    low, high = axis <= reference - 2, axis >= reference + 2
    actual = w.astype(int)
    tail = np.column_stack((np.sum(mass * low, axis=1), np.sum(mass * high, axis=1)))
    loss = np.column_stack(
        (
            -log_mass(w, n, p, rho),
            (tail[:, 0] - low[np.arange(len(w)), actual]) ** 2,
            (tail[:, 1] - high[np.arange(len(w)), actual]) ** 2,
        )
    )
    return loss, tail


def intervals(gains, weeks):
    groups = sorted(set(weeks))
    sums = np.array([gains[weeks == key].sum(axis=0) for key in groups])
    counts = np.array([(weeks == key).sum() for key in groups])
    sample = np.random.default_rng(20261112).integers(len(groups), size=(2000, len(groups)))
    return np.quantile(sums[sample].sum(axis=1) / counts[sample].sum(axis=1)[:, None], [0.025, 0.975], axis=0).T


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads((args.cache / "cases.json").read_text())
    with np.load(args.cache / "matchup_features.npz") as f:
        if str(f["key"]) != MATCHUP_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Matchup source differs")
        lookup = f["names"].tolist()
        matchup = f["x"][
            :,
            [
                lookup.index(n)
                for n in (
                    "own_duel_fraction",
                    "expected_duel_fraction",
                    "opponent_duel_fraction",
                    "own_duel_won90",
                    "own_duel_lost90",
                )
            ],
        ]
    with np.load(args.cache / "event_intensity_features.npz") as f:
        if str(f["key"]) != EVENT_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Forecast minutes source differs")
        minutes = f["x"][:, f["names"].tolist().index("event_expected_minutes")]
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Native archive differs")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    names = source["features"]
    report = {"sourceKey": source["key"], "scope": "Earlier duel distribution only. Historical reuse.", "cohorts": {}}
    for cohort in ("start", "bench"):
        # Exclude 2026 from all mechanism inputs as well as from evaluation.
        scope = np.array([r["cohort"] == cohort and r["date"] < "2026-01-01" for r in source["rows"]])
        rows = [r for r, keep in zip(source["rows"], scope, strict=True) if keep]
        position = np.array([r["pos"] for r in rows])
        home, opponent_rate, sides, counts = [], [], [], []
        for row in rows:
            game = games[row["game"]]
            native = game["players"][row["player"]]
            club, h, a = native["team"], game["home"]["slug"], game["away"]["slug"]
            if row["date"] != game["date"] or club not in (h, a):
                raise ValueError("Fixture and side identity differs")
            is_home = club == h
            if bool(row["x"][names.index("home")]) != is_home:
                raise ValueError("Source home flag differs")
            home.append(is_home)
            opponent_rate.append(row["x"][names.index("match_lam_a" if is_home else "match_lam_h")])
            sides.append((club, a if is_home else h))
            counts.append(native_values(row, native)[3:] if row["pos"] != "GK" else [np.nan, np.nan])
        counts = np.array(counts)
        known = counts[position != "GK"]
        if not np.isfinite(known).all() or (known < 0).any() or not np.array_equal(known, np.rint(known)):
            raise ValueError("Outfield duel counts must be known nonnegative integers")
        availability = np.array([(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rows])
        locks = np.array([cutoff_for(r["date"]).timestamp() for r in rows])
        if (availability <= locks).any():
            raise ValueError("A match is available before its own lock")
        own, expected, opp, won90, lost90 = matchup[scope].T
        prior_p = np.clip(np.where(np.isfinite(expected), expected, np.where(np.isfinite(own), own, 0.5)), 0.02, 0.98)
        history = past_surprises(rows, sides, counts, prior_p, availability, locks)
        projected_n = (won90 + lost90) * minutes[scope] / 90
        x = np.column_stack(
            (home, opponent_rate, own, expected, opp, projected_n, history, *[position == p for p in POSITIONS])
        )
        variance_x = np.column_stack((history[:, [1, 2, 4, 5]], opponent_rate, projected_n))
        n, w = counts.sum(axis=1), counts[:, 0]
        dates = np.array([r["date"] for r in rows])
        weeks = np.array([r["week"] for r in rows])
        primary = position == "DEF" if cohort == "start" else position != "GK"
        phases = {}
        all_gains, all_weeks = [], []
        for phase, begin, end in PHASES:
            target = (dates >= begin) & (dates < end)
            fit = (dates < begin) & (availability < locks[target].min())
            fit_duels, test_duels = fit & (n > 0), target & (n > 0)
            prediction_set = fit_duels | target
            p_raw = fitted(x, counts, fit, prediction_set, "logistic")["probability"]
            blanked = np.where(fit[:, None], counts, np.nan)
            np.testing.assert_array_equal(p_raw, fitted(x, blanked, fit, prediction_set, "logistic")["probability"])
            p = np.clip(p_raw, 0.01, 0.99)
            use_fit = fit_duels[fit_duels | target]
            p_fit, p_test = p[use_fit], p[~use_fit]
            fixed = dispersion(variance_x[fit_duels, :0], variance_x[target, :0], w[fit_duels], n[fit_duels], p_fit)
            adaptive = dispersion(variance_x[fit_duels], variance_x[target], w[fit_duels], n[fit_duels], p_fit)
            scored = test_duels[target]
            evaluation = {
                name: observation_losses(
                    w[test_duels],
                    n[test_duels],
                    p_test[scored],
                    None if rho is None else rho[scored],
                    prior_p[test_duels],
                )
                for name, rho in (("independent", None), ("fixed", fixed), ("adaptive", adaptive))
            }
            group = primary[test_duels]
            loss = {name: pair[0] for name, pair in evaluation.items()}
            tail_change = np.abs(evaluation["adaptive"][1] - evaluation["fixed"][1])[group]
            difference = loss["fixed"][group] - loss["adaptive"][group]
            gains = np.column_stack((difference[:, 0], difference[:, 1:].mean(axis=1)))
            all_gains.append(gains)
            all_weeks.append(weeks[test_duels][group])
            phases[phase] = {
                "allCases": int(target.sum()),
                "fitDuelGames": int(fit_duels.sum()),
                "zeroDuelOutfield": int((target & (n == 0)).sum()),
                "unknownKeeper": int((target & np.isnan(n)).sum()),
                "primaryDuelGames": int(group.sum()),
                "primaryLoss": {name: values[group].mean(axis=0).tolist() for name, values in loss.items()},
                "fixedCorrelation": float(fixed[0]),
                "adaptiveCorrelationP10P50P90": np.quantile(adaptive[scored][group], [0.1, 0.5, 0.9]).tolist(),
                "tailProbabilityChangeMedianAndP95": np.quantile(tail_change, [0.5, 0.95]).tolist(),
                "primaryCasesEitherTailMovesAtLeastFivePercentagePoints": int((tail_change.max(axis=1) >= 0.05).sum()),
                "adaptiveGainLogLossAndTailBrier": gains.mean(axis=0).tolist(),
            }
            print(cohort, phase, "adaptive improvement", phases[phase]["adaptiveGainLogLossAndTailBrier"], flush=True)
        interval = intervals(np.concatenate(all_gains), np.concatenate(all_weeks))
        passes = bool(
            np.all(interval[:, 0] > 0) and all(min(p["adaptiveGainLogLossAndTailBrier"]) > 0 for p in phases.values())
        )
        report["cohorts"][cohort] = {"phases": phases, "adaptivePairedGain95": interval.tolist(), "advance": passes}
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_duel_game_spread.json"))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
