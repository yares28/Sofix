"""Paired xScore test of historical recovery and interception context."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research.score_component_replacement import EVENT_KEY
from app.research.score_openplay_aerial_routine import ordinary_quantiles
from app.research.score_openplay_duel_signal import native_archive
from app.research.score_search import POSITIONS
from app.research.score_shared_error_recovery import compare, snapshots
from app.research.score_stats_run import paired_interval


def native_points(row, game):
    p = game["players"][row["player"]]
    if (
        row["date"] != game["date"]
        or p["ver"] != 7
        or not p["played"]
        or p["pos"] != row["pos"]
        or p["started"] != (row["cohort"] == "start")
        or p["mins"] != row["minutes"]
        or any(abs(p[k] - row[k]) > 1e-7 for k in ("score", "aa", "level"))
    ):
        raise ValueError("Native recovery-point label differs")
    return sum(p["stats"].get(k, (0, 0))[1] for k in ("poss_won", "interception_won"))


def load_features(args, source, read):
    audit = read("laliga_score_openplay_regain_features")
    path = args.cache / "openplay-data-v0.1.0" / "regain_workload_features.npz"
    if hashlib.sha256(path.read_bytes()).hexdigest() != audit["featureSha256"]:
        raise ValueError("Source feature fingerprint differs")
    with np.load(path) as f:
        if (
            str(f["sourceKey"]) != source["key"]
            or audit["sourceKey"] != source["key"]
            or len(f["raw"]) != len(source["rows"])
            or len(f["context"]) != len(source["rows"])
            or audit["first2026LockCasesExactWithOutcomesRemoved"] != 310
        ):
            raise ValueError("Source feature audit incomplete")
        raw, context = f["raw"], f["context"]
    with np.load(args.cache / "event_intensity_features.npz") as f:
        if str(f["key"]) != EVENT_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Pre-lock minute source differs")
        minutes = f["x"][:, f["names"].tolist().index("event_expected_minutes")]
    return raw, context, minutes, audit


def component_predictions(x, activity, fit, target):
    from sklearn.ensemble import HistGradientBoostingRegressor

    model = HistGradientBoostingRegressor(
        loss="absolute_error",
        max_leaf_nodes=15,
        min_samples_leaf=60,
        max_iter=80,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261112,
    ).fit(x[fit], activity[fit])
    return model.predict(x[target])


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads((args.cache / "cases.json").read_text())
    games = native_archive(args.games)
    read = lambda name: json.loads((args.out.parent / f"{name}.json").read_text())
    raw, context, minutes, audit = load_features(args, source, read)
    old = tuple(read(f"laliga_score_{key}") for key in ("match_context", "stability", "ordinary"))
    if any(r["sourceKey"] != source["key"] for r in old):
        raise ValueError("Reference probability inputs differ")
    report = {
        "scope": "Test only. Reused historical outcomes.",
        "sourceKey": source["key"],
        "sourceAudit": audit,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        pos = np.array([r["pos"] for r in rows])
        recovery_points = np.array([native_points(r, games[r["game"]]) for r in rows])
        scores, points, levels = (np.array([r[k] for r in rows]) for k in ("score", "aa", "level"))
        controls = np.column_stack(([r["x"] for r in rows], minutes[keep], raw[keep], *[pos == p for p in POSITIONS]))
        matrices = {"raw": controls, "context": np.column_stack((controls, context[keep]))}
        known = (raw[keep, -2:] >= 3).any(axis=1)
        masks = stability.phase_masks(rows)
        references = snapshots(args, source, rows, cohort, read)
        history, periods = None, {}
        promote = False
        for phase, _, _ in stability.PHASES:
            if phase == "later2026":
                promote = all(
                    value["contextAgainstFrozen"]["net"] > 0 and value["contextAgainstRaw"]["net"] > 0
                    for value in periods.values()
                )
                args.out.with_suffix(f".{cohort}.selection.json").write_text(json.dumps({"context": promote}))
                if not promote:
                    break
            mask = masks[phase]
            fit, target = mask["fit"], mask["target"]
            if not fit.any() or (fit & target).any():
                raise ValueError("Chronological fit overlaps target or has no rows")
            classes, probability, _ = flow.old_components(SimpleNamespace(cache=args.cache), cohort, phase, *old)
            quantiles = {
                name: ordinary_quantiles(
                    x, np.where(fit, points, np.nan), np.where(fit, levels, np.nan), classes, fit, target
                )
                for name, x in matrices.items()
            }
            if phase != "warm2023":
                previous, previous_classes, previous_mask = history
                prev_rows = [r for r, ok in zip(rows, previous_mask, strict=True) if ok]
                bank_mask = stability.previous_bank_mask(prev_rows, mask["first"])
                frozen = references[phase][1]
                forecasts = {}
                for key, parts in quantiles.items():
                    bank = empirical.fit_bank(
                        previous_classes,
                        previous[key],
                        points[previous_mask],
                        levels[previous_mask],
                        pos[previous_mask],
                        bank_mask,
                        "raw",
                    )
                    full = empirical.empirical_predictions(classes, probability, parts, pos[target], bank, 20, 0.75, 0)
                    forecasts[key] = np.where(known[target], full, frozen)
                actual = scores[target]
                all_cases = np.ones(len(actual), dtype=bool)
                weeks = [r["week"] for r, ok in zip(rows, target, strict=True) if ok]
                component = {
                    key: component_predictions(x, recovery_points, fit & (pos != "GK"), target)
                    for key, x in matrices.items()
                }
                component["context"] = np.where(known[target], component["context"], component["raw"])
                evaluation = np.isin(pos[target], ("DEF", "MID")) if cohort == "start" else pos[target] != "GK"
                actual_component = recovery_points[target][evaluation]
                periods[phase] = {
                    "fitCases": int(fit.sum()),
                    "targetCases": len(actual),
                    "casesWithSourceHistory": int(known[target].sum()),
                    "nativeComponentCases": int(evaluation.sum()),
                    "nativeComponentMae": {
                        key: float(np.abs(actual_component - pred[evaluation]).mean())
                        for key, pred in component.items()
                    },
                    "contextAgainstRaw": compare(actual, forecasts["raw"], forecasts["context"], all_cases),
                    "contextAgainstFrozen": compare(actual, frozen, forecasts["context"], all_cases),
                    "rawAgainstFrozen": compare(actual, frozen, forecasts["raw"], all_cases),
                    "contextAgainstRawWeekGain95": paired_interval(
                        actual, forecasts["context"], forecasts["raw"], weeks
                    ),
                }
                print(
                    cohort,
                    phase,
                    periods[phase]["nativeComponentMae"],
                    periods[phase]["contextAgainstRaw"]["net"],
                    periods[phase]["contextAgainstFrozen"]["net"],
                    flush=True,
                )
            history = quantiles, classes, target
        report["cohorts"][cohort] = {"advanced": promote, "periods": periods}
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_regain_workload.json")
    )
    run(parser.parse_args())


if __name__ == "__main__":
    main()
