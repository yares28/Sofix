"""Strictly historical team volume, player involvement, roles and minutes."""

from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from typing import Any

import numpy as np

from app.research.score_foundation import prior_role
from app.research.score_search import cutoff_for, moment

STATS = (
    "accurate_pass",
    "missed_pass",
    "successful_final_third_passes",
    "pen_area_entries",
    "duel_won",
    "duel_lost",
    "won_tackle",
    "interception_won",
    "poss_won",
    "poss_lost_ctrl",
    "total_scoring_att",
    "ontarget_scoring_att",
    "adjusted_total_att_assist",
    "won_contest",
    "effective_clearance",
    "blocked_scoring_att",
    "saves",
    "fouls",
    "was_fouled",
    "goals",
)


def style_features(
    games: list[dict[str, Any]], rows: list[dict[str, Any]]
) -> tuple[np.ndarray, list[str], dict[str, Any]]:
    indexed = {g["id"]: g for g in games}
    if len(indexed) != len(games):
        raise ValueError("Duplicate source game")
    queue = sorted(games, key=lambda g: (g["date"], g["id"]))
    names = [
        "team_history_count",
        "opponent_history_count",
        "team_incomplete_28",
        "opponent_incomplete_28",
        "team_style_age",
        "opponent_style_age",
        "team_xi_turnover",
    ]
    for kind in ("team", "allowed"):
        for n in (3, 10):
            names.extend(f"{kind}_{n}_{stat}" for stat in STATS)
    names.extend(f"expected_team_{stat}" for stat in STATS)
    names.extend(f"player_share_count_{stat}" for stat in STATS)
    role_names = [
        "role_depth",
        "role_edge",
        "role_lines",
        "role_width",
        "role_depth_sd",
        "role_edge_sd",
        "role_recent_change",
    ]
    role_names += [
        f"role_minutes_{n}_{key}"
        for n in (3, 10)
        for key in ("last", "median", "q20", "q80", "sd", "under60", "over80")
    ]
    names.extend(role_names)
    teams: dict[str, list[dict[str, Any]]] = defaultdict(list)
    people: dict[str, list[dict[str, Any]]] = defaultdict(list)
    share_prior = {}
    global_sum = np.zeros(len(STATS))
    global_n = 0
    receipt = {"games": len(games), "incompleteGames": 0, "availabilityHours": 48, "rows": len(rows)}
    seen = 0
    previous = None
    output = []
    for row in rows:
        cutoff = cutoff_for(row["date"])
        if previous is not None and cutoff < previous:
            raise ValueError("Rows must be chronological")
        previous = cutoff
        while seen < len(queue) and moment(queue[seen]["date"]) + timedelta(hours=48) < cutoff:
            game = queue[seen]
            slugs = [game[side]["slug"] for side in ("home", "away")]
            played = [(slug, p) for slug, p in game["players"].items() if p.get("played") is True]
            complete = all(
                p.get("ver") == 7
                and p.get("mins") is not None
                and isinstance(p.get("stats"), dict)
                and type(p.get("started")) is bool
                and p.get("team") in slugs
                for _, p in played
            )
            xi = {}
            for side, club in zip(("home", "away"), slugs, strict=True):
                form = (game.get("xi") or {}).get(side) or {}
                xi[club] = {p for line in form.get("start") or [] for p in line}
                marked = {p for p, r in played if r.get("team") == club and r.get("started") is True}
                complete &= form.get("available") is True and len(xi[club]) == 11 and marked == xi[club]
            totals = {}
            for club in slugs:
                totals[club] = (
                    sum(
                        (
                            np.array([p["stats"].get(s, [0, 0])[0] for s in STATS], dtype=float)
                            for _, p in played
                            if p["team"] == club
                        ),
                        np.zeros(len(STATS)),
                    )
                    if complete
                    else None
                )
            receipt["incompleteGames"] += not complete
            for club, other in (slugs, slugs[::-1]):
                teams[club].append(
                    {"date": game["date"], "counts": totals[club], "allowed": totals[other], "xi": xi[club]}
                )
                if complete:
                    global_sum += totals[club]
                    global_n += 1
            for slug, p in played:
                if p.get("mins") is None or type(p.get("started")) is not bool:
                    continue
                count = np.array([p["stats"].get(s, [0, 0])[0] for s in STATS], dtype=float) if complete else None
                form = (game.get("xi") or {}).get("home" if p.get("team") == slugs[0] else "away") or {}
                lines = form.get("start") or []
                depth, edge = prior_role(game, slug, p.get("team") == slugs[0])
                width = next((len(line) for line in lines if slug in line), np.nan)
                record = {
                    "cohort": "start" if p["started"] else "bench",
                    "minutes": p["mins"],
                    "counts": count,
                    "teamCounts": totals.get(p.get("team")),
                    "role": (depth, edge, len(lines), width),
                    "date": game["date"],
                }
                people[slug].append(record)
                if complete:
                    key = p["pos"], record["cohort"]
                    num, den = share_prior.get(key, (np.zeros(len(STATS)), np.zeros(len(STATS))))
                    share_prior[key] = num + count, den + record["teamCounts"] * p["mins"] / 90
            seen += 1
        target = indexed[row["game"]]
        own = target["players"][row["player"]]["team"]
        if own not in (target["home"]["slug"], target["away"]["slug"]):
            raise ValueError("Player source side does not belong to target game")
        other = target["away"]["slug"] if own == target["home"]["slug"] else target["home"]["slug"]
        valid = {club: [g for g in teams[club] if g["counts"] is not None] for club in (own, other)}
        missing = {
            club: sum(g["counts"] is None and cutoff - moment(g["date"]) <= timedelta(days=28) for g in teams[club])
            for club in (own, other)
        }
        values = [len(valid[own]), len(valid[other]), missing[own], missing[other]]
        values += [
            (cutoff - moment(valid[club][-1]["date"])).total_seconds() / 86400 if valid[club] else np.nan
            for club in (own, other)
        ]
        values += [1 - len(valid[own][-1]["xi"] & valid[own][-2]["xi"]) / 11 if len(valid[own]) > 1 else np.nan]
        global_mean = global_sum / global_n if global_n else np.full(len(STATS), np.nan)
        estimated = []
        for club, field in ((own, "counts"), (other, "allowed")):
            for n in (3, 10):
                group = valid[club][-n:]
                mean = (
                    (sum((g[field] for g in group), np.zeros(len(STATS))) + 3 * global_mean) / (len(group) + 3)
                    if group
                    else np.full(len(STATS), np.nan)
                )
                values.extend(mean)
                if n == 10:
                    estimated.append(mean)
        stack = np.array(estimated)
        available = np.isfinite(stack).sum(axis=0)
        expected = np.divide(np.nansum(stack, axis=0), available, out=np.full(len(STATS), np.nan), where=available > 0)
        values.extend(expected)
        history = [p for p in people[row["player"]] if p["cohort"] == row["cohort"]]
        complete_history = [p for p in history if p["counts"] is not None][-10:]
        num = sum((p["counts"] for p in complete_history), np.zeros(len(STATS)))
        den = sum((p["teamCounts"] * p["minutes"] / 90 for p in complete_history), np.zeros(len(STATS)))
        prior_num, prior_den = share_prior.get(
            (row["pos"], row["cohort"]), (np.zeros(len(STATS)), np.zeros(len(STATS)))
        )
        fraction = np.divide(prior_num, prior_den, out=np.zeros(len(STATS)), where=prior_den > 0)
        pseudo = 3 * np.nan_to_num(global_mean)
        share = np.divide(num + pseudo * fraction, den + pseudo, out=np.zeros(len(STATS)), where=den + pseudo > 0)
        minutes = (
            float(np.median([p["minutes"] for p in history[-10:]]))
            if history
            else (80 if row["cohort"] == "start" else 20)
        )
        values.extend(share * expected * minutes / 90)
        roles = [p["role"] for p in people[row["player"]] if p["cohort"] == "start" and p["role"][0] >= 0][-5:]
        if roles:
            a = np.array(roles)
            values.extend(
                [
                    *roles[-1],
                    float(a[:, 0].std()),
                    float(a[:, 1].std()),
                    float(np.linalg.norm(a[-1, :2] - a[-2, :2])) if len(a) > 1 else 0,
                ]
            )
        else:
            values.extend([np.nan] * 7)
        for n in (3, 10):
            a = np.array([p["minutes"] for p in history[-n:]])
            values.extend(
                [
                    a[-1],
                    np.median(a),
                    np.quantile(a, 0.2),
                    np.quantile(a, 0.8),
                    a.std(),
                    np.mean(a < 60),
                    np.mean(a >= 80),
                ]
                if len(a)
                else [np.nan] * 7
            )
        output.append(values)
    return np.asarray(output, dtype=np.float32), names, receipt
