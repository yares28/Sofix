import copy

import numpy as np

from app.research.score_branches import choose_branch
from app.research.score_foundation import build_cases, pick_score
from app.research.score_foundation_run import best_window, score_from_parts
from tests.test_score_search import game


def test_predicts_a_likely_outcome_instead_of_the_average():
    assert pick_score(np.array([[0.6, 0.4]]), np.array([40.0, 80.0]))[0] == 40


def test_high_and_low_branch_never_become_a_blended_score():
    assert choose_branch(np.array([0.4, 0.6]), np.array([40.0, 40.0]), np.array([80.0, 80.0]), 0.5).tolist() == [40, 80]


def test_decisive_floor_survives_allaround_perturbations():
    assert score_from_parts(60, np.array([-20.0, 5.0, 70.0])).tolist() == [60, 65, 100]
    assert score_from_parts(35, np.array([-40.0, -5.0])).tolist() == [0, 30]


def test_direct_window_probabilities_are_not_smoothed_a_second_time():
    chances = np.zeros((1, 101))
    chances[0, 20:31] = 0.5
    chances[0, 80] = 0.8
    assert best_window(chances)[0] == 80


def test_starts_and_substitute_appearances_are_separate_and_dnp_is_excluded():
    g = game("2025-10-12T20:00:00Z", 40)
    g["xi"] = {}
    g["players"]["sub"] = {**g["players"]["player"], "started": False, "mins": 15, "score": 35}
    g["players"]["dnp"] = {**g["players"]["sub"], "played": False, "mins": 0, "score": 0}
    rows, _ = build_cases([g], {})
    assert [(r["player"], r["cohort"]) for r in rows] == [("player", "start"), ("sub", "bench")]


def test_result_minutes_role_stats_and_later_games_cannot_change_a_prediction():
    past = game("2025-09-20T16:00:00Z", 40, "past")
    target = game("2025-10-12T20:00:00Z", 80, "target")
    original, _ = build_cases([past, target], {})
    altered = copy.deepcopy(target)
    altered["players"]["player"].update(score=0, mins=1, aa=-30, level=0, stats={"goals": [9, 90]})
    altered["homeGoals"] = 10
    changed, _ = build_cases([past, altered, game("2026-01-01T20:00:00Z", 100, "future")], {})
    a = next(r for r in original if r["game"] == "target")
    b = next(r for r in changed if r["game"] == "target")
    assert a["x"] == b["x"]
    assert a["score"] != b["score"]


def test_zero_stays_a_real_result_and_unknown_started_stays_unknown():
    g = game("2025-10-12T20:00:00Z", 0)
    rows, _ = build_cases([g], {})
    assert rows[0]["score"] == 0
    g["players"]["player"]["started"] = None
    assert build_cases([g], {})[0] == []
