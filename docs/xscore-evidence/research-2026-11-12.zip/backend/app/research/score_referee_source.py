"""Testing-only official referee appointment source pilot; no forecast formula."""

from __future__ import annotations

import hashlib
import html
import json
import re
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research.score_search import cutoff_for, moment

OFFICIAL_CLUBS = {
    "Athletic Club": "athletic-club-bilbao",
    "Club Atlético de Madrid": "atletico-madrid-madrid",
    "FC Barcelona": "barcelona-barcelona",
    "Real Betis Balompié": "real-betis-sevilla",
    "Cádiz CF": "cadiz-cadiz",
    "RC Celta de Vigo": "celta-de-vigo-vigo",
    "Deportivo Alavés": "deportivo-alaves-vitoria-gasteiz",
    "Elche CF": "elche-elche",
    "RCD Espanyol de Barcelona": "espanyol-barcelona",
    "Getafe CF": "getafe-getafe-madrid",
    "Girona FC": "girona-girona",
    "Granada CF": "granada-granada",
    "UD Las Palmas": "las-palmas-las-palmas-de-gran-canaria",
    "CD Leganés": "leganes-leganes",
    "Levante UD": "levante-valencia",
    "RCD Mallorca": "mallorca-palma-de-mallorca",
    "Club Atlético Osasuna": "osasuna-pamplona-irunea",
    "Rayo Vallecano de Madrid": "rayo-vallecano-madrid",
    "Real Madrid CF": "real-madrid-madrid",
    "Real Oviedo": "real-oviedo-oviedo",
    "Real Sociedad de Fútbol": "real-sociedad-donostia-san-sebastian",
    "Real Valladolid CF": "real-valladolid-valladolid",
    "Sevilla FC": "sevilla-sevilla-1890",
    "UD Almería": "almeria-almeria",
    "Valencia CF": "valencia-valencia",
    "Villarreal CF": "villarreal-villarreal",
}


def publication(text):
    blocks = re.findall(r'<div class="news__header__date[^\"]*">(.*?)</div>', text, re.S)
    if len(blocks) != 1:
        raise ValueError("Unknown article publication timestamp")
    dates = re.findall(r"(\d{2}/\d{2}/\d{4})\s*-\s*(\d{2}:\d{2})", blocks[0])
    if len(dates) != 1:
        raise ValueError("Unknown article publication timestamp")
    return (
        datetime.strptime(" ".join(dates[0]), "%d/%m/%Y %H:%M")
        .replace(tzinfo=ZoneInfo("Europe/Madrid"))
        .astimezone(UTC)
    )


def availability(*timestamps):
    if not timestamps or any(t is None or t.tzinfo is None or t.utcoffset() is None for t in timestamps):
        raise ValueError("Missing source timestamp or timezone")
    return max(t.astimezone(UTC) for t in timestamps)


def assignment_rows(text):
    # Exact men's senior top division, excluding Primera Federación, women and futsal.
    if not re.search(
        r"Competición:\s*Campeonato Nacional de (?:Liga de )?Primera División\s*-\s*Primera División", text
    ):
        raise ValueError("Unexpected source competition")
    lines = text.splitlines()
    result = []
    for i, line in enumerate(lines):
        match = re.fullmatch(r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+(\d{2}:\d{2})", line.strip())
        if not match:
            continue
        pairs = [(h, a) for h in OFFICIAL_CLUBS for a in OFFICIAL_CLUBS if h + " " + a == match[2]]
        if len(pairs) != 1:
            raise ValueError("Unknown or ambiguous printed club pair")
        referee = (
            re.fullmatch(r"Árbitro:\s*(.+?)\s+4º Árbitro:.*", lines[i + 1].strip()) if i + 1 < len(lines) else None
        )
        if referee is None:
            raise ValueError("No unique main referee adjacent to fixture")
        result.append(
            dict(
                localDate=datetime.strptime(match[1], "%d-%m-%Y").date().isoformat(),
                time=match[3],
                home=pairs[0][0],
                away=pairs[0][1],
                referee=referee[1].strip(),
            )
        )
    if not result or len(result) != len(re.findall(r"(?m)^Árbitro:", text)):
        raise ValueError("Incomplete appointment source rows")
    return result


def main():
    from pypdf import PdfReader

    folder = Path("data/raw/score-foundation/referee-source")
    reports = Path("reports/experiments")
    entries = json.loads((folder / "pilot_pdf_manifest.json").read_text(encoding="utf-8-sig"))
    pages = {r["File"]: r for r in json.loads((folder / "pilot_pages_manifest.json").read_text(encoding="utf-8-sig"))}
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    native_sha = hashlib.sha256(native.read_bytes()).hexdigest()
    if native_sha != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Frozen native schedule differs")
    games = [json.loads(v) for v in native.read_text(encoding="utf-8").splitlines()]
    result = []
    for entry in entries:
        if entry["Status"] != "downloaded":
            raise ValueError("Pilot source download incomplete")
        path = folder / entry["File"]
        raw = path.read_bytes()
        if not raw.startswith(b"%PDF-") or hashlib.sha256(raw).hexdigest() != entry["SHA256"].lower():
            raise ValueError("Unknown or changed PDF bytes")
        page_path = folder / entry["ParentPage"]
        page_raw = page_path.read_bytes()
        if (
            hashlib.sha256(page_raw).hexdigest() != entry["ParentPageSHA"].lower()
            or pages[entry["ParentPage"]]["SHA256"].lower() != entry["ParentPageSHA"].lower()
        ):
            raise ValueError("Parent article bytes changed")
        article = page_raw.decode("utf-8")
        links = [html.unescape(v) for v in re.findall(r'href="([^"]*\.pdf[^\"]*)"', article)]
        if links != [entry["Url"].removeprefix("https://rfef.es")]:
            raise ValueError("PDF is not unique document linked by original article")
        reader = PdfReader(path)
        created, modified = reader.metadata.creation_date, reader.metadata.modification_date
        stamp = entry["LastModified"]
        http = parsedate_to_datetime(stamp[0] if isinstance(stamp, list) else stamp)
        published = publication(article)
        available = availability(published, created, modified, http)
        assignments = []
        for p, page in enumerate(reader.pages):
            for row in assignment_rows(page.extract_text()):
                local = datetime.fromisoformat(row["localDate"] + "T" + row["time"]).replace(
                    tzinfo=ZoneInfo("Europe/Madrid")
                )
                kickoff = local.astimezone(UTC)
                candidates = [
                    g["id"]
                    for g in games
                    if g["home"]["slug"] == OFFICIAL_CLUBS[row["home"]]
                    and g["away"]["slug"] == OFFICIAL_CLUBS[row["away"]]
                    and moment(g["date"]) == kickoff
                ]
                if len(candidates) != 1:
                    raise ValueError("Official appointment does not uniquely match native schedule")
                lock = cutoff_for(kickoff.isoformat())
                assignments.append(
                    row
                    | dict(
                        page=p + 1,
                        game=candidates[0],
                        kickoffUTC=kickoff.isoformat(),
                        inferredLockUTC=lock.isoformat(),
                        metadataBeforeLock=available < lock,
                        refereeInput=row["referee"] if available < lock else None,
                    )
                )
        result.append(
            dict(
                file=path.name,
                sha256=entry["SHA256"].lower(),
                page=entry["ParentPage"],
                articleSHA=entry["ParentPageSHA"].lower(),
                publicationUTC=published.isoformat(),
                creationUTC=created.astimezone(UTC).isoformat(),
                modificationUTC=modified.astimezone(UTC).isoformat(),
                httpLastModifiedUTC=http.isoformat(),
                availableUTC=available.isoformat(),
                assignments=assignments,
            )
        )
        print(
            "REFEREE_SOURCE_PILOT",
            json.dumps(
                dict(file=path.name, rows=len(assignments), prelock=sum(r["metadataBeforeLock"] for r in assignments))
            ),
            flush=True,
        )
    inputs = {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [
            folder / "pilot_pdf_manifest.json",
            folder / "pilot_pages_manifest.json",
            reports / "laliga_score_referee_source.plan.json",
        ]
    }
    key = hashlib.sha256(
        Path(__file__).read_bytes() + json.dumps(inputs, sort_keys=True).encode() + native_sha.encode()
    ).hexdigest()
    output = dict(
        scope="Official source pilot only, no model and no xScore improvement",
        implementationKey=key,
        manifests=inputs,
        nativeSHA=native_sha,
        documents=result,
        assignments=sum(len(d["assignments"]) for d in result),
        availableAssignments=sum(r["metadataBeforeLock"] for d in result for r in d["assignments"]),
        limitation="Current official page/document timestamps reconstruct availability; not original captured receipts. Late PDF revisions cannot use earlier article dates. Referee name identity across naming changes not resolved, no model eligible yet.",
    )
    (reports / "laliga_score_referee_source.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
