"""Testing-only repair of pass-coordinate late binding; preserve legacy artifacts."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from app.research import score_player_context as legacy

GEOMETRY_FIELDS = (
    "usage_progressive90",
    "usage_box_passes90",
    "usage_pass_x",
    "usage_pass_edge",
    "usage_pass_x_sd",
    "usage_attacking_fraction",
    "usage_central_fraction",
)

_original_metrics = legacy.player_metrics
recent_features = legacy.recent_features


def player_metrics(shots, passes, role, minutes):
    result = _original_metrics(shots, passes, role, minutes)
    result.update(dict.fromkeys(GEOMETRY_FIELDS, np.nan))
    if passes is None:
        return result
    # Each tuple is consumed while this particular pass is bound.
    coordinates = [tuple(legacy.number(p.get(k)) for k in ("x", "y", "ex", "ey")) for p in passes]
    valid = [p for p in coordinates if np.isfinite(p).all() and all(0 <= v <= 100 for v in p)]
    if len(valid) == len(passes) and minutes > 0:
        result["usage_progressive90"] = sum(ex - x >= 15 for x, _, ex, _ in valid) * 90 / minutes
        result["usage_box_passes90"] = sum(legacy.in_box(ex, ey) for _, _, ex, ey in valid) * 90 / minutes
    if valid:
        x, y, _, _ = np.asarray(valid).T
        result.update(
            usage_pass_x=float(x.mean()),
            usage_pass_edge=float((2 * abs(y - 50)).mean()),
            usage_pass_x_sd=float(x.std()),
            usage_attacking_fraction=float((x >= 200 / 3).mean()),
            usage_central_fraction=float((abs(y - 50) <= 20).mean()),
        )
    return result


def load_corrected(repo, manifest, games, aliases):
    descriptions = []

    def tracked(shots, passes, role, minutes):
        descriptions.append(
            dict(
                player=passes[0].get("player") if passes else None,
                passStreamKnown=isinstance(passes, list),
                passCount=len(passes) if passes is not None else None,
                role=role,
            )
        )
        return player_metrics(shots, passes, role, minutes)

    previous = legacy.player_metrics
    legacy.player_metrics = tracked
    try:
        records, receipt = legacy.load_observations(repo, manifest, games, aliases)
    finally:
        legacy.player_metrics = previous
    if len(records) != len(descriptions):
        raise ValueError("Source geometry attribution lost native observation order")
    for record, metadata in zip(records, descriptions, strict=True):
        record["geometrySource"] = metadata
    return records, receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--manifest", type=Path, default=Path("data/raw/score-foundation/match-context/data.txt"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_pass_geometry_corrected.json")
    )
    args = parser.parse_args()
    os.environ["GIT_NO_LAZY_FETCH"] = "1"
    source = json.loads((args.cache / "cases.json").read_text())
    native_raw, aliases_raw = args.games.read_bytes(), (args.cache / "player_names.json").read_bytes()
    if hashlib.sha256(native_raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native case source changed")
    expected_old = hashlib.sha256(
        (source["key"] + legacy.COMMIT).encode() + native_raw + aliases_raw + Path(legacy.__file__).read_bytes()
    ).hexdigest()
    old_archive = json.loads(gzip.decompress((args.cache / "player_context_observations.json.gz").read_bytes()))
    with np.load(args.cache / "player_context_features.npz") as f:
        if str(f["key"]) != expected_old or old_archive["key"] != expected_old:
            raise ValueError("Original preserved geometry source key changed")
        old_x, old_names = f["x"], f["names"].tolist()
    games = [json.loads(line) for line in native_raw.decode().splitlines() if line.strip()]
    records, receipt = load_corrected(args.repo, args.manifest, games, json.loads(aliases_raw))
    if receipt != old_archive["receipt"] or len(records) != len(old_archive["records"]):
        raise ValueError("Coordinate repair changed source fixture/name/cohort coverage")
    changed_fields, unchanged_fields = {}, set(legacy.FIELDS) - set(GEOMETRY_FIELDS)
    for new, old in zip(records, old_archive["records"], strict=True):
        if any(new[k] != old[k] for k in ("date", "game", "player", "club", "cohort", "minutes")):
            raise ValueError("Coordinate repair changed observation identity")
        for name in unchanged_fields:
            if new["values"][name] != old["values"][name]:
                raise ValueError("Coordinate repair changed an unaffected value")
        for name in GEOMETRY_FIELDS:
            changed_fields[name] = changed_fields.get(name, 0) + int(new["values"][name] != old["values"][name])
    key = hashlib.sha256(
        expected_old.encode() + Path(__file__).read_bytes() + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    archive = args.cache / "pass_geometry_corrected_observations.json.gz"
    archive.write_bytes(
        gzip.compress(
            json.dumps(
                dict(key=key, records=records, receipt=receipt), separators=(",", ":"), allow_nan=False
            ).encode(),
            mtime=0,
        )
    )
    extra, names, metadata = recent_features(source["rows"], records, {g["id"]: g for g in games})
    if names != old_names or extra.shape != old_x.shape or len(extra) != 38850:
        raise ValueError("Coordinate repair changed full target schema/population")
    geometry = np.array([any(field + "_" in name for field in GEOMETRY_FIELDS) for name in names])
    if geometry.sum() != 42:
        raise ValueError("Geometry-only feature schema differs")
    np.testing.assert_array_equal(extra[:, ~geometry], old_x[:, ~geometry])
    changed = ~np.isclose(extra, old_x, rtol=0, atol=1e-10, equal_nan=True)
    feature_key = hashlib.sha256(
        (key + source["key"] + hashlib.sha256(archive.read_bytes()).hexdigest()).encode()
    ).hexdigest()
    path = args.cache / "pass_geometry_corrected_features.npz"
    np.savez_compressed(
        path,
        key=feature_key,
        x=extra,
        names=names,
        geometry=geometry,
        legacy_key=expected_old,
        source_key=source["key"],
    )
    output = dict(
        scope="Research input repair only; no accuracy improvement claimed or app change",
        sourceKey=source["key"],
        legacyKey=expected_old,
        implementationKey=key,
        featureKey=feature_key,
        metadata=metadata,
        sourceObservationCount=len(records),
        unchangedNonGeometryFields=len(unchanged_fields),
        perFieldChangedObservations=changed_fields,
        geometryFeatureColumns=int(geometry.sum()),
        changedFeatureColumns=int(changed.any(axis=0).sum()),
        changedFeatureCells=int(changed.sum()),
        changedTargetRows=int(changed.any(axis=1).sum()),
        sourceContentSha256=receipt["sourceContentSha256"],
        observationsSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        featuresSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        status="Source rebuilt; independent raw geometry and lagged-feature audit REQUIRED before model fitting",
    )
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print("GEOMETRY_REBUILT " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
