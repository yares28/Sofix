"""Testing only: score distributions conditional on simulated future match paths."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_identity import category_values
from app.research.score_joint_density import components
from app.research.score_match_context import CLUBS, normalise, season_year
from app.research.score_player_context import COMMIT
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres

FLOW_NAMES = ("gf", "ga", "leading", "level", "trailing", "mean_difference", "leading_two", "trailing_two")
CENTRES = np.arange(0, 100.01, 0.5)


def flow_vector(events, end, away=False):
    if not np.isfinite(end) or end <= 0:
        raise ValueError("Unknown match clock")
    result = np.zeros(8)
    home, visitor, before = 0, 0, 0.0
    for minute, side in sorted([*events, (end, "end")], key=lambda e: e[0]):
        if side not in ("home", "away", "end") or not 0 <= minute <= end:
            raise ValueError("Invalid goal event")
        duration = (minute - before) / end
        difference = home - visitor
        result[2 if difference > 0 else 4 if difference < 0 else 3] += duration
        result[5] += difference * duration
        result[6] += (difference >= 2) * duration
        result[7] += (difference <= -2) * duration
        home += side == "home"
        visitor += side == "away"
        before = minute
    result[:2] = home, visitor
    if away:
        result = result[[1, 0, 4, 3, 2, 5, 7, 6]]
        result[5] *= -1
    return result


def verified_flow(detail, home_goals, away_goals):
    goals = detail.get("goals")
    if not isinstance(goals, list):
        return None
    events = []
    for goal in goals:
        minute, side = goal.get("min"), goal.get("team")
        if type(minute) not in (int, float) or not np.isfinite(minute) or minute < 0 or side not in ("home", "away"):
            return None
        events.append((float(minute), side))
    if [sum(side == s for _, side in events) for s in ("home", "away")] != [home_goals, away_goals]:
        return None
    maximum = detail.get("maxMin")
    if type(maximum) not in (int, float) or not np.isfinite(maximum):
        return None
    end = max(90, maximum, max((t for t, _ in events), default=90))
    return flow_vector(events, end), sorted(t / end for t, _ in events)


def clock_bank(labels, rows, fit):
    games = {r["game"] for r, yes in zip(rows, fit, strict=True) if yes}
    times = sorted(t for game in games if game in labels for t in labels[game]["times"])
    if not times:
        raise ValueError("No available earlier goal clocks")
    return np.array(times)


def scenario_flows(fixtures, away, times, count=32, seed=20261104):
    from scipy.stats import poisson, qmc

    if count <= 0 or count & (count - 1):
        raise ValueError("Scenario count must be a power of two")
    uniform = qmc.Sobol(d=34, scramble=True, seed=seed).random_base2(int(np.log2(count)))
    scenarios = {}
    result = []
    for (game, home_lambda, away_lambda), is_away in zip(fixtures, away, strict=True):
        if not np.isfinite([home_lambda, away_lambda]).all() or min(home_lambda, away_lambda) < 0:
            raise ValueError("Unknown or invalid prematch lambda")
        identity = (game, home_lambda, away_lambda)
        if identity not in scenarios:
            goals = poisson.ppf(uniform[:, :2], [home_lambda, away_lambda]).astype(int)
            if goals.max() > 16:
                raise ValueError("Poisson tail exceeds declared scenario capacity")
            vectors = []
            for i in range(count):
                events = []
                for j, side in enumerate(("home", "away")):
                    u = uniform[i, 2 + j * 16 : 2 + j * 16 + goals[i, j]]
                    events.extend(
                        (90 * t, side) for t in times[np.minimum((u * len(times)).astype(int), len(times) - 1)]
                    )
                vectors.append(flow_vector(events, 90))
            scenarios[identity] = np.array(vectors)
        value = scenarios[identity]
        if is_away:
            value = value[:, [1, 0, 4, 3, 2, 5, 7, 6]].copy()
            value[:, 5] *= -1
        result.append(value)
    return np.array(result)


def sample_prediction(levels, locations, errors, spread, shift):
    floor = np.where(levels >= 60, levels, 0)
    scores = np.sort(np.clip(np.maximum(floor, levels + locations + errors * spread + shift), 0, 100), axis=1)
    mass = np.array(
        [
            np.searchsorted(row, CENTRES + 7, side="right") - np.searchsorted(row, CENTRES - 7, side="left")
            for row in scores
        ]
    )
    return window_centres(mass, CENTRES)


def source_labels(repo, manifest, games):
    head = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if head != COMMIT:
        raise ValueError("Flow source commit differs")
    tree = subprocess.check_output(["git", "-C", str(repo), "ls-tree", "-r", "HEAD"], text=True)
    blobs = {line.split("\t", 1)[1]: line.split()[2] for line in tree.splitlines()}
    digest = hashlib.sha256()

    def read(path, name):
        canonical = path.read_bytes().replace(b"\r\n", b"\n")
        actual = hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest()
        if actual != blobs[name]:
            raise ValueError("Flow source blob hash differs")
        digest.update(canonical)
        return json.loads(canonical.decode("utf-8").split("=", 1)[1].strip().rstrip(";"))

    schedule = read(manifest, "laliga_dashboard/data.js")
    local = defaultdict(list)
    for game in games:
        local[season_year(game["date"]), game["home"]["slug"], game["away"]["slug"]].append(game)
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    clubs.update(
        {
            normalise(k): CLUBS[v]
            for k, v in (
                ("Alaves", "Deportivo Alaves"),
                ("Celta", "Celta Vigo"),
                ("Deportivo La Coruna", "Deportivo A Coruna"),
            )
        }
    )
    labels, audit, seen = {}, Counter(), set()
    for season in schedule["seasons"].values():
        for entry in season["matches"]:
            if entry.get("played") is not True:
                continue
            identity = (
                season_year(entry["date"]),
                clubs.get(normalise(entry["home"])),
                clubs.get(normalise(entry["away"])),
            )
            matches = local.get(identity, [])
            if len(matches) != 1:
                audit["noUniqueLocalFixture"] += 1
                continue
            game = matches[0]
            if game["id"] in seen:
                raise ValueError("Duplicate flow source fixture")
            seen.add(game["id"])
            name = f"laliga_dashboard/matches_detail/{entry['id']}.js"
            if name not in blobs or not (repo / name).exists():
                audit["missingDetail"] += 1
                continue
            detail = read(repo / name, name)
            if [clubs.get(normalise(detail[s].get("name", ""))) for s in ("home", "away")] != list(identity[1:]):
                audit["clubConflict"] += 1
                continue
            if (detail["home"].get("score"), detail["away"].get("score")) != (game["homeGoals"], game["awayGoals"]):
                audit["scoreConflict"] += 1
                continue
            value = verified_flow(detail, game["homeGoals"], game["awayGoals"])
            if value is None:
                audit["unverifiedTimeline"] += 1
                continue
            vector, times = value
            labels[game["id"]] = {"home": vector.tolist(), "times": times, "date": game["date"]}
            audit["verifiedFixtures"] += 1
            audit["correctedDates"] += detail.get("date") != game["date"][:10]
            audit["verifiedGoals"] += len(times)
    return labels, {"commit": head, "contentSha256": digest.hexdigest(), **dict(audit), "localFixtures": len(games)}


def fact_matrix(rows, identities, games, labels, feature_names):
    by_game = {g["id"]: g for g in games}
    values, fixtures, away = [], [], []
    for row, identity in zip(rows, identities, strict=True):
        game = by_game[row["game"]]
        is_away = identity[1] == game["away"]["slug"]
        if identity[1] not in (game["home"]["slug"], game["away"]["slug"]):
            raise ValueError("Playing side differs from fixture")
        fact = np.array(labels[row["game"]]["home"]) if row["game"] in labels else np.full(8, np.nan)
        if is_away:
            fact = fact[[1, 0, 4, 3, 2, 5, 7, 6]].copy()
            fact[5] *= -1
        values.append(fact)
        fixtures.append(
            (row["game"], row["x"][feature_names.index("match_lam_h")], row["x"][feature_names.index("match_lam_a")])
        )
        away.append(is_away)
    return np.array(values), fixtures, np.array(away)


def add_context(frame, flow, minutes=None, levels=None):
    result = frame.copy()
    for j, name in enumerate(FLOW_NAMES):
        result["flow_" + name] = flow[:, j]
    if minutes is not None:
        result["exposure"] = minutes
    if levels is not None:
        result["candidate_level"] = levels
    return result


def predict_batched(model, frame, cats, probability=False):
    from catboost import Pool

    chunks = []
    for i in range(0, len(frame), 16384):
        pool = Pool(frame.iloc[i : i + 16384], cat_features=cats)
        chunks.append(model.predict_proba(pool) if probability else model.predict(pool))
    return np.concatenate(chunks)


def fitted_paths(frame, cats, factual, aa, minutes, levels, mask, scenarios, old_classes, path, key):
    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) == key and np.array_equal(stored["classes"], old_classes):
                return {
                    n: stored[n] for n in ("locations", "probability", "factual_location", "minutes", "factual_minutes")
                }
    from catboost import CatBoostClassifier, Pool

    fit, check = mask["fit"], mask["target"]
    train = add_context(frame.loc[fit], factual[fit])
    minute_model = ordinary.regressor("MAE", minutes=True)
    minute_model.fit(Pool(train, label=minutes[fit], cat_features=cats))
    train["exposure"] = minutes[fit]
    decisive = CatBoostClassifier(
        loss_function="MultiClass",
        iterations=300,
        depth=4,
        l2_leaf_reg=20,
        learning_rate=0.05,
        random_seed=20261104,
        thread_count=4,
        task_type="CPU",
        border_count=64,
        max_ctr_complexity=1,
        allow_writing_files=False,
        verbose=False,
    )
    decisive.fit(Pool(train, label=levels[fit], cat_features=cats))
    if not np.array_equal(decisive.classes_, old_classes):
        raise ValueError("Conditional decisive classes differ")
    train["candidate_level"] = levels[fit]
    aa_model = ordinary.regressor("MAE")
    aa_model.fit(Pool(train, label=aa[fit], cat_features=cats))
    target_frame = frame.loc[check].reset_index(drop=True)
    factual_frame = add_context(target_frame, factual[check])
    factual_minutes = np.clip(predict_batched(minute_model, factual_frame, cats), 1, 100)
    # This factual prediction exists ONLY for the next phase's earlier error bank.
    factual_frame["exposure"] = factual_minutes
    factual_frame["candidate_level"] = levels[check]
    factual_location = predict_batched(aa_model, factual_frame, cats)
    n, count, _ = scenarios.shape
    locations = np.empty((n, count, len(old_classes)), dtype=np.float32)
    probability = np.empty_like(locations)
    forecast_minutes = np.empty((n, count), dtype=np.float32)
    for context in range(count):
        future = add_context(target_frame, scenarios[:, context])
        exposure = np.clip(predict_batched(minute_model, future, cats), 1, 100)
        forecast_minutes[:, context] = exposure
        future["exposure"] = exposure
        probability[:, context] = predict_batched(decisive, future, cats, probability=True)
        for j, level in enumerate(old_classes):
            future["candidate_level"] = level
            locations[:, context, j] = predict_batched(aa_model, future, cats)
        if context % 8 == 0:
            print(f"PATH {path.stem} {context + 1}/{count}", flush=True)
    result = {
        "locations": locations,
        "probability": probability,
        "factual_location": factual_location,
        "minutes": forecast_minutes,
        "factual_minutes": factual_minutes,
    }
    np.savez_compressed(path, key=key, classes=old_classes, **result)
    return result


def residual_bank(previous_rows, previous, factual, first):
    available = stability.previous_bank_mask(previous_rows, first) & np.isfinite(factual).all(axis=1)
    aa = np.array([r["aa"] for r in previous_rows])
    level = np.array([r["level"] for r in previous_rows])
    pos = np.array([r["pos"] for r in previous_rows])
    residual = aa - previous["factual_location"]
    if not available.any() or not np.isfinite(residual[available]).all():
        raise ValueError("No usable earlier flow error bank")
    return {
        "global": np.sort(residual[available]),
        "positions": {p: np.sort(residual[available & (pos == p)]) for p in set(pos[available])},
        "levels": {
            (p, float(v)): np.sort(residual[available & (pos == p) & (level == v)])
            for p, v in set(zip(pos[available], level[available], strict=True))
        },
        "cases": int(available.sum()),
        "unavailable": int((~available).sum()),
    }


def score_draws(classes, old_probability, paths, positions, bank, blend, draws=64, seed=20261104):
    from scipy.stats import qmc

    n, contexts, _ = paths["locations"].shape
    u = (
        qmc.Sobol(d=3, scramble=True, seed=seed)
        .random_base2(int(np.log2(contexts * draws)))
        .reshape(contexts, draws, 3)
    )
    probability = (1 - blend) * old_probability[:, None, :] + blend * paths["probability"]
    probability = probability / probability.sum(axis=2, keepdims=True)
    indices = np.sum(u[None, :, :, 0, None] > np.cumsum(probability, axis=2)[:, :, None, :], axis=3)
    indices = np.minimum(indices, len(classes) - 1)
    level = classes[indices]
    location = np.take_along_axis(paths["locations"], indices, axis=2)
    errors = np.zeros_like(location)
    for pos in set(positions):
        selected = np.flatnonzero(positions == pos)
        pooled = bank["positions"].get(pos, bank["global"])
        for j, value in enumerate(classes):
            conditional = bank["levels"].get((pos, float(value)), np.array([]))
            weight = len(conditional) / (len(conditional) + 20)
            sampled = pooled[np.minimum((u[:, :, 2] * len(pooled)).astype(int), len(pooled) - 1)]
            if len(conditional):
                other = conditional[np.minimum((u[:, :, 2] * len(conditional)).astype(int), len(conditional) - 1)]
                sampled = np.where(u[:, :, 1] < weight, other, sampled)
            errors[selected] = np.where(indices[selected] == j, sampled[None, :, :], errors[selected])
    return tuple(a.reshape(n, -1) for a in (level, location, errors))


def old_components(args, cohort, phase, old_match, old_stability, old_ordinary):
    if phase in ("autumn2025", "later2026"):
        ending = "selection" if phase == "autumn2025" else "later"
        return components(
            args.cache / f"feature_laliga_score_match_context_{cohort}_chances_and_intensity_{ending}.npz",
            old_match["implementationKey"],
        )
    if cohort == "start":
        return components(args.cache / f"laliga_score_stability_base_{phase}.npz", old_stability["implementationKey"])
    return components(args.cache / f"laliga_score_ordinary_base_bench_{phase}.npz", old_ordinary["implementationKey"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "cases",
        "games",
        "stats-cache",
        "match-cache",
        "player-cache",
        "cache",
        "packages",
        "out",
        "repo",
        "manifest",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--source-only", action="store_true")
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import catboost
    import pandas as pd

    source = json.loads(args.cases.read_text())
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    labels, receipt = source_labels(args.repo, args.manifest, games)
    labels_path = args.cache / (args.out.stem + "_factual_labels.json")
    labels_path.write_text(json.dumps({"receipt": receipt, "labels": labels}))
    print("SOURCE " + json.dumps(receipt), flush=True)
    args.out.with_name(args.out.stem + ".source.json").write_text(json.dumps(receipt, indent=2))
    if args.source_only:
        return
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Flow reference cases differ")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    with np.load(args.match_cache) as stored:
        match, match_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Match feature key differs")
    with np.load(args.player_cache) as stored:
        player, player_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_player["featureKey"]:
            raise ValueError("Player feature key differs")
    identities = category_values(source["rows"], games)
    files = [
        Path(__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + receipt["contentSha256"]
            + catboost.__version__
        ).encode()
        + raw
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "source": receipt,
        "cohorts": {},
    }
    if args.out.exists():
        previous_report = json.loads(args.out.read_text())
        if previous_report.get("implementationKey") == key:
            report = previous_report
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        aa, levels, minutes, y = (np.array([r[n] for r in rows]) for n in ("aa", "level", "minutes", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        factual, fixtures, away = fact_matrix(rows, identities[keep], games, labels, source["features"])
        numeric, feature_names = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        frame = pd.DataFrame(numeric, columns=[f"n{i}" for i in range(numeric.shape[1])])
        cats = ["player_id", "playing_side", "opponent_side", "card_position"]
        for i, name in enumerate(cats):
            frame[name] = identities[keep, i]
        records = [
            {
                "spec": {"blend": blend, "spread": spread, "shift": shift, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for blend in (0, 0.5, 1)
            for spread in (0.75, 1, 1.25)
            for shift in (-2, 0, 2)
            for scope in ("all", "defmid")
        ]
        prior, winner, best = None, None, None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            target_fixtures = [f for f, yes in zip(fixtures, target, strict=True) if yes]
            clock = clock_bank(labels, rows, mask["fit"])
            scenarios = scenario_flows(target_fixtures, away[target], clock)
            old = old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if len(old[1]) != target.sum():
                raise ValueError("Original target rows differ")
            paths = fitted_paths(
                frame,
                cats,
                factual,
                aa,
                minutes,
                levels,
                mask,
                scenarios,
                old[0],
                args.cache / f"{args.out.stem}_{cohort}_{phase}_paths.npz",
                key,
            )
            audit[phase] = {
                "fit": int(mask["fit"].sum()),
                "target": int(target.sum()),
                "knownFlowFit": int(np.isfinite(factual[mask["fit"]]).all(axis=1).sum()),
                "knownFlowTarget": int(np.isfinite(factual[target]).all(axis=1).sum()),
                "clockGoals": len(clock),
                "clockFitGames": len({r["game"] for r, yes in zip(rows, mask["fit"], strict=True) if yes}),
                "forecastMinutesMeanMiss": float(np.mean(np.abs(minutes[target] - paths["minutes"].mean(axis=1)))),
            }
            if prior is None:
                prior = (target_rows, old, paths, factual[target])
                print("WARM " + json.dumps({"cohort": cohort, **audit[phase]}), flush=True)
                continue
            previous_rows, previous_old, previous_paths, previous_factual = prior
            if cohort == "start":
                control_parts = stability.starter_control(previous_old, old, previous_rows, mask["first"])
                control = empirical.empirical_predictions(
                    *control_parts[:3], positions[target], control_parts[3], 20, 0.75, 0
                )
            else:
                control = stability.analogue_control(args, key, source, old_bench, phase, mask)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control)["within7"] != expected["within7"]:
                raise ValueError("Frozen control did not reproduce")
            bank = residual_bank(previous_rows, previous_paths, previous_factual, mask["first"])
            audit[phase]["control"] = measure(y[target], control)
            audit[phase]["errorBank"] = {k: bank[k] for k in ("cases", "unavailable")}
            if phase == "later2026" and best is None:
                raise ValueError("Candidate must be frozen before later outcomes")
            active_records = [best] if phase == "later2026" else records
            prediction_cache = {}
            for blend in sorted({r["spec"]["blend"] for r in active_records}):
                draws = score_draws(old[0], old[1], paths, positions[target], bank, blend)
                for record in [r for r in active_records if r["spec"]["blend"] == blend]:
                    spec = record["spec"]
                    identity = (spec["spread"], spec["shift"])
                    if identity not in prediction_cache:
                        prediction_cache[identity] = sample_prediction(*draws, spec["spread"], spec["shift"])
                    candidate = ordinary.scoped_prediction(
                        prediction_cache[identity], control, positions[target], spec["scope"]
                    )
                    metric = measure(y[target], candidate)
                    if phase != "later2026":
                        gain = metric["within7"] - audit[phase]["control"]["within7"]
                        record["gains"].append(gain)
                        record["errors"].append(metric["mae"])
                        record["counts"].append(len(candidate))
                        record["periods"][phase] = {"gain": gain, "metrics": metric}
                    else:
                        alternate = candidate
                prediction_cache.clear()
            print("PERIOD " + json.dumps({"cohort": cohort, "phase": phase, **audit[phase]}), flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                    "candidates": records,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            prior = (target_rows, old, paths, factual[target])
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        weeks = [r["week"] for r in target_rows]
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "featureNames": feature_names,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
