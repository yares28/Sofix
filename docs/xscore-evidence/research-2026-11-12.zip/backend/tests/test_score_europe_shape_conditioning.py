"""Testing only: Euro and merged formation histories are explicit, complete ablations."""

import numpy as np
import pytest

from app.research import score_europe_shape_conditioning as conditioning
from app.research import score_europe_shape_history as history


def test_european_shape_six_ablations_keep_sources_and_personal_aa_distinct():
    groups = conditioning.feature_groups(history.NAMES)
    assert len(groups) == 6
    for source in ("euro", "combined"):
        structural, aa, all_columns = (groups[source + "_" + name] for name in ("structural", "aa", "all"))
        assert structural.sum() == 88 and aa.sum() == 14 and all_columns.sum() == 102
        assert not (structural & aa).any()
        np.testing.assert_array_equal(structural | aa, all_columns)
        assert all(
            n.startswith("europe_shape_" + source + "_aa_") for n, yes in zip(history.NAMES, aa, strict=True) if yes
        )
    assert not (groups["euro_all"] & groups["combined_all"]).any()
    assert (groups["euro_all"] | groups["combined_all"]).all()
    with pytest.raises(ValueError, match="schema"):
        conditioning.feature_groups(list(history.NAMES)[::-1])
