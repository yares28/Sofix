"""Independent pinned raw-shot and every-player provider-quality qualification audit."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research import score_postshot_probe as study


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_postshot_probe.json"))
    args = parser.parse_args()
    original = (args.cache / "shot_style_observations.json.gz").read_bytes()
    raw, built = args.games.read_bytes(), (args.cache / "postshot_observations.json.gz").read_bytes()
    report = json.loads(args.out.read_text())
    key = hashlib.sha256(
        raw + original + Path(study.__file__).read_bytes() + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if (
        hashlib.sha256(original).hexdigest() != "31f5b36e6bddabeec8a143ebfe21ac213a6bfe7b3fd58f4c92be1f014191ab47"
        or hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(built).hexdigest() != report["observationsSHA"]
        or key != report["implementationKey"]
    ):
        raise ValueError("Pinned post-shot source/implementation changed")
    parent = json.loads(gzip.decompress(original))
    actual = json.loads(gzip.decompress(built))
    if actual["key"] != key:
        raise ValueError("Post-shot observations identify different implementation")
    records = {(r["game"], r["player"]): r for r in actual["records"]}
    if len(records) != len(actual["records"]) or len(records) != 34871:
        raise ValueError("Complete unique source player coverage required")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    people = defaultdict(list)
    for r in parent["players"]:
        people[r["game"], r["club"]].append(r)

    def tokens(name):
        ascii_text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii").lower()
        return tuple(re.findall(r"[a-z]+", ascii_text))

    def is_quality(v):
        return type(v) in (float, int) and math.isfinite(v) and 0 <= v <= 1

    nshots, nfixtures = 0, set()
    raw_side = {}
    parsed = {}
    collisions = {}
    counts, reasons, years = Counter(), Counter(), defaultdict(Counter)
    for side in parent["sides"]:
        path = side["sourcePath"]
        if path not in parsed:
            source = (args.repo / path).read_bytes().replace(b"\r\n", b"\n")
            blob = hashlib.sha1(b"blob " + str(len(source)).encode() + b"\0" + source).hexdigest()
            if blob != side["sourceBlob"]:
                raise ValueError("Pinned actual detail source blob differs")
            text = source.decode("utf-8")
            parsed[path] = json.loads(text[text.index("{") :].strip().removesuffix(";"))
        g = games[side["game"]]
        canonical_side = "home" if g["home"]["slug"] == side["club"] else "away"
        shots = [s for s in parsed[path]["shots"] if s["team"] == canonical_side]
        if shots != side["shots"]:
            raise ValueError("Every cached raw shot differs from pinned actual detail")
        identity = side["game"], side["club"]
        raw_side[identity] = shots
        actor_names = {r["sourcePlayer"] for r in people[identity] if r["sourcePlayer"]} | {
            s["player"] for s in shots if s.get("player")
        }
        surname_count = Counter(tokens(n)[-1] for n in actor_names if tokens(n))
        collisions[identity] = {n for n in actor_names if tokens(n) and surname_count[tokens(n)[-1]] > 1}
        nshots += len(shots)
        nfixtures.add(side["game"])
    for source in parent["players"]:
        identity = source["game"], source["club"]
        name = tokens(source["sourcePlayer"] or "")
        shots = [s for s in raw_side[identity] if tokens(s["player"]) == name]
        p = games[source["game"]]["players"][source["player"]]
        n = float(p["stats"].get("ontarget_scoring_att", [0, 0])[0])
        quality = [s for s in shots if is_quality(s.get("xgot_fotmob"))]
        errors = []
        if not source["known"]:
            errors.append("parent_identity_or_stream_unknown")
        if source["sourcePlayer"] in collisions[identity]:
            errors.append("same_side_surname_collision")
        if any(s.get("xgot_fotmob") is not None and not is_quality(s["xgot_fotmob"]) for s in shots):
            errors.append("invalid_provider_quality")
        if len(quality) != n:
            errors.append("provider_count_differs_native_sot")
        if any(s["xgot_fotmob"] > 0 and s.get("onTarget") is not True for s in quality):
            errors.append("positive_postshot_on_offtarget")
        known = not errors
        total = sum(s["xgot_fotmob"] for s in quality) if known else None
        before = (
            sum(s["xg_fotmob"] for s in quality)
            if known and all(is_quality(s.get("xg_fotmob")) for s in quality)
            else None
        )
        expected = {k: source[k] for k in ("game", "date", "player", "club", "cohort", "minutes", "sourcePlayer")}
        expected.update(
            known=known,
            reasons=errors,
            nativeSOT=n,
            providerCount=len(quality),
            postshotTotal=total,
            matchedPreshotTotal=before,
            postshotPerTarget=total / n if known and n > 0 else None,
            placementPerTarget=(total - before) / n if known and before is not None and n > 0 else None,
            zeroOrigin="native_no_sot_derived_zero" if known and n == 0 else None,
        )
        r = records[source["game"], source["player"]]
        if set(r) != set(expected):
            raise ValueError("Raw qualification field coverage differs")
        for k, v in expected.items():
            if type(v) in (float, int) and type(v) is not bool:
                np.testing.assert_allclose(r[k], v, rtol=0, atol=1e-12)
            elif r[k] != v:
                raise ValueError("Independent raw qualification differs: " + k)
        local = Counter(
            records=1,
            nativeSOT=int(n),
            known=int(known),
            knownNativeSOT=int(n) if known else 0,
            knownPositiveSOT=int(known and n > 0),
            pairedPositiveSOT=int(expected["placementPerTarget"] is not None),
            derivedZeroSOT=int(expected["zeroOrigin"] is not None),
        )
        counts.update(local)
        reasons.update(errors)
        years[source["date"][:4]].update(local)
    summary = dict(
        counts=dict(counts),
        reasons=dict(reasons),
        years={y: dict(v) for y, v in years.items()},
        sameSideSurnameCollisionNames=sum(map(len, collisions.values())),
    )
    if summary != report["summary"]:
        raise ValueError("Independent source totals differ")
    receipt = dict(
        implementationKey=key,
        actualRawFixturesVerified=len(nfixtures),
        rawSidesVerified=len(raw_side),
        everyRawShotVerified=nshots,
        independentPlayerQualification=len(records),
        sourceSummaryVerified=True,
        observationsSHA=report["observationsSHA"],
        status="COMPLETE independent source/identity/nativecount/nullability/qualification audit; no accuracy claim",
    )
    args.out.with_suffix(".integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("POSTSHOT_SOURCE_AUDIT " + json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
