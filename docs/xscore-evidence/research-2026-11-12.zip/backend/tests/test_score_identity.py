import copy

import numpy as np
import pytest

from app.research.score_identity import category_values, density_choice, score_bins
from tests.test_score_search import game


def test_density_choice_selects_likely_outcome_and_does_not_average_two_peaks():
    probability = np.array([[0.6, 0.4], [0.3, 0.7]])
    scores = density_choice(probability, np.array([8, 16]))
    assert abs(scores[0] - 40) <= 7
    assert abs(scores[1] - 80) <= 7


def test_category_identity_uses_playing_side_and_not_actual_performance():
    g = game("2025-10-12T20:00:00Z", 40)
    rows = [{"player": "player", "game": "a", "pos": "MID"}]
    before = category_values(rows, [g])
    changed = copy.deepcopy(g)
    changed["players"]["player"].update(score=99, mins=1, aa=64)
    np.testing.assert_array_equal(before, category_values(rows, [changed]))
    assert before.tolist() == [["player", "home", "away", "MID"]]


def test_new_player_category_remains_present_and_unknown_side_is_rejected():
    g = game("2025-10-12T20:00:00Z", 40)
    g["players"]["debut"] = g["players"].pop("player")
    rows = [{"player": "debut", "game": "a", "pos": "MID"}]
    assert category_values(rows, [g])[0, 0] == "debut"
    g["players"]["debut"]["team"] = "unrelated-club"
    with pytest.raises(ValueError, match="side"):
        category_values(rows, [g])


def test_zero_and_score_cap_are_valid_targets():
    assert score_bins(np.array([0, 35, 60, 100])).tolist() == [0, 7, 12, 20]
