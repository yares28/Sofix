from copy import deepcopy

import numpy as np

from app.research import score_postshot_features as post


def fixture():
    games, records = [], []
    dates = [
        "2025-12-01T12:00:00Z",
        "2025-12-08T12:00:00Z",
        "2025-12-15T12:00:00Z",
        "2025-12-22T12:00:00Z",
        "2026-01-03T12:00:00Z",
    ]
    for i, date in enumerate(dates):
        games.append(
            dict(
                id=f"g{i}",
                date=date,
                players={
                    "p": dict(
                        played=True,
                        ver=7,
                        pos="FWD",
                        mins=90,
                        team="A",
                        stats={"ontarget_scoring_att": [1, 3], "goals": [0, 0]},
                    )
                },
            )
        )
        records.append(
            dict(
                game=f"g{i}",
                date=date,
                player="p",
                minutes=90,
                known=i != 2,
                nativeSOT=1.0,
                postshotTotal=0.4 if i != 2 else None,
                matchedPreshotTotal=0.2 if i != 2 else None,
            )
        )
    rows = [dict(game="g4", player="p", date=dates[-1])]
    return rows, games, records


def test_choose_native_window_before_qualified_source_and_keep_missing_case():
    x, names, _ = post.build_features(*fixture())
    assert x.shape == (1, 24)
    assert x[0, names.index("postshot_3_native_games")] == 3
    assert x[0, names.index("postshot_3_known_games")] == 2
    assert x[0, names.index("postshot_10_known_games")] == 3
    assert x[0, names.index("postshot_3_source_minutes_fraction")] == 2 / 3
    assert x[0, names.index("postshot_3_postshot_per_sot")] == 0.4


def test_zero_sot_history_has_zero_total_rate_but_no_placement_average():
    args = fixture()
    for g in args[1]:
        g["players"]["p"]["stats"] = {}
    for r in args[2]:
        r.update(nativeSOT=0, known=True, postshotTotal=0, matchedPreshotTotal=0)
    x, names, _ = post.build_features(*args)
    assert x[0, names.index("postshot_3_postshot90")] == 0
    assert np.isnan(x[0, names.index("postshot_3_postshot_per_sot")])
    assert np.isnan(x[0, names.index("postshot_3_paired_preshot_per_sot")])
    assert np.isnan(x[0, names.index("postshot_3_age_days")])


def test_current_stats_minutes_and_source_quality_do_not_enter_earlier_forecast():
    args = fixture()
    expected, _, _ = post.build_features(*args)
    changed = deepcopy(args)
    changed[1][-1]["players"]["p"].update(mins=999, stats={"goals": [99, 0]})
    changed[2][-1].update(known=True, postshotTotal=99, matchedPreshotTotal=99)
    actual, _, _ = post.build_features(*changed)
    np.testing.assert_array_equal(actual, expected)


def test_exact48hour_availability_is_not_available_and_cold_player_retained():
    args = fixture()
    args[1][-2]["date"] = args[2][-2]["date"] = "2025-12-31T14:00:00Z"
    args[0].append(dict(game="g4", player="unknown", date="2026-01-03T12:00:00Z"))
    x, names, _ = post.build_features(*args)
    assert x.shape == (2, 24)
    assert x[0, names.index("postshot_10_native_games")] == 3
    assert x[1, names.index("postshot_10_native_games")] == 0
    assert np.isnan(x[1, names.index("postshot_10_postshot90")])
