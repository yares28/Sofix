import numpy as np
import pytest

from app.research.score_local_errors import CENTRES, FitNormaliser, LocalErrors, mass


def test_weighted_native_boundary_floor_and_cap_match_direct_score_counting():
    errors = np.array([-100, -7, 7, 7.001, 100])
    weights = np.array([1, 2, 3, 4, 5])
    for level in (0, 35, 60, 100):
        for location in (-5, 10):
            expected_scores = np.clip(np.maximum(level if level >= 60 else 0, level + location + errors), 0, 100)
            expected = ((np.abs(expected_scores[:, None] - CENTRES) <= 7) * weights[:, None]).sum(
                axis=0
            ) / weights.sum()
            np.testing.assert_allclose(mass(errors, weights, [location], level, 1)[0], expected, atol=1e-15)
    with pytest.raises(ValueError, match="Known errors"):
        mass([np.nan], [1], [0], 35, 1)


def test_fit_normalisation_keeps_zero_distinct_from_missing_and_future_is_inert():
    normaliser = FitNormaliser().fit([[0, np.nan], [2, 1]])
    original = normaliser.transform([[0, 0]])
    normaliser.transform([[100000, np.nan]])
    np.testing.assert_equal(original, normaliser.transform([[0, 0]]))
    assert not np.array_equal(original, normaliser.transform([[0, np.nan]]))


def records(future_error=999):
    return {
        "available": np.array([1, 2, 100]),
        "error": np.array([-10, 10, future_error]),
        "position": np.array(["FWD"] * 3),
        "level": np.array([35] * 3),
        "player": np.array(["own", "peer", "future"]),
        "x": np.zeros((3, 4)),
    }


def test_future_labels_exact_cutoff_empty_level_and_position_fallback_keep_all_cases():
    specs = {"pool": {"kind": "pooled", "spread": 1}}
    parts = {q: np.zeros((2, 1)) for q in (0.35, 0.5, 0.65)}
    left = LocalErrors(records(999), 50)
    right = LocalErrors(records(-999), 50)
    args = (np.zeros((2, 1)), np.array([60]), np.ones((2, 1)), parts, "GK", ["cold", "other"], 100, specs)
    a, audit = left.predict_group(*args)
    b, _ = right.predict_group(*args)
    np.testing.assert_equal(a["pool"], b["pool"])
    assert len(a["pool"]) == 2 and audit["earlierErrors"] == 2
    assert audit["positionFallback"] is True and audit["emptyLevelFallbacks"] == 1


def test_own_player_weight_can_choose_a_different_whole_score_mode():
    parts = {q: np.zeros((1, 1)) for q in (0.35, 0.5, 0.65)}
    data = records()
    data["available"][2] = 3
    data["error"][2] = 10
    data["player"][2] = "peer2"
    specs = {
        "one": {"kind": "local", "k": 50, "own": 1, "prior": 0.01, "spread": 1},
        "eight": {"kind": "local", "k": 50, "own": 8, "prior": 0.01, "spread": 1},
    }
    model = LocalErrors(data, 50)
    predicted, _ = model.predict_group(
        np.zeros((1, 1)), np.array([35]), np.ones((1, 1)), parts, "FWD", ["own"], 50, specs
    )
    assert 38 <= predicted["one"][0] <= 52
    assert 18 <= predicted["eight"][0] <= 32


def test_calibration_labels_wait_exactly_forty_eight_hours_and_unknown_class_is_not_imputed():
    from app.research.score_local_errors_run import calibration_records
    from app.research.score_search import moment

    rows = [
        {"date": "2026-01-06T14:00:00Z", "pos": "FWD", "player": "old", "level": 35, "aa": 0},
        {"date": "2026-01-07T14:00:00Z", "pos": "FWD", "player": "boundary", "level": 35, "aa": 99},
        {"date": "2026-01-01T14:00:00Z", "pos": "FWD", "player": "unknown", "level": 100, "aa": 4},
    ]
    parts = (np.array([35]), np.ones((3, 1)), {q: np.zeros((3, 1)) for q in (0.35, 0.5, 0.65)})
    bank, unknown = calibration_records(rows, np.zeros((3, 1)), parts)
    assert unknown == 1 and len(bank["error"]) == 2
    lock = moment("2026-01-09T14:00:00Z").timestamp()
    assert bank["available"][1] == lock
    model = LocalErrors(bank, lock)
    result, evidence = model.predict_group(
        np.zeros((1, 1)),
        np.array([35]),
        np.ones((1, 1)),
        {q: np.zeros((1, 1)) for q in (0.35, 0.5, 0.65)},
        "FWD",
        ["target"],
        lock,
        {"pool": {"kind": "pooled", "spread": 1}},
    )
    assert evidence["earlierErrors"] == 1
    assert 28 <= result["pool"][0] <= 42
