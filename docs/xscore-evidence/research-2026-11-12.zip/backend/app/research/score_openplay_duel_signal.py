"""Paired comparison of LaLiga forecasts with and without detailed contest history."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_component_replacement import EVENT_KEY, native_values
from app.research.score_duel_game_spread import intervals, observation_losses, past_surprises
from app.research.score_openplay_duel_features import FEATURES, PAIR_FIELDS, features_for, read_contests
from app.research.score_opposition_strength import MATCHUP_KEY
from app.research.score_physical_duel_signal import MATCHUP_FIELDS, fitted
from app.research.score_search import POSITIONS, cutoff_for, moment
from app.research.score_shared_error_recovery import NATIVE_SHA, compare, snapshots
from app.research.score_stats_run import paired_interval

FACTORS = {"GK": 0.0, "DEF": 3.5, "MID": 1.6, "FWD": 2.0}
MODELS = ("logistic", "nonlinear")
ARMS = ("typesAndZones", "withNamedAerialOpponents")


def native_archive(path):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Native archive fingerprint differs")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.splitlines() if line.strip())}
    if len(games) != 1238:
        raise ValueError("Native fixture coverage differs")
    return games


def prelock_features(args, source, games):
    directory = args.cache / "openplay-data-v0.1.0"
    receipt = json.loads((args.out.parent / "laliga_score_openplay_duel_source.json").read_text())
    if receipt["sourceKey"] != source["key"] or receipt["nativeSha256"] != NATIVE_SHA:
        raise ValueError("Contest source differs")
    contests = read_contests(directory, receipt, games)
    rows = source["rows"]
    features = features_for(rows, games, contests)
    later = [r for r in rows if r["date"] >= "2026-01-01"]
    lock = min(cutoff_for(r["date"]) for r in later)
    cases = [i for i, r in enumerate(rows) if cutoff_for(r["date"]) == lock]
    eligible = {key for key, g in games.items() if moment(g["date"]) + timedelta(hours=48) < lock}
    visible = eligible | {rows[i]["game"] for i in cases}
    kept = {key: games[key] for key in visible}
    # For current cases retain only side identification. Strip scores, minutes and all actual participants
    # except those whose forecast identity must be provided to the feature builder.
    current = {}
    for i in cases:
        row = rows[i]
        g = games[row["game"]]
        stub = current.setdefault(row["game"], {k: g[k] for k in ("id", "date", "home", "away")} | {"players": {}})
        stub["players"][row["player"]] = {"team": g["players"][row["player"]]["team"]}
    kept.update(current)
    no_future = {key: v for key, v in contests.items() if key in eligible}
    reduced = features_for([rows[i] for i in cases], kept, no_future)
    np.testing.assert_array_equal(features[cases], reduced)
    np.savez_compressed(
        directory / "strict_past_duel_features.npz",
        sourceKey=source["key"],
        pairSha=receipt["pairedArtifactSha256"],
        names=FEATURES,
        x=features,
    )
    return features, {
        "allCases": len(rows),
        "first2026LockCasesRebuiltWithoutTargetData": len(cases),
        "unavailableContestFixturesRemoved": len(contests) - len(no_future),
    }


def control_inputs(args, source):
    with np.load(args.cache / "matchup_features.npz") as f:
        if str(f["key"]) != MATCHUP_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Control matchup source differs")
        x = f["x"][:, [f["names"].tolist().index(n) for n in MATCHUP_FIELDS]]
    with np.load(args.cache / "event_intensity_features.npz") as f:
        if str(f["key"]) != EVENT_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Control forecast minutes source differs")
        minutes = f["x"][:, f["names"].tolist().index("event_expected_minutes")]
    return x, minutes


def component_metrics(counts, p, historical_p, selected):
    use = selected & np.isfinite(counts).all(axis=1) & (counts.sum(axis=1) > 0)
    w, lost = counts[use].T
    q = p[use]
    per_case = (w * (1 - q) ** 2 + lost * q**2) / (w + lost)
    conditional, _ = observation_losses(w, w + lost, q, None, historical_p[use])
    return use, np.column_stack((per_case, conditional[:, 1:].mean(axis=1)))


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads((args.cache / "cases.json").read_text())
    games = native_archive(args.games)
    features, audit = prelock_features(args, source, games)
    old_x, minutes = control_inputs(args, source)
    read = lambda name: json.loads((args.out.parent / f"{name}.json").read_text())
    report = {
        "sourceKey": source["key"],
        "scope": "Test only, reused historical outcomes",
        "featureAudit": audit,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        scope = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r, ok in zip(source["rows"], scope, strict=True) if ok]
        row_ids = {(r["game"], r["player"]): i for i, r in enumerate(rows)}
        if len(row_ids) != len(rows):
            raise ValueError("Nonunique native case")
        pos = np.array([r["pos"] for r in rows])
        available = np.array([(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rows])
        locks = np.array([cutoff_for(r["date"]).timestamp() for r in rows])
        if (available <= locks).any():
            raise ValueError("Outcome available by own lock")
        sides, counts, match_x = [], [], []
        names = source["features"]
        for r in rows:
            game = games[r["game"]]
            person = game["players"][r["player"]]
            club, home, away = person["team"], game["home"]["slug"], game["away"]["slug"]
            if r["date"] != game["date"] or club not in (home, away):
                raise ValueError("Native fixture or side differs")
            sides.append((club, away if club == home else home))
            label = native_values(r, person)
            counts.append(label[3:] if r["pos"] != "GK" else [np.nan, np.nan])
            match_x.append([float(club == home), r["x"][names.index("match_lam_a" if club == home else "match_lam_h")]])
        counts = np.array(counts, dtype=float)
        native_known = counts[pos != "GK"]
        if (
            not np.isfinite(native_known).all()
            or (native_known < 0).any()
            or not np.array_equal(native_known, np.rint(native_known))
        ):
            raise ValueError("Native outfield counts must be nonnegative integers")
        m = old_x[scope]
        expected = m[:, MATCHUP_FIELDS.index("expected_duel_fraction")]
        own = m[:, MATCHUP_FIELDS.index("own_duel_fraction")]
        historical_p = np.clip(
            np.where(np.isfinite(expected), expected, np.where(np.isfinite(own), own, 0.5)), 0.02, 0.98
        )
        prior = past_surprises(rows, sides, counts, historical_p, available, locks)
        projected = (
            (m[:, MATCHUP_FIELDS.index("own_duel_won90")] + m[:, MATCHUP_FIELDS.index("own_duel_lost90")])
            * minutes[scope]
            / 90
        )
        base_x = np.column_stack((match_x, m, projected, prior, *[pos == p for p in POSITIONS]))
        detail = features[scope]
        typed = detail[:, : -len(PAIR_FIELDS)]
        matrices = {ARMS[0]: np.column_stack((base_x, typed)), ARMS[1]: np.column_stack((base_x, detail))}
        known = (detail[:, FEATURES.index("player_games")] >= 3) | (detail[:, FEATURES.index("opponent_games")] >= 3)
        usable_patch = known & np.isfinite(projected) & (pos != "GK")
        references = snapshots(args, source, rows, cohort, read)
        records = {(m, a): {"periods": {}, "values": [], "weeks": []} for m in MODELS for a in ARMS}
        chosen = []
        for phase, (subset, score_reference, *_unused) in references.items():
            if phase == "later2026":
                passing = [
                    key for key, r in records.items() if all(p["score"]["net"] > 0 for p in r["periods"].values())
                ]
                if passing:
                    chosen = [
                        max(
                            passing,
                            key=lambda key: (
                                min(p["score"]["net"] for p in records[key]["periods"].values()),
                                sum(p["score"]["net"] for p in records[key]["periods"].values()),
                            ),
                        )
                    ]
                args.out.with_suffix(f".{cohort}.selection.json").write_text(json.dumps({"chosen": chosen}))
                active = chosen
            else:
                active = list(records)
            if not active:
                continue
            ids = np.array([row_ids[r["game"], r["player"]] for r in subset])
            target = np.zeros(len(rows), dtype=bool)
            target[ids] = True
            if not np.array_equal(ids, np.flatnonzero(target)):
                raise ValueError("Target case order differs")
            fit = available < locks[target].min()
            if (fit & target).any():
                raise ValueError("Target outcomes entered fit")
            y = np.array([r["score"] for r in subset])
            weeks = np.array([r["week"] for r in subset])
            primary = pos[ids] == "DEF" if cohort == "start" else pos[ids] != "GK"
            factor = np.array([FACTORS[p] for p in pos[ids]])
            old = {}
            for model, arm in active:
                if model not in old:
                    old[model] = np.clip(fitted(base_x, counts, fit, target, model)["probability"], 0.01, 0.99)
                p0 = old[model]
                blanked = np.where(fit[:, None], counts, np.nan)
                p1 = np.clip(fitted(matrices[arm], blanked, fit, target, model)["probability"], 0.01, 0.99)
                # Retain the control where this player's fixture has too little pre-lock source history.
                p1 = np.where(known[ids], p1, p0)
                group, old_loss = component_metrics(counts[ids], p0, historical_p[ids], primary)
                _, new_loss = component_metrics(counts[ids], p1, historical_p[ids], primary)
                increment = np.zeros(len(ids))
                active_cases = usable_patch[ids]
                increment[active_cases] = factor[active_cases] * projected[ids][active_cases] * (p1 - p0)[active_cases]
                forecast = np.clip(score_reference + increment, 0, 100)
                record = records[model, arm]
                record["periods"][phase] = {
                    "all": len(ids),
                    "earlierFitRows": int(fit.sum()),
                    "primaryLabelledGames": int(group.sum()),
                    "sourceCases": int(active_cases.sum()),
                    "componentErrorControlAndNew": [old_loss.mean(axis=0).tolist(), new_loss.mean(axis=0).tolist()],
                    "pointMoveP50P95P99": np.quantile(np.abs(increment), [0.5, 0.95, 0.99]).tolist(),
                    "score": compare(y, score_reference, forecast, np.ones(len(y), dtype=bool)),
                    "weekGain95": paired_interval(y, forecast, score_reference, weeks.tolist()),
                }
                if phase != "later2026":
                    record["values"].append(old_loss - new_loss)
                    record["weeks"].append(weeks[group])
                print(cohort, phase, model, arm, record["periods"][phase]["score"]["net"], flush=True)
        report["cohorts"][cohort] = {
            "chosen": chosen,
            "candidates": {
                f"{model}/{arm}": {
                    "periods": r["periods"],
                    "pairedComponentGain95": intervals(
                        np.concatenate(r["values"]), np.concatenate(r["weeks"])
                    ).tolist(),
                }
                for (model, arm), r in records.items()
            },
        }
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_duel_signal.json"))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
