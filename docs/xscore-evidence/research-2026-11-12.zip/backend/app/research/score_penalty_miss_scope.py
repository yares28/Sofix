"""Measure existing forecast misses around observed penalty events, for diagnosis only."""

import hashlib
import json

import numpy as np

from app.research.score_absence_clock_pilot import NATIVE, NATIVE_SHA, ROOT, coverage_ceiling
from app.research.score_absence_role_signal import REPORTS
from app.research.score_failure_review import summary

REFERENCES = {
    "start": ("team_share", "d66dd32e242a419580610b05ab06eea8dd29c873c76a7d30cd9bb0a374f3190a", 6754, 2765),
    "bench": ("mixture_shrunk", "04f46a9b7f9709260ec765b80c00701db41a8bc3078d7684c6c1557f33a7f610", 2925, 2201),
}


def has_event(source, field):
    count = source.get("stats", {}).get(field, (0, 0))[0]
    if type(count) not in (int, float) or count < 0 or int(count) != count:
        raise ValueError("Unexpected recorded penalty event count")
    return count > 0


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] >= "2026-01-01"}
    rows = [r for r in json.loads((ROOT / "cases.json").read_bytes())["rows"] if r["date"] >= "2026-01-01"]
    flags, matches, same_side = {}, set(), set()
    for r in rows:
        g = games[r["game"]]
        player = g["players"][r["player"]]
        assert player["played"] and player["score"] == r["score"] and player["started"] == (r["cohort"] == "start")
        count = player["pen"]
        assert type(count) is int and count >= 0
        took = count > 0
        saved = has_event(player, "penalty_save")
        won = has_event(player, "penalty_won")
        conceded = has_event(player, "penalty_conceded")
        flags[r["game"], r["player"]] = (took, took or saved or won or conceded)
        if took:
            matches.add(r["game"])
            same_side.add((r["game"], player["team"]))
    output = dict(
        nativeSHA=NATIVE_SHA,
        fixtureCount=len(games),
        fixturesWithRecordedPenaltyTaker=len(matches),
        outcomesUsedOnlyForDiagnosis=True,
        cohorts={},
        wholeFixtureCeiling=coverage_ceiling(rows, matches),
        interpretation="These scopes describe recorded events. The ceilings assume perfect repairs within the named "
        "scope, no changes outside it, and no lost hits. A real formula can also change predictions in other games. "
        "The export represents unavailable counts as zero and event association does not establish cause.",
    )
    for cohort, (stem, key, n, hits) in REFERENCES.items():
        selected = [r for r in rows if r["cohort"] == cohort]
        with np.load(ROOT / f"laliga_score_{stem}_predictions_{cohort}.npz") as saved:
            assert str(saved["key"]) == key
            y, pred = saved["y"], saved["prediction"]
        np.testing.assert_array_equal(y, [r["score"] for r in selected])
        assert len(selected) == n and np.sum(abs(y - pred) <= 7) == hits
        pairs = np.array([flags[r["game"], r["player"]] for r in selected])
        taking_team = np.array(
            [(r["game"], games[r["game"]]["players"][r["player"]]["team"]) in same_side for r in selected]
        )
        output["cohorts"][cohort] = {
            label: summary(y[mask], pred[mask])
            for label, mask in (
                ("all", np.ones(n, dtype=bool)),
                ("taker", pairs[:, 0]),
                ("directlyInvolved", pairs[:, 1]),
                ("takingTeam", taking_team),
            )
        }
    (REPORTS / "laliga_score_penalty_miss_scope.json").write_text(json.dumps(output, indent=2) + "\n")
    for cohort, groups in output["cohorts"].items():
        print(cohort, {k: (g["n"], g["misses"], g["errorAbove25"]) for k, g in groups.items()})
    print(output["wholeFixtureCeiling"])


if __name__ == "__main__":
    main()
