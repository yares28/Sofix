"""Audit early team forecasts and evaluate every earlier fixture."""

import hashlib
import json
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_absence_role_audit import lock_time
from app.research.score_absence_team_audit import compare_mappings, replacement
from app.research.score_absence_team_earlier import STEM, score
from app.research.score_absence_team_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT, fit
from app.research.score_card_cycle import PHASES
from app.research.score_search import moment


def audit_forecasts():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = sorted(
        (g for g in map(json.loads, raw.splitlines()) if g["date"] < "2025-07-01"),
        key=lambda g: (g["date"], g["id"]),
    )
    index = {g["id"]: g for g in games}
    clocks = {g["id"]: moment(g["date"]) + timedelta(days=2) for g in games}
    clubs, team_histories, played = {}, defaultdict(list), defaultdict(list)
    for g in games:
        i = g["id"]
        clubs[i] = tuple(g[s]["slug"] for s in ("home", "away"))
        for club in clubs[i]:
            team_histories[club].append(i)
        for person, p in g["players"].items():
            if p["played"] is True and p["ver"] == 7:
                played[person].append((i, p["team"]))
    cases = json.loads((ROOT / "cases.json").read_text())
    names = cases["features"]
    columns = tuple(names.index(n) for n in ("match_lam_h", "match_lam_a"))
    anchors = {}
    for r in cases["rows"]:
        xy = tuple(r["x"][j] for j in columns)
        assert anchors.setdefault(r["game"], xy) == xy
    card_path = REPORTS / "laliga_score_card_cycle.forecasts.json"
    card = json.loads(card_path.read_text())
    trusted = json.loads((REPORTS / "laliga_score_card_cycle.json").read_text())
    assert hashlib.sha256(card_path.read_bytes()).hexdigest() == trusted["forecastSHA"]
    forecast_path = REPORTS / f"{STEM}.forecasts.json"
    forecast = json.loads(forecast_path.read_text())
    assert forecast["cardCycleKey"] == trusted["key"] == card["key"]
    assert forecast["sourceKey"] == cases["key"]
    flags = defaultdict(dict)
    for v in card["predictions"]:
        if v["phase"] in forecast["phases"] and v["status"] == "timely":
            flags[v["target"], v["club"]][v["player"]] = v
    prepared = {}
    for phase, values in forecast["phases"].items():
        begin, end = PHASES[phase]
        target = [g for g in games if begin <= g["date"] < end]
        lock = min(lock_time(g["date"]) for g in target)
        allowed = [g for g in games if g["date"] < begin and clocks[g["id"]] < lock]
        assert [g["id"] for g in allowed] == values["fittedFixtures"]
        fx, beta, names, teams, _ = fit(allowed, {g["id"]: anchors[g["id"]] for g in allowed})
        npz = ROOT / f"{STEM}_{phase}.npz"
        assert hashlib.sha256(npz.read_bytes()).hexdigest() == values["arraySHA"]
        with np.load(npz) as a:
            np.testing.assert_array_equal(a["beta"], beta)
            np.testing.assert_array_equal(a["names"], names)
            np.testing.assert_array_equal(a["clubs"], teams)
            arrays = a["rates"]
        actual_checked = 0
        matched = []
        for j, (g, item) in enumerate(zip(target, values["vectors"], strict=True)):
            game_id = g["id"]
            lock = lock_time(g["date"])
            assert item["game"] == game_id and item["lock"] == lock.isoformat()
            effects, exact = [], True
            any_removed = False
            for k, club in enumerate(clubs[game_id]):
                past = [i for i in team_histories[club] if clocks[i] < lock][-3:]
                observed = defaultdict(list)
                for i in past:
                    for p, v in index[i]["players"].items():
                        if v["played"] is True and v["team"] == club:
                            assert v["ver"] == 7
                            observed[p].append((v["pos"], v["mins"]))
                base = {p: (v[-1][0], sum(m for _, m in v) / len(past)) for p, v in observed.items()}
                proof = item["clubs"][k]
                assert proof["projectedPastGames"] == len(past)
                compare_mappings(base, proof["baseline"])
                reported = flags[game_id, club]
                removals, exclude = set(), set(reported)
                for p, (_, mins) in base.items():
                    prior = [c for i, c in played[p] if clocks[i] < lock]
                    if not prior or prior[-1] != club:
                        exclude.add(p)
                    elif p in reported and mins >= 15:
                        assert clocks[reported[p]["origin"]] < lock
                        removals.add(p)
                assert sorted(removals) == item["removed"][k]
                any_removed |= bool(removals)
                placebo = set()
                for p in sorted(removals, key=lambda n: (-base[n][1], n)):
                    role, mins = base[p]
                    options = [
                        (abs(n - mins), q)
                        for q, (pos, n) in base.items()
                        if pos == role and abs(n - mins) <= 15 and q not in exclude | placebo
                    ]
                    if options:
                        placebo.add(min(options)[1])
                assert sorted(placebo) == item["placeboRemoved"][k]
                exact &= len(placebo) == len(removals)
                changes = []
                for label, anonymous, selection in (
                    ("proposal", "anonymousProposal", removals),
                    ("placebo", "anonymousPlacebo", placebo),
                ):
                    next_roster, unknown = replacement(base, selection)
                    compare_mappings(next_roster, proof[label])
                    assert unknown.keys() == proof[anonymous].keys()
                    for role, minutes in unknown.items():
                        np.testing.assert_allclose(minutes, proof[anonymous][role], rtol=0, atol=1e-8)
                    change = sum(
                        (
                            np.array(fx.get(p, (0.0, 0.0))) * (next_roster.get(p, ("", 0))[1] - base[p][1]) / 90
                            for p in base
                        ),
                        np.zeros(2),
                    )
                    changes.append(change)
                effects.append(changes)
            assert item["completelyMatchedPlacebo"] == (exact and any_removed)
            matched.extend([exact and any_removed] * 2)
            actual_checked += any_removed
            a = np.array(anchors[game_id])
            h, w = effects
            predicted = [a, *[np.clip(a * np.exp([h[k][0] + w[k][1], w[k][0] + h[k][1]]), 0.05, 8.0) for k in range(2)]]
            np.testing.assert_allclose(predicted, arrays[j], rtol=0, atol=1e-12)
            np.testing.assert_array_equal(item["rates"], arrays[j])
        assert actual_checked == values["affectedFixtures"]
        prepared[phase] = (target, arrays, np.array(matched), actual_checked)
        print(phase, len(target), "independent rate reconstructions", flush=True)
    return prepared, hashlib.sha256(forecast_path.read_bytes()).hexdigest()


def main():
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    prepared, source = audit_forecasts()
    summaries, pool = {}, []
    for phase, (target, arrays, matched, changed) in prepared.items():
        actual = np.array([[g["homeGoals"], g["awayGoals"]] for g in target])
        weeks = np.repeat([lock_time(g["date"]).isoformat() for g in target], 2)
        summaries[phase] = dict(
            fixtures=len(target),
            affected=changed,
            matchedFixtures=int(matched.sum() // 2),
            metrics=score(arrays, actual, weeks, matched),
        )
        pool.append((arrays, actual, weeks, matched))
    pooled = score(*(np.concatenate(v) for v in zip(*pool, strict=True)))
    metrics = ("poisson", "cleanSheetBrier")
    rules = dict(
        eachPeriodBothBetter=all(
            p["metrics"][m]["interventionVsControl"]["gain"] > 0 for p in summaries.values() for m in metrics
        ),
        pooledLowerBoundPositive=any(pooled[m]["interventionVsControl"]["week95Interval"][0] > 0 for m in metrics),
        matchedPlaceboBeat=pooled["poisson"]["matchedInterventionVsPlacebo"]["gain"] > 0,
    )
    report = dict(
        forecastsSHA=source,
        phases=summaries,
        pooled=pooled,
        gate=rules,
        passes=all(rules.values()),
        independentRefits=2,
        reconstructedFixtures=580,
        later2026Evaluated=False,
        autumnPublishedPreviewTestPreserved=True,
    )
    (REPORTS / f"{STEM}.json").write_text(json.dumps(report, indent=2) + "\n")
    result = {phase: {k: v["interventionVsControl"] for k, v in p["metrics"].items()} for phase, p in summaries.items()}
    print(json.dumps(dict(phases=result, pooled=pooled, gate=rules, passed=report["passes"]), indent=2))


if __name__ == "__main__":
    main()
