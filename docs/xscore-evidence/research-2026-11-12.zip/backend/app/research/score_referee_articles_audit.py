"""Independent parser audit of all collected announcement dates and literal PDF links."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from zoneinfo import ZoneInfo

from app.research import score_referee_articles as primary
from app.research.score_referee_source_audit import Published


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.pdfs = set()

    def handle_starttag(self, tag, attrs):
        href = dict(attrs).get("href", "")
        if tag != "a" or not urlsplit(href).path.lower().endswith(".pdf"):
            return
        url = urljoin("https://rfef.es/", href)
        split = urlsplit(url)
        if (
            split.scheme != "https"
            or split.netloc not in ["rfef.es", "www.rfef.es"]
            or not split.path.startswith("/sites/default/files/")
        ):
            raise ValueError("Unexpected document source")
        self.pdfs.add(url)


def main():
    folder = Path("data/raw/score-foundation/referee-source")
    reports = Path("reports/experiments")
    manifest = (folder / "archive_article_manifest.json").read_bytes()
    result = json.loads((reports / "laliga_score_referee_articles.json").read_text())
    if hashlib.sha256(manifest).hexdigest() != result["articleManifestSHA"]:
        raise ValueError("Announcement manifest changed")
    key = hashlib.sha256(Path(primary.__file__).read_bytes() + manifest + result["indexKey"].encode()).hexdigest()
    if key != result["implementationKey"]:
        raise ValueError("Announcement catalogue implementation changed")
    entries = {e["File"]: e for e in json.loads(manifest.decode("utf-8-sig"))}
    expected = json.loads((folder / "archive_article_requests.json").read_text())
    if len(entries) != len(expected) or {e["Url"] for e in entries.values()} != {e["Url"] for e in expected}:
        raise ValueError("Entire selected archive request coverage differs")
    requests = json.loads((folder / "archive_pdf_requests.json").read_text())
    requested = {r["Url"]: r for r in requests}
    all_links = set()
    checked = 0
    for row in result["records"]:
        if row["status"] == "unreadable_article":
            if row["Status"] == "downloaded" or row["pdfURLs"]:
                raise ValueError("Unreadable source silently received document links")
            continue
        raw = (folder / row["file"]).read_bytes()
        entry = entries[row["file"]]
        sha = hashlib.sha256(raw).hexdigest()
        if sha != row["sha256"] or sha != entry["SHA256"].lower():
            raise ValueError("Official announcement bytes changed")
        text = raw.decode("utf-8")
        clock = Published()
        clock.feed(text)
        stamp = "".join(clock.content).strip().split(", ", 1)[1]
        date = datetime.strptime(stamp, "%d/%m/%Y - %H:%M").replace(tzinfo=ZoneInfo("Europe/Madrid"))
        if (
            date.date().isoformat() != entry["CatalogueDate"]
            or date.astimezone(UTC).isoformat() != row["publicationUTC"]
        ):
            raise ValueError("Independent original article publication differs")
        parser = Links()
        parser.feed(text)
        if sorted(parser.pdfs) != row["pdfURLs"]:
            raise ValueError("Independent literal linked document coverage differs")
        for url in parser.pdfs:
            if url not in requested:
                raise ValueError("Document request missing")
            parent = dict(File=row["file"], SHA256=sha, PublicationUTC=row["publicationUTC"], URL=row["url"])
            if parent not in requested[url]["Parents"]:
                raise ValueError("Source parent identity changed")
        all_links.update(parser.pdfs)
        checked += 1
    if set(requested) != all_links or len(requests) != len(all_links):
        raise ValueError("Extra or duplicate document requests")
    receipt = dict(
        status="COMPLETE independent announcement publication and document-link audit",
        implementationKey=key,
        selectedArticleCases=len(expected),
        independentlyVerifiedReadableArticles=checked,
        uniqueLinkedDocuments=len(all_links),
        originalCapturedReceiptNotEstablished=True,
        modelFits=0,
    )
    (reports / "laliga_score_referee_articles.integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("REFEREE_ARTICLES_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
