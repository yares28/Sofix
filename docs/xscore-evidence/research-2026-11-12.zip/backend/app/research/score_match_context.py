"""Testing-only provider chance quality and observed match intensity, strictly lagged."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import unicodedata
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

from app.research.score_feature_compare import compare_features
from app.research.score_search import cutoff_for, moment

CLUBS = {
    "Almeria": "almeria-almeria",
    "Athletic Club": "athletic-club-bilbao",
    "Atletico Madrid": "atletico-madrid-madrid",
    "Barcelona": "barcelona-barcelona",
    "Cadiz": "cadiz-cadiz",
    "Celta Vigo": "celta-de-vigo-vigo",
    "Deportivo A Coruna": "deportivo-la-coruna-a-coruna",
    "Deportivo Alaves": "deportivo-alaves-vitoria-gasteiz",
    "Elche": "elche-elche",
    "Espanyol": "espanyol-barcelona",
    "Getafe": "getafe-getafe-madrid",
    "Girona": "girona-girona",
    "Granada": "granada-granada",
    "Las Palmas": "las-palmas-las-palmas-de-gran-canaria",
    "Leganes": "leganes-leganes",
    "Levante": "levante-valencia",
    "Malaga": "malaga-malaga",
    "Mallorca": "mallorca-palma-de-mallorca",
    "Osasuna": "osasuna-pamplona-irunea",
    "Racing Santander": "racing-santander-santander",
    "Rayo Vallecano": "rayo-vallecano-madrid",
    "Real Betis": "real-betis-sevilla",
    "Real Madrid": "real-madrid-madrid",
    "Real Oviedo": "real-oviedo-oviedo",
    "Real Sociedad": "real-sociedad-donostia-san-sebastian",
    "Real Valladolid": "real-valladolid-valladolid",
    "Sevilla": "sevilla-sevilla-1890",
    "Valencia": "valencia-valencia",
    "Villarreal": "villarreal-villarreal",
}
FIELDS = (
    "xg_for",
    "xg_against",
    "ppda",
    "box_for",
    "box_against",
    "possession",
    "shots_for",
    "shots_against",
    "sot_for",
    "sot_against",
    "passes",
    "pass_accuracy",
)


def normalise(value):
    return re.sub("[^a-z]", "", unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower())


def number(value):
    return (
        float(value)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and np.isfinite(value)
        else np.nan
    )


def season_year(date):
    return int(date[:4]) - (int(date[5:7]) < 7)


def read_calendar(path):
    aliases = {
        "Ath Bilbao": "Athletic Club",
        "Ath Madrid": "Atletico Madrid",
        "Betis": "Real Betis",
        "Celta": "Celta Vigo",
        "Espanol": "Espanyol",
        "Vallecano": "Rayo Vallecano",
        "Sociedad": "Real Sociedad",
        "Valladolid": "Real Valladolid",
        "Alaves": "Deportivo Alaves",
        "Oviedo": "Real Oviedo",
        "Santander": "Racing Santander",
        "La Coruna": "Deportivo A Coruna",
    }
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    fixtures = []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for r in csv.DictReader(handle):
            if not r.get("Date") or r.get("FTHG") in (None, "") or r.get("FTAG") in (None, ""):
                continue
            day = datetime.strptime(r["Date"], "%d/%m/%Y").date().isoformat()
            sides = [clubs.get(normalise(aliases.get(r[k], r[k]))) for k in ("HomeTeam", "AwayTeam")]
            if None in sides:
                raise ValueError("Unmapped historical calendar club")
            fixtures.append(
                {
                    "date": day + "T23:59:59Z",
                    "home": {"slug": sides[0]},
                    "away": {"slug": sides[1]},
                    "homeGoals": int(r["FTHG"]),
                    "awayGoals": int(r["FTAG"]),
                }
            )
    return fixtures


def parse_source(payload, targets):
    clubs = {normalise(k): v for k, v in CLUBS.items()}
    local = defaultdict(list)
    for g in targets:
        local[season_year(g["date"]), g["home"]["slug"], g["away"]["slug"]].append(g)
    covered_seasons = {season_year(g["date"]) for g in targets}
    audit = {
        "sourceGames": 0,
        "overlap": 0,
        "correctedDates": 0,
        "ambiguousFixture": 0,
        "unmatchedCoveredSeason": 0,
        "scoreConflicts": 0,
        "unknownClub": 0,
        "keptGames": 0,
        "officialChancePairs": 0,
        "providerCounts": {"fotmob": 0, "understat": 0},
    }
    games, seen = [], set()
    for season in payload["seasons"].values():
        for raw in season["matches"]:
            if raw.get("played") is not True:
                continue
            audit["sourceGames"] += 1
            sides = [clubs.get(normalise(raw.get(side, ""))) for side in ("home", "away")]
            if None in sides:
                audit["unknownClub"] += 1
                continue
            identity = season_year(raw["date"]), *sides
            if identity in seen:
                raise ValueError("Duplicate source fixture")
            seen.add(identity)
            matches = local.get(identity, [])
            if len(matches) > 1:
                audit["ambiguousFixture"] += 1
                continue
            actual = matches[0] if matches else None
            if actual is None and identity[0] in covered_seasons:
                audit["unmatchedCoveredSeason"] += 1
                continue
            if actual:
                audit["overlap"] += 1
                audit["correctedDates"] += actual["date"][:10] != raw["date"][:10]
                if all(actual.get(k) is not None for k in ("homeGoals", "awayGoals")) and (
                    raw.get("hs"),
                    raw.get("as"),
                ) != (actual["homeGoals"], actual["awayGoals"]):
                    audit["scoreConflicts"] += 1
                    continue
            # Known local kickoff is authoritative; otherwise date-only end-of-day is conservative.
            at = actual["date"] if actual else raw["date"][:10] + "T23:59:59Z"
            metrics = np.full((2, len(FIELDS)), np.nan)
            providers = []
            for provider in ("fotmob", "understat"):
                pair = np.array([number(raw.get(f"xg_{side}_{provider}")) for side in ("home", "away")])
                if np.isfinite(pair).all():
                    providers.append(pair)
                    audit["providerCounts"][provider] += 1
            if providers:
                pair = np.mean(providers, axis=0)
                metrics[:, 0], metrics[:, 1] = pair, pair[::-1]
                audit["officialChancePairs"] += 1
            stats = raw.get("stats") or {}
            for i, side in enumerate(("home", "away")):
                metrics[i, 2] = number(raw.get("ppda_" + side))
                for j, key, index in ((3, "box", i), (4, "box", 1 - i)):
                    pair = raw.get(key)
                    metrics[i, j] = number(pair[index]) if isinstance(pair, list) and len(pair) == 2 else np.nan
                for j, key, index in (
                    (5, "possession", i),
                    (6, "shots", i),
                    (7, "shots", 1 - i),
                    (8, "sot", i),
                    (9, "sot", 1 - i),
                    (10, "passes", i),
                    (11, "pass_acc", i),
                ):
                    pair = stats.get(key)
                    metrics[i, j] = number(pair[index]) if isinstance(pair, list) and len(pair) == 2 else np.nan
            games.append(
                {"date": at, "available": moment(at) + timedelta(hours=48), "sides": sides, "metrics": metrics}
            )
    audit["keptGames"] = len(games)
    return games, audit


def context_features(rows, targets, external):
    indexed = {g["id"]: g for g in targets}
    names = ["own_recent_games", "own_source_age", "opponent_recent_games", "opponent_source_age"]
    for side in ("own", "opponent"):
        for n in (3, 10):
            names += [f"{side}_{n}_{field}_{stat}" for field in FIELDS for stat in ("mean", "sd", "count")]
    extra = np.full((len(rows), len(names)), np.nan)
    order = sorted(range(len(rows)), key=lambda i: cutoff_for(rows[i]["date"]))
    queue = sorted(external, key=lambda g: g["available"])
    history = defaultdict(list)
    by_fixture_side = {}
    cursor = 0
    for i in order:
        row = rows[i]
        cutoff = cutoff_for(row["date"])
        while cursor < len(queue) and queue[cursor]["available"] < cutoff:
            game = queue[cursor]
            for j, club in enumerate(game["sides"]):
                history[club].append((moment(game["date"]), game["metrics"][j]))
            cursor += 1
        target = indexed[row["game"]]
        sides = [target[s]["slug"] for s in ("home", "away")]
        own = target["players"][row["player"]]["team"]
        if own not in sides:
            raise ValueError("Target playing side differs from fixture")
        key = row["game"], own, cutoff
        if key in by_fixture_side:
            extra[i] = by_fixture_side[key]
            continue
        other = sides[1 - sides.index(own)]
        groups = [[g for g in history[club] if cutoff - g[0] <= timedelta(days=180)] for club in (own, other)]
        values = [
            value
            for group in groups
            for value in (len(group), (cutoff - group[-1][0]).total_seconds() / 86400 if group else np.nan)
        ]
        for group in groups:
            for n in (3, 10):
                a = np.array([g[1] for g in group[-n:]]) if group else np.empty((0, len(FIELDS)))
                for j in range(len(FIELDS)):
                    observed = a[np.isfinite(a[:, j]), j]
                    values += [
                        float(observed.mean()) if len(observed) else np.nan,
                        float(observed.std()) if len(observed) else np.nan,
                        len(observed),
                    ]
        extra[i] = values
        by_fixture_side[key] = extra[i].copy()
    metadata = {
        "inputs": len(names),
        "historyDays": 180,
        "delayHours": 48,
        "ownChanceCovered": int(np.isfinite(extra[:, names.index("own_3_xg_for_mean")]).sum()),
        "opponentChanceCovered": int(np.isfinite(extra[:, names.index("opponent_3_xg_for_mean")]).sum()),
    }
    return extra, names, metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "games", "archive", "control", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--calendar", type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    games = [json.loads(line) for line in args.games.read_text(encoding="utf-8").splitlines() if line.strip()]
    raw = args.archive.read_bytes()
    payload = json.loads(raw.decode("utf-8").split("=", 1)[1].strip().rstrip(";"))
    calendar = read_calendar(args.calendar)
    external, audit = parse_source(payload, games + calendar)
    extra, names, metadata = context_features(source["rows"], games, external)
    metadata["sourceAudit"] = audit
    metadata["laterCoverage"] = {}
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        metadata["laterCoverage"][cohort] = {
            "n": int(selected.sum()),
            "ownChanceCovered": int(np.isfinite(extra[selected, names.index("own_3_xg_for_mean")]).sum()),
        }
    key = hashlib.sha256(
        raw + Path(__file__).read_bytes() + args.games.read_bytes() + args.calendar.read_bytes()
    ).hexdigest()
    np.savez_compressed(args.cache / "match_context_features.npz", key=key, x=extra, names=names)
    args.out.with_suffix(".source-audit.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("Source audit " + json.dumps(metadata), flush=True)
    if args.audit_only:
        return
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    with np.load(args.stats_cache) as stored:
        numeric, stat_key = stored["x"], str(stored["key"])
    groups = {
        "official_chances": np.array(["xg_" in n or "recent_games" in n or "source_age" in n for n in names]),
        "chances_and_intensity": np.ones(len(names), dtype=bool),
    }
    compare_features(args, source, numeric, stat_key, extra, names, groups, key, metadata)


if __name__ == "__main__":
    main()
