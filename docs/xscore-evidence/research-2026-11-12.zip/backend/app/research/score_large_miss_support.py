"""Research-only accounting of large errors and already-known outcome support."""

from __future__ import annotations

import argparse
import hashlib
import json
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_failure_review import activity_groups, summary
from app.research.score_search import cutoff_for, measure, moment


def similar_count(values, target):
    return int((np.abs(np.asarray(values) - target) <= 7).sum())


def event_state(level):
    return -1 if level < 35 else 0 if level == 35 else 1


def history_summary(past, score, aa):
    out = {"count": len(past)}
    for size in (10, 30):
        recent = past[-size:]
        scores, activity = [r["score"] for r in recent], [r["aa"] for r in recent]
        out[f"similarScore{size}"] = similar_count(scores, score) if recent else None
        out[f"similarAA{size}"] = similar_count(activity, aa) if recent else None
        out[f"minAA{size}"] = min(activity) if recent else None
        out[f"maxAA{size}"] = max(activity) if recent else None
    return out


def player_histories(rows):
    by_player = defaultdict(list)
    for row in rows:
        by_player[row["player"], row["cohort"]].append(row)
    for values in by_player.values():
        values.sort(key=lambda r: (r["date"], r["game"]))
    times = {k: [moment(r["date"]) + timedelta(hours=48) for r in values] for k, values in by_player.items()}
    return [
        by_player[r["player"], r["cohort"]][: bisect_left(times[r["player"], r["cohort"]], cutoff_for(r["date"]))]
        for r in rows
    ]


def support_stats(rows, history, keep):
    indices = np.flatnonzero(keep)
    result = {"n": len(indices), "withoutHistory": sum(not history[i] for i in indices)}
    for size, minimum in ((10, 5), (30, 10)):
        eligible = [i for i in indices if len(history[i]) >= minimum]
        result[f"previous{size}"] = {
            "eligible": len(eligible),
            "actualScoreHadSimilarPastScore": sum(
                similar_count([p["score"] for p in history[i][-size:]], rows[i]["score"]) > 0 for i in eligible
            ),
            "actualAAHadSimilarPastAA": sum(
                similar_count([p["aa"] for p in history[i][-size:]], rows[i]["aa"]) > 0 for i in eligible
            ),
            "actualScoreHadSimilarPastScoreSameEventState": sum(
                similar_count(
                    [
                        p["score"]
                        for p in history[i][-size:]
                        if event_state(p["level"]) == event_state(rows[i]["level"])
                    ],
                    rows[i]["score"],
                )
                > 0
                for i in eligible
            ),
            "anyPastSameEventState": sum(
                any(event_state(p["level"]) == event_state(rows[i]["level"]) for p in history[i][-size:])
                for i in eligible
            ),
            "actualAAAboveAllPastAA": sum(rows[i]["aa"] > max(p["aa"] for p in history[i][-size:]) for i in eligible),
            "actualAABelowAllPastAA": sum(rows[i]["aa"] < min(p["aa"] for p in history[i][-size:]) for i in eligible),
        }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--reports", type=Path, default=Path("reports/experiments"))
    parser.add_argument("--games", type=Path, required=True)
    args = parser.parse_args()
    source = json.loads((args.cache / "cases.json").read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    native = {
        (g["id"], player): p
        for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())
        for player, p in g["players"].items()
    }
    for row in source["rows"]:
        p = native[row["game"], row["player"]]
        if (
            p["ver"] != 7
            or not p["played"]
            or p["started"] != (row["cohort"] == "start")
            or any(abs(p[k] - row[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Native case outcome mismatch")
    histories = player_histories(source["rows"])
    output = {
        "sourceKey": source["key"],
        "nativeCasesVerified": len(source["rows"]),
        "warning": "Hindsight diagnostic, not new forecast accuracy. Similar past scores show historical support, not ability to identify which future match will repeat one. No history exclusions from accuracy denominators.",
        "cohorts": {},
    }
    for cohort, name in (("start", "laliga_score_team_share"), ("bench", "laliga_score_mixture_shrunk")):
        indices = [i for i, r in enumerate(source["rows"]) if r["cohort"] == cohort and r["date"] >= "2026-01-01"]
        rows, history = [source["rows"][i] for i in indices], [histories[i] for i in indices]
        report = json.loads((args.reports / (name + ".json")).read_text())
        with np.load(args.cache / f"{name}_predictions_{cohort}.npz") as f:
            if str(f["key"]) != report["implementationKey"] or report["sourceKey"] != source["key"]:
                raise ValueError("Strongest prediction key mismatch")
            prediction = f["prediction"]
            np.testing.assert_array_equal(f["y"], np.array([r["score"] for r in rows]))
        y, aa, level = (np.array([r[k] for r in rows]) for k in ("score", "aa", "level"))
        if measure(y, prediction) != report["cohorts"][cohort]["later"]:
            raise ValueError("Strongest native forecast metrics mismatch")
        large = np.abs(y - prediction) > 25
        neutral = level == 35
        result = {
            "overall": summary(y, prediction),
            "largeMisses": summary(y[large], prediction[large]),
            "largeByActualEvent": {
                name: summary(y[large & mask], prediction[large & mask])
                for name, mask in (
                    ("normalBase", neutral),
                    ("positiveEvent", level >= 60),
                    ("negativeEvent", level < 35),
                )
            },
            "supportAllLarge": support_stats(rows, history, large),
            "supportLargeNormalBase": support_stats(rows, history, large & neutral),
            "supportAllMissesNormalBase": support_stats(rows, history, (np.abs(y - prediction) > 7) & neutral),
            "examples": [],
        }
        for kind, mask in (
            ("normalBaseUnder", large & neutral & (y > prediction)),
            ("normalBaseOver", large & neutral & (y < prediction)),
            ("positiveEventUnder", large & (level >= 60) & (y > prediction)),
        ):
            eligible = sorted(
                (i for i in np.flatnonzero(mask) if len(history[i]) >= 10), key=lambda i: -abs(y[i] - prediction[i])
            )
            for i in eligible[:2]:
                row = rows[i]
                actual_groups = activity_groups(native[row["game"], row["player"]]["stats"])
                previous_groups = [activity_groups(native[p["game"], p["player"]]["stats"]) for p in history[i][-3:]]
                previous = {name: float(np.mean([g[name] for g in previous_groups])) for name in actual_groups}
                result["examples"].append(
                    {
                        "type": kind,
                        "player": row["player"],
                        "date": row["date"],
                        "position": row["pos"],
                        "forecast": float(prediction[i]),
                        "actual": float(y[i]),
                        "actualBaseEventScore": float(level[i]),
                        "actualAA": float(aa[i]),
                        "actualMinutes": row["minutes"],
                        "pastSupport": history_summary(history[i], y[i], aa[i]),
                        "actualActivityGroups": actual_groups,
                        "previous3MeanActivityGroups": previous,
                        "activityGroupChange": {name: actual_groups[name] - previous[name] for name in actual_groups},
                        "majorNativeEventCounts": {
                            s: native[row["game"], row["player"]]["stats"].get(s, [0, 0])[0]
                            for s in (
                                "goals",
                                "goal_assist",
                                "clean_sheet_60",
                                "red_card",
                                "own_goals",
                                "penalty_conceded",
                                "error_lead_to_goal",
                            )
                        },
                    }
                )
        output["cohorts"][cohort] = result
        print(
            "SUPPORT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "largeByEvent": result["largeByActualEvent"],
                    "allLarge": result["supportAllLarge"],
                    "normalLarge": result["supportLargeNormalBase"],
                }
            ),
            flush=True,
        )
    (args.reports / "laliga_score_large_miss_support.json").write_text(json.dumps(output, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
