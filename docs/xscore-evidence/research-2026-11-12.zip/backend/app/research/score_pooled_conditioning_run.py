"""Testing only: shared native European training versus domestic-only training."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_analogues as analogues
from app.research import score_density_blend as density
from app.research import score_density_blend_run as reference_runner
from app.research import score_empirical_density as empirical
from app.research import score_europe_ordinary as euro_ordinary
from app.research import score_europe_routine as routine
from app.research import score_europe_routine_history as routine_history
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_pooled_conditioning as conditioning
from app.research import score_pooled_history as history
from app.research import score_quantile_curve as curve
from app.research import score_shared_windows as normalising
from app.research import score_stability as stability
from app.research import score_stats_hybrid as conditional
from app.research import score_team_shape_conditioning_run as policy_runner
from app.research import score_team_shape_history as modal
from app.research import score_windows as windows
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval

REPORTS = (
    "laliga_score_match_context",
    "laliga_score_stability",
    "laliga_score_ordinary",
    "laliga_score_match_empirical_density",
    "laliga_score_analogues",
)


def implementation_key(source, feature_key, reports, plan, sklearn_version):
    modules = (
        conditioning,
        history,
        routine_history,
        routine,
        euro_ordinary,
        modal,
        policy_runner,
        density,
        reference_runner,
        empirical,
        flow,
        controls,
        ordinary,
        curve,
        normalising,
        stability,
        windows,
        conditional,
        analogues,
    )
    return hashlib.sha256(
        (
            source["key"]
            + feature_key
            + sklearn_version
            + "".join(reports[n]["implementationKey"] for n in sorted(reports))
        ).encode()
        + Path(__file__).read_bytes()
        + plan.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()


def fitted(x, aa, levels, queries, cohort, begin, first, classes, group, target_indices, canonical, mask, path, key):
    ds_fit, aa_fit, weights, receipt = conditioning.training_masks(
        queries, aa, levels, cohort, begin, first, classes, conditioning.GROUPS[group]
    )
    if not np.array_equal(ds_fit[canonical], mask["fit"]) or not np.array_equal(aa_fit[canonical], mask["fit"]):
        raise ValueError("Shared training changed canonical domestic phase-fit cases")
    if path.exists():
        with np.load(path) as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["ds_fit"], ds_fit)
                or not np.array_equal(f["aa_fit"], aa_fit)
                or not np.array_equal(f["weights"], weights)
                or not np.array_equal(f["target_indices"], target_indices)
                or json.loads(str(f["receipt"])) != receipt
            ):
                raise ValueError("Shared native model cache source-fit masks/weights differ")
        return components(path, key), receipt
    result = conditioning.fitted_components(x, aa, levels, ds_fit, aa_fit, weights, target_indices, classes)
    np.savez_compressed(
        path,
        key=key,
        classes=result[0],
        probability=result[1],
        **{f"q{q}": a for q, a in result[2].items()},
        ds_fit=ds_fit,
        aa_fit=aa_fit,
        weights=weights,
        target_indices=target_indices,
        receipt=json.dumps(receipt, sort_keys=True),
    )
    return result, receipt


def candidates():
    return [
        dict(spec=dict(group=g, policy=p, spread=s, weight=w, scope=c), gains=[], errors=[], counts=[], periods={})
        for g in conditioning.GROUPS
        for p in ("both", "ordinary", "events")
        for s in (0.75, 1)
        for w in (0.25, 0.5, 1)
        for c in ("all", "defmid")
    ]


def load_shared(args, source):
    report = json.loads(args.history_report.read_text())
    audit = json.loads(args.history_report.with_suffix(".integrity.json").read_text())
    if (
        report["sourceKey"] != source["key"]
        or report["featureKey"] != audit["featureKey"]
        or not audit["all226ColumnsReproduced"]
        or audit["independentFeatureRows"] != 95852
        or audit["canonicalCases"] != len(source["rows"])
        or audit["first2026LockCasesUnchanged"] != 310
        or not audit["all6754Starts2925PlayedSubsRetained"]
    ):
        raise ValueError("Full independent shared source/feature audit required before fitting")
    plan = json.loads(args.out.with_suffix(".plan.json").read_text())
    if report["featureKey"] not in plan["featureStage"]:
        raise ValueError("Shared feature source differs from registered formula plan")
    with np.load(args.history_cache) as f:
        if str(f["key"]) != report["featureKey"] or tuple(f["names"]) != history.NAMES:
            raise ValueError("Shared input identity/schema differs")
        x, canonical = f["x"], f["canonical_indices"]
    payload = json.loads(gzip.decompress(args.history_cache.with_suffix(".queries.json.gz").read_bytes()))
    raw = args.routine_cache.with_suffix(".observations.json.gz").read_bytes()
    corpus = json.loads(gzip.decompress(raw))
    if (
        payload["key"] != report["featureKey"]
        or hashlib.sha256(raw).hexdigest() != report["routineCorpusSha256"]
        or corpus["key"] != report["routineFeatureKey"]
    ):
        raise ValueError("Shared native training query/corpus source changed")
    queries = payload["queries"]
    lookup = {(r["game"], r["player"]): r for r in corpus["records"]}
    records = [lookup[q["game"], q["player"]] for q in queries]
    aa = np.array([r["ordinary"]["point"] if r["ordinary"]["kind"] == "exact" else np.nan for r in records])
    levels = np.array([r["level"] for r in records])
    for i, row in zip(canonical, source["rows"], strict=True):
        if (
            any(queries[i][n] != row[n] for n in ("game", "player", "date", "pos", "cohort"))
            or aa[i] != row["aa"]
            or levels[i] != row["level"]
        ):
            raise ValueError("Shared canonical native label identity differs")
    return report, x, canonical, queries, aa, levels


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "history-cache", "history-report", "routine-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    feature, x, canonical_all, queries, shared_aa, shared_levels = load_shared(args, source)
    reports = {n: json.loads((args.out.parent / (n + ".json")).read_text()) for n in REPORTS}
    if any(r["sourceKey"] != source["key"] for r in reports.values()):
        raise ValueError("Shared formula strongest original references use different source cases")
    key = implementation_key(
        source, feature["featureKey"], reports, args.out.with_suffix(".plan.json"), sklearn.__version__
    )
    report = dict(
        scope="Testing only, no application changes",
        sourceKey=source["key"],
        implementationKey=key,
        historyFeatureKey=feature["featureKey"],
        featureAuditVerified=True,
        evidenceLimit="Repeated retrospective reuse, exploratory not fresh blind proof",
        cohorts={},
    )
    if args.out.exists():
        old_report = json.loads(args.out.read_text())
        if old_report["implementationKey"] != key:
            raise ValueError("Existing shared formula report has a different frozen implementation")
        report = old_report
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        if cohort in report["cohorts"]:
            continue
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        canonical = canonical_all[keep]
        masks = stability.phase_masks(rows)
        records = candidates()
        prior, winner, best = None, None, None
        audit = {}
        for phase, begin, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(
                args,
                cohort,
                phase,
                reports["laliga_score_match_context"],
                reports["laliga_score_stability"],
                reports["laliga_score_ordinary"],
            )
            if phase == "later2026" and best is None:
                raise ValueError("Shared formula must freeze selection before final outcomes")
            active = [best] if phase == "later2026" else records
            current = {}
            audit[phase] = dict(fit=int(mask["fit"].sum()), target=int(target.sum()), groups={})
            for group in sorted({r["spec"]["group"] for r in active}):
                print(f"POOLED_FITTING {cohort} {phase} {group} inputs226", flush=True)
                current[group], receipt = fitted(
                    x,
                    shared_aa,
                    shared_levels,
                    queries,
                    cohort,
                    begin,
                    mask["first"],
                    old[0],
                    group,
                    canonical[target],
                    canonical,
                    mask,
                    args.cache / f"{args.out.stem}_{cohort}_{phase}_{group}.npz",
                    key,
                )
                audit[phase]["groups"][group] = receipt
            if prior is None:
                prior = (target_rows, old, current)
                continue
            previous_rows, previous_old, previous_new = prior
            base_mass, control, repeated_old, reference_receipt = reference_runner.reference(
                args, key, source, cohort, phase, masks, reports
            )
            if any(not np.array_equal(a, b) for a, b in zip(old[:2], repeated_old[:2], strict=True)):
                raise ValueError("Shared formula old reference components changed")
            metric = measure(y[target], control)
            expected = (
                reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else reports["laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"][
                    "cohorts"
                ][cohort]["later"]
            )
            if metric != expected:
                raise ValueError("Shared formula strongest original control did not reproduce")
            audit[phase].update(control=metric, reference=reference_receipt)
            for group in sorted({r["spec"]["group"] for r in active}):
                for policy in sorted({r["spec"]["policy"] for r in active if r["spec"]["group"] == group}):
                    pieces = policy_runner.component_policy(old, current[group], policy)
                    previous = policy_runner.component_policy(previous_old, previous_new[group], policy)
                    bank = policy_runner.bank_from(previous, previous_rows, mask["first"])
                    for spread in sorted(
                        {
                            r["spec"]["spread"]
                            for r in active
                            if r["spec"]["group"] == group and r["spec"]["policy"] == policy
                        }
                    ):
                        mass = conditioning.empirical_mass(*pieces, positions[target], bank, spread)
                        for record in [
                            r
                            for r in active
                            if r["spec"]["group"] == group
                            and r["spec"]["policy"] == policy
                            and r["spec"]["spread"] == spread
                        ]:
                            spec = record["spec"]
                            candidate, _ = density.forecast(
                                base_mass, mass, spec["weight"], control, positions[target], spec["scope"]
                            )
                            cm = measure(y[target], candidate)
                            if phase != "later2026":
                                gain = cm["within7"] - metric["within7"]
                                record["gains"].append(gain)
                                record["errors"].append(cm["mae"])
                                record["counts"].append(len(candidate))
                                record["periods"][phase] = dict(gain=gain, metrics=cm)
                            else:
                                alternate = candidate
                    print(f"POOLED_TESTED {cohort} {phase} {group} {policy}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = dict(
                    implementationKey=key,
                    winner=winner,
                    best=best,
                    candidates=records,
                    passingCandidates=sum(min(r["gains"]) > 0 for r in records),
                )
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("POOLED_FROZEN " + json.dumps(dict(cohort=cohort, winner=winner, best=best)), flush=True)
            prior = (target_rows, old, current)
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = abs(y[target] - control) <= 7, abs(y[target] - alternate) <= 7
        result = dict(
            selected="candidate" if winner else "control",
            winner=winner,
            candidate=best,
            candidateCount=len(records) + 1,
            earlierPeriods=audit,
            later=measure(y[target], prediction),
            candidateLater=measure(y[target], alternate),
            control=measure(y[target], control),
            candidateGain95=paired_interval(y[target], alternate, control, [r["week"] for r in target_rows]),
            candidateGainedCorrect=int((new_hit & ~old_hit).sum()),
            candidateLostCorrect=int((old_hit & ~new_hit).sum()),
            positions={
                p: dict(
                    candidate=measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    control=measure(y[target][positions[target] == p], control[positions[target] == p]),
                )
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            controlReproduced=True,
        )
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "POOLED_RESULT "
            + json.dumps(
                dict(
                    cohort=cohort,
                    selected=result["selected"],
                    later=result["later"],
                    candidateLater=result["candidateLater"],
                )
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
