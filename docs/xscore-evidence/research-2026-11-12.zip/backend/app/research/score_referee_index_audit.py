"""Independent HTML-parser checks for official referee archive completeness."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import date
from html.parser import HTMLParser
from pathlib import Path

from app.research import score_referee_index as primary


class Articles(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self.current = None
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "article":
            if self.current is not None:
                raise ValueError("Nested source articles")
            self.current = dict(titles=[], text=[])
        if self.current is not None and tag == "a" and "fw-bolder" in attrs.get("class", "").split():
            self.current["titles"].append(dict(path=attrs["href"], parts=[]))
            self.in_title = True

    def handle_endtag(self, tag):
        if tag == "a":
            self.in_title = False
        if tag == "article" and self.current is not None:
            self.rows.append(self.current)
            self.current = None

    def handle_data(self, data):
        if self.current is not None:
            self.current["text"].append(data)
            if self.in_title:
                self.current["titles"][-1]["parts"].append(data)


def main():
    folder = Path("data/raw/score-foundation/referee-source")
    path = Path("reports/experiments/laliga_score_referee_index.json")
    report = json.loads(path.read_text())
    manifests = {}
    entries = []
    for filename, digest in report["manifestHashes"].items():
        raw = (folder / filename).read_bytes()
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError("Source index manifest changed")
        manifests[filename] = digest
        data = json.loads(raw.decode("utf-8-sig"))
        entries.extend(data if isinstance(data, list) else [data])
    key = hashlib.sha256(
        Path(primary.__file__).read_bytes() + json.dumps(manifests, sort_keys=True).encode()
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Index parser key changed")
    rows = {}
    months = [
        "enero",
        "febrero",
        "marzo",
        "abril",
        "mayo",
        "junio",
        "julio",
        "agosto",
        "septiembre",
        "octubre",
        "noviembre",
        "diciembre",
    ]
    for entry in entries:
        if entry["Status"] != "downloaded":
            raise ValueError("Official archive index incomplete")
        raw = (folder / entry["File"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["SHA256"].lower():
            raise ValueError("Source index bytes changed")
        parser = Articles()
        parser.feed(raw.decode("utf-8"))
        for card in parser.rows:
            if len(card["titles"]) != 1:
                raise ValueError("Independent title count differs")
            source = card["titles"][0]
            title = " ".join(" ".join(source["parts"]).split())
            candidates = []
            for value in card["text"]:
                tokens = value.strip().lower().split()
                if len(tokens) == 3 and tokens[1] in months and tokens[0].isdigit() and tokens[2].isdigit():
                    candidates.append(date(int(tokens[2]), months.index(tokens[1]) + 1, int(tokens[0])).isoformat())
            if len(candidates) != 1:
                raise ValueError("Independent date parser differs")
            normalized = unicodedata.normalize("NFKD", title).encode("ascii", "ignore").decode().lower()
            eligible = any(v in normalized for v in ["designaciones", "estos son los arbitros"])
            eligible &= "primera division" in normalized
            eligible &= not any(
                v in normalized for v in ["femenina", "futbol sala", "segunda division", "primera federacion"]
            )
            record = dict(path=source["path"], title=title, date=candidates[0], appointment=eligible)
            if source["path"] in rows and rows[source["path"]] != record:
                raise ValueError("Independent duplicate index conflict")
            rows[source["path"]] = record
    if sorted(rows.values(), key=lambda r: (r["date"], r["path"])) != report["records"]:
        raise ValueError("Independent entire archive inventory differs")
    requests = json.loads((folder / "archive_article_requests.json").read_text())
    selected = [r for r in report["records"] if r["appointment"] and "2023-07-01" <= r["date"] < "2026-11-01"]
    if {r["Url"] for r in requests} != {"https://rfef.es" + r["path"] for r in selected} or len(requests) != len(
        selected
    ):
        raise ValueError("Article request coverage differs")
    first = (folder / entries[0]["File"]).read_text(encoding="utf-8")
    total = int(re.search(r'<span class="results">(\d+)</span>', first)[1])
    if len(rows) != total:
        raise ValueError("Official stated inventory count differs")
    receipt = dict(
        status="COMPLETE independent entire official archive inventory audit",
        implementationKey=key,
        officialStatedCards=total,
        independentlyParsedCards=len(rows),
        indexPages=len(entries),
        sourceArticleRequests=len(requests),
        outcomeDataRead=False,
        modelFits=0,
    )
    path.with_suffix(".integrity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("REFEREE_INDEX_AUDIT", json.dumps(receipt))


if __name__ == "__main__":
    main()
