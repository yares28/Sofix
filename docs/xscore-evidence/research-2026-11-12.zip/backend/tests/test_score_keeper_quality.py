from copy import deepcopy

import numpy as np

from app.research import score_keeper_quality as keeper


def fixture():
    games, sides = [], []
    for i, date in enumerate(
        [
            "2025-12-01T12:00:00Z",
            "2025-12-08T12:00:00Z",
            "2025-12-15T12:00:00Z",
            "2025-12-22T12:00:00Z",
            "2026-01-03T12:00:00Z",
        ]
    ):
        g = dict(
            id=f"g{i}",
            date=date,
            home=dict(slug="A"),
            away=dict(slug="B"),
            homeGoals=1,
            awayGoals=0,
            players={
                "ka": dict(team="A", played=True, ver=7, pos="GK", mins=90, stats={}),
                "kb": dict(
                    team="B", played=True, ver=7, pos="GK", mins=90, stats={"saves": [1, 2], "goals_conceded": [1, -5]}
                ),
            },
        )
        games.append(g)
        sides.extend(
            [
                dict(
                    game=f"g{i}",
                    club="A",
                    shots=[dict(xgot_fotmob=0.7, onTarget=True), dict(xgot_fotmob=0.5, onTarget=True)],
                ),
                dict(game=f"g{i}", club="B", shots=[]),
            ]
        )
    rows = [dict(game="g4", date=games[-1]["date"], x=[1])]
    return rows, games, sides, ["home"]


def test_quality_compares_native_saved_and_conceded_counts_and_not_model_field():
    _, games, sides, _ = fixture()
    source = keeper.qualify(games[0], "away", sides[0]["shots"])
    assert source["known"] and source["faced"] == 2 and source["postshot"] == 1.2
    missing = deepcopy(sides[0]["shots"])
    missing[0].update(xgot_fotmob=None, xgot_model=0.7)
    assert not keeper.qualify(games[0], "away", missing)["known"]


def test_own_goal_and_split_goalkeepers_make_quality_unknown():
    _, games, sides, _ = fixture()
    g = deepcopy(games[0])
    g["players"]["kb"]["stats"]["own_goals"] = [1, 0]
    assert "own_goal" in keeper.qualify(g, "away", sides[0]["shots"])["reasons"]
    g = deepcopy(games[0])
    g["players"]["other"] = dict(g["players"]["kb"], mins=1)
    assert "not_one_full90_keeper" in keeper.qualify(g, "away", sides[0]["shots"])["reasons"]


def test_projection_uses_past_keeper_and_native_window_before_quality():
    rows, games, sides, names = fixture()
    source = keeper.build_source(games, sides)
    next(r for r in source if r["game"] == "g2" and r["club"] == "B").update(known=False, postshot=None)
    x, fields, _ = keeper.build_features(rows, games, source, names)
    assert x.shape == (1, 24)
    assert x[0, fields.index("keeper_3_native_games")] == 3
    assert x[0, fields.index("keeper_3_qualified_games")] == 2
    assert x[0, fields.index("keeper_10_qualified_games")] == 3
    np.testing.assert_allclose(x[0, fields.index("keeper_3_keeper_goal_delta_per_faced")], -0.1)


def test_actual_future_keeper_minutes_source_and_xi_cannot_change_projection():
    rows, games, sides, names = fixture()
    source = keeper.build_source(games, sides)
    expected, _, _ = keeper.build_features(rows, games, source, names)
    changed_games, changed_source = deepcopy((games, source))
    changed_games[-1]["players"] = {
        "future_keeper": dict(team="B", pos="GK", played=True, ver=7, mins=9999, stats={"saves": [9999, 0]})
    }
    changed_games[-1]["xi"] = "future actual XI"
    for r in changed_source:
        if r["game"] == "g4":
            r.update(known=True, postshot=999, keeper="future_keeper")
    actual, _, _ = keeper.build_features(rows, changed_games, changed_source, names)
    np.testing.assert_array_equal(actual, expected)


def test_strict48hour_boundary_and_cold_club_keep_counts_zero_and_ability_unknown():
    rows, games, sides, names = fixture()
    games[-2]["date"] = "2025-12-31T14:00:00Z"
    source = keeper.build_source(games, sides)
    x, fields, _ = keeper.build_features(rows, games, source, names)
    assert x[0, fields.index("keeper_10_native_games")] == 3
    cold = [dict(game="g0", date=games[0]["date"], x=[1])]
    x, fields, _ = keeper.build_features(cold, games, source, names)
    assert x[0, fields.index("keeper_3_projected_keepers")] == 0
    assert x[0, fields.index("keeper_3_native_games")] == 0
    assert x[0, fields.index("keeper_3_qualified_games")] == 0
    assert x[0, fields.index("keeper_3_source_minutes_fraction")] == 0
    assert np.isnan(x[0, fields.index("keeper_3_keeper_goal_delta_per_faced")])


def test_independent_source_and_projected_profiles_match_actual_fixture_workflow():
    from app.research.score_keeper_quality_audit import reconstruct, source_check

    rows, games, sides, names = fixture()
    source = keeper.build_source(games, sides)
    independently_qualified = source_check(games, sides, source)
    actual, _, _ = keeper.build_features(rows, games, independently_qualified, names)
    expected = reconstruct(rows, games, source, names)
    np.testing.assert_allclose(actual, expected, rtol=0, atol=1e-12, equal_nan=True)
