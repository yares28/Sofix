import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))

from app.research import score_referee_signal as source


def test_all_outside_fit_labels_blank_leaves_both_paired_models_identical():
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(20261106)
    full = rng.normal(size=(240, 204))
    full[::13, 0] = np.nan
    full[::7, 195:] = np.nan
    counts = rng.integers(1, 9, size=(240, 2)).astype(float)
    fit, target = np.arange(240) < 180, np.arange(240) >= 180
    blind = counts.copy()
    blind[~fit] = np.nan
    for columns in [195, 204]:
        for architecture in ["logistic", "nonlinear"]:
            original = source.fitted(full[:, :columns], counts, fit, target, architecture)
            actual = source.fitted(full[:, :columns], blind, fit, target, architecture)
            np.testing.assert_array_equal(original["probability"], actual["probability"])
            assert original["missing_flag_width"] == 195
            if architecture == "logistic":
                assert len(original["coefficient"]) == columns + 195
