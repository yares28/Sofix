"""Audit current and preserved versions of coach appointment announcements."""

import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import Path

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_referee_archive import club_key
from app.research.score_search import cutoff_for

DIRECTORY = ROOT / "coach-source"


class Head(HTMLParser):
    def __init__(self):
        super().__init__()
        self.values = defaultdict(set)
        self.stopped = False
        self.headline = []
        self.in_headline = False
        self.headline_seen = False

    def handle_starttag(self, tag, attrs):
        if tag == "h1" and not self.headline_seen:
            self.in_headline = True
            self.headline_seen = True
        if self.stopped or tag != "meta":
            return
        attrs = dict(attrs)
        key = attrs.get("property") or attrs.get("name")
        if key in ("og:title", "article:published_time", "article:modified_time") and attrs.get("content"):
            self.values[key].add(attrs["content"])

    def handle_endtag(self, tag):
        if tag == "head":
            self.stopped = True
        if tag == "h1":
            self.in_headline = False

    def handle_data(self, data):
        if self.in_headline:
            self.headline.append(data)


def aware_time(value):
    stamp = datetime.fromisoformat(value)
    if "T" not in value:
        raise ValueError("Date without an exact article time")
    if stamp.tzinfo is None:
        # Use a conservative upper bound for all real civil-zone offsets.
        return stamp.replace(tzinfo=UTC) + timedelta(hours=14), "timezone_upper_bound"
    return stamp.astimezone(UTC), "explicit_timezone"


def inspect(body):
    header = Head()
    header.feed(body)
    values = header.values
    title = next(iter(values["og:title"]), "") if len(values["og:title"]) <= 1 else ""
    timestamps = {}
    for label, name in (("Published", "published"), ("Modified", "modified")):
        structured = set(re.findall(rf'"date{label}"\s*:\s*"([\dT:+.Z-]{{10,40}})"', body))
        og = values[f"article:{name}_time"]
        timestamps[name] = sorted(structured | og)
    headline = " ".join(" ".join(header.headline).split())
    return title[:200], headline[:200], timestamps


def version_clock(timestamps):
    found, mode = {}, set()
    try:
        for name in ("published", "modified"):
            observed = [aware_time(x) for x in timestamps[name]]
            if not observed or len({style for _, style in observed}) != 1:
                return None, "missing_or_ambiguous_article_clock"
            times = [t for t, _ in observed]
            if (max(times) - min(times)).total_seconds() >= 1:
                return None, "disagreeing_article_clocks"
            found[name] = max(times)
            mode.update(style for _, style in observed)
    except ValueError:
        return None, "missing_or_invalid_article_clock"
    if found["modified"] < found["published"]:
        return None, "revision_precedes_publication"
    return found["modified"], "revision_" + ("explicit_timezone" if mode == {"explicit_timezone"} else "upper_bound")


def visible_title_mentions(coach, title):
    normalized = club_key(title)
    person = coach.split(" (", 1)[0]
    return bool(normalized and club_key(person.split()[-1]) in normalized)


def load_json(path):
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    return value if isinstance(value, list) else [value]


def main():
    loc_path = REPORTS / "laliga_score_coach_discovery.json"
    locator = json.loads(loc_path.read_text())
    docs = locator["appointments"]
    paths = [DIRECTORY / n for n in ("appointment_manifest.json", "archive_appointment_manifest.json")]
    requested = [DIRECTORY / n for n in ("appointment_requests.json", "archive_appointment_requests.json")]
    output = defaultdict(list)
    for path, reqs, archive in zip(paths, requested, (False, True), strict=True):
        seen = load_json(path)
        plan = {r["url"]: r for r in load_json(reqs)}
        assert len({x["url"] for x in seen}) == len(seen) and all(r["url"] in plan for r in seen)
        for item in seen:
            index = item["index"]
            assert index == plan[item["url"]]["index"]
            result = dict(url=item["url"], archive=archive, downloadStatus=item.get("status", "failed"))
            if item.get("status") != 200:
                output[index].append(dict(result, status="download_failed"))
                continue
            source = Path(item["file"]).read_bytes()
            assert hashlib.sha256(source).hexdigest() == item["sha256"]
            body = source.decode("utf-8")
            title, headline, dates = inspect(body)
            coach = docs[index]["incomingCoach"]
            in_title = any(visible_title_mentions(coach, label) for label in (title, headline))
            if archive:
                observed = item.get("memento", [])
                expected = datetime.strptime(plan[item["url"]]["expectedCapture"], "%Y%m%d%H%M%S").replace(tzinfo=UTC)
                valid = len(observed) == 1 and parsedate_to_datetime(observed[0]) == expected
                t = expected if valid else None
                status = "verified_capture_header" if valid else "capture_header_missing_or_differs"
            else:
                t, status = version_clock(dates)
            output[index].append(
                dict(
                    result,
                    sha256=item["sha256"],
                    title=title,
                    headline=headline,
                    titleMatchesCoach=in_title,
                    status=status,
                    clock=t.isoformat() if t is not None else None,
                    articleTimestamps=dates,
                )
            )
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    fixtures = {g["id"]: g["date"] for g in map(json.loads, raw.splitlines())}
    rows = json.loads((ROOT / "cases.json").read_text())["rows"]
    windows, info = set(), []
    for i, doc in enumerate(docs):
        evidence = output.get(i, [])
        matching = [e for e in evidence if e.get("clock") and e["titleMatchesCoach"]]
        best = min((datetime.fromisoformat(e["clock"]) for e in matching), default=None)
        timely = [j for j in doc.get("candidateFixtures", []) if best and best < cutoff_for(fixtures[j])]
        windows.update(timely)
        info.append(
            dict(
                index=i,
                team=doc["team"],
                club=doc["club"],
                coach=doc["incomingCoach"],
                discoveryDate=doc["candidateDate"],
                candidateFixtures=doc.get("candidateFixtures", []),
                timelyClockAndTitleFixtureCandidates=timely,
                evidence=evidence,
            )
        )
    scope = {}
    for phase, (begin, end) in dict(PHASES, later2026=("2026-01-01", "2027-01-01")).items():
        group = [r for r in rows if begin <= r["date"] < end and r["game"] in windows]
        scope[phase] = dict(fixtures=len({r["game"] for r in group}), **dict(Counter(r["cohort"] for r in group)))
    report = dict(
        discoverySHA=hashlib.sha256(loc_path.read_bytes()).hexdigest(),
        manifests={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        byEvidenceStatus=dict(Counter(e["status"] for v in output.values() for e in v)),
        noticesWithTitleAndClock=sum(
            any(e.get("clock") and e["titleMatchesCoach"] for e in v) for v in output.values()
        ),
        preliminaryCoverage=scope,
        approvedFeatures=0,
        laterOutcomesEvaluated=False,
        limit="Title and timing evidence is not appointment scope proof. Confirm terms, effective start, temporary overlap "
        "and actual first-team role in the preserved notice before use.",
        appointments=info,
    )
    (REPORTS / "laliga_score_coach_clocks.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "appointments"}, indent=2))


if __name__ == "__main__":
    main()
