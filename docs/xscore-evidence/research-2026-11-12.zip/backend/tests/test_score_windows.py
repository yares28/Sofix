import numpy as np

from app.research.score_windows import window_centres


def test_score_is_in_a_winning_interval_even_for_two_separated_peaks():
    centres = np.arange(0, 101, 0.5)
    probability = np.zeros((1, len(centres)))
    probability[0, centres == 40] = 0.6
    probability[0, centres == 80] = 0.6
    assert window_centres(probability, centres)[0] in (40, 80)


def test_largest_interval_probability_wins_instead_of_average():
    assert window_centres(np.array([[0.6, 0.4], [0.1, 0.9]]), np.array([40, 80])).tolist() == [40, 80]
