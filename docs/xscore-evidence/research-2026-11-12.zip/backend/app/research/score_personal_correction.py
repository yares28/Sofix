"""Testing only: modal personal corrections learned from earlier forecast errors."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval


def keys(row, forecast, group):
    extra = None
    if group == "player_home":
        extra = bool(row["home"])
    elif group == "player_forecast":
        extra = int(forecast >= 35) + int(forecast >= 50) + int(forecast >= 60)
    return (row["player"], row["pos"], extra), (row["pos"], extra)


def online_corrections(rows, baseline, spec):
    actual = np.array([r["score"] for r in rows])
    if not np.isfinite(actual).all() or not np.isfinite(baseline).all():
        raise ValueError("Actuals and forecasts must be known")
    deltas = np.arange(-30, 30.01, 0.5)
    availability = np.array([moment(r["date"]).timestamp() + 48 * 3600 for r in rows])
    order = np.argsort(availability, kind="stable")
    origin = availability.min()
    predicted = {cap: np.empty(len(rows)) for cap in (5, 15, 30)}
    own, parent = {}, {}
    seen = 0
    previous = None
    for i, row in enumerate(rows):
        cutoff = cutoff_for(row["date"]).timestamp()
        if previous is not None and cutoff < previous:
            raise ValueError("Rows must be chronological")
        previous = cutoff
        while seen < len(order) and availability[order[seen]] < cutoff:
            j = order[seen]
            weight = np.exp2((availability[j] - origin) / (86400 * spec["halfLifeDays"]))
            hits = (np.abs(np.clip(baseline[j] + deltas, 0, 100) - actual[j]) <= 7).astype(float)
            own_key, parent_key = keys(rows[j], baseline[j], spec["group"])
            for table, key in ((own, own_key), (parent, parent_key)):
                total = table.setdefault(key, [np.zeros(len(deltas)), 0.0])
                total[0] += weight * hits
                total[1] += weight
            seen += 1
        own_key, parent_key = keys(row, baseline[i], spec["group"])
        prior = parent.get(parent_key)
        if prior is None:
            for cap in predicted:
                predicted[cap][i] = baseline[i]
            continue
        person = own.get(own_key, [np.zeros(len(deltas)), 0.0])
        decay = np.exp2(-(cutoff - origin) / (86400 * spec["halfLifeDays"]))
        mass = person[0] * decay + spec["priorStrength"] * prior[0] / prior[1]
        for cap in predicted:
            allowed = np.abs(deltas) <= cap
            top = np.max(mass[allowed])
            winners = np.flatnonzero(allowed & (np.abs(mass - top) <= 1e-12))
            chosen = winners[np.argmin(np.abs(deltas[winners]))]
            predicted[cap][i] = np.clip(baseline[i] + deltas[chosen], 0, 100)
    return predicted


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "control", "selector", "cache", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    control = json.loads(args.control.read_text(encoding="utf-8"))
    selector = json.loads(args.selector.read_text(encoding="utf-8"))
    if source["key"] != control["sourceKey"] or source["key"] != selector["sourceKey"]:
        raise ValueError("Source cases differ")
    report = {
        "scope": "Testing only; no application changes",
        "target": "Actual LaLiga score within7, all starts/substitutes separately",
        "method": "Choose modal personal forecast correction from earlier error patterns",
        "evidenceLimit": "Retrospective exploratory reuse; no new blind claim",
        "sourceKey": source["key"],
        "cohorts": {},
    }
    home_index = source["features"].index("home")
    for cohort in ("start", "bench"):
        original = [r for r in source["rows"] if r["cohort"] == cohort and r["date"][:10] >= "2025-07-01"]
        rows = [
            {"player": r["player"], "pos": r["pos"], "score": r["score"], "date": r["date"], "home": r["x"][home_index]}
            for r in original
        ]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        earlier = dates < "2026-01-01"
        select = (dates >= "2025-11-01") & earlier
        test = ~earlier
        with np.load(args.cache / f"selector_{cohort}_control_earlier.npz") as stored:
            if str(stored["key"]) != selector["implementationKey"]:
                raise ValueError("Earlier prediction cache differs")
            old_predictions = stored["prediction"]
        if (
            abs(
                measure(y[earlier], old_predictions)["within7"]
                - control["cohorts"][cohort]["selection"]["control"]["selection"]["within7"]
            )
            > 1e-12
        ):
            raise ValueError("Earlier control did not reproduce")
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(y[test], stored["y"]):
                raise ValueError("Later prediction cases differ")
            baseline = np.concatenate((old_predictions, stored["control"]))
        candidates = [{"group": "unchanged", "selection": measure(y[select], baseline[select])}]
        earlier_rows = rows[: int(earlier.sum())]
        for group, strength, life in itertools.product(
            ("player", "player_home", "player_forecast"), (5, 15, 30), (90, 365)
        ):
            spec = {"group": group, "priorStrength": strength, "halfLifeDays": life}
            predictions = online_corrections(earlier_rows, baseline[earlier], spec)
            for cap, prediction in predictions.items():
                candidates.append(
                    {**spec, "maximumCorrection": cap, "selection": measure(y[select], prediction[select[earlier]])}
                )
            print(f"Selected {cohort} {group} prior{strength} half-life{life}", flush=True)
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        if winner["group"] == "unchanged":
            prediction = baseline[test]
        else:
            prediction = online_corrections(rows, baseline, winner)[winner["maximumCorrection"]][test]
        weeks = [r["week"] for r, yes in zip(original, test, strict=True) if yes]
        pos = np.array([r["pos"] for r in rows])[test]
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "control": measure(y[test], baseline[test]),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "gain95": paired_interval(y[test], prediction, baseline[test], weeks),
            "changedCases": int((abs(prediction - baseline[test]) > 1e-12).sum()),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {p: measure(y[test][pos == p], prediction[pos == p]) for p in POSITIONS if (pos == p).any()},
        }
        np.savez_compressed(
            args.cache / f"personal_correction_predictions_{cohort}.npz", prediction=prediction, y=y[test]
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
