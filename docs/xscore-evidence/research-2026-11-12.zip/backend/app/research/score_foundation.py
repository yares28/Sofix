"""LaLiga score research: strictly lagged features for starts and bench appearances."""

from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from typing import Any

import numpy as np

from app.research.score_search import POSITIONS, cutoff_for, moment

STATS = (
    "goals",
    "goal_assist",
    "ontarget_scoring_att",
    "total_scoring_att",
    "big_chance_created",
    "big_chance_missed",
    "won_tackle",
    "interception_won",
    "duel_won",
    "duel_lost",
    "accurate_pass",
    "successful_final_third_passes",
    "pen_area_entries",
    "poss_lost_ctrl",
    "saves",
    "saved_ibox",
    "effective_clearance",
    "blocked_scoring_att",
    "yellow_card",
    "fouls",
    "was_fouled",
)


def pick_score(probability: np.ndarray, outcomes: np.ndarray) -> np.ndarray:
    """Maximise probability inside +/-7; ties nearest the most probable outcome."""
    centres = np.arange(101)
    mass = probability @ (np.abs(outcomes[:, None] - centres) <= 7)
    preferred = outcomes[probability.argmax(axis=1)]
    distance = np.abs(centres[None, :] - preferred[:, None])
    return centres[np.argmax(mass - distance * 1e-12, axis=1)].astype(float)


def prior_role(g: dict[str, Any], player: str, home: bool) -> tuple[float, float]:
    lines = ((g.get("xi") or {}).get("home" if home else "away") or {}).get("start") or []
    for line, people in enumerate(lines):
        if player in people:
            depth = line / max(1, len(lines) - 1)
            edge = abs(people.index(player) / max(1, len(people) - 1) - 0.5) * 2
            return depth, edge
    return -1.0, -1.0


def build_cases(games: list[dict[str, Any]], context: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    history: dict[str, list[dict[str, Any]]] = defaultdict(list)
    opposing: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    teams: dict[str, list[tuple[Any, float, float]]] = defaultdict(list)
    rows, names = [], []
    seen = set()
    for g in sorted(games, key=lambda v: (v["date"], v["id"])):
        if g["id"] in seen:
            raise ValueError("Duplicate game")
        seen.add(g["id"])
        cutoff = cutoff_for(g["date"])
        for player, actual in g["players"].items():
            if (
                actual.get("played") is not True
                or type(actual.get("started")) is not bool
                or actual.get("score") is None
                or actual.get("ver") != 7
                or actual.get("pos") not in POSITIONS
            ):
                continue
            home = actual["team"] == g["home"]["slug"]
            own, other = (g["home"]["slug"], g["away"]["slug"]) if home else (g["away"]["slug"], g["home"]["slug"])
            cohort = "start" if actual["started"] else "bench"
            pos = actual["pos"]
            past = [r for r in history[player] if r["available"] < cutoff]
            features: dict[str, float] = {"home": float(home), **{f"position_{p}": float(pos == p) for p in POSITIONS}}
            latest = max([r["available"] for r in past], default=None)
            features["days_since_appearance"] = (cutoff - latest).total_seconds() / 86400 if latest else 90.0
            for kind in ("start", "bench"):
                own_past = [r for r in past if r["cohort"] == kind]
                features[f"{kind}_history_count"] = len(own_past)
                for n in (3, 10, 30):
                    group = own_past[-n:]
                    a = np.array([r["vector"] for r in group])
                    prefix = f"{kind}_{n}"
                    default = np.array(
                        [
                            45 if kind == "start" else 38,
                            10 if kind == "start" else 3,
                            35,
                            80 if kind == "start" else 20,
                            0.2,
                            0,
                            0,
                            0,
                            0,
                            -0.1,
                            -0.1,
                        ]
                    )
                    mean = a[:, :11].mean(axis=0) if len(group) else default
                    for j, label in enumerate(
                        (
                            "score",
                            "aa",
                            "level",
                            "minutes",
                            "decisive",
                            "pen",
                            "setp",
                            "corners",
                            "fk",
                            "role_depth",
                            "role_edge",
                        )
                    ):
                        features[f"{prefix}_{label}"] = float(mean[j])
                    scores = a[:, 0] if len(group) else np.array([default[0]])
                    for q in (0.2, 0.5, 0.8):
                        features[f"{prefix}_score_q{q}"] = float(np.quantile(scores, q))
                    features[f"{prefix}_score_sd"] = float(scores.std())
                    if n == 10:
                        minutes = float(a[:, 3].sum()) if len(group) else 0
                        for j, stat in enumerate(STATS):
                            features[f"{kind}_rate_{stat}"] = float(a[:, 11 + j].sum() * 90 / minutes) if minutes else 0
            for club, label in ((own, "team"), (other, "opponent")):
                results = [r for r in teams[club] if r[0] < cutoff][-20:]
                for n in (5, 20):
                    group = results[-n:]
                    features[f"{label}_{n}_scored"] = float(np.mean([r[1] for r in group])) if group else 1.3
                    features[f"{label}_{n}_conceded"] = float(np.mean([r[2] for r in group])) if group else 1.3
            allowed = [r for r in opposing[other, pos] if r["available"] < cutoff][-150:]
            a = np.array([r["vector"] for r in allowed])
            minutes = float(a[:, 3].sum()) if len(allowed) else 0
            features["style_cases"] = len(allowed)
            features["style_aa_per90"] = float(a[:, 1].sum() * 90 / minutes) if minutes else 10
            features["style_decisive"] = float(a[:, 4].mean()) if len(allowed) else 0.2
            for j, stat in enumerate(STATS):
                features[f"style_{stat}"] = float(a[:, 11 + j].sum() * 90 / minutes) if minutes else 0
            c = context.get(g["id"]) or {}
            if c and moment(c["before"]) > cutoff:
                raise ValueError("Football context is later than the prediction deadline")
            for key in ("lam_h", "lam_a", "cs_h", "cs_a", "p_h", "p_d", "p_a"):
                features[f"match_{key}"] = float(c[key]) if c else -1.0
            names = list(features)
            rows.append(
                {
                    "game": g["id"],
                    "player": player,
                    "date": g["date"],
                    "week": cutoff.isoformat(),
                    "cohort": cohort,
                    "pos": pos,
                    "score": float(actual["score"]),
                    "aa": float(actual.get("aa") or 0),
                    "level": float(actual.get("level") or 0),
                    "minutes": actual.get("mins"),
                    "x": list(features.values()),
                    "recent": [r["vector"][0] for r in past if r["cohort"] == cohort][-20:],
                }
            )
        # No current-game information enters any of the predictions above.
        available = moment(g["date"]) + timedelta(hours=48)
        for player, actual in g["players"].items():
            if (
                actual.get("played") is not True
                or type(actual.get("started")) is not bool
                or actual.get("score") is None
                or actual.get("ver") != 7
                or actual.get("pos") not in POSITIONS
            ):
                continue
            home = actual["team"] == g["home"]["slug"]
            other = g["away" if home else "home"]["slug"]
            depth, edge = prior_role(g, player, home)
            vector = [
                actual["score"],
                actual.get("aa") or 0,
                actual.get("level") or 0,
                actual.get("mins") or 0,
                float((actual.get("level") or 0) >= 60),
                *[actual.get(k) or 0 for k in ("pen", "setp", "corners", "fk")],
                depth,
                edge,
                *[(actual.get("stats") or {}).get(stat, [0, 0])[0] for stat in STATS],
            ]
            r = {"available": available, "cohort": "start" if actual["started"] else "bench", "vector": vector}
            history[player].append(r)
            opposing[other, actual["pos"]].append(r)
        if g.get("homeGoals") is not None and g.get("awayGoals") is not None:
            teams[g["home"]["slug"]].append((available, g["homeGoals"], g["awayGoals"]))
            teams[g["away"]["slug"]].append((available, g["awayGoals"], g["homeGoals"]))
    return rows, names
