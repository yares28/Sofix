"""Clock and fixture coverage for a handful of official coaching announcements."""

import hashlib
import json
import re
from collections import defaultdict
from datetime import date, datetime, time
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for

PILOT = {
    "celta_giraldez_2024.html": ("celta-de-vigo-vigo", "Claudio Giráldez", "2024-03-12", "2024-03-13"),
    "valencia_corberan_2024.html": ("valencia-valencia", "Carlos Corberán", "2024-12-27", "2024-12-27"),
    "oviedo_carrion_2025.html": ("real-oviedo-oviedo", "Luis Carrión", "2025-10-10", "2025-10-10"),
    "madrid_arbeloa_2026.html": ("real-madrid-madrid", "Álvaro Arbeloa", "2026-01-12", "2026-01-12"),
    "alaves_sanchez_flores_2026.html": (
        "deportivo-alaves-vitoria-gasteiz",
        "Quique Sánchez Flores",
        "2026-03-03",
        "2026-03-03",
    ),
    "valencia_oscar_sanchez_2026.html": ("valencia-valencia", "Óscar Sánchez", "2026-09-13", "2026-09-13"),
}


def clock(body, published):
    values = {}
    for kind in ("Published", "Modified"):
        matches = set(re.findall(rf'"date{kind}"\s*:\s*"([^"]+)"', body))
        if len(matches) != 1:
            break
        x = datetime.fromisoformat(matches.pop())
        if x.tzinfo is None:
            break
        values[kind] = x
    if len(values) == 2:
        assert values["Published"].date().isoformat() == published and values["Modified"] >= values["Published"]
        return values["Modified"], "publication_and_revision", values["Published"].isoformat()
    bound = datetime.combine(date.fromisoformat(published), time.max, tzinfo=ZoneInfo("Europe/Madrid"))
    return bound, "publication_day_only_revision_unknown", None


def main():
    native = NATIVE.read_bytes()
    assert hashlib.sha256(native).hexdigest() == NATIVE_SHA
    games = sorted(map(json.loads, native.splitlines()), key=lambda g: (g["date"], g["id"]))
    rows = json.loads((ROOT / "cases.json").read_text())["rows"]
    manifest_path = ROOT / "coach-source/pilot_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    assert len(manifest) == len(PILOT)
    eligible = defaultdict(set)
    samples = []
    for m in manifest:
        path = Path(m["file"])
        raw = path.read_bytes()
        assert m["status"] == 200 and hashlib.sha256(raw).hexdigest() == m["sha256"]
        club, coach, day, effective = PILOT[path.name]
        body = raw.decode("utf-8")
        # Human-reviewed visible date and role facts are pinned in PILOT.
        assert coach.split()[-1] in body or coach.split()[-1].lower() in body.lower()
        available, status, pub = clock(body, day)
        starts = [g for g in games if g["date"][:10] >= effective and club in (g["home"]["slug"], g["away"]["slug"])][
            :6
        ]
        timely = [g["id"] for g in starts if available < cutoff_for(g["date"])]
        eligible[status].update(timely)
        samples.append(
            dict(
                club=club,
                coach=coach,
                publicationDay=day,
                effectiveDay=effective,
                source=m["url"],
                sha256=m["sha256"],
                archivedPageClock=available.isoformat(),
                status=status,
                structuredPublication=pub,
                observedFixtureCount=len(starts),
                firstFixture=starts[0]["date"],
                firstLock=cutoff_for(starts[0]["date"]).isoformat(),
                timelyFixtures=timely,
            )
        )
    bands = dict(PHASES, later2026=("2026-01-01", "2027-01-01"))
    support = {}
    for name, (begin, end) in bands.items():
        support[name] = {}
        for category, ids in eligible.items():
            targets = [r for r in rows if begin <= r["date"] < end and r["game"] in ids]
            support[name][category] = dict(
                fixtures=len({r["game"] for r in targets}),
                starters=sum(r["cohort"] == "start" for r in targets),
                substitutes=sum(r["cohort"] == "bench" for r in targets),
            )
    result = dict(
        manifestSHA=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        samples=samples,
        fullPhaseCaseCoverage=support,
        outcomeLabelsRead=False,
        modelEvaluated=False,
        limit="Published-version timestamps are reconstructed. Date-only rows are provisional. "
        "The six-match windows do not certify that the same coach was in charge for every fixture.",
    )
    (REPORTS / "laliga_score_coach_source_pilot.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(support, indent=2))


if __name__ == "__main__":
    main()
