"""Offline native pass-endpoint pressure source; missing geometry stays explicit."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np

CATEGORIES = ("cross_end", "long_forward_end", "third_entry_end")


def pass_stream(events, side):
    if side not in ("home", "away"):
        raise ValueError("Known native fixture side required")
    if not isinstance(events, list):
        return dict(
            known=False,
            passCount=None,
            successes=None,
            invalidFlags=None,
            unknownCoordinates=None,
            classificationComplete=False,
            categories={name: None for name in CATEGORIES},
        )
    own = [e for e in events if e.get("team") == side]
    invalid = sum(type(e.get("ok")) is not bool or type(e.get("cross")) is not bool for e in own)
    geometry_known = [
        e
        for e in own
        if all(type(e.get(k)) in (int, float) and np.isfinite(e[k]) and 0 < e[k] < 100 for k in ("x", "y", "ex", "ey"))
    ]
    valid = [e for e in geometry_known if type(e.get("ok")) is bool and type(e.get("cross")) is bool]
    categories = {name: [] for name in CATEGORIES}
    for event in valid:
        point = [event["ex"], event["ey"], int(event["ok"])]
        if event["cross"]:
            categories["cross_end"].append(point)
        if event["ex"] - event["x"] >= 15 and (event["ex"] - event["x"]) ** 2 + (event["ey"] - event["y"]) ** 2 >= 900:
            categories["long_forward_end"].append(point)
        if event["x"] < 200 / 3 <= event["ex"]:
            categories["third_entry_end"].append(point)
    return dict(
        known=True,
        passCount=len(own),
        successes=sum(e["ok"] for e in own) if all(type(e.get("ok")) is bool for e in own) else None,
        invalidFlags=invalid,
        unknownCoordinates=len(own) - len(geometry_known),
        classificationComplete=len(valid) == len(own),
        categories=categories,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_spatial_pass_probe.json"))
    args = parser.parse_args()
    old_raw = (args.cache / "spatial_pressure_observations.json.gz").read_bytes()
    if hashlib.sha256(old_raw).hexdigest() != "10520bbc82875f183dffca091d2603c9d3f1bfb6618a043d97519037b05d9ff6":
        raise ValueError("Audited take-on source changed")
    old = json.loads(gzip.decompress(old_raw))
    native_raw = args.games.read_bytes()
    if hashlib.sha256(native_raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    games = {g["id"]: g for g in (json.loads(line) for line in native_raw.decode().splitlines() if line.strip())}
    observations, counts, samples = [], Counter(), []
    last_path, detail = None, None
    for record in old["observations"]:
        path = record["sourcePath"]
        if path != last_path:
            canonical = (args.repo / path).read_bytes().replace(b"\r\n", b"\n")
            if (
                hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest()
                != record["sourceBlob"]
            ):
                raise ValueError("Cached source pass bytes changed")
            detail = json.loads(canonical.decode().partition("=")[2].strip().removesuffix(";"))
            last_path = path
        game = games[record["game"]]
        side = next(s for s in ("home", "away") if game[s]["slug"] == record["club"])
        summary = pass_stream(detail.get("passes"), side)
        people = [p for p in game["players"].values() if p.get("played") is True and p.get("team") == record["club"]]
        known = all(p.get("ver") == 7 and isinstance(p.get("stats"), dict) for p in people)
        native = sum(p["stats"].get("accurate_pass", [0, 0])[0] for p in people) if known else None
        verified = native is not None and summary["successes"] is not None and native == summary["successes"]
        counts["teamSides"] += 1
        counts["nativeSuccessAgreements"] += int(verified)
        counts["knownStreams"] += int(summary["known"])
        counts["completeSpatialClassification"] += int(summary["classificationComplete"])
        counts["trustedCompleteSides"] += int(verified and summary["classificationComplete"])
        if summary["known"]:
            for field in ("passCount", "unknownCoordinates", "invalidFlags"):
                counts[field] += summary[field]
            for name in CATEGORIES:
                counts[name + "_knownLowerBound"] += len(summary["categories"][name])
        if not verified and len(samples) < 15:
            samples.append(
                dict(
                    game=record["game"],
                    club=record["club"],
                    nativeAccuratePass=native,
                    sourceSuccessfulPasses=summary["successes"],
                )
            )
        observations.append({**record, "passes": summary, "nativeAccuratePass": native, "passCountsVerified": verified})
    path = args.cache / "spatial_pass_pressure_observations.json.gz"
    key = hashlib.sha256(
        old_raw + native_raw + Path(__file__).read_bytes() + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    path.write_bytes(
        gzip.compress(
            json.dumps(dict(key=key, observations=observations), separators=(",", ":"), allow_nan=False).encode(),
            mtime=0,
        )
    )
    output = dict(
        scope="Source-only probe, no forecast accuracy claim",
        implementationKey=key,
        sourceCommit=old["source"]["sourceCommit"],
        nativeFixtures=len(games),
        sourceTeamSideRecords=len(observations),
        counts=dict(counts),
        disagreementSamples=samples,
        observationsFile=str(path),
        observationsSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        limitations="Incomplete classification counts are explicit observed lower bounds, not full zeros. Categories overlap. No inferred carry endpoints/receiver identities. Past records require strict48h prelock lag before any feature use.",
    )
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
    print("SPATIAL_PASSES " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
