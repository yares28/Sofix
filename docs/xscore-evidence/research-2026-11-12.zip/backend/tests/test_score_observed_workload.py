import copy

import numpy as np
import pytest

from app.research.score_observed_workload import NAMES, build_features, euro_game, merge_records
from app.research.score_search import cutoff_for


def raw_euro(date="2026-01-06T18:00:00Z", minutes=90, played=True):
    return {
        "id": "euro",
        "date": date,
        "statusTyped": "played",
        "homeTeam": {"slug": "home"},
        "awayTeam": {"slug": "away"},
        "homeFormation": {},
        "awayFormation": {},
        "playerGameScores": [
            {
                "anyPlayer": {"slug": "p"},
                "score": 0,
                "scoreStatus": "UNKNOWN",
                "scoringVersion": None,
                "anyPlayerGameStats": {"anyTeam": {"slug": "home"}, "minsPlayed": minutes, "playedInGame": played},
            }
        ],
    }


def target():
    row = {
        "game": "target",
        "player": "p",
        "date": "2026-01-10T18:00:00Z",
        "pos": "DEF",
        "cohort": "start",
        "score": 40,
        "aa": 5,
        "level": 35,
        "minutes": 90,
    }
    game = {
        "id": "target",
        "date": row["date"],
        "home": {"slug": "home"},
        "away": {"slug": "away"},
        "players": {"p": {"team": "home", "played": True, "mins": 90, "score": 40, "pos": "DEF"}},
    }
    return row, game


def built(raw):
    row, game = target()
    fixture, records, counts = euro_game(raw, "CL")
    values, audit = build_features([row], [game], [fixture], records)
    return values[0], audit, counts


def test_known_minutes_survive_missing_xi_and_unusable_sorare_score():
    values, _, counts = built(raw_euro())
    assert values[NAMES.index("load_euro_player_7_known_minutes")] == 90
    assert values[NAMES.index("load_euro_player_7_known_rows")] == 1
    assert counts["knownPositiveMinutes"] == 1


def test_explicit_zero_is_known_and_no_record_is_missing():
    zero, _, _ = built(raw_euro(minutes=0, played=False))
    assert zero[NAMES.index("load_euro_player_7_known_minutes")] == 0
    assert zero[NAMES.index("load_euro_player_7_zero_rows")] == 1
    raw = raw_euro()
    raw["playerGameScores"] = []
    missing, _, _ = built(raw)
    assert np.isnan(missing[NAMES.index("load_euro_player_7_known_minutes")])
    assert missing[NAMES.index("load_euro_player_7_known_rows")] == 0


def test_exact_forty_eight_hour_boundary_is_excluded_from_player_and_club():
    row, _ = target()
    assert cutoff_for(row["date"]).isoformat() == "2026-01-09T14:00:00+00:00"
    values, _, _ = built(raw_euro(date="2026-01-07T14:00:00Z"))
    assert values[NAMES.index("load_euro_player_7_known_rows")] == 0
    assert values[NAMES.index("load_euro_club_7_observed_fixtures")] == 0


def test_partial_minutes_stay_partial_and_invalid_side_is_unknown():
    a = raw_euro()
    f1, r1, _ = euro_game(a, "CL")
    b = raw_euro(date="2026-01-05T18:00:00Z", minutes=None)
    b["id"] = "euro2"
    f2, r2, _ = euro_game(b, "CL")
    row, game = target()
    values, _ = build_features([row], [game], [f1, f2], r1 + r2)
    assert values[0, NAMES.index("load_euro_player_7_known_minutes")] == 90
    assert np.isnan(values[0, NAMES.index("load_euro_player_7_complete_observed_minutes")])
    assert values[0, NAMES.index("load_euro_player_7_unknown_rows")] == 1
    a["playerGameScores"][0]["anyPlayerGameStats"]["anyTeam"]["slug"] = "wrong"
    values, _, _ = built(a)
    assert np.isnan(values[NAMES.index("load_euro_player_7_known_minutes")])
    assert values[NAMES.index("load_euro_player_7_unknown_rows")] == 1


def test_current_and_unavailable_outcomes_and_formations_cannot_change_features():
    row, game = target()
    f1, r1, _ = euro_game(raw_euro(), "CL")
    f2, r2, _ = euro_game(raw_euro(date="2026-01-07T14:00:00Z", minutes=120), "CL")
    f2["game"] = "late"
    for r in r2:
        r["game"] = "late"
    before, _ = build_features([row], [game], [f1, f2], r1 + r2)
    changed_row, changed_game, changed_records = copy.deepcopy(row), copy.deepcopy(game), copy.deepcopy(r1 + r2)
    changed_row.update(minutes=1, score=99, aa=64, level=60)
    changed_game["players"]["p"].update(mins=1, score=99)
    changed_records[-1]["minutes"] = 0
    after, _ = build_features([changed_row], [changed_game], [f1, f2], changed_records)
    np.testing.assert_equal(before, after)


def test_identity_dedup_and_conflicting_known_minutes():
    _, records, _ = euro_game(raw_euro(), "CL")
    assert len(merge_records(records + copy.deepcopy(records))) == 1
    wrong = copy.deepcopy(records)
    wrong[0]["minutes"] = 60
    with pytest.raises(ValueError, match="Conflicting"):
        merge_records(records + wrong)
