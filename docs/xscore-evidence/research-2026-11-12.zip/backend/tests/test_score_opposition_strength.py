import sys
from copy import deepcopy
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))

from app.research import score_opposition_strength as study


def game(identity, date):
    players = {}
    for club in ("H", "A"):
        for i in range(11):
            players[club + str(i)] = dict(
                played=True,
                started=True,
                team=club,
                pos="GK" if i == 0 else "DEF",
                ver=7,
                mins=90,
                stats=dict(duel_won=[2, 3], duel_lost=[1, -2]),
            )
    return dict(id=identity, date=date, home=dict(slug="H"), away=dict(slug="A"), players=players)


def test_analytic_gradient_matches_finite_difference():
    from scipy.sparse import csr_matrix

    x = csr_matrix([[1, 0, 1, -0.3], [0, 1, -0.8, 1], [1, 0, 0, 0]])
    counts = np.array([[7.0, 3], [1.0, 4], [0.0, 0]])
    beta, penalty = np.array([0.2, -0.5, 0.1, 0.4]), np.array([0.01, 0.01, 5, 5])
    _, grad = study.objective(beta, x, counts, penalty)
    numerical = []
    for j in range(len(beta)):
        shift = np.zeros_like(beta)
        shift[j] = 1e-6
        numerical.append(
            (
                study.objective(beta + shift, x, counts, penalty)[0]
                - study.objective(beta - shift, x, counts, penalty)[0]
            )
            / 2e-6
        )
    np.testing.assert_allclose(grad, numerical, atol=1e-7)


def test_schedule_adjustment_is_measurable_in_synthetic_counts():
    # Equal observed success, but A faced strong S and B weak W. Shared anchor observations
    # identify S/W; no real football accuracy is inferred from this constructed example.
    obs = []
    for player, opponent, won in [("S", "W", 80), ("W", "S", 20), ("A", "S", 50), ("B", "W", 50)]:
        obs.append(
            dict(
                player=player, pos="DEF", cohort="start", home=0.0, opposition={opponent: 1.0}, counts=[won, 100 - won]
            )
        )
    players = study.dictionary(obs)
    base, joint = (study.training_matrix(obs, players, a) for a in (False, True))
    counts = np.array([r["counts"] for r in obs], float)
    b, _ = study.fit(base, counts)
    j, _ = study.fit(joint, counts)
    assert abs(b[7 + players["A"]] - b[7 + players["B"]]) < 1e-7
    assert j[7 + players["A"]] > j[7 + players["B"]] + 0.3


def test_missing_stats_are_unknown_and_known_zero_is_retained():
    old = game("old", "2024-01-13T13:00:00Z")
    old["players"]["H1"]["stats"] = {}
    rows = study.observations([old])
    zero = next(r for r in rows if r["player"] == "H1")
    assert zero["counts"] == [0, 0]
    assert abs(sum(zero["opposition"].values()) - 1) < 1e-12
    old["players"]["A1"]["stats"] = None
    assert study.observations([old]) == []
    assert study.qualified(old) is None


def test_projection_never_reads_future_participants_or_equal_boundary():
    old, target = game("old", "2024-01-13T13:00:00Z"), game("target", "2024-01-17T20:00:00Z")
    row = dict(game="target", date=target["date"], player="new", pos="DEF", cohort="start", x=[1.0])
    all_games = [old, target]
    before = study.projections([row], all_games, ["home"])
    changed = deepcopy(all_games)
    changed[1]["players"] = {"BAD": dict(score=100, mins=9999, pos="FWD")}
    assert study.projections([row], changed, ["home"]) == before
    assert before[0]["knownGames"] == 1 and abs(sum(before[0]["opposition"].values()) - 1) < 1e-12
    changed[0]["date"] = "2024-01-14T14:00:00Z"
    cold = study.projections([row], changed, ["home"])[0]
    assert cold["knownGames"] == 0 and cold["opposition"] == {}


def test_unseen_players_have_no_fitted_columns_or_strength():
    obs = [dict(player="old", pos="DEF", cohort="start", home=1.0, opposition={"old": 1.0}, counts=[2, 1])]
    players = study.dictionary(obs)
    target = dict(player="future", pos="DEF", cohort="start", home=0.0, opposition={"future": 1.0})
    matrix = study.training_matrix([target], players, True)
    assert players == {"old": 0} and matrix.shape == (1, 8)
    assert matrix.toarray()[0, 7] == 0


def test_outside_fit_labels_are_not_an_argument_to_fit():
    obs = [dict(player="old", pos="DEF", cohort="start", home=0.0, opposition={}, counts=[6, 4])]
    players = study.dictionary(obs)
    x = study.training_matrix(obs, players, False)
    b, _ = study.fit(x, np.array([[6.0, 4]]))
    target = deepcopy(obs)
    target[0]["counts"] = [np.nan, np.nan]
    np.testing.assert_array_equal(x.toarray(), study.training_matrix(target, players, False).toarray())
    assert np.isfinite(b).all()
