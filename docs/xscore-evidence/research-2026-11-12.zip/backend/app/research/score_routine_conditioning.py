"""Testing only: ablate source coverage in corrected ordinary-activity history."""

import numpy as np

from app.research import score_europe_routine_history as history


def feature_groups(names):
    if list(names) != list(history.NAMES):
        raise ValueError("Corrected routine-history feature schema differs")
    euro = np.array([n.startswith("routine_euro_") for n in names])
    combined = np.array([n.startswith("routine_combined_") for n in names])
    if (euro & combined).any() or not (euro | combined).all():
        raise ValueError("Corrected routine-history source coverage differs")
    return {"euro": euro, "combined": combined, "all": np.ones(len(names), dtype=bool)}
