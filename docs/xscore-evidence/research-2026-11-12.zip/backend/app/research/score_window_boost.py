"""Independent overlapping-score classifiers, selected without later targets."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def choose_position_models(y: np.ndarray, predictions: dict[str, np.ndarray], positions: np.ndarray) -> dict[str, str]:
    selected = {}
    for pos in POSITIONS:
        mask = positions == pos
        if not mask.any():
            continue
        selected[pos] = max(
            predictions,
            key=lambda name: (
                measure(y[mask], predictions[name][mask])["within7"],
                -measure(y[mask], predictions[name][mask])["mae"],
            ),
        )
    return selected


def fit_intervals(x, y, fit, check, leaves, minimum, cache: Path, key: str, label: str):
    from sklearn.ensemble import HistGradientBoostingClassifier

    centres = np.arange(0, 100.01, 2.5)
    probability = np.zeros((int(check.sum()), len(centres)))
    done = 0
    if cache.exists():
        with np.load(cache) as previous:
            if str(previous["key"]) == key:
                probability = previous["probability"]
                done = int(previous["done"])
    for i in range(done, len(centres)):
        target = np.abs(y[fit] - centres[i]) <= 7
        if target.all() or not target.any():
            probability[:, i] = target.mean()
        else:
            model = HistGradientBoostingClassifier(
                max_leaf_nodes=leaves,
                min_samples_leaf=minimum,
                max_iter=120,
                learning_rate=0.06,
                l2_regularization=10,
                early_stopping=False,
                random_state=20261103,
            ).fit(x[fit], target)
            probability[:, i] = model.predict_proba(x[check])[:, 1]
        np.savez_compressed(cache, key=key, probability=probability, done=i + 1)
        if i % 10 == 0 or i == len(centres) - 1:
            print(f"{label}: {i + 1}/{len(centres)} intervals", flush=True)
    return window_centres(probability, centres), probability.max(axis=1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    with np.load(args.stats_cache) as stored:
        allx = stored["x"]
        stat_key = str(stored["key"])
    fingerprint = hashlib.sha256((source["key"] + stat_key).encode() + Path(__file__).read_bytes()).hexdigest()
    report = {
        "target": "Actual score within seven; independent classifiers for every overlapping score interval",
        "evidenceLimit": "Retrospective exploratory reuse of Jan-Oct2026; not blind or prospective evidence",
        "split": "Train before July2025; select July-Dec2025; refit before Jan2026; evaluate later after freezing",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "implementationKey": fingerprint,
        "cohorts": {},
    }
    configurations = {"small": (7, 80), "medium": (15, 60)}
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        x = allx[keep]
        y = np.array([r["score"] for r in rows])
        dates = np.array([r["date"][:10] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        earlier, later, certainty = {}, {}, {}
        for name, (leaves, minimum) in configurations.items():
            label = f"{cohort}_{name}_selection"
            earlier[name], _ = fit_intervals(
                x, y, train, valid, leaves, minimum, args.cache / (label + ".npz"), fingerprint, label
            )
        metrics = {name: measure(y[valid], prediction) for name, prediction in earlier.items()}
        chosen = max(metrics, key=lambda name: (metrics[name]["within7"], -metrics[name]["mae"]))
        per_position = choose_position_models(y[valid], earlier, positions[valid])
        fallback = chosen
        choices = np.array([per_position.get(pos, fallback) for pos in positions[test]])
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"chosenGlobal": chosen, "positions": per_position, "selection": metrics}, indent=2),
            encoding="utf-8",
        )
        for name, (leaves, minimum) in configurations.items():
            label = f"{cohort}_{name}_later"
            later[name], certainty[name] = fit_intervals(
                x, y, ~test, test, leaves, minimum, args.cache / (label + ".npz"), fingerprint, label
            )
        predictions = {"global": later[chosen]}
        predictions["positionChoice"] = np.array([later[name][i] for i, name in enumerate(choices)])
        confidence = {
            "global": certainty[chosen],
            "positionChoice": np.array([certainty[name][i] for i, name in enumerate(choices)]),
        }
        baseline_cache = np.load(args.cache / f"europe_predictions_{cohort}.npz")
        if not np.array_equal(y[test], baseline_cache["y"]):
            raise ValueError("Baseline cases differ")
        baseline = baseline_cache["control"]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {"chosenGlobal": chosen, "positionModels": per_position, "selection": metrics, "variants": {}}
        for name, prediction in predictions.items():
            hit = np.abs(y[test] - prediction) <= 7
            result["variants"][name] = {
                "later": measure(y[test], prediction),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "gain95": paired_interval(y[test], prediction, baseline, weeks),
                "meanPredictedHitChance": float(confidence[name].mean()),
                "hitChanceBrier": float(np.mean((confidence[name] - hit) ** 2)),
                "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
                "positions": {
                    pos: measure(y[test][positions[test] == pos], prediction[positions[test] == pos])
                    for pos in POSITIONS
                    if (positions[test] == pos).any()
                },
            }
        np.savez_compressed(args.cache / f"window_boost_predictions_{cohort}.npz", **predictions, y=y[test])
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
