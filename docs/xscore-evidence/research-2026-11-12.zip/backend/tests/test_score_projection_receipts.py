from app.research.score_projection_receipts import copy_text, time_valid


def test_capture_must_precede_both_locks():
    kickoff = "2026-10-24T17:00:00Z"
    assert time_valid("2026-10-23T13:00:00Z", "2026-10-23T13:30:00Z", kickoff)
    assert not time_valid("2026-10-23T13:30:00Z", "2026-10-23T13:30:00Z", kickoff)
    assert not time_valid("2026-10-23T14:00:00Z", "2026-10-23T15:00:00Z", kickoff)


def test_postgres_copy_decodes_json_escapes_one_layer_only():
    assert copy_text(r'{"word":"a\\nb"}') == r'{"word":"a\nb"}'
