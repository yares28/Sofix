from app.research.score_card_cycle import generate


def fixture(n, date, y=1, r=0, playing=True):
    return {
        "id": str(n),
        "date": date,
        "home": {"slug": "H"},
        "away": {"slug": "A"},
        "players": {
            "p": {
                "team": "H",
                "pos": "DEF",
                "ver": 7,
                "played": playing,
                "started": playing,
                "mins": 90 if playing else 0,
                "stats": {"yellow_card": [y, 0], "red_card": [r, 0]},
            },
        },
    }


def test_card_cycles_ignore_mixed_reds_keep_bench_yellows_and_reset_by_season():
    games = [
        fixture(0, "2023-12-08T20:00:00Z", r=1),
        fixture(1, "2023-12-15T20:00:00Z"),
        fixture(2, "2023-12-22T20:00:00Z"),
        fixture(3, "2024-01-05T20:00:00Z", playing=False),
        fixture(4, "2024-01-12T20:00:00Z"),
        fixture(5, "2024-01-19T20:00:00Z"),
        fixture(6, "2024-01-26T20:00:00Z", y=0),
        fixture(7, "2024-08-16T20:00:00Z"),
        fixture(8, "2024-08-23T20:00:00Z", y=0),
    ]
    result, audit = generate(games)
    assert [(x["origin"], x["target"], x["status"]) for x in result] == [("5", "6", "timely")]
    assert result[0]["cycleCards"] == ["1", "2", "3", "4", "5"]
    assert audit["excludedRedYellow"] == 1


def test_late_origin_does_not_carry_forward_to_a_different_fixture():
    games = [
        fixture(i, d)
        for i, d in enumerate(
            [
                "2024-01-05T20:00:00Z",
                "2024-01-12T20:00:00Z",
                "2024-01-19T20:00:00Z",
                "2024-01-26T20:00:00Z",
                "2024-02-01T20:00:00Z",
                "2024-02-03T20:00:00Z",
                "2024-02-09T20:00:00Z",
            ]
        )
    ]
    result, _ = generate(games)
    assert [(x["origin"], x["target"], x["status"]) for x in result] == [("4", "5", "late")]
