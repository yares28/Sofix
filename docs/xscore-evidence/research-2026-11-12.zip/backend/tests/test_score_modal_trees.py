import numpy as np

from app.research.score_modal_trees import (
    CENTRES,
    FitBinner,
    ModalForest,
    ModalTree,
    interval_histogram,
    score_intervals,
    week_weights,
)


def test_difference_histogram_matches_every_native_within7_boundary():
    y = np.array([0.0, 7, 35.00000000000001, 42, 42.00000000000001, 60, 93, 100])
    bins = np.array([0, 0, 1, 1, 16, 16, 16, 0], dtype=np.uint8)
    weights = np.array([1.0, 2, 3, 4, 1, 2, 3, 4])
    lo, hi = score_intervals(y)
    actual = interval_histogram(bins, lo, hi, weights, 17)
    brute = np.array(
        [((np.abs(y[:, None] - CENTRES) <= 7) * (weights * (bins == b))[:, None]).sum(axis=0) for b in range(17)]
    )
    np.testing.assert_array_equal(actual, brute)


def test_binning_is_fit_only_and_keeps_missing_separate_from_known_zero():
    fit = np.array([[0.0, np.nan], [0, 1], [1, 2], [1, 3]])
    binner = FitBinner().fit(fit)
    before = [c.copy() for c in binner.cuts_]
    value = binner.transform(np.array([[0.0, np.nan], [1, 1000], [np.nan, 0]]))
    assert value[0, 0] != value[1, 0]
    assert value[0, 0] != value[2, 0]
    assert value[0, 1] == binner.bin_counts_[1] - 1
    for a, b in zip(before, binner.cuts_, strict=True):
        np.testing.assert_array_equal(a, b)


def test_tree_picks_conditional_modes_and_an_unsplit_leaf_does_not_average():
    y = np.array([40.0] * 60 + [80.0] * 40)
    x = np.array([[0.0]] * 60 + [[1.0]] * 40)
    tree = ModalTree(max_depth=1, min_leaf=10).fit(x, y)
    pred = tree.predict(np.array([[0.0], [1.0]]))
    np.testing.assert_array_equal(pred, [40, 80])
    flat = ModalTree(max_depth=1, min_leaf=10).fit(np.zeros_like(x), y)
    assert abs(flat.predict(np.array([[0.0]]))[0] - 40) <= 7


def test_tree_can_split_missing_from_known_zero_without_dropping_rows():
    x = np.array([[np.nan]] * 20 + [[0.0]] * 20)
    y = np.array([40.0] * 20 + [80.0] * 20)
    tree = ModalTree(max_depth=1, min_leaf=10).fit(x, y)
    np.testing.assert_array_equal(tree.predict(np.array([[np.nan], [0.0]])), [40, 80])


def test_week_bootstrap_is_deterministic_and_resamples_whole_weeks():
    weeks = np.array(["a", "a", "b", "c", "c"])
    a = week_weights(weeks, np.random.default_rng(41))
    b = week_weights(weeks, np.random.default_rng(41))
    np.testing.assert_array_equal(a, b)
    assert a[0] == a[1] and a[3] == a[4]
    assert a[[0, 2, 3]].sum() == 3


def test_forest_averages_window_probabilities_not_point_predictions():
    from types import SimpleNamespace

    low, high = [(np.abs(CENTRES - s) <= 7).astype(float) for s in (40, 80)]
    forest = ModalForest(trees=5, max_depth=1, min_leaf=2)
    forest.binner_ = FitBinner().fit(np.array([[0.0], [1]]))
    forest.trees_ = [
        SimpleNamespace(predict_binned_mass=lambda b, m=m: np.tile(m, (len(b), 1))) for m in (low, low, low, high, high)
    ]
    pred = forest.predict(np.array([[0.0]]))[0]
    assert abs(pred - 40) <= 7
    assert abs(pred - 56) > 7


def test_forest_predictions_are_reproducible_with_unchanged_training_inputs():
    x = np.arange(80.0)[:, None]
    y = np.where(x[:, 0] < 40, 40.0, 80)
    weeks = np.array([str(i // 8) for i in range(80)])
    args = {"trees": 4, "max_depth": 2, "min_leaf": 4}
    first, second = ModalForest(**args).fit(x, y, weeks), ModalForest(**args).fit(x, y, weeks)
    np.testing.assert_array_equal(first.predict(x), second.predict(x))
