"""Offline diagnosis: prior contribution frequency of missed goals and assists."""

from __future__ import annotations

import argparse
import hashlib
import json
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment


def bucket(contributions, appearances):
    if appearances == 0:
        return "no_history"
    if appearances < 5:
        return "short_history_1_to_4"
    if contributions == 0:
        return "zero_in_recent_5_to_10"
    if contributions / appearances <= 0.2:
        return "positive_to_20_percent"
    if contributions / appearances <= 0.4:
        return "above20_to40_percent"
    return "above40_percent"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_goal_miss_history.json"))
    args = parser.parse_args()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native archive changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    source = json.loads((args.cache / "cases.json").read_text())
    history, contributions = defaultdict(list), {}
    for r in source["rows"]:
        game = games[r["game"]]
        p = game["players"][r["player"]]
        if (
            p["ver"] != 7
            or not p["played"]
            or p["started"] != (r["cohort"] == "start")
            or game["date"] != r["date"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Native diagnostic case differs")
        history[r["player"], r["cohort"]].append(r)
        contributions[r["game"], r["player"]] = any(p["stats"].get(k, [0, 0])[0] > 0 for k in ("goals", "goal_assist"))
    for records in history.values():
        records.sort(key=lambda r: moment(r["date"]))
    times = {key: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for key, rs in history.items()}
    result = dict(
        sourceKey=source["key"],
        nativeCasesVerified=len(source["rows"]),
        warning="Hindsight miss labels and prelock history diagnostic only; not a new formula or accuracy improvement",
        cohorts={},
    )
    for cohort, name, correct, n in (
        ("start", "laliga_score_team_share", 2765, 6754),
        ("bench", "laliga_score_mixture_shrunk", 2201, 2925),
    ):
        rows = [r for r in source["rows"] if r["cohort"] == cohort and r["date"] >= "2026-01-01"]
        reference = json.loads((args.out.parent / (name + ".json")).read_text())
        with np.load(args.cache / f"{name}_predictions_{cohort}.npz") as f:
            if str(f["key"]) != reference["implementationKey"]:
                raise ValueError("Frozen prediction key differs")
            y, pred = f["y"], f["prediction"]
        np.testing.assert_array_equal(y, [r["score"] for r in rows])
        if len(rows) != n or int((abs(y - pred) <= 7).sum()) != correct:
            raise ValueError("Frozen full-cohort counts changed")
        buckets, prior_counts = defaultdict(Counter), Counter()
        for r, actual, guess in zip(rows, y, pred, strict=True):
            key, lock = (r["player"], cohort), cutoff_for(r["date"])
            end = bisect_left(times[key], lock.timestamp())
            past = [p for p in history[key][:end] if lock - moment(p["date"]) <= timedelta(days=365)][-10:]
            count = sum(contributions[p["game"], p["player"]] for p in past)
            current = contributions[r["game"], r["player"]]
            large = current and actual - guess > 25 and r["level"] >= 60
            b = buckets[bucket(count, len(past))]
            b.update(
                allCases=1,
                actualGoalOrAssist=int(current),
                retainedBestCorrect=int(abs(actual - guess) <= 7),
                largePositiveGoalAssistMiss=int(large),
            )
            if large:
                prior_counts[str(len(past))] += 1
        large_n = sum(b["largePositiveGoalAssistMiss"] for b in buckets.values())
        if sum(b["allCases"] for b in buckets.values()) != n or large_n != {"start": 719, "bench": 203}[cohort]:
            raise ValueError("Native event diagnostic totals differ")
        result["cohorts"][cohort] = dict(
            allCases=n,
            largeGoalAssistMisses=large_n,
            buckets=dict(buckets),
            largeMissPriorAppearances=dict(prior_counts),
        )
    args.out.write_text(json.dumps(result, indent=2))
    print("GOAL_MISS_HISTORY " + json.dumps(result["cohorts"]), flush=True)


if __name__ == "__main__":
    main()
