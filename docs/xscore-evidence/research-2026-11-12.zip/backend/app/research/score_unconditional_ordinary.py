"""Testing only: ordinary-point forecasts with no decisive-label conditioning."""

from __future__ import annotations

import numpy as np

QUANTILES = (0.35, 0.5, 0.65)


def regressor(quantile):
    from sklearn.ensemble import HistGradientBoostingRegressor

    return HistGradientBoostingRegressor(
        loss="quantile",
        quantile=quantile,
        max_leaf_nodes=15,
        min_samples_leaf=60,
        max_iter=120,
        learning_rate=0.1,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )


def fit_quantiles(x, aa, positions, fit, target, classes, mode):
    if mode not in ("pooled", "position"):
        raise ValueError("Declared unconditional AA model required")
    if not np.asarray(fit).any() or not np.isfinite(aa[fit]).all() or len(x) != len(aa) or len(positions) != len(x):
        raise ValueError("Known earlier AA labels and matching input identities required")
    current = positions[target]
    output, fallback = {}, set()
    fit_counts = {p: int((fit & (positions == p)).sum()) for p in set(current)}
    for q in QUANTILES:
        pooled = regressor(q).fit(x[fit], aa[fit])
        prediction = pooled.predict(x[target])
        if mode == "position":
            for pos in sorted(set(current)):
                own = fit & (positions == pos)
                if own.sum() < 80:
                    fallback.add(pos)
                    continue
                model = regressor(q).fit(x[own], aa[own])
                prediction[current == pos] = model.predict(x[target][current == pos])
        if prediction.shape != (int(target.sum()),) or not np.isfinite(prediction).all():
            raise ValueError("Unconditional AA forecast coverage or finite values differ")
        output[q] = np.repeat(prediction[:, None], len(classes), axis=1)
    return output, {
        "mode": mode,
        "fitCases": int(fit.sum()),
        "targetCases": int(target.sum()),
        "inputFeatures": x.shape[1],
        "fitCasesByTargetPosition": fit_counts,
        "pooledFallbackPositions": sorted(fallback),
        "AAIdenticalAcrossPossibleClasses": True,
        "DSLabelsPassedToAARegressor": False,
    }
