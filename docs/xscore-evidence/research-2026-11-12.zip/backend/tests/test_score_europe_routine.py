"""Testing-only native defensive-point intervals and exposure-weighted history."""

from collections import Counter

import numpy as np
import pytest

from app.research import score_europe_ordinary as ordinary
from app.research import score_europe_routine as routine
from app.research.score_search import moment


def record(points, minutes, cohort="start", source="euro"):
    return dict(
        date="2023-12-20T12:00:00Z",
        minutes=minutes,
        cohort=cohort,
        source=source,
        club="A",
        routine=dict(point=points, lower=points, upper=points, kind="exact"),
        effect=dict(gcInferredZero=False),
    )


def test_null_gc_is_unknown_except_certified_zero_and_never_inferred_from90_minutes():
    effect = routine.effect_bounds("DEF", None, 0, 2, 90)
    assert effect["lower"] == -8
    assert effect["upper"] == 0
    assert effect["gcUnknown"]
    corrected = routine.remove_effect(ordinary.ordinary_bounds(55, 35), effect)
    assert corrected == dict(lower=20, upper=28, point=None, kind="bounded")
    clean = routine.effect_bounds("DEF", None, 1, 2, 80)
    assert clean["lower"] == clean["upper"] == 10
    assert clean["gcInferredZero"]
    team = routine.effect_bounds("MID", None, 0, 0, 20)
    assert team["lower"] == team["upper"] == 0
    assert team["gcSource"] == "team_zero"
    unbounded = routine.effect_bounds("MID", None, None, None, 90)
    assert unbounded["lower"] is None
    assert unbounded["upper"] == 0


def test_censored_aa_never_becomes_exact_zero_after_defensive_removal():
    effect = routine.effect_bounds("DEF", None, 1, 0, 90)
    bounds = routine.remove_effect(ordinary.ordinary_bounds(60, 60), effect)
    assert bounds == dict(lower=None, upper=-10, point=None, kind="upper")
    bounds = routine.remove_effect(ordinary.ordinary_bounds(100, 100), effect)
    assert bounds["kind"] == "unbounded"
    assert bounds["point"] is None
    lower = routine.remove_effect(ordinary.ordinary_bounds(100, 35), routine.effect_bounds("GK", 2, 0, 2, 90))
    assert lower == dict(lower=75, upper=None, point=None, kind="lower")


def test_native_contradictions_and_invalid_flags_are_rejected():
    with pytest.raises(ValueError, match="exceeds"):
        routine.effect_bounds("DEF", 3, 0, 2, 90)
    with pytest.raises(ValueError, match="contradicts"):
        routine.effect_bounds("DEF", 1, 1, 2, 90)
    with pytest.raises(ValueError, match="contradicts"):
        routine.effect_bounds("GK", None, 1, 0, 59)
    with pytest.raises(ValueError, match="count"):
        routine.effect_bounds("MID", False, 0, 2, 90)
    with pytest.raises(ValueError, match="flag"):
        routine.effect_bounds("DEF", 1, 2, 2, 90)


def test_minutes_weighting_prevents_one_minute_rate_from_dominating_and_preserves_mode():
    result = routine.summary([record(1, 1), record(10, 90)], moment("2024-01-05T14:00:00Z"), "A")
    assert np.isclose(result["routine90_weighted_mean"], 90 * 11 / 91)
    assert result["routine90_weighted_median"] == 10
    assert result["routine90_mode"] == 10
    assert result["exact_minutes"] == 91
    bimodal = routine.summary([record(40, 90), record(80, 90)], moment("2024-01-05T14:00:00Z"), "A")
    assert bimodal["routine90_mode"] in (40, 80)
    assert bimodal["routine90_mode"] != 60


def test_zero_and_unknown_aa_and_unknown_cohort_remain_distinct():
    lock = moment("2024-01-05T14:00:00Z")
    zero = routine.summary([record(0, 90, cohort=None)], lock, "B")
    assert zero["routine90_weighted_mean"] == 0
    assert zero["unknown_cohort_fraction"] == 1
    assert zero["same_club_fraction"] == 0
    missing = routine.summary([], lock, "A")
    assert missing["exact_games"] == 0
    assert np.isnan(missing["routine90_weighted_mean"])
    partial = record(0, 90)
    partial["routine"] = dict(point=None, lower=None, upper=0, kind="upper")
    partial = routine.summary([partial], lock, "A")
    assert partial["exact_games"] == 0
    assert np.isnan(partial["routine90_weighted_mean"])
    assert partial["finite_upper90_mean"] == 0
    with pytest.raises(ValueError, match="Unavailable"):
        routine.summary([record(0, 90)], moment("2023-12-22T12:00:00Z"), "A")


def test_european_null_start_flag_is_unknown_not_bench_and_actual_side_is_preserved():
    game = dict(
        id="g",
        date="2023-12-20T12:00:00Z",
        statusTyped="played",
        homeTeam=dict(slug="A"),
        awayTeam=dict(slug="B"),
        homeGoals=1,
        awayGoals=2,
        playerGameScores=[
            dict(
                anyPlayer=dict(slug="p"),
                scoringVersion=7,
                scoreStatus="FINAL",
                score=55,
                decisiveScore=dict(totalScore=35),
                positionTyped="Defender",
                anyPlayerGameStats=dict(
                    anyTeam=dict(slug="A"),
                    playedInGame=True,
                    minsPlayed=20,
                    gameStarted=None,
                    goalsConceded=2,
                    cleanSheet60=0,
                ),
            )
        ],
    )
    rows = routine.euro_records(game, Counter())
    assert len(rows) == 1
    assert rows[0]["cohort"] is None
    assert rows[0]["club"] == "A"
    assert rows[0]["routine"] == dict(lower=28, upper=28, point=28, kind="exact")


def test_noneligible_source_rows_cannot_block_a_valid_final_v7_record():
    valid = dict(
        anyPlayer=dict(slug="p"),
        scoringVersion=7,
        scoreStatus="FINAL",
        score=55,
        decisiveScore=dict(totalScore=35),
        positionTyped="Defender",
        anyPlayerGameStats=dict(
            anyTeam=dict(slug="A"), playedInGame=True, minsPlayed=90, gameStarted=1, goalsConceded=2, cleanSheet60=0
        ),
    )
    game = dict(
        id="g",
        date="2023-12-20T12:00:00Z",
        statusTyped="played",
        homeTeam=dict(slug="A"),
        awayTeam=dict(slug="B"),
        homeGoals=1,
        awayGoals=2,
        playerGameScores=[
            valid,
            dict(anyPlayer=None, scoringVersion=6, score=0),
            dict(anyPlayer=None, scoringVersion=6, score=1),
            {**valid, "scoringVersion": 6, "score": 40},
        ],
    )
    rows = routine.euro_records(game, Counter())
    assert len(rows) == 1
    assert rows[0]["player"] == "p"
    assert rows[0]["score"] == 55


def test_null_start_flag_can_be_certified_by_a_complete_past_named_bench():
    score = dict(
        anyPlayer=dict(slug="p"),
        scoringVersion=7,
        scoreStatus="FINAL",
        score=45,
        decisiveScore=dict(totalScore=35),
        positionTyped="Defender",
        anyPlayerGameStats=dict(
            anyTeam=dict(slug="A"),
            playedInGame=True,
            minsPlayed=20,
            gameStarted=None,
            goalsConceded=None,
            cleanSheet60=0,
        ),
    )
    game = dict(
        id="g",
        date="2023-12-20T12:00:00Z",
        statusTyped="played",
        homeTeam=dict(slug="A"),
        awayTeam=dict(slug="B"),
        homeGoals=1,
        awayGoals=0,
        playerGameScores=[score],
        homeFormation=dict(
            startingLineupAvailable=True,
            startingLineup=[[dict(slug="s" + str(i)) for i in range(11)]],
            bench=[dict(slug="p")],
        ),
    )
    observed = routine.euro_records(game, Counter())
    assert observed[0]["cohort"] == "bench"
    game["homeFormation"]["startingLineupAvailable"] = False
    assert routine.euro_records(game, Counter())[0]["cohort"] is None
