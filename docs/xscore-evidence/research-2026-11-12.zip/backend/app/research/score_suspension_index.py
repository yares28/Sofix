"""Inventory the cached federation suspension and appeal listings."""

import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlsplit

ROOT = Path("data/raw/score-foundation/suspension-source")
OUT = Path("reports/experiments/laliga_score_suspension_index.json")
MARKER = "view-id-sanciones_"
FIELD = r'views-field-{}">.*?<div class="field-content">(.*?)</div>'


def clean(html):
    return " ".join(unescape(re.sub("<[^>]+>", " ", html)).split())


def norm(text):
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower()


class PDFLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("type") == "application/pdf":
            self.links.append(attrs["href"])


def records(html, url):
    _, body = html.split(MARKER, 1)
    view, _ = body.split('<nav aria-label="pagination-heading">', 1)
    result = []
    independent = PDFLinks()
    independent.feed(view)
    literal_links = []
    for line in re.split(r'<div class="views-row">', view)[1:]:
        first = re.findall(r'views-field-(?:name|title)"><span class="field-content">(.*?)</span>', line, re.S)
        description = re.search(FIELD.format("body"), line, re.S)
        links = re.findall(r'href="([^"]+)" type="application/pdf"', line)
        if len(first) != 2 or description is None or len(links) > 1:
            raise ValueError("Index row structure differs")
        link = None
        if links:
            href = unescape(links[0])
            literal_links.append(href)
            link = urljoin(url, href)
            assert urlsplit(link).hostname == "rfef.es" and urlsplit(link).path.lower().endswith(".pdf")
        result.append(dict(section=clean(first[0]), title=clean(first[1]), description=clean(description[1]), pdf=link))
    assert len(result) == 5 and literal_links == independent.links
    return result


def classify(row, kind):
    headline = norm(row["title"] + " " + row["description"])
    if re.search(r"ascenso a primera division|primera division.{0,12}femenin|futbol sala|futbol femenino", headline):
        return "other_competition"
    if "primera division" in headline or "primera division" in norm(row["section"]) or re.search(r"\b1div\b", headline):
        return "candidate_primera"
    if kind == "appeals":
        return "appeal_scope_unresolved"
    return "other_or_scope_unresolved"


def main():
    path = ROOT / "rfef_index_archive_manifest.json"
    raw = path.read_bytes()
    entries = json.loads(raw.decode("utf-8-sig"))
    expected = {(kind, p) for kind, n in (("primera", 34), ("appeals", 22)) for p in range(n)}
    assert {(e["kind"], e["page"]) for e in entries} == expected and len(entries) == len(expected)
    catalogue, status, unlinked = defaultdict(list), Counter(), []
    for page in entries:
        source = Path(page["file"]).read_bytes()
        assert page["status"] == 200 and hashlib.sha256(source).hexdigest() == page["sha256"]
        for row in records(source.decode("utf-8"), page["url"]):
            category = classify(row, page["kind"])
            status[category] += 1
            entry = dict(row, category=category, indexURL=page["url"], kind=page["kind"], page=page["page"])
            if row["pdf"] is None:
                unlinked.append(entry)
            else:
                catalogue[row["pdf"]].append(entry)
    counts = Counter()
    documents = []
    for url, rows in sorted(catalogue.items()):
        categories = {r["category"] for r in rows}
        priority = (
            "candidate_primera"
            if "candidate_primera" in categories
            else ("needs_appeal_scope" if "appeal_scope_unresolved" in categories else "other_or_unknown")
        )
        counts[priority] += 1
        documents.append(dict(url=url, priority=priority, indexRows=rows))
    report = dict(
        manifestSHA=hashlib.sha256(raw).hexdigest(),
        verifiedPages=len(entries),
        indexRows=sum(status.values()),
        classifications=dict(status),
        distinctPDFs=len(catalogue),
        documentPriorities=dict(counts),
        rowsWithoutPDF=unlinked,
        scope="Index inventory only. Document competition, issue and publication clocks, appeals and applicability require separate verification.",
        documents=documents,
    )
    OUT.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "documents"}, indent=2))


if __name__ == "__main__":
    main()
