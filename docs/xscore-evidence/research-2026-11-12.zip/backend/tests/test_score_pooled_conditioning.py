"""Testing only: pooled sources never bypass native labels, cohort or lock boundaries."""

from pathlib import Path

import numpy as np
import pytest

from app.research import score_pooled_conditioning as conditioning


def test_pooled_masks_keep_source_weights_censoring_and_class_support_separate():
    queries = [dict(date="2023-12-01T12:00:00Z", cohort="start", source=s) for s in ("laliga", "euro", "euro", "euro")]
    queries.extend(
        [
            dict(date="2023-12-31T14:00:00Z", cohort="start", source="euro"),
            dict(date="2023-11-01T12:00:00Z", cohort="bench", source="euro"),
        ]
    )
    aa = np.array([0.0, 4.0, np.nan, 5.0, 3.0, 0.0])
    levels = np.array([35.0, 35.0, 60.0, 100.0, 35.0, 35.0])
    ds, ordinary, weights, receipt = conditioning.training_masks(
        queries, aa, levels, "start", "2024-01-01", "2024-01-02T20:00:00Z", np.array([35.0, 60.0]), 0.25
    )
    np.testing.assert_array_equal(ds, [True, True, True, False, False, False])
    np.testing.assert_array_equal(ordinary, [True, True, False, True, False, False])
    np.testing.assert_array_equal(weights, [1.0, 0.25, 0.25, 0.25, 0.25, 0.25])
    assert receipt["europeanDSOutsideLLSupport"] == 1
    assert receipt["europeanCensoredAA"] == 1
    assert receipt["dsFitLaLiga"] == 1
    assert receipt["dsFitEurope"] == 2
    ds, ordinary, _, _ = conditioning.training_masks(
        queries, aa, levels, "start", "2024-01-01", "2024-01-02T20:00:00Z", np.array([35.0, 60.0]), 0
    )
    np.testing.assert_array_equal(ds, [True, False, False, False, False, False])
    np.testing.assert_array_equal(ordinary, ds)
    with pytest.raises(ValueError, match="weight"):
        conditioning.training_masks(
            queries, aa, levels, "start", "2024-01-01", "2024-01-02T20:00:00Z", np.array([35.0, 60.0]), -1
        )


def test_pooled_distribution_keeps_modal_peak_and_exact_within_seven_boundaries():
    from app.research import score_empirical_density as empirical

    classes = np.array([35.0, 60.0])
    probability = np.array([[0.6, 0.4]])
    parts = {q: np.array([[0.0, 0.0]]) for q in (0.35, 0.5, 0.65)}
    bank = {
        "mode": "raw",
        "global": np.array([-7.0, 0.0, 7.0]),
        "positions": {"MID": np.array([-7.0, 0.0, 7.0])},
        "levels": {},
    }
    mass = conditioning.empirical_mass(classes, probability, parts, np.array(["MID"]), bank, 0.75)
    centres = np.arange(0, 100.01, 0.5)
    raw = np.zeros(201)
    for p, level in zip(probability[0], classes, strict=True):
        for error in bank["global"]:
            score = np.clip(level + 0.75 * error, level if level >= 60 else 0, 100)
            raw += p * (abs(score - centres) <= 7) / 3
    np.testing.assert_allclose(mass[0], raw, atol=1e-15, rtol=0)
    expected = empirical.empirical_predictions(classes, probability, parts, np.array(["MID"]), bank, 20, 0.75, 0)
    np.testing.assert_array_equal(conditioning.centres_from_mass(mass), expected)


def test_actual_pooled_models_ignore_outcomes_outside_each_training_set(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(15)
    x = rng.normal(size=(240, 3))
    x[::9, 0] = np.nan
    levels = rng.choice([35.0, 60.0], 240)
    aa = rng.normal(8, 12, 240)
    ds_fit = np.arange(240) < 200
    aa_fit = np.arange(240) < 190
    weights = np.where(np.arange(240) % 3 == 0, 0.25, 1.0)
    target = np.arange(200, 240)
    classes = np.array([35.0, 60.0])
    first = conditioning.fitted_components(x, aa, levels, ds_fit, aa_fit, weights, target, classes)
    aa[~aa_fit], levels[~ds_fit] = np.nan, np.nan
    second = conditioning.fitted_components(x, aa, levels, ds_fit, aa_fit, weights, target, classes)
    np.testing.assert_array_equal(first[0], second[0])
    np.testing.assert_array_equal(first[1], second[1])
    for q in first[2]:
        np.testing.assert_array_equal(first[2][q], second[2][q])
