"""Testing only: shrink full forecast distributions toward the frozen reference."""

from __future__ import annotations

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_ordinary as ordinary
from app.research.score_modal_trees import CENTRES
from app.research.score_windows import window_centres


def validate_mass(mass):
    mass = np.asarray(mass, dtype=float)
    if (
        mass.ndim != 2
        or mass.shape[1] != 201
        or not np.isfinite(mass).all()
        or (mass < 0).any()
        or (mass > 1 + 1e-12).any()
    ):
        raise ValueError("Finite native score-window probabilities required")
    return mass


def empirical_mass(classes, probability, parts, positions, bank):
    classes, probability, positions = np.asarray(classes), np.asarray(probability), np.asarray(positions)
    if (
        probability.shape != (len(positions), len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Valid frozen decisive probabilities required")
    location, scale = empirical.location_scale(parts, "raw")
    scale *= 0.75
    if location.shape != probability.shape or not np.isfinite(location).all():
        raise ValueError("Complete conditional AA locations required")
    mass = np.zeros((len(positions), 201))
    low, high = CENTRES[None, :] - 7, CENTRES[None, :] + 7
    for pos in sorted(set(positions)):
        selected = np.flatnonzero(positions == pos)
        pool = bank["positions"].get(pos, bank["global"])
        for j, level in enumerate(classes):
            floor = level if level >= 60 else 0
            lo = (low - level - location[selected, j, None]) / scale[selected, j, None]
            hi = (high - level - location[selected, j, None]) / scale[selected, j, None]
            clipping = low <= floor, high >= 100, high < floor
            base = empirical.window_mass(pool, lo, hi, *clipping)
            group = bank["levels"].get((pos, float(level)))
            if group is not None and len(group):
                extra = empirical.window_mass(group, lo, hi, *clipping)
                base = (len(group) * extra + 20 * base) / (len(group) + 20)
            mass[selected] += probability[selected, j, None] * base
    return validate_mass(mass)


def lookup_mass(prepared, spec):
    weights = (prepared["valid"] & (np.arange(500)[None, :] < spec["neighbours"])).astype(float)
    weights *= (1 + prepared["distance"]) ** -spec["distancePower"]
    weights *= np.exp2(-prepared["age"] / spec["halfLifeDays"])
    weights *= np.where(prepared["own"], spec["ownPlayerWeight"], 1)
    order, low, high = prepared["windows"]
    cumulative = np.column_stack(
        (np.zeros(len(weights)), np.cumsum(np.take_along_axis(weights, order, axis=1), axis=1))
    )
    raw = np.take_along_axis(cumulative, high, axis=1) - np.take_along_axis(cumulative, low, axis=1)
    totals = weights.sum(axis=1)
    normalized = np.divide(raw, totals[:, None], out=np.zeros_like(raw), where=totals[:, None] > 0)
    fallback = totals <= 0
    normalized[fallback] = (np.abs(prepared["fallback"][fallback, None] - CENTRES) <= 7).astype(float)
    original_prediction = window_centres(raw, CENTRES)
    original_prediction[fallback] = prepared["fallback"][fallback]
    return (
        validate_mass(normalized),
        original_prediction,
        dict(noNeighbourFallbackCases=int(fallback.sum()), target=len(weights)),
    )


def forecast(base, new, weight, control, positions, scope):
    base, new = validate_mass(base), validate_mass(new)
    control, positions = np.asarray(control), np.asarray(positions)
    if (
        base.shape != new.shape
        or control.shape != (len(base),)
        or positions.shape != control.shape
        or not np.isfinite(control).all()
        or not np.isfinite(weight)
        or not 0 <= weight <= 1
    ):
        raise ValueError("Matched all-case distributions, reference and valid mixing weight required")
    if scope not in ("all", "defmid"):
        raise ValueError("Registered density mixing scope required")
    mass = (1 - weight) * base + weight * new
    candidate = control.copy() if weight == 0 else window_centres(mass, CENTRES)
    return ordinary.scoped_prediction(candidate, control, positions, scope), mass
