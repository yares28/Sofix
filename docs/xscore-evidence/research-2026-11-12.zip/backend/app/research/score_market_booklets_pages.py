"""Read-only public booklet source extraction; no odds-to-score formula or fair-P claim."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research.score_search import cutoff_for


def plain(value):
    return "".join(c for c in unicodedata.normalize("NFKD", value.lower()) if not unicodedata.combining(c))


def table_rows(table):
    if not table or [plain(str(v or "")).strip() for v in table[0]] != ["vreme", "", "sifra", "igrac", "tim", "kvota"]:
        raise ValueError("Unrecognized player market table header")
    rows = []
    for r in table[1:]:
        if len(r) != 6 or any(v is None or not str(v).strip() for v in r):
            raise ValueError("Unknown or wrapped player market columns")
        day, clock, code, player, club, quoted = [str(v).strip() for v in r]
        price = quoted.replace(",", ".")
        try:
            number = Decimal(price)
        except InvalidOperation as exc:
            raise ValueError("Invalid player market price") from exc
        if not number.is_finite() or number <= 1 or number > 1000:
            raise ValueError("Invalid player market price")
        if not re.fullmatch(r"\d{1,2}:\d{2}", clock) or not code.isdigit():
            raise ValueError("Invalid printed time/code")
        rows.append(dict(weekday=day, time=clock, code=code, player=player, club=club, decimalOdds=price))
    return rows


def kickoff(weekday, clock, begin, end):
    key = plain(weekday).strip()
    days = {
        "po": 0,
        "pon": 0,
        "ut": 1,
        "uto": 1,
        "sr": 2,
        "sre": 2,
        "ce": 3,
        "cet": 3,
        "pe": 4,
        "pet": 4,
        "su": 5,
        "sub": 5,
        "ne": 6,
        "ned": 6,
    }
    if key not in days:
        raise ValueError("Unrecognized printed weekday")
    selected = [
        begin + timedelta(days=i)
        for i in range((end - begin).days + 1)
        if (begin + timedelta(days=i)).weekday() == days[key]
    ]
    if len(selected) != 1:
        raise ValueError("Printed weekday is not unique in cover range")
    hour, minute = map(int, clock.split(":"))
    return datetime.combine(selected[0], time(hour, minute), ZoneInfo("Europe/Belgrade")).astimezone(UTC)


def available_at(created, modified, publisher_last_modified):
    values = (created, modified, publisher_last_modified)
    if any(v is None for v in values):
        raise ValueError("Missing document/publisher timestamps")
    if any(v.tzinfo is None or v.utcoffset() is None for v in values):
        raise ValueError("Missing timestamp timezone")
    return max(v.astimezone(UTC) for v in values)


def before_lock(available, game):
    return available < cutoff_for(game.isoformat())


def printed_page_range(text):
    ranges = re.findall(r"(\d{1,2})\.(\d{1,2})\.(\d{4})\s*-\s*(\d{1,2})\.(\d{1,2})\.(\d{4})", text)
    unique = set(ranges)
    if len(unique) != 1:
        raise ValueError("Unknown or conflicting quote-page date range")
    a, b, c, d, e, f = map(int, unique.pop())
    begin, end = date(c, b, a), date(f, e, d)
    if not 0 <= (end - begin).days <= 14:
        raise ValueError("Unexpected quote-page range length")
    return begin, end


def market_grid(tables):
    expected = ["vreme", "", "sifra", "igrac", "tim", "kvota"]
    selected = [t for t in tables if t and [plain(str(v or "")).strip() for v in t[0]] == expected]
    if len(selected) != 1:
        raise ValueError("Ambiguous player market grid")
    return selected[0]


def extract_pdf(path, entry):
    import pdfplumber
    from pypdf import PdfReader

    reader = PdfReader(path)
    text_cache = {}

    def text(i):
        if i not in text_cache:
            text_cache[i] = reader.pages[i].extract_text() or ""
        return text_cache[i]

    first = text(0)
    cover = re.search(r"(\d{1,2})\.(\d{1,2})\.(\d{4})\s*-\s*(\d{1,2})\.(\d{1,2})\.(\d{4})", first)
    if cover is None:
        raise ValueError("No complete printed cover date range")
    a, b, c, d, e, f = map(int, cover.groups())
    begin, end = date(c, b, a), date(f, e, d)
    if not 0 <= (end - begin).days <= 14:
        raise ValueError("Unexpected cover length")
    metadata = reader.metadata
    value = entry["LastModified"]
    last_modified = parsedate_to_datetime(value[0] if isinstance(value, list) else value)
    available = available_at(metadata.creation_date, metadata.modification_date, last_modified)
    candidates = set(range(min(12, len(reader.pages))))
    for i in tuple(candidates):
        for hint in re.findall(r"Spain\s+La\s+Liga\s+(\d{1,3})", text(i), re.I):
            p = int(hint) - 1
            candidates.update(j for j in range(p, p + 4) if 0 <= j < len(reader.pages))
    selected = [i for i in sorted(candidates) if re.search(r"GOALSCORER\s+SPAIN\s+LA\s+LIGA", text(i), re.I)]
    if not selected:
        selected = [i for i in range(len(reader.pages)) if re.search(r"GOALSCORER\s+SPAIN\s+LA\s+LIGA", text(i), re.I)]
    records, tables = [], []
    with pdfplumber.open(path) as pdf:
        for i in selected:
            page = pdf.pages[i]
            page_begin, page_end = printed_page_range(text(i))
            for hit in page.search(r"(?i)GOALSCORER SPAIN LA LIGA"):
                enclosing = [
                    r
                    for r in page.rects
                    if r["x0"] <= hit["x0"]
                    and r["x1"] >= hit["x1"]
                    and r["top"] <= hit["top"]
                    and r["bottom"] >= hit["bottom"]
                ]
                if not enclosing:
                    raise ValueError("Player market header has no unambiguous table box")
                rect = min(enclosing, key=lambda r: (r["x1"] - r["x0"]) * (r["bottom"] - r["top"]))
                bbox = (rect["x0"] - 1, rect["bottom"] - 1, rect["x1"] + 1, page.height - 20)
                extracted = page.crop(bbox).extract_tables()
                selected_table = market_grid(extracted)
                rows = table_rows(selected_table)
                tables.append(
                    dict(
                        page=i + 1,
                        bbox=list(bbox),
                        rawRows=selected_table,
                        pageBegin=page_begin.isoformat(),
                        pageEnd=page_end.isoformat(),
                        excludedGridCount=len(extracted) - 1,
                    )
                )
                for row in rows:
                    when = kickoff(row["weekday"], row["time"], page_begin, page_end)
                    records.append(
                        row
                        | dict(
                            page=i + 1,
                            printedPageBegin=page_begin.isoformat(),
                            printedPageEnd=page_end.isoformat(),
                            coverDateMismatch=(page_begin, page_end) != (begin, end),
                            listedTimeUTC=when.isoformat(),
                            inferredLockUTC=cutoff_for(when.isoformat()).isoformat(),
                            metadataBeforeLock=before_lock(available, when),
                            provisionalAvailableUTC=available.isoformat(),
                            eligibleForModel=False,
                            eligibilityReason="Market settlement and original publication evidence not yet verified",
                        )
                    )
    return dict(
        file=path.name,
        url=entry["Url"],
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        coverBegin=begin.isoformat(),
        coverEnd=end.isoformat(),
        creationUTC=metadata.creation_date.astimezone(UTC).isoformat(),
        documentModifiedUTC=metadata.modification_date.astimezone(UTC).isoformat(),
        httpLastModifiedUTC=last_modified.isoformat(),
        provisionalAvailableUTC=available.isoformat(),
        totalPages=len(reader.pages),
        tables=tables,
        records=records,
        primaryMarketLabel="GOALSCORER SPAIN LA LIGA",
        receiptLimit="Publisher metadata corroboration; no independent original-publication receipt",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--folder", type=Path, default=Path("data/raw/score-foundation/player-prop-booklets"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_market_booklets_pages.json"))
    args = parser.parse_args()
    entries, manifests = {}, []
    for manifest in sorted(args.folder.glob("*manifest*.json")):
        raw = manifest.read_bytes()
        manifests.append(dict(file=manifest.name, sha256=hashlib.sha256(raw).hexdigest()))
        values = json.loads(raw.decode("utf-8-sig"))
        for entry in values if isinstance(values, list) else [values]:
            if entry.get("Status", "downloaded") == "downloaded" and "File" in entry:
                entries[entry["File"]] = entry
    results = []
    for filename, entry in sorted(entries.items()):
        path = args.folder / filename
        if path.name != filename or hashlib.sha256(path.read_bytes()).hexdigest() != entry["SHA256"].lower():
            raise ValueError("Pinned downloaded booklet bytes differ")
        result = extract_pdf(path, entry)
        results.append(result)
        print(
            "MARKET_BOOKLET_EXTRACTED "
            + json.dumps(
                dict(
                    file=filename,
                    cover=result["coverBegin"],
                    quotes=len(result["records"]),
                    provisionalPrelock=sum(r["metadataBeforeLock"] for r in result["records"]),
                ),
                ensure_ascii=True,
            ),
            flush=True,
        )
    key = hashlib.sha256(
        Path(__file__).read_bytes()
        + args.out.parent.joinpath("laliga_score_market_source.plan.json").read_bytes()
        + json.dumps(manifests, sort_keys=True).encode()
    ).hexdigest()
    report = dict(
        scope="Public dated booklet source pilot, no formula/data-availability certification or accuracy claim",
        implementationKey=key,
        manifests=manifests,
        booklets=results,
        quotes=sum(len(r["records"]) for r in results),
        modelEligibleQuotes=0,
        next="Independent deterministic extraction/name+fixture/time audit, official market settlement,2023/2026coverage and own-quote repair headroom before any model",
    )
    args.out.write_text(json.dumps(report, indent=2, ensure_ascii=True, allow_nan=False) + "\n")
    print(
        "MARKET_BOOKLET_PILOT "
        + json.dumps(
            dict(implementationKey=key, booklets=len(results), quotes=report["quotes"], modelEligibleQuotes=0)
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
