import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))

from app.research import score_postshot_signal as signal


def test_both_architectures_ignore_every_nontraining_label():
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(6)
    x = rng.normal(size=(240, 49))
    x[::9, -1] = np.nan
    y = rng.integers(0, 2, size=240).astype(float)
    fit, target = np.arange(240) < 180, np.arange(240) >= 180
    blind = y.copy()
    blind[~fit] = np.nan
    for architecture in ("logistic", "nonlinear"):
        original = signal.fitted(x, y, fit, target, architecture)
        proposed = signal.fitted(x, blind, fit, target, architecture)
        np.testing.assert_array_equal(original["probability"], proposed["probability"])
        assert len(proposed["probability"]) == target.sum()


def test_registered_input_schema_and_new_unknowns_preserve_entire_native_population():
    from types import SimpleNamespace

    args = SimpleNamespace(
        cache=Path("data/raw/score-foundation"),
        games=Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl"),
        out=Path("reports/experiments/laliga_score_postshot_signal.json"),
    )
    source, inputs, outcomes, _ = signal.load_inputs(args)
    assert len(source["rows"]) == 38850 and inputs["baseline"].shape == (38850, 45)
    assert inputs["postshot"].shape == (38850, 49)
    np.testing.assert_array_equal(inputs["postshot"][:, :45], inputs["baseline"])
    assert np.isnan(inputs["postshot"][:, -4:]).any()
    assert set(outcomes) == {"goal", "goalassist"} and all(len(v) == 38850 for v in outcomes.values())
