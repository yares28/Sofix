"""Test prospective aerial exposure in a distribution of ordinary points."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research.score_component_replacement import EVENT_KEY
from app.research.score_openplay_aerial_exposure import ARMS
from app.research.score_search import POSITIONS
from app.research.score_shared_error_recovery import compare, snapshots
from app.research.score_stats_run import paired_interval


def ordinary_quantiles(x, points, levels, classes, fit, target):
    from sklearn.ensemble import HistGradientBoostingRegressor

    train = np.column_stack((x[fit], levels[fit]))
    test = x[target]
    grid = np.column_stack((np.tile(test, (len(classes), 1)), np.repeat(classes, len(test))))
    result = {}
    for q in (0.35, 0.5, 0.65):
        model = HistGradientBoostingRegressor(
            loss="quantile",
            quantile=q,
            max_leaf_nodes=15,
            min_samples_leaf=60,
            max_iter=80,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261112,
        ).fit(train, points[fit])
        result[q] = model.predict(grid).reshape(len(classes), len(test)).T
    return result


def load_inputs(args, source, read):
    source_report = read("laliga_score_openplay_duel_source")
    pairing_report = read("laliga_score_openplay_aerial_exposure")
    if pairing_report["sourceKey"] != source["key"] or not all(
        pairing_report["pooled"][group]["passes"]["personalAerialInvolvement"]
        for group in ("startAllOutfield", "benchPrimary")
    ):
        raise ValueError("Required earlier aerial pairing evidence is absent")
    with np.load(args.cache / "openplay-data-v0.1.0" / "aerial_exposure_forecasts.npz") as f:
        if (
            str(f["sourceKey"]) != source["key"]
            or str(f["pairSha"]) != source_report["pairedArtifactSha256"]
            or f["names"].tolist() != [*ARMS, "attemptsPer90"]
            or len(f["x"]) != len(source["rows"])
        ):
            raise ValueError("Aerial forecast features differ from source")
        aerial = f["x"]
    with np.load(args.cache / "event_intensity_features.npz") as f:
        if str(f["key"]) != EVENT_KEY or len(f["x"]) != len(source["rows"]):
            raise ValueError("Pre-lock minute source differs")
        minutes = f["x"][:, f["names"].tolist().index("event_expected_minutes")]
    return aerial, minutes


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads((args.cache / "cases.json").read_text())
    read = lambda name: json.loads((args.out.parent / f"{name}.json").read_text())
    aerial, minutes = load_inputs(args, source, read)
    old = tuple(read(f"laliga_score_{key}") for key in ("match_context", "stability", "ordinary"))
    if any(r["sourceKey"] != source["key"] for r in old):
        raise ValueError("Decisive probabilities are from different cases")
    report = {"scope": "Test only. Reused historical outcomes.", "sourceKey": source["key"], "cohorts": {}}
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        scores, points, levels = (np.array([r[k] for r in rows]) for k in ("score", "aa", "level"))
        pos = np.array([r["pos"] for r in rows])
        base = np.column_stack(([r["x"] for r in rows], minutes[keep], *[pos == p for p in POSITIONS]))
        volume = aerial[keep, -1] * minutes[keep] / 90
        policies = {key: aerial[keep, ARMS.index(key)] for key in (ARMS[0], ARMS[-1])}
        matrices = {key: np.column_stack((base, volume * p, volume * (1 - p))) for key, p in policies.items()}
        has_roster = np.isfinite(volume) & (pos != "GK")
        masks = stability.phase_masks(rows)
        references = snapshots(args, source, rows, cohort, read)
        history, evaluations = {}, {}
        chosen = False
        for phase, _, _ in stability.PHASES:
            if phase == "later2026":
                chosen = all(
                    p["personalAgainstRetained"]["net"] > 0 and p["personalAgainstBroad"]["net"] > 0
                    for p in evaluations.values()
                )
                args.out.with_suffix(f".{cohort}.selection.json").write_text(json.dumps({"personal": chosen}))
                if not chosen:
                    break
            mask = masks[phase]
            fit, target = mask["fit"], mask["target"]
            if (fit & target).any() or not fit.any():
                raise ValueError("Empty or overlapping chronological fit")
            classes, probability, _ = flow.old_components(SimpleNamespace(cache=args.cache), cohort, phase, *old)
            current = {key: ordinary_quantiles(x, points, levels, classes, fit, target) for key, x in matrices.items()}
            if phase != "warm2023":
                previous, previous_classes, previous_mask = history
                old_rows = [r for r, ok in zip(rows, previous_mask, strict=True) if ok]
                valid = stability.previous_bank_mask(old_rows, mask["first"])
                frozen = references[phase][1]
                forecasts = {}
                for key, prediction in current.items():
                    bank = empirical.fit_bank(
                        previous_classes,
                        previous[key],
                        points[previous_mask],
                        levels[previous_mask],
                        pos[previous_mask],
                        valid,
                        "raw",
                    )
                    decoded = empirical.empirical_predictions(
                        classes, probability, prediction, pos[target], bank, 20, 0.75, 0
                    )
                    forecasts[key] = np.where(has_roster[target], decoded, frozen)
                broad, personal = forecasts[ARMS[0]], forecasts[ARMS[-1]]
                all_cases = np.ones(target.sum(), dtype=bool)
                labels = scores[target]
                weeks = [r["week"] for r, ok in zip(rows, target, strict=True) if ok]
                evaluations[phase] = {
                    "fitCases": int(fit.sum()),
                    "referenceResidualCases": int(valid.sum()),
                    "rosterCases": int(has_roster[target].sum()),
                    "broadAgainstRetained": compare(labels, frozen, broad, all_cases),
                    "personalAgainstRetained": compare(labels, frozen, personal, all_cases),
                    "personalAgainstBroad": compare(labels, broad, personal, all_cases),
                    "personalAgainstBroadByPosition": {
                        p: compare(labels, broad, personal, pos[target] == p) for p in POSITIONS
                    },
                    "weeklyPairedGain95AgainstRetained": paired_interval(labels, personal, frozen, weeks),
                }
                print(
                    cohort,
                    phase,
                    {
                        key: evaluations[phase][key]["net"]
                        for key in (
                            "broadAgainstRetained",
                            "personalAgainstRetained",
                            "personalAgainstBroad",
                        )
                    },
                    flush=True,
                )
            history = current, classes, target
        report["cohorts"][cohort] = {"advanced": chosen, "periods": evaluations}
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_aerial_routine.json")
    )
    run(parser.parse_args())


if __name__ == "__main__":
    main()
