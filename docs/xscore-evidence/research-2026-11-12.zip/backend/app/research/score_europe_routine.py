"""Testing only: honest defensive-point removal from older native AA observations."""

from __future__ import annotations

import math

import numpy as np

from app.research import score_europe_ordinary as ordinary
from app.research.score_search import moment
from app.research.score_team_shape_history import weighted_mode

GC_PRICE = {"GK": -5.0, "DEF": -4.0, "MID": -2.0, "FWD": 0.0}
FIELDS = (
    "observed_games",
    "last_days",
    "minutes_mean",
    "exact_games",
    "exact_minutes",
    "routine90_weighted_mean",
    "routine90_weighted_median",
    "routine90_mode",
    "routine90_mode_mass",
    "routine90_sd",
    "upper_fraction",
    "lower_fraction",
    "bounded_fraction",
    "unbounded_fraction",
    "finite_lower90_mean",
    "finite_upper90_mean",
    "euro_fraction",
    "unknown_cohort_fraction",
    "same_club_fraction",
    "inferred_gc0_fraction",
)


def count_value(value, name):
    if value is None:
        return None
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0 or value != int(value):
        raise ValueError("Invalid native count: " + name)
    return float(value)


def clean_value(value):
    if value is None:
        return None
    if type(value) is bool:
        return int(value)
    if type(value) in (int, float) and value in (0, 1):
        return int(value)
    raise ValueError("Invalid native clean-sheet flag")


def effect_bounds(position, conceded, clean, team_against, minutes):
    if (
        position not in GC_PRICE
        or type(minutes) not in (int, float)
        or not math.isfinite(minutes)
        or not 1 <= minutes <= 120
    ):
        raise ValueError("Known position and positive native playing time required")
    gc, total, cs = count_value(conceded, "player GC"), count_value(team_against, "team GC"), clean_value(clean)
    if gc is not None and total is not None and gc > total:
        raise ValueError("Player GC exceeds actual team GC")
    if cs == 1 and ((gc is not None and gc > 0) or minutes < 60):
        raise ValueError("Native clean-sheet flag contradicts GC/minutes")
    inferred = False
    reason = "native" if gc is not None else "unknown"
    if gc is None and total == 0:
        gc, inferred, reason = 0.0, True, "team_zero"
    elif gc is None and cs == 1:
        gc, inferred, reason = 0.0, True, "native_clean_one"
    low_gc, high_gc = (gc, gc) if gc is not None else (0.0, total)
    clean_low, clean_high = ((cs, cs) if cs is not None else (0, 1)) if position == "DEF" else (0, 0)
    price = GC_PRICE[position]
    lower = price * high_gc + 10 * clean_low if high_gc is not None else None
    upper = price * low_gc + 10 * clean_high
    if price == 0:
        lower, upper = 10 * clean_low, 10 * clean_high
    return dict(
        lower=float(lower) if lower is not None else None,
        upper=float(upper),
        gcInferredZero=inferred,
        gcSource=reason,
        gcUnknown=gc is None,
    )


def remove_effect(aa, effect):
    lower = aa["lower"] - effect["upper"] if aa["lower"] is not None and effect["upper"] is not None else None
    upper = aa["upper"] - effect["lower"] if aa["upper"] is not None and effect["lower"] is not None else None
    if lower is not None and upper is not None and lower > upper:
        raise ValueError("Corrected native AA bounds inverted")
    exact = lower is not None and upper is not None and lower == upper
    kind = (
        "exact"
        if exact
        else "bounded"
        if lower is not None and upper is not None
        else "lower"
        if lower is not None
        else "upper"
        if upper is not None
        else "unbounded"
    )
    return dict(
        lower=float(lower) if lower is not None else None,
        upper=float(upper) if upper is not None else None,
        point=float(lower) if exact else None,
        kind=kind,
    )


def euro_records(game, receipt):
    bases = ordinary.game_records(game, receipt)
    eligible_players = {r["player"] for r in bases}
    raw = {}
    for r in game.get("playerGameScores") or []:
        player = (r.get("anyPlayer") or {}).get("slug")
        if (
            player not in eligible_players
            or r.get("scoringVersion") != 7
            or r.get("scoreStatus") != "FINAL"
            or (r.get("anyPlayerGameStats") or {}).get("playedInGame") is not True
        ):
            continue
        if player in raw and raw[player] != r:
            raise ValueError("Conflicting native player rows in same European fixture")
        raw[player] = r
    records = []
    for base in bases:
        stats = raw[base["player"]].get("anyPlayerGameStats") or {}
        home = base["club"] == (game.get("homeTeam") or {}).get("slug")
        against = game.get("awayGoals" if home else "homeGoals")
        try:
            effect = effect_bounds(
                base["pos"], stats.get("goalsConceded"), stats.get("cleanSheet60"), against, base["minutes"]
            )
            routine = remove_effect(base["ordinary"], effect)
        except ValueError as error:
            receipt["invalidRoutine:" + str(error)] += 1
            continue
        records.append(
            {
                **base,
                "source": "euro",
                "routine": routine,
                "effect": effect,
                "nativeConceded": stats.get("goalsConceded"),
                "nativeClean": stats.get("cleanSheet60"),
                "teamAgainst": against,
            }
        )
        receipt["routine:" + routine["kind"]] += 1
        receipt["inferredGC0"] += effect["gcInferredZero"]
    return records


def summary(history, lock, current_club):
    if not history:
        return {f: 0.0 if f in ("observed_games", "exact_games", "exact_minutes") else np.nan for f in FIELDS}
    if any(moment(r["date"]).timestamp() + 172800 >= lock.timestamp() for r in history):
        raise ValueError("Unavailable routine-AA observation in prelock history")
    kinds = {"exact", "bounded", "upper", "lower", "unbounded"}
    if any(r["routine"]["kind"] not in kinds or not 1 <= r["minutes"] <= 120 for r in history):
        raise ValueError("Known interval kinds and positive historical exposure required")
    exact = [r for r in history if r["routine"]["kind"] == "exact"]
    output = dict(
        observed_games=float(len(history)),
        last_days=(lock - moment(history[-1]["date"])).total_seconds() / 86400,
        minutes_mean=float(np.mean([r["minutes"] for r in history])),
        exact_games=float(len(exact)),
        exact_minutes=float(sum(r["minutes"] for r in exact)),
    )
    for field in (
        "routine90_weighted_mean",
        "routine90_weighted_median",
        "routine90_mode",
        "routine90_mode_mass",
        "routine90_sd",
    ):
        output[field] = np.nan
    if exact:
        points, exposure = (
            np.array([r[k] if k == "minutes" else r["routine"]["point"] for r in exact], dtype=float)
            for k in ("point", "minutes")
        )
        rates, weights = 90 * points / exposure, exposure / exposure.sum()
        if not np.isfinite(rates).all():
            raise ValueError("Exact routine AA cannot be missing")
        order = np.argsort(rates, kind="stable")
        median = float(rates[order[np.flatnonzero(np.cumsum(weights[order]) >= 0.5 - 1e-12)[0]]])
        mean = float(90 * points.sum() / exposure.sum())
        mode, mass = weighted_mode(rates, weights)
        output.update(
            routine90_weighted_mean=mean,
            routine90_weighted_median=median,
            routine90_mode=mode,
            routine90_mode_mass=mass,
            routine90_sd=float(np.sqrt(weights @ ((rates - mean) ** 2))),
        )
    for kind in ("upper", "lower", "bounded", "unbounded"):
        output[kind + "_fraction"] = sum(r["routine"]["kind"] == kind for r in history) / len(history)
    for bound in ("lower", "upper"):
        selected = [r for r in history if r["routine"][bound] is not None]
        output["finite_" + bound + "90_mean"] = (
            90 * sum(r["routine"][bound] for r in selected) / sum(r["minutes"] for r in selected)
            if selected
            else np.nan
        )
    output.update(
        euro_fraction=sum(r["source"] == "euro" for r in history) / len(history),
        unknown_cohort_fraction=sum(r["cohort"] is None for r in history) / len(history),
        same_club_fraction=sum(r["club"] == current_club for r in history) / len(history),
        inferred_gc0_fraction=sum(r["effect"]["gcInferredZero"] for r in history) / len(history),
    )
    return output
