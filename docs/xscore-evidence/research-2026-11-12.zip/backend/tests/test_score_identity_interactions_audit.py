import numpy as np

from app.research import score_identity_interactions as core
from app.research import score_identity_interactions_audit as audit


def test_independent_forward_matches_real_model_for_missing_and_cold_identities():
    x = np.array([[0.0, np.nan], [1.0, np.nan], [2.0, np.nan], [3.0, np.nan]])
    cats = np.array([["p", "t", "o"], ["q", "t", "o"], ["p", "t", "u"], ["q", "t", "u"]], dtype=object)
    y = np.array([40.0, 80.0, 80.0, 40.0])
    model = core.InteractionNetwork(rank=2, width=4, epochs=2, seed=31).fit(x, cats, y)
    stored = {
        "normaliser_mean": model.normaliser_.mean_,
        "normaliser_scale": model.normaliser_.scale_,
        "normaliser_known": model.normaliser_.known_,
        **{"w_" + n: v for n, v in model.weights_.items()},
    }
    target = np.array([[2.0, 999.0], [np.nan, np.nan]])
    ids = np.array([["p", "t", "u"], ["cold", "new", None]], dtype=object)
    expected = model.predict_mass(target, ids)
    np.testing.assert_array_equal(audit.independent_forward(target, ids, stored, model.encoder_.maps_), expected)


def test_independent_window_decision_keeps_real_winner_and_scope_population():
    base = np.zeros((3, 201))
    new = base.copy()
    base[:, 80] = 0.6
    new[:, 160] = 0.9
    pred = audit.independent_forecast(
        base, new, 1.0, np.array([40.0, 40.0, 40.0]), np.array(["DEF", "GK", "MID"]), "defmid"
    )
    np.testing.assert_array_equal(pred, [80.0, 40.0, 80.0])
    tied = np.zeros((1, 201))
    tied[0, [80, 160]] = 1
    assert audit.independent_forecast(tied, tied, 1.0, np.array([40.0]), np.array(["DEF"]), "all")[0] == 40.0
