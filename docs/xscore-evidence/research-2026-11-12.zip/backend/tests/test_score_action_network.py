import numpy as np
import pytest

from app.research.score_action_network import ActionNetwork, Normaliser, loss_gradient, probabilities, targets


def test_window_and_auxiliary_targets_keep_endpoints_and_inclusive_seven():
    valid, exact = targets(np.array([0, 40, 80.25, 100]))
    assert valid[1, 66] == 1 and valid[1, 94] == 1
    assert valid[1, 65] == 0 and valid[1, 95] == 0
    np.testing.assert_allclose(exact.sum(axis=1), 1)
    assert exact[2, 160] == exact[2, 161] == 0.5
    assert exact[0, 0] == 1 and exact[-1, -1] == 1
    with pytest.raises(ValueError, match="Known score"):
        targets([np.nan])


def test_normaliser_fits_only_training_data_and_keeps_never_known_fields_inert():
    raw = np.array([[1.0, np.nan], [3.0, np.nan]])
    n = Normaliser().fit(raw)
    before = n.mean_.copy(), n.scale_.copy()
    a = n.transform(np.array([[5.0, np.nan], [5.0, 9999]]))
    np.testing.assert_equal(a[0], a[1])
    np.testing.assert_equal(before[0], n.mean_)
    np.testing.assert_equal(before[1], n.scale_)
    assert np.isfinite(a).all() and a.shape == (2, 4)


@pytest.mark.parametrize("auxiliary", [0, 0.1])
def test_every_parameter_gradient_matches_finite_differences(auxiliary):
    rng = np.random.default_rng(9)
    x = rng.normal(size=(3, 2))
    weights = [rng.normal(0, 0.1, (2, 3)), rng.normal(0, 0.1, 3), rng.normal(0, 0.1, (3, 201)), rng.normal(0, 0.1, 201)]
    valid, exact = targets([30, 45.25, 80])
    _, analytic = loss_gradient(x, valid, exact, weights, 0.01, auxiliary)
    for j, w in enumerate(weights):
        numeric = np.zeros_like(w)
        for at in np.ndindex(w.shape):
            original = w[at]
            w[at] = original + 1e-5
            plus = loss_gradient(x, valid, exact, weights, 0.01, auxiliary)[0]
            w[at] = original - 1e-5
            minus = loss_gradient(x, valid, exact, weights, 0.01, auxiliary)[0]
            w[at] = original
            numeric[at] = (plus - minus) / 2e-5
        np.testing.assert_allclose(analytic[j], numeric, rtol=1e-5, atol=1e-8)


def test_decision_network_can_choose_separated_outcomes_without_an_average():
    x = np.repeat([[-1.0], [1.0]], 30, axis=0)
    y = np.repeat([40.0, 80.0], 30)
    model = ActionNetwork(32, 0.001, 0.1, epochs=160, batch=60).fit(x, y)
    p = model.predict_mass(np.array([[-1.0], [1.0], [np.nan]]))
    prediction = model.predict(np.array([[-1.0], [1.0], [np.nan]]))
    assert abs(prediction[0] - 40) <= 7 and abs(prediction[1] - 80) <= 7
    assert len(prediction) == 3 and np.isfinite(p).all()
    assert model.statistics_["lossLast"] < model.statistics_["lossFirst"]
    # This validates a small synthetic mechanism only, not football accuracy.


def test_softmax_is_stable_with_large_logits():
    x = np.ones((2, 1))
    weights = [np.ones((1, 1)), np.zeros(1), np.full((1, 201), 10000.0), np.arange(201.0)]
    _, p = probabilities(x, weights)
    assert np.isfinite(p).all()
    np.testing.assert_allclose(p.sum(axis=1), 1)
