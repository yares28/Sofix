"""Check whether the trailing passing increase is visible within appearances."""

import hashlib
import json

import numpy as np

from app.research.score_absence_role_signal import REPORTS, ROOT
from app.research.score_card_cycle import PHASES


def paired(rows, a, b):
    chosen = [r for r in rows if min(r["exposure"][a], r["exposure"][b]) >= 10]
    if not chosen:
        return {"n": 0}
    exposure = np.array([r["exposure"] for r in chosen])
    actions = np.array([r["completed"] for r in chosen])
    delta = 90 * (actions[:, a] / exposure[:, a] - actions[:, b] / exposure[:, b])
    return dict(
        n=len(chosen),
        fixtures=len({r["game"] for r in chosen}),
        higher=int((delta > 0).sum()),
        meanPer90=float(delta.mean()),
        medianPer90=float(np.median(delta)),
    )


def main():
    receipt = json.loads((REPORTS / "laliga_score_passing_state.source.json").read_bytes())
    raw = (ROOT / "laliga_score_passing_state.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == receipt["stateArchiveSHA"]
    rows = json.loads(raw)
    phases = {}
    for phase, (begin, end) in PHASES.items():
        phases[phase] = {}
        for role in ("start", "bench"):
            sample = [r for r in rows if begin <= r["date"] < end and r["cohort"] == role]
            phases[phase][role] = {
                "trailingVsLevel": paired(sample, 0, 1),
                "leadingVsLevel": paired(sample, 2, 1),
                "trailingVsLeading": paired(sample, 0, 2),
            }
    result = dict(
        archiveSHA=receipt["stateArchiveSHA"],
        periods=phases,
        interpretation="Within-player same-match comparison, keeping at least ten unambiguous minutes per state. "
        "Different states can occur at different minutes or after an opponent change. This is diagnostic only.",
    )
    (REPORTS / "laliga_score_passing_state_paired.json").write_text(json.dumps(result, indent=2) + "\n")
    for name, phase in phases.items():
        print(
            name,
            {
                role: (d["trailingVsLevel"]["n"], round(d["trailingVsLevel"]["meanPer90"], 2))
                for role, d in phase.items()
            },
        )


if __name__ == "__main__":
    main()
