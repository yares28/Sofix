"""Predict minutes and all stat counts, then select a likely reconstructed Sorare score.

Offline LaLiga experiment. Uses the existing chronological research cohort, not a
fresh blind sample. Does not modify a production forecast or call external APIs.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

from app.research.score_branches import choose_branch
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats import add_stat_features, decisive_level, fit_weights, point_totals, simulate_counts

CONTRACT = {
    "outcome": "Improve LaLiga score within seven if starting and if coming off the bench, separately; aim above 50%",
    "phase": "Estimate minutes and 50 stat counts, reconstruct ordinary points and decisive level, select a likely score rather than average disjoint outcomes",
    "coverage": "Every original eligible appearance; unchanged January-October 2026 research comparison; cold starts retained",
    "split": "Train before July 2025, select July-December 2025, refit before January 2026, evaluate later dates only after selection",
    "calibration": "Residual vectors from latest 20% of earlier training dates, predicted by a model trained on the preceding dates; same position only",
    "userActions": "None; free local calculation, no external calls or production changes",
    "information": "Only pre-lock lagged inputs. Current-game counts, minutes, ordinary points and decisive level are targets, never input features",
    "assumptions": [
        "300 minutes of positional prior for stat-rate shrinkage",
        "48-hour result availability and inferred GW cutoffs",
        "Joint empirical residuals approximate ordinary stat variation",
        "Rare decisive actions are Poisson draws from predicted player rates",
        "On-field goals conceded are Poisson from football-model goals against scaled by minutes; clean sheets obey minutes/goals consistency",
        "Shared point-rule fallback only when all earlier observed positions agree; unknown contributions and reconstruction failures are reported",
    ],
    "evidenceLimit": "These historical dates were examined in earlier research. This is exploratory forward testing, never fresh prospective confirmation",
    "primary": "Within seven on all cases in each cohort; secondary average error, minutes, ordinary points, high-score games and matched baseline comparison",
    "deployment": "Research only; existing production formula unchanged",
}


def paired_interval(y: np.ndarray, candidate: np.ndarray, baseline: np.ndarray, weeks: list[str]) -> list[float]:
    key = np.array(weeks)
    delta = (np.abs(candidate - y) <= 7).astype(float) - (np.abs(baseline - y) <= 7).astype(float)
    values = np.array([[delta[key == w].sum(), (key == w).sum()] for w in sorted(set(weeks))])
    draws = np.random.default_rng(20261103).integers(0, len(values), (2000, len(values)))
    sums = values[draws].sum(axis=1)
    return [float(v) for v in np.quantile(sums[:, 0] / sums[:, 1], [0.025, 0.975])]


def fit_rates(inputs: np.ndarray, targets: np.ndarray, exposures: np.ndarray, minimum: int, mask: np.ndarray):
    from sklearn.ensemble import ExtraTreesRegressor

    scale = np.maximum(np.std(targets[mask], axis=0), 0.05)
    model = ExtraTreesRegressor(
        n_estimators=100, min_samples_leaf=minimum, max_features=0.7, max_depth=16, n_jobs=4, random_state=20261103
    )
    model.fit(inputs[mask], targets[mask] / scale, sample_weight=np.maximum(exposures[mask] / 90, 0.02))
    return model, scale


def previous_branch(
    x: np.ndarray, y: np.ndarray, fit: np.ndarray, check: np.ndarray, specification: dict[str, Any]
) -> np.ndarray:
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

    chosen = specification["chosen"]
    classifier = HistGradientBoostingClassifier(
        max_leaf_nodes=chosen["leaves"],
        min_samples_leaf=80,
        max_iter=120,
        learning_rate=0.06,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )
    classifier.fit(x[fit], y[fit] >= 60)
    outputs = []
    for upper in (False, True):
        regressor = HistGradientBoostingRegressor(
            loss="quantile",
            quantile=chosen["quantile"],
            max_leaf_nodes=chosen["leaves"],
            min_samples_leaf=40,
            max_iter=120,
            learning_rate=0.06,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261103,
        )
        subset = fit & ((y >= 60) == upper)
        regressor.fit(x[subset], y[subset])
        outputs.append(np.clip(regressor.predict(x[check]), 60 if upper else 0, 100 if upper else 60))
    return choose_branch(classifier.predict_proba(x[check])[:, 1], *outputs, chosen["threshold"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--packages", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--previous", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.with_suffix(".plan.json").write_text(json.dumps(CONTRACT, indent=2), encoding="utf-8")
    games = [json.loads(s) for s in args.games.read_text(encoding="utf-8").splitlines() if s.strip()]
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    rows = source["rows"]
    base_names = source["features"]
    stats = sorted(
        {
            stat
            for g in games
            if g["date"][:10] < "2025-07-01"
            for r in g["players"].values()
            for stat in r.get("stats", {})
        }
    )
    key = hashlib.sha256(
        (source["key"] + json.dumps(stats)).encode() + Path(__file__).with_name("score_stats.py").read_bytes()
    ).hexdigest()
    cached = np.load(args.cache) if args.cache.exists() else {}
    if str(cached.get("key", "")) == key:
        x, counts = cached["x"], cached["counts"]
    else:
        x, counts, names = add_stat_features(games, rows, base_names, stats)
        args.cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(args.cache, key=key, x=x, counts=counts, names=np.array(names))
    previous = json.loads(args.previous.read_text(encoding="utf-8"))
    print(json.dumps({"cases": len(rows), "features": x.shape[1], "stats": len(stats)}), flush=True)
    report: dict[str, Any] = {
        "contract": CONTRACT,
        "sourceKey": source["key"],
        "featureKey": key,
        "stats": stats,
        "cohorts": {},
        "status": "running",
    }
    # Independent audit of score construction on the raw recorded counts.
    all_positions = np.array([r["pos"] for r in rows])
    all_scores = np.array([r["score"] for r in rows])
    all_aa = np.array([r["aa"] for r in rows])
    weights, weight_info = fit_weights(games, stats, "2025-07-01")
    rebuilt_aa = point_totals(counts, all_positions, weights)
    rebuilt_level = decisive_level(counts, stats, all_positions)
    rebuilt = np.clip(rebuilt_level + rebuilt_aa, np.where(rebuilt_level >= 60, rebuilt_level, 0), 100)
    report["scoringAudit"] = {
        "cases": len(rows),
        "ordinaryPointMismatches": int((abs(rebuilt_aa - all_aa) > 0.15).sum()),
        "scoreMismatches": int((abs(rebuilt - all_scores) > 0.15).sum()),
        "weights": weight_info,
    }
    if report["scoringAudit"]["scoreMismatches"]:
        raise ValueError("Raw stat-count score reconstruction is incomplete; no appearance may be silently excluded")
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort for r in rows])
        mine = [r for r in rows if r["cohort"] == cohort]
        features = x[selected]
        target = counts[selected]
        y = np.array([r["score"] for r in mine])
        aa = np.array([r["aa"] for r in mine])
        minutes = np.array([r["minutes"] for r in mine], dtype=float)
        positions = np.array([r["pos"] for r in mine])
        dates = np.array([r["date"][:10] for r in mine])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        boundaries = sorted(set(dates[train]))
        cal_boundary = boundaries[int(len(boundaries) * 0.8)]
        fit = train & (dates < cal_boundary)
        calibration = train & ~fit
        rate_target = target * 90 / np.maximum(minutes[:, None], 1)
        prior_minutes = np.array([r["x"][base_names.index(cohort + "_10_minutes")] for r in mine])
        at_home = features[:, base_names.index("home")] > 0
        goals_against = np.where(
            at_home, features[:, base_names.index("match_lam_a")], features[:, base_names.index("match_lam_h")]
        )
        if (goals_against < 0).any():
            raise ValueError("Every case needs earlier football context")
        candidates = []
        best = None
        saved = {}

        def rate_model(
            minimum: int,
            mask: np.ndarray,
            targets: np.ndarray = rate_target,
            inputs: np.ndarray = features,
            exposures: np.ndarray = minutes,
        ):
            return fit_rates(inputs, targets, exposures, minimum, mask)

        for minimum in (30, 100):
            earlier, earlier_scale = rate_model(minimum, fit)
            cal_rates = np.maximum(0, earlier.predict(features[calibration]) * earlier_scale)
            residual = target[calibration] - cal_rates * minutes[calibration, None] / 90
            model, scale = rate_model(minimum, train)
            rates = np.maximum(0, model.predict(features[valid]) * scale)
            for learned in (False, True):
                if learned:
                    parameters = dict(
                        loss="absolute_error",
                        max_leaf_nodes=15,
                        min_samples_leaf=60,
                        max_iter=120,
                        l2_regularization=10,
                        early_stopping=False,
                        random_state=20261103,
                    )
                    minute_model = HistGradientBoostingRegressor(**parameters).fit(features[fit], minutes[fit])
                    cal_minutes = np.clip(minute_model.predict(features[calibration]), 0, 100)
                    minute_model.fit(features[train], minutes[train])
                    predicted_minutes = np.clip(minute_model.predict(features[valid]), 0, 100)
                else:
                    cal_minutes = prior_minutes[calibration]
                    predicted_minutes = prior_minutes[valid]
                min_residual = minutes[calibration] - cal_minutes
                for spread in (0.5, 1.0, 1.5):
                    prediction, aa_prediction = simulate_counts(
                        rates,
                        predicted_minutes,
                        residual,
                        min_residual,
                        minutes[calibration],
                        positions[calibration],
                        positions[valid],
                        weights,
                        stats,
                        goals_against[valid],
                        spread,
                    )
                    for shift in (-3, 0, 3):
                        result = measure(y[valid], np.clip(prediction + shift, 0, 100))
                        spec = {
                            "minimumLeaf": minimum,
                            "learnedMinutes": learned,
                            "residualSpread": spread,
                            "scoreShift": shift,
                            "selection": result,
                        }
                        candidates.append(spec)
                        if best is None or (result["within7"], -result["mae"]) > (
                            best["selection"]["within7"],
                            -best["selection"]["mae"],
                        ):
                            best = spec
                            saved = {"residual": residual, "minuteResidual": min_residual}
                            print(cohort + " LEADER " + json.dumps(spec), flush=True)
        assert best is not None
        # Freeze the earlier-data choice before computing later-game accuracy.
        args.out.with_suffix(f".{cohort}.selection.json").write_text(
            json.dumps({"contract": CONTRACT, "winner": best, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        model, scale = rate_model(best["minimumLeaf"], ~test)
        rates = np.maximum(0, model.predict(features[test]) * scale)
        if best["learnedMinutes"]:
            minute_model = HistGradientBoostingRegressor(
                loss="absolute_error",
                max_leaf_nodes=15,
                min_samples_leaf=60,
                max_iter=120,
                l2_regularization=10,
                early_stopping=False,
                random_state=20261103,
            ).fit(features[~test], minutes[~test])
            predicted_minutes = np.clip(minute_model.predict(features[test]), 0, 100)
        else:
            predicted_minutes = prior_minutes[test]
        test_weights, weight_info = fit_weights(games, stats, "2026-01-01")
        prediction, aa_prediction = simulate_counts(
            rates,
            predicted_minutes,
            saved["residual"],
            saved["minuteResidual"],
            minutes[calibration],
            positions[calibration],
            positions[test],
            test_weights,
            stats,
            goals_against[test],
            best["residualSpread"],
        )
        prediction = np.clip(prediction + best["scoreShift"], 0, 100)
        old = previous_branch(features[:, : len(base_names)], y, ~test, test, previous["cohorts"][cohort])
        weeks = [r["week"] for r, keep in zip(mine, test, strict=True) if keep]
        result = {
            "winner": best,
            "candidateCount": len(candidates),
            "later": measure(y[test], prediction),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "previousBranch": measure(y[test], old),
            "within7Gain95": paired_interval(y[test], prediction, old, weeks),
            "ordinaryPoints": measure(aa[test], aa_prediction),
            "ordinaryPointsFromOwnPast": measure(aa[test], features[test, base_names.index(cohort + "_10_aa")]),
            "minutesMiss": float(np.mean(abs(predicted_minutes - minutes[test]))),
            "minutesWithin15": float(np.mean(abs(predicted_minutes - minutes[test]) <= 15)),
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
            "positions": {},
            "pointRules": weight_info,
            "countMiss": {
                s: float(np.mean(abs(target[test, j] - rates[:, j] * predicted_minutes / 90)))
                for j, s in enumerate(stats)
            },
        }
        for pos in POSITIONS:
            mask = positions[test] == pos
            if mask.any():
                result["positions"][pos] = {
                    "score": measure(y[test][mask], prediction[mask]),
                    "ordinaryPoints": measure(aa[test][mask], aa_prediction[mask]),
                }
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    **{k: v for k, v in result.items() if k not in ("positions", "pointRules", "countMiss")},
                }
            ),
            flush=True,
        )
    report["status"] = "complete research comparison; no production promotion"
    args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
