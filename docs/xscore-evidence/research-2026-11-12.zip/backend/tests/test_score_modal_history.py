import copy

import numpy as np
import pytest

from app.research.score_modal_history import build_history, history_summary, tackle_bounds


def test_history_describes_disjoint_modes_instead_of_replacing_them_with_the_mean():
    values = history_summary([40.0] * 12 + [80.0] * 8)
    assert values["mode"] == values["low_mode"] == 40
    assert values["high_mode"] == 80
    assert values["high_fraction"] == values["high_window_mass"] == 0.4
    assert values["low_window_mass"] == 0.6
    empty = history_summary([])
    assert empty["count"] == 0 and np.isnan(empty["mode"]) and np.isnan(empty["high_fraction"])


def test_bonus_infers_a_tackle_interval_without_inventing_an_exact_count():
    assert tackle_bounds(3, 0, 4) == (2, np.inf)
    assert tackle_bounds(0, 2, 4) == (2, np.inf)
    assert tackle_bounds(3, 3, 4) == (0, 1)
    assert tackle_bounds(3, 3, 6) == (2, 2)
    assert tackle_bounds(2, 3, 6) == (2, np.inf)
    assert tackle_bounds(3, 3, 12) == (3, np.inf)
    assert tackle_bounds(2, 0, 0) == (0, 1)
    assert tackle_bounds(0, 0, 0) == (0, np.inf)
    with pytest.raises(ValueError, match="inconsistent"):
        tackle_bounds(0, 0, 4)


def fixture(identity, date, score=40, bonus=0):
    person = {"pos": "FWD", "started": True, "stats": {"duel_won": [8, 8], "duel_lost": [5, -5]}}
    if bonus:
        person["stats"]["double_double"] = [1, bonus]
    game = {"id": identity, "date": date, "players": {"p": person}}
    row = {
        "game": identity,
        "player": "p",
        "date": date,
        "pos": "FWD",
        "cohort": "start",
        "score": score,
        "minutes": 90,
        "recent": [],
    }
    return game, row


def test_current_and_unavailable_future_outcomes_do_not_enter_history_features():
    pairs = [
        fixture("old", "2025-10-20T18:00:00Z"),
        fixture("target", "2025-11-01T18:00:00Z", 80, 4),
        fixture("next", "2025-11-02T18:00:00Z"),
    ]
    games, rows = map(list, zip(*pairs, strict=True))
    rows[1]["recent"], rows[2]["recent"] = [40], [40]
    first, _, _ = build_history(rows, games)
    changed_rows, changed_games = copy.deepcopy(rows), copy.deepcopy(games)
    changed_rows[1]["score"] = 15
    changed_games[1]["players"]["p"]["stats"].pop("double_double")
    second, _, _ = build_history(changed_rows, changed_games)
    np.testing.assert_array_equal(first, second)


def test_a_result_available_exactly_at_lock_is_excluded_until_a_later_lock():
    pairs = [fixture("old", "2025-10-29T14:00:00Z"), fixture("target", "2025-11-01T18:00:00Z")]
    games, rows = map(list, zip(*pairs, strict=True))
    values, names, _ = build_history(rows, games)
    assert values[1, names.index("modal_history_count")] == 0
    games[0]["date"] = rows[0]["date"] = "2025-10-29T13:00:00Z"
    rows[1]["recent"] = [40]
    values, names, _ = build_history(rows, games)
    assert values[1, names.index("modal_history_count")] == 1


def test_censored_history_audit_is_serializable_without_numpy_integer_leaks():
    import json

    game, row = fixture("g", "2025-10-20T18:00:00Z", bonus=4)
    _, _, audit = build_history([row], [game])
    assert audit["censoredPositiveMinimumRecords"] == 1
    assert json.loads(json.dumps(audit)) == audit
