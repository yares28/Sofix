from datetime import timedelta

import numpy as np

from app.research import score_rolling_strong as rolling
from app.research.score_search import cutoff_for, moment


def parts(classes, count=2, value=5):
    p = np.full((count, len(classes)), 1 / len(classes))
    return np.array(classes, dtype=float), p, {q: np.full(p.shape, value, dtype=float) for q in rolling.QUANTILES}


def test_alignment_keeps_unsupported_classes_at_zero_probability_and_explicitly_unknown():
    padded, known = rolling.aligned(parts([35, 60]))
    np.testing.assert_equal(padded[1].sum(axis=1), 1)
    assert not known[:, 0].any() and not padded[1][:, 0].any()
    assert known[:, 3:5].all()


def test_component_mix_uses_other_supported_quantile_for_a_rare_missing_class():
    old, old_known = rolling.aligned(parts([35, 60], value=10))
    new, new_known = rolling.aligned(parts([35], value=20))
    mixed, known = rolling.combine(old, old_known, new, new_known, "ordinary")
    assert mixed[1][0, 4] == 0.5
    for q in rolling.QUANTILES:
        assert mixed[2][q][0, 3] == 20 and mixed[2][q][0, 4] == 10
    assert known[0, 4]


def test_monthly_fit_embargo_excludes_exact48hour_and_same_lock_results(tmp_path, monkeypatch):
    rows = [
        {"date": date}
        for date in (
            "2023-08-01T20:00:00Z",
            "2024-01-10T13:59:00Z",
            "2024-01-10T14:00:00Z",
            "2024-01-12T20:00:00Z",
            "2024-01-15T20:00:00Z",
            "2024-02-03T20:00:00Z",
        )
    ]
    selected = np.array([False, False, False, True, True, True])
    calls = []

    def fit(x, aa, levels, fit, check):
        anchor = min(cutoff_for(r["date"]) for r, yes in zip(rows, check, strict=True) if yes)
        assert all(moment(r["date"]) + timedelta(hours=48) < anchor for r, yes in zip(rows, fit, strict=True) if yes)
        calls.append((fit.copy(), check.copy()))
        return parts([35, 60], int(check.sum()))

    monkeypatch.setattr(rolling, "conditional_components", fit)
    output, known, receipt = rolling.rolling_parts(
        np.zeros((6, 1)), rows, np.ones(6), np.full(6, 35), selected, 0, tmp_path, "key", "toy"
    )
    assert len(calls) == 2 and calls[0][0][1] and not calls[0][0][2]
    assert not calls[0][0][3:5].any() and calls[1][0][3:5].all()
    assert output[1].shape == known.shape == (3, 9)
    assert sum(r["target"] for r in receipt) == 3


def test_unsupported_past_actual_class_does_not_become_a_zero_filled_AA_error():
    padded, known = rolling.aligned(parts([35]))
    rows = [
        {"date": "2023-12-01T20:00:00Z", "pos": "DEF", "level": 35, "aa": 10},
        {"date": "2023-12-02T20:00:00Z", "pos": "DEF", "level": 60, "aa": 99999},
    ]
    _, audit = rolling.bank_from(padded, known, rows, "2024-01-12T20:00:00Z")
    assert audit == {"cases": 1, "unknownAvailableClassLabels": 1}
