"""Independent native score-window decisions and full chronological refit checks."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import numpy as np

from app.research import score_geometry_conditioning as study
from app.research.score_search import cutoff_for, measure, moment
from app.research.score_team_error_memory_audit import independent_predict


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_geometry_conditioning.json")
    )
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    args.out = args.report
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, reports, all_inputs, provenance = study.load_inputs(args)
    key = study.implementation_key(
        source, reports, provenance, args.report.with_suffix(".plan.json"), sklearn.__version__
    )
    report = json.loads(args.report.read_text())
    if key != report["implementationKey"] or report["sourceKey"] != source["key"]:
        raise ValueError("Geometry study frozen implementation/source differs")
    native = {}
    for game in (json.loads(line) for line in args.games.read_text().splitlines() if line.strip()):
        for player, person in game["players"].items():
            native[game["id"], player] = game, person
    for row in source["rows"]:
        game, p = native[row["game"], row["player"]]
        if (
            game["date"] != row["date"]
            or p["pos"] != row["pos"]
            or p["ver"] != 7
            or not p["played"]
            or p["started"] != (row["cohort"] == "start")
            or p["mins"] != row["minutes"]
            or any(abs(p[k] - row[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Full native geometry-study case identity differs")
    output = dict(
        implementationKey=key, featureKey=provenance["featureKey"], nativeCasesVerified=len(source["rows"]), cohorts={}
    )
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        result = report["cohorts"][cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y, aa, level, positions = (np.array([r[name] for r in rows]) for name in ("score", "aa", "level", "pos"))
        inputs = {group: values[keep] for group, values in all_inputs.items()}
        masks = study.stability.phase_masks(rows)
        call = SimpleNamespace(**{**vars(args), "rows": rows})
        frozen = json.loads(args.report.with_name(args.report.stem + f".{cohort}.frozen.json").read_text())
        active_phases = study.stability.PHASES if frozen["winner"] else study.stability.PHASES[:-1]
        previous, vectors, bundles, masks_checked = None, 0, 0, 0
        for phase, begin, end in active_phases:
            mask = masks[phase]
            np.testing.assert_array_equal(mask["target"], [begin <= r["date"] < end for r in rows])
            np.testing.assert_array_equal(
                mask["fit"],
                [
                    r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < cutoff_for(mask["first"])
                    for r in rows
                ],
            )
            masks_checked += 1
            records = [frozen["winner"]] if phase == "later2026" else frozen["candidates"]
            current = {}
            for group in sorted({r["spec"]["group"] for r in records}):
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_{group}.npz"
                with np.load(path) as f:
                    if str(f["key"]) != key:
                        raise ValueError("Geometry model-bundle key differs")
                    np.testing.assert_array_equal(f["fit"], mask["fit"])
                    np.testing.assert_array_equal(f["target"], mask["target"])
                current[group] = study.components(path, key)
                classes, probability, parts = current[group]
                np.testing.assert_array_equal(classes, np.unique(level[mask["fit"]]))
                if (
                    probability.shape != (int(mask["target"].sum()), len(classes))
                    or not np.isfinite(probability).all()
                    or (probability < 0).any()
                    or not np.allclose(probability.sum(axis=1), 1)
                ):
                    raise ValueError("Complete geometry class probabilities invalid")
                if any(values.shape != probability.shape or not np.isfinite(values).all() for values in parts.values()):
                    raise ValueError("Complete geometry AA components invalid")
                bundles += 1
            old = study.flow.old_components(
                call,
                cohort,
                phase,
                reports["laliga_score_match_context"],
                reports["laliga_score_stability"],
                reports["laliga_score_ordinary"],
            )
            target_rows = [r for r, yes in zip(rows, mask["target"], strict=True) if yes]
            if previous is None:
                previous = target_rows, old, current
                continue
            previous_rows, previous_old, previous_models = previous
            control = study.reference(
                call, key, source, reports, cohort, phase, mask, (previous_rows, previous_old), old
            )
            if measure(y[mask["target"]], control) != result["earlierPeriods"][phase]["control"]:
                raise ValueError("Geometry original reference native metric differs")
            target = mask["target"]
            for group in sorted(current):
                for policy in ("ordinary", "events", "both"):
                    candidates = [r for r in records if r["spec"]["group"] == group and r["spec"]["policy"] == policy]
                    if not candidates:
                        continue
                    pieces = study.helpers.component_policy(old, current[group], policy)
                    previous_pieces = study.helpers.component_policy(previous_old, previous_models[group], policy)
                    bank = study.helpers.bank_from(previous_pieces, previous_rows, mask["first"])
                    # Explicit native clipped-score samples rather than the predictor's residual thresholds.
                    location = np.sort(np.stack([pieces[2][q] for q in (0.35, 0.5, 0.65)]), axis=0)[1]
                    raw = independent_predict(pieces[0], pieces[1], location, positions[target], bank)
                    for candidate in candidates:
                        spec = candidate["spec"]
                        pred = np.array(
                            [
                                value if spec["scope"] == "all" or pos in ("DEF", "MID") else old_value
                                for value, old_value, pos in zip(raw, control, positions[target], strict=True)
                            ]
                        )
                        with np.load(
                            args.cache
                            / f"{args.report.stem}_{cohort}_{phase}_{group}_{policy}_{spec['scope']}_prediction.npz"
                        ) as f:
                            if str(f["key"]) != key:
                                raise ValueError("Geometry forecast vector key differs")
                            np.testing.assert_array_equal(f["y"], y[target])
                            np.testing.assert_array_equal(f["control"], control)
                            np.testing.assert_array_equal(f["prediction"], pred)
                        expected = candidate["periods"][phase]["metrics"] if phase != "later2026" else result["later"]
                        if measure(y[target], pred) != expected:
                            raise ValueError("Independent native geometry candidate metric differs")
                        vectors += 1
            previous = target_rows, old, current
        winner, best = study.stability.choose_stable(frozen["candidates"])
        if winner != frozen["winner"] or best != frozen["best"]:
            raise ValueError("Geometry earlier freeze does not reproduce")
        if not winner and "later" in result:
            raise ValueError("Rejected geometry arm was evaluated on final outcomes")
        spec = (winner or best)["spec"]
        phase = "later2026" if winner else "spring2024"
        mask = masks[phase]
        expected = study.components(args.cache / f"{args.report.stem}_{cohort}_{phase}_{spec['group']}.npz", key)
        blinded_aa, blinded_level = aa.copy(), level.copy()
        blinded_aa[~mask["fit"]], blinded_level[~mask["fit"]] = np.nan, np.nan
        root = args.cache / "geometry-native-refits" / uuid4().hex
        root.mkdir(parents=True)
        actual = study.fitted(
            inputs[spec["group"]], blinded_aa, blinded_level, mask, root / "four-model-native.npz", key
        )
        for a, b in zip(actual[:2], expected[:2], strict=True):
            np.testing.assert_array_equal(a, b)
        for q in actual[2]:
            np.testing.assert_array_equal(actual[2][q], expected[2][q])
        if winner:
            with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
                if (
                    len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
                    or measure(f["y"], f["prediction"]) != result["later"]
                ):
                    raise ValueError("Geometry final full denominator or result differs")
        output["cohorts"][cohort] = dict(
            modelBundlesVerified=bundles,
            independentNativeCandidateVectors=vectors,
            chronologicalMasksVerified=masks_checked,
            frozenSelectionVerified=True,
            actualFourModelRefit=dict(
                phase=phase, allOutsideFitLabelsAbsent=True, allClassesProbabilitiesQuantilesExact=True
            ),
            accepted=bool(winner),
            rejectedFinalNotEvaluated=not winner,
        )
        print("GEOMETRY_MODELS_AUDITED " + json.dumps(dict(cohort=cohort, **output["cohorts"][cohort])), flush=True)
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
