"""Testing only: exact historical observations, difficulty context and transitions."""

from __future__ import annotations

from collections import defaultdict

import numpy as np

from app.research.score_search import cutoff_for, moment

FIELDS = (
    "score",
    "ordinary",
    "level",
    "minutes",
    "home",
    "own_goals",
    "opponent_goals",
    "own_cs",
    "opponent_cs",
    "role",
)


def states(record):
    return int(record[0] >= 35) + int(record[0] >= 60), int(record[1] >= 0) + int(record[1] >= 15)


def sequence_features(rows: list[dict], base_names: list[str], roles: np.ndarray):
    if len(rows) != len(roles):
        raise ValueError("Role records do not match cases")
    index = {name: i for i, name in enumerate(base_names)}
    records = []
    for row, role in zip(rows, roles, strict=True):
        x = row["x"]
        home = x[index["home"]] > 0
        side, other = ("h", "a") if home else ("a", "h")
        context = [
            x[index[f"match_lam_{side}"]],
            x[index[f"match_lam_{other}"]],
            x[index[f"match_cs_{side}"]],
            x[index[f"match_cs_{other}"]],
        ]
        context = [v if v >= 0 else np.nan for v in context]
        vector = np.array(
            [
                row["score"],
                row["aa"],
                row["level"],
                row["minutes"],
                float(home),
                *context,
                float(role) if role != 9 else np.nan,
            ]
        )
        if not np.isfinite(vector[:4]).all():
            raise ValueError("Missing observed performance cannot become zero")
        records.append(
            {
                "available": moment(row["date"]).timestamp() + 48 * 3600,
                "player": row["player"],
                "cohort": row["cohort"],
                "position": row["pos"],
                "vector": vector,
            }
        )
    records.sort(key=lambda r: r["available"])
    names = ["sequence_same_history", "sequence_all_history"]
    for group, n in (("same", 8), ("all", 3)):
        for lag in range(1, n + 1):
            names.extend(f"lag_{group}_{lag}_{field}" for field in FIELDS)
            if group == "all":
                names.append(f"lag_all_{lag}_is_start")
    for kind in ("score", "ordinary"):
        names.extend(f"state_{kind}_p{i}_{j}" for i in range(3) for j in range(3))
        names.extend(f"state_{kind}_next_{j}" for j in range(3))
        names.append(f"state_{kind}_run")
    names.extend(
        f"trend_{field}_{kind}"
        for field in ("score", "ordinary", "minutes")
        for kind in ("slope5", "last_vs3", "mean3_vs10")
    )
    by_cohort = defaultdict(list)
    by_player = defaultdict(list)
    prior = defaultdict(lambda: np.zeros((2, 3, 3)))
    seen = 0
    previous_cutoff = None
    out = []
    for row in rows:
        cutoff = cutoff_for(row["date"]).timestamp()
        if previous_cutoff is not None and cutoff < previous_cutoff:
            raise ValueError("Rows must be chronological")
        previous_cutoff = cutoff
        while seen < len(records) and records[seen]["available"] < cutoff:
            r = records[seen]
            history = by_cohort[r["player"], r["cohort"]]
            if history:
                old, new = states(history[-1]["vector"]), states(r["vector"])
                for k in range(2):
                    prior[r["cohort"], r["position"]][k, old[k], new[k]] += 1
            history.append(r)
            by_player[r["player"]].append(r)
            seen += 1
        history = by_cohort[row["player"], row["cohort"]]
        all_history = by_player[row["player"]]
        values = [len(history), len(all_history)]
        for group, n in ((history, 8), (all_history, 3)):
            for lag in range(1, n + 1):
                record = group[-lag] if len(group) >= lag else None
                values.extend(record["vector"] if record else [np.nan] * len(FIELDS))
                if group is all_history:
                    values.append(float(record["cohort"] == "start") if record else np.nan)
        recent = history[-30:]
        observed = np.array([states(p["vector"]) for p in recent])
        global_counts = prior[row["cohort"], row["pos"]]
        for k in range(2):
            counts = np.zeros((3, 3))
            if len(recent) > 1:
                np.add.at(counts, (observed[:-1, k], observed[1:, k]), 1)
            base = (global_counts[k] + 1) / (global_counts[k].sum(axis=1, keepdims=True) + 3)
            probability = (counts + 5 * base) / (counts.sum(axis=1, keepdims=True) + 5)
            values.extend(probability.ravel())
            values.extend(probability[observed[-1, k]] if len(recent) else [np.nan] * 3)
            run = 0
            if len(recent):
                for value in observed[::-1, k]:
                    if value != observed[-1, k]:
                        break
                    run += 1
            values.append(run if len(recent) else np.nan)
        a = np.array([p["vector"] for p in history[-10:]])
        for column in (0, 1, 3):
            if len(a) > 1:
                last = a[-5:, column]
                time = np.arange(len(last)) - (len(last) - 1) / 2
                values.extend(
                    [
                        np.dot(time, last) / np.dot(time, time),
                        a[-1, column] - a[-3:, column].mean(),
                        a[-3:, column].mean() - a[:, column].mean(),
                    ]
                )
            else:
                values.extend([np.nan] * 3)
        if len(values) != len(names):
            raise ValueError("Sequence feature count mismatch")
        out.append(values)
    return np.asarray(out, dtype=np.float32), names
