"""Independent keeper raw qualifications, projected profiles and future mutation."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from bisect import bisect_left
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta
from functools import cache
from pathlib import Path

import numpy as np

from app.research import score_keeper_quality as study
from app.research.score_search import cutoff_for, moment


def source_check(games, sides, records):
    shots = {(r["game"], r["club"]): r["shots"] for r in sides}
    expected = []
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        for own, other in (("home", "away"), ("away", "home")):
            club, opposite = g[own]["slug"], g[other]["slug"]
            members = [
                (p, r)
                for p, r in g["players"].items()
                if r.get("played") is True and r.get("pos") == "GK" and r.get("team") == club
            ]
            pid, detail = members[0] if len(members) == 1 else (None, {})
            errors = set()
            if len(members) != 1 or detail.get("mins") != 90:
                errors.add("not_one_full90_keeper")
            if detail.get("ver") != 7 or not isinstance(detail.get("stats"), dict):
                errors.add("incomplete_native_sheet")
            saved = float((detail.get("stats") or {}).get("saves", [0])[0])
            gc = float((detail.get("stats") or {}).get("goals_conceded", [0])[0])
            own_goal = sum(
                p.get("stats", {}).get("own_goals", [0])[0]
                for p in g["players"].values()
                if p.get("played") is True and p.get("team") == club
            )
            if own_goal:
                errors.add("own_goal")
            if gc != g[other + "Goals"]:
                errors.add("native_gc_differs_fixture")
            raw = shots.get((g["id"], opposite))
            if raw is None:
                errors.add("missing_opponent_shots")
            quality = []
            for shot in raw or []:
                value = shot.get("xgot_fotmob")
                if value is None:
                    continue
                if type(value) not in (float, int) or not math.isfinite(value) or value < 0 or value > 1:
                    errors.add("invalid_provider_quality")
                    continue
                quality.append(value)
                if value > 0 and shot.get("onTarget") is not True:
                    errors.add("positive_postshot_on_offtarget")
            if len(quality) != saved + gc:
                errors.add("provider_count_differs_native_faced")
            expected.append(
                dict(
                    game=g["id"],
                    date=g["date"],
                    club=club,
                    keeper=pid,
                    minutes=detail.get("mins"),
                    known=not errors,
                    reasons=sorted(errors),
                    saves=saved,
                    conceded=gc,
                    faced=saved + gc,
                    providerCount=len(quality),
                    postshot=sum(quality) if not errors else None,
                    derivedZero=not errors and saved + gc == 0,
                )
            )
    if expected != records:
        raise ValueError("Independent raw keeper source qualification differs")
    return expected


def reconstruct(rows, games, records, feature_names):
    native, teams = defaultdict(list), defaultdict(list)
    observed = {(r["game"], r["keeper"]): r for r in records if r["keeper"] is not None}
    indexed = {g["id"]: g for g in games}
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        lineup = {g[s]["slug"]: [] for s in ("home", "away")}
        for player, p in g["players"].items():
            minutes = p.get("mins")
            if (
                p.get("played") is True
                and p.get("pos") == "GK"
                and p.get("team") in lineup
                and type(minutes) in (float, int)
                and np.isfinite(minutes)
                and minutes > 0
            ):
                lineup[p["team"]].append((player, minutes))
                if p.get("ver") == 7 and isinstance(p.get("stats"), dict):
                    native[player].append((moment(g["date"]), g["id"], p))
        for club, members in lineup.items():
            teams[club].append((moment(g["date"]), members))
    times = {p: [r[0] for r in rs] for p, rs in native.items()}
    team_times = {p: [r[0] for r in rs] for p, rs in teams.items()}

    @cache
    def profile(player, lock, size):
        ts = times.get(player, [])
        end, begin = bisect_left(ts, lock - timedelta(hours=48)), bisect_left(ts, lock - timedelta(days=365))
        past = native.get(player, [])[max(begin, end - size) : end]
        total_minutes = sum(p["mins"] for _, _, p in past)
        total_gc = sum(p["stats"].get("goals_conceded", [0])[0] for _, _, p in past)
        total_faced = total_gc + sum(p["stats"].get("saves", [0])[0] for _, _, p in past)
        good = [
            (date, p, observed[g, player])
            for date, g, p in past
            if (g, player) in observed and observed[g, player]["known"]
        ]
        minutes = sum(p["mins"] for _, p, _ in good)
        goals = sum(r["conceded"] for _, _, r in good)
        faced = sum(r["faced"] for _, _, r in good)
        q = sum(r["postshot"] for _, _, r in good)
        dates = [d for d, _, r in good if r["faced"] > 0]
        return np.array(
            [
                len(past),
                90 * total_faced / total_minutes if total_minutes else np.nan,
                total_gc / total_faced if total_faced else np.nan,
                len(good),
                90 * faced / minutes if minutes else np.nan,
                goals / faced if faced else np.nan,
                minutes / total_minutes if total_minutes else 0.0,
                (lock - max(dates)).total_seconds() / 86400 if dates else np.nan,
                (goals - q) / faced if faced else np.nan,
            ]
        )

    @cache
    def projected(club, lock):
        ts = team_times.get(club, [])
        end, begin = bisect_left(ts, lock - timedelta(hours=48)), bisect_left(ts, lock - timedelta(days=365))
        past = teams.get(club, [])[max(begin, end - 3) : end]
        weights = defaultdict(float)
        for _, members in past:
            for player, minutes in members:
                weights[player] += minutes / len(past)
        values = []
        for size in (3, 10):
            profiles = [(profile(p, lock, size), weight) for p, weight in weights.items()]
            known_weight = sum(w for p, w in profiles if np.isfinite(p[-1]))
            fraction = known_weight / sum(weights.values()) if weights else 0.0
            mean = []
            for j in range(9):
                good = [(p[j], w) for p, w in profiles if np.isfinite(p[j])]
                mean.append(
                    sum(v * w for v, w in good) / sum(w for _, w in good) if sum(w for _, w in good) > 0 else np.nan
                )
            if not weights:
                for j in (0, 3, 6):
                    mean[j] = 0.0
            values.extend([len(weights), sum(weights.values()), fraction, *mean])
        return values

    out = []
    for row in rows:
        g, lock = indexed[row["game"]], cutoff_for(row["date"])
        club = g["away" if row["x"][feature_names.index("home")] > 0 else "home"]["slug"]
        out.append(projected(club, lock))
    return np.array(out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_keeper_quality.json"))
    args = parser.parse_args()
    source, report = json.loads((args.cache / "cases.json").read_text()), json.loads(args.out.read_text())
    raw, shots = args.games.read_bytes(), (args.cache / "shot_style_observations.json.gz").read_bytes()
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + shots
        + Path(study.__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if (
        key != report["featureKey"]
        or hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(shots).hexdigest() != "31f5b36e6bddabeec8a143ebfe21ac213a6bfe7b3fd58f4c92be1f014191ab47"
    ):
        raise ValueError("Pinned source/implementation changed")
    opath, fpath = args.cache / "keeper_quality_observations.json.gz", args.cache / "keeper_quality_features.npz"
    if (
        hashlib.sha256(opath.read_bytes()).hexdigest() != report["observationsSHA"]
        or hashlib.sha256(fpath.read_bytes()).hexdigest() != report["featureSHA"]
    ):
        raise ValueError("Keeper source/feature artifacts changed")
    observed = json.loads(gzip.decompress(opath.read_bytes()))
    with np.load(fpath) as f:
        if str(f["key"]) != key or str(f["source_key"]) != source["key"] or f["x"].shape != (38850, 24):
            raise ValueError("Full native coverage/key differs")
        x = f["x"]
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    records = source_check(games, json.loads(gzip.decompress(shots))["sides"], observed["records"])
    rebuilt = reconstruct(source["rows"], games, records, source["features"])
    np.testing.assert_allclose(rebuilt, x, rtol=0, atol=1e-10, equal_nan=True)
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if cutoff_for(r["date"]) == first]
    targets = [source["rows"][i] for i in indices]
    changed_games, changed_records = deepcopy((games, records))
    ng = nr = 0
    for g in changed_games:
        if moment(g["date"]) + timedelta(hours=48) >= first:
            ng += 1
            g["xi"] = "FUTURE ACTUAL GK"
            for p in g["players"].values():
                p.update(pos="GK", mins=999999, stats={"saves": [999999, 0], "goals_conceded": [999999, 0]})
    for r in changed_records:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            nr += 1
            r.update(known=True, postshot=999999, faced=1999998, conceded=999999, minutes=999999)
    mutated, _, _ = study.build_features(targets, changed_games, changed_records, source["features"])
    np.testing.assert_array_equal(mutated, x[indices])
    result = dict(
        featureKey=key,
        independentRawSideQualifications=len(records),
        nativeForecastCases=len(x),
        independentlyRecomputedColumns=24,
        actualFutureMutation=dict(fixtures=ng, keeperProfiles=nr, targetRows=len(indices), all24columnsExact=True),
        status="COMPLETE independent raw keeper source/all24past-only projected inputs/future-mutation audit",
    )
    args.out.with_suffix(".integrity.json").write_text(json.dumps(result, indent=2) + "\n")
    print("KEEPER_QUALITY_AUDIT " + json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
