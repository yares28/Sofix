"""Independent raw source qualification, all lagged columns, and future mutation."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from functools import lru_cache
from pathlib import Path

import numpy as np

from app.research import score_pass_source_qualified as qualified
from app.research.score_search import cutoff_for, moment


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_pass_source_qualified.json")
    )
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source changed")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    parent_raw = (args.cache / "pass_geometry_corrected_observations.json.gz").read_bytes()
    pressure_raw = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    expected = hashlib.sha256(
        parent_raw
        + pressure_raw
        + raw
        + Path(qualified.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if expected != report["implementationKey"]:
        raise ValueError("Frozen qualification implementation changed")
    compressed = (args.cache / "pass_source_qualified_observations.json.gz").read_bytes()
    if hashlib.sha256(compressed).hexdigest() != report["observationsSha256"]:
        raise ValueError("Qualified observations changed")
    decoded = json.loads(gzip.decompress(compressed))
    parent = json.loads(gzip.decompress(parent_raw))["records"]
    observations = decoded["records"]
    source = json.loads((args.cache / "cases.json").read_text())
    index = {
        r["game"]: (r["sourcePath"], r["sourceBlob"]) for r in json.loads(gzip.decompress(pressure_raw))["observations"]
    }

    @lru_cache(maxsize=8)
    def raw_passes(game_id):
        path, blob = index[game_id]
        canonical = (args.repo / path).read_bytes().replace(b"\r\n", b"\n")
        if hashlib.sha1(b"blob " + str(len(canonical)).encode() + b"\0" + canonical).hexdigest() != blob:
            raise ValueError("Raw source blob changed")
        return json.loads(canonical.decode().partition("=")[2].strip().removesuffix(";")).get("passes")

    values, reasons, unknown = {}, Counter(), 0
    if len(observations) != 34871 or len(parent) != 34871:
        raise ValueError("Source coverage changed")
    for old, record in zip(parent, observations, strict=True):
        if {k: v for k, v in old.items() if k != "values"} != {
            k: v for k, v in record.items() if k not in ("values", "passSourceQuality")
        }:
            raise ValueError("Source identity/metadata changed")
        native = games[record["game"]]
        person = native["players"][record["player"]]
        if (
            person["ver"] != 7
            or not person["played"]
            or person["team"] != record["club"]
            or native["date"] != record["date"]
        ):
            raise ValueError("Native identity differs")
        side = "home" if native["home"]["slug"] == record["club"] else "away"
        events = raw_passes(record["game"])
        stream_known = isinstance(events, list)
        side_events = [e for e in events if e.get("team") == side] if stream_known else []
        tokens = lambda name: tuple(re.findall("[a-z]+", (name or "").lower()))
        actor = tokens(record["geometrySource"]["player"])
        count = sum(tokens(e.get("player")) == actor for e in side_events) if stream_known else None
        if (
            count != record["geometrySource"]["passCount"]
            or stream_known != record["geometrySource"]["passStreamKnown"]
        ):
            raise ValueError("Native source actor count differs")
        completed = person["stats"].get("accurate_pass", [0, 0])[0]
        observed = bool(side_events)
        flags = []
        if not stream_known or count is None:
            flags.append("actor_pass_stream_unavailable")
        if not observed:
            flags.append("side_pass_stream_unobserved")
        if count is not None and completed is not None and count < completed:
            flags.append("native_completed_exceeds_source_attempts")
        expected_quality = dict(
            known=not flags, reasons=flags, sourceAttempts=count, nativeAccurate=completed, sideObserved=observed
        )
        if record["passSourceQuality"] != expected_quality:
            raise ValueError("Independent source qualification differs")
        expected_values = dict(old["values"])
        if flags:
            expected_values.update(dict.fromkeys(qualified.PASS_FIELDS))
        if expected_values != record["values"]:
            raise ValueError("Qualified native values differ")
        values[record["game"], record["player"]] = expected_values
        reasons.update(flags)
        unknown += bool(flags)
    feature_path = args.cache / "pass_source_qualified_features.npz"
    if hashlib.sha256(feature_path.read_bytes()).hexdigest() != report["featuresSha256"]:
        raise ValueError("Qualified features changed")
    with np.load(feature_path) as f:
        x, names, selected = f["x"], f["names"].tolist(), f["qualified"]
        if str(f["key"]) != report["featureKey"]:
            raise ValueError("Qualified feature key differs")
    grouped = defaultdict(list)
    for record in sorted(observations, key=lambda r: moment(r["date"])):
        grouped[record["player"]].append(record)
    times = {p: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for p, rs in grouped.items()}
    subnames = [n for n, keep in zip(names, selected, strict=True) if keep]
    cols = {n: i for i, n in enumerate(subnames)}
    rebuilt = np.full((len(source["rows"]), len(cols)), np.nan)
    for i, row in enumerate(source["rows"]):
        lock = cutoff_for(row["date"])
        end = bisect_left(times.get(row["player"], []), lock.timestamp())
        history = [
            r for r in grouped.get(row["player"], [])[:end] if (lock - moment(r["date"])).total_seconds() <= 365 * 86400
        ]
        same = [r for r in history if r["cohort"] == row["cohort"]]
        for prefix, group in (("same_3", same[-3:]), ("same_10", same[-10:]), ("all_3", history[-3:])):
            for field in qualified.PASS_FIELDS:
                pairs = [
                    (values[r["game"], r["player"]][field], r["minutes"])
                    for r in group
                    if values[r["game"], r["player"]][field] is not None and r["minutes"] > 0
                ]
                weight = sum(m for _, m in pairs)
                rebuilt[i, cols[prefix + "_" + field + "_mean"]] = (
                    math.fsum(v * m for v, m in pairs) / weight if weight else np.nan
                )
                rebuilt[i, cols[prefix + "_" + field + "_count"]] = len(pairs)
    np.testing.assert_allclose(rebuilt, x[:, selected], rtol=0, atol=1e-10, equal_nan=True)
    with np.load(args.cache / "pass_geometry_corrected_features.npz") as f:
        np.testing.assert_array_equal(x[:, ~selected], f["x"][:, ~selected])
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    altered, mutations = [], 0
    for record in observations:
        copy = {**record, "values": dict(record["values"])}
        if moment(record["date"]) + timedelta(hours=48) >= first:
            copy["values"].update({field: 1e6 for field in qualified.PASS_FIELDS})
            mutations += 1
        altered.append(copy)
    changed, changed_names, _ = qualified.recent_features([source["rows"][i] for i in indices], altered, games)
    if changed_names != names:
        raise ValueError("Mutated schema changed")
    np.testing.assert_array_equal(changed, x[indices])
    output = dict(
        implementationKey=expected,
        featureKey=report["featureKey"],
        sourceObservationsVerified=len(observations),
        independentlyRecomputedRows=len(rebuilt),
        independentlyRecomputedColumns=len(cols),
        unchangedOtherColumns=int((~selected).sum()),
        unknownObservations=unknown,
        unknownReasons=dict(reasons),
        actualFutureMutation=dict(
            firstLock=first.isoformat(),
            rows=len(indices),
            unavailableObservationsChanged=mutations,
            all166columnsExact=True,
        ),
        scope="Input qualification only, not formula accuracy",
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("QUALIFIED_SOURCE_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
