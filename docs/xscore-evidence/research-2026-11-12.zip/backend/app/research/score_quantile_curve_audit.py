"""Testing only: complete quantile-bundle/anchor/selection/native-score checks and real refits."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_flow as flow
from app.research import score_matchups_run as matched
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_quantile_curve as curve
from app.research import score_quantile_curve_run as runner
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import measure


def numerical_curves(parts, classes):
    q = np.r_[0.0, curve.QUANTILES, 1.0]
    u = (np.arange(200000) + 0.5) / 200000
    count = 0
    maximum = 0.0
    for case in np.unique(np.linspace(0, len(parts[0.5]) - 1, 4).astype(int)):
        for j, level in enumerate(classes):
            values = np.sort([parts[v][case, j] for v in curve.QUANTILES])
            for tails in ("clamp", "extrapolate"):
                a, b = values[0], values[-1]
                if tails == "extrapolate":
                    a = (values[0] * curve.QUANTILES[1] - values[1] * curve.QUANTILES[0]) / (
                        curve.QUANTILES[1] - curve.QUANTILES[0]
                    )
                    b = values[-1] + (values[-1] - values[-2]) * (1 - curve.QUANTILES[-1]) / (
                        curve.QUANTILES[-1] - curve.QUANTILES[-2]
                    )
                aa = np.interp(u, q, np.r_[a, values, b])
                score = np.sort(np.clip(np.maximum(level if level >= 60 else 0, level + aa), 0, 100))
                native = (
                    np.searchsorted(score, modal.CENTRES + 7, side="right")
                    - np.searchsorted(score, modal.CENTRES - 7, side="left")
                ) / len(score)
                analytical = curve.curve_mass(values[None, :], level, tails)[0]
                error = float(np.max(np.abs(native - analytical)))
                maximum = max(maximum, error)
                count += 1
                if error > 2e-5:
                    raise ValueError("Quantile native numerical integration differs: " + str(error))
    return {
        "caseClassTailProfilesChecked": count,
        "deterministicDrawsPerProfile": len(u),
        "maximumMassDifference": maximum,
        "scope": "Numerical CDF check only, no forecast accuracy claimed",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda n: json.loads((args.report.parent / (n + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Full quantile curve audit source differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Full quantile curve match features differ")
        all_x = np.column_stack((base, f["x"]))
    modules = (curve, flow, matched, controls, modal, ordinary, stability, windows)
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + sklearn.__version__
            + np.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Full quantile curve fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        x = all_x[keep]
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        aa, levels, y = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        selection_path = args.report.with_name(args.report.stem + f".{cohort}.selection120.json")
        frozen, selection = (json.loads(p.read_text()) for p in (frozen_path, selection_path))
        initial_winner, initial_best = stability.choose_stable(frozen["candidates120"])
        confirmed = frozen["best"]
        if (
            frozen["implementationKey"] != key
            or selection["implementationKey"] != key
            or initial_winner != frozen["initialWinner120"]
            or initial_best != frozen["initialBest120"]
            or initial_winner != selection["winner"]
            or initial_best != selection["best"]
            or selection["candidates"] != frozen["candidates120"]
            or confirmed["spec"] != initial_best["spec"]
            or (min(confirmed["gains"]) > 0) != (frozen["winner"] is not None)
            or (frozen["winner"] is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Full quantile curve earlier confirmation/choice differs")
        reconstructed, bundles, individual = 0, 0, 0
        for phase, _, _ in stability.PHASES[1:]:
            fit, target = masks[phase]["fit"], masks[phase]["target"]
            old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Full quantile curve strongest control differs")
            fit_hash = hashlib.sha256(
                np.packbits(fit).tobytes() + np.packbits(target).tobytes() + aa[fit].tobytes() + levels[fit].tobytes()
            ).hexdigest()
            active = (
                [(confirmed, 240)]
                if phase == "later2026"
                else [(r, 120) for r in frozen["candidates120"]] + [(confirmed, 240)]
            )
            for iterations in sorted({i for _, i in active}):
                path = args.cache / f"{args.report.stem}_{cohort}_{phase}_e{iterations}.npz"
                with np.load(path) as f:
                    stats = json.loads(str(f["statistics"]))
                    parts = {q: f[f"q{q}"] for q in curve.QUANTILES}
                    if (
                        str(f["key"]) != key
                        or not np.array_equal(f["classes"], old[0])
                        or not np.array_equal(f["probability"], old[1])
                        or stats["fitHash"] != fit_hash
                        or stats["fitCases"] != int(fit.sum())
                        or stats["targetCases"] != int(target.sum())
                        or stats["iterations"] != iterations
                        or stats["quantileLevels"] != list(curve.QUANTILES)
                        or any(
                            v.shape != (int(target.sum()), len(old[0])) or not np.isfinite(v).all()
                            for v in parts.values()
                        )
                    ):
                        raise ValueError("Full quantile bundle/mask/class/coverage differs")
                stacked = np.stack([parts[q] for q in curve.QUANTILES])
                if stats["quantileArraySha256"] != hashlib.sha256(stacked.tobytes()).hexdigest():
                    raise ValueError("Full quantile array fingerprint differs")
                reused = [0.35, 0.5, 0.65] if iterations == 120 else []
                fitted = [q for q in curve.QUANTILES if q not in reused or q == 0.5]
                if stats["quantilesReused"] != reused or stats["quantilesFittedOrReloaded"] != fitted:
                    raise ValueError("Full quantile anchor/fitting receipt differs")
                for q in reused:
                    if not np.array_equal(parts[q], old[2][q]):
                        raise ValueError("Original AA anchor was changed")
                for q in fitted:
                    qpath = (
                        args.cache
                        / f"{args.report.stem}_{cohort}_{phase}_i{iterations}_q{str(q).replace('.', 'p')}.npz"
                    )
                    with np.load(qpath) as f:
                        if (
                            str(f["key"]) != key
                            or str(f["fitHash"]) != fit_hash
                            or not np.array_equal(f["classes"], old[0])
                            or float(f["quantile"]) != q
                            or int(f["iterations"]) != iterations
                        ):
                            raise ValueError("Individual AA quantile provenance differs")
                        delta = float(np.max(np.abs(f["prediction"] - parts[q])))
                    if q == 0.5 and reused:
                        if delta != stats["anchorMedianMaximumDifference"] or delta > 1e-10:
                            raise ValueError("Original median anchor independent refit differs")
                    elif delta != 0:
                        raise ValueError("Individual AA quantile does not match common bundle")
                    individual += 1
                bundles += 1
                for record, _ in [a for a in active if a[1] == iterations]:
                    spec = record["spec"]
                    mass = curve.forecast_mass(old[0], old[1], parts, spec["model"])
                    raw = windows.window_centres(mass, modal.CENTRES)
                    forecast = ordinary.scoped_prediction(raw, control, positions[target], spec["scope"])
                    if phase == "later2026":
                        alternate = forecast
                        final_parts = parts
                    elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                        raise ValueError("Full quantile curve earlier forecasts do not reconstruct")
                    reconstructed += 1
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Full quantile curve all-case native final identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Full quantile curve final native metric differs")
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "commonBundlesVerified": bundles,
            "individualQuantileCachesVerified": individual,
            "candidateForecastsReconstructed": reconstructed,
            "fixedLongerTrainingConfirmationVerified": True,
            "nativeNumericalCurveChecks": numerical_curves(final_parts, old[0]),
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            aa[~fit] = np.nan
            levels[~fit] = np.nan
            print(f"QUANTILE_CURVE_AUDIT_REFIT {cohort} all11models", flush=True)
            repeated, _ = curve.fit_quantiles(
                x, aa, levels, fit, target, old[0], old[2], 240, prefix=f"audit_{cohort}_final"
            )
            if any(not np.array_equal(repeated[q], final_parts[q]) for q in curve.QUANTILES):
                raise ValueError("Actual final11quantile refit changed when outside-fit AA/DS blanked")
            evidence[cohort]["real11ModelRefitAfterOutsideFitLabelsBlanked"] = {
                "outsideFitAAandDSRowsBlanked": int((~fit).sum()),
                "all11PossibleClassQuantileArraysReproduced": True,
            }
    output = {
        "scope": "Testing-only full native audit; exploratory reuse not fresh blind proof",
        "implementationKey": key,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
