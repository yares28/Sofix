"""Controlled LaLiga team-style and historical-role feature experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_europe_run import predict_components, select_components
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_hybrid import choose_level, conditional_components
from app.research.score_stats_run import paired_interval
from app.research.score_style import style_features


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "games", "control", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    control = json.loads(args.control.read_text(encoding="utf-8"))
    if source["key"] != control["sourceKey"]:
        raise ValueError("Control source differs")
    with np.load(args.stats_cache) as stored:
        x = stored["x"]
        stat_key = str(stored["key"])
    raw_bytes = args.games.read_bytes()
    games = [json.loads(s) for s in raw_bytes.decode("utf-8").splitlines() if s.strip()]
    key = hashlib.sha256(
        source["key"].encode() + raw_bytes + Path(__file__).with_name("score_style.py").read_bytes()
    ).hexdigest()
    feature_cache = args.cache / "style_features.npz"
    cached = np.load(feature_cache) if feature_cache.exists() else None
    if cached is not None and str(cached["key"]) == key:
        features, names = cached["x"], cached["names"].tolist()
        receipt = json.loads(str(cached["receipt"]))
        cached.close()
    else:
        if cached is not None:
            cached.close()
        features, names, receipt = style_features(games, source["rows"])
        np.savez_compressed(feature_cache, x=features, names=names, receipt=json.dumps(receipt), key=key)
    print("Style inputs: " + json.dumps({**receipt, "features": len(names)}), flush=True)
    groups = {
        "team_style": np.column_stack((x, features[:, [not n.startswith("role_") for n in names]])),
        "team_style_role": np.column_stack((x, features)),
    }
    fit_key = hashlib.sha256(
        (key + stat_key).encode()
        + Path(__file__).read_bytes()
        + Path(__file__).with_name("score_stats_hybrid.py").read_bytes()
    ).hexdigest()
    report = {
        "target": "Actual score within seven on every LaLiga starter and played substitute, separate cohorts",
        "split": "Train before July2025; choose July-Dec2025; refit before Jan2026; compare Jan-Oct2026",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind validation",
        "sourceKey": source["key"],
        "statKey": stat_key,
        "featureKey": key,
        "implementationKey": fit_key,
        "receipt": receipt,
        "features": names,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        aa = np.array([r["aa"] for r in rows])
        level = np.array([r["level"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"

        def components(name, fit, check, label, cohort=cohort, keep=keep, aa=aa, level=level):
            path = args.cache / f"style_{cohort}_{name}_{label}.npz"
            if path.exists():
                with np.load(path) as previous:
                    if str(previous["key"]) == fit_key:
                        return (
                            previous["classes"],
                            previous["probability"],
                            {q: previous[f"q{q}"] for q in (0.35, 0.5, 0.65)},
                        )
            classes, probability, parts = conditional_components(groups[name][keep], aa, level, fit, check)
            np.savez_compressed(
                path, key=fit_key, classes=classes, probability=probability, **{f"q{q}": v for q, v in parts.items()}
            )
            return classes, probability, parts

        selection = {"control": control["cohorts"][cohort]["selection"]["control"]}
        for name in groups:
            winner, candidates = select_components(components(name, train, valid, "selection"), y[valid])
            selection[name] = winner
            args.out.with_suffix(f".{cohort}.{name}.selection.json").write_text(
                json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
            )
            print(f"Selected {cohort} {name}: " + json.dumps(winner), flush=True)
        chosen = max(selection, key=lambda n: (selection[n]["selection"]["within7"], -selection[n]["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"chosen": chosen, "selection": selection}, indent=2), encoding="utf-8"
        )
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as baseline:
            if not np.array_equal(baseline["y"], y[test]):
                raise ValueError("Control comparison cases differ")
            predictions = {"control": baseline["control"]}
        ordinary = {}
        for name in groups:
            part = components(name, ~test, test, "later")
            predictions[name] = predict_components(part, selection[name])
            # Ordinary-point estimates correspond to the chosen branch, never the actual later level.
            lev = choose_level(part[1], part[0], selection[name]["threshold"])
            indices = np.searchsorted(part[0], lev)
            ordinary[name] = (
                part[2][selection[name]["quantile"]][np.arange(len(indices)), indices]
                + selection[name]["ordinaryShift"]
            )
            print(f"Evaluated {cohort} {name}", flush=True)
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        pos = np.array([r["pos"] for r in rows])[test]
        result = {"chosen": chosen, "selection": selection, "groups": {}}
        for name, prediction in predictions.items():
            result["groups"][name] = {
                "later": measure(y[test], prediction),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "gain95": paired_interval(y[test], prediction, predictions["control"], weeks),
                "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
                "positions": {
                    p: measure(y[test][pos == p], prediction[pos == p]) for p in POSITIONS if (pos == p).any()
                },
            }
            if name in ordinary:
                result["groups"][name]["ordinaryPoints"] = measure(aa[test], ordinary[name])
        np.savez_compressed(args.cache / f"style_predictions_{cohort}.npz", **predictions, y=y[test], key=fit_key)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, "chosen": chosen, "groups": {n: m["later"] for n, m in result["groups"].items()}}
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
