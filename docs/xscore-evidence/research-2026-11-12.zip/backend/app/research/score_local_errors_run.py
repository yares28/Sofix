"""Testing only: chronological local calibration of genuine out-of-fit AA errors."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_local_errors as local
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_matchups_run import validate_stat_identity
from app.research.score_search import POSITIONS, cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval


def calibration_records(rows, context, parts):
    classes, probability, quantiles = parts
    known = np.isin([r["level"] for r in rows], classes)
    indices = np.flatnonzero(known)
    labels = np.array([r["level"] for r in rows])[known]
    columns = np.searchsorted(classes, labels)
    q = np.sort(np.stack([quantiles[v] for v in (0.35, 0.5, 0.65)]), axis=0)
    predicted = q[1, indices, columns]
    record = {
        "available": np.array([(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rows])[known],
        "position": np.array([r["pos"] for r in rows])[known],
        "player": np.array([r["player"] for r in rows])[known],
        "level": labels,
        "error": np.array([r["aa"] for r in rows])[known] - predicted,
        "x": np.column_stack(
            (context[known], predicted, q[2, indices, columns] - q[0, indices, columns], probability[indices, columns])
        ),
    }
    return record, int((~known).sum())


def predicted_phase(bank, rows, context, parts, settings, path, key):
    if path.exists():
        with np.load(path) as f:
            if str(f["key"]) != key or any(f["p_" + name].shape != (len(rows),) for name in settings):
                raise ValueError("Local error phase cache identity differs")
            return {name: f["p_" + name] for name in settings}, json.loads(str(f["audit"]))
    locks = np.array([cutoff_for(r["date"]).timestamp() for r in rows])
    model = local.LocalErrors(bank, locks.min())
    predictions = {name: np.full(len(rows), np.nan) for name in settings}
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        groups[locks[i], row["pos"]].append(i)
    audit = {
        "cases": len(rows),
        "groups": len(groups),
        "positionFallbackGroups": 0,
        "emptyLevelFallbacks": 0,
        "minimumEarlierErrors": len(bank["error"]),
        "maximumEarlierErrors": 0,
    }
    for count, ((lock, position), cases) in enumerate(sorted(groups.items()), 1):
        at = np.array(cases)
        output, evidence = model.predict_group(
            context[at],
            parts[0],
            parts[1][at],
            {q: value[at] for q, value in parts[2].items()},
            position,
            [rows[i]["player"] for i in cases],
            lock,
            settings,
        )
        for name in settings:
            predictions[name][at] = output[name]
        audit["positionFallbackGroups"] += int(evidence["positionFallback"])
        audit["emptyLevelFallbacks"] += evidence["emptyLevelFallbacks"]
        audit["minimumEarlierErrors"] = min(audit["minimumEarlierErrors"], evidence["earlierErrors"])
        audit["maximumEarlierErrors"] = max(audit["maximumEarlierErrors"], evidence["earlierErrors"])
        if count % 20 == 0:
            print(f"ERROR_GROUPS {count}/{len(groups)}", flush=True)
    if any(not np.isfinite(p).all() or ((p < 0) | (p > 100)).any() for p in predictions.values()):
        raise ValueError("Local error forecast cases missing or out of bounds")
    np.savez_compressed(path, key=key, audit=json.dumps(audit), **{"p_" + name: p for name, p in predictions.items()})
    return predictions, audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "stats-cache", "match-cache", "player-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import scipy
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Local error source cases differ")
    with np.load(args.stats_cache) as f:
        base, names, stat_key = f["x"], f["names"].tolist(), str(f["key"])
        validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.match_cache) as f:
        match, match_names = f["x"], f["names"].tolist()
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Local error match feature identity differs")
    with np.load(args.player_cache) as f:
        player, player_names = f["x"], f["names"].tolist()
        if str(f["key"]) != old_player["featureKey"]:
            raise ValueError("Local error player feature identity differs")
    files = [
        Path(__file__),
        Path(local.__file__),
        Path(controls.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + np.__version__
            + scipy.__version__
        ).encode()
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only, no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Retrospective reused outcomes, not fresh blind proof",
        "cohorts": {},
    }
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        selected = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        numeric, ordinary_names = ordinary.ordinary_inputs(
            base[selected], names, player[selected], player_names, match[selected], match_names, cohort
        )
        context_names = [n.format(c=cohort) for n in local.CONTEXT]
        context = numeric[:, [ordinary_names.index(n) for n in context_names]]
        masks = stability.phase_masks(rows)
        candidates = [
            {"spec": {"setting": setting, "scope": scope}, "gains": [], "errors": [], "counts": [], "periods": {}}
            for setting in local.SETTINGS
            for scope in ("all", "defmid")
        ]
        bank, winner, best = None, None, None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            components = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            current, unknown = calibration_records(target_rows, context[target], components)
            bank = current if bank is None else {name: np.concatenate((bank[name], current[name])) for name in bank}
            if phase == "warm2023":
                continue
            if phase == "later2026" and best is None:
                raise ValueError("Local error choice must freeze before final outcomes")
            active = [best] if phase == "later2026" else candidates
            settings = {r["spec"]["setting"]: local.SETTINGS[r["spec"]["setting"]] for r in active}
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric != expected:
                raise ValueError("Local error strongest control did not exactly reproduce")
            print(f"CALIBRATING {cohort} {phase} {len(settings)}settings {int(target.sum())}cases", flush=True)
            forecasts, evidence = predicted_phase(
                bank,
                target_rows,
                context[target],
                components,
                settings,
                args.cache / f"{args.out.stem}_{cohort}_{phase}_predictions.npz",
                key,
            )
            audit[phase] = {
                "fit": int(mask["fit"].sum()),
                "target": int(target.sum()),
                "control": metric,
                "calibration": evidence,
                "unknownCurrentCalibrationLevels": unknown,
            }
            for record in active:
                spec = record["spec"]
                prediction = ordinary.scoped_prediction(
                    forecasts[spec["setting"]], control, positions[target], spec["scope"]
                )
                measured = measure(y[target], prediction)
                if phase == "later2026":
                    alternate = prediction
                else:
                    gain = measured["within7"] - metric["within7"]
                    record["gains"].append(gain)
                    record["errors"].append(measured["mae"])
                    record["counts"].append(len(prediction))
                    record["periods"][phase] = {"gain": gain, "metrics": measured}
            if phase == "autumn2025":
                winner, best = stability.choose_stable(candidates)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in candidates),
                    "candidates": candidates,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(candidates) + 1,
            "earlierPeriods": audit,
            "featureNames": context_names + ["predicted_aa", "predicted_aa_width", "predicted_level_probability"],
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": metric,
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateGain95": paired_interval(y[target], alternate, control, [r["week"] for r in target_rows]),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "candidateLater": result["candidateLater"],
                    "later": result["later"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
