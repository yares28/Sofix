from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_geometry_conditioning as study


def test_geometry_arms_have_identical_base_and_preserve_unknown_columns():
    base = np.array([[1.0, 2.0], [3.0, 4.0]])
    legacy = np.array([[np.nan, 5.0, 7.0], [8.0, 9.0, 10.0]])
    fixed = legacy.copy()
    fixed[:, 1] = [50.0, 90.0]
    inputs = study.feature_arms(base, legacy, fixed, np.array([False, True, True]))
    np.testing.assert_array_equal(inputs["legacy_geometry"][:, :2], base)
    np.testing.assert_array_equal(inputs["corrected_geometry"][:, :2], base)
    assert inputs["legacy_geometry"].shape == inputs["corrected_geometry"].shape == (2, 4)
    np.testing.assert_array_equal(inputs["corrected_geometry"][:, 2], [50.0, 90.0])


def test_real_conditional_fit_ignores_every_outsidefit_outcome(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(33)
    x = rng.normal(size=(480, 3))
    aa = rng.normal(10, 5, 480)
    levels = np.where(np.arange(480) % 3 == 0, 60.0, 35.0)
    mask = {"fit": np.arange(480) < 400, "target": np.arange(480) >= 400}
    root = Path(__file__).parents[1] / "data/raw/geometry-fit-tests" / uuid4().hex
    root.mkdir(parents=True)
    a = study.fitted(x, aa, levels, mask, root / "a.npz", "fixture")
    aa[~mask["fit"]] = np.nan
    levels[~mask["fit"]] = np.nan
    b = study.fitted(x, aa, levels, mask, root / "b.npz", "fixture")
    for left, right in zip(a[:2], b[:2], strict=True):
        np.testing.assert_array_equal(left, right)
    for q in a[2]:
        np.testing.assert_array_equal(a[2][q], b[2][q])
