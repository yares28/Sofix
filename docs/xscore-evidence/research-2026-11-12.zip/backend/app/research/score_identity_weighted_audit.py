"""Independent native identity-frequency and inherited full-refit verification."""

import hashlib
import json

import numpy as np

from app.research import score_identity_interactions_audit as auditor
from app.research import score_identity_weighted as network
from app.research import score_identity_weighted_run as adapter

original_verify = auditor.verify_bundle


def verify_bundle(path, key, x, cats, scores, mask, spec, epochs):
    mass, data = original_verify(path, key, x, cats, scores, mask, spec, epochs)
    stats = json.loads(str(data["statistics"]))
    maps = json.loads(str(data["category_maps"]))
    values = []
    for j, mapping in enumerate(maps):
        counts = {name: 0 for name in mapping}
        for value in cats[mask["fit"], j]:
            if str(value) in counts:
                counts[str(value)] += 1
        total = sum(counts.values()) + 20 * len(mapping)
        weights = np.zeros(len(mapping) + 1, dtype=np.float32)
        for name, index in mapping.items():
            weights[index] = (counts[name] + 20) / total
        values.append(weights)
    digest = hashlib.sha256(b"".join(v.tobytes() for v in values)).hexdigest()
    if digest != stats["embeddingPenaltyWeightsSha256"] or stats["identityPrior"] != 20:
        raise ValueError("Independent training-only identity population penalty differs")
    return mass, data


if __name__ == "__main__":
    auditor.runner = adapter.configure()
    auditor.core = network
    auditor.verify_bundle = verify_bundle
    auditor.main()
