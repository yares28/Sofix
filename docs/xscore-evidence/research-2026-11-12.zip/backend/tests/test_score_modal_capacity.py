import numpy as np

from app.research.score_modal_capacity import PARAMETERS, CapacityForest, candidate_feature_count


def test_registered_capacity_grid_has_all_depth_leaf_and_feature_combinations():
    assert len(PARAMETERS) == 18
    combinations = {(p["depth"], p["minLeaf"], p["features"]) for p in PARAMETERS.values()}
    assert combinations == {
        (d, leaf, feature) for d in (8, 12) for leaf in (20, 40, 80) for feature in ("sqrt", "quarter", "all")
    }
    assert candidate_feature_count(159, "sqrt") == 12
    assert candidate_feature_count(159, "quarter") == 40
    assert candidate_feature_count(159, "all") is None


def test_expanded_forest_uses_declared_capacity_and_preserves_every_prediction():
    x = np.column_stack((np.arange(100.0), np.arange(100.0) % 3, np.zeros(100)))
    y = np.where(x[:, 0] < 50, 40.0, 80)
    weeks = np.array([str(i // 10) for i in range(100)])
    model = CapacityForest(4, 4, 5, "all").fit(x, y, weeks)
    assert model.statistics_["candidateFeaturesPerNode"] == 3
    assert model.statistics_["uniqueLeafMinimum"] == 5
    assert model.statistics_["depthLimit"] == 4
    prediction = model.predict(x)
    assert len(prediction) == 100
    assert ((prediction >= 0) & (prediction <= 100)).all()


def test_confirmation_forest_keeps_the_same_first_members_as_smaller_search_forest():
    x = np.arange(80.0)[:, None]
    y = np.where(x[:, 0] < 40, 40.0, 80)
    weeks = np.array([str(i // 8) for i in range(80)])
    smaller = CapacityForest(2, 3, 4, "quarter").fit(x, y, weeks)
    larger = CapacityForest(4, 3, 4, "quarter").fit(x, y, weeks)
    binned = smaller.binner_.transform(x)
    for i in range(2):
        np.testing.assert_array_equal(
            smaller.trees_[i].predict_binned_mass(binned), larger.trees_[i].predict_binned_mass(binned)
        )
