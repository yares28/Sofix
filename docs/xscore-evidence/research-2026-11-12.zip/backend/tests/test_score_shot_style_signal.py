from pathlib import Path

import numpy as np

from app.research import score_shot_style_signal as signal


def test_real_binary_signal_fit_ignores_outsidefit_labels_and_uses_fit_only_scales(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    rng = np.random.default_rng(11)
    x = rng.normal(size=(200, 4))
    x[::7, -1] = np.nan
    y = (rng.random(200) < 0.3).astype(float)
    fit = np.arange(200) < 160
    target = ~fit
    before = signal.fitted(x, y, fit, target)
    y[target] = np.nan
    after = signal.fitted(x, y, fit, target)
    np.testing.assert_array_equal(before["probability"], after["probability"])
    altered = x.copy()
    altered[target] = 1e6
    changed = signal.fitted(altered, y, fit, target)
    for k in ("median", "mean", "scale"):
        np.testing.assert_array_equal(changed[k], before[k])


def test_probability_losses_use_all_cases_and_keep_exact_zero_one_finite():
    loss = signal.losses(np.array([0.0, 1.0]), np.array([0.0, 1.0]))
    assert np.isfinite(loss["logloss"]) and loss["brier"] == 0 and loss["n"] == 2
    assert signal.losses(np.array([0.0, 1.0]), np.array([1.0, 0.0]))["brier"] == 1
