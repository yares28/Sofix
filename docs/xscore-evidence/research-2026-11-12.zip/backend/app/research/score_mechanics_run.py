"""Testing-only chronological runner for stripped defensive score mechanisms."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_mechanics as mechanics
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_identity import category_values
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "stats-cache", "match-cache", "player-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import catboost
    import pandas as pd

    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Mechanics reference cases differ")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    with np.load(args.match_cache) as stored:
        match, match_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Match feature key differs")
    with np.load(args.player_cache) as stored:
        player, player_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_player["featureKey"]:
            raise ValueError("Player feature key differs")
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    identities = category_values(source["rows"], games)
    all_base_aa, all_base_net, reconstruction = mechanics.observed_components(source["rows"], games)
    files = [
        Path(__file__),
        Path(mechanics.__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + catboost.__version__
        ).encode()
        + raw
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "reconstruction": reconstruction,
        "cohorts": {},
    }
    if args.out.exists():
        previous = json.loads(args.out.read_text())
        if previous.get("implementationKey") == key:
            report = previous
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        aa, net = all_base_aa[keep], all_base_net[keep]
        minutes = np.array([r["minutes"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, feature_names = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        frame = pd.DataFrame(numeric, columns=[f"n{i}" for i in range(numeric.shape[1])])
        cats = ["player_id", "playing_side", "opponent_side", "card_position"]
        for j, name in enumerate(cats):
            frame[name] = identities[keep, j]
        home = base[keep, names.index("home")] > 0
        lam = np.where(home, base[keep, names.index("match_lam_a")], base[keep, names.index("match_lam_h")])
        cs = np.where(home, base[keep, names.index("match_cs_h")], base[keep, names.index("match_cs_a")])
        records = [
            {
                "spec": {"minuteSpread": ms, "goals": goal, "spread": spread, "shift": shift, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for ms in (0.75, 1, 1.25)
            for goal in ("lambda", "calibratedCS")
            for spread in (0.75, 1, 1.25)
            for shift in (-2, 0, 2)
            for scope in ("all", "defmid")
        ]
        prior, winner, best = None, None, None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            print(f"FITTING {cohort} {phase}", flush=True)
            pieces = mechanics.fitted_pieces(
                frame, cats, aa, net, minutes, mask, args.cache / f"{args.out.stem}_{cohort}_{phase}_pieces.npz", key
            )
            audit[phase] = {
                "fit": int(mask["fit"].sum()),
                "target": int(target.sum()),
                "minutesMeanMiss": float(np.mean(np.abs(minutes[target] - pieces["minutes"]))),
            }
            if prior is None:
                prior = (target_rows, old, pieces, aa[target], net[target])
                continue
            previous_rows, previous_old, previous_pieces, previous_aa, previous_net = prior
            if cohort == "start":
                control_parts = stability.starter_control(previous_old, old, previous_rows, mask["first"])
                control = empirical.empirical_predictions(
                    *control_parts[:3], positions[target], control_parts[3], 20, 0.75, 0
                )
            else:
                control = stability.analogue_control(args, key, source, old_bench, phase, mask)
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric["within7"] != expected["within7"]:
                raise ValueError("Mechanics frozen control did not reproduce")
            bank = mechanics.paired_bank(previous_rows, previous_aa, previous_net, previous_pieces, mask["first"])
            audit[phase]["control"] = metric
            audit[phase]["errorBank"] = {k: bank[k] for k in ("cases", "unavailable")}
            if phase == "later2026" and best is None:
                raise ValueError("Candidate must be frozen before later outcomes")
            active = [best] if phase == "later2026" else records
            indices, minute_errors, aa_errors, goal_uniform = mechanics.paired_draws(pieces, positions[target], bank)
            sampled_net = pieces["classes"][indices]
            for minute_spread in sorted({r["spec"]["minuteSpread"] for r in active}):
                sampled_minutes, location = mechanics.sampled_base_locations(
                    pieces, indices, minute_errors, minute_spread
                )
                current = [r for r in active if r["spec"]["minuteSpread"] == minute_spread]
                for goal in sorted({r["spec"]["goals"] for r in current}):
                    conceded = mechanics.conceded_samples(lam[target], cs[target], sampled_minutes, goal_uniform, goal)
                    predictions = {}
                    for record in [r for r in current if r["spec"]["goals"] == goal]:
                        spec = record["spec"]
                        choice = spec["spread"], spec["shift"]
                        if choice not in predictions:
                            sampled_aa = location + aa_errors * spec["spread"] + spec["shift"]
                            predictions[choice] = mechanics.mechanistic_prediction(
                                sampled_aa, sampled_net, sampled_minutes, conceded, positions[target]
                            )
                        candidate = ordinary.scoped_prediction(
                            predictions[choice], control, positions[target], spec["scope"]
                        )
                        cm = measure(y[target], candidate)
                        if phase != "later2026":
                            gain = cm["within7"] - metric["within7"]
                            record["gains"].append(gain)
                            record["errors"].append(cm["mae"])
                            record["counts"].append(len(candidate))
                            record["periods"][phase] = {"gain": gain, "metrics": cm}
                        else:
                            alternate = candidate
                print(f"TESTED {cohort} {phase} minutesSpread{minute_spread}", flush=True)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                    "candidates": records,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            prior = (target_rows, old, pieces, aa[target], net[target])
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        weeks = [r["week"] for r in target_rows]
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "featureNames": feature_names,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
