"""Testing only: constant score-window labels remain valid in the substitute research."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_identity import category_values
from app.research.score_search import POSITIONS, measure
from app.research.score_stats_run import paired_interval

CENTRES = np.arange(101, dtype=float)
MODELS = {
    f"depth{d}_{name}": (d, trees, penalty)
    for d in (4, 6, 8)
    for name, trees, penalty in (("short", 400, 20), ("long", 1000, 60))
}


def window_targets(scores):
    if not np.isfinite(scores).all() or ((scores < 0) | (scores > 100)).any():
        raise ValueError("Score targets must be known and within0..100")
    return (np.abs(scores[:, None] - CENTRES[None, :]) <= 7).astype(np.int8)


def direct_choice(probability, control):
    if probability.shape != (len(control), 101) or not np.isfinite(probability).all():
        raise ValueError("Unknown direct window probabilities")
    winning = probability == probability.max(axis=1, keepdims=True)
    distance = np.where(winning, np.abs(CENTRES[None, :] - control[:, None]), np.inf)
    return CENTRES[np.argmin(distance, axis=1)]


def gated_choice(probability, control, positions, threshold, scope):
    candidate = direct_choice(probability, control)
    low = np.floor(control).astype(int)
    high = np.ceil(control).astype(int)
    if ((low < 0) | (high > 100)).any():
        raise ValueError("Control outside score bounds")
    rows = np.arange(len(control))
    control_probability = probability[rows, low] * (1 - (control - low)) + probability[rows, high] * (control - low)
    chosen = np.where(probability.max(axis=1) - control_probability > threshold, candidate, control)
    return ordinary.scoped_prediction(chosen, control, positions, scope)


def fit_windows(frame, cats, scores, mask, setting, path, key):
    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) == key:
                return stored["probability"]
    from catboost import CatBoostClassifier, Pool

    depth, trees, penalty = MODELS[setting]
    model = CatBoostClassifier(
        loss_function="MultiLogloss",
        iterations=trees,
        depth=depth,
        l2_leaf_reg=penalty,
        learning_rate=0.04,
        random_seed=20261104,
        thread_count=4,
        task_type="CPU",
        border_count=64,
        max_ctr_complexity=1,
        allow_writing_files=False,
        allow_const_label=True,
        verbose=False,
    )
    fit, target = mask["fit"], mask["target"]
    model.fit(Pool(frame.loc[fit], label=window_targets(scores[fit]), cat_features=cats))
    probability = model.predict_proba(Pool(frame.loc[target], cat_features=cats))
    if probability.shape != (int(target.sum()), 101) or not np.isfinite(probability).all():
        raise ValueError("Wrong shared-window output")
    np.savez_compressed(path, key=key, probability=probability)
    return probability


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "stats-cache", "match-cache", "player-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="bench")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import catboost
    import pandas as pd

    source = json.loads(args.cases.read_text())
    read = lambda name: json.loads((args.out.parent / (name + ".json")).read_text())
    old_match, old_player = read("laliga_score_match_context"), read("laliga_score_player_context")
    old_stability, old_ordinary = read("laliga_score_stability"), read("laliga_score_ordinary")
    old_start, old_bench = read("laliga_score_match_empirical_density"), read("laliga_score_analogues")
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Shared-window reference cases differ")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    with np.load(args.match_cache) as stored:
        match, match_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Match feature key differs")
    with np.load(args.player_cache) as stored:
        player, player_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_player["featureKey"]:
            raise ValueError("Player feature key differs")
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    identities = category_values(source["rows"], games)
    files = [
        Path(__file__),
        Path(ordinary.__file__),
        Path(stability.__file__),
        Path(empirical.__file__),
        Path(flow.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + catboost.__version__
        ).encode()
        + raw
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "cohorts": {},
    }
    if args.out.exists():
        previous = json.loads(args.out.read_text())
        if previous.get("implementationKey") == key:
            report = previous
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, feature_names = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        frame = pd.DataFrame(numeric, columns=[f"n{i}" for i in range(numeric.shape[1])])
        cats = ["player_id", "playing_side", "opponent_side", "card_position"]
        for j, name in enumerate(cats):
            frame[name] = identities[keep, j]
        records = [
            {
                "spec": {"model": model, "threshold": threshold, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for model in MODELS
            for threshold in (0, 0.01, 0.025, 0.05)
            for scope in ("all", "defmid")
        ]
        previous_rows, previous_old, winner, best = None, None, None, None
        audit = {}
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            if phase == "warm2023":
                previous_rows, previous_old = target_rows, old
                continue
            if cohort == "start":
                control_parts = stability.starter_control(previous_old, old, previous_rows, mask["first"])
                control = empirical.empirical_predictions(
                    *control_parts[:3], positions[target], control_parts[3], 20, 0.75, 0
                )
            else:
                control = stability.analogue_control(args, key, source, old_bench, phase, mask)
            metric = measure(y[target], control)
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if metric["within7"] != expected["within7"]:
                raise ValueError("Direct-window frozen control did not reproduce")
            audit[phase] = {"fit": int(mask["fit"].sum()), "target": int(target.sum()), "control": metric, "models": {}}
            if phase == "later2026" and best is None:
                raise ValueError("Candidate must be frozen before later outcomes")
            active = [best] if phase == "later2026" else records
            for setting in sorted({r["spec"]["model"] for r in active}):
                probability = fit_windows(
                    frame, cats, y, mask, setting, args.cache / f"{args.out.stem}_{cohort}_{phase}_{setting}.npz", key
                )
                audit[phase]["models"][setting] = measure(y[target], direct_choice(probability, control))
                for record in [r for r in active if r["spec"]["model"] == setting]:
                    spec = record["spec"]
                    candidate = gated_choice(probability, control, positions[target], spec["threshold"], spec["scope"])
                    candidate_metric = measure(y[target], candidate)
                    if phase != "later2026":
                        gain = candidate_metric["within7"] - metric["within7"]
                        record["gains"].append(gain)
                        record["errors"].append(candidate_metric["mae"])
                        record["counts"].append(len(candidate))
                        record["periods"][phase] = {"gain": gain, "metrics": candidate_metric}
                    else:
                        alternate = candidate
                print(
                    "MODEL "
                    + json.dumps(
                        {
                            "cohort": cohort,
                            "phase": phase,
                            "setting": setting,
                            "rawMetrics": audit[phase]["models"][setting],
                        }
                    ),
                    flush=True,
                )
            if phase == "autumn2025":
                winner, best = stability.choose_stable(records)
                frozen = {
                    "implementationKey": key,
                    "winner": winner,
                    "best": best,
                    "passingCandidates": sum(min(r["gains"]) > 0 for r in records),
                    "candidates": records,
                }
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2))
                print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": best}), flush=True)
            previous_rows, previous_old = target_rows, old
        prediction = alternate if winner else control.copy()
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        weeks = [r["week"] for r in target_rows]
        result = {
            "selected": "candidate" if winner else "control",
            "winner": winner,
            "candidate": best,
            "candidateCount": len(records) + 1,
            "earlierPeriods": audit,
            "featureNames": feature_names,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
