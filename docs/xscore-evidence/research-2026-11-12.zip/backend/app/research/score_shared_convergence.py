"""Check the earlier-selected shared-window model with a longer training cap."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_search import measure
from app.research.score_shared_windows import fit_probability, window_targets
from app.research.score_windows import window_centres


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "packages", "previous", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    previous = json.loads(args.previous.read_text(encoding="utf-8"))
    if previous["sourceKey"] != source["key"]:
        raise ValueError("Source cases differ")
    with np.load(args.stats_cache) as cache:
        x = cache["x"]
        if str(cache["key"]) != previous["statKey"]:
            raise ValueError("Source stat features differ")
    report = {
        "test": "Raise maximum training from120to500 for the earlier-selected architecture; choose epoch policy only on earlier games",
        "evidenceLimit": "Retrospective exploratory reuse",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"][:10] for r in rows])
        y = np.array([r["score"] for r in rows])
        train = dates < "2025-07-01"
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        old = previous["cohorts"][cohort]
        spec = old["winner"]
        centres, target = window_targets(y)
        probability, training = fit_probability(
            x[keep], target, train, valid, spec["hidden"], spec["alpha"], max_epochs=500
        )
        candidates = []
        for shift in (-3, 0, 3):
            candidates.append(
                {
                    "shift": shift,
                    "selection": measure(y[valid], np.clip(window_centres(probability, centres) + shift, 0, 100)),
                }
            )
        best = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        wins = (best["selection"]["within7"], -best["selection"]["mae"]) > (
            spec["selection"]["within7"],
            -spec["selection"]["mae"],
        )
        result = {
            "architecture": {"hidden": spec["hidden"], "alpha": spec["alpha"]},
            "earlier120": spec["selection"],
            "earlier500": best,
            "training500": training,
            "chosenMaximumEpochs": 500 if wins else 120,
        }
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("FROZEN " + json.dumps({"cohort": cohort, **result}), flush=True)
        if wins:
            probability, training = fit_probability(
                x[keep], target, ~test, test, spec["hidden"], spec["alpha"], max_epochs=500
            )
            prediction = np.clip(window_centres(probability, centres) + best["shift"], 0, 100)
            result.update(later=measure(y[test], prediction), laterTraining=training)
        else:
            result.update(later=old["later"], laterTraining=old["laterTraining"])
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
