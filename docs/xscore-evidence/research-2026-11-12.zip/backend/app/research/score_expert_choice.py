"""Testing only: choose one of five earlier-fitted forecasts, with lagged error history."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_analogues import descriptor_groups, predict_lookup, prepare_lookup
from app.research.score_empirical_density import calibration_split
from app.research.score_europe_run import predict_components
from app.research.score_identity import density_choice
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_selector import make_model
from app.research.score_stats_run import paired_interval

EXPERTS = ("control", "ordered_history", "identity", "match_context", "similar_games")


def expert_history(rows, forecasts):
    if forecasts.shape[0] != len(rows) or not np.isfinite(forecasts).all():
        raise ValueError("Expert case identity or forecasts differ")
    queue = sorted(range(len(rows)), key=lambda i: moment(rows[i]["date"]) + timedelta(hours=48))
    order = sorted(range(len(rows)), key=lambda i: cutoff_for(rows[i]["date"]))
    by_player = defaultdict(lambda: deque(maxlen=10))
    result = np.full((len(rows), forecasts.shape[1] * 4), np.nan)
    cursor = 0
    for i in order:
        cutoff = cutoff_for(rows[i]["date"])
        while cursor < len(queue) and moment(rows[queue[cursor]]["date"]) + timedelta(hours=48) < cutoff:
            j = queue[cursor]
            by_player[rows[j]["player"]].append(forecasts[j] - rows[j]["score"])
            cursor += 1
        past = by_player[rows[i]["player"]]
        for j in range(forecasts.shape[1]):
            result[i, j * 4] = len(past)
            if past:
                errors = np.array(past)[:, j]
                result[i, j * 4 + 1 : j * 4 + 4] = [(np.abs(errors) <= 7).mean(), errors.mean(), np.abs(errors).mean()]
    return result


def choose_expert(forecasts, gains, threshold):
    best = gains.argmax(axis=1)
    selected = np.where(gains[np.arange(len(best)), best] > threshold, best + 1, 0)
    return forecasts[np.arange(len(selected)), selected], selected


def position_choices(y, forecasts, positions):
    selected = {}
    for pos in POSITIONS:
        mask = positions == pos
        if mask.sum() < 100:
            mask = np.ones(len(y), dtype=bool)
        selected[pos] = max(
            range(forecasts.shape[1]),
            key=lambda j: (
                measure(y[mask], forecasts[mask, j])["within7"],
                -measure(y[mask], forecasts[mask, j])["mae"],
            ),
        )
    return selected


def load_experts(args, source, rows, cohort, valid, test, reports):
    early, late = [], []
    with np.load(args.cache / f"selector_{cohort}_control_earlier.npz") as f:
        if str(f["key"]) != reports["selector"]["implementationKey"]:
            raise ValueError("Earlier control cache differs")
        early.append(f["prediction"])
    with np.load(args.cache / f"europe_predictions_{cohort}.npz") as f:
        if not np.array_equal(f["y"], np.array([r["score"] for r, yes in zip(rows, test, strict=True) if yes])):
            raise ValueError("Later control cases differ")
        late.append(f["control"])
    for name, group in (("sequence", "ordered_observations"), ("match_context", "chances_and_intensity")):
        report = reports[name]
        arrays = []
        for phase in ("selection", "later"):
            path = args.cache / f"feature_laliga_score_{name}_{cohort}_{group}_{phase}.npz"
            bundle = components(path, report["implementationKey"])
            arrays.append(predict_components(bundle, {"threshold": 0.5, "quantile": 0.5, "ordinaryShift": 0}))
        early.append(arrays[0])
        late.append(arrays[1])
    # Insert identity between ordered history and match context, preserving EXPERTS order.
    identity = reports["identity"]
    with np.load(args.cache / f"identity_{cohort}_identity_4_10_selection.npz") as f:
        if str(f["key"]) != identity["implementationKey"]:
            raise ValueError("Earlier identity cache differs")
        early.insert(2, density_choice(f["probability"], f["classes"]))
    chosen = identity["cohorts"][cohort]["winner"]
    if (chosen["group"], chosen["depth"], chosen["penalty"], chosen["shift"]) != ("identity", 4, 10, 0):
        raise ValueError("Stored identity refit is not the declared fixed expert")
    with np.load(args.cache / f"identity_predictions_{cohort}.npz") as f:
        if str(f["key"]) != identity["implementationKey"]:
            raise ValueError("Later identity cache differs")
        late.insert(2, f["prediction"])
    analogues = reports["analogues"]
    spec = analogues["cohorts"][cohort]["winner"]
    with np.load(args.cache / f"analogues_{cohort}_{spec['group']}_selection.npz") as f:
        if str(f["key"]) != analogues["implementationKey"]:
            raise ValueError("Earlier similar-game cache differs")
        train = np.array([r["date"] < "2025-07-01" for r in rows])
        prediction, _ = predict_lookup(prepare_lookup(rows, valid, train, f["indices"], f["distance"]), spec)
        early.append(prediction)
    with np.load(args.cache / f"analogues_predictions_{cohort}.npz") as f:
        if str(f["key"]) != analogues["implementationKey"]:
            raise ValueError("Later similar-game cache differs")
        late.append(f["prediction"])
    result = np.column_stack(early), np.column_stack(late)
    if result[0].shape != (int(valid.sum()), len(EXPERTS)) or result[1].shape != (int(test.sum()), len(EXPERTS)):
        raise ValueError("Expert prediction case count differs")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "reports", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    reports = {
        name: json.loads((args.reports / f"laliga_score_{name}.json").read_text(encoding="utf-8"))
        for name in ("selector", "sequence", "identity", "match_context", "analogues")
    }
    if any(r["sourceKey"] != source["key"] for r in reports.values()):
        raise ValueError("Expert sources differ")
    key = hashlib.sha256(
        json.dumps({n: r["implementationKey"] for n, r in reports.items()}, sort_keys=True).encode()
        + Path(__file__).read_bytes()
    ).hexdigest()
    with np.load(args.cache / "match_context_features.npz") as stored:
        if str(stored["key"]) != reports["match_context"]["featureKey"]:
            raise ValueError("Match-context feature cache differs")
        context, context_names = stored["x"], stored["names"].tolist()
    columns = [
        context_names.index(n)
        for n in (
            "own_3_xg_for_mean",
            "opponent_3_xg_for_mean",
            "own_3_ppda_mean",
            "opponent_3_ppda_mean",
            "own_3_box_for_mean",
            "opponent_3_box_for_mean",
        )
    ]
    report = {
        "scope": "Testing only; no application change",
        "evidenceLimit": "Retrospective exploratory reuse; base parameters selected on2025 too; not freshblind",
        "sourceKey": source["key"],
        "implementationKey": key,
        "experts": EXPERTS,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"] for r in rows])
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        y = np.array([r["score"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        earlier, later = load_experts(args, source, rows, cohort, valid, test, reports)
        active = valid | test
        all_forecasts = np.full((len(rows), len(EXPERTS)), np.nan)
        all_forecasts[valid], all_forecasts[test] = earlier, later
        history = expert_history([r for r, yes in zip(rows, active, strict=True) if yes], all_forecasts[active])
        base = descriptor_groups(rows, source["features"], cohort)["form_role_match"]
        features = np.column_stack(
            (
                base[active],
                context[keep][active][:, columns],
                np.column_stack([positions[active] == p for p in POSITIONS]),
                all_forecasts[active],
                abs(all_forecasts[active, 1:] - all_forecasts[active, :1]),
                np.ptp(all_forecasts[active], axis=1),
            )
        )
        earlier_x, later_x = features[valid[active]], features[test[active]]
        earlier_h, later_h = history[valid[active]], history[test[active]]
        fit, select = calibration_split([r for r, yes in zip(rows, valid, strict=True) if yes])
        first_later_lock = min(cutoff_for(v["date"]) for v, yes in zip(rows, test, strict=True) if yes)
        if not all(
            moment(r["date"]) + timedelta(hours=48) < first_later_lock
            for r, yes in zip(rows, valid, strict=True)
            if yes
        ):
            raise ValueError("Refit labels unavailable at first later lock")
        target = (abs(earlier - y[valid, None]) <= 7).astype(float)
        gains = target[:, 1:] - target[:, :1]
        candidates = [
            {"kind": "fixed", "expert": j, "selection": measure(y[valid][select], earlier[select, j])}
            for j in range(len(EXPERTS))
        ]
        pos_choice = position_choices(y[valid][fit], earlier[fit], positions[valid][fit])
        pos_index = np.array([pos_choice[p] for p in positions[valid][select]])
        candidates.append(
            {
                "kind": "position",
                "positions": pos_choice,
                "selection": measure(y[valid][select], earlier[select][np.arange(select.sum()), pos_index]),
            }
        )
        for use_history in (False, True):
            x = np.column_stack((earlier_x, earlier_h)) if use_history else earlier_x
            for leaves in (3, 7):
                for minimum in (80, 160):
                    predicted = np.column_stack(
                        [
                            make_model(leaves, minimum).fit(x[fit], gains[fit, j]).predict(x[select])
                            for j in range(len(EXPERTS) - 1)
                        ]
                    )
                    for threshold in (-0.05, 0, 0.05, 0.1):
                        prediction, _ = choose_expert(earlier[select], predicted, threshold)
                        candidates.append(
                            {
                                "kind": "learned",
                                "history": use_history,
                                "leaves": leaves,
                                "minimumLeaf": minimum,
                                "threshold": threshold,
                                "selection": measure(y[valid][select], prediction),
                            }
                        )
        winner = max(candidates, key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        if winner["kind"] == "fixed":
            selected = np.full(int(test.sum()), winner["expert"])
        elif winner["kind"] == "position":
            choices = position_choices(y[valid], earlier, positions[valid])
            selected = np.array([choices[p] for p in positions[test]])
        else:
            x = np.column_stack((earlier_x, earlier_h)) if winner["history"] else earlier_x
            z = np.column_stack((later_x, later_h)) if winner["history"] else later_x
            predicted = np.column_stack(
                [
                    make_model(winner["leaves"], winner["minimumLeaf"]).fit(x, gains[:, j]).predict(z)
                    for j in range(len(EXPERTS) - 1)
                ]
            )
            _, selected = choose_expert(later, predicted, winner["threshold"])
        prediction = later[np.arange(len(later)), selected]
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "metaFitCases": int(fit.sum()),
            "metaSelectionCases": int(select.sum()),
            "embargoCases": int((~fit & ~select).sum()),
            "later": measure(y[test], prediction),
            "control": measure(y[test], later[:, 0]),
            "gain95": paired_interval(y[test], prediction, later[:, 0], weeks),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "expertResults": {name: measure(y[test], later[:, j]) for j, name in enumerate(EXPERTS)},
            "expertSelections": {name: int((selected == j).sum()) for j, name in enumerate(EXPERTS)},
            "diagnosticPerfectChoiceOnly": {
                "notUsablePrediction": True,
                "n": int(test.sum()),
                "within7": float((abs(later - y[test, None]) <= 7).any(axis=1).mean()),
            },
            "positions": {
                p: measure(y[test][positions[test] == p], prediction[positions[test] == p])
                for p in POSITIONS
                if (positions[test] == p).any()
            },
            "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
        }
        np.savez_compressed(
            args.cache / f"expert_choice_predictions_{cohort}.npz",
            key=key,
            y=y[test],
            prediction=prediction,
            selected=selected,
            experts=later,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
