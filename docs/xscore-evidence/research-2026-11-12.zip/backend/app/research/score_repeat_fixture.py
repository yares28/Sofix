"""Earlier-only test of pre-lock repeat fixture and lineup continuity."""

import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta
from math import exp, log1p

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_style_signal import forecast
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_repeat_fixture"
LOOKBACK = timedelta(days=730)


def starters(game, side):
    formation = game["xi"][side]
    if not formation["available"]:
        return None
    values = {slug for line in formation["start"] for slug in line}
    return values if len(values) == 11 else None


def overlap(older, recent):
    return len(older & recent) / 11 if older is not None and recent is not None else None


def pair_history(records, lock, last_own, last_other):
    eligible = [r for r in records if r[0] >= lock - LOOKBACK]
    if not eligible:
        return np.zeros(8)
    total = np.zeros(4)
    amount = 0.0
    continuity = []
    for t, own, other, stats in eligible:
        age = (lock - t).total_seconds() / 86400
        both = overlap(own, last_own), overlap(other, last_other)
        observed = [c for c in both if c is not None]
        weight = exp(-age / 400)
        if observed:
            continuity.append(float(np.mean(observed)))
            weight *= (1 + continuity[-1]) / 2
        total += weight * stats
        amount += weight
    return np.r_[
        log1p(len(eligible)),
        total / (amount + 2),
        float(np.mean(continuity)) if continuity else 0,
        log1p(len(continuity)),
        (lock - eligible[-1][0]).days / 365,
    ]


def player_history(records, lock):
    kept = [r for r in records if r[0] >= lock - LOOKBACK]
    if not kept:
        return np.zeros(5)
    w = np.array([exp(-(lock - t).days / 400) for t, _ in kept])
    stats = np.array([value for _, value in kept])
    return np.r_[log1p(len(kept)), w @ stats / (w.sum() + 2), (lock - kept[-1][0]).days / 365]


def build(rows, games, names):
    order = sorted(games, key=lambda g: (g["date"], g["id"]))
    ready = [moment(g["date"]) + DELAY for g in order]
    game_rows = defaultdict(list)
    for i, row in enumerate(rows):
        game_rows[row["game"]].append(i)
    aa_index = {c: names.index(f"{c}_10_aa") for c in ("start", "bench")}
    s_index = {c: names.index(f"{c}_10_score") for c in ("start", "bench")}
    m_index = {c: names.index(f"{c}_10_minutes") for c in ("start", "bench")}
    lam_h, lam_a = (names.index(f"match_lam_{s}") for s in ("h", "a"))
    records = {}
    team, player = defaultdict(lambda: deque(maxlen=6)), defaultdict(lambda: deque(maxlen=6))
    xi = {}
    league = defaultdict(lambda: deque(maxlen=150))
    team_x, player_x = np.empty((len(rows), 8)), np.empty((len(rows), 5))
    cursor = 0
    for game in order:
        lock = cutoff_for(game["date"])
        while cursor < len(order) and ready[cursor] < lock:
            previous = order[cursor]
            at = ready[cursor] - DELAY
            for own, other, own_xi, other_xi, stats in records.pop(previous["id"]):
                team[own, other].append((at, own_xi, other_xi, stats))
                if own_xi is not None:
                    xi[own] = own_xi
            for i in game_rows[previous["id"]]:
                row = rows[i]
                slug, cohort = row["player"], row["cohort"]
                own = previous["players"][slug]["team"]
                other = previous["away"]["slug"] if own == previous["home"]["slug"] else previous["home"]["slug"]
                stats = np.array(
                    [
                        row["aa"] - row["x"][aa_index[cohort]],
                        row["score"] - row["x"][s_index[cohort]],
                        row["minutes"] - row["x"][m_index[cohort]],
                    ]
                )
                player[slug, own, other, cohort].append((at, stats))
                league[row["pos"], cohort].append(stats[0])
            cursor += 1
        home, away = (game[s]["slug"] for s in ("home", "away"))
        x = rows[game_rows[game["id"]][0]]["x"]
        past_features = {
            home: pair_history(team[home, away], lock, xi.get(home), xi.get(away)),
            away: pair_history(team[away, home], lock, xi.get(away), xi.get(home)),
        }
        residuals = {home: [], away: []}
        for i in game_rows[game["id"]]:
            row = rows[i]
            slug, cohort = row["player"], row["cohort"]
            own = game["players"][slug]["team"]
            other = away if own == home else home
            assert own in residuals and row["date"] == game["date"]
            team_x[i] = past_features[own]
            player_x[i] = player_history(player[slug, own, other, cohort], lock)
            typical = league[row["pos"], cohort]
            residual = row["aa"] - row["x"][aa_index[cohort]]
            residuals[own].append(residual - (float(np.mean(typical)) if typical else 0))
        home_xi, away_xi = starters(game, "home"), starters(game, "away")
        h, a = game["homeGoals"], game["awayGoals"]
        hrs, ars = float(np.mean(residuals[home])), float(np.mean(residuals[away]))
        expected_h = x[lam_h] if x[lam_h] >= 0 else 1.45
        expected_a = x[lam_a] if x[lam_a] >= 0 else 1.15
        records[game["id"]] = [
            (home, away, home_xi, away_xi, np.array([h - expected_h, a - expected_a, hrs, ars])),
            (away, home, away_xi, home_xi, np.array([a - expected_a, h - expected_h, ars, hrs])),
        ]
    return team_x, player_x


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["date"] < "2026-01-01"]
    base = np.array([r["x"] for r in rows])
    team, person = build(rows, games, source["features"])
    arms = {
        "control": base,
        "team": np.column_stack((base, team)),
        "teamAndPlayer": np.column_stack((base, team, person)),
    }
    date = np.array([r["date"] for r in rows])
    cohort = np.array([r["cohort"] for r in rows])
    y = np.array([r["score"] for r in rows])
    locks = np.array([cutoff_for(d) for d in date])
    ready = np.array([moment(d) + DELAY for d in date])
    periods = {}
    for phase, (begin, end) in PHASES.items():
        chosen = (date >= begin) & (date < end)
        earlier = ready < locks[chosen].min()
        periods[phase] = {}
        for role in ("start", "bench"):
            train, check = earlier & (cohort == role), chosen & (cohort == role)
            anchor = base[:, source["features"].index(f"{role}_10_score")]
            predictions = {
                k: np.clip(anchor[check] + forecast(a, y - anchor, train, check), 0, 100) for k, a in arms.items()
            }
            periods[phase][role] = dict(
                **{k: metrics(y[check], predictions["control"], predictions[k]) for k in arms if k != "control"},
                teamHistoryCases=int(np.count_nonzero(team[check, 0])),
                playerHistoryCases=int(np.count_nonzero(person[check, 0])),
            )
    gates = {}
    for role in ("start", "bench"):
        gates[role] = {}
        for k in ("team", "teamAndPlayer"):
            results = [v[role][k] for v in periods.values()]
            n = sum(r["n"] for r in results)
            hits = [r["gained"] - r["lost"] for r in results]
            mae = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in results) / n
            gates[role][k] = dict(
                n=n,
                netHits=sum(hits),
                phaseHitGains=hits,
                maeGain=mae,
                passEarlier=sum(hits) > 0 and mae > 0 and min(hits) >= 0,
            )
    result = dict(nativeSHA=NATIVE_SHA, sourceKey=source["key"], periods=periods, gate=gates, laterEvaluated=False)
    (REPORTS / (STEM + ".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(gates, indent=2))


if __name__ == "__main__":
    main()
