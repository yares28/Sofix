import numpy as np

from app.research.score_rolling import month_folds


def test_month_refit_never_learns_from_same_gw_or_unavailable_result():
    rows = [
        {"date": "2025-12-20T20:00:00Z"},
        {"date": "2026-01-01T20:00:00Z"},
        {"date": "2026-01-03T20:00:00Z"},
        {"date": "2026-01-04T20:00:00Z"},
        {"date": "2026-02-07T20:00:00Z"},
    ]
    selected = np.array([False, False, True, True, True])
    folds = month_folds(rows, selected, 0)
    assert len(folds) == 2
    assert folds[0][0].tolist() == [True, False, False, False, False]
    assert folds[0][1].tolist() == [False, False, True, True, False]
    assert folds[1][0].tolist() == [True, True, True, True, False]


def test_rolling_window_keeps_every_target_and_only_cuts_old_training_rows():
    rows = [{"date": date} for date in ("2023-01-01T20:00:00Z", "2025-12-01T20:00:00Z", "2026-01-03T20:00:00Z")]
    folds = month_folds(rows, np.array([False, False, True]), 365)
    assert folds[0][0].tolist() == [False, True, False]
    assert folds[0][1].tolist() == [False, False, True]
