"""Offline formula search. Never loads credentials or enables a production model.

Run from backend with the existing Python environment and optional local sklearn path.
Only lagged inputs are used. Historical Tuesday/Friday cutoffs are inferred at 14 UTC;
results receive a conservative 48-hour availability delay. This is retrospective
research, not proof of archived pre-lock availability or a fresh blind sample.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np

POSITIONS = ("GK", "DEF", "MID", "FWD")
PLAN = {
    "requestedOutcome": "More than 50% of all eligible starts within seven points, without future inputs",
    "scope": "LaLiga first: local authentic version-7 starter export; all other leagues remain untested",
    "userActions": "None; local computation only, no source calls, spending or production changes",
    "training": "2023-08-01 through 2025-06-30",
    "selection": "2025-07-01 through 2026-09-30",
    "test": "2026-10-01 onward, evaluated only after selecting one candidate",
    "testLimit": "October outcomes already examined in earlier research; not freshly blind",
    "features": "Own past scores, minutes, decisive levels, all-around stats; past team/opponent results; home; position",
    "exclusions": "No same-game minutes, XI, stats, results, Sorare projections, closing prices or future player history",
    "availability": "Inferred Tuesday/Friday 14 UTC deadline; past kickoff plus 48 hours must precede it",
    "search": "Recent mean/median/window mode, shifted and scaled formulas, nonlinear mean/quantile models, direct interval-probability models",
    "acceptance": "All starts counted; per-position counts, errors, bias, weekly uncertainty, no hidden low-confidence exclusions",
    "promotion": "No automatic promotion; closest-score objective can undervalue high-upside players and differs from expected score",
    "nextEvidence": "After this search, any new claim needs later untouched weeks; never retune against this test",
}


def moment(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def cutoff_for(value: str) -> datetime:
    at = moment(value)
    for days in range(8):
        cutoff = (at - timedelta(days=days)).replace(hour=14, minute=0, second=0, microsecond=0)
        if cutoff.weekday() in (1, 4) and cutoff <= at:
            return cutoff
    raise ValueError("No cutoff")


def interval_mode(values: list[float]) -> float:
    """Centre of the densest 14-point interval; ties go nearest the median."""
    if not values:
        return 45.0
    a = np.asarray(values)
    centres = np.arange(0, 100.01, 0.5)
    counts = (np.abs(a[:, None] - centres) <= 7).sum(axis=0)
    winners = centres[counts == counts.max()]
    return float(winners[np.argmin(np.abs(winners - np.median(a)))])


def make_cases(games: list[dict[str, Any]]) -> list[dict[str, Any]]:
    history: dict[str, list[tuple[datetime, dict[str, Any]]]] = defaultdict(list)
    clubs: dict[str, list[tuple[datetime, float, float]]] = defaultdict(list)
    out = []
    # Stat names are schema only; their values always come from earlier games.
    stats = sorted({n for g in games for r in g["players"].values() for n in r.get("stats", {})})
    seen = set()
    for g in sorted(games, key=lambda x: (x["date"], x["id"])):
        if g["id"] in seen:
            raise ValueError("Duplicate game identity")
        seen.add(g["id"])
        at = moment(g["date"])
        cutoff = cutoff_for(g["date"])
        available = at + timedelta(hours=48)
        for player, r in g["players"].items():
            if (
                r.get("started") is not True
                or r.get("score") is None
                or r.get("pos") not in POSITIONS
                or r.get("ver") != 7
            ):
                continue
            past = [v for date, v in history[player] if date < cutoff]
            starts = [v for v in past if v.get("started") is True and v.get("score") is not None]
            scores = [float(v["score"]) for v in starts]
            home = r["team"] == g["home"]["slug"]
            own = g["home" if home else "away"]["slug"]
            other = g["away" if home else "home"]["slug"]
            x = [float(home), *[float(r["pos"] == pos) for pos in POSITIONS], float(len(starts))]
            for window in (3, 5, 10, 20):
                part = starts[-window:]
                vals = [float(v["score"]) for v in part]
                x.extend(
                    [
                        float(np.mean(vals)) if vals else 45,
                        float(np.median(vals)) if vals else 45,
                        float(np.std(vals)) if vals else 18,
                        float(np.mean([v.get("mins") or 0 for v in part])) if part else 75,
                        float(np.mean([v.get("aa") or 0 for v in part])) if part else 10,
                        float(np.mean([(v.get("level") or 0) >= 60 for v in part])) if part else 0.25,
                    ]
                )
            for club in (own, other):
                matches = [v for v in clubs[club] if v[0] < cutoff][-20:]
                for window in (5, 20):
                    part = matches[-window:]
                    x.extend([float(np.mean([v[i] for v in part])) if part else 1.3 for i in (1, 2)])
            for window in (5, 20):
                part = starts[-window:]
                for stat in stats:
                    x.append(float(np.mean([v.get("stats", {}).get(stat, [0, 0])[0] for v in part])) if part else 0)
            out.append(
                {
                    "date": g["date"],
                    "week": cutoff.isoformat(),
                    "player": player,
                    "game": g["id"],
                    "pos": r["pos"],
                    "score": float(r["score"]),
                    "projection": r.get("proj"),
                    "x": x,
                    "recent": scores[-20:],
                }
            )
        # Store history after creating features, and enforce availability again on every later read.
        for player, r in g["players"].items():
            if r.get("played") is True and r.get("score") is not None and r.get("ver") == 7:
                history[player].append((available, r))
        if g.get("homeGoals") is not None and g.get("awayGoals") is not None:
            clubs[g["home"]["slug"]].append((available, g["homeGoals"], g["awayGoals"]))
            clubs[g["away"]["slug"]].append((available, g["awayGoals"], g["homeGoals"]))
    return out


def measure(y: np.ndarray, predicted: np.ndarray) -> dict[str, Any]:
    error = predicted - y
    return {
        "n": len(y),
        "within7": float(np.mean(np.abs(error) <= 7)),
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(error**2))),
        "bias": float(np.mean(error)),
    }


def bootstrap(y: np.ndarray, pred: np.ndarray, weeks: list[str]) -> list[float]:
    keys = sorted(set(weeks))
    values = np.array(
        [
            [np.sum(np.abs(pred[np.array(weeks) == w] - y[np.array(weeks) == w]) <= 7), np.sum(np.array(weeks) == w)]
            for w in keys
        ]
    )
    draws = np.random.default_rng(20261103).integers(0, len(keys), (2000, len(keys)))
    totals = values[draws].sum(axis=1)
    return [float(v) for v in np.quantile(totals[:, 0] / totals[:, 1], [0.025, 0.975])]


def main() -> None:
    import sys

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--packages", type=Path)
    args = parser.parse_args()
    if args.packages:
        sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.with_suffix(".plan.json").write_text(json.dumps(PLAN, indent=2), encoding="utf-8")
    games = [json.loads(s) for s in args.games.read_text(encoding="utf-8").splitlines() if s.strip()]
    rows = make_cases(games)
    x = np.asarray([r["x"] for r in rows], dtype=np.float32)
    y = np.asarray([r["score"] for r in rows])
    dates = np.array([r["date"][:10] for r in rows])
    train, valid, test = dates < "2025-07-01", (dates >= "2025-07-01") & (dates < "2026-10-01"), dates >= "2026-10-01"
    if not all(mask.any() for mask in (train, valid, test)):
        raise ValueError("Every chronological partition must have cases")
    print(
        json.dumps(
            {"train": int(train.sum()), "validation": int(valid.sum()), "test": int(test.sum()), "features": x.shape[1]}
        ),
        flush=True,
    )
    candidates = []
    best = None

    def consider(name: str, pred: np.ndarray, spec: dict[str, Any]) -> None:
        nonlocal best
        score = measure(y[valid], pred)
        candidates.append({"name": name, **score})
        if best is None or (score["within7"], -score["mae"]) > (
            best["validation"]["within7"],
            -best["validation"]["mae"],
        ):
            best = {"name": name, "validation": score, "spec": spec}
            print("LEADER " + json.dumps({"name": name, **score}), flush=True)

    # Explicit formula search: no current model coefficients are reused.
    for window in (3, 5, 10, 20):
        for method in ("mean", "median", "mode"):
            values = []
            for r in rows:
                past = r["recent"][-window:]
                values.append(
                    interval_mode(past) if method == "mode" else float(getattr(np, method)(past)) if past else 45
                )
            values = np.array(values)
            for scale in (0.7, 0.85, 1, 1.15):
                for shift in range(-12, 13, 2):
                    consider(
                        f"{method}{window}:scale{scale}:shift{shift}",
                        np.clip(45 + scale * (values[valid] - 45) + shift, 0, 100),
                        {"family": "formula", "window": window, "method": method, "scale": scale, "shift": shift},
                    )
    # Rebuilt nonlinear scores: mean, median and asymmetric quantiles, pooled with position inputs.
    for leaves in (7, 15, 31):
        for leaf_size in (30, 100):
            for quantile in (None, 0.25, 0.4, 0.5, 0.6, 0.75):
                spec = {
                    "max_leaf_nodes": leaves,
                    "min_samples_leaf": leaf_size,
                    "max_iter": 120,
                    "learning_rate": 0.06,
                    "l2_regularization": 5,
                    "early_stopping": False,
                    "random_state": 20261103,
                    "loss": "squared_error" if quantile is None else "quantile",
                }
                if quantile is not None:
                    spec["quantile"] = quantile
                model = HistGradientBoostingRegressor(**spec).fit(x[train], y[train])
                consider(
                    f"boost:{leaves}:{leaf_size}:{quantile}",
                    model.predict(x[valid]),
                    {"family": "boost", "params": spec},
                )
    # Learn the probability of landing within seven for every integer score directly.
    centres = np.arange(0, 101)
    target = (np.abs(y[:, None] - centres) <= 7).astype(np.float32)
    for leaf_size in (30, 100, 300):
        for features in (0.5, 1.0):
            spec = {
                "n_estimators": 100,
                "min_samples_leaf": leaf_size,
                "max_features": features,
                "max_depth": 16,
                "n_jobs": 4,
                "random_state": 20261103,
            }
            model = ExtraTreesRegressor(**spec).fit(x[train], target[train])
            pred = centres[model.predict(x[valid]).argmax(axis=1)]
            consider(f"interval-forest:{leaf_size}:{features}", pred, {"family": "interval", "params": spec})
    assert best is not None
    # Freeze the winner before touching test predictions. No test-driven retry in this command.
    args.out.with_suffix(".selection.json").write_text(
        json.dumps({"plan": PLAN, "winner": best, "candidates": candidates}, indent=2), encoding="utf-8"
    )
    spec = best["spec"]
    if spec["family"] == "formula":
        pred = []
        for r in [r for r, keep in zip(rows, test, strict=True) if keep]:
            past = r["recent"][-spec["window"] :]
            value = (
                interval_mode(past)
                if spec["method"] == "mode"
                else float(getattr(np, spec["method"])(past))
                if past
                else 45
            )
            pred.append(np.clip(45 + spec["scale"] * (value - 45) + spec["shift"], 0, 100))
        prediction = np.array(pred)
    else:
        model = (HistGradientBoostingRegressor if spec["family"] == "boost" else ExtraTreesRegressor)(**spec["params"])
        model.fit(x[~test], y[~test] if spec["family"] == "boost" else target[~test])
        result = model.predict(x[test])
        prediction = result if spec["family"] == "boost" else centres[result.argmax(axis=1)]
    testrows = [r for r, keep in zip(rows, test, strict=True) if keep]
    actual = y[test]
    report = {
        "plan": PLAN,
        "sourceSha256": hashlib.sha256(args.games.read_bytes()).hexdigest(),
        "sourceGames": len(games),
        "candidateCount": len(candidates),
        "winner": best,
        "test": measure(actual, prediction),
        "weekly95": bootstrap(actual, prediction, [r["week"] for r in testrows]),
        "positions": {},
        "deployment": "Research only; production unchanged",
    }
    for pos in POSITIONS:
        mask = np.array([r["pos"] == pos for r in testrows])
        report["positions"][pos] = measure(actual[mask], prediction[mask]) if mask.any() else None
    paired = [(i, r["projection"]) for i, r in enumerate(testrows) if r["projection"] is not None]
    report["sorareSameCases"] = (
        measure(actual[[i for i, _ in paired]], np.array([v for _, v in paired])) if paired else None
    )
    report["candidateSameSorareCases"] = (
        measure(actual[[i for i, _ in paired]], prediction[[i for i, _ in paired]]) if paired else None
    )
    args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("RESULT " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
