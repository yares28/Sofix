"""Testing only: native shared-source fit masks and full conditional score distributions."""

from __future__ import annotations

import numpy as np

from app.research import score_density_blend as density
from app.research import score_empirical_density as empirical
from app.research.score_search import cutoff_for, moment
from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)
GROUPS = {"ll": 0.0, "quarter": 0.25, "full": 1.0}


def training_masks(queries, aa, levels, cohort, begin, first, classes, euro_weight):
    if euro_weight not in (0, 0.25, 1):
        raise ValueError("Registered European sample weight required")
    if cohort not in ("start", "bench") or len(queries) != len(aa) or len(queries) != len(levels):
        raise ValueError("Known cohort and matched shared labels required")
    if any(q["source"] not in ("laliga", "euro") or q["cohort"] not in ("start", "bench") for q in queries):
        raise ValueError("Unknown native shared source/cohort")
    aa, levels = np.asarray(aa), np.asarray(levels)
    europe = np.array([q["source"] == "euro" for q in queries])
    lock = cutoff_for(first).timestamp()
    eligible = np.array(
        [q["cohort"] == cohort and q["date"] < begin and moment(q["date"]).timestamp() + 172800 < lock for q in queries]
    )
    eligible &= ~europe | (euro_weight > 0)
    if not np.isfinite(levels[eligible]).all():
        raise ValueError("Unknown shared fit decisive labels")
    ds = eligible & np.isin(levels, classes)
    ordinary = eligible & np.isfinite(aa)
    weights = np.where(europe, euro_weight, 1.0)
    receipt = dict(
        dsFitLaLiga=int((ds & ~europe).sum()),
        dsFitEurope=int((ds & europe).sum()),
        aaFitLaLiga=int((ordinary & ~europe).sum()),
        aaFitEurope=int((ordinary & europe).sum()),
        europeanDSOutsideLLSupport=int((eligible & europe & ~np.isin(levels, classes)).sum()),
        europeanCensoredAA=int((eligible & europe & ~np.isfinite(aa)).sum()),
        europeanWeight=float(euro_weight),
    )
    return ds, ordinary, weights, receipt


def fitted_components(x, aa, levels, ds_fit, aa_fit, weights, target_indices, classes):
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

    if (
        not np.isfinite(aa[aa_fit]).all()
        or not np.isfinite(levels[ds_fit]).all()
        or not np.isfinite(levels[aa_fit]).all()
        or not (weights[ds_fit] > 0).all()
        or not (weights[aa_fit] > 0).all()
        or not np.array_equal(np.unique(levels[ds_fit]), classes)
    ):
        raise ValueError("Shared native fit support/weights/AA labels invalid")
    classifier = HistGradientBoostingClassifier(
        max_leaf_nodes=7,
        min_samples_leaf=80,
        max_iter=120,
        learning_rate=0.06,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )
    classifier.fit(x[ds_fit], levels[ds_fit].astype(int), sample_weight=weights[ds_fit])
    if not np.array_equal(classifier.classes_, classes):
        raise ValueError("Shared classifier original native class support differs")
    probability = classifier.predict_proba(x[target_indices])
    parts = {}
    train = np.column_stack((x[aa_fit], levels[aa_fit]))
    for q in (0.35, 0.5, 0.65):
        model = HistGradientBoostingRegressor(
            loss="quantile",
            quantile=q,
            max_leaf_nodes=15,
            min_samples_leaf=60,
            max_iter=120,
            learning_rate=0.1,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261103,
        )
        model.fit(train, aa[aa_fit], sample_weight=weights[aa_fit])
        parts[q] = np.column_stack(
            [model.predict(np.column_stack((x[target_indices], np.full(len(target_indices), v)))) for v in classes]
        )
    return classes.copy(), probability, parts


def empirical_mass(classes, probability, parts, positions, bank, multiplier):
    if multiplier not in (0.75, 1):
        raise ValueError("Registered residual spread required")
    probability, positions = np.asarray(probability), np.asarray(positions)
    if (
        probability.shape != (len(positions), len(classes))
        or not np.isfinite(probability).all()
        or (probability < 0).any()
        or not np.allclose(probability.sum(axis=1), 1)
    ):
        raise ValueError("Native possible-class probability required")
    location, scale = empirical.location_scale(parts, "raw")
    scale *= multiplier
    mass = np.zeros((len(positions), 201))
    low, high = CENTRES[None, :] - 7, CENTRES[None, :] + 7
    for pos in sorted(set(positions)):
        selected = np.flatnonzero(positions == pos)
        pooled = bank["positions"].get(pos, bank["global"])
        for j, level in enumerate(classes):
            floor = level if level >= 60 else 0
            lo = (low - level - location[selected, j, None]) / scale[selected, j, None]
            hi = (high - level - location[selected, j, None]) / scale[selected, j, None]
            clipping = low <= floor, high >= 100, high < floor
            base = empirical.window_mass(pooled, lo, hi, *clipping)
            group = bank["levels"].get((pos, float(level)))
            if group is not None and len(group):
                extra = empirical.window_mass(group, lo, hi, *clipping)
                base = (len(group) * extra + 20 * base) / (len(group) + 20)
            mass[selected] += probability[selected, j, None] * base
    return density.validate_mass(mass)


def centres_from_mass(mass):
    return window_centres(density.validate_mass(mass), CENTRES)
