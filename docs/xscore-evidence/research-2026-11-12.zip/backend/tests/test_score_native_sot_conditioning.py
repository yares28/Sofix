from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_native_sot_conditioning as study


def test_native_sot_arm_replaces_only24_fields_preserves_allcases_and529base():
    base = np.zeros((38850, 529))
    old = np.full((38850, 148), np.nan)
    fixed = old.copy()
    mask = np.arange(148) < 24
    fixed[:, mask] = 3
    x = study.feature_arms(base, old, fixed, mask)["native_sot"]
    assert x.shape == (38850, 677)
    np.testing.assert_array_equal(x[:, :529], base)
    np.testing.assert_array_equal(x[:, 529:][:, ~mask], old[:, ~mask])
    assert np.isnan(x[0, -1]) and x[0, 529] == 3


def test_native_conditional_models_ignore_all_outsidefit_outcomes(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(91)
    x = rng.normal(size=(480, 5))
    x[::5, -1] = np.nan
    aa = rng.normal(10, 6, 480)
    levels = np.where(np.arange(480) % 3 == 0, 60.0, 35.0)
    masks = {"fit": np.arange(480) < 400, "target": np.arange(480) >= 400}
    root = Path(__file__).parents[1] / "data/raw/native-sot-fit-tests" / uuid4().hex
    root.mkdir(parents=True)
    original = study.fitted(x, aa, levels, masks, root / "a.npz", "fixture")
    aa[~masks["fit"]], levels[~masks["fit"]] = np.nan, np.nan
    altered = study.fitted(x, aa, levels, masks, root / "b.npz", "fixture")
    for a, b in zip(original[:2], altered[:2], strict=True):
        np.testing.assert_array_equal(a, b)
    for q in original[2]:
        np.testing.assert_array_equal(original[2][q], altered[2][q])
