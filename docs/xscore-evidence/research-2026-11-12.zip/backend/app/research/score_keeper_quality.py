"""Testing-only native keeper shot-quality source and projected past-only ability."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

FIELDS = (
    "projected_keepers",
    "projected_exposure",
    "known_ability_fraction",
    "native_games",
    "native_faced90",
    "native_gc_per_save_plus_gc",
    "qualified_games",
    "qualified_faced90",
    "qualified_gc_per_faced",
    "source_minutes_fraction",
    "ability_age_days",
    "keeper_goal_delta_per_faced",
)


def qualify(game, side, shots):
    club = game[side]["slug"]
    other = "away" if side == "home" else "home"
    keepers = [
        (p, r)
        for p, r in game["players"].items()
        if r.get("played") is True and r.get("pos") == "GK" and r.get("team") == club
    ]
    errors = []
    person, p = keepers[0] if len(keepers) == 1 else (None, {})
    if len(keepers) != 1 or p.get("mins") != 90:
        errors.append("not_one_full90_keeper")
    if p.get("ver") != 7 or not isinstance(p.get("stats"), dict):
        errors.append("incomplete_native_sheet")
    stats = p.get("stats") or {}
    saves, gc = (float(stats.get(k, [0, 0])[0]) for k in ("saves", "goals_conceded"))
    own_goals = sum(
        r.get("stats", {}).get("own_goals", [0])[0]
        for r in game["players"].values()
        if r.get("played") is True and r.get("team") == club
    )
    if own_goals > 0:
        errors.append("own_goal")
    if gc != game[other + "Goals"]:
        errors.append("native_gc_differs_fixture")
    if shots is None:
        errors.append("missing_opponent_shots")
    shots = shots or []
    valid = []
    for s in shots:
        q = s.get("xgot_fotmob")
        if q is None:
            continue
        if type(q) not in (int, float) or not math.isfinite(q) or not 0 <= q <= 1:
            errors.append("invalid_provider_quality")
        else:
            valid.append(q)
            if q > 0 and s.get("onTarget") is not True:
                errors.append("positive_postshot_on_offtarget")
    faced = saves + gc
    if len(valid) != faced:
        errors.append("provider_count_differs_native_faced")
    errors = sorted(set(errors))
    return dict(
        game=game["id"],
        date=game["date"],
        club=club,
        keeper=person,
        minutes=p.get("mins"),
        known=not errors,
        reasons=errors,
        saves=saves,
        conceded=gc,
        faced=faced,
        providerCount=len(valid),
        postshot=sum(valid) if not errors else None,
        derivedZero=not errors and faced == 0,
    )


def build_source(games, sides):
    indexed = {(r["game"], r["club"]): r["shots"] for r in sides}
    if len(indexed) != len(sides):
        raise ValueError("Duplicate shot side")
    return [
        qualify(g, side, indexed.get((g["id"], g["away" if side == "home" else "home"]["slug"])))
        for g in sorted(games, key=lambda g: (g["date"], g["id"]))
        for side in ("home", "away")
    ]


def build_features(rows, games, records, names):
    source = {(r["game"], r["keeper"]): r for r in records if r["keeper"] is not None}
    indexed = {g["id"]: g for g in games}
    schedule = sorted(games, key=lambda g: (g["date"], g["id"]))
    people, teams = defaultdict(list), defaultdict(list)
    fields = [f"keeper_{n}_{f}" for n in (3, 10) for f in FIELDS]
    x, cursor, previous = [], 0, None
    person_cache, club_cache = {}, {}

    def profile(player, lock, size):
        identity = player, size
        if identity in person_cache:
            return person_cache[identity]
        history = [r for r in people[player] if lock - r["date"] <= timedelta(days=365)][-size:]
        minutes = sum(r["minutes"] for r in history)
        faced = sum(r["faced"] for r in history)
        goals = sum(r["conceded"] for r in history)
        known = [r for r in history if r["quality"] is not None]
        km = sum(r["minutes"] for r in known)
        kf = sum(r["faced"] for r in known)
        kg = sum(r["conceded"] for r in known)
        q = sum(r["quality"]["postshot"] for r in known)
        positive = [r for r in known if r["faced"] > 0]
        value = np.array(
            [
                len(history),
                90 * faced / minutes if minutes else np.nan,
                goals / faced if faced else np.nan,
                len(known),
                90 * kf / km if km else np.nan,
                kg / kf if kf else np.nan,
                km / minutes if minutes else 0.0,
                (lock - positive[-1]["date"]).total_seconds() / 86400 if positive else np.nan,
                (kg - q) / kf if kf else np.nan,
            ]
        )
        person_cache[identity] = value
        return value

    for row in rows:
        lock = cutoff_for(row["date"])
        if previous is not None and lock < previous:
            raise ValueError("Keeper targets must be chronological")
        if lock != previous:
            person_cache.clear()
            club_cache.clear()
            previous = lock
        while cursor < len(schedule) and moment(schedule[cursor]["date"]) + timedelta(hours=48) < lock:
            g = schedule[cursor]
            clubs = {g[s]["slug"]: [] for s in ("home", "away")}
            for player, p in g["players"].items():
                minutes = p.get("mins")
                if (
                    p.get("played") is not True
                    or p.get("pos") != "GK"
                    or p.get("team") not in clubs
                    or type(minutes) not in (int, float)
                    or not np.isfinite(minutes)
                    or minutes <= 0
                ):
                    continue
                clubs[p["team"]].append((player, minutes))
                if p.get("ver") != 7 or not isinstance(p.get("stats"), dict):
                    continue
                saves, gc = (float(p["stats"].get(k, [0])[0]) for k in ("saves", "goals_conceded"))
                q = source.get((g["id"], player))
                if (
                    q is not None
                    and q["known"]
                    and (q["minutes"] != minutes or q["faced"] != saves + gc or q["conceded"] != gc)
                ):
                    raise ValueError("Qualified keeper/native history differs")
                people[player].append(
                    dict(
                        date=moment(g["date"]),
                        minutes=minutes,
                        faced=saves + gc,
                        conceded=gc,
                        quality=q if q is not None and q["known"] else None,
                    )
                )
            for club, keepers in clubs.items():
                teams[club].append((moment(g["date"]), keepers))
            cursor += 1
        g = indexed[row["game"]]
        club = g["away" if row["x"][names.index("home")] > 0 else "home"]["slug"]
        if club not in club_cache:
            recent = [r for r in teams[club] if lock - r[0] <= timedelta(days=365)][-3:]
            exposure = defaultdict(float)
            for _, keepers in recent:
                for player, minutes in keepers:
                    exposure[player] += minutes / len(recent)
            weights = np.array(list(exposure.values()))
            value = []
            for size in (3, 10):
                profiles = np.array([profile(player, lock, size) for player in exposure]).reshape(-1, 9)
                finite = np.isfinite(profiles)
                denominator = (finite * weights[:, None]).sum(axis=0)
                average = np.divide(
                    (np.where(finite, profiles, 0) * weights[:, None]).sum(axis=0),
                    denominator,
                    out=np.full(9, np.nan),
                    where=denominator > 0,
                )
                if not len(exposure):
                    average[[0, 3, 6]] = 0
                ability_fraction = float(weights[finite[:, -1]].sum() / weights.sum()) if weights.sum() else 0.0
                value.extend([len(exposure), sum(exposure.values()), ability_fraction, *average])
            club_cache[club] = value
        x.append(club_cache[club])
    x = np.array(x)
    return (
        x,
        fields,
        dict(
            rows=len(rows),
            coldOpponentRows=int((x[:, 0] == 0).sum()),
            knownAbility3=int(np.isfinite(x[:, 11]).sum()),
            knownAbility10=int(np.isfinite(x[:, 23]).sum()),
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_keeper_quality.json"))
    args = parser.parse_args()
    source = json.loads((args.cache / "cases.json").read_text())
    raw, shot_raw = args.games.read_bytes(), (args.cache / "shot_style_observations.json.gz").read_bytes()
    if (
        hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(shot_raw).hexdigest() != "31f5b36e6bddabeec8a143ebfe21ac213a6bfe7b3fd58f4c92be1f014191ab47"
    ):
        raise ValueError("Pinned native/shot sources differ")
    parent_audit = json.loads((args.out.parent / "laliga_score_postshot_probe.integrity.json").read_text())
    if parent_audit["everyRawShotVerified"] != 29915:
        raise ValueError("Complete raw provider shot audit required")
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    records = build_source(games, json.loads(gzip.decompress(shot_raw))["sides"])
    x, names, audit = build_features(source["rows"], games, records, source["features"])
    if len(records) != 2476 or x.shape != (38850, 24):
        raise ValueError("Registered full coverage differs")
    key = hashlib.sha256(
        source["key"].encode()
        + raw
        + shot_raw
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    path = args.cache / "keeper_quality_features.npz"
    np.savez_compressed(path, key=key, source_key=source["key"], x=x, names=names)
    opath = args.cache / "keeper_quality_observations.json.gz"
    opath.write_bytes(
        gzip.compress(
            json.dumps(dict(key=key, records=records), allow_nan=False, separators=(",", ":")).encode(), mtime=0
        )
    )
    report = dict(
        scope="Opponent keeper quality source/projected input only, no accuracy claim",
        featureKey=key,
        sourceKey=source["key"],
        observationsSHA=hashlib.sha256(opath.read_bytes()).hexdigest(),
        featureSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        audit=audit,
        sourceRows=len(records),
        sourceKnown=sum(r["known"] for r in records),
        sourcePositiveKnown=sum(r["known"] and r["faced"] > 0 for r in records),
        sourceReasons=dict(Counter(e for r in records for e in r["reasons"])),
        warning="Past keeper ability from qualified provider totals; target goalkeeper membership/minutes never inputs. Counts/48h availability and retrospective source assumptions remain explicit.",
        next="Independent all2476source and38850x24history/time audit before model plan",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print("KEEPER_QUALITY_BUILT " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
