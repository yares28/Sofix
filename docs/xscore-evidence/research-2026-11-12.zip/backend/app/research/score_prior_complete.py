"""Testing-only source sensitivity with a complete previous-season archive."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_feature_compare import compare_features
from app.research.score_prior_chances import OBSERVED, link_players, prior_features

LEAGUES = {
    "ESP-La Liga": "La_Liga",
    "ENG-Premier League": "EPL",
    "ITA-Serie A": "Serie_A",
    "GER-Bundesliga": "Bundesliga",
    "FRA-Ligue 1": "Ligue_1",
}
FIELDS = {
    "id": "player_id",
    "player_name": "player",
    "team_title": "team",
    "games": "matches",
    "time": "minutes",
    "xG": "xg",
    "npg": "np_goals",
    "npxG": "np_xg",
    "xA": "xa",
    "xGChain": "xg_chain",
    "xGBuildup": "xg_buildup",
    **{f: f for f in ("goals", "assists", "shots", "key_passes", "yellow_cards", "red_cards")},
}


def complete_records(old, full):
    merged = [r for r in old if int(r["year"]) != 2025]
    for r in full:
        if r["season"] != "2526":
            continue
        record = {target: r.get(source) for target, source in FIELDS.items()}
        record.update(year="2025", league=LEAGUES[r["league"]])
        merged.append(record)
    return merged


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "stats-cache", "archive", "full", "names", "control", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    aliases = json.loads(args.names.read_text(encoding="utf-8"))
    original = []
    for path in sorted(args.archive.glob("*.csv")):
        with path.open(encoding="utf-8-sig", newline="") as handle:
            original.extend(csv.DictReader(handle))
    with args.full.open(encoding="utf-8-sig", newline="") as handle:
        full = list(csv.DictReader(handle))
    links = link_players(sorted({r["player"] for r in source["rows"]}), aliases, original)
    previous, _, _ = prior_features(source["rows"], links, original)
    records = complete_records(original, full)
    extra, names, coverage = prior_features(source["rows"], links, records)
    # All replacement rows are the full, already-finished 2025 season, not the old September snapshot.
    extra[extra[:, 0] == 1, names.index("prior_partial_snapshot")] = 0
    earlier = np.array([r["date"] < "2026-07-01" for r in source["rows"]])
    if not np.array_equal(extra[earlier], previous[earlier], equal_nan=True):
        raise ValueError("Source replacement altered earlier training/selection inputs")
    metadata = {
        "source": "Community Understat-derived complete previous-season sensitivity; source hashes/collector review in receipt",
        "coverage": coverage,
        "unchangedBeforeJuly2026": int(earlier.sum()),
        "staticIdentityLinks": "Original join frozen; no new aliases or IDs",
        "sourceRows": len(records),
        "laterCoverage": {},
    }
    metadata["coverage"]["partialSnapshot"] = 0
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        metadata["laterCoverage"][cohort] = {"n": int(selected.sum()), "matched": int(extra[selected, 0].sum())}
    args.out.with_suffix(".source-audit.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("Complete source " + json.dumps(metadata), flush=True)
    key = hashlib.sha256(
        json.dumps(records, sort_keys=True).encode() + Path(__file__).read_bytes() + args.names.read_bytes()
    ).hexdigest()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    with np.load(args.stats_cache) as stored:
        numeric, stat_key = stored["x"], str(stored["key"])
    groups = {
        "chance_quality": np.array([not any(n == f"prior_{f}_per90" for f in OBSERVED) for n in names]),
        "chance_quality_observed": np.ones(len(names), dtype=bool),
    }
    compare_features(args, source, numeric, stat_key, extra, names, groups, key, metadata)


if __name__ == "__main__":
    main()
