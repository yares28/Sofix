"""Testing-only full official referee source rows, clocks and schedule-only linkage."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from app.research.score_match_context import CLUBS
from app.research.score_referee_source import OFFICIAL_CLUBS as PILOT_CLUBS
from app.research.score_referee_source import availability, publication
from app.research.score_search import cutoff_for, moment

OFFICIAL_CLUBS = PILOT_CLUBS | {
    "Málaga CF": CLUBS["Malaga"],
    "RC Deportivo": CLUBS["Deportivo A Coruna"],
    "Real Racing Club de Santander": CLUBS["Racing Santander"],
}


def club_key(value):
    return re.sub("[^a-z0-9]", "", unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower())


def parse_rows(text):
    lines = [" ".join(line.split()) for line in text.splitlines() if line.strip()]
    if not any(
        re.fullmatch(
            r"(?:Competición: )?Campeonato Nacional de (?:Liga de )?Primera División(?: - Primera División)?(?: Jornada - \d+)?",
            line,
        )
        for line in lines
    ):
        raise ValueError("Unexpected source competition")
    result = []
    for i, line in enumerate(lines):
        match = re.fullmatch(r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+(\d{2}:\d{2})", line)
        if match is None:
            continue
        clubs = [(h, a) for h in OFFICIAL_CLUBS for a in OFFICIAL_CLUBS if club_key(h + " " + a) == club_key(match[2])]
        if len(clubs) != 1:
            raise ValueError("Unknown or ambiguous printed club pair")
        referee = (
            re.fullmatch(r"Árbitr[oa]:\s*(.+?)\s+4[ºª] Árbitr[oa]:.*", lines[i + 1]) if i + 1 < len(lines) else None
        )
        if referee is None and i + 1 < len(lines) and lines[i + 1].startswith("Árbitr"):
            raise ValueError("No unique main referee adjacent to fixture")
        result.append(
            dict(
                localDate=datetime.strptime(match[1], "%d-%m-%Y").date().isoformat(),
                time=match[3],
                home=clubs[0][0],
                away=clubs[0][1],
                referee=referee[1] if referee is not None else None,
                printedPair=match[2],
            )
        )
    if sum(r["referee"] is not None for r in result) != len(re.findall(r"(?m)^Árbitr[oa]:", text)):
        raise ValueError("Incomplete appointment source rows")
    return result


def choose(records, cutoff):
    known = [
        r
        for r in records
        if r.get("referee") is not None and r.get("availableUTC") is not None and moment(r["availableUTC"]) < cutoff
    ]
    if not known:
        return None
    latest = max(moment(r["availableUTC"]) for r in known)
    selected = [r for r in known if moment(r["availableUTC"]) == latest]
    if len({r["referee"] for r in selected}) != 1:
        return None
    return selected[0]


def main():
    from pypdf import PdfReader

    folder = Path("data/raw/score-foundation/referee-source")
    reports = Path("reports/experiments")
    manifest = (folder / "archive_pdf_manifest.json").read_bytes()
    entries = json.loads(manifest.decode("utf-8-sig"))
    expected = json.loads((folder / "archive_pdf_requests.json").read_text())
    if len(entries) != len(expected) or {e["Url"] for e in entries} != {e["Url"] for e in expected}:
        raise ValueError("Live official document collection incomplete; do not restart it")
    article_audit = json.loads((reports / "laliga_score_referee_articles.integrity.json").read_text())
    if article_audit["independentlyVerifiedReadableArticles"] != 269:
        raise ValueError("Completed independent entire announcement audit required")
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    native_sha = hashlib.sha256(native.read_bytes()).hexdigest()
    if native_sha != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native source bytes differ")
    # Source linkage never reads participants, scores, minutes, events or lineups.
    schedule = [
        {k: g[k] for k in ["id", "date", "home", "away"]}
        for g in map(json.loads, native.read_text(encoding="utf-8").splitlines())
    ]
    index = defaultdict(list)
    for g in schedule:
        index[g["home"]["slug"], g["away"]["slug"], moment(g["date"])].append(g["id"])
    documents, rows = [], []
    for entry in entries:
        if entry["Status"] != "downloaded":
            documents.append(dict(file=entry["File"], url=entry["Url"], status="unreadable_document", assignments=[]))
            continue
        path = folder / entry["File"]
        raw = path.read_bytes()
        if not raw.startswith(b"%PDF-") or hashlib.sha256(raw).hexdigest() != entry["SHA256"].lower():
            raise ValueError("Pinned official PDF bytes differ")
        parent_times = []
        for parent in entry["Parents"]:
            page = (folder / parent["File"]).read_bytes()
            if hashlib.sha256(page).hexdigest() != parent["SHA256"].lower():
                raise ValueError("Parent announcement bytes changed")
            timestamp = publication(page.decode("utf-8"))
            if timestamp != moment(parent["PublicationUTC"]):
                raise ValueError("Parent publication clock differs")
            parent_times.append(timestamp)
        reader = PdfReader(path)
        clock_error, available, created, modified, http = None, None, None, None, None
        try:
            created, modified = reader.metadata.creation_date, reader.metadata.modification_date
            stamp = entry["LastModified"]
            http = parsedate_to_datetime(stamp[0] if isinstance(stamp, list) else stamp)
            available = availability(min(parent_times), created, modified, http)
        except (ValueError, TypeError, IndexError) as ex:
            clock_error = str(ex)
        assignments, parse_error = [], None
        try:
            for p, page in enumerate(reader.pages):
                for row in parse_rows(page.extract_text()):
                    kickoff = (
                        datetime.fromisoformat(row["localDate"] + "T" + row["time"])
                        .replace(tzinfo=ZoneInfo("Europe/Madrid"))
                        .astimezone(UTC)
                    )
                    candidates = index[OFFICIAL_CLUBS[row["home"]], OFFICIAL_CLUBS[row["away"]], kickoff]
                    value = row | dict(
                        page=p + 1,
                        sourceFile=path.name,
                        kickoffUTC=kickoff.isoformat(),
                        game=candidates[0] if len(candidates) == 1 else None,
                        fixtureCandidates=candidates,
                        availableUTC=available.isoformat() if available is not None else None,
                        sourceStatus="matched_native_fixture" if len(candidates) == 1 else "no_unique_native_fixture",
                    )
                    assignments.append(value)
        except ValueError as ex:
            parse_error = str(ex)
            assignments = []
        documents.append(
            dict(
                file=path.name,
                url=entry["Url"],
                sha256=entry["SHA256"].lower(),
                parents=entry["Parents"],
                status="parse_error" if parse_error else "unknown_clock" if clock_error else "parsed",
                parseError=parse_error,
                clockError=clock_error,
                totalPages=len(reader.pages),
                creationUTC=created.astimezone(UTC).isoformat() if created is not None else None,
                modificationUTC=modified.astimezone(UTC).isoformat() if modified is not None else None,
                httpLastModifiedUTC=http.isoformat() if http is not None else None,
                availableUTC=available.isoformat() if available is not None else None,
                assignments=assignments,
            )
        )
        rows.extend(assignments)
    by_game = defaultdict(list)
    for row in rows:
        if row["game"] is not None:
            by_game[row["game"]].append(row)
    choices = []
    for g in schedule:
        choices.append(
            dict(
                game=g["id"],
                date=g["date"],
                prelock=choose(by_game[g["id"]], cutoff_for(g["date"])),
                pregame=choose(by_game[g["id"]], moment(g["date"])),
            )
        )
    key = hashlib.sha256(
        Path(__file__).read_bytes() + manifest + article_audit["implementationKey"].encode() + native_sha.encode()
    ).hexdigest()
    report = dict(
        scope="Full official source reconstruction only; not a forecast or actual-referee result claim",
        implementationKey=key,
        documentManifestSHA=hashlib.sha256(manifest).hexdigest(),
        nativeSHA=native_sha,
        announcementAuditKey=article_audit["implementationKey"],
        documents=documents,
        sourceRows=len(rows),
        documentStatusCounts=dict(Counter(d["status"] for d in documents)),
        matchedSourceRows=sum(r["game"] is not None for r in rows),
        nativeGames=len(schedule),
        prelockKnownGames=sum(r["prelock"] is not None for r in choices),
        pregameKnownGames=sum(r["pregame"] is not None for r in choices),
        fixtureChoices=choices,
        modelFits=0,
        limitation="Current official document metadata/publication reconstruct availability, not independent original captured receipts. Historical pregame assignment is a proxy for actual officiating, not verified postmatch referee identity. All unparsed/late/missing assignments stay unknown.",
    )
    (reports / "laliga_score_referee_archive.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(
        "REFEREE_ARCHIVE_SOURCE",
        json.dumps(
            {
                k: report[k]
                for k in [
                    "sourceRows",
                    "documentStatusCounts",
                    "matchedSourceRows",
                    "nativeGames",
                    "prelockKnownGames",
                    "pregameKnownGames",
                ]
            }
        ),
    )


if __name__ == "__main__":
    main()
