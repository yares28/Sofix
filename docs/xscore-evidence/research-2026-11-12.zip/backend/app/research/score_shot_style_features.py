"""Testing-only shot-style qualification and strictly past opportunity descriptors."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from functools import cache
from pathlib import Path

import numpy as np

from app.research.score_prior_chances import words
from app.research.score_search import cutoff_for, moment
from app.research.score_shot_style_probe import interior

BODY = ("Header", "Left Foot", "Right Foot")
PLAYER = (
    "native_games",
    "known_games",
    "known_minutes",
    "age_days",
    "nonpen_shots90",
    "knownbody_fraction",
    "knownzone_fraction",
    "header_fraction",
    "left_fraction",
    "right_fraction",
    "inside_fraction",
    "outside_fraction",
    "unknownbody_fraction",
    "unknownzone_fraction",
    "native_goalassist_fraction",
    "native_goals90",
    "native_assists90",
    "source_fraction",
    "total_source_attempts",
    "nonpen_shots_pergame",
)
OPPONENT = (
    "native_games",
    "known_games",
    "age_days",
    "nonpen_allowed_pergame",
    "knownbody_fraction",
    "knownzone_fraction",
    "header_fraction",
    "left_fraction",
    "right_fraction",
    "inside_fraction",
    "outside_fraction",
    "unknownbody_fraction",
    "unknownzone_fraction",
    "source_fraction",
    "total_source_attempts",
    "nonpen_allowed_games_withshots_fraction",
)
MATCHED = (
    "header_rate",
    "left_rate",
    "right_rate",
    "inside_rate",
    "outside_rate",
    "body_rate",
    "zone_rate",
    "body_lift",
    "zone_lift",
    "combined_lift",
)


def feature_names():
    return [
        *("shotstyle_player_" + k for k in PLAYER),
        *("shotstyle_opponent_" + k for k in OPPONENT),
        *("shotstyle_match_" + k for k in MATCHED),
    ]


def profile(shots, known):
    if not known or shots is None:
        return dict(known=False, attempts=None, nonpen=None, body=None, zones=None, unknownBody=None, unknownZone=None)
    nonpen = [e for e in shots if e.get("sit") != "Penalty"]
    bodies = [sum(e.get("body") == b for e in nonpen) for b in BODY]
    inside = [e["x"] >= 83 and 21 <= e["y"] <= 79 for e in nonpen if interior(e)]
    return dict(
        known=True,
        attempts=len(shots),
        nonpen=len(nonpen),
        body=bodies,
        zones=[sum(inside), len(inside) - sum(inside)],
        unknownBody=len(nonpen) - sum(bodies),
        unknownZone=len(nonpen) - len(inside),
    )


def style_lift(player, opponent_counts, prior):
    p, count, prior = (np.asarray(v, dtype=float) for v in (player, opponent_counts, prior))
    if (
        not np.isfinite(p).all()
        or not np.isfinite(count).all()
        or not np.isfinite(prior).all()
        or (prior <= 0).any()
        or count.sum() <= 0
        or not np.isclose(p.sum(), 1)
        or not np.isclose(prior.sum(), 1)
    ):
        return np.nan
    smoothed = (count + 10 * prior) / (count.sum() + 10)
    return float(np.dot(p, smoothed / prior))


def qualify_sources(shot_source, pass_source):
    passes = {(r["game"], r["club"]): r["passes"] for r in pass_source}
    raw_sides = {(r["game"], r["club"]): r for r in shot_source["sides"]}
    sides, people = [], []
    for r in shot_source["sides"]:
        p = passes[r["game"], r["club"]]
        known = bool(p["known"] and p["passCount"] > 0 and p["invalidFlags"] == 0 and r["shotSource"]["streamPresent"])
        sides.append({**{k: r[k] for k in ("game", "date", "club", "opponent")}, "profile": profile(r["shots"], known)})
    side_known = {(r["game"], r["club"]): r["profile"]["known"] for r in sides}
    for r in shot_source["players"]:
        own = raw_sides[r["game"], r["club"]]["shots"]
        matched = [e for e in own or [] if words(e.get("player", "")) == words(r["sourcePlayer"] or "")]
        known = bool(r["known"] and side_known[r["game"], r["club"]])
        if known and len(matched) != r["summary"]["shots"]:
            raise ValueError("Verified player shot attribution changed")
        people.append(
            {
                **{k: r[k] for k in ("game", "date", "player", "club", "cohort", "minutes", "sourcePlayer")},
                "profile": profile(matched, known),
            }
        )
    return sides, people


def aggregate(records):
    known = [r for r in records if r is not None and r["profile"]["known"]]
    total = sum(r["profile"]["nonpen"] for r in known)
    body = np.sum([r["profile"]["body"] for r in known], axis=0) if known else np.zeros(3)
    zones = np.sum([r["profile"]["zones"] for r in known], axis=0) if known else np.zeros(2)
    return dict(
        known=known,
        total=total,
        body=body,
        zones=zones,
        bodyFraction=body / total if total else np.full(3, np.nan),
        zoneFraction=zones / total if total else np.full(2, np.nan),
        unknownBody=total - body.sum(),
        unknownZone=total - zones.sum(),
    )


def build_features(rows, games, side_profiles, player_profiles):
    side_map = {(r["game"], r["club"]): r for r in side_profiles}
    person_map = {(r["game"], r["player"]): r for r in player_profiles}
    people, clubs = defaultdict(list), defaultdict(list)
    for r in rows:
        people[r["player"], r["cohort"]].append(r)
    for g in games.values():
        for s in ("home", "away"):
            clubs[g[s]["slug"]].append(g)
    for histories in (people, clubs):
        for rs in histories.values():
            rs.sort(key=lambda r: moment(r["date"]))
    player_times = {k: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for k, rs in people.items()}
    club_times = {k: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for k, rs in clubs.items()}
    league = sorted([r for r in side_profiles if r["profile"]["known"]], key=lambda r: moment(r["date"]))
    league_times = [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in league]

    def past(records, times, lock):
        end = bisect_left(times, lock.timestamp())
        return [r for r in records[max(0, end - 10) : end] if lock - moment(r["date"]) <= timedelta(days=365)]

    @cache
    def prior(lock):
        end = bisect_left(league_times, lock.timestamp())
        selected = [r for r in league[:end] if lock - moment(r["date"]) <= timedelta(days=365)]
        a = aggregate(selected)
        return (
            a["body"] / a["body"].sum() if a["body"].sum() else np.full(3, np.nan),
            a["zones"] / a["zones"].sum() if a["zones"].sum() else np.full(2, np.nan),
        )

    @cache
    def opponent(team, lock):
        fixtures = past(clubs.get(team, []), club_times.get(team, []), lock)
        profiles = []
        for g in fixtures:
            other = g["away"]["slug"] if g["home"]["slug"] == team else g["home"]["slug"]
            profiles.append(side_map.get((g["id"], other)))
        a = aggregate(profiles)
        known, total = a["known"], a["total"]
        fraction = lambda v, denominator=total: float(v / denominator) if denominator else np.nan
        values = [
            len(fixtures),
            len(known),
            (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan,
            total / len(known) if known else np.nan,
            fraction(a["body"].sum()),
            fraction(a["zones"].sum()),
            *a["bodyFraction"],
            *a["zoneFraction"],
            fraction(a["unknownBody"]),
            fraction(a["unknownZone"]),
            len(known) / len(fixtures) if fixtures else np.nan,
            sum(r["profile"]["attempts"] for r in known),
            sum(r["profile"]["nonpen"] > 0 for r in known) / len(known) if known else np.nan,
        ]
        return values, a

    names = feature_names()
    x = np.full((len(rows), len(names)), np.nan)
    for i, r in enumerate(rows):
        lock = cutoff_for(r["date"])
        key = r["player"], r["cohort"]
        history = past(people.get(key, []), player_times.get(key, []), lock)
        a = aggregate([person_map.get((h["game"], h["player"])) for h in history])
        known, total = a["known"], a["total"]
        minutes = sum(h["minutes"] for h in known)
        goals, assists, goalassist, native_minutes = 0, 0, 0, 0
        for h in history:
            p = games[h["game"]]["players"][h["player"]]
            go, ass = (p["stats"].get(k, [0, 0])[0] for k in ("goals", "goal_assist"))
            goals += go
            assists += ass
            goalassist += go > 0 or ass > 0
            native_minutes += h["minutes"]
        fraction = lambda v, denominator=total: float(v / denominator) if denominator else np.nan
        values = [
            len(history),
            len(known),
            minutes,
            (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan,
            total * 90 / minutes if minutes else np.nan,
            fraction(a["body"].sum()),
            fraction(a["zones"].sum()),
            *a["bodyFraction"],
            *a["zoneFraction"],
            fraction(a["unknownBody"]),
            fraction(a["unknownZone"]),
            goalassist / len(history) if history else np.nan,
            goals * 90 / native_minutes if native_minutes else np.nan,
            assists * 90 / native_minutes if native_minutes else np.nan,
            len(known) / len(history) if history else np.nan,
            sum(p["profile"]["attempts"] for p in known),
            total / len(known) if known else np.nan,
        ]
        g = games[r["game"]]
        club = g["players"][r["player"]]["team"]
        other = g["away"]["slug"] if club == g["home"]["slug"] else g["home"]["slug"]
        opponent_values, b = opponent(other, lock)
        values.extend(opponent_values)
        body_rates = b["body"] / len(b["known"]) if b["known"] else np.full(3, np.nan)
        zone_rates = b["zones"] / len(b["known"]) if b["known"] else np.full(2, np.nan)
        matched_body, matched_zone = a["bodyFraction"] * body_rates, a["zoneFraction"] * zone_rates
        body_prior, zone_prior = prior(lock)
        body_lift = (
            style_lift(a["bodyFraction"], b["body"], body_prior)
            if a["unknownBody"] == b["unknownBody"] == 0
            else np.nan
        )
        zone_lift = (
            style_lift(a["zoneFraction"], b["zones"], zone_prior)
            if a["unknownZone"] == b["unknownZone"] == 0
            else np.nan
        )
        values.extend(
            [
                *matched_body,
                *matched_zone,
                matched_body.sum(),
                matched_zone.sum(),
                body_lift,
                zone_lift,
                (body_lift + zone_lift) / 2,
            ]
        )
        x[i] = values
    return x, names


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_shot_style_features.json"))
    args = parser.parse_args()
    native_raw = args.games.read_bytes()
    shot_raw = (args.cache / "shot_style_observations.json.gz").read_bytes()
    pass_raw = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    if (
        hashlib.sha256(native_raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(shot_raw).hexdigest() != "31f5b36e6bddabeec8a143ebfe21ac213a6bfe7b3fd58f4c92be1f014191ab47"
        or hashlib.sha256(pass_raw).hexdigest() != "daba17833020e8212346bb79f8b0918b69ab5e2a36ad60cc44d3fb1a4f7d064a"
    ):
        raise ValueError("Pinned shot-style source changed")
    source = json.loads((args.cache / "cases.json").read_text())
    games = {g["id"]: g for g in (json.loads(line) for line in native_raw.decode().splitlines() if line.strip())}
    sides, people = qualify_sources(
        json.loads(gzip.decompress(shot_raw)), json.loads(gzip.decompress(pass_raw))["observations"]
    )
    key = hashlib.sha256(
        source["key"].encode()
        + native_raw
        + shot_raw
        + pass_raw
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    archive = args.cache / "shot_style_qualified_observations.json.gz"
    archive.write_bytes(
        gzip.compress(
            json.dumps(dict(key=key, sides=sides, players=people), separators=(",", ":"), allow_nan=False).encode(),
            mtime=0,
        )
    )
    x, names = build_features(source["rows"], games, sides, people)
    if x.shape != (38850, 46) or len(people) != 34871 or len(sides) != 2436:
        raise ValueError("Registered full shot-style coverage differs")
    feature_key = hashlib.sha256((key + hashlib.sha256(archive.read_bytes()).hexdigest()).encode()).hexdigest()
    path = args.cache / "shot_style_features.npz"
    np.savez_compressed(path, key=feature_key, source_key=source["key"], x=x, names=names)
    coverage = {}
    for cohort in ("start", "bench"):
        mask = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        coverage[cohort] = dict(
            allCases=int(mask.sum()),
            bodyLiftKnown=int(np.isfinite(x[mask, names.index("shotstyle_match_body_lift")]).sum()),
            zoneLiftKnown=int(np.isfinite(x[mask, names.index("shotstyle_match_zone_lift")]).sum()),
        )
    report = dict(
        scope="Testing-only shot-style source/features; no formula fit or accuracy claim",
        sourceKey=source["key"],
        implementationKey=key,
        featureKey=feature_key,
        observationsSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        featuresSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        rows=len(x),
        columns=len(names),
        sourceSideRecords=len(sides),
        knownSideProfiles=sum(r["profile"]["known"] for r in sides),
        sourcePlayerRecords=len(people),
        knownPlayerProfiles=sum(r["profile"]["known"] for r in people),
        laterCoverage=coverage,
        status="Independent raw/profile/ALL46laggedfeature/futuremutation audit REQUIRED before earlier-only diagnostic",
    )
    args.out.write_text(json.dumps(report, indent=2))
    print("SHOT_STYLE_FEATURES " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
