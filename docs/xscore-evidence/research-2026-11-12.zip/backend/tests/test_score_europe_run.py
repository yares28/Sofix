import numpy as np

from app.research.score_europe_run import predict_components, select_components


def test_prediction_uses_chosen_level_and_never_blends_disjoint_levels():
    components = (np.array([35, 60]), np.array([[0.6, 0.4], [0.3, 0.7]]), {0.5: np.array([[5, 10], [5, 10]])})
    result = predict_components(components, {"threshold": 0.5, "quantile": 0.5, "ordinaryShift": 0})
    assert result.tolist() == [40, 70]


def test_selection_uses_earlier_targets_and_keeps_every_case():
    components = (
        np.array([35, 60]),
        np.array([[0.6, 0.4], [0.3, 0.7]]),
        {q: np.zeros((2, 2)) for q in (0.35, 0.5, 0.65)},
    )
    winner, candidates = select_components(components, np.array([35, 60]))
    assert winner["selection"]["within7"] == 1
    assert len(predict_components(components, winner)) == 2
    assert len(candidates) == 315
