"""Test earlier-only routine scores using archived defensive roles."""

import hashlib
import json
from collections import Counter, defaultdict, deque
from datetime import timedelta

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_style_signal import forecast
from app.research.score_player_context import link_names, words
from app.research.score_search import cutoff_for, moment
from app.research.score_substitution_clock import capture
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_defender_slots"
AGE = timedelta(days=365)
ROLES = ("centre", "wide", "advanced")
ADVANCED = {"MC", "DMC", "AMC", "AMR", "AML", "MR", "ML", "FW", "FWR", "FWL", "DMR", "DML", "DMLC", "DMRC"}


def archived_slot(code):
    if code == "DC":
        return "centre"
    if code in ("DL", "DR"):
        return "wide"
    return "advanced" if code in ADVANCED else None


class Slots:
    def __init__(self, aliases):
        self.aliases = aliases
        self.records = {}
        self.audit = Counter()

    def observe(self, game, detail, side, clocks, qualified):
        starters, subs = clocks
        club = qualified["club"]
        native = {slug: p for slug, p in game["players"].items() if p.get("played") and p["team"] == club}
        lineup = starters + subs
        links, _ = link_names([p["name"] for p in lineup], native, self.aliases)
        reliable = {r["player"] for r in qualified["players"]}
        for player in starters + subs:
            slug = links.get(words(player["name"]))
            if slug not in reliable or native[slug]["pos"] != "DEF":
                continue
            if player["on"] is None:
                slot = archived_slot(player["pos"])
                kind = "start"
            else:
                minute = player["on"]
                out = [p for p in lineup if p.get("off") == minute]
                arrivals = [p for p in subs if p["on"] == minute]
                if len(out) != 1 or len(arrivals) != 1 or out[0] not in starters:
                    self.audit["subProxyAmbiguous"] += 1
                    continue
                outgoing = links.get(words(out[0]["name"]))
                if outgoing not in reliable or native[outgoing]["pos"] != "DEF":
                    self.audit["subProxyOutgoingUnknown"] += 1
                    continue
                slot = archived_slot(out[0]["pos"])
                kind = "bench"
            if slot is None:
                self.audit["unknownSlot"] += 1
                continue
            key = game["id"], slug
            assert key not in self.records
            self.records[key] = dict(
                game=game["id"],
                player=slug,
                date=game["date"],
                club=club,
                cohort=kind,
                slot=slot,
                aa=native[slug]["aa"],
            )
            self.audit[kind + "_" + slot] += 1


def history_features(person, club, fallback):
    counts = np.bincount([r[0] for r in person], minlength=3)
    pool = np.bincount([r[0] for r in club], minlength=3) + 1
    distribution = (counts + 4 * pool / pool.sum()) / (counts.sum() + 4)
    common = float(np.median([a for _, a in person])) if person else fallback
    shifts = np.zeros(3)
    for i in range(3):
        values = [a for slot, a in person if slot == i]
        if values:
            shifts[i] = (np.median(values) - common) * len(values) / (len(values) + 4)
    return common, np.r_[distribution, shifts, distribution @ shifts]


def features(rows, games, cache, names):
    data = sorted([(moment(r["date"]) + DELAY, r) for r in cache], key=lambda pair: pair[0])
    previous, team = defaultdict(lambda: deque(maxlen=24)), defaultdict(lambda: deque(maxlen=160))
    locks = [cutoff_for(r["date"]) for r in rows]
    idx = {k: names.index(f"{k}_10_aa") for k in ("start", "bench")}
    baseline, candidate, cursor = np.empty((len(rows), 3)), np.empty((len(rows), 7)), 0
    for i in sorted(range(len(rows)), key=locks.__getitem__):
        row, lock = rows[i], locks[i]
        while cursor < len(data) and data[cursor][0] < lock:
            ready, r = data[cursor]
            key = r["club"], r["cohort"]
            item = ready - DELAY, (ROLES.index(r["slot"]), r["aa"])
            previous[r["player"], *key].append(item)
            team[key].append(item)
            cursor += 1
        g = games[row["game"]]
        club = g["players"][row["player"]]["team"]
        assert row["date"] == g["date"] and club in (g["home"]["slug"], g["away"]["slug"])
        key = club, row["cohort"]
        person = [v for t, v in previous[row["player"], *key] if t >= lock - AGE]
        unit = [v for t, v in team[key] if t >= lock - AGE]
        common, candidate[i] = history_features(person, unit, row["x"][idx[row["cohort"]]])
        baseline[i] = common, np.log1p(len(person)), np.log1p(len(unit))
    return baseline, candidate


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    source = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in source["rows"] if r["game"] in games and r["pos"] == "DEF"]
    collector = Slots(json.loads((ROOT / "player_names.json").read_bytes()))
    _, _, digest = capture(list(games.values()), collector.aliases, observe=collector.observe)
    receipt = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    assert digest == receipt["archiveReadSHA"]
    qualified = list(collector.records.values())
    baseline, expanded = features(rows, games, qualified, source["features"])
    native = np.array([r["x"] for r in rows])
    base = np.column_stack((native, baseline))
    candidate = np.column_stack((base, expanded))
    roles = np.array([r["cohort"] for r in rows])
    date = np.array([r["date"] for r in rows])
    locks = np.array([cutoff_for(d) for d in date])
    ready = np.array([moment(d) + DELAY for d in date])
    labels = np.array([r["aa"] for r in rows]) - baseline[:, 0]
    periods = {}
    for phase, (begin, end) in PHASES.items():
        selected = (date >= begin) & (date < end)
        usable = ready < locks[selected].min()
        periods[phase] = {}
        for cohort in ("start", "bench"):
            test, fit = selected & (roles == cohort), usable & (roles == cohort)
            predictions = [forecast(x, labels, fit, test) for x in (base, candidate)]
            sample = [
                (i, collector.records[r["game"], r["player"]])
                for i, r in enumerate(rows)
                if test[i] and (r["game"], r["player"]) in collector.records
            ]
            priors = Counter(
                r["slot"]
                for r in qualified
                if r["cohort"] == cohort and moment(r["date"]) + DELAY < locks[selected].min()
            )
            default = priors.most_common(1)[0][0]
            test_indices = np.flatnonzero(test)
            by_role_match = defaultdict(list)
            by_label = {i: r for i, r in sample}
            for j, i in enumerate(test_indices):
                observation = by_label.get(i)
                if observation is None:
                    group = "unverifiedSlot"
                elif ROLES[np.argmax(expanded[i, :3])] == observation["slot"]:
                    group = "slotCorrect"
                else:
                    group = "slotIncorrect"
                by_role_match[group].append(j)
            split = {
                group: metrics(labels[test][indices], predictions[0][indices], predictions[1][indices])
                for group, indices in by_role_match.items()
            }
            periods[phase][cohort] = dict(
                routine=metrics(labels[test], *predictions),
                slotLabels=len(sample),
                slotGuessHits=int(sum(ROLES[np.argmax(expanded[i, :3])] == r["slot"] for i, r in sample)),
                pooledSlotGuessHits=sum(default == r["slot"] for _, r in sample),
                slotDiagnostic=split,
            )
    gate = {}
    for cohort in ("start", "bench"):
        group = [v[cohort]["routine"] for v in periods.values()]
        n = sum(r["n"] for r in group)
        hits = sum(r["gained"] - r["lost"] for r in group)
        gain = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in group) / n
        stable = sum(r["mae"][1] <= r["mae"][0] and r["hits"][1] >= r["hits"][0] for r in group)
        gate[cohort] = dict(
            n=n, hitGain=hits, maeGain=gain, phasesWithoutLoss=stable, passEarlier=hits > 0 and gain > 0 and stable >= 2
        )
    output = dict(
        nativeSHA=NATIVE_SHA,
        archiveSHA=digest,
        audit=dict(collector.audit),
        periods=periods,
        gate=gate,
        benchIsReplacementProxy=True,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
