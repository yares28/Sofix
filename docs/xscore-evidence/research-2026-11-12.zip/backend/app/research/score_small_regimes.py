"""Testing only: compact past-only predictors for low/high actual score regimes."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_empirical_density import empirical_predictions, fit_bank
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres

GATES = ("logistic_0.1", "logistic_1", "boost_3", "boost_7", "boost_15")
CENTRES = np.arange(0, 100.01, 0.5)


def split_masks(rows):
    dates = np.array([r["date"] for r in rows])
    valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
    test = dates >= "2026-01-01"
    select = valid & (dates >= "2025-11-01")
    first_select = min(cutoff_for(r["date"]) for r, yes in zip(rows, select, strict=True) if yes)
    first_test = min(cutoff_for(r["date"]) for r, yes in zip(rows, test, strict=True) if yes)
    first_valid = min(cutoff_for(r["date"]) for r, yes in zip(rows, valid, strict=True) if yes)
    available = np.array([moment(r["date"]) + timedelta(hours=48) for r in rows])
    return {
        "train": (dates < "2025-07-01") & (available < first_valid),
        "valid": valid,
        "bank": valid & (dates < "2025-11-01") & (available < first_select),
        "select": select,
        "refit": (dates < "2026-01-01") & (available < first_test),
        "test": test,
    }


def compact_inputs(base, names, player, player_names, cohort):
    columns, selected = [], []

    def add(matrix, available, wanted):
        for name in wanted:
            if name in available:
                columns.append(matrix[:, available.index(name)])
                selected.append(name)

    add(
        base, names, ["home", *["position_" + p for p in POSITIONS], "days_since_appearance", cohort + "_history_count"]
    )
    add(
        base,
        names,
        [
            f"{cohort}_{n}_{field}"
            for n in (3, 10)
            for field in ("score", "aa", "minutes", "decisive", "score_sd", "role_depth", "role_edge")
        ]
        + [f"{cohort}_30_{f}" for f in ("score", "aa", "decisive")]
        + [
            f"{cohort}_rate_{f}"
            for f in ("goal_assist", "ontarget_scoring_att", "accurate_pass", "won_tackle", "duel_won", "saves")
        ]
        + [f"{side}_5_{f}" for side in ("team", "opponent") for f in ("scored", "conceded")]
        + ["style_aa_per90", "style_goal_assist", "style_saves"],
    )
    home = base[:, names.index("home")] > 0
    for label, h, a in (("model_goals", "match_lam_h", "match_lam_a"), ("model_cs", "match_cs_h", "match_cs_a")):
        for side in ("own", "other"):
            selected.append(f"{side}_{label}")
            columns.append(np.where(home == (side == "own"), base[:, names.index(h)], base[:, names.index(a)]))
    groups, feature_names = {"form": np.column_stack(columns)}, {"form": selected.copy()}
    add(
        player,
        player_names,
        [
            f"same_{n}_{field}"
            for n in (3, 10)
            for field in (
                "source_games",
                "source_age",
                "chance_xg90_mean",
                "chance_npxg90_mean",
                "chance_shots90_mean",
                "chance_big90_mean",
                "chance_key_passes90_mean",
                "chance_provider_fraction_mean",
            )
        ]
        + ["all_3_source_games", "all_3_chance_xg90_mean", "all_3_chance_shots90_mean"],
    )
    groups["chances"], feature_names["chances"] = np.column_stack(columns), selected.copy()
    add(
        player,
        player_names,
        [
            f"same_{n}_usage_{field}_mean"
            for n in (3, 10)
            for field in ("pass_x", "pass_edge", "attacking_fraction", "central_fraction", "completed90")
        ]
        + ["all_3_usage_pass_x_mean"],
    )
    groups["usage"], feature_names["usage"] = np.column_stack(columns), selected.copy()
    return groups, feature_names


def odds_shift(probability, multiplier):
    if multiplier <= 0 or not np.isfinite(probability).all() or (probability < 0).any() or (probability > 1).any():
        raise ValueError("Invalid gate probability or odds multiplier")
    return multiplier * probability / (1 - probability + multiplier * probability)


def choose_score(low, high, probability, odds):
    p = odds_shift(probability, odds)[:, None]
    return window_centres((1 - p) * low + p * high, CENTRES)


def branch_mass(samples, location, scale, centres, cutoff, high):
    """Window probabilities after regime truncation and physical clipping at0/100."""
    if (
        len(samples) == 0
        or not np.isfinite(samples).all()
        or not np.isfinite(location).all()
        or not np.isfinite(scale).all()
        or (scale <= 0).any()
    ):
        raise ValueError("Invalid conditional support")
    samples = np.sort(samples)
    lo = (centres[None, :] - 7 - location[:, None]) / scale[:, None]
    hi = (centres[None, :] + 7 - location[:, None]) / scale[:, None]
    boundary = np.searchsorted(samples, (cutoff - location) / scale, side="left") / len(samples)
    lower = np.searchsorted(samples, lo, side="left") / len(samples)
    upper = np.searchsorted(samples, hi, side="right") / len(samples)
    if high:
        lower = np.maximum(lower, boundary[:, None])
        upper = np.where(centres[None, :] + 7 >= 100, 1, upper)
        denominator = 1 - boundary
    else:
        lower = np.where(centres[None, :] - 7 <= 0, 0, lower)
        upper = np.minimum(upper, boundary[:, None])
        denominator = boundary
    if (denominator <= 0).any():
        raise ValueError("Empty conditional support")
    return np.clip((upper - lower) / denominator[:, None], 0, 1)


def locations(parts):
    q = np.sort(parts, axis=2)
    return q[:, :, 1], np.clip((q[:, :, 2] - q[:, :, 0]) / 0.7706409328151355, 2, 40)


def error_bank(y, parts, positions, fit, cutoff):
    location, scale = locations(parts)
    branch = (y >= cutoff).astype(int)
    idx = np.flatnonzero(fit)
    residual = (y[idx] - location[idx, branch[idx]]) / scale[idx, branch[idx]]
    return {
        (b, p): residual[(branch[idx] == b) & ((positions[idx] == p) if p else True)]
        for b in (0, 1)
        for p in (None, *POSITIONS)
    }


def conditional_masses(parts, positions, bank, cutoff, spread):
    location, scale = locations(parts)
    result = [np.zeros((len(parts), len(CENTRES))) for _ in (0, 1)]
    fallbacks = 0
    for b in (0, 1):
        for pos in set(positions):
            idx = np.flatnonzero(positions == pos)
            pooled = branch_mass(bank[b, None], location[idx, b], scale[idx, b] * spread, CENTRES, cutoff, bool(b))
            residual = bank.get((b, pos), [])
            if len(residual):
                try:
                    conditional = branch_mass(
                        residual, location[idx, b], scale[idx, b] * spread, CENTRES, cutoff, bool(b)
                    )
                    pooled = (len(residual) * conditional + 50 * pooled) / (len(residual) + 50)
                except ValueError as error:
                    if str(error) != "Empty conditional support":
                        raise
                    fallbacks += len(idx)
            result[b][idx] = pooled
    return *result, fallbacks


def fitted_components(x, y, fit, check, cutoff, path, key):
    if path.exists():
        with np.load(path) as old:
            if str(old["key"]) == key:
                return old["parts"], old["gates"]
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler

    parts = np.zeros((int(check.sum()), 2, 3))
    gate = np.zeros((int(check.sum()), len(GATES)))
    common = dict(
        max_iter=120,
        learning_rate=0.06,
        l2_regularization=20,
        min_samples_leaf=80,
        early_stopping=False,
        random_state=20261104,
    )
    for b in (0, 1):
        training = fit & ((y >= cutoff) == bool(b))
        if training.sum() < 20:
            raise ValueError("Insufficient earlier branch cases")
        for j, q in enumerate((0.35, 0.5, 0.65)):
            model = HistGradientBoostingRegressor(loss="quantile", quantile=q, max_leaf_nodes=7, **common)
            parts[:, b, j] = model.fit(x[training], y[training]).predict(x[check])
    for j, name in enumerate(GATES):
        if name.startswith("logistic"):
            model = make_pipeline(
                SimpleImputer(add_indicator=True, keep_empty_features=True),
                StandardScaler(),
                LogisticRegression(C=float(name.split("_")[1]), max_iter=2000),
            )
        else:
            model = HistGradientBoostingClassifier(max_leaf_nodes=int(name.split("_")[1]), **common)
        gate[:, j] = model.fit(x[fit], y[fit] >= cutoff).predict_proba(x[check])[:, 1]
    np.savez_compressed(path, key=key, parts=parts, gates=gate)
    return parts, gate


def controls(source, rows, cohort, split, cache, reports):
    """Reconstruct the already frozen controls without any new parameter search."""
    valid = split["valid"]
    y = np.array([r["score"] for r in rows])
    if cohort == "start":
        report = json.loads((reports / "laliga_score_match_empirical_density.json").read_text())
        component = json.loads((reports / "laliga_score_match_context.json").read_text())
        spec = report["cohorts"][cohort]["empiricalSpec"]
        classes, probability, parts = components(
            cache / "feature_laliga_score_match_context_start_chances_and_intensity_selection.npz",
            component["implementationKey"],
        )
        positions = np.array([r["pos"] for r in rows])[valid]
        bank = fit_bank(
            classes,
            parts,
            np.array([r["aa"] for r in rows])[valid],
            np.array([r["level"] for r in rows])[valid],
            positions,
            split["bank"][valid],
            spec["mode"],
        )
        earlier = empirical_predictions(
            classes, probability, parts, positions, bank, spec["prior"], spec["multiplier"], spec["shift"]
        )
        path, prediction_name = cache / "laliga_score_match_empirical_density_predictions_start.npz", "prediction"
    else:
        from app.research.score_analogues import predict_lookup, prepare_lookup

        report = json.loads((reports / "laliga_score_analogues.json").read_text())
        spec = report["cohorts"][cohort]["winner"]
        with np.load(cache / f"analogues_bench_{spec['group']}_selection.npz") as old:
            if str(old["key"]) != report["implementationKey"]:
                raise ValueError("Earlier analogue identity differs")
            prepared = prepare_lookup(rows, valid, split["train"], old["indices"], old["distance"])
        earlier, _ = predict_lookup(prepared, spec)
        path, prediction_name = cache / "analogues_predictions_bench.npz", "prediction"
    if report["sourceKey"] != source["key"]:
        raise ValueError("Control source identity differs")
    with np.load(path) as old:
        if str(old["key"]) != report["implementationKey"] or not np.array_equal(old["y"], y[split["test"]]):
            raise ValueError("Later control identity differs")
        later = old[prediction_name]
    if abs(measure(y[split["test"]], later)["within7"] - report["cohorts"][cohort]["later"]["within7"]) > 1e-12:
        raise ValueError("Control rate did not reproduce")
    return earlier, later


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "stats-cache", "player-cache", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    source = json.loads(args.cases.read_text())
    with np.load(args.stats_cache) as data:
        base, names, stat_key = data["x"], data["names"].tolist(), str(data["key"])
    with np.load(args.player_cache) as data:
        player, player_names, player_key = data["x"], data["names"].tolist(), str(data["key"])
    prior = json.loads((args.out.parent / "laliga_score_player_context.json").read_text())
    if (
        prior["sourceKey"] != source["key"]
        or prior["featureKey"] != player_key
        or len(base) != len(source["rows"])
        or len(player) != len(base)
    ):
        raise ValueError("Input source identity differs")
    plan = args.out.with_suffix(".plan.json")
    key = hashlib.sha256(
        (source["key"] + stat_key + player_key).encode() + Path(__file__).read_bytes() + plan.read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind validation",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y = np.array([r["score"] for r in rows])
        pos = np.array([r["pos"] for r in rows])
        split = split_masks(rows)
        valid, select, test = split["valid"], split["select"], split["test"]
        groups, feature_names = compact_inputs(base[keep], names, player[keep], player_names, cohort)
        old_earlier, old_later = controls(source, rows, cohort, split, args.cache, args.out.parent)
        candidates = [{"kind": "control", "selection": measure(y[select], old_earlier[select[valid]])}]
        selected_groups, stored_earlier = {}, {}
        for group, x in groups.items():
            for cutoff in (50, 60):
                label = f"{cohort}_{group}_{cutoff}"
                parts, gates = fitted_components(
                    x, y, split["train"], valid, cutoff, args.cache / f"{args.out.stem}_{label}_selection.npz", key
                )
                stored_earlier[group, cutoff] = parts
                bank = error_bank(y[valid], parts, pos[valid], split["bank"][valid], cutoff)
                local = []
                for spread in (0.75, 1, 1.25):
                    low, high, fallback = conditional_masses(parts[select[valid]], pos[select], bank, cutoff, spread)
                    for j, gate in enumerate(GATES):
                        for odds in (0.5, 1, 1.5, 2, 3):
                            p = choose_score(low, high, gates[select[valid], j], odds)
                            local.append(
                                {
                                    "kind": "regime",
                                    "group": group,
                                    "cutoff": cutoff,
                                    "gate": gate,
                                    "spread": spread,
                                    "odds": odds,
                                    "pooledFallbackCases": fallback,
                                    "selection": measure(y[select], p),
                                }
                            )
                best = max(local, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
                selected_groups[label] = best
                candidates.extend(local)
                print("SELECTED " + json.dumps({"cohort": cohort, **best}), flush=True)
        winner = max(candidates, key=lambda s: (s["selection"]["within7"], -s["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2)
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        prediction = old_later.copy()
        variants, all_predictions = {}, {"control": old_later}
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        for label, spec in selected_groups.items():
            group, cutoff = spec["group"], spec["cutoff"]
            parts, gates = fitted_components(
                groups[group], y, split["refit"], test, cutoff, args.cache / f"{args.out.stem}_{label}_later.npz", key
            )
            bank = error_bank(y[valid], stored_earlier[group, cutoff], pos[valid], split["refit"][valid], cutoff)
            low, high, fallback = conditional_masses(parts, pos[test], bank, cutoff, spec["spread"])
            p = gates[:, GATES.index(spec["gate"])]
            forecast = choose_score(low, high, p, spec["odds"])
            all_predictions[label] = forecast
            if winner == spec:
                prediction = forecast
            oracle = (
                np.minimum(
                    np.abs(y[test] - window_centres(low, CENTRES)), np.abs(y[test] - window_centres(high, CENTRES))
                )
                <= 7
            )
            variants[label] = {
                "spec": spec,
                "later": measure(y[test], forecast),
                "gain95": paired_interval(y[test], forecast, old_later, weeks),
                "highScoreGames": measure(y[test][y[test] >= 60], forecast[y[test] >= 60]),
                "gateProbabilityError": float(np.mean((p - (y[test] >= cutoff)) ** 2)),
                "pooledFallbackCases": fallback,
                "unusableOracleEitherBranchHitRate": float(oracle.mean()),
                "positions": {
                    p: measure(y[test][pos[test] == p], forecast[pos[test] == p])
                    for p in POSITIONS
                    if (pos[test] == p).any()
                },
            }
            print(
                "EVALUATED " + json.dumps({"cohort": cohort, "label": label, "later": variants[label]["later"]}),
                flush=True,
            )
        result = {
            "winner": winner,
            "candidateCount": len(candidates),
            "featureNames": feature_names,
            "control": measure(y[test], old_later),
            "later": measure(y[test], prediction),
            "weekly95": bootstrap(y[test], prediction, weeks),
            "variants": variants,
            "splitCounts": {k: int(v.sum()) for k, v in split.items()},
        }
        all_predictions["chosen"] = prediction
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz", key=key, y=y[test], **all_predictions
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print("RESULT " + json.dumps({"cohort": cohort, "winner": winner, "later": result["later"]}), flush=True)


if __name__ == "__main__":
    main()
