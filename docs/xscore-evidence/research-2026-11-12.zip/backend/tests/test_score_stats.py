import copy

import numpy as np
import pytest

from app.research.score_foundation import build_cases
from app.research.score_stats import add_stat_features, decisive_level, fit_weights, point_totals, simulate_counts
from app.research.score_stats_hybrid import choose_level
from tests.test_score_search import game


def test_count_weights_are_learned_before_the_requested_boundary():
    earlier = game("2024-09-01T16:00:00Z", 37, "earlier")
    earlier["players"]["player"].update(aa=2, stats={"won_tackle": [1, 2]})
    future = copy.deepcopy(earlier)
    future.update(id="future", date="2026-09-01T16:00:00Z")
    future["players"]["player"]["stats"] = {"won_tackle": [1, 99]}
    weights, _ = fit_weights([earlier, future], ["won_tackle"], "2025-01-01")
    assert point_totals(np.array([[3.0]]), np.array(["MID"]), weights).tolist() == [6]


def test_hybrid_selects_one_actual_level_without_blending_them():
    probability = np.array([[0.6, 0.3, 0.1], [0.2, 0.3, 0.5]])
    assert choose_level(probability, np.array([35, 60, 70]), 0.5).tolist() == [35, 70]


def test_unknown_nonzero_point_rule_is_not_silently_zero():
    with pytest.raises(ValueError, match="inconsistent"):
        a = game("2024-09-01T16:00:00Z", 40, "a")
        b = game("2024-09-10T16:00:00Z", 40, "b")
        a["players"]["player"]["stats"] = {"won_tackle": [1, 2]}
        b["players"]["player"]["stats"] = {"won_tackle": [1, 3]}
        fit_weights([a, b], ["won_tackle"], "2025-01-01")


def test_decisive_level_is_reconstructed_from_counts_including_keeper_clean_sheet():
    names = ["goals", "goal_assist", "clean_sheet_60", "red_card"]
    count = np.array([[1, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], dtype=float)
    assert decisive_level(count, names, np.array(["FWD", "GK", "DEF"])).tolist() == [70, 60, 15]


def test_simulation_keeps_clean_sheet_points_and_decisive_level_consistent():
    names = ["goals_conceded", "clean_sheet_60"]
    weights = np.zeros((4, 2))
    weights[1, 1] = 10
    score, aa = simulate_counts(
        np.zeros((2, 2)),
        np.array([90, 90]),
        np.zeros((2, 2)),
        np.zeros(2),
        np.array([90, 90]),
        np.array(["GK", "DEF"]),
        np.array(["GK", "DEF"]),
        weights,
        names,
        np.zeros(2),
        1,
        draws=8,
    )
    assert score.tolist() == [60, 45]
    assert aa.tolist() == [0, 10]


def test_new_stat_features_do_not_read_the_target_or_same_week():
    past = game("2025-09-20T16:00:00Z", 40, "past")
    past["players"]["player"]["stats"] = {"won_tackle": [2, 4]}
    target = game("2025-10-12T20:00:00Z", 80, "target")
    rows, names = build_cases([past, target], {})
    before = add_stat_features([past, target], rows, names, ["won_tackle"])[0]
    changed = copy.deepcopy(target)
    changed["players"]["player"].update(mins=1, stats={"won_tackle": [90, 180]})
    after = add_stat_features([past, changed], rows, names, ["won_tackle"])[0]
    np.testing.assert_array_equal(before, after)


def test_missing_minutes_are_not_a_zero_minute_appearance():
    g = game("2025-10-12T20:00:00Z", 35)
    rows, names = build_cases([g], {})
    g["players"]["player"]["mins"] = None
    with pytest.raises(ValueError, match="Missing minutes"):
        add_stat_features([g], rows, names, ["won_tackle"])
