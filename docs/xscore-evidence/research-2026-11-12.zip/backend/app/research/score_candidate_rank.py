"""Testing only: learn which counterfactual decisive/ordinary score is likely to hit."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research.score_analogues import descriptor_groups
from app.research.score_empirical_density import calibration_split
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval

LEVELS = np.array([0, 5, 15, 35, 60, 70, 80, 90, 100])


def candidate_frame(base, classes, probability, parts):
    n, levels = probability.shape
    k = levels * 3
    q = np.sort(np.stack([parts[v] for v in (0.35, 0.5, 0.65)], axis=2), axis=2)
    potential_levels = np.tile(np.repeat(classes, 3), (n, 1))
    scores = np.clip(potential_levels + q.reshape(n, k), np.where(potential_levels >= 60, potential_levels, 0), 100)
    p = np.repeat(probability, 3, axis=1)
    flattened_levels = potential_levels.ravel()
    frame = np.column_stack(
        (
            np.repeat(base, k, axis=0),
            np.column_stack([flattened_levels == level for level in LEVELS]),
            scores.ravel(),
            p.ravel(),
            np.repeat(q[:, :, 0], 3, axis=1).ravel(),
            np.repeat(q[:, :, 1], 3, axis=1).ravel(),
            np.repeat(q[:, :, 2], 3, axis=1).ravel(),
            np.tile([0.35, 0.5, 0.65], n * levels),
        )
    )
    return frame.astype(np.float32), scores, p


def choose_candidate(scores, success, probability, penalty, anchor):
    adjusted = success + penalty * np.log(np.maximum(probability, 1e-8))
    winners = abs(adjusted - adjusted.max(axis=1, keepdims=True)) <= 1e-12
    distance = np.where(winners, abs(scores - anchor[:, None]), np.inf)
    selected = distance.argmin(axis=1)
    return scores[np.arange(len(scores)), selected]


def anchor_score(classes, probability, parts):
    index = probability.argmax(axis=1)
    level = classes[index]
    return np.clip(level + parts[0.5][np.arange(len(index)), index], np.where(level >= 60, level, 0), 100)


def model_for(leaves, minimum):
    from sklearn.ensemble import HistGradientBoostingClassifier

    return HistGradientBoostingClassifier(
        max_leaf_nodes=leaves,
        min_samples_leaf=minimum,
        max_iter=100,
        learning_rate=0.05,
        l2_regularization=10,
        early_stopping=False,
        random_state=20261103,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "reports", "cache", "packages", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    sequence = json.loads((args.reports / "laliga_score_sequence.json").read_text(encoding="utf-8"))
    context_report = json.loads((args.reports / "laliga_score_match_context.json").read_text(encoding="utf-8"))
    selector = json.loads((args.reports / "laliga_score_selector.json").read_text(encoding="utf-8"))
    if any(r["sourceKey"] != source["key"] for r in (sequence, context_report, selector)):
        raise ValueError("Source cases differ")
    key = hashlib.sha256(
        (source["key"] + sequence["implementationKey"] + context_report["implementationKey"]).encode()
        + Path(__file__).read_bytes()
    ).hexdigest()
    with np.load(args.cache / "match_context_features.npz") as stored:
        if str(stored["key"]) != context_report["featureKey"]:
            raise ValueError("Context feature cache differs")
        context, names = stored["x"], stored["names"].tolist()
    columns = [
        names.index(n)
        for n in (
            "own_3_xg_for_mean",
            "opponent_3_xg_for_mean",
            "own_3_ppda_mean",
            "opponent_3_ppda_mean",
            "own_3_box_for_mean",
            "opponent_3_box_for_mean",
        )
    ]
    report = {
        "scope": "Testing only; no application change",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "implementationKey": key,
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        dates = np.array([r["date"] for r in rows])
        valid = (dates >= "2025-07-01") & (dates < "2026-01-01")
        test = dates >= "2026-01-01"
        y = np.array([r["score"] for r in rows])
        positions = np.array([r["pos"] for r in rows])
        fit, select = calibration_split([r for r, yes in zip(rows, valid, strict=True) if yes])
        base = np.column_stack(
            (
                descriptor_groups(rows, source["features"], cohort)["form_role_match"],
                context[keep][:, columns],
                np.column_stack([positions == p for p in POSITIONS]),
            )
        )
        prefix = f"feature_laliga_score_sequence_{cohort}_ordered_observations"
        classes, probability, parts = components(
            args.cache / (prefix + "_selection.npz"), sequence["implementationKey"]
        )
        frame, scores, p = candidate_frame(base[valid], classes, probability, parts)
        k = scores.shape[1]
        anchor = anchor_score(classes, probability, parts)
        target = (abs(scores - y[valid, None]) <= 7).ravel()
        with np.load(args.cache / f"selector_{cohort}_control_earlier.npz") as stored:
            if str(stored["key"]) != selector["implementationKey"]:
                raise ValueError("Earlier control cache differs")
            earlier_control = stored["prediction"]
        candidates = [{"kind": "control", "selection": measure(y[valid][select], earlier_control[select])}]
        for leaves in (7, 15):
            for minimum in (400, 800):
                model = model_for(leaves, minimum).fit(
                    frame[np.repeat(fit, k)],
                    target[np.repeat(fit, k)],
                    sample_weight=np.full(int(fit.sum()) * k, 1 / k),
                )
                success = model.predict_proba(frame[np.repeat(select, k)])[:, 1].reshape(int(select.sum()), k)
                for penalty in (0, 0.03, 0.1):
                    prediction = choose_candidate(scores[select], success, p[select], penalty, anchor[select])
                    candidates.append(
                        {
                            "kind": "ranked",
                            "leaves": leaves,
                            "minimumLeaf": minimum,
                            "penalty": penalty,
                            "selection": measure(y[valid][select], prediction),
                        }
                    )
        winner = max(candidates, key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
        alternate_spec = max(candidates[1:], key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
        )
        print("FROZEN " + json.dumps({"cohort": cohort, **winner}), flush=True)
        model = model_for(alternate_spec["leaves"], alternate_spec["minimumLeaf"]).fit(
            frame, target, sample_weight=np.full(len(frame), 1 / k)
        )
        classes, probability, parts = components(args.cache / (prefix + "_later.npz"), sequence["implementationKey"])
        later_frame, later_scores, later_p = candidate_frame(base[test], classes, probability, parts)
        success = model.predict_proba(later_frame)[:, 1].reshape(later_scores.shape)
        alternate = choose_candidate(
            later_scores, success, later_p, alternate_spec["penalty"], anchor_score(classes, probability, parts)
        )
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Later control cases differ")
            baseline = stored["control"]
        prediction = baseline if winner["kind"] == "control" else alternate
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        result = {
            "winner": winner,
            "rankedSpec": alternate_spec,
            "candidateCount": len(candidates),
            "choicesPerAppearance": int(later_scores.shape[1]),
            "metaFitCases": int(fit.sum()),
            "metaSelectionCases": int(select.sum()),
            "later": measure(y[test], prediction),
            "rankedLater": measure(y[test], alternate),
            "control": measure(y[test], baseline),
            "gain95": paired_interval(y[test], alternate, baseline, weeks),
            "weekly95": bootstrap(y[test], alternate, weeks),
            "diagnosticPerfectChoiceOnly": {
                "notUsablePrediction": True,
                "n": int(test.sum()),
                "within7": float((abs(later_scores - y[test, None]) <= 7).any(axis=1).mean()),
            },
            "positions": {
                p: measure(y[test][positions[test] == p], alternate[positions[test] == p])
                for p in POSITIONS
                if (positions[test] == p).any()
            },
            "highScoreGames": measure(y[test][y[test] >= 60], alternate[y[test] >= 60]),
        }
        np.savez_compressed(
            args.cache / f"candidate_rank_predictions_{cohort}.npz",
            key=key,
            y=y[test],
            prediction=prediction,
            alternate=alternate,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print("RESULT " + json.dumps({"cohort": cohort, **result}), flush=True)


if __name__ == "__main__":
    main()
