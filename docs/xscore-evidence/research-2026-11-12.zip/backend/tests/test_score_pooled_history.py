"""Testing only: one identical causal input schema for domestic and European training."""

from copy import deepcopy
from datetime import timedelta

import numpy as np
import pytest

from app.research import score_pooled_history as pooled
from app.research.score_search import cutoff_for, moment


def observation(date, cohort="start", source="laliga", score=35, aa=0):
    return dict(
        game=date,
        player="p",
        date=date,
        club="a",
        pos="MID",
        cohort=cohort,
        minutes=90,
        score=score,
        level=35,
        source=source,
        ordinary=dict(point=aa, lower=aa, upper=aa, kind="exact"),
        routine=dict(point=aa, lower=aa, upper=aa, kind="exact"),
        effect=dict(gcInferredZero=False),
    )


def query(date, cohort="start", source="laliga"):
    return dict(game=date, date=date, player="p", pos="MID", cohort=cohort, club="a", home=True, source=source)


def test_pooled_cold_start_missing_rates_and_native_zero_are_distinct():
    q = query("2024-02-03T20:00:00Z")
    cold = pooled.build_features([q], [])
    assert cold.shape == (1, 226)
    assert cold[0, pooled.NAMES.index("routine_combined_same_cohort_15_observed_games")] == 0
    assert np.isnan(cold[0, pooled.NAMES.index("routine_combined_same_cohort_15_routine90_weighted_mean")])
    warm = pooled.build_features([q], [observation("2024-01-01T12:00:00Z")])
    assert warm[0, pooled.NAMES.index("routine_combined_same_cohort_15_routine90_weighted_mean")] == 0
    assert warm[0, pooled.NAMES.index("position_MID")] == 1
    assert warm[0, pooled.NAMES.index("home")] == 1
    assert warm[0, pooled.NAMES.index("source_is_euro")] == 0


def test_pooled_strict_availability_current_labels_and_unknown_cohort_history():
    q = query("2024-02-03T20:00:00Z")
    boundary = (cutoff_for(q["date"]) - timedelta(hours=48)).isoformat()
    old = observation("2024-01-01T12:00:00Z", cohort=None, source="euro", aa=3)
    edge = observation(boundary, aa=999)
    current = observation(q["date"], aa=-999)
    before = pooled.build_features([q], [old, edge, current])
    assert before[0, pooled.NAMES.index("routine_combined_same_position_15_observed_games")] == 1
    assert before[0, pooled.NAMES.index("routine_combined_same_cohort_15_observed_games")] == 0
    changed = deepcopy([old, edge, current])
    for r in changed[1:]:
        r.update(score=np.nan, level=np.nan, minutes=-999)
        r["routine"] = dict(point=np.nan, lower=np.nan, upper=np.nan, kind="exact")
    q.update(score=np.nan, aa=np.nan, level=np.nan, minutes=-999)
    np.testing.assert_array_equal(before, pooled.build_features([q], changed))
    assert moment(boundary) + timedelta(hours=48) == cutoff_for(q["date"])


def test_pooled_queries_require_known_native_cohort_and_playing_side():
    with pytest.raises(ValueError, match="cohort"):
        pooled.build_features([query("2024-02-03T20:00:00Z", cohort=None)], [])
    q = query("2024-02-03T20:00:00Z")
    q["home"] = None
    with pytest.raises(ValueError, match="identity"):
        pooled.build_features([q], [])


def test_pooled_native_queries_keep_domestic_cases_and_report_only_unknown_extra_cohorts():
    date = "2024-01-01T12:00:00Z"
    r = observation(date)
    unknown = {**observation(date, cohort=None, source="euro"), "game": "e"}
    headers = {date: dict(date=date, home="a", away="b"), "e": dict(date=date, home="c", away="a")}
    queries, excluded = pooled.make_queries([r, unknown], headers)
    assert len(queries) == 1
    assert queries[0]["home"] is True
    assert excluded == {"unknownEuropeanCohort": 1}
    case = {**r, "aa": 0}
    np.testing.assert_array_equal(pooled.canonical_indices([case], queries, [r, unknown]), [0])
    with pytest.raises(ValueError, match="cohort"):
        pooled.make_queries([{**r, "cohort": None}], headers)
    with pytest.raises(ValueError, match="playing-side"):
        pooled.make_queries([{**r, "club": "wrong"}], headers)
    with pytest.raises(ValueError, match="labels"):
        pooled.canonical_indices([{**case, "score": 99}], queries, [r, unknown])
