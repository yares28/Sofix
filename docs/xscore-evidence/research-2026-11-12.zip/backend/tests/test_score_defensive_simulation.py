import copy

import numpy as np
import pytest

from app.research import score_defensive_residuals as defensive
from app.research import score_defensive_simulation as simulation


def test_class_draws_validate_probabilities_and_uniform_support():
    p = np.array([[0.25, 0.75], [0, 1]])
    np.testing.assert_equal(simulation.class_indices(p, np.array([0, 0.25, 0.999])), [[0, 1, 1], [1, 1, 1]])
    for u in (np.array([1.0]), np.array([np.nan]), np.array([-0.1])):
        with pytest.raises(ValueError, match="uniform"):
            simulation.class_indices(p, u)
    with pytest.raises(ValueError, match="probabilities"):
        simulation.class_indices(p * 0.5, np.array([0.5]))


def test_bank_excludes_unavailable_labels_and_preserves_minute_error_pair():
    rows = [
        {"date": "2023-12-01T20:00:00Z", "pos": "DEF", "level": 35, "aa": 7, "minutes": 60},
        {"date": "2024-01-06T20:00:00Z", "pos": "DEF", "level": 35, "aa": 999, "minutes": 90},
    ]
    parts = (np.array([35.0]), np.ones((2, 1)), {q: np.full((2, 1), 5.0) for q in (0.35, 0.5, 0.65)})
    context = {"lam": np.array([0.0, 0]), "cs": np.ones(2), "actual": np.array([10.0, 999])}
    spec = {"goals": "lambda", "location": "mean"}
    a = simulation.make_bank(rows, parts, context, np.array([80.0, 80]), "2024-01-07T20:00:00Z", None, spec)
    np.testing.assert_equal(a["global"], [[2, -20]])
    changed = copy.deepcopy(rows)
    changed[1]["aa"] = np.nan
    context["actual"][1] = np.nan
    b = simulation.make_bank(changed, parts, context, np.array([80.0, 80]), "2024-01-07T20:00:00Z", None, spec)
    np.testing.assert_equal(a["global"], b["global"])
    assert a["cases"] == 1


def test_simulator_keeps_full_coverage_missing_fallback_and_native_positive_floor():
    pos = np.array(["DEF", "MID", "GK", "FWD", "DEF"])
    classes = np.array([35.0, 60])
    p = np.array([[1, 0], [0, 1], [1, 0], [1, 0], [1, 0]], dtype=float)
    q = np.array([[5, -100], [5, -100], [5, -100], [5, -100], [5, -100]], dtype=float)
    parts = classes, p, {z: q.copy() for z in (0.35, 0.5, 0.65)}
    control = np.array([42, 43, 44, 45, 46.0])
    bank = {"global": np.array([[0, 0.0]]), "positions": {}, "levels": {}}
    spec = defensive.PARAMETERS["uniform_lambda_mean_spread0.75"]
    banks = {("uniform", "lambda", "mean"): bank}
    settings = {"test": spec}
    prediction, stats = simulation.simulate(
        parts,
        pos,
        np.array([0, 0, 0, 0, np.nan]),
        np.ones(5),
        np.full(5, 90.0),
        control,
        banks,
        {"uniform": None},
        settings,
        32,
    )
    np.testing.assert_equal(prediction["test"], [40, 60, 44, 45, 46])
    assert stats["cases"] == 5 and stats["simulated"] == 2 and stats["fallbackMissingFootball"] == 1
    with pytest.raises(ValueError, match="power of two"):
        simulation.simulate(
            parts, pos, np.zeros(5), np.ones(5), np.full(5, 90.0), control, banks, {"uniform": None}, settings, 33
        )


def test_native_observation_price_and_home_away_identity():
    features = ["match_lam_h", "match_lam_a", "match_cs_h", "match_cs_a"]
    row = {"game": "g", "player": "p", "date": "2024-01-01", "minutes": 90, "pos": "DEF", "x": [2, 1, 0.4, 0.2]}
    game = {
        "id": "g",
        "date": row["date"],
        "home": {"slug": "h"},
        "away": {"slug": "a"},
        "homeGoals": 2,
        "awayGoals": 0,
        "players": {"p": {"team": "h", "pos": "DEF", "mins": 90, "ver": 7, "stats": {"clean_sheet_60": [1, 10]}}},
    }
    observed = simulation.observations([row], [game], features)
    assert observed["lam"][0] == 1 and observed["cs"][0] == 0.4 and observed["actual"][0] == 10
    game["players"]["p"]["stats"]["clean_sheet_60"][1] = 0
    with pytest.raises(ValueError, match="price"):
        simulation.observations([row], [game], features)
