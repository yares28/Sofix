"""Testing only: learn discrete forecast actions with the native seven-point reward."""

from __future__ import annotations

import numpy as np

from app.research.score_windows import window_centres

CENTRES = np.arange(0, 100.01, 0.5)
PARAMETERS = {
    f"width{width}_l2{ridge}_aux{aux}": {"width": width, "ridge": ridge, "aux": aux}
    for width in (32, 96)
    for ridge in (0.001, 0.01)
    for aux in (0, 0.1)
}


class Normaliser:
    def fit(self, x):
        x = np.asarray(x, dtype=float)
        if x.ndim != 2 or not len(x):
            raise ValueError("Nonempty fit input matrix required")
        valid = np.isfinite(x)
        count = valid.sum(axis=0)
        self.known_ = count > 0
        self.mean_ = np.divide(np.where(valid, x, 0).sum(axis=0), count, out=np.zeros(x.shape[1]), where=count > 0)
        self.scale_ = np.sqrt(
            np.divide(
                np.where(valid, (x - self.mean_) ** 2, 0).sum(axis=0), count, out=np.zeros(x.shape[1]), where=count > 0
            )
        )
        self.scale_[self.scale_ < 1e-8] = 1
        return self

    def transform(self, x):
        x = np.asarray(x, dtype=float)
        if x.ndim != 2 or x.shape[1] != len(self.mean_):
            raise ValueError("Forecast input dimensions differ")
        valid = np.isfinite(x)
        filled = np.where(valid, x, self.mean_)
        values = np.clip((filled - self.mean_) / self.scale_, -8, 8)
        values[:, ~self.known_] = 0
        missing = (~valid).astype(float)
        missing[:, ~self.known_] = 0
        return np.column_stack((values, missing)).astype(np.float32)


def targets(scores):
    scores = np.asarray(scores, dtype=float)
    if scores.ndim != 1 or not np.isfinite(scores).all() or ((scores < 0) | (scores > 100)).any():
        raise ValueError("Known score labels in0to100 required")
    valid = (np.abs(scores[:, None] - CENTRES) <= 7).astype(float)
    exact = np.zeros_like(valid)
    location = scores * 2
    low = np.floor(location).astype(int)
    high = np.minimum(low + 1, len(CENTRES) - 1)
    ratio = location - low
    exact[np.arange(len(scores)), low] += 1 - ratio
    exact[np.arange(len(scores)), high] += ratio
    return valid, exact


def probabilities(x, weights):
    a, b, c, d = weights
    hidden = np.tanh(x @ a + b)
    logits = hidden @ c + d
    logits -= logits.max(axis=1, keepdims=True)
    probability = np.exp(logits)
    probability /= probability.sum(axis=1, keepdims=True)
    return hidden, probability


def loss_gradient(x, valid, exact, weights, ridge, auxiliary):
    hidden, p = probabilities(x, weights)
    mass = np.maximum((p * valid).sum(axis=1, keepdims=True), 1e-30)
    loss = -np.log(mass).mean() - auxiliary * (exact * np.log(np.maximum(p, 1e-30))).sum(axis=1).mean()
    delta = (p - p * valid / mass + auxiliary * (p - exact)) / len(x)
    a, _, c, _ = weights
    upstream = (delta @ c.T) * (1 - hidden**2)
    gradients = [x.T @ upstream + ridge * a, upstream.sum(axis=0), hidden.T @ delta + ridge * c, delta.sum(axis=0)]
    loss += 0.5 * ridge * ((a**2).sum() + (c**2).sum())
    return float(loss), gradients


class ActionNetwork:
    def __init__(self, width, ridge, auxiliary, epochs=80, batch=256, seed=20261104):
        self.width, self.ridge, self.auxiliary = width, ridge, auxiliary
        self.epochs, self.batch, self.seed = epochs, batch, seed

    def fit(self, raw, scores):
        if self.epochs <= 0 or self.batch <= 0:
            raise ValueError("Positive training epochs and batch required")
        self.normaliser_ = Normaliser().fit(raw)
        x = self.normaliser_.transform(raw)
        valid, exact = [value.astype(np.float32) for value in targets(scores)]
        if len(x) != len(valid):
            raise ValueError("Training cases and action labels differ")
        rng = np.random.default_rng(self.seed)
        self.weights_ = [
            rng.normal(0, 1 / np.sqrt(x.shape[1]), (x.shape[1], self.width)).astype(np.float32),
            np.zeros(self.width, dtype=np.float32),
            rng.normal(0, 0.01, (self.width, len(CENTRES))).astype(np.float32),
            np.zeros(len(CENTRES), dtype=np.float32),
        ]
        means = [np.zeros_like(w) for w in self.weights_]
        squares = [np.zeros_like(w) for w in self.weights_]
        step, history = 0, []
        for epoch in range(self.epochs):
            order = rng.permutation(len(x))
            total = 0.0
            for begin in range(0, len(x), self.batch):
                at = order[begin : begin + self.batch]
                loss, gradients = loss_gradient(x[at], valid[at], exact[at], self.weights_, self.ridge, self.auxiliary)
                if not np.isfinite(loss) or any(not np.isfinite(g).all() for g in gradients):
                    raise ValueError("Action network training became nonfinite")
                step += 1
                for j, gradient in enumerate(gradients):
                    means[j] = 0.9 * means[j] + 0.1 * gradient
                    squares[j] = 0.999 * squares[j] + 0.001 * gradient**2
                    self.weights_[j] -= (
                        0.001 * (means[j] / (1 - 0.9**step)) / (np.sqrt(squares[j] / (1 - 0.999**step)) + 1e-8)
                    )
                total += loss * len(at)
            history.append(total / len(x))
            if (epoch + 1) % 40 == 0:
                print(f"ACTION_EPOCH {epoch + 1}/{self.epochs} loss{history[-1]:.6f}", flush=True)
        self.statistics_ = {
            "epochs": self.epochs,
            "fitRows": len(x),
            "rawFeatures": raw.shape[1],
            "normalisedFeatures": x.shape[1],
            "width": self.width,
            "ridge": self.ridge,
            "auxiliary": self.auxiliary,
            "lossFirst": history[0],
            "lossLast": history[-1],
            "lossLastTenMean": float(np.mean(history[-10:])),
            "steps": step,
        }
        return self

    def predict_mass(self, raw):
        result = probabilities(self.normaliser_.transform(raw), self.weights_)[1]
        if not np.isfinite(result).all() or not np.allclose(result.sum(axis=1), 1, atol=1e-6):
            raise ValueError("Invalid action forecast probability or lost case")
        return result

    def predict(self, raw):
        return window_centres(self.predict_mass(raw), CENTRES)
