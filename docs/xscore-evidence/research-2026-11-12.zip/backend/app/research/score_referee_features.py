"""Testing-only strictly past official referee-name-group foul and duel style."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

NAMES = [
    "ref_current_known",
    "ref_history_selected_games",
    "ref_history_qualified_games",
    "ref_history_age_days",
    "ref_fouls90",
    "ref_was_fouled90",
    "ref_yellow90",
    "ref_red90",
    "ref_penalty_conceded90",
    "ref_defender_win_fraction",
    "ref_defender_duels90",
    "ref_defender_fouls_per_duel",
    "ref_own_opponent_foul_fraction",
]
EVENTS = ["fouls", "was_fouled", "yellow_card", "red_card", "penalty_conceded", "duel_won", "duel_lost"]


def words(value):
    return " ".join(
        re.findall("[a-z]+", unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower())
    )


def name_groups(labels):
    full, groups = {}, {}
    for label in sorted(set(labels)):
        if "," not in label:
            continue
        parts = label.split(",")
        if len(parts) != 2:
            raise ValueError("Unknown official legacy name order")
        family, given = map(words, parts)
        tokens = family.split()
        first_family = " ".join(tokens[:-1]) if len(tokens) > 1 else family
        group = given + " " + first_family
        groups[label] = group
        full[given + " " + family] = group
    for label in labels:
        if label not in groups:
            groups[label] = full.get(words(label), words(label))
    return groups


def native_style(game):
    clubs = {game[s]["slug"] for s in ["home", "away"]}
    starts = {c: 0 for c in clubs}
    totals = np.zeros(12)
    for p in game.get("players", {}).values():
        if p.get("played") is not True:
            continue
        club = p.get("team")
        minutes = p.get("mins")
        if (
            club not in clubs
            or p.get("pos") not in ["GK", "DEF", "MID", "FWD"]
            or p.get("ver") != 7
            or type(p.get("started")) is not bool
            or type(minutes) not in (int, float)
            or not np.isfinite(minutes)
            or minutes < 0
            or not isinstance(p.get("stats"), dict)
        ):
            return None
        starts[club] += int(p["started"])
        if p["pos"] == "GK":
            continue
        counts = []
        for event in EVENTS:
            item = p["stats"].get(event, [0, 0])
            if (
                not isinstance(item, (list, tuple))
                or len(item) != 2
                or type(item[0]) not in (int, float)
                or not np.isfinite(item[0])
                or item[0] < 0
                or item[0] != round(item[0])
            ):
                return None
            counts.append(float(item[0]))
        totals[:6] += np.r_[minutes, counts[:5]]
        if p["pos"] == "DEF":
            totals[6:10] += np.array([counts[5], counts[6], minutes, counts[0]])
        totals[10 if club == game["home"]["slug"] else 11] += counts[0]
    return totals if len(starts) == 2 and all(v == 11 for v in starts.values()) and totals[0] > 0 else None


def style_rates(total):
    result = np.full(9, np.nan)
    if total[0] > 0:
        result[:5] = total[1:6] * 90 / total[0]
    duels = total[6] + total[7]
    if duels > 0:
        result[5] = total[6] / duels
        result[7] = total[9] / duels
    if total[8] > 0:
        result[6] = duels * 90 / total[8]
    if total[10] + total[11] > 0:
        result[8] = (total[10] - total[11]) / (total[10] + total[11])
    return result


def feature_rows(rows, games, archive, feature_names):
    indexed = {g["id"]: g for g in games}
    if len(indexed) != len(games):
        raise ValueError("Duplicate native game")
    choices = {r["game"]: r for r in archive["fixtureChoices"]}
    labels = [r[k]["referee"] for r in choices.values() for k in ["prelock", "pregame"] if r[k] is not None]
    groups = name_groups(labels)
    histories = defaultdict(list)
    qualified_native = 0
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        appointment = choices[g["id"]]["pregame"]
        if appointment is None:
            continue
        at = moment(g["date"])
        if moment(appointment["availableUTC"]) >= at:
            raise ValueError("Historical appointment postdates past kickoff")
        style = native_style(g)
        qualified_native += style is not None
        histories[groups[appointment["referee"]]].append(dict(date=at, available=at + timedelta(hours=48), style=style))
    times = {r: [p["available"] for p in h] for r, h in histories.items()}
    home_index = feature_names.index("home")
    output = []
    cached = {}
    previous = None
    audit = dict(
        rows=len(rows),
        unknownCurrentRows=0,
        coldCurrentRows=0,
        qualifiedNativePregameGames=qualified_native,
        rawNameLabels=len(groups),
        publishedNameGroups=len(set(groups.values())),
        nameGroups=groups,
    )
    for row in rows:
        lock = cutoff_for(row["date"])
        if previous is not None and lock < previous:
            raise ValueError("Forecast rows not chronological")
        previous = lock
        if indexed[row["game"]]["date"] != row["date"]:
            raise ValueError("Forecast native date mismatch")
        current = choices[row["game"]]["prelock"]
        if current is None:
            output.append(np.r_[0, 0, 0, np.full(10, np.nan)])
            audit["unknownCurrentRows"] += 1
            continue
        if moment(current["availableUTC"]) >= lock:
            raise ValueError("Current referee source is not strictly prelock")
        group = groups[current["referee"]]
        identity = group, lock
        if identity not in cached:
            end = bisect_left(times.get(group, []), lock)
            history = [p for p in histories[group][:end] if lock - p["date"] <= timedelta(days=365)][-10:]
            qualified = [p for p in history if p["style"] is not None]
            total = sum((p["style"] for p in qualified), np.zeros(12))
            rates = style_rates(total) if qualified else np.full(9, np.nan)
            age = (lock - qualified[-1]["date"]).total_seconds() / 86400 if qualified else np.nan
            cached[identity] = np.r_[1, len(history), len(qualified), age, rates]
        value = cached[identity].copy()
        if not value[2]:
            audit["coldCurrentRows"] += 1
        value[-1] *= 1 if row["x"][home_index] > 0 else -1
        output.append(value)
    return np.asarray(output), NAMES.copy(), audit


def main():
    root = Path("data/raw/score-foundation")
    reports = Path("reports/experiments")
    source = json.loads((root / "cases.json").read_text())
    archive_path = reports / "laliga_score_referee_archive.json"
    archive = json.loads(archive_path.read_text())
    integrity_path = reports / "laliga_score_referee_archive.integrity.json"
    integrity = json.loads(integrity_path.read_text())
    if (
        integrity["implementationKey"] != archive["implementationKey"]
        or integrity["documents"] != 269
        or integrity["nativeFixtureChoices"] != 1238
        or not integrity["secondPDFEngineAllParsedRows"]
    ):
        raise ValueError("Completed entire official source audit required")
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    raw = native.read_bytes()
    if hashlib.sha256(raw).hexdigest() != archive["nativeSHA"]:
        raise ValueError("Native source changed")
    games = [json.loads(v) for v in raw.decode("utf-8").splitlines()]
    x, names, audit = feature_rows(source["rows"], games, archive, source["features"])
    if x.shape != (38850, 13):
        raise ValueError("Full forecast feature population changed")
    plan = reports / "laliga_score_referee_features.plan.json"
    key = hashlib.sha256(
        Path(__file__).read_bytes()
        + plan.read_bytes()
        + archive_path.read_bytes()
        + integrity_path.read_bytes()
        + source["key"].encode()
        + raw
    ).hexdigest()
    np.savez_compressed(root / "referee_features.npz", key=key, source_key=source["key"], x=x, names=np.array(names))
    report = dict(
        scope="Strictly past referee-name-group features, not a score accuracy result",
        featureKey=key,
        sourceKey=source["key"],
        archiveKey=archive["implementationKey"],
        nativeSHA=archive["nativeSHA"],
        names=names,
        matrixSHA=hashlib.sha256((root / "referee_features.npz").read_bytes()).hexdigest(),
        audit=audit,
        cohorts={},
        evidenceLimit="Published-name grouping is categorical, not independent person identity. Historical pregame assignment proxies actual officiating. Original captured publication receipt absent. Unknown inputs retained.",
    )
    for cohort in ["start", "bench"]:
        mask = np.array([r["cohort"] == cohort and r["date"] >= "2026-01-01" for r in source["rows"]])
        report["cohorts"][cohort] = dict(
            rows=int(mask.sum()), currentKnown=int(x[mask, 0].sum()), withQualifiedHistory=int((x[mask, 2] > 0).sum())
        )
    (reports / "laliga_score_referee_features.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(
        "REFEREE_FEATURES", json.dumps(dict(featureKey=key, rows=len(x), columns=len(names), cohorts=report["cohorts"]))
    )


if __name__ == "__main__":
    main()
