"""Local component replacement, with explicit hindsight and pre-lock branches."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import POSITIONS, cutoff_for, moment
from app.research.score_shared_error_recovery import NATIVE_SHA, compare, snapshots
from app.research.score_stats_run import paired_interval

EVENT_KEY = "c9221e0d402118e5b565a81380c7418103d11a067f2aa60f4724b4ef86d4301b"
POINTS = {"cleanSheet": [0], "conceded": [1], "cleanSheetAndConceded": [0, 1], "duels": [2], "combined": [0, 1, 2]}
FIELD_NAMES = ("clean_sheet_60", "goals_conceded", "duel_won", "duel_lost")
FORECAST_COMPONENTS = ("cleanSheet", "conceded", "duels")


def native_values(row, record):
    if (
        record["ver"] != 7
        or record["started"] != (row["cohort"] == "start")
        or record["pos"] != row["pos"]
        or record["mins"] != row["minutes"]
        or any(abs(record[k] - row[k]) > 1e-7 for k in ("aa", "level", "score"))
    ):
        raise ValueError("Native outcome identity differs")
    stats = record["stats"]
    if abs(sum(value[1] for value in stats.values()) - row["aa"]) > 1e-7:
        raise ValueError("Native all-around points do not add up")
    clean, conceded, won, lost = (stats.get(name, (0, 0)) for name in FIELD_NAMES)
    if clean[1] != (10 if row["pos"] == "DEF" else 0) * clean[0]:
        raise ValueError("Clean sheet scoring differs")
    if conceded[1] != {"GK": -5, "DEF": -4, "MID": -2, "FWD": 0}[row["pos"]] * conceded[0]:
        raise ValueError("Conceded scoring differs")
    if row["pos"] == "DEF" and (won[1] != 1.5 * won[0] or lost[1] != -2 * lost[0]):
        raise ValueError("Defender duel scoring differs")
    return [clean[1], conceded[1], won[1] + lost[1], won[0], lost[0]]


def history_for(rows, sides, points, times, locks):
    """Prepare dated reference means and independent prior match-side summaries."""
    games = defaultdict(list)
    for i, (club, opp) in enumerate(sides):
        games[times[i], rows[i]["game"], club, opp, rows[i]["pos"]].append(i)
    events = sorted(games.items())
    cursor = 0
    players = defaultdict(lambda: deque(maxlen=6))
    roles = defaultdict(lambda: deque(maxlen=120))
    clubs = defaultdict(lambda: deque(maxlen=12))
    opponents = defaultdict(lambda: deque(maxlen=12))
    result = np.zeros((len(rows), 18), dtype=float)
    for i in np.argsort(locks, kind="stable"):
        while cursor < len(events) and events[cursor][0][0] < locks[i]:
            (_, _, club, opp, pos), group = events[cursor]
            mean = points[group].mean(axis=0)
            roles[pos].append(mean)
            clubs[club, pos].append(mean)
            opponents[opp, pos].append(mean)
            for j in group:
                players[rows[j]["player"], pos].append(points[j])
            cursor += 1
        pos = rows[i]["pos"]
        club, opp = sides[i]
        history = roles[pos]
        pool = np.mean(history, axis=0) if history else np.zeros(points.shape[1])
        groups = (players[rows[i]["player"], pos], clubs[club, pos], opponents[opp, pos])
        for k, group in enumerate(groups):
            count = len(group)
            result[i, k * 6 : k * 6 + 5] = (np.sum(group, axis=0) + 5 * pool) / (count + 5) if count else pool
            result[i, k * 6 + 5] = count
    return result


def shift(base, delta):
    return np.clip(base + delta, 0, 100)


def diagnostics(y, base, delta, keep):
    full = shift(base, delta)
    half = shift(base, delta / 2)
    best = (np.abs(y - full) <= 7) | (np.abs(y - half) <= 7) | (np.abs(y - base) <= 7)
    can_recover = best & (np.abs(y - base) > 7) & keep
    return {
        "fixedFullShift": compare(y, base, full, keep),
        "fixedHalfShift": compare(y, base, half, keep),
        "rescuesWithPerfectMoveSelection": int(can_recover.sum()),
    }


def point_metrics(actual, reference, forecast):
    error = np.column_stack((actual - reference, actual - forecast))
    return {
        "n": len(actual),
        "maeReferenceAndNew": np.abs(error).mean(axis=0).tolist(),
        "rmseReferenceAndNew": np.sqrt((error**2).mean(axis=0)).tolist(),
        "biasReferenceAndNew": error.mean(axis=0).tolist(),
    }


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    read = lambda name: json.loads((args.out.parent / f"{name}.json").read_text())
    source = json.loads((args.cache / "cases.json").read_text())
    with np.load(args.cache / "event_intensity_features.npz") as stored:
        if str(stored["key"]) != EVENT_KEY or len(stored["x"]) != len(source["rows"]):
            raise ValueError("Pre-lock minute cache differs")
        predicted_minutes = stored["x"][:, stored["names"].tolist().index("event_expected_minutes")]
        if not np.isfinite(predicted_minutes).all() or ((predicted_minutes < 1) | (predicted_minutes > 90)).any():
            raise ValueError("Pre-lock minute support differs")
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Native archive differs")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    report = {
        "sourceKey": source["key"],
        "nativeSha": NATIVE_SHA,
        "scope": "Local test; reused historical outcomes",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        minutes = predicted_minutes[[r["cohort"] == cohort for r in source["rows"]]]
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        references = snapshots(args, source, rows, cohort, read)
        row_ids = {(r["game"], r["player"]): i for i, r in enumerate(rows)}
        if len(row_ids) != len(rows):
            raise ValueError("Duplicate fixture/player identity")
        labels, sides, x = [], [], []
        names = source["features"]
        for row in rows:
            game = games[row["game"]]
            person = game["players"][row["player"]]
            home, away = game["home"]["slug"], game["away"]["slug"]
            club = person["team"]
            if game["date"] != row["date"] or club not in (home, away):
                raise ValueError("Fixture or side differs")
            labels.append(native_values(row, person))
            sides.append((club, away if club == home else home))
            h, a = ("h", "a") if club == home else ("a", "h")
            x.append(
                [
                    row["x"][names.index(n)]
                    for n in (
                        "home",
                        f"match_lam_{h}",
                        f"match_lam_{a}",
                        f"match_cs_{h}",
                        f"match_cs_{a}",
                        f"{cohort}_history_count",
                    )
                ]
            )
        labels = np.array(labels, dtype=float)
        times = np.array([(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rows])
        locks = np.array([cutoff_for(r["date"]).timestamp() for r in rows])
        if (times <= locks).any():
            raise ValueError("Outcome availability must follow lock")
        history = history_for(rows, sides, labels, times, locks)
        position = np.array([r["pos"] for r in rows])
        features = np.column_stack((x, minutes, history, *[position == p for p in POSITIONS])).astype(float)
        usable = [position == "DEF", position != "FWD", position != "GK"]
        tests = {key: {} for key in ("cleanSheetAndConceded", "duels", "combined")}
        audits = {}
        estimates = {}
        for phase, (subset, base, *_unused) in references.items():
            target = np.array([row_ids[r["game"], r["player"]] for r in subset])
            fit = times < locks[target].min()
            if fit[target].any():
                raise ValueError("Fit overlaps phase")
            y = np.array([r["score"] for r in subset])
            neutral = np.array([r["level"] == 35 for r in subset])
            defend = position[target] == "DEF"
            all_cases = np.ones(len(y), dtype=bool)
            reference_points = history[target, :3]
            if phase == "later2026":
                active = [key for key in tests if all(p["net"] > 0 for p in tests[key].values())]
                args.out.with_suffix(f".{cohort}.selection.json").write_text(
                    json.dumps({"passing": active, "tests": tests}, indent=2)
                )
            else:
                active = list(tests)
            if active:
                predicted = reference_points.copy()
                estimates[phase] = {}
                for j, eligible in enumerate(usable):
                    model = HistGradientBoostingRegressor(
                        max_iter=70, max_leaf_nodes=7, min_samples_leaf=80, l2_regularization=10, early_stopping=False
                    )
                    train = fit & eligible
                    keep = eligible[target]
                    model.fit(features[train], labels[train, j])
                    predicted[keep, j] = model.predict(features[target[keep]])
                    estimates[phase][FORECAST_COMPONENTS[j]] = point_metrics(
                        labels[target[keep], j], reference_points[keep, j], predicted[keep, j]
                    )
                for key in active:
                    cols = POINTS[key]
                    forecast = shift(base, (predicted[:, cols] - reference_points[:, cols]).sum(axis=1))
                    tests[key][phase] = compare(y, base, forecast, all_cases)
                    tests[key][phase]["neutral"] = compare(y, base, forecast, neutral)
                    tests[key][phase]["weekGain95"] = paired_interval(y, forecast, base, [r["week"] for r in subset])
            actual = labels[target]
            delta = {key: (actual[:, cols] - reference_points[:, cols]).sum(axis=1) for key, cols in POINTS.items()}
            won, lost = actual[:, 3:5].T
            ref_won, ref_lost = history[target, 3:5].T
            volume, ref_volume = won + lost, ref_won + ref_lost
            fraction = np.divide(ref_won, ref_volume, out=np.full_like(ref_won, 0.5), where=ref_volume > 0)
            volume_effect = (3.5 * fraction - 2) * (volume - ref_volume)
            win_effect = 3.5 * (won - fraction * volume)
            np.testing.assert_allclose((volume_effect + win_effect)[defend], delta["duels"][defend], rtol=0, atol=1e-8)
            audits[phase] = {
                "all": {key: diagnostics(y, base, d, all_cases) for key, d in delta.items()},
                "neutral": {key: diagnostics(y, base, d, neutral) for key, d in delta.items()},
                "neutralDefenders": {key: diagnostics(y, base, d, neutral & defend) for key, d in delta.items()},
                "defenderDuelTerms": {
                    key: diagnostics(y, base, d, neutral & defend)
                    for key, d in {"volumeOnly": volume_effect, "winsAtActualVolume": win_effect}.items()
                },
            }
            print(cohort, phase, "eligibleForecasts", active, "earlierFits", int(fit.sum()), flush=True)
        report["cohorts"][cohort] = {"prelock": tests, "prelockComponentErrors": estimates, "hindsight": audits}
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_component_replacement.json"))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
