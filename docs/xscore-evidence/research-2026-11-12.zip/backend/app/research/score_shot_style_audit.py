"""Independent raw shot profiles, all46 chronological features, future mutation."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
from bisect import bisect_left
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta
from functools import cache
from pathlib import Path

import numpy as np

from app.research import score_shot_style_features as study
from app.research.score_search import cutoff_for, moment


def independent_profile(events, known):
    if not known:
        return dict(known=False, attempts=None, nonpen=None, body=None, zones=None, unknownBody=None, unknownZone=None)
    body, zones, total, unknown_body, unknown_zone = [0, 0, 0], [0, 0], 0, 0, 0
    for e in events:
        if e.get("sit") == "Penalty":
            continue
        total += 1
        if e.get("body") in ("Header", "Left Foot", "Right Foot"):
            body[("Header", "Left Foot", "Right Foot").index(e["body"])] += 1
        else:
            unknown_body += 1
        if all(type(e.get(k)) in (int, float) and math.isfinite(e[k]) and 0 < e[k] < 100 for k in ("x", "y")):
            zone = 0 if e["x"] >= 83 and 21 <= e["y"] <= 79 else 1
            zones[zone] += 1
        else:
            unknown_zone += 1
    return dict(
        known=True,
        attempts=len(events),
        nonpen=total,
        body=body,
        zones=zones,
        unknownBody=unknown_body,
        unknownZone=unknown_zone,
    )


def raw_profiles(repo, games, parent_shots, parent_people, qualified):
    tokenize = lambda text: tuple(re.findall("[a-z]+", (text or "").lower()))
    source_people = {(r["game"], r["player"]): r for r in parent_people}
    qualified_people = {(r["game"], r["player"]): r for r in qualified["players"]}
    by_game = defaultdict(list)
    for r in parent_shots["players"]:
        by_game[r["game"]].append(r)
    side_output, player_output, seen = {}, {}, set()
    for r in parent_shots["sides"]:
        game_id = r["game"]
        if game_id in seen:
            continue
        raw = (repo / r["sourcePath"]).read_bytes().replace(b"\r\n", b"\n")
        if hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() != r["sourceBlob"]:
            raise ValueError("Raw source shot blob changed")
        detail = json.loads(raw.decode().partition("=")[2].strip().removesuffix(";"))
        game = games[game_id]
        lookup = {}
        for side in ("home", "away"):
            club = game[side]["slug"]
            passes = detail.get("passes")
            own_passes = [e for e in passes or [] if e.get("team") == side]
            known = (
                isinstance(passes, list)
                and bool(own_passes)
                and all(type(e.get("ok")) is bool and type(e.get("cross")) is bool for e in own_passes)
                and isinstance(detail.get("shots"), list)
            )
            own_shots = [e for e in detail.get("shots") or [] if e.get("team") == side]
            cached = next(a for a in parent_shots["sides"] if a["game"] == game_id and a["club"] == club)
            if cached["shots"] != own_shots or cached["date"] != game["date"]:
                raise ValueError("Source shot lists/canonical date differ")
            profile = independent_profile(own_shots, known)
            side_output[game_id, club] = dict(
                game=game_id,
                date=game["date"],
                club=club,
                opponent=game["away" if side == "home" else "home"]["slug"],
                profile=profile,
            )
            lookup[club] = (own_shots, known)
        for r in by_game[game_id]:
            key = game_id, r["player"]
            parent = source_people[key]
            person = game["players"][r["player"]]
            if (
                parent["geometrySource"]["player"] != r["sourcePlayer"]
                or r["minutes"] != person["mins"]
                or r["club"] != person["team"]
                or r["cohort"] != ("start" if person["started"] else "bench")
            ):
                raise ValueError("Native/source player attribution differs")
            own, side_known = lookup[r["club"]]
            actor_known = r["sourcePlayer"] is not None and isinstance(detail.get("shots"), list)
            events = (
                [e for e in own if tokenize(e.get("player")) == tokenize(r["sourcePlayer"])] if actor_known else None
            )
            previous_rate = parent["values"].get("chance_shots90")
            previous_count = previous_rate * person["mins"] / 90 if previous_rate is not None else None
            reasons = []
            if not actor_known:
                reasons.append("actor_or_stream_unavailable")
            if events is None or previous_count is None or abs(len(events) - previous_count) >= 1e-8:
                reasons.append("previously_verified_actor_count_unavailable_or_differs")
            for stat, flag in (("goals", "goal"), ("ontarget_scoring_att", "onTarget")):
                count = person.get("stats", {}).get(stat, [None])[0]
                source_count = (
                    sum(e[flag] for e in events)
                    if events is not None and all(type(e.get(flag)) is bool for e in events)
                    else None
                )
                if count is not None and source_count is not None and count > source_count:
                    reasons.append("source_below_native_" + stat)
            if reasons != r["reasons"] or r["known"] != (not reasons):
                raise ValueError("Independent parent actor qualification differs")
            expected = independent_profile(events, actor_known and not reasons and side_known)
            actual = qualified_people[key]
            if actual["profile"] != expected:
                raise ValueError("Independent qualified player shot profile differs")
            if any(actual[k] != r[k] for k in ("game", "date", "player", "club", "cohort", "minutes", "sourcePlayer")):
                raise ValueError("Qualified player identities changed")
            player_output[key] = actual
        seen.add(game_id)
    for actual in qualified["sides"]:
        if actual != side_output[actual["game"], actual["club"]]:
            raise ValueError("Independent raw qualified side profile differs")
    if len(side_output) != 2436 or len(player_output) != 34871:
        raise ValueError("Independent source population differs")
    return side_output, player_output


def sum_profiles(records):
    records = [r for r in records if r is not None and r["profile"]["known"]]
    total = sum(r["profile"]["nonpen"] for r in records)
    body = [sum(r["profile"]["body"][j] for r in records) for j in range(3)]
    zones = [sum(r["profile"]["zones"][j] for r in records) for j in range(2)]
    fraction = lambda count: count / total if total else np.nan
    return dict(
        records=records,
        total=total,
        body=body,
        zones=zones,
        bf=[fraction(v) for v in body],
        zf=[fraction(v) for v in zones],
        ub=total - sum(body),
        uz=total - sum(zones),
    )


def relative_lift(player, count, reference):
    if (
        not all(math.isfinite(v) for v in (*player, *reference))
        or any(v <= 0 for v in reference)
        or sum(count) <= 0
        or abs(sum(player) - 1) > 1e-8
    ):
        return np.nan
    return math.fsum(
        player[j] * (count[j] + 10 * reference[j]) / (sum(count) + 10) / reference[j] for j in range(len(player))
    )


def reconstruct(rows, games, sides, players):
    people, clubs = defaultdict(list), defaultdict(list)
    for r in rows:
        people[r["player"], r["cohort"]].append(r)
    for g in games.values():
        clubs[g["home"]["slug"]].append(g)
        clubs[g["away"]["slug"]].append(g)
    for histories in (people, clubs):
        for rs in histories.values():
            rs.sort(key=lambda r: moment(r["date"]))
    player_times = {k: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for k, rs in people.items()}
    club_times = {k: [(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rs] for k, rs in clubs.items()}

    def select(records, times, lock):
        end = bisect_left(times, lock.timestamp())
        return [r for r in records[:end] if moment(r["date"]) >= lock - timedelta(days=365)][-10:]

    @cache
    def allowed(team, lock):
        past = select(clubs.get(team, []), club_times.get(team, []), lock)
        profiles = []
        for g in past:
            other = g["away"]["slug"] if g["home"]["slug"] == team else g["home"]["slug"]
            profiles.append(sides.get((g["id"], other)))
        return past, sum_profiles(profiles)

    @cache
    def league(lock):
        a = sum_profiles(
            [
                r
                for r in sides.values()
                if moment(r["date"]) + timedelta(hours=48) < lock and moment(r["date"]) >= lock - timedelta(days=365)
            ]
        )
        return (
            [v / sum(a["body"]) for v in a["body"]] if sum(a["body"]) else [np.nan] * 3,
            [v / sum(a["zones"]) for v in a["zones"]] if sum(a["zones"]) else [np.nan] * 2,
        )

    result = np.full((len(rows), 46), np.nan)
    for i, r in enumerate(rows):
        lock, key = cutoff_for(r["date"]), (r["player"], r["cohort"])
        history = select(people.get(key, []), player_times.get(key, []), lock)
        a = sum_profiles([players.get((h["game"], h["player"])) for h in history])
        known = a["records"]
        total, minutes = a["total"], sum(h["minutes"] for h in known)
        past_goal, past_assist, past_ga, native_minutes = 0, 0, 0, 0
        for h in history:
            p = games[h["game"]]["players"][h["player"]]
            goals = p["stats"].get("goals", [0, 0])[0]
            assists = p["stats"].get("goal_assist", [0, 0])[0]
            past_goal += goals
            past_assist += assists
            past_ga += bool(goals > 0 or assists > 0)
            native_minutes += h["minutes"]
        ratio = lambda numerator, denominator=total: numerator / denominator if denominator else np.nan
        values = [
            len(history),
            len(known),
            minutes,
            (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan,
            90 * total / minutes if minutes else np.nan,
            ratio(sum(a["body"])),
            ratio(sum(a["zones"])),
            *a["bf"],
            *a["zf"],
            ratio(a["ub"]),
            ratio(a["uz"]),
            past_ga / len(history) if history else np.nan,
            90 * past_goal / native_minutes if native_minutes else np.nan,
            90 * past_assist / native_minutes if native_minutes else np.nan,
            len(known) / len(history) if history else np.nan,
            sum(h["profile"]["attempts"] for h in known),
            total / len(known) if known else np.nan,
        ]
        g = games[r["game"]]
        own = g["players"][r["player"]]["team"]
        team = g["away"]["slug"] if own == g["home"]["slug"] else g["home"]["slug"]
        fixtures, b = allowed(team, lock)
        known = b["records"]
        total = b["total"]
        ratio = lambda numerator, denominator=total: numerator / denominator if denominator else np.nan
        values.extend(
            [
                len(fixtures),
                len(known),
                (lock - moment(known[-1]["date"])).total_seconds() / 86400 if known else np.nan,
                total / len(known) if known else np.nan,
                ratio(sum(b["body"])),
                ratio(sum(b["zones"])),
                *b["bf"],
                *b["zf"],
                ratio(b["ub"]),
                ratio(b["uz"]),
                len(known) / len(fixtures) if fixtures else np.nan,
                sum(h["profile"]["attempts"] for h in known),
                sum(h["profile"]["nonpen"] > 0 for h in known) / len(known) if known else np.nan,
            ]
        )
        body_rate = [a["bf"][j] * b["body"][j] / len(known) for j in range(3)] if known else [np.nan] * 3
        zone_rate = [a["zf"][j] * b["zones"][j] / len(known) for j in range(2)] if known else [np.nan] * 2
        pb, pz = league(lock)
        body_lift = relative_lift(a["bf"], b["body"], pb) if a["ub"] == b["ub"] == 0 else np.nan
        zone_lift = relative_lift(a["zf"], b["zones"], pz) if a["uz"] == b["uz"] == 0 else np.nan
        values.extend(
            [*body_rate, *zone_rate, sum(body_rate), sum(zone_rate), body_lift, zone_lift, (body_lift + zone_lift) / 2]
        )
        result[i] = values
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--repo", type=Path, default=Path("data/raw/score-foundation/player-context-source"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_shot_style_features.json")
    )
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    native = args.games.read_bytes()
    shot = (args.cache / "shot_style_observations.json.gz").read_bytes()
    passes = (args.cache / "spatial_pass_pressure_observations.json.gz").read_bytes()
    source = json.loads((args.cache / "cases.json").read_text())
    key = hashlib.sha256(
        source["key"].encode()
        + native
        + shot
        + passes
        + Path(study.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if key != report["implementationKey"] or source["key"] != report["sourceKey"]:
        raise ValueError("Shot style source/core/plan changed")
    games = {g["id"]: g for g in (json.loads(line) for line in native.decode().splitlines() if line.strip())}
    for r in source["rows"]:
        g, p = games[r["game"]], games[r["game"]]["players"][r["player"]]
        if (
            g["date"] != r["date"]
            or p["ver"] != 7
            or not p["played"]
            or p["started"] != (r["cohort"] == "start")
            or p["mins"] != r["minutes"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Full native score-style population differs")
    archive = (args.cache / "shot_style_qualified_observations.json.gz").read_bytes()
    feature_path = args.cache / "shot_style_features.npz"
    if (
        hashlib.sha256(archive).hexdigest() != report["observationsSha256"]
        or hashlib.sha256(feature_path.read_bytes()).hexdigest() != report["featuresSha256"]
    ):
        raise ValueError("Shot style artifacts changed")
    qualified = json.loads(gzip.decompress(archive))
    parent_people = json.loads(
        gzip.decompress((args.cache / "pass_source_qualified_observations.json.gz").read_bytes())
    )["records"]
    sides, people = raw_profiles(args.repo, games, json.loads(gzip.decompress(shot)), parent_people, qualified)
    with np.load(feature_path) as f:
        x, names = f["x"], f["names"].tolist()
        if str(f["key"]) != report["featureKey"] or names != study.feature_names():
            raise ValueError("Feature identity/schema differs")
    print("SHOT_STYLE_RAW_AUDITED " + json.dumps(dict(sides=len(sides), players=len(people))), flush=True)
    rebuilt = reconstruct(source["rows"], games, sides, people)
    np.testing.assert_allclose(x, rebuilt, rtol=0, atol=1e-10, equal_nan=True)
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    changed_rows, changed_games, changed_sides, changed_players = deepcopy(
        (source["rows"], games, qualified["sides"], qualified["players"])
    )
    mutations = defaultdict(int)
    for kind, records in (("sideProfiles", changed_sides), ("playerProfiles", changed_players)):
        for r in records:
            if moment(r["date"]) + timedelta(hours=48) >= first:
                r["profile"] = dict(
                    known=True, attempts=999, nonpen=999, body=[999, 0, 0], zones=[999, 0], unknownBody=0, unknownZone=0
                )
                if "minutes" in r:
                    r["minutes"] = 1e6
                mutations[kind] += 1
    for r in changed_rows:
        if moment(r["date"]) + timedelta(hours=48) >= first:
            r.update(minutes=1e6, score=100, aa=99, level=80)
            mutations["nativeCases"] += 1
    for g in changed_games.values():
        if moment(g["date"]) + timedelta(hours=48) >= first:
            g["homeGoals"], g["awayGoals"], g["xi"] = 9, 9, None
            for p in g["players"].values():
                p.update(stats={"goals": [99, 0], "goal_assist": [99, 0]}, mins=1e6, score=100, aa=99, level=80)
    altered, altered_names = study.build_features(changed_rows, changed_games, changed_sides, changed_players)
    if altered_names != names:
        raise ValueError("Future mutation schema differs")
    np.testing.assert_array_equal(altered[indices], x[indices])
    output = dict(
        implementationKey=key,
        featureKey=report["featureKey"],
        nativeCasesVerified=len(source["rows"]),
        nativeRawSidesVerified=len(sides),
        nativeRawPlayerProfilesVerified=len(people),
        independentlyRecomputedRows=len(rebuilt),
        independentlyRecomputedColumns=46,
        actualFutureMutation=dict(
            firstLock=first.isoformat(), rows=len(indices), mutatedRecords=dict(mutations), all46columnsExact=True
        ),
        scope="Feature verification only, no formula accuracy claim",
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("SHOT_STYLE_FEATURES_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
