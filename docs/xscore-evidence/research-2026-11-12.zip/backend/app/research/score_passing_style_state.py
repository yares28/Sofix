"""Measure historical pass type while leading, level and trailing."""

import hashlib
import json

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_passing_state import Source
from app.research.score_substitution_clock import capture

STEM = "laliga_score_passing_style_state"
TYPES = ("completedForward", "completedOther", "chancePass", "incomplete")


def pass_categories(events, state):
    counts = np.zeros((4, 3), dtype=int)
    for p in events:
        minute = p["min"]
        if minute not in state:
            continue
        x, end, key = (p.get(field) for field in ("x", "ex", "key"))
        if type(key) is not bool or not all(type(v) in (int, float) and 0 <= v <= 100 for v in (x, end)):
            return {"passTypes": None}
        s = state[minute]
        counts[2, s] += key
        kind = 3 if not p["ok"] else 0 if end - x >= 15 else 1
        counts[kind, s] += 1
    return {"passTypes": counts.tolist()}


def paired(group):
    selected = [r for r in group if min(r["exposure"][:2]) >= 10]
    if not selected:
        return {"n": 0}
    exposure = np.array([r["exposure"] for r in selected])[:, None, :]
    rates = 90 * np.array([r["passTypes"] for r in selected])[:, :, :2] / exposure[:, :, :2]
    return {
        "n": len(selected),
        "trailingMinusLevelPer90": dict(zip(TYPES, (rates[:, :, 0] - rates[:, :, 1]).mean(axis=0), strict=True)),
    }


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    aliases = json.loads((ROOT / "player_names.json").read_bytes())
    source = Source(aliases, pass_categories)
    _, _, digest = capture(list(games.values()), aliases, observe=source.observe)
    previous_receipt = json.loads((REPORTS / "laliga_score_passing_state.source.json").read_bytes())
    previous_raw = (ROOT / "laliga_score_passing_state.json").read_bytes()
    assert digest == previous_receipt["archiveReadSHA"]
    assert hashlib.sha256(previous_raw).hexdigest() == previous_receipt["stateArchiveSHA"]
    assert [{k: v for k, v in r.items() if k != "passTypes"} for r in source.records] == json.loads(previous_raw)
    selected = [r for r in source.records if r["passTypes"] is not None]
    for r in selected:
        counts = np.array(r["passTypes"])
        assert np.array_equal(counts[0] + counts[1], r["completed"])
        g = games[r["game"]]
        home, away = (g[k]["slug"] for k in ("home", "away"))
        assert r["club"] in (home, away)
        r["opponent"] = away if r["club"] == home else home
    archive = ROOT / (STEM + ".json")
    archive.write_text(json.dumps(selected, separators=(",", ":")) + "\n")
    phases = {}
    for phase, (begin, end) in PHASES.items():
        phases[phase] = {
            role: paired([r for r in selected if r["cohort"] == role and begin <= r["date"] < end])
            for role in ("start", "bench")
        }
    result = dict(
        sourceSHA=previous_receipt["stateArchiveSHA"],
        archiveSHA=hashlib.sha256(archive.read_bytes()).hexdigest(),
        passingStyleAppearances=len(selected),
        unknownStyle=len(source.records) - len(selected),
        phases=phases,
        types=TYPES,
        laterEvaluated=False,
    )
    (REPORTS / (STEM + ".source.json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
