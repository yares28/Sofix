"""Test whether reported same-position absences predict conditional playing time."""

import hashlib
import json
from bisect import bisect_left
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path
from statistics import mean

import numpy as np

from app.research.score_absence_clock_pilot import NATIVE, NATIVE_SHA, ROOT
from app.research.score_search import cutoff_for, moment

REPORTS = Path("reports/experiments")
STEM = "laliga_score_absence_role_signal"
MAX_AGE = timedelta(days=365)
DELAY = timedelta(hours=48)


def historical_difference(missing, present):
    n = min(len(missing), len(present))
    if n < 2:
        return 0.0
    return (mean(missing) - mean(present)) * n / (8 + n)


def native_history(games):
    fixtures, all_player, player_club, played = {}, defaultdict(list), defaultdict(list), {}
    for g in sorted(games, key=lambda v: (v["date"], v["id"])):
        assert g["id"] not in fixtures
        fixtures[g["id"]] = g
        ready = moment(g["date"]) + DELAY
        played[g["id"]] = {p for p, v in g["players"].items() if v.get("played") is True}
        for player in sorted(played[g["id"]]):
            p = g["players"][player]
            if p.get("ver") != 7:
                continue
            club = p["team"]
            obs = dict(
                game=g["id"],
                ready=ready,
                club=club,
                position=p["pos"],
                cohort="start" if p["started"] else "bench",
                minutes=float(p["mins"]),
            )
            all_player[player].append(obs)
            player_club[player, club].append(obs)
    clocks = {p: [r["ready"] for r in h] for p, h in all_player.items()}
    first = {key: h[0]["ready"] for key, h in player_club.items()}
    return fixtures, all_player, clocks, first, played


def forecast(rows, games, features, claims):
    fixtures, all_player, clocks, first, played = native_history(games)
    home_col = features.index("home")
    cold_col = {c: features.index(c + "_3_minutes") for c in ("start", "bench")}
    vectors, proofs, exclusions = [], [], Counter()
    for r in rows:
        g = fixtures[r["game"]]
        assert r["date"] == g["date"]
        home = r["x"][home_col]
        assert home in (0, 1)
        club = g["home" if home else "away"]["slug"]
        lock, player = cutoff_for(r["date"]), r["player"]
        own = all_player.get(player, [])
        known = own[: bisect_left(clocks.get(player, []), lock)]
        part = [
            v
            for v in known
            if v["club"] == club
            and v["position"] == r["pos"]
            and v["cohort"] == r["cohort"]
            and lock - (v["ready"] - DELAY) <= MAX_AGE
        ][-30:]
        baseline = float(np.clip(mean([v["minutes"] for v in part]) if part else r["x"][cold_col[r["cohort"]]], 0, 100))
        candidates = claims.get((r["game"], club), {})
        if player in candidates:
            exclusions["namedSubject"] += 1
            candidates = {}
        same_position = []
        for name, prior in candidates.items():
            if prior < 15:
                continue
            history = all_player.get(name, [])
            last = bisect_left(clocks.get(name, []), lock) - 1
            if last < 0 or history[last]["club"] != club:
                exclusions["otherOrUnknownLatestClubCandidates"] += 1
                continue
            if history[last]["position"] == r["pos"]:
                same_position.append((-prior, name))
        proposed, support = baseline, 0
        if same_position:
            prior, peer = min(same_position)
            groups = ([], [])
            for obs in part:
                old_lock = cutoff_for(fixtures[obs["game"]]["date"])
                if first[peer, club] >= old_lock:
                    continue
                groups[peer in played[obs["game"]]].append((obs["game"], obs["minutes"]))
            support = min(map(len, groups))
            missing, present = [[v for _, v in group] for group in groups]
            delta = historical_difference(missing, present)
            proposed = float(np.clip(baseline + delta, 0, 100))
            if proposed != baseline:
                proofs.append(
                    dict(
                        game=r["game"],
                        player=player,
                        cohort=r["cohort"],
                        club=club,
                        peer=peer,
                        peerProjectedPriorMinutes=-prior,
                        missing=groups[0],
                        present=groups[1],
                        baseline=baseline,
                        proposed=proposed,
                    )
                )
        vectors.append((baseline, proposed, support))
    return np.array(vectors), proofs, dict(exclusions)


def evaluate(minutes, prediction, rows):
    results = {}
    for cohort in ("start", "bench"):
        selected = np.array([r["cohort"] == cohort for r in rows])
        a, b = prediction[selected, :2].T
        y = minutes[selected]
        assert np.isfinite(y).all()
        changed = a != b
        gain = np.abs(y - a) - np.abs(y - b)
        week = np.array([r["week"] for r, s in zip(rows, selected, strict=True) if s])
        _, group = np.unique(week, return_inverse=True)
        total = np.bincount(group, weights=gain)
        counts = np.bincount(group)
        draws = np.random.default_rng(20261111).integers(len(counts), size=(2000, len(counts)))
        interval = np.quantile(total[draws].sum(axis=1) / counts[draws].sum(axis=1), [0.025, 0.975]).tolist()
        results[cohort] = dict(
            cases=int(selected.sum()),
            changed=int(changed.sum()),
            baselineMAE=float(np.abs(y - a).mean()),
            proposedMAE=float(np.abs(y - b).mean()),
            pairedMAEGain=float(gain.mean()),
            weekly95Interval=interval,
            changedCasesMAEGain=float(gain[changed].mean()) if changed.any() else None,
            supportedForPromotion=bool(changed.sum() >= 100 and gain.mean() > 0 and interval[0] > 0),
        )
    return results


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [json.loads(v) for v in raw.splitlines()]
    source = json.loads((ROOT / "cases.json").read_text())
    claim_path = REPORTS / "laliga_score_absence_claims_pilot.json"
    claim_raw = claim_path.read_bytes()
    qualified = json.loads(claim_raw)
    assert qualified["nativeSHA"] == NATIVE_SHA and len(qualified["sourceClaims"]) == 728
    claims = {}
    for item in qualified["sourceClaims"]:
        if not "2025-07-01" <= item["date"] < "2026-01-01":
            continue
        key = item["game"], item["club"]
        assert key not in claims
        claims[key] = {
            r["player"]: r["projectedPriorMinutes"]
            for category in ("sancionados", "lesionados")
            for r in item["mentions"].get(category, [])
            if r["player"] is not None
        }
    all_rows = source["rows"]
    assert len(all_rows) == 38850
    target = np.array(["2025-07-01" <= r["date"] < "2026-01-01" for r in all_rows])
    assert target.sum() == 5383
    rows = [r for r, yes in zip(all_rows, target, strict=True) if yes]
    # Only autumn receives the intervention. Preserve paired baseline predictions
    # for every other case without evaluating any later outcomes.
    full_forecasts, proofs, exclusions = forecast(all_rows, games, source["features"], claims)
    assert np.array_equal(full_forecasts[~target, 0], full_forecasts[~target, 1])
    prediction = full_forecasts[target]
    key = hashlib.sha256(
        Path(__file__).read_bytes() + (REPORTS / f"{STEM}.plan.json").read_bytes() + claim_raw + source["key"].encode()
    ).hexdigest()
    counts = {}
    for cohort in ("start", "bench"):
        mask = np.array([r["cohort"] == cohort for r in rows])
        delta = np.abs(prediction[mask, 1] - prediction[mask, 0])
        moved = delta[delta > 0]
        counts[cohort] = dict(
            cases=int(mask.sum()),
            changed=len(moved),
            medianNonzeroMinutes=float(np.median(moved)) if len(moved) else None,
            maxMinutes=float(delta.max()),
        )
    first = min(cutoff_for(r["date"]) for r in rows)
    first_rows = [r for r in rows if cutoff_for(r["date"]) == first]
    mutated = [dict(g, players={}) if moment(g["date"]) + DELAY >= first else g for g in games]
    before, bp, _ = forecast(first_rows, games, source["features"], claims)
    after, ap, _ = forecast(first_rows, mutated, source["features"], claims)
    np.testing.assert_array_equal(before, after)
    assert bp == ap
    out = ROOT / f"{STEM}.npz"
    np.savez_compressed(out, key=key, autumn_target=target, full_forecasts=full_forecasts)
    report = dict(
        implementationKey=key,
        claimReportSHA=hashlib.sha256(claim_raw).hexdigest(),
        sourceKey=source["key"],
        fullCases=len(all_rows),
        autumnCases=len(rows),
        firstAutumnLockMutationCases=len(first_rows),
        laterOutcomesExamined=False,
        futureMutationForecastsExact=True,
        movement=counts,
        exclusions=exclusions,
        changes=proofs,
    )
    (REPORTS / f"{STEM}.forecasts.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {k: report[k] for k in ("fullCases", "autumnCases", "movement", "firstAutumnLockMutationCases")}, indent=2
        )
    )


if __name__ == "__main__":
    main()
