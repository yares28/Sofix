"""Testing only: durable fit snapshots for the frozen direct-window studies."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np


def learning_parameters(runner, setting, safe):
    depth, trees, penalty = runner.MODELS[setting]
    params = {
        "loss_function": "MultiLogloss",
        "iterations": trees,
        "depth": depth,
        "l2_leaf_reg": penalty,
        "learning_rate": 0.04,
        "random_seed": 20261104,
        "thread_count": 4,
        "task_type": "CPU",
        "border_count": 64,
        "max_ctr_complexity": 1,
    }
    if safe:
        params["allow_const_label"] = True
    return params


def snapshot_fit(
    runner, frame, cats, scores, mask, setting, path, key, execution_root, safe=False, keep_snapshot=False
):
    if path.exists():
        with np.load(path) as f:
            if str(f["key"]) != key or f["probability"].shape != (int(mask["target"].sum()), 101):
                raise ValueError("Existing frozen direct-window probability cache differs")
            return f["probability"]
    from catboost import CatBoostClassifier, Pool

    execution_root = execution_root.resolve()
    path_hash = hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:12]
    directory = (execution_root / key[:12] / path_hash).resolve()
    if not directory.is_relative_to(execution_root):
        raise ValueError("Research snapshot path escapes intended execution directory")
    directory.mkdir(parents=True, exist_ok=True)
    snapshot = directory / "fit.snapshot"
    if len(str(snapshot)) + 4 >= 240:
        raise ValueError("Use a shorter research execution root for native Windows snapshots")
    params = learning_parameters(runner, setting, safe)
    adapter_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mask_key = hashlib.sha256(np.packbits(mask["fit"]).tobytes() + np.packbits(mask["target"]).tobytes()).hexdigest()
    receipt_path = directory / "execution.json"
    receipt = {
        "scope": "Testing-only fit recovery, no formula change or accuracy claim",
        "parentKey": key,
        "adapterSha256": adapter_hash,
        "parentSourceSha256": hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),
        "learningParameters": params,
        "fitMaskKey": mask_key,
        "fitRows": int(mask["fit"].sum()),
        "forecastRows": int(mask["target"].sum()),
        "snapshotExistedAtStart": snapshot.exists(),
        "completedProbabilityCache": str(path.resolve()),
        "completed": False,
    }
    if receipt_path.exists():
        previous = json.loads(receipt_path.read_text())
        if any(
            previous[k] != receipt[k]
            for k in ("parentKey", "adapterSha256", "parentSourceSha256", "learningParameters", "fitMaskKey")
        ):
            raise ValueError("Snapshot execution provenance differs; cannot resume")
    receipt_path.write_text(json.dumps(receipt, indent=2))
    print(f"DIRECT_SNAPSHOT_FIT {path.stem} resumed{snapshot.exists()}", flush=True)
    model = CatBoostClassifier(**params, allow_writing_files=True, train_dir=str(directory), verbose=50)
    model.fit(
        Pool(frame.loc[mask["fit"]], label=runner.window_targets(scores[mask["fit"]]), cat_features=cats),
        save_snapshot=True,
        snapshot_file=str(snapshot),
        snapshot_interval=30,
    )
    probability = model.predict_proba(Pool(frame.loc[mask["target"]], cat_features=cats))
    if probability.shape != (int(mask["target"].sum()), 101) or not np.isfinite(probability).all():
        raise ValueError("Snapshot direct-window native output coverage differs")
    np.savez_compressed(path, key=key, probability=probability, execution_adapter_sha256=adapter_hash)
    receipt.update(
        completed=True,
        snapshotWritten=snapshot.exists(),
        savedProbabilitySha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    )
    receipt_path.write_text(json.dumps(receipt, indent=2))
    if not keep_snapshot and snapshot.exists():
        if not snapshot.resolve().is_relative_to(execution_root) or snapshot.name != "fit.snapshot":
            raise ValueError("Unexpected snapshot cleanup target")
        snapshot.unlink()
    return probability


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--runner", choices=("start", "bench"), required=True)
    parser.add_argument("--execution-root", type=Path, required=True)
    args, remaining = parser.parse_known_args()
    if args.runner == "start":
        from app.research import score_direct_windows as parent
    else:
        from app.research import score_direct_windows_bench_safe as parent

    def fitted(frame, cats, scores, mask, setting, path, key):
        return snapshot_fit(
            parent, frame, cats, scores, mask, setting, path, key, args.execution_root, safe=args.runner == "bench"
        )

    parent.fit_windows = fitted
    sys.argv = [parent.__file__, *remaining]
    parent.main()


if __name__ == "__main__":
    main()
