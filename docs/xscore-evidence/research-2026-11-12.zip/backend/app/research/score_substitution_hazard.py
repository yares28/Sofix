"""Compare time-varying substitution forecasts with and without score state."""

import hashlib
import json
from collections import defaultdict

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, POSITIONS, fit, metrics

STEM = "laliga_score_substitution_hazard"
MINUTES = np.arange(1, 91)
BAND = np.digitize(MINUTES, (46, 60, 75))
DIFFERENCES = np.arange(-15, 16)
STATE = np.sign(DIFFERENCES) + 1
DECAY_PRIOR = 1200


def counts(records, lock):
    position = defaultdict(lambda: np.zeros((2, 90)))
    role = defaultdict(lambda: np.zeros((2, 90)))
    individual = defaultdict(lambda: np.zeros((2, 90)))
    states = defaultdict(lambda: np.zeros((2, 4, 3)))
    matched = 0
    for r in records:
        if moment(r["date"]) + DELAY >= lock:
            continue
        matched += 1
        goals = r["goalsForClub"]
        known = ~np.isin(MINUTES, [m for m, _ in goals])
        state = np.sign(sum((delta * (m < MINUTES) for m, delta in goals), start=np.zeros(90, dtype=int))) + 1
        bucket = BAND * 3 + state
        for p in r["players"]:
            cohort = "start" if p["started"] else "bench"
            decision = p["off"] if p["started"] else p["on"]
            if p["position"] not in POSITIONS or (cohort == "bench" and decision is None):
                continue
            at_risk = known if decision is None else known & (decision >= MINUTES)
            event = at_risk & (decision == MINUTES) if decision is not None else np.zeros(90, dtype=bool)
            update = np.array([at_risk, event])
            key = cohort, p["position"]
            role[cohort] += update
            position[key] += update
            individual[(*key, r["club"], p["player"])] += update
            states[key] += np.array(
                [np.bincount(bucket[condition], minlength=12).reshape(4, 3) for condition in (at_risk, event)]
            )
    return position, role, individual, states, matched


def hazard_tables(rows, identities, group):
    position, role, individual, states, _ = group
    base, delta = [], []
    for r, club in zip(rows, identities, strict=True):
        key = r["cohort"], r["pos"]
        league_exposed, league_events = role[r["cohort"]]
        league_hazard = (league_events + 0.1) / (league_exposed + 50)
        exposed, events = position[key]
        position_hazard = (events + 100 * league_hazard) / (exposed + 100)
        own_exposed, own_events = individual[(*key, club, r["player"])]
        hazard = (own_events + 25 * position_hazard) / (own_exposed + 25)
        band_exposure, band_events = states[key]
        band_rate = (band_events.sum(axis=1) + 1) / (band_exposure.sum(axis=1) + 100)
        rate = (band_events + DECAY_PRIOR * band_rate[:, None]) / (band_exposure + DECAY_PRIOR)
        # Regularize rare states and preserve the pooled rate as the comparison.
        delta.append(np.log(rate / (1 - rate)) - np.log(band_rate[:, None] / (1 - band_rate[:, None])))
        base.append(hazard)
    return np.array(base), np.array(delta)


def step_goals(survival, weights, direction):
    propagated = survival * weights[:, :1]
    for n in range(1, weights.shape[1]):
        contribution = survival * weights[:, n : n + 1]
        if direction == 1:
            propagated[:, n:] += contribution[:, :-n]
            propagated[:, -1] += contribution[:, -n:].sum(axis=1)
        else:
            propagated[:, :-n] += contribution[:, n:]
            propagated[:, 0] += contribution[:, :n].sum(axis=1)
    return propagated


def goal_weights(rate):
    zero = np.exp(-rate)
    one = rate * zero
    two = rate * one / 2
    return np.column_stack((zero, one, two, np.maximum(0, 1 - zero - one - two)))


def decision_distributions(base, delta, own, opp):
    n = len(base)
    odds = base / (1 - base)
    ok = (own >= 0) & (own <= 8) & (opp >= 0) & (opp <= 8)
    weights_for = goal_weights(np.where(ok, own / 90, 0.0))
    weights_against = goal_weights(np.where(ok, opp / 90, 0.0))
    survival = np.zeros((n, len(DIFFERENCES)))
    survival[:, len(DIFFERENCES) // 2] = 1
    adjusted = np.exp(np.where(ok[:, None, None], delta, 0.0))
    static = np.empty((n, 90))
    stateful = np.empty((n, 90))
    static_remaining = np.ones(n)
    for minute in range(89):
        h = base[:, minute]
        static[:, minute] = static_remaining * h
        static_remaining -= static[:, minute]
        adjusted_odds = odds[:, minute, None] * adjusted[:, BAND[minute], STATE]
        chance = adjusted_odds / (1 + adjusted_odds)
        change = survival * chance
        stateful[:, minute] = change.sum(axis=1)
        survival = step_goals(step_goals(survival - change, weights_for, 1), weights_against, -1)
    static[:, -1] = static_remaining
    stateful[:, -1] = survival.sum(axis=1)
    stateful[~ok] = static[~ok]
    np.testing.assert_allclose(stateful.sum(axis=1), 1, atol=1e-10, rtol=0)
    return static, stateful


def summaries(distribution, cohort):
    start = cohort == "start"
    duration = MINUTES if start else MINUTES[::-1]
    median = duration[np.sum(np.cumsum(distribution, axis=1) < 0.5, axis=1)]
    short_or_long = duration <= 65 if start else duration >= 25
    return np.column_stack((distribution @ duration, median, distribution[:, short_or_long].sum(axis=1)))


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    case_data = json.loads((ROOT / "cases.json").read_bytes())
    rows = [r for r in case_data["rows"] if r["date"] < "2026-01-01"]
    archive = (ROOT / "laliga_score_substitution_clock.json").read_bytes()
    receipt = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    assert hashlib.sha256(archive).hexdigest() == receipt["qualifiedCacheSHA"] and receipt["nativeSHA"] == NATIVE_SHA
    records = json.loads(archive)
    features = np.array([r["x"] for r in rows])
    date = np.array([r["date"] for r in rows])
    roles = np.array([r["cohort"] for r in rows])
    y = np.array([r["aa"] for r in rows])
    minutes = np.array([r["minutes"] for r in rows])
    ready = np.array([moment(d) + DELAY for d in date])
    locks = np.array([cutoff_for(d) for d in date])
    identity = [games[r["game"]]["players"][r["player"]]["team"] for r in rows]
    is_home = np.array([club == games[r["game"]]["home"]["slug"] for r, club in zip(rows, identity, strict=True)])
    h, a = (features[:, case_data["features"].index(f"match_lam_{side}")] for side in ("h", "a"))
    own, opp = np.where(is_home, h, a), np.where(is_home, a, h)
    distributions = np.full((2, len(rows), 3), np.nan)
    periods = {}
    for phase, (begin, end) in {"warm": ("2023-11-01", "2024-01-01"), **PHASES}.items():
        selected = (date >= begin) & (date < end)
        first = locks[selected].min()
        group = counts(records, first)
        periods[phase] = {"sourceSides": group[-1]}
        for role in ("start", "bench"):
            test = selected & (roles == role)
            loc = np.flatnonzero(test)
            base, delta = hazard_tables([rows[i] for i in loc], [identity[i] for i in loc], group)
            predicted = decision_distributions(base, delta, own[test], opp[test])
            for j, value in enumerate(predicted):
                distributions[j, test] = summaries(value, role)
            if phase == "warm":
                continue
            train = (ready < first) & (roles == role) & np.isfinite(distributions[0, :, 0])
            assert np.isfinite(distributions[:, train | test]).all()
            historical_aa = features[:, case_data["features"].index(f"{role}_10_aa")]
            point_estimates = [
                fit(np.column_stack((features, d)), y - historical_aa, train, test) for d in distributions
            ]
            truth = minutes[test] <= 65 if role == "start" else minutes[test] >= 25
            periods[phase][role] = dict(
                train=int(train.sum()),
                minutesMAE=np.abs(distributions[:, test, 1] - minutes[test]).mean(axis=1).tolist(),
                eventBrier=((distributions[:, test, 2] - truth) ** 2).mean(axis=1).tolist(),
                routine=metrics(y[test] - historical_aa[test], *point_estimates),
                prematchRatesAvailable=int(((own[test] >= 0) & (opp[test] >= 0)).sum()),
            )
    gate = {}
    for role in ("start", "bench"):
        checked = [periods[p][role] for p in PHASES]
        n = sum(r["routine"]["n"] for r in checked)
        gains = np.array(
            [
                [
                    r["minutesMAE"][0] - r["minutesMAE"][1],
                    r["eventBrier"][0] - r["eventBrier"][1],
                    r["routine"]["mae"][0] - r["routine"]["mae"][1],
                    (r["routine"]["gained"] - r["routine"]["lost"]) / r["routine"]["n"],
                ]
                for r in checked
            ]
        )
        totals = np.average(gains, axis=0, weights=[r["routine"]["n"] for r in checked])
        kept = int(np.sum(np.all(gains >= 0, axis=1)))
        gate[role] = dict(
            n=n,
            minutesMAEGain=float(totals[0]),
            eventBrierGain=float(totals[1]),
            routineMAEGain=float(totals[2]),
            routineHitGain=sum(r["routine"]["gained"] - r["routine"]["lost"] for r in checked),
            phasesWithoutLoss=kept,
            passEarlier=bool((totals > 0).all() and kept >= 2),
        )
    report = dict(
        sourceSHA=receipt["qualifiedCacheSHA"],
        periods=periods,
        gate=gate,
        laterOutcomesEvaluated=False,
    )
    (REPORTS / (STEM + ".json")).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
