"""Research-only cross-player memory of completed ordinary-point forecast errors."""

from __future__ import annotations

import argparse
import hashlib
import json
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_stability as stability
from app.research.score_failure_review import summary
from app.research.score_matchups_run import bank_from
from app.research.score_search import cutoff_for, measure, moment

SIGNALS = ("own3", "own10", "opponent3", "opponent10", "combined10")


def records_from(rows, sides, classes, median):
    if np.shape(median) != (len(rows), len(classes)) or not np.isfinite(median).all():
        raise ValueError("Complete previously forecast conditional medians required")
    groups = defaultdict(list)
    unsupported = 0
    for i, row in enumerate(rows):
        if row["level"] not in classes:
            unsupported += 1
            continue
        club, opponent = sides[row["game"], row["player"]]
        column = int(np.flatnonzero(classes == row["level"])[0])
        groups[row["game"], row["date"], club, opponent, row["pos"], row["cohort"]].append(
            (float(row["aa"]), float(median[i, column]))
        )
    records = []
    for (game, date, club, opponent, pos, cohort), pairs in groups.items():
        actual, predicted = np.asarray(pairs).mean(axis=0)
        records.append(
            dict(
                game=game,
                available=(moment(date) + timedelta(hours=48)).timestamp(),
                club=club,
                opponent=opponent,
                pos=pos,
                cohort=cohort,
                residual=float(actual - predicted),
                actualAA=float(actual),
                predictedAA=float(predicted),
                members=len(pairs),
            )
        )
    return sorted(records, key=lambda r: (r["available"], r["game"], r["club"], r["pos"], r["cohort"])), {
        "knownPlayerErrors": len(rows) - unsupported,
        "unsupportedPastLevels": unsupported,
        "teamRoleRecords": len(records),
    }


def from_lists(own, opponent, pooled):
    baseline = float(np.mean([r["residual"] for r in pooled[-100:]])) if pooled else 0.0
    result = {"pooledCount": min(len(pooled), 100), "pooledMean": baseline}
    for name, values in (("own", own), ("opponent", opponent)):
        for size in (3, 10):
            recent = values[-size:]
            n = len(recent)
            result[f"{name}{size}Count"] = n
            result[f"{name}{size}"] = (
                n / (n + 5) * (float(np.mean([r["residual"] for r in recent])) - baseline) if n else 0.0
            )
    result["combined10"] = (result["own10"] + result["opponent10"]) / 2
    return result


def signal_for(records, club, opponent, pos, cohort, lock):
    eligible = sorted(
        (r for r in records if r["available"] < lock and r["pos"] == pos and r["cohort"] == cohort),
        key=lambda r: (r["available"], r["game"], r["club"], r["pos"], r["cohort"]),
    )
    return from_lists(
        [r for r in eligible if r["club"] == club], [r for r in eligible if r["opponent"] == opponent], eligible
    )


class Memory:
    def __init__(self, records):
        self.groups = defaultdict(list)
        for r in sorted(records, key=lambda r: (r["available"], r["game"], r["club"], r["pos"], r["cohort"])):
            for role, identity in (("own", r["club"]), ("opponent", r["opponent"]), ("pool", None)):
                self.groups[role, identity, r["pos"], r["cohort"]].append(r)
        self.times = {k: [r["available"] for r in values] for k, values in self.groups.items()}

    def query(self, club, opponent, pos, cohort, lock):
        values = []
        for role, identity, keep in (("own", club, 10), ("opponent", opponent, 10), ("pool", None, 100)):
            key = role, identity, pos, cohort
            n = bisect_left(self.times.get(key, []), lock)
            values.append(self.groups.get(key, [])[max(0, n - keep) : n])
        return from_lists(*values)


def shift_parts(parts, signal, selected, weight):
    delta = np.where(selected, np.clip(np.asarray(signal) * weight, -12, 12), 0)
    if not np.isfinite(delta).all():
        raise ValueError("Finite historical corrections required")
    return {q: values + delta[:, None] for q, values in parts.items()}


def association(signal, residual):
    keep = np.isfinite(signal) & np.isfinite(residual)
    x, y = np.asarray(signal)[keep], np.asarray(residual)[keep]
    if not len(x):
        return {"n": 0}
    low, high = np.quantile(x, [0.2, 0.8])
    lo, hi = y[x <= low], y[x >= high]
    return {
        "n": len(x),
        "correlation": float(np.corrcoef(x, y)[0, 1]) if x.std() > 1e-10 and y.std() > 1e-10 else None,
        "bottomFifthMeanNextError": float(lo.mean()),
        "topFifthMeanNextError": float(hi.mean()),
        "topMinusBottom": float(hi.mean() - lo.mean()),
        "signalSD": float(x.std()),
    }


def frozen_choice(records):
    best = max(
        records,
        key=lambda r: (
            min(r["gains"]),
            np.average(r["gains"], weights=r["counts"]),
            -np.average(r["maes"], weights=r["counts"]),
        ),
    )
    return best if min(best["gains"]) > 0 else None, best


def evaluate(y, prediction, control):
    h1, h0 = np.abs(y - prediction) <= 7, np.abs(y - control) <= 7
    return {
        "metrics": measure(y, prediction),
        "summary": summary(y, prediction),
        "rescued": int((h1 & ~h0).sum()),
        "spoiled": int((h0 & ~h1).sum()),
        "net": int(h1.sum() - h0.sum()),
    }


def run(args):
    source = json.loads((args.cache / "cases.json").read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Native games source changed")
    sides = {}
    for game in (json.loads(line) for line in raw.decode().splitlines() if line.strip()):
        for player, person in game["players"].items():
            club = person.get("team")
            if club not in (game["home"]["slug"], game["away"]["slug"]):
                raise ValueError("Unknown native fixture side")
            opponent = game["away" if club == game["home"]["slug"] else "home"]["slug"]
            sides[game["id"], player] = club, opponent
    read = lambda name: json.loads((args.reports / (name + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
        ),
    )
    if any(r["sourceKey"] != source["key"] for r in (old_match, old_stability, old_ordinary, old_start)):
        raise ValueError("Original component cases differ")
    key = hashlib.sha256(
        (
            source["key"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
        ).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    output = {
        "scope": "Local testing only; no app changes. One bounded cause-driven hypothesis, not a restart of retired grids.",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind proof.",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        masks = stability.phase_masks(rows)
        call = SimpleNamespace(rows=rows, cache=args.cache)
        bundles, phase_rows, record_lists, receipts = {}, {}, {}, {}
        for phase, _, _ in stability.PHASES[:-1]:
            bundles[phase] = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            phase_rows[phase] = [r for r, yes in zip(rows, masks[phase]["target"], strict=True) if yes]
            median, _ = empirical.location_scale(bundles[phase][2], "raw")
            record_lists[phase], receipts[phase] = records_from(phase_rows[phase], sides, bundles[phase][0], median)
        all_records = sum(record_lists.values(), [])
        memory = Memory(all_records)
        specs = [
            {"signal": s, "weight": w, "scope": scope} for s in SIGNALS for w in (0.5, 1) for scope in ("DEF", "all")
        ]
        candidates = [{"spec": spec, "gains": [], "counts": [], "maes": [], "periods": {}} for spec in specs]
        diagnostics, prior = {}, "warm2023"
        for phase, _, _ in stability.PHASES[1:-1]:
            current_rows, current = phase_rows[phase], bundles[phase]
            pos = np.array([r["pos"] for r in current_rows])
            y, aa, level = (np.array([r[k] for r in current_rows]) for k in ("score", "aa", "level"))
            classes, probability, parts = current
            bank = bank_from(bundles[prior], phase_rows[prior], masks[phase]["first"])
            control = (
                empirical.empirical_predictions(classes, probability, parts, pos, bank, 20, 0.75, 0)
                if cohort == "start"
                else None
            )
            if cohort == "bench":
                old_bench = read("laliga_score_analogues")
                control = stability.analogue_control(
                    SimpleNamespace(**vars(call), out=args.out), key, source, old_bench, phase, masks[phase]
                )
            expected = old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
            if measure(y, control) != expected:
                raise ValueError("Original earlier control does not reconstruct")
            signals = [
                memory.query(*sides[r["game"], r["player"]], r["pos"], cohort, cutoff_for(r["date"]).timestamp())
                for r in current_rows
            ]
            if phase == "spring2024":
                for row, signal in zip(current_rows, signals, strict=True):
                    direct = signal_for(
                        all_records,
                        *sides[row["game"], row["player"]],
                        row["pos"],
                        cohort,
                        cutoff_for(row["date"]).timestamp(),
                    )
                    if direct != signal:
                        raise ValueError("Independent direct-filter memory reconstruction differs")
            location, _ = empirical.location_scale(parts, "raw")
            residual = np.full(len(y), np.nan)
            known = np.isin(level, classes)
            indices = np.flatnonzero(known)
            residual[known] = aa[known] - location[indices, np.searchsorted(classes, level[known])]
            diagnostics[phase] = {
                "all": {},
                "DEF": {},
                "coldOwn10": sum(s["own10Count"] == 0 for s in signals),
                "coldOpponent10": sum(s["opponent10Count"] == 0 for s in signals),
            }
            for s in SIGNALS:
                values = np.array([r[s] for r in signals])
                diagnostics[phase]["all"][s] = association(values, residual)
                diagnostics[phase]["DEF"][s] = association(values[pos == "DEF"], residual[pos == "DEF"])
            np.savez_compressed(
                args.cache / f"{args.out.stem}_{cohort}_{phase}_signals.npz",
                key=key,
                x=np.array([[r[s] for s in SIGNALS] for r in signals]),
                control=control,
                y=y,
            )
            for s in SIGNALS:
                signal = np.array([r[s] for r in signals])
                for weight in (0.5, 1):
                    shifted = shift_parts(parts, signal, np.ones(len(y), dtype=bool), weight)
                    all_prediction = empirical.empirical_predictions(
                        classes, probability, shifted, pos, bank, 20, 0.75, 0
                    )
                    for scope in ("DEF", "all"):
                        prediction = (
                            np.where(pos == "DEF", all_prediction, control) if scope == "DEF" else all_prediction
                        )
                        record = next(
                            r for r in candidates if r["spec"] == {"signal": s, "weight": weight, "scope": scope}
                        )
                        result = evaluate(y, prediction, control)
                        record["gains"].append(result["metrics"]["within7"] - expected["within7"])
                        record["counts"].append(len(y))
                        record["maes"].append(result["metrics"]["mae"])
                        record["periods"][phase] = result
                        np.savez_compressed(
                            args.cache / f"{args.out.stem}_{cohort}_{phase}_{s}_w{weight}_{scope}.npz",
                            key=key,
                            prediction=prediction,
                        )
            print(
                "EARLIER "
                + json.dumps(
                    {"cohort": cohort, "phase": phase, "bestNet": max(r["periods"][phase]["net"] for r in candidates)}
                ),
                flush=True,
            )
            prior = phase
        winner, best = frozen_choice(candidates)
        frozen = {"implementationKey": key, "winner": winner, "best": best, "candidates": candidates}
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(json.dumps(frozen, indent=2, allow_nan=False))
        output["cohorts"][cohort] = {
            "selected": "candidate" if winner else "control",
            "bestEarlier": best,
            "passingCandidates": sum(min(r["gains"]) > 0 for r in candidates),
            "diagnostics": diagnostics,
            "pastRecordReceipts": receipts,
            "independentDirectFilterVerifiedPhase": "spring2024",
            "laterStatus": "Not evaluated: rejected earlier"
            if not winner
            else "Pending fixed frozen candidate evaluation",
        }
        args.out.write_text(json.dumps(output, indent=2, allow_nan=False))
        print(
            "FROZEN "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": bool(winner),
                    "spec": best["spec"],
                    "netByPeriod": {p: r["net"] for p, r in best["periods"].items()},
                }
            ),
            flush=True,
        )
        # Final evaluation is a separate explicit step only if a fixed candidate passes all earlier periods.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--reports", type=Path, default=Path("reports/experiments"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_team_error_memory.json"))
    parser.add_argument("--games", type=Path, required=True)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
