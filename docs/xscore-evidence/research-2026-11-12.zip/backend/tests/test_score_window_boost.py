import sys
from types import SimpleNamespace

import numpy as np

from app.research.score_window_boost import choose_position_models, fit_intervals


def test_position_selection_uses_earlier_targets_without_dropping_a_position():
    y = np.array([40, 70, 30])
    positions = np.array(["GK", "DEF", "FWD"])
    predictions = {"a": np.array([40, 10, 30]), "b": np.array([10, 70, 10])}
    chosen = choose_position_models(y, predictions, positions)
    assert chosen == {"GK": "a", "DEF": "b", "FWD": "a"}


def test_later_target_scores_cannot_change_the_interval_predictions(tmp_path, monkeypatch):
    class EarlierOnlyClassifier:
        def __init__(self, **kwargs):
            pass

        def fit(self, x, target):
            assert len(x) == len(target) == 2
            self.chance = target.mean()
            return self

        def predict_proba(self, x):
            return np.tile([1 - self.chance, self.chance], (len(x), 1))

    monkeypatch.setitem(
        sys.modules, "sklearn.ensemble", SimpleNamespace(HistGradientBoostingClassifier=EarlierOnlyClassifier)
    )
    x = np.zeros((4, 1))
    fit = np.array([True, True, False, False])
    original = np.array([40, 80, 10, 20])
    changed = np.array([40, 80, 100, 0])
    a = fit_intervals(x, original, fit, ~fit, 7, 80, tmp_path / "a.npz", "key", "test")
    b = fit_intervals(x, changed, fit, ~fit, 7, 80, tmp_path / "b.npz", "key", "test")
    np.testing.assert_array_equal(a, b)
