"""Test whether linked routine-point errors help locate one score window."""

import argparse
import hashlib
import json
from collections import defaultdict

import numpy as np

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_failure_review import activity_groups
from app.research.score_goal_context_rebuild import CONTEXT_KEY, INTENSITY, QUALITY
from app.research.score_search import cutoff_for, moment
from app.research.score_team_routine_shift import DELAY, metrics

STEM = "laliga_score_activity_dependence"
CENTRES = np.arange(-45, 111, 0.5)


def native_points(stats):
    grouped = activity_groups(stats)
    clean, defensive, passing = (
        grouped[name] for name in ("cleanSheetAndConceded", "duelsTacklesRecoveries", "passingAndControl")
    )
    return [clean, defensive, passing, sum(grouped.values()) - clean - defensive - passing]


def centres(x, labels, fit, check):
    a, b = x[fit], x[check]
    mean, sd = a.mean(axis=0), a.std(axis=0)
    sd[sd < 1e-7] = 1
    a, b = np.clip((a - mean) / sd, -5, 5), np.clip((b - mean) / sd, -5, 5)
    y = np.clip(labels[fit], -35, 45)
    intercept = y.mean(axis=0)
    weights = np.linalg.solve(a.T @ a + 180 * np.eye(a.shape[1]), a.T @ (y - intercept))
    return intercept + b @ weights


def distribution(residuals, draw_count, seed):
    random = np.random.default_rng(seed)
    ids = random.integers(0, len(residuals), draw_count)
    paired = residuals[ids]
    independent = np.column_stack([random.permutation(paired[:, i]) for i in range(paired.shape[1])])
    return paired.sum(axis=1), independent.sum(axis=1)


def forecasts(location, atoms):
    output = np.empty(len(location))
    atoms = np.sort(atoms)
    for i, mean in enumerate(location):
        low = np.searchsorted(atoms, CENTRES - mean - 7, side="left")
        high = np.searchsorted(atoms, CENTRES - mean + 7, side="right")
        mass = high - low
        options = CENTRES[mass == mass.max()]
        output[i] = options[np.argmin(abs(options - (mean + atoms.mean())))]
    return output


def exact_distribution(residuals):
    integer = np.rint(np.asarray(residuals) * 20).astype(int)
    offset = integer.min(axis=0)
    hist = [np.bincount(values - start) / len(values) for values, start in zip(integer.T, offset, strict=True)]
    mass = hist[0]
    for probabilities in hist[1:]:
        mass = np.convolve(mass, probabilities)
    sums, frequencies = np.unique(integer.sum(axis=1), return_counts=True)
    np.testing.assert_allclose(mass.sum(), 1, rtol=0, atol=1e-10)
    return (sums / 20, frequencies / len(integer)), ((np.arange(len(mass)) + offset.sum()) / 20, mass)


def exact_forecasts(location, model):
    points, probabilities = model
    cumulative = np.r_[0.0, probabilities.cumsum()]
    out = np.empty(len(location))
    for i, mean in enumerate(location):
        low = np.searchsorted(points, CENTRES - mean - 7, side="left")
        high = np.searchsorted(points, CENTRES - mean + 7, side="right")
        mass = cumulative[high] - cumulative[low]
        options = CENTRES[np.abs(mass - mass.max()) <= 1e-12]
        out[i] = options[np.argmin(abs(options - (mean + points @ probabilities)))]
    return out


def predict(residuals, earlier, check, position, threat, means, conditional, exact):
    pools = defaultdict(list)
    pool_position = defaultdict(list)
    for i in np.flatnonzero(earlier):
        pools[position[i], threat[i]].append(residuals[i])
        pool_position[position[i]].append(residuals[i])
    all_past = residuals[earlier]
    ids = np.flatnonzero(check)
    out = np.empty((2, len(ids)))
    output_ids = defaultdict(list)
    for j, i in enumerate(ids):
        key = position[i], threat[i] if conditional else -2
        output_ids[key].append(j)
    for j, ((pos, risk), indices) in enumerate(sorted(output_ids.items())):
        pool = pools[pos, risk]
        if risk < 0 or len(pool) < 60:
            pool = pool_position[pos]
        if len(pool) < 25:
            pool = all_past
        if exact:
            for i, model in enumerate(exact_distribution(pool)):
                out[i, indices] = exact_forecasts(means[ids[indices]], model)
        else:
            for i, atoms in enumerate(distribution(np.array(pool), 256, 20261111 + j)):
                out[i, indices] = forecasts(means[ids[indices]], atoms)
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exact", action="store_true")
    args = parser.parse_args()
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = {g["id"]: g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"}
    case_data = json.loads((ROOT / "cases.json").read_bytes())
    ids = [i for i, r in enumerate(case_data["rows"]) if r["game"] in games]
    rows = [case_data["rows"][i] for i in ids]
    native = np.array([r["x"] for r in rows])
    names = case_data["features"]
    cache = ROOT / "match_context_features.npz"
    with np.load(cache) as f:
        assert str(f["key"]) == CONTEXT_KEY
        feature_names = f["names"].tolist()
        history = f["x"][ids][:, [feature_names.index(k) for k in (*QUALITY, *INTENSITY)]]
    x = np.column_stack((native, np.nan_to_num(history), ~np.isfinite(history)))
    label = np.array([native_points(games[r["game"]]["players"][r["player"]]["stats"]) for r in rows])
    y = np.array([r["aa"] for r in rows])
    np.testing.assert_allclose(label.sum(axis=1), y, atol=1e-7, rtol=0)
    home, h, a = (names.index(k) for k in ("home", "match_lam_h", "match_lam_a"))
    opponent = np.where(native[:, home] > 0, native[:, a], native[:, h])
    threat = np.where(opponent >= 0, np.digitize(opponent, (0.85, 1.4)), -1)
    position = np.array([r["pos"] for r in rows])
    cohort = np.array([r["cohort"] for r in rows])
    date = np.array([r["date"] for r in rows])
    locks = np.array([cutoff_for(r["date"]) for r in rows])
    ready = np.array([moment(r["date"]) + DELAY for r in rows])
    predicted = np.full_like(label, np.nan)
    phases = {}
    for phase, (begin, end) in {"warm": ("2023-11-01", "2024-01-01"), **PHASES}.items():
        selected = (date >= begin) & (date < end)
        available = ready < locks[selected].min()
        phases[phase] = {}
        for role in ("start", "bench"):
            check, fit = selected & (cohort == role), available & (cohort == role)
            predicted[check] = centres(x, label, fit, check)
            if phase == "warm":
                continue
            earlier = fit & np.isfinite(predicted[:, 0])
            residual = label - predicted
            actual = y[check]
            phases[phase][role] = {}
            for name, conditional in (("position", False), ("opponentThreat", True)):
                paired, control = predict(
                    residual, earlier, check, position, threat, predicted.sum(axis=1), conditional, args.exact
                )
                phases[phase][role][name] = metrics(actual, control, paired)
    gate = {}
    for role in ("start", "bench"):
        gate[role] = {}
        for name in ("position", "opponentThreat"):
            selection = [phases[p][role][name] for p in PHASES]
            n = sum(r["n"] for r in selection)
            changes = [r["gained"] - r["lost"] for r in selection]
            mae = sum(r["n"] * (r["mae"][0] - r["mae"][1]) for r in selection) / n
            gate[role][name] = dict(
                n=n,
                hitGain=sum(changes),
                maeGain=mae,
                phaseHitGains=changes,
                passEarlier=sum(changes) > 0 and mae > 0 and min(changes) >= 0,
            )
    output = dict(
        nativeSHA=NATIVE_SHA,
        matchContextSHA=hashlib.sha256(cache.read_bytes()).hexdigest(),
        periods=phases,
        gate=gate,
        laterEvaluated=False,
    )
    name = STEM + ("_exact" if args.exact else "")
    (REPORTS / (name + ".json")).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
