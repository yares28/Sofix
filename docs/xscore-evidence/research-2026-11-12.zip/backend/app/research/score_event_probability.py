"""Testing only: calibrated event intensities and supported decisive-score probabilities."""

from __future__ import annotations

import numpy as np

MODELS = {
    f"{group}_{mode}": (group, mode)
    for group in ("history", "quality")
    for mode in ("physics", "global1", "global20", "position1", "position20")
}
NET = {0: -3, 5: -2, 15: -1, 35: 0, 60: 1, 70: 2, 80: 3, 90: 4, 100: 5}


def calibrate(raw, target, ridge, prior=(0, 1)):
    from scipy.optimize import minimize

    raw, target = np.asarray(raw, dtype=float), np.asarray(target, dtype=float)
    if (
        raw.ndim != 1
        or target.shape != raw.shape
        or not len(raw)
        or not np.isfinite(raw).all()
        or (raw < 0).any()
        or not np.isfinite(target).all()
        or (target < 0).any()
    ):
        raise ValueError("Available finite nonnegative event labels and intensities required")
    x = np.column_stack((np.ones(len(raw)), np.log(np.clip(raw, 1e-8, 20))))
    prior = np.asarray(prior, dtype=float)

    def objective(beta):
        eta = x @ beta
        fitted = np.exp(eta)
        delta = beta - prior
        loss = float((fitted - target * eta).sum() + 0.5 * ridge * (delta @ delta))
        gradient = x.T @ (fitted - target) + ridge * delta
        return loss, gradient

    fit = minimize(
        objective,
        prior,
        jac=True,
        method="L-BFGS-B",
        bounds=((-3, 3), (0.25, 2)),
        options={"maxiter": 1000, "ftol": 1e-12, "gtol": 1e-7},
    )
    if not fit.success or not np.isfinite(fit.x).all():
        raise ValueError("Event calibration did not converge: " + str(fit.message))
    stats = {
        "fitRows": len(raw),
        "events": float(target.sum()),
        "converged": bool(fit.success),
        "iterations": int(fit.nit),
        "intercept": float(fit.x[0]),
        "power": float(fit.x[1]),
        "boundary": bool(np.isclose(abs(fit.x[0]), 3) or np.isclose(fit.x[1], 0.25) or np.isclose(fit.x[1], 2)),
    }
    return fit.x, stats


def expected_count(raw, beta):
    return np.clip(np.exp(beta[0] + beta[1] * np.log(np.clip(raw, 1e-8, 20))), 1e-8, 10)


def fit_intensities(positive_raw, negative_raw, positive_label, negative_label, positions, fit, target, mode):
    eligible = np.asarray(fit) & (np.asarray(positions) != "GK")
    current = np.asarray(positions)[target]
    rates = np.column_stack((positive_raw[target], negative_raw[target])).astype(float)
    stats = {
        "mode": mode,
        "fitOutfieldRows": int(eligible.sum()),
        "targetRows": int(np.asarray(target).sum()),
        "models": {},
    }
    if mode == "physics":
        return np.clip(rates, 1e-8, 10), stats
    ridge = 20 if mode.endswith("20") else 1
    for j, (name, raw, labels) in enumerate(
        (("positive", positive_raw, positive_label), ("negative", negative_raw, negative_label))
    ):
        global_beta, global_stats = calibrate(raw[eligible], labels[eligible], ridge)
        rates[:, j] = expected_count(raw[target], global_beta)
        stats["models"][name] = {"global": global_stats, "positions": {}}
        if mode.startswith("position"):
            for pos in sorted(set(current)):
                own = eligible & (np.asarray(positions) == pos)
                if own.sum() < 100:
                    stats["models"][name]["positions"][pos] = {"globalFallback": True, "fitRows": int(own.sum())}
                    continue
                beta, pos_stats = calibrate(raw[own], labels[own], ridge, global_beta)
                rates[current == pos, j] = expected_count(raw[target][current == pos], beta)
                stats["models"][name]["positions"][pos] = {**pos_stats, "globalFallback": False}
    if not np.isfinite(rates).all() or (rates <= 0).any():
        raise ValueError("Invalid forecast event intensities")
    return rates, stats


def event_probabilities(classes, positive, negative, policy, old):
    from scipy.stats import poisson, skellam

    classes = np.asarray(classes)
    positive, negative = np.asarray(positive, dtype=float), np.asarray(negative, dtype=float)
    if (
        positive.ndim != 1
        or negative.shape != positive.shape
        or not np.isfinite(positive).all()
        or not np.isfinite(negative).all()
        or (positive < 0).any()
        or (negative < 0).any()
        or len(classes) < 1
        or 35 not in classes
        or not all(v in NET for v in classes)
    ):
        raise ValueError("Supported levels and nonnegative event means required")
    net = np.array([NET[v] for v in classes])
    if not (np.diff(net) > 0).all():
        raise ValueError("Decisive classes must be unique and ordered")
    cuts = []
    for low, high in zip(net[:-1], net[1:], strict=True):
        mid = (low + high) / 2
        cut = int(np.floor(mid))
        if mid == cut and abs(low) > abs(high):
            cut -= 1
        cuts.append(cut)
    cuts = np.asarray(cuts)
    cdf = np.zeros((len(positive), len(cuts)))
    both = (positive > 0) & (negative > 0)
    cdf[both] = skellam.cdf(cuts[None, :], positive[both, None], negative[both, None])
    only_positive = (positive > 0) & (negative == 0)
    cdf[only_positive] = poisson.cdf(cuts[None, :], positive[only_positive, None])
    only_negative = (positive == 0) & (negative > 0)
    cdf[only_negative] = poisson.sf(-cuts[None, :] - 1, negative[only_negative, None])
    neither = (positive == 0) & (negative == 0)
    cdf[neither] = (cuts >= 0).astype(float)
    probability = np.maximum(
        0, np.diff(np.column_stack((np.zeros(len(positive)), cdf, np.ones(len(positive)))), axis=1)
    )
    probability /= probability.sum(axis=1, keepdims=True)
    if policy == "state_totals":
        old = np.asarray(old, dtype=float)
        if (
            old.shape != probability.shape
            or not np.isfinite(old).all()
            or (old < 0).any()
            or not np.allclose(old.sum(axis=1), 1)
        ):
            raise ValueError("Valid prior class probabilities required")
        for selected in (net < 0, net == 0, net > 0):
            if not selected.any():
                continue
            total = probability[:, selected].sum(axis=1)
            old_total = old[:, selected].sum(axis=1)
            weight = np.divide(
                old[:, selected], old_total[:, None], out=np.zeros_like(old[:, selected]), where=old_total[:, None] > 0
            )
            probability[:, selected] = np.where(
                old_total[:, None] > 0, total[:, None] * weight, probability[:, selected]
            )
    elif policy != "counts":
        raise ValueError("Unknown event probability policy")
    if not np.isfinite(probability).all() or (probability < 0).any() or not np.allclose(probability.sum(axis=1), 1):
        raise ValueError("Invalid event probability output")
    return probability


def forecast_policy(candidate, control, positions, decision, scope):
    if decision == "state_changes":
        chosen = np.where((candidate >= 60) != (control >= 60), candidate, control)
    elif decision == "full":
        chosen = candidate
    else:
        raise ValueError("Unknown event score policy")
    if scope == "outfield":
        selected = np.asarray(positions) != "GK"
    elif scope == "defmid":
        selected = np.isin(positions, ["DEF", "MID"])
    elif scope == "forward":
        selected = np.asarray(positions) == "FWD"
    else:
        raise ValueError("Unknown event score scope")
    return np.where(selected, chosen, control)
