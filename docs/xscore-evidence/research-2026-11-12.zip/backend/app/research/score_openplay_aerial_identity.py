"""Check the retrospective value of knowing the actual aerial opponent."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from app.research.score_duel_game_spread import intervals
from app.research.score_openplay_duel_features import FEATURES, chance, read_contests
from app.research.score_openplay_duel_signal import native_archive
from app.research.score_opposition_strength import PHASES

MODELS = ("even", "playerOnly", "projectedOpponents", "actualOpponentHindsight")


def run(args):
    source = json.loads((args.cache / "cases.json").read_text())
    source_report = json.loads((args.out.parent / "laliga_score_openplay_duel_source.json").read_text())
    directory = args.cache / "openplay-data-v0.1.0"
    games = native_archive(args.games)
    contests = read_contests(directory, source_report, games)
    with np.load(directory / "strict_past_duel_features.npz") as store:
        if (
            str(store["sourceKey"]) != source["key"]
            or str(store["pairSha"]) != source_report["pairedArtifactSha256"]
            or store["names"].tolist() != list(FEATURES)
            or len(store["x"]) != len(source["rows"])
        ):
            raise ValueError("Verified lagged feature identity differs")
        indexes = [FEATURES.index(name) for name in ("aerial_ability", "aerial_projected_win")]
        x = store["x"][:, indexes]
    by_game = {(r["game"], r["player"]): (r["week"], values) for r, values in zip(source["rows"], x, strict=True)}
    periods = {}
    for phase, begin, end in PHASES:
        audit = Counter()
        paired = defaultdict(list)
        for game_id, events in contests.items():
            game = games[game_id]
            if not begin <= game["date"] < end:
                continue
            for kind, _x, clubs, actors in events:
                if kind != 0:
                    continue
                audit["allAerialPairs"] += 1
                if None in actors:
                    audit["unmappedActor"] += 1
                    continue
                won = clubs[0] == game["home"]["slug"]
                home, away = actors if won else actors[::-1]
                a, b = (by_game.get((game_id, player)) for player in (home, away))
                if a is None or b is None or not np.isfinite([a[1], b[1]]).all():
                    audit["unknownPriorRatingOrProjection"] += 1
                    continue
                if a[0] != b[0]:
                    raise ValueError("Gameweek differs within fixture")
                home_rating, home_roster = a[1]
                away_rating, away_roster = b[1]
                projected = (home_roster + (1 - away_roster)) / 2
                hindsight = chance(home_rating - away_rating)
                p = np.array([0.5, chance(home_rating), projected, hindsight])
                paired[a[0]].append((p - won) ** 2)
                audit["scoredDiagnosticPairs"] += 1
                audit["actualPairChangesChanceByAtLeastFivePoints"] += abs(hindsight - projected) >= 0.05
        losses = np.concatenate([v for v in paired.values()])
        week = np.concatenate([np.repeat(k, len(v)) for k, v in paired.items()])
        gain = losses[:, :3] - losses[:, 3:]
        periods[phase] = {
            "coverage": {k: int(v) for k, v in audit.items()},
            "brier": dict(zip(MODELS, losses.mean(axis=0).tolist(), strict=True)),
            "hindsightGain95AgainstEvenPlayerAndRoster": intervals(gain, week).tolist(),
        }
    args.out.write_text(
        json.dumps(
            {
                "scope": "Earlier diagnostic only, actual opponent identity used only to explain.",
                "sourceKey": source["key"],
                "periods": periods,
            },
            indent=2,
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/experiments/laliga_score_openplay_aerial_identity.json")
    )
    run(parser.parse_args())


if __name__ == "__main__":
    main()
