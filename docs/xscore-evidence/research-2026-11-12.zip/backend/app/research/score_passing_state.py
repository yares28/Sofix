"""Audit whether completed passes can be assigned to verified match states."""

import hashlib
import json
from collections import Counter, defaultdict

from app.research.score_absence_role_signal import NATIVE, NATIVE_SHA, REPORTS, ROOT
from app.research.score_card_cycle import PHASES
from app.research.score_player_context import link_names, words
from app.research.score_substitution_clock import capture

STEM = "laliga_score_passing_state"


def minutes_by_state(goals, entry, exit):
    ambiguous = {t for t, _ in goals}
    states = {}
    for minute in range(max(entry + 1, 1), min(exit, 91)):
        if minute not in ambiguous:
            margin = sum(delta for at, delta in goals if at < minute)
            states[minute] = 0 if margin < 0 else 2 if margin > 0 else 1
    return states


class Source:
    def __init__(self, aliases, characterize=None):
        self.aliases = aliases
        self.characterize = characterize
        self.audit = Counter()
        self.records = []

    def observe(self, game, detail, side, clocks, qualified):
        passes = detail.get("passes")
        if not isinstance(passes, list):
            self.audit["missingFixturePassStream"] += 1
            return
        stream = [e for e in passes if e.get("team") == side]
        if not stream:
            self.audit["missingSidePassStream"] += 1
            return
        by_name = defaultdict(list)
        for p in stream:
            by_name[words(p.get("player", ""))].append(p)
        starters, substitutes = clocks
        named = [*starters, *substitutes]
        archive_by_name = {words(p["name"]): p for p in named}
        club = qualified["club"]
        native = {slug: p for slug, p in game["players"].items() if p.get("played") and p["team"] == club}
        links, _ = link_names([p["name"] for p in named], native, self.aliases)
        lookup = {slug: name for name, slug in links.items()}
        for player in qualified["players"]:
            slug = player["player"]
            name = lookup[slug]
            label = native[slug].get("stats", {}).get("accurate_pass")
            if label is None:
                self.audit["noExplicitNativeAccurateCount"] += 1
                continue
            events = by_name[name]
            if any(type(p.get("min")) is not int or type(p.get("ok")) is not bool for p in events):
                self.audit["badPassClockOrOutcome"] += 1
                continue
            if sum(p["ok"] for p in events) != label[0]:
                self.audit["completionCountDiffers"] += 1
                continue
            source = archive_by_name[name]
            entry = source.get("on") or 0
            exit = source.get("off") or 91
            if any(not entry - 1 <= p["min"] <= exit + 15 for p in events):
                self.audit["passOutsideAppearance"] += 1
                continue
            by_minute = minutes_by_state(qualified["goalsForClub"], entry, exit)
            exposures = Counter(by_minute.values())
            completions = Counter(by_minute[p["min"]] for p in events if p["ok"] and p["min"] in by_minute)
            if not exposures:
                self.audit["noUnambiguousExposure"] += 1
                continue
            extra = self.characterize(events, by_minute) if self.characterize is not None else {}
            self.records.append(
                dict(
                    game=game["id"],
                    date=game["date"],
                    club=club,
                    player=slug,
                    position=player["position"],
                    cohort="start" if player["started"] else "bench",
                    exposure=[exposures[i] for i in range(3)],
                    completed=[completions[i] for i in range(3)],
                    fullCompleted=label[0],
                    **extra,
                )
            )
            self.audit["accepted"] += 1


def main():
    raw = NATIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == NATIVE_SHA
    games = [g for g in map(json.loads, raw.splitlines()) if g["date"] < "2026-01-01"]
    aliases = json.loads((ROOT / "player_names.json").read_bytes())
    passing = Source(aliases)
    _, _, digest = capture(games, aliases, observe=passing.observe)
    clock_source = json.loads((REPORTS / "laliga_score_substitution_clock.source.json").read_bytes())
    assert digest == clock_source["archiveReadSHA"]
    assert len({(r["game"], r["player"]) for r in passing.records}) == len(passing.records)
    archive = ROOT / (STEM + ".json")
    archive.write_text(json.dumps(passing.records, separators=(",", ":")) + "\n")
    groups = {}
    for phase, (begin, end) in PHASES.items():
        groups[phase] = {}
        for cohort in ("start", "bench"):
            selected = [r for r in passing.records if begin <= r["date"] < end and r["cohort"] == cohort]
            exposure = [sum(r["exposure"][i] for r in selected) for i in range(3)]
            actions = [sum(r["completed"][i] for r in selected) for i in range(3)]
            groups[phase][cohort] = dict(
                observations=len(selected),
                fixtures=len({r["game"] for r in selected}),
                exposure=exposure,
                completions=actions,
                completedPer90=[round(90 * n / e, 2) if e else None for n, e in zip(actions, exposure, strict=True)],
            )
    result = dict(
        nativeSHA=NATIVE_SHA,
        archiveReadSHA=digest,
        stateArchiveSHA=hashlib.sha256(archive.read_bytes()).hexdigest(),
        audit=dict(passing.audit),
        periods=groups,
        laterEvaluated=False,
        evidenceLimit="Exact full-match totals are a consistency check. Eligibility depends on identity, source coverage "
        "and agreement, so the observed rates do not represent every appearance. No forecasts have been fitted.",
    )
    (REPORTS / (STEM + ".source.json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"audit": result["audit"], "periods": groups}, indent=2))


if __name__ == "__main__":
    main()
