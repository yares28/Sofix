"""Testing only: verify mixture training confirmation, native scores and real refits."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_action_network as network
from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_local_errors as local
from app.research import score_local_errors_run as local_runner
from app.research import score_matchups_run as matched
from app.research import score_mixture_ordinary as mixture_base
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_residual_mixture as mixture
from app.research import score_residual_mixture_run as runner
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import cutoff_for, measure, moment


def independent_banks(rows, context, cohort, args, old_match, old_stability, old_ordinary, key):
    masks = stability.phase_masks(rows)
    bank = None
    banks = {}
    call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
    for phase, _, _ in stability.PHASES:
        target = masks[phase]["target"]
        if phase != "warm2023":
            banks[phase] = {n: v.copy() for n, v in bank.items()}
            path = args.cache / f"{args.report.stem}_bank_{cohort}_{phase}_{key[:12]}.npz"
            with np.load(path) as f:
                if str(f["key"]) != key or any(
                    not np.array_equal(f[n], v, equal_nan=True) if v.dtype.kind in "fc" else not np.array_equal(f[n], v)
                    for n, v in bank.items()
                ):
                    raise ValueError("Independent native OOF residual bank does not reconstruct")
        if phase == "later2026":
            break
        classes, p, parts = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
        past = [r for r, yes in zip(rows, target, strict=True) if yes]
        labels = np.array([r["level"] for r in past])
        known = np.isin(labels, classes)
        at = np.flatnonzero(known)
        columns = np.searchsorted(classes, labels[known])
        q = np.sort(np.stack([parts[v] for v in (0.35, 0.5, 0.65)]), axis=0)
        location = q[1, at, columns]
        record = {
            "available": np.array([(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in past])[known],
            "position": np.array([r["pos"] for r in past])[known],
            "player": np.array([r["player"] for r in past])[known],
            "level": labels[known],
            "error": np.array([r["aa"] for r in past])[known] - location,
            "x": np.column_stack(
                (context[target][known], location, q[2, at, columns] - q[0, at, columns], p[at, columns])
            ),
        }
        bank = record if bank is None else {n: np.concatenate((bank[n], record[n])) for n in bank}
    return banks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-final", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import scipy
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda n: json.loads((args.report.parent / (n + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"] for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Mixture audit source identity differs")
    old_player = read("laliga_score_player_context")
    if old_player["sourceKey"] != source["key"]:
        raise ValueError("Residual player source differs")
    with np.load(args.cache / "stats.npz") as f:
        base, names, stat_key = f["x"], f["names"].tolist(), str(f["key"])
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Mixture audit match feature identity differs")
        match, match_names = f["x"], f["names"].tolist()
    with np.load(args.cache / "player_context_features.npz") as f:
        if str(f["key"]) != old_player["featureKey"]:
            raise ValueError("Residual player features differ")
        player, player_names = f["x"], f["names"].tolist()
    modules = (
        mixture,
        mixture_base,
        network,
        local,
        local_runner,
        empirical,
        flow,
        matched,
        controls,
        modal,
        ordinary,
        stability,
        windows,
    )
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + scipy.__version__
            + np.__version__
        ).encode()
        + Path(runner.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    if key != report["implementationKey"]:
        raise ValueError("Mixture audit formula fingerprint differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        y = np.array([r["score"] for r in rows], dtype=float)
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, ordinary_names = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        context = numeric[:, [ordinary_names.index(n.format(c=cohort)) for n in local.CONTEXT]]
        banks = independent_banks(rows, context, cohort, args, old_match, old_stability, old_ordinary, key)
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        selection_path = args.report.with_name(args.report.stem + f".{cohort}.selection80.json")
        frozen, selection = (json.loads(p.read_text()) for p in (frozen_path, selection_path))
        initial_winner, initial_best = stability.choose_stable(frozen["candidates80"])
        confirmed = frozen["best"]
        if (
            frozen["implementationKey"] != key
            or selection["implementationKey"] != key
            or initial_winner != frozen["initialWinner80"]
            or initial_best != frozen["initialBest80"]
            or initial_best != selection["best"]
            or initial_winner != selection["winner"]
            or selection["candidates"] != frozen["candidates80"]
            or confirmed["spec"] != initial_best["spec"]
            or (min(confirmed["gains"]) > 0) != (frozen["winner"] is not None)
            or (frozen["winner"] is not None) != (result["selected"] == "candidate")
        ):
            raise ValueError("Mixture audit initial/fixed-confirmed selection differs")
        caches, reconstructed = 0, 0
        for phase, _, _ in stability.PHASES[1:]:
            target = masks[phase]["target"]
            old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Mixture audit strongest control differs")
            first_lock = cutoff_for(masks[phase]["first"]).timestamp()
            eligible = banks[phase]["available"] < first_lock
            trainraw = mixture_base.design(
                banks[phase]["x"][eligible], banks[phase]["position"][eligible], banks[phase]["level"][eligible]
            )
            trainerrors = banks[phase]["error"][eligible]
            data_key = hashlib.sha256(trainraw.tobytes() + trainerrors.tobytes()).hexdigest()
            normaliser = network.Normaliser().fit(trainraw)
            normaliser_key = hashlib.sha256(
                normaliser.mean_.tobytes() + normaliser.scale_.tobytes() + normaliser.known_.tobytes()
            ).hexdigest()
            active = (
                [(confirmed, 160)]
                if phase == "later2026"
                else [(r, 80) for r in frozen["candidates80"]] + [(confirmed, 160)]
            )
            grouped = sorted({(r["spec"]["model"], epochs) for r, epochs in active})
            for model, epochs in grouped:
                with np.load(args.cache / f"{args.report.stem}_{cohort}_{phase}_{model}_e{epochs}.npz") as f:
                    mass, stats = f["mass"], json.loads(str(f["statistics"]))
                    if (
                        str(f["key"]) != key
                        or not np.array_equal(f["classes"], old[0])
                        or not np.array_equal(f["probability"], old[1])
                        or stats["epochs"] != epochs
                        or stats["settings"] != runner.MODELS[model]
                        or stats["eligibleOOFErrors"] != int(eligible.sum())
                        or stats["excludedUnavailableErrors"] != int((~eligible).sum())
                        or stats["eligibleDataSha256"] != data_key
                        or stats["firstLock"] != first_lock
                        or not stats["currentOutcomeLabelsNotAnInput"]
                        or stats["targetCases"] != int(target.sum())
                        or stats["normaliserSha256"] != normaliser_key
                        or len(stats["trainingOnlyLoss"]) != epochs
                        or not np.isfinite(stats["trainingOnlyLoss"]).all()
                        or not stats["eventProbabilitiesUnchanged"]
                        or mass.shape != (int(target.sum()), 201)
                        or not np.isfinite(mass).all()
                        or (mass < 0).any()
                        or (mass > 1 + 1e-12).any()
                    ):
                        raise ValueError("Mixture audit cached training/mass/feature/event identity differs")
                caches += 1
                raw = windows.window_centres(mass, modal.CENTRES)
                for record, _record_epochs in [a for a in active if a[0]["spec"]["model"] == model and a[1] == epochs]:
                    forecast = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    if phase == "later2026":
                        alternate = forecast
                        final_mass = mass
                        final_stats = stats
                    elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                        raise ValueError("Mixture audit earlier forecast metric differs")
                    reconstructed += 1
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Mixture audit native final all-case score identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Mixture audit native final metric differs")
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = {
            "n": int(target.sum()),
            "candidateCorrect": int(h1.sum()),
            "controlCorrect": int(h0.sum()),
            "gained": int((h1 & ~h0).sum()),
            "lost": int((h0 & ~h1).sum()),
            "massCachesVerified": caches,
            "candidateForecastsReconstructed": reconstructed,
            "fixedLongerTrainingConfirmationVerified": True,
            "freezeSha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        }
        if args.refit_final:
            bank = {n: v.copy() for n, v in banks["later2026"].items()}
            unavailable = bank["available"] >= first_lock
            for name in ("error", "level", "x"):
                bank[name][unavailable] = np.nan
            n = int(target.sum())
            for name, values in bank.items():
                if name == "available":
                    extra = np.full(n, first_lock + 1)
                elif name == "position":
                    extra = positions[target]
                elif name == "player":
                    extra = np.full(n, "unavailable")
                else:
                    extra = np.full((n, *values.shape[1:]), np.nan)
                bank[name] = np.concatenate((values, extra))
            print(f"RESIDUAL_MIXTURE_AUDIT_REFIT {cohort} {confirmed['spec']['model']}", flush=True)
            repeated, stats = mixture.fit_forecasts(
                bank,
                context[target],
                old,
                positions[target],
                first_lock,
                runner.MODELS[confirmed["spec"]["model"]],
                160,
            )
            expected_stats = {**final_stats, "excludedUnavailableErrors": final_stats["excludedUnavailableErrors"] + n}
            if not np.array_equal(repeated, final_mass) or stats != expected_stats:
                raise ValueError(
                    "Residual mixture final model changes after unavailable labels blanked and future placeholders injected"
                )
            evidence[cohort]["realRefitWithUnavailableLabelsMutated"] = {
                "existingUnavailableOOFRowsBlanked": int(unavailable.sum()),
                "additionalUnavailableFutureRowsInjected": n,
                "all201MassesExactWeightsAndEligibleDataReproduced": True,
                "current2026AAandDSNeverNeeded": True,
            }
    output = {
        "scope": "Testing-only full native audit; exploratory reuse not fresh blind proof",
        "implementationKey": key,
        "cohorts": evidence,
    }
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
