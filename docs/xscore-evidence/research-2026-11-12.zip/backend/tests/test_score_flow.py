import numpy as np
import pytest

from app.research.score_flow import (
    clock_bank,
    flow_vector,
    sample_prediction,
    scenario_flows,
    score_draws,
    verified_flow,
)


def test_flow_integrates_time_and_mirrors_the_away_side():
    home = flow_vector([(30.0, "home"), (60.0, "away")], 90)
    np.testing.assert_allclose(home, [1, 1, 1 / 3, 2 / 3, 0, 1 / 3, 0, 0])
    away = flow_vector([(30.0, "home"), (60.0, "away")], 90, away=True)
    np.testing.assert_allclose(away, [1, 1, 0, 2 / 3, 1 / 3, -1 / 3, 0, 0])
    np.testing.assert_array_equal(flow_vector([], 96), [0, 0, 0, 1, 0, 0, 0, 0])


def test_own_goal_team_is_the_beneficiary_and_mismatch_is_unknown():
    detail = {"goals": [{"min": 45, "team": "home", "own": True}], "maxMin": 90}
    value, times = verified_flow(detail, 1, 0)
    np.testing.assert_array_equal(value, [1, 0, 0.5, 0.5, 0, 0.5, 0, 0])
    np.testing.assert_array_equal(times, [0.5])
    assert verified_flow(detail, 0, 1) is None
    assert verified_flow({"maxMin": 90}, 0, 0) is None
    assert verified_flow({"goals": [], "maxMin": 90}, 0, 0) is not None


def test_clock_bank_only_uses_unique_available_fit_games():
    labels = {"a": {"times": [0.1]}, "b": {"times": [0.9]}}
    rows = [{"game": "a"}, {"game": "a"}, {"game": "b"}]
    np.testing.assert_array_equal(clock_bank(labels, rows, np.array([True, True, False])), [0.1])


def test_scenarios_are_fixture_shared_mirrored_and_do_not_take_future_labels():
    fixtures = [("g", 1.4, 0.8), ("g", 1.4, 0.8)]
    home = scenario_flows(fixtures, np.array([False, False]), np.array([0.2, 0.5, 0.8]))
    away = scenario_flows(fixtures[:1], np.array([True]), np.array([0.2, 0.5, 0.8]))
    np.testing.assert_array_equal(home[0], home[1])
    np.testing.assert_allclose(home[0, :, [0, 1]], away[0, :, [1, 0]])
    np.testing.assert_allclose(home[0, :, 2], away[0, :, 4])
    np.testing.assert_allclose(home[0, :, 5], -away[0, :, 5])
    np.testing.assert_allclose(home[:, :, 2:5].sum(axis=2), 1)
    with pytest.raises(ValueError, match="lambda"):
        scenario_flows([("g", np.nan, 1.0)], np.array([False]), np.array([0.5]))


def test_score_samples_obey_floors_caps_and_choose_one_real_mode():
    level = np.array([[60.0] * 100, [35.0] * 100, [0.0] * 100])
    aa = np.array([[-50.0] * 100, [120.0] * 100, [40.0] * 51 + [80.0] * 49])
    prediction = sample_prediction(level, aa, np.zeros_like(aa), 1, 0)
    assert abs(prediction[0] - 60) <= 7
    assert abs(prediction[1] - 100) <= 7
    assert abs(prediction[2] - 40) <= 7
    assert abs(prediction[2] - 80) > 7


def test_decisive_blends_sample_the_selected_probability_and_keep_each_player():
    paths = {"locations": np.zeros((3, 32, 2)), "probability": np.tile([0.0, 1.0], (3, 32, 1))}
    bank = {"global": np.array([0.0]), "positions": {}, "levels": {}}
    for blend, expected in ((0, 35), (1, 60)):
        levels, locations, residuals = score_draws(
            np.array([35.0, 60]),
            np.tile([1.0, 0], (3, 1)),
            paths,
            np.array(["DEF", "MID", "FWD"]),
            bank,
            blend,
        )
        assert levels.shape == (3, 2048)
        np.testing.assert_array_equal(levels, expected)
        np.testing.assert_array_equal(locations, 0)
        np.testing.assert_array_equal(residuals, 0)


def test_changing_future_truth_cannot_change_usable_path_predictions(monkeypatch, tmp_path):
    import sys
    from types import SimpleNamespace

    import pandas as pd

    from app.research import score_ordinary as ordinary
    from app.research.score_flow import fitted_paths

    class Pool:
        def __init__(self, data, label=None, cat_features=None):
            self.data, self.label = data, label

    class Model:
        def __init__(self, minute=False, **kwargs):
            self.minute = minute

        def fit(self, pool):
            assert len(pool.data) == 3
            assert pool.data["n0"].max() == 2
            assert np.max(pool.label) < 100
            self.classes_ = np.array([35.0, 60])

        def predict(self, pool):
            x = pool.data
            return (80 if self.minute else 5) + x["flow_gf"].to_numpy() + x.get("candidate_level", 0)

        def predict_proba(self, pool):
            return np.tile([0.7, 0.3], (len(pool.data), 1))

    monkeypatch.setitem(sys.modules, "catboost", SimpleNamespace(Pool=Pool, CatBoostClassifier=Model))
    monkeypatch.setattr(ordinary, "regressor", lambda loss, minutes=False: Model(minute=minutes))
    frame = pd.DataFrame({"n0": np.arange(5.0), "person": ["p"] * 5})
    mask = {"fit": np.array([True, True, True, False, False]), "target": np.array([False, False, False, True, True])}
    flow = np.tile([0.0, 0, 0, 1, 0, 0, 0, 0], (5, 1))
    scenarios = np.tile(flow[3:, None, :], (1, 2, 1))
    aa, minutes, levels = np.array([1.0, 2, 3, 4, 5]), np.full(5, 80.0), np.array([35.0, 60, 35, 35, 60])
    first = fitted_paths(
        frame, ["person"], flow, aa, minutes, levels, mask, scenarios, np.array([35.0, 60]), tmp_path / "a.npz", "a"
    )
    changed = flow.copy()
    changed[3:, 0] = 8
    aa[3:], minutes[3:], levels[3:] = 900, 900, 900
    second = fitted_paths(
        frame, ["person"], changed, aa, minutes, levels, mask, scenarios, np.array([35.0, 60]), tmp_path / "b.npz", "b"
    )
    for name in ("locations", "probability", "minutes"):
        np.testing.assert_array_equal(first[name], second[name])
    assert not np.array_equal(first["factual_location"], second["factual_location"])
