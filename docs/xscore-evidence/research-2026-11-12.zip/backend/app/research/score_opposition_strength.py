"""Local research: jointly estimated aggregate opposition-adjusted duel abilities.

This is not an exact player-pair likelihood: individual duel partners are unknown.
The first stage measures prediction movement without inspecting target outcomes.
"""

from __future__ import annotations

import hashlib
import json
import sys
from bisect import bisect_left
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

DEPTH = {"DEF": 0.2, "MID": 0.6, "FWD": 1.0}
PHASES = (
    ("spring2024", "2024-01-01", "2024-07-01"),
    ("season2024", "2024-07-01", "2025-07-01"),
    ("autumn2025", "2025-07-01", "2026-01-01"),
)
NATIVE_SHA = "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
MATCHUP_KEY = "c823678a28410cd6f76bd73b824f54579522f44c49021ee1def6accc63e70d55"


def qualified(game):
    clubs = {game[s]["slug"] for s in ("home", "away")}
    starters = {c: 0 for c in clubs}
    members = {c: [] for c in clubs}
    for identity, p in game.get("players", {}).items():
        if p.get("played") is not True:
            continue
        club, pos, minutes = p.get("team"), p.get("pos"), p.get("mins")
        if (
            club not in clubs
            or pos not in ("GK", *DEPTH)
            or p.get("ver") != 7
            or type(p.get("started")) is not bool
            or type(minutes) not in (int, float)
            or not np.isfinite(minutes)
            or minutes < 0
            or not isinstance(p.get("stats"), dict)
        ):
            return None
        starters[club] += int(p["started"])
        if pos == "GK":
            continue
        counts = []
        for event in ("duel_won", "duel_lost"):
            entry = p["stats"].get(event, [0, 0])
            if (
                not isinstance(entry, (list, tuple))
                or len(entry) != 2
                or type(entry[0]) not in (int, float)
                or not np.isfinite(entry[0])
                or entry[0] < 0
                or entry[0] != round(entry[0])
            ):
                return None
            counts.append(float(entry[0]))
        members[club].append(
            dict(
                player=identity,
                pos=pos,
                minutes=float(minutes),
                cohort="start" if p["started"] else "bench",
                counts=counts,
            )
        )
    if len(clubs) != 2 or any(n != 11 for n in starters.values()):
        return None
    if any(not sum(p["minutes"] for p in people) > 0 for people in members.values()):
        return None
    return members


def exposure(position, members):
    if position not in DEPTH or not members:
        return {}
    weights = {
        p["player"]: p["minutes"] / (0.25 + abs(DEPTH[position] + DEPTH[p["pos"]] - 1.2))
        for p in members
        if p["minutes"] > 0
    }
    total = sum(weights.values())
    return {p: w / total for p, w in sorted(weights.items())} if total > 0 else {}


def observations(games):
    result = []
    for game in sorted(games, key=lambda g: (g["date"], g["id"])):
        members = qualified(game)
        if members is None:
            continue
        for side, other in (("home", "away"), ("away", "home")):
            for p in members[game[side]["slug"]]:
                result.append(
                    dict(
                        p,
                        game=game["id"],
                        date=game["date"],
                        home=float(side == "home"),
                        opposition=exposure(p["pos"], members[game[other]["slug"]]),
                    )
                )
    return result


def dictionary(obs):
    return {p: j for j, p in enumerate(sorted({r["player"] for r in obs}))}


def training_matrix(obs, players, joint):
    from scipy.sparse import coo_matrix

    row, col, data = [], [], []
    for i, r in enumerate(obs):
        if r["pos"] not in DEPTH:
            continue
        group = list(DEPTH).index(r["pos"]) + (3 if r["cohort"] == "bench" else 0)
        values = {group: 1.0, 6: float(r["home"])}
        if r["player"] in players:
            values[7 + players[r["player"]]] = 1.0
        if joint:
            for person, weight in r["opposition"].items():
                if person in players:
                    j = 7 + players[person]
                    values[j] = values.get(j, 0.0) - weight
        for j, value in sorted(values.items()):
            if value:
                row.append(i)
                col.append(j)
                data.append(value)
    return coo_matrix((data, (row, col)), shape=(len(obs), 7 + len(players))).tocsr()


def objective(beta, x, counts, penalty):
    from scipy.special import expit

    n, wins = counts.sum(axis=1), counts[:, 0]
    linear = x @ beta
    loss = np.sum(n * np.logaddexp(0.0, linear) - wins * linear) + 0.5 * np.dot(penalty, beta**2)
    gradient = np.asarray(x.T @ (n * expit(linear) - wins)) + penalty * beta
    return float(loss), gradient


def fit(x, counts):
    from scipy.optimize import minimize

    if counts.shape != (x.shape[0], 2) or not np.isfinite(counts).all() or (counts < 0).any():
        raise ValueError("Only finite nonnegative training counts accepted")
    if not (counts.sum(axis=0) > 0).all():
        raise ValueError("Both training outcome counts required")
    initial = np.zeros(x.shape[1])
    for group in range(6):
        selected = np.asarray(x[:, group].toarray()).ravel() == 1
        wins, losses = counts[selected].sum(axis=0)
        initial[group] = np.log((wins + 1) / (losses + 1))
    penalty = np.r_[np.full(7, 0.01), np.full(x.shape[1] - 7, 5.0)]
    result = minimize(
        objective,
        initial,
        args=(x, counts, penalty),
        method="L-BFGS-B",
        jac=True,
        options=dict(maxiter=2000, gtol=1e-7, ftol=1e-12),
    )
    if not result.success or not np.isfinite(result.x).all():
        raise ValueError("Fixed solver failed: " + str(result.message))
    return result.x, dict(
        iterations=int(result.nit),
        evaluations=int(result.nfev),
        objective=float(result.fun),
        maxGradient=float(np.max(np.abs(result.jac))),
        solverMessage=str(result.message),
        zeroDuelRows=int((counts.sum(axis=1) == 0).sum()),
    )


def projections(rows, games, features):
    history = defaultdict(list)
    indexed = {g["id"]: g for g in games}
    if len(indexed) != len(games):
        raise ValueError("Duplicate fixture")
    for g in sorted(games, key=lambda g: (g["date"], g["id"])):
        available = moment(g["date"]) + timedelta(hours=48)
        for side in ("home", "away"):
            club = g[side]["slug"]
            history[club].append((available, g))
    times = {c: [at for at, _ in h] for c, h in history.items()}
    cached, qualified_past, result = {}, {}, []
    for row in rows:
        fixture, lock = indexed[row["game"]], cutoff_for(row["date"])
        if fixture["date"] != row["date"]:
            raise ValueError("Fixture date differs")
        home = float(row["x"][features.index("home")])
        if home not in (0.0, 1.0):
            raise ValueError("Frozen home indicator invalid")
        club = fixture["away" if home else "home"]["slug"]
        key = club, lock, row["pos"]
        if key not in cached:
            end = bisect_left(times[club], lock)
            last = []
            for _, game in history[club][max(0, end - 3) : end]:
                if game["id"] not in qualified_past:
                    qualified_past[game["id"]] = qualified(game)
                members = qualified_past[game["id"]]
                last.append(None if members is None else members[club])
            people, seen = {}, {}
            # An incomplete selected game is not silently dropped to extend history.
            complete = bool(last) and all(members is not None for members in last)
            if complete:
                for members in last:
                    for p in members:
                        seen[p["player"]] = p["pos"]
                        people[p["player"]] = people.get(p["player"], 0.0) + p["minutes"] / len(last)
            projected = [dict(player=p, minutes=m, pos=seen[p]) for p, m in sorted(people.items())]
            cached[key] = dict(
                opposition=exposure(row["pos"], projected),
                selectedGames=len(last),
                knownGames=len(last) if complete else 0,
            )
        result.append(dict(player=row["player"], pos=row["pos"], cohort=row["cohort"], home=home, **cached[key]))
    return result


def main():
    sys.path.insert(0, str(Path("data/raw/formula-packages").resolve()))
    import scipy
    from scipy.special import expit
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    root, reports = Path("data/raw/score-foundation"), Path("reports/experiments")
    plan = reports / "laliga_score_opposition_strength.plan.json"
    source = json.loads((root / "cases.json").read_text())
    native = Path("C:/Users/Yaya/Desktop/PROJECTS/FixtureDiff/backend/data/raw/sorare_games.jsonl")
    raw = native.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Native source differs")
    games = [json.loads(v) for v in raw.decode().splitlines() if v.strip()]
    # No target score/event label is accessed by this headroom stage.
    rows = source["rows"]
    if len(rows) != 38850:
        raise ValueError("Full original cases changed")
    with np.load(root / "matchup_features.npz") as z:
        if str(z["key"]) != MATCHUP_KEY:
            raise ValueError("Original matchup inputs differ")
        matchup, names = z["x"], z["names"].tolist()
    projected_duels = (
        (matchup[:, names.index("own_duel_won90")] + matchup[:, names.index("own_duel_lost90")])
        * np.array([r["x"][source["features"].index(r["cohort"] + "_3_minutes")] for r in rows])
        / 90
    )
    key = hashlib.sha256(
        Path(__file__).read_bytes()
        + plan.read_bytes()
        + source["key"].encode()
        + scipy.__version__.encode()
        + NATIVE_SHA.encode()
        + MATCHUP_KEY.encode()
    ).hexdigest()
    report = dict(
        implementationKey=key,
        sourceKey=source["key"],
        nativeSHA=NATIVE_SHA,
        matchupKey=MATCHUP_KEY,
        scipyVersion=scipy.__version__,
        periods={},
        scope="Earlier pre-outcome prediction movement only; no xScore accuracy inference",
        later2026="Not fitted or evaluated",
        targetLabelsAccessed=False,
    )
    for phase, begin, end in PHASES:
        selected = np.array([begin <= r["date"] < end for r in rows])
        rr = [r for r, yes in zip(rows, selected, strict=True) if yes]
        lock = min(cutoff_for(r["date"]) for r in rr)
        past = [g for g in games if g["date"] < begin and moment(g["date"]) + timedelta(hours=48) < lock]
        obs = observations(past)
        players = dictionary(obs)
        counts = np.array([r["counts"] for r in obs], float)
        forecast = projections(rr, games, source["features"])
        probabilities, estimates, solvers = {}, {}, {}
        for arm, joint in (("baseline", False), ("opposition", True)):
            train = training_matrix(obs, players, joint)
            beta, solver = fit(train, counts)
            probabilities[arm] = expit(training_matrix(forecast, players, joint) @ beta)
            estimates[arm], solvers[arm] = beta, solver
            print(
                json.dumps(dict(phase=phase, arm=arm, fitCases=len(obs), players=len(players), solver=solver)),
                flush=True,
            )
        delta = probabilities["opposition"] - probabilities["baseline"]
        points = 3.5 * projected_duels[selected] * delta
        summary = {}
        for cohort in ("start", "bench"):
            defend = np.array([r["cohort"] == cohort and r["pos"] == "DEF" for r in rr])
            values = np.abs(points[defend])
            known = np.isfinite(values)
            summary[cohort] = dict(
                cases=sum(r["cohort"] == cohort for r in rr),
                defenderCases=int(defend.sum()),
                knownProjectedDuelCases=int(known.sum()),
                coldOpponentCases=sum(
                    r["cohort"] == cohort and not f["knownGames"] for r, f in zip(rr, forecast, strict=True)
                ),
                absolutePointShiftQuantiles=np.quantile(values[known], [0.5, 0.9, 0.95, 0.99, 1]).tolist(),
                overOnePointCases=int((values >= 1).sum()),
            )
        path = root / f"laliga_score_opposition_strength_{phase}.npz"
        np.savez_compressed(
            path,
            key=key,
            selected=selected,
            baseline=probabilities["baseline"],
            opposition=probabilities["opposition"],
            point_shift=points,
            projected_duels=projected_duels[selected],
            baseline_beta=estimates["baseline"],
            opposition_beta=estimates["opposition"],
            players=np.array(list(players)),
            known_games=np.array([r["knownGames"] for r in forecast]),
            training_game=np.array([r["game"] for r in obs]),
            training_player=np.array([r["player"] for r in obs]),
        )
        report["periods"][phase] = dict(
            firstLock=lock.isoformat(),
            fitGames=len(past),
            qualifiedFitGames=len(set(r["game"] for r in obs)),
            fitCases=len(obs),
            players=len(players),
            targets=len(rr),
            solvers=solvers,
            cohorts=summary,
            artifact=str(path),
            artifactSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        )
        (reports / "laliga_score_opposition_strength.json").write_text(json.dumps(report, indent=2) + "\n")
    report["pruneForInsufficientMovement"] = all(
        period["cohorts"]["start"]["absolutePointShiftQuantiles"][-1] < 1 for period in report["periods"].values()
    )
    report["nextStep"] = (
        "Retire this additive correction route"
        if report["pruneForInsufficientMovement"]
        else "Independent source/design/time audit, then separately register proper duel-loss gate"
    )
    (reports / "laliga_score_opposition_strength.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
