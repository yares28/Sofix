"""Testing only: shared low-rank player/opponent and team/opponent score-window patterns."""

from __future__ import annotations

import numpy as np

from app.research.score_pooled_windows import CENTRES, Normaliser, targets
from app.research.score_windows import window_centres

PARAMETERS = {
    f"rank{r}_penalty{name}": dict(rank=r, width=32, ridge=w, embedding_ridge=e)
    for r in (4, 8)
    for name, w, e in (("light", 0.0001, 0.001), ("strong", 0.001, 0.01))
}
PARAMETERS.update(
    {
        f"numeric_penalty{name}": dict(rank=4, width=32, ridge=w, embedding_ridge=e, use_identities=False)
        for name, w, e in (("light", 0.0001, 0.001), ("strong", 0.001, 0.01))
    }
)
EMBEDDINGS = ("E_player", "E_team", "E_opponent")


def category_key(value):
    if value is None or isinstance(value, (float, np.floating)) and not np.isfinite(value):
        return None
    result = str(value)
    return result if result else None


class CategoryEncoder:
    def fit(self, raw):
        raw = np.asarray(raw, dtype=object)
        if raw.ndim != 2 or raw.shape[1] != 3 or not len(raw):
            raise ValueError("Three matched training fixture identities required")
        self.maps_ = []
        for j in range(3):
            keys = {category_key(v) for v in raw[:, j]}
            keys.discard(None)
            self.maps_.append({k: i + 1 for i, k in enumerate(sorted(keys))})
        return self

    def transform(self, raw):
        raw = np.asarray(raw, dtype=object)
        if raw.ndim != 2 or raw.shape[1] != 3:
            raise ValueError("Three forecast fixture identities required")
        return np.array(
            [[self.maps_[j].get(category_key(v), 0) for j, v in enumerate(row)] for row in raw], dtype=np.int64
        )


def initial_weights(features, sizes, rank, width, seed):
    rng = np.random.default_rng(seed)
    weights = {"W": rng.normal(0, 1 / np.sqrt(features), (features, width)).astype(np.float32)}
    for name, size in zip(EMBEDDINGS, sizes, strict=True):
        weights[name] = rng.normal(0, 0.05, (size + 1, rank)).astype(np.float32)
        weights[name][0] = 0
    for name in ("U_player", "U_team", "U_opponent", "U_po", "U_to"):
        weights[name] = rng.normal(0, 1 / np.sqrt(rank), (rank, width)).astype(np.float32)
    weights["b_hidden"] = np.zeros(width, dtype=np.float32)
    weights["V"] = rng.normal(0, 0.01, (width, len(CENTRES))).astype(np.float32)
    weights["b_output"] = np.zeros(len(CENTRES), dtype=np.float32)
    return weights


def initial_output_bias(scores):
    labels = targets(scores)
    frequency = (labels.sum(axis=0) + 1) / (len(labels) + 2)
    return np.log(frequency / (1 - frequency)).astype(np.float32)


def selected_vectors(ids, weights):
    return [np.where(ids[:, j, None] > 0, weights[name][ids[:, j]], 0) for j, name in enumerate(EMBEDDINGS)]


def forward(x, ids, weights):
    p, t, o = selected_vectors(ids, weights)
    hidden = np.tanh(
        x @ weights["W"]
        + p @ weights["U_player"]
        + t @ weights["U_team"]
        + o @ weights["U_opponent"]
        + (p * o) @ weights["U_po"]
        + (t * o) @ weights["U_to"]
        + weights["b_hidden"]
    )
    logits = hidden @ weights["V"] + weights["b_output"]
    probability = np.exp(-np.logaddexp(0, -logits))
    return hidden, logits, probability


def loss_gradient(x, ids, labels, weights, ridge, embedding_ridge):
    hidden, logits, probability = forward(x, ids, weights)
    loss = float((np.logaddexp(0, logits) - labels * logits).mean())
    delta = (probability - labels) / (len(x) * labels.shape[1])
    back = (delta @ weights["V"].T) * (1 - hidden**2)
    p, t, o = selected_vectors(ids, weights)
    grad = {
        "W": x.T @ back,
        "b_hidden": back.sum(axis=0),
        "V": hidden.T @ delta,
        "b_output": delta.sum(axis=0),
        "U_player": p.T @ back,
        "U_team": t.T @ back,
        "U_opponent": o.T @ back,
        "U_po": (p * o).T @ back,
        "U_to": (t * o).T @ back,
    }
    pair_po, pair_to = back @ weights["U_po"].T, back @ weights["U_to"].T
    contributions = [
        back @ weights["U_player"].T + pair_po * o,
        back @ weights["U_team"].T + pair_to * o,
        back @ weights["U_opponent"].T + pair_po * p + pair_to * t,
    ]
    for j, name in enumerate(EMBEDDINGS):
        grad[name] = np.zeros_like(weights[name])
        np.add.at(grad[name], ids[:, j], contributions[j])
        grad[name][0] = 0
    for name, value in weights.items():
        if name.startswith("b_"):
            continue
        if name in EMBEDDINGS:
            loss += 0.5 * embedding_ridge * (value[1:] ** 2).sum()
            grad[name][1:] += embedding_ridge * value[1:]
        else:
            loss += 0.5 * ridge * (value**2).sum()
            grad[name] += ridge * value
    return float(loss), grad


class InteractionNetwork:
    def __init__(
        self,
        rank,
        width=32,
        ridge=0.0001,
        embedding_ridge=0.001,
        epochs=80,
        batch=256,
        seed=20261105,
        use_identities=True,
    ):
        self.rank, self.width, self.ridge, self.embedding_ridge = rank, width, ridge, embedding_ridge
        self.epochs, self.batch, self.seed = epochs, batch, seed
        self.use_identities = use_identities

    def fit(self, raw, categories, scores):
        raw = np.asarray(raw, dtype=float)
        categories = np.asarray(categories, dtype=object)
        if not self.use_identities:
            categories = np.full(categories.shape, None, dtype=object)
        if self.epochs <= 0 or self.batch <= 0 or self.rank <= 0 or self.width <= 0:
            raise ValueError("Positive interaction dimensions and training schedule required")
        self.normaliser_ = Normaliser().fit(raw, np.ones(len(raw)))
        self.encoder_ = CategoryEncoder().fit(categories)
        x, ids = self.normaliser_.transform(raw), self.encoder_.transform(categories)
        labels = targets(scores).astype(np.float32)
        if len(x) != len(ids) or len(x) != len(labels):
            raise ValueError("Matched native interaction inputs and score labels required")
        sizes = [len(m) for m in self.encoder_.maps_]
        self.weights_ = initial_weights(x.shape[1], sizes, self.rank, self.width, self.seed)
        self.weights_["b_output"] = initial_output_bias(scores)
        means = {n: np.zeros_like(w) for n, w in self.weights_.items()}
        squares = {n: np.zeros_like(w) for n, w in self.weights_.items()}
        rng = np.random.default_rng(self.seed)
        history = []
        step = 0
        for epoch in range(self.epochs):
            order = rng.permutation(len(x))
            total = 0.0
            for begin in range(0, len(x), self.batch):
                at = order[begin : begin + self.batch]
                loss, grad = loss_gradient(x[at], ids[at], labels[at], self.weights_, self.ridge, self.embedding_ridge)
                if not np.isfinite(loss) or any(not np.isfinite(g).all() for g in grad.values()):
                    raise ValueError("Interaction-window optimization became nonfinite")
                step += 1
                for n, g in grad.items():
                    means[n] = 0.9 * means[n] + 0.1 * g
                    squares[n] = 0.999 * squares[n] + 0.001 * g**2
                    self.weights_[n] -= (
                        0.001 * (means[n] / (1 - 0.9**step)) / (np.sqrt(squares[n] / (1 - 0.999**step)) + 1e-8)
                    )
                for name in EMBEDDINGS:
                    self.weights_[name][0] = 0
                total += loss * len(at)
            history.append(total / len(x))
            if (epoch + 1) % 40 == 0:
                print(f"INTERACTION_EPOCH {epoch + 1}/{self.epochs} loss{history[-1]:.6f}", flush=True)
        self.history_ = np.array(history)
        self.statistics_ = dict(
            epochs=self.epochs,
            fitRows=len(x),
            rawFeatures=raw.shape[1],
            normalisedFeatures=x.shape[1],
            rank=self.rank,
            width=self.width,
            ridge=self.ridge,
            embeddingRidge=self.embedding_ridge,
            seed=self.seed,
            batch=self.batch,
            categorySizes=sizes,
            useIdentities=self.use_identities,
            steps=step,
            lossFirst=history[0],
            lossLast=history[-1],
            lossLastTenMean=float(np.mean(history[-10:])),
        )
        return self

    def predict_mass(self, raw, categories):
        if not self.use_identities:
            categories = np.full(np.asarray(categories).shape, None, dtype=object)
        x, ids = self.normaliser_.transform(raw), self.encoder_.transform(categories)
        if len(x) != len(ids):
            raise ValueError("Matched forecast feature and identity rows required")
        mass = forward(x, ids, self.weights_)[2]
        if mass.shape != (len(raw), 201) or not np.isfinite(mass).all() or (mass < 0).any() or (mass > 1).any():
            raise ValueError("Complete finite native overlapping window probabilities required")
        return mass

    def predict(self, raw, categories):
        return window_centres(self.predict_mass(raw, categories), CENTRES)
