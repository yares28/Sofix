import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from app.research.score_direct_window_resume import snapshot_fit


@pytest.mark.parametrize("safe", [False, True])
def test_snapshot_execution_and_reloading_match_fresh_parent_probabilities(tmp_path, monkeypatch, safe):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    import pandas as pd

    if safe:
        from app.research import score_direct_windows_bench_safe as parent
    else:
        from app.research import score_direct_windows as parent
    monkeypatch.setitem(parent.MODELS, "snapshot_probe", (2, 80, 20))
    scores = np.tile([40.0, 80.0], 40) if safe else np.tile(np.arange(101, dtype=float), 2)
    frame = pd.DataFrame({"who": np.tile(["a", "b"], len(scores) // 2), "numeric": np.arange(len(scores)) % 3})
    mask = {"fit": np.arange(len(scores)) < len(scores) - 20, "target": np.arange(len(scores)) >= len(scores) - 20}
    original = parent.fit_windows(frame, ["who"], scores, mask, "snapshot_probe", tmp_path / "original.npz", "toy-only")
    cache = tmp_path / "snapshot.npz"
    unique = hashlib.sha256(str(tmp_path).encode()).hexdigest()[:12]
    root = Path(__file__).parents[1] / "data/raw/dw-tests" / unique
    first = snapshot_fit(
        parent, frame, ["who"], scores, mask, "snapshot_probe", cache, "toy-only", root, safe=safe, keep_snapshot=True
    )
    np.testing.assert_allclose(first, original, rtol=0, atol=1e-12)
    snap = next(root.glob("*/*/fit.snapshot"))
    assert snap.exists() and snap.stat().st_size > 0
    cache.unlink()
    repeated = snapshot_fit(parent, frame, ["who"], scores, mask, "snapshot_probe", cache, "toy-only", root, safe=safe)
    np.testing.assert_allclose(repeated, original, rtol=0, atol=1e-12)
    receipt = json.loads((snap.parent / "execution.json").read_text())
    assert receipt["snapshotExistedAtStart"] and receipt["completed"]
    assert not snap.exists()


def test_snapshot_adapter_rejects_wrong_existing_probability_cache(tmp_path):
    from app.research import score_direct_windows as parent

    path = tmp_path / "wrong.npz"
    np.savez_compressed(path, key="wrong", probability=np.zeros((1, 101)))
    with pytest.raises(ValueError, match="differs"):
        snapshot_fit(
            parent,
            None,
            [],
            None,
            {"fit": np.array([True]), "target": np.array([True])},
            "unused",
            path,
            "expected",
            tmp_path / "snapshots",
        )
