"""Testing only: latent score-state persistence with exact native score windows."""

from __future__ import annotations

import numpy as np

CENTRES = np.arange(101, dtype=float)
PARAMETERS = {
    f"states{k}_prior{prior}_history{history}": (k, prior, history)
    for k in (2, 4, 6)
    for prior in (1, 20)
    for history in (5, 20)
}


def distribution(values, axis=-1):
    values = np.maximum(values, 1e-8)
    return values / values.sum(axis=axis, keepdims=True)


def score_bins(scores):
    values = np.asarray(scores, dtype=float)
    if not np.isfinite(values).all() or ((values < 0) | (values > 100)).any():
        raise ValueError("Historical scores must be known within0..100")
    return np.floor(values / 5).astype(int)


def padded(sequences):
    lengths = np.array([len(s) for s in sequences])
    if not len(lengths) or (lengths == 0).any():
        raise ValueError("Training sequences must contain known observations")
    observed = np.zeros((len(lengths), lengths.max()), dtype=int)
    valid = np.arange(lengths.max())[None, :] < lengths[:, None]
    for i, seq in enumerate(sequences):
        observed[i, : len(seq)] = score_bins(seq)
    return observed, valid


class HiddenScores:
    def __init__(self, states=2, transition_prior=20, emission_prior=20, max_iter=80, tolerance=1e-6):
        self.states = states
        self.transition_prior = transition_prior
        self.emission_prior = emission_prior
        self.max_iter, self.tolerance = max_iter, tolerance

    def expectation(self, observed, valid):
        n, length = observed.shape
        emitted = np.where(valid[:, :, None], self.emission_[:, observed].transpose(1, 2, 0), 1)
        alpha, beta = np.empty((n, length, self.states)), np.ones((n, length, self.states))
        scale = np.ones((n, length))
        initial = self.initial_[None, :] * emitted[:, 0]
        scale[:, 0] = initial.sum(axis=1)
        alpha[:, 0] = initial / scale[:, 0, None]
        for t in range(1, length):
            step = (alpha[:, t - 1] @ self.transition_) * emitted[:, t]
            scale[:, t] = np.where(valid[:, t], step.sum(axis=1), 1)
            alpha[:, t] = np.where(valid[:, t, None], step / scale[:, t, None], alpha[:, t - 1])
        transitions = np.zeros((self.states, self.states))
        for t in range(length - 2, -1, -1):
            next_term = emitted[:, t + 1] * beta[:, t + 1]
            step = (next_term @ self.transition_.T) / scale[:, t + 1, None]
            beta[:, t] = np.where(valid[:, t + 1, None], step, 1)
            xi = alpha[:, t, :, None] * self.transition_[None, :, :] * next_term[:, None, :]
            xi /= scale[:, t + 1, None, None]
            transitions += np.where(valid[:, t + 1, None, None], xi, 0).sum(axis=0)
        posterior = alpha * beta
        posterior /= posterior.sum(axis=2, keepdims=True)
        posterior = np.where(valid[:, :, None], posterior, 0)
        return posterior, transitions, float(np.log(scale[valid]).sum())

    def fit(self, sequences):
        observed, valid = padded(sequences)
        scores = np.concatenate([np.asarray(s, dtype=float) for s in sequences])
        global_bins = distribution(np.bincount(observed[valid], minlength=21).astype(float))
        locations = np.quantile(scores, np.linspace(0.1, 0.9, self.states))
        bin_centres = np.minimum(100, np.arange(21) * 5 + 2.5)
        self.emission_ = distribution(
            global_bins[None, :] * np.exp(-0.5 * ((bin_centres[None, :] - locations[:, None]) / 16) ** 2)
        )
        self.transition_ = 0.6 * np.eye(self.states) + np.full((self.states, self.states), 0.4 / self.states)
        self.initial_ = np.full(self.states, 1 / self.states)
        likelihoods, converged = [], False
        for _ in range(self.max_iter):
            posterior, transitions, likelihood = self.expectation(observed, valid)
            likelihoods.append(likelihood)
            if len(likelihoods) >= 5 and abs(likelihoods[-1] - likelihoods[-2]) <= self.tolerance * (
                1 + abs(likelihoods[-2])
            ):
                converged = True
                break
            state_frequency = posterior.sum(axis=(0, 1)) / valid.sum()
            self.transition_ = distribution(transitions + self.transition_prior * state_frequency[None, :])
            self.initial_ = distribution(posterior[:, 0].sum(axis=0) + self.emission_prior * state_frequency)
            counts = np.array(
                [
                    np.bincount(observed[valid], weights=posterior[:, :, k][valid], minlength=21)
                    for k in range(self.states)
                ]
            )
            self.emission_ = distribution(counts + self.emission_prior * global_bins[None, :])
        posterior, transitions, likelihood = self.expectation(observed, valid)
        responsibility = posterior[valid]
        hits = (np.abs(scores[:, None] - CENTRES[None, :]) <= 7).astype(float)
        self.windows_ = (responsibility.T @ hits + self.emission_prior * hits.mean(axis=0)[None, :]) / (
            responsibility.sum(axis=0)[:, None] + self.emission_prior
        )
        if not np.allclose(transitions.sum(), valid.sum() - len(sequences)):
            raise ValueError("Hidden-state transition support differs")
        self.statistics_ = {
            "states": self.states,
            "sequences": len(sequences),
            "observations": int(valid.sum()),
            "iterations": len(likelihoods),
            "converged": converged,
            "logLikelihood": likelihood,
            "transitionMinimum": float(self.transition_.min()),
        }
        return self

    def predict(self, histories):
        state = np.broadcast_to(self.initial_, (len(histories), self.states)).copy()
        for t in range(max(map(len, histories), default=0)):
            active = np.array([len(h) > t for h in histories])
            bins = score_bins([h[t] for h in histories if len(h) > t])
            posterior = state[active] * self.emission_[:, bins].T
            posterior /= posterior.sum(axis=1, keepdims=True)
            state[active] = posterior @ self.transition_
        result = state @ self.windows_
        if not np.isfinite(result).all() or (result < 0).any() or (result > 1 + 1e-12).any():
            raise ValueError("Invalid hidden-state score-window mass")
        return result
