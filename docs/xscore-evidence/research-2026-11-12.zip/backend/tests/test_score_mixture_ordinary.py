from pathlib import Path

import numpy as np

from app.research.score_mixture_ordinary import MixtureNetwork, fit_forecasts, loss_gradient, mixture_mass
from app.research.score_modal_trees import CENTRES
from app.research.score_windows import window_centres


def test_every_mixture_gradient_matches_finite_differences():
    rng = np.random.default_rng(73)
    x = rng.normal(size=(4, 2))
    aa = np.array([-10.0, 0.0, 14.0, 35.0])
    weights = [rng.normal(0, 0.2, (2, 3)), rng.normal(0, 0.1, 3), rng.normal(0, 0.2, (3, 6)), rng.normal(0, 0.1, 6)]
    _, gradients = loss_gradient(x, aa, weights, 2, 0.01)
    for w, gradient in zip(weights, gradients, strict=True):
        for index in np.ndindex(w.shape):
            old = w[index]
            w[index] = old + 1e-5
            high = loss_gradient(x, aa, weights, 2, 0.01)[0]
            w[index] = old - 1e-5
            low = loss_gradient(x, aa, weights, 2, 0.01)[0]
            w[index] = old
            np.testing.assert_allclose(gradient[index], (high - low) / 2e-5, rtol=1e-5, atol=1e-7)


def test_two_density_peaks_choose_real_score_instead_of_the_average(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    mass = mixture_mass(np.array([[0.6, 0.4]]), np.array([[5.0, 45.0]]), np.array([[2.0, 2.0]]), 35)
    prediction = window_centres(mass, CENTRES)[0]
    assert abs(prediction - 40) <= 7 and abs(prediction - 56) > 7
    assert np.isfinite(mass).all() and ((mass >= 0) & (mass <= 1)).all()


def test_analytical_windows_match_independent_normal_cdf_floor_and_cap(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from scipy.stats import norm

    weights = np.array([[0.3, 0.7]])
    means = np.array([[-30.0, 50.0]])
    scales = np.array([[5.0, 20.0]])
    for level in (0, 35, 60, 100):
        mass = mixture_mass(weights, means, scales, level)[0]
        floor = level if level >= 60 else 0
        for i, centre in enumerate(CENTRES):
            lower, upper = centre - 7, centre + 7
            expected = 0.0
            if upper >= floor:
                for w, mu, sd in zip(weights[0], means[0], scales[0], strict=True):
                    lo = 0 if lower <= floor else norm.cdf(lower - level, loc=mu, scale=sd)
                    hi = 1 if upper >= 100 else norm.cdf(upper - level, loc=mu, scale=sd)
                    expected += w * max(0, hi - lo)
            np.testing.assert_allclose(mass[i], expected, atol=1e-12)


def test_actual_mixture_fit_excludes_target_labels_and_preserves_all_cases(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    rng = np.random.default_rng(68)
    x = rng.normal(size=(100, 3))
    x[::7, 0] = np.nan
    aa = rng.normal(10, 9, 100)
    levels = np.full(100, 35.0)
    positions = np.array(["DEF"] * 95 + ["GK"] * 5)
    fit = np.arange(100) < 80
    target = ~fit
    classes = np.array([35.0, 60.0])
    p = np.tile([0.8, 0.2], (20, 1))
    setting = {"components": 2, "width": 4, "ridge": 0.01}
    first, stats = fit_forecasts(x, aa, levels, positions, fit, target, classes, p, setting, epochs=3)
    aa[target] = np.nan
    levels[target] = np.nan
    repeated, newstats = fit_forecasts(x, aa, levels, positions, fit, target, classes, p, setting, epochs=3)
    np.testing.assert_equal(first, repeated)
    assert stats == newstats and first.shape == (20, 201) and np.isfinite(first).all()


def test_constant_native_aa_does_not_collapse_the_density_or_drop_outputs():
    model = MixtureNetwork(2, 4, 0.01, epochs=3).fit(np.ones((40, 2)), np.full(40, 10.0))
    weights, means, scales = model.predict(np.ones((3, 2)))
    assert weights.shape == (3, 2) and np.allclose(weights.sum(axis=1), 1)
    assert np.isfinite(means).all() and ((scales >= 2) & (scales <= 40)).all()
