from fractions import Fraction

import numpy as np

from app.research import score_duel_miss_decomposition as duel


def test_duel_point_identity_with_volume_share_and_interaction():
    result = duel.decompose(10, 0.5, 9, 3)
    assert result["actualPoints"] == 7.5
    assert result["baselinePoints"] == -2.5
    np.testing.assert_allclose(sum(result[k] for k in ("volume", "winshare", "interaction")), 10)
    np.testing.assert_allclose(result["symmetricVolume"] + result["symmetricWinshare"], 10)


def test_zero_target_duels_keep_winning_fraction_unknown_without_division():
    result = duel.decompose(10, 0.5, 0, 0)
    assert result["actualWinningFraction"] is None
    assert result["winshare"] is None and result["interaction"] is None
    assert result["volume"] == 2.5 and result["winmixResidual"] == 0


def test_volume_can_cancel_instead_of_increasing_duel_points():
    neutral = duel.decompose(10, 2 / 3.5, 12, 8)
    assert abs(neutral["volume"]) < 1e-10
    assert abs(neutral["symmetricWinshare"]) > abs(neutral["symmetricVolume"])


def test_exact_seven_point_swing_is_inclusive_despite_float_rounding():
    result = duel.decompose(Fraction(29, 3), Fraction(17, 29), 1, 4)
    assert result["meaningfulPointShift"]
    assert result["exactPointShift"] == "-7"
