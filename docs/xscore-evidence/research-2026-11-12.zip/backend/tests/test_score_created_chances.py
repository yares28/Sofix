import numpy as np

from app.research.score_created_chances import created_metrics, link_chances


def chance(minute=3, second=40, receiver="Shooter", **kwargs):
    return {
        "team": "home",
        "player": "Passer",
        "recv": receiver,
        "min": minute,
        "sec": second,
        "key": True,
        "assist": False,
        "ok": True,
        **kwargs,
    }


def shot(minute=3, second=43, player="Shooter", **kwargs):
    return {
        "team": "home",
        "player": player,
        "min": minute,
        "sec": second,
        "goal": False,
        "big": False,
        "xg": 0.99,
        "xg_fotmob": 0.4,
        **kwargs,
    }


def test_only_native_quality_is_credited_to_the_explicit_passer_receiver_link():
    passes, shots = [chance()], [shot()]
    links, audit = link_chances(passes, shots)
    assert links == {0: 0}
    assert audit["linked"] == 1
    values = created_metrics(passes, shots, links, [0], 90)
    assert values["created_quality90"] == values["created_known_quality90"] == 0.4
    assert values["created_chances90"] == 1


def test_missing_native_quality_stays_unknown_even_if_an_own_model_value_exists():
    passes, shots = [chance()], [shot(xg_fotmob=None)]
    links, _ = link_chances(passes, shots)
    values = created_metrics(passes, shots, links, [0], 90)
    assert np.isnan(values["created_quality90"])
    assert values["created_known_quality90"] == values["created_provider_fraction"] == 0
    shots[0]["xg_fotmob"] = 0
    assert created_metrics(passes, shots, links, [0], 90)["created_quality90"] == 0


def test_ambiguous_receiver_team_clock_and_intervening_pass_do_not_become_guesses():
    cases = [
        ([chance(receiver=None)], [shot()]),
        ([chance()], [shot(team="away")]),
        ([chance()], [shot(second=1, minute=4)]),
        ([chance(team=None)], [shot(team=None)]),
        ([chance(receiver="")], [shot(player="")]),
        ([chance(), chance()], [shot()]),
        ([chance(), chance(second=42, key=False, player="Other")], [shot()]),
        ([chance(assist=True)], [shot(goal=False)]),
    ]
    for passes, shots in cases:
        links, _ = link_chances(passes, shots)
        assert links == {}


def test_single_chance_pass_cannot_be_used_again_for_a_rebound_shot():
    passes = [chance()]
    shots = [shot(second=43), shot(second=45)]
    links, _ = link_chances(passes, shots)
    assert links == {0: 0}


def test_known_no_chances_is_zero_and_missing_event_stream_is_unknown():
    values = created_metrics([], [], {}, [], 90)
    assert values["created_quality90"] == 0 and values["created_provider_fraction"] == 1
    unknown = created_metrics(None, None, {}, [], 90)
    assert all(np.isnan(v) for v in unknown.values())


def test_missing_pass_flags_are_unknown_and_boundary_twenty_seconds_is_valid():
    passes, shots = [chance()], [shot(minute=4, second=0)]
    links, _ = link_chances(passes, shots)
    assert links == {0: 0}
    del passes[0]["key"]
    assert all(np.isnan(v) for v in created_metrics(passes, shots, links, [0], 90).values())


def test_future_and_exact_embargo_observations_cannot_change_lag_inputs():
    from datetime import timedelta

    from app.research.score_created_chances import FIELDS
    from app.research.score_created_chances_build import lag_features
    from app.research.score_search import cutoff_for

    row = {"date": "2026-01-10T18:00:00Z", "player": "a", "cohort": "start", "game": "g"}
    lock = cutoff_for(row["date"])
    games = {"g": {"players": {"a": {"team": "club"}}}}
    old = {
        "date": (lock - timedelta(days=4)).isoformat(),
        "player": "a",
        "cohort": "start",
        "minutes": 90,
        "club": "club",
        "values": dict.fromkeys(FIELDS, 0.25),
    }
    boundary = {**old, "date": (lock - timedelta(hours=48)).isoformat(), "values": dict.fromkeys(FIELDS, 99)}
    future = {**boundary, "date": row["date"]}
    before, names = lag_features([row], [old], games)
    after, _ = lag_features([row], [old, boundary, future], games)
    np.testing.assert_equal(before, after)
    assert before[0, names.index("same_3_created_quality90_mean")] == 0.25
    assert before[0, names.index("same_3_source_games")] == 1


def test_rate_only_ablation_excludes_partial_lower_bounds_and_coverage():
    from app.research.score_created_chances_run import component_policy, feature_groups

    names = [
        "same_3_created_quality90_mean",
        "same_3_created_known_quality90_mean",
        "same_3_created_quality90_count",
        "same_3_created_provider_fraction_mean",
        "all_10_created_chances90_mean",
        "last_source_same_club",
    ]
    groups = feature_groups(names)
    assert groups["creation_rates"].tolist() == [True, False, False, False, True, False]
    assert groups["creation_with_coverage"].all()
    old = (np.array([0, 1]), np.array([[0.9, 0.1]]), {0.5: np.array([[1, 2]])})
    new = (old[0].copy(), np.array([[0.6, 0.4]]), {0.5: np.array([[3, 4]])})
    events = component_policy(old, new, "events")
    ordinary = component_policy(old, new, "ordinary")
    assert events[1] is new[1] and events[2] is old[2]
    assert ordinary[1] is old[1] and ordinary[2] is new[2]
