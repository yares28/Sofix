"""Testing only: integrate conditional score distributions to choose one winning range."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.special import expit, ndtr

from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres


def cdf(z, family):
    if family == "normal":
        return ndtr(z)
    if family == "logistic":
        return expit(z)
    if family == "laplace":
        tail = 0.5 * np.exp(-np.abs(z))
        return np.where(z < 0, tail, 1 - tail)
    raise ValueError("Unknown distribution")


def interval_mass(centres, classes, location, spread, family):
    levels = np.asarray(classes).reshape(1, -1, 1)
    floor = np.where(levels >= 60, levels, 0)
    low, high = centres[None, None, :] - 7, centres[None, None, :] + 7
    lower = cdf((low - levels - location[:, :, None]) / spread[:, :, None], family)
    upper = cdf((high - levels - location[:, :, None]) / spread[:, :, None], family)
    lower = np.where(low <= floor, 0, lower)
    upper = np.where(high >= 100, 1, upper)
    return np.where(high < floor, 0, np.maximum(0, upper - lower))


def density_predictions(classes, probability, parts, family, multiplier, shift):
    if not np.isfinite(probability).all() or (probability < 0).any() or not np.allclose(probability.sum(axis=1), 1):
        raise ValueError("Invalid class probability rows")
    quantiles = np.sort(np.stack([parts[q] for q in (0.35, 0.5, 0.65)]), axis=0)
    if quantiles.shape[1:] != probability.shape or not np.isfinite(quantiles).all():
        raise ValueError("Conditional quantile shapes or values differ")
    divisor = {"normal": 0.7706409328151355, "logistic": 2 * np.log(0.65 / 0.35), "laplace": -2 * np.log(0.7)}[family]
    spread = np.clip((quantiles[2] - quantiles[0]) / divisor, 2, 40) * multiplier
    location = quantiles[1] + shift
    centres = np.arange(0, 100.01, 0.5)
    result = []
    for start in range(0, len(probability), 256):
        end = start + 256
        mass = interval_mass(centres, classes, location[start:end], spread[start:end], family)
        combined = np.einsum("nl,nlk->nk", probability[start:end], mass)
        result.append(window_centres(combined, centres))
    return np.concatenate(result)


def components(path, expected_key):
    with np.load(path) as stored:
        if str(stored["key"]) != expected_key:
            raise ValueError("Component cache identity differs")
        return stored["classes"], stored["probability"], {q: stored[f"q{q}"] for q in (0.35, 0.5, 0.65)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("cases", "component-report", "control", "cache", "out"):
        parser.add_argument("--" + arg, type=Path, required=True)
    parser.add_argument("--groups", nargs="+", required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text(encoding="utf-8"))
    component_report = json.loads(args.component_report.read_text(encoding="utf-8"))
    control = json.loads(args.control.read_text(encoding="utf-8"))
    if source["key"] != component_report["sourceKey"] or source["key"] != control["sourceKey"]:
        raise ValueError("Comparison source identity differs")
    key = hashlib.sha256(
        (source["key"] + component_report["implementationKey"]).encode() + Path(__file__).read_bytes()
    ).hexdigest()
    report = {
        "scope": "Testing only; no application/production changes",
        "target": "Actual score within7, all starts and played substitutes separately",
        "evidenceLimit": "Retrospective exploratory reuse, not fresh blind evidence",
        "sourceKey": source["key"],
        "implementationKey": key,
        "componentReport": str(args.component_report),
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        valid = np.array(["2025-07-01" <= r["date"] < "2026-01-01" for r in rows])
        test = np.array([r["date"] >= "2026-01-01" for r in rows])
        y = np.array([r["score"] for r in rows])
        selection = {"control": control["cohorts"][cohort]["selection"]["control"]}
        for group in args.groups:
            path = args.cache / f"feature_{args.component_report.stem}_{cohort}_{group}_selection.npz"
            classes, probability, parts = components(path, component_report["implementationKey"])
            if len(probability) != valid.sum():
                raise ValueError("Earlier component case count differs")
            candidates = []
            for family in ("normal", "logistic", "laplace"):
                for multiplier in (0.5, 0.75, 1, 1.5, 2):
                    for shift in (-6, -3, 0, 3, 6):
                        prediction = density_predictions(classes, probability, parts, family, multiplier, shift)
                        candidates.append(
                            {
                                "family": family,
                                "multiplier": multiplier,
                                "shift": shift,
                                "selection": measure(y[valid], prediction),
                            }
                        )
            winner = max(candidates, key=lambda c: (c["selection"]["within7"], -c["selection"]["mae"]))
            selection[group] = winner
            args.out.with_suffix(f".{cohort}.{group}.selection.json").write_text(
                json.dumps({"winner": winner, "candidates": candidates}, indent=2), encoding="utf-8"
            )
            print(f"Selected {cohort} {group}: " + json.dumps(winner), flush=True)
        chosen = max(selection, key=lambda g: (selection[g]["selection"]["within7"], -selection[g]["selection"]["mae"]))
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps({"chosen": chosen, "selection": selection}, indent=2), encoding="utf-8"
        )
        with np.load(args.cache / f"europe_predictions_{cohort}.npz") as stored:
            if not np.array_equal(stored["y"], y[test]):
                raise ValueError("Control cases differ")
            predictions = {"control": stored["control"]}
        for group in args.groups:
            path = args.cache / f"feature_{args.component_report.stem}_{cohort}_{group}_later.npz"
            classes, probability, parts = components(path, component_report["implementationKey"])
            spec = selection[group]
            predictions[group] = density_predictions(
                classes, probability, parts, spec["family"], spec["multiplier"], spec["shift"]
            )
        weeks = [r["week"] for r, yes in zip(rows, test, strict=True) if yes]
        positions = np.array([r["pos"] for r in rows])[test]
        result = {"chosen": chosen, "selection": selection, "groups": {}}
        for group, prediction in predictions.items():
            result["groups"][group] = {
                "later": measure(y[test], prediction),
                "weekly95": bootstrap(y[test], prediction, weeks),
                "gain95": paired_interval(y[test], prediction, predictions["control"], weeks),
                "highScoreGames": measure(y[test][y[test] >= 60], prediction[y[test] >= 60]),
                "positions": {
                    p: measure(y[test][positions == p], prediction[positions == p])
                    for p in POSITIONS
                    if (positions == p).any()
                },
            }
        np.savez_compressed(args.cache / f"{args.out.stem}_predictions_{cohort}.npz", key=key, y=y[test], **predictions)
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, "chosen": chosen, "groups": {g: v["later"] for g, v in result["groups"].items()}}
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
