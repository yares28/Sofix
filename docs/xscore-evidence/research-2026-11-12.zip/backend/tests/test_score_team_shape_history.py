"""Testing-only strict prelock shape/rotation/conditional-AA feature contracts."""

import copy

import numpy as np

from app.research import score_team_shape_history as shape


def game(identity, date, formation=(4, 3, 3), own_aa=0, home="A", away="B"):
    players, xi = {}, {}
    for side, prefix, club in (("home", "h", home), ("away", "a", away)):
        names = [prefix + str(i) for i in range(11)]
        positions = ["GK", *(["DEF"] * 4), *(["MID"] * 3), *(["FWD"] * 3)]
        for i, name in enumerate(names):
            aa = own_aa if name == "h1" else 0
            players[name] = dict(
                team=club,
                pos=positions[i],
                played=True,
                started=True,
                ver=7,
                aa=aa,
                score=float(np.clip(35 + aa, 0, 100)),
                mins=90,
            )
        lines, at = [], 0
        for width in (1, *formation):
            lines.append(names[at : at + width])
            at += width
        xi[side] = dict(available=True, start=lines)
    return dict(id=identity, date=date, home=dict(slug=home), away=dict(slug=away), players=players, xi=xi)


def query(g, player="h1", cohort="start"):
    return dict(
        game=g["id"],
        date=g["date"],
        player=player,
        pos=g["players"][player]["pos"],
        cohort=cohort,
        aa=-999,
        score=-999,
        level=-999,
        minutes=-999,
    )


def test_shape_requires_complete_matching_native_starters_while_xi_can_remain_known():
    g = game("g", "2023-12-20T14:00:00Z")
    r = shape.team_records(g)[0]
    assert r["shape"] == (4, 3, 3)
    assert len(r["xi"]) == 11
    altered = copy.deepcopy(g)
    altered["xi"]["home"]["start"][1][0] = "h2"
    r = shape.team_records(altered)[0]
    assert r["shape"] is None
    assert len(r["xi"]) == 11
    altered["players"]["h1"]["started"] = 1
    r = shape.team_records(altered)[0]
    assert r["xi"] is None
    assert all(p["player"] != "h1" for p in r["labels"])


def test_unknown_shape_and_no_history_are_not_reported_as_zero_variation():
    empty = shape.team_summary([])
    assert empty["observed_games"] == 0
    assert np.isnan(empty["shape_entropy"])
    assert np.isnan(empty["xi_retained_mean"])
    r = shape.team_records(game("g", "2023-12-20T14:00:00Z"))[0]
    stable = shape.team_summary([r, {**r, "game": "g2"}])
    assert stable["shape_switch_rate"] == 0
    assert stable["xi_retained_mean"] == 1
    unknown = shape.team_summary([r, {**r, "game": "g2", "shape": None, "xi": None}])
    assert unknown["observed_games"] == 2
    assert unknown["shape_known_count"] == 1
    assert np.isnan(unknown["shape_switch_rate"])
    assert np.isnan(unknown["xi_last_retained_fraction"])


def test_formation_mixture_shrinks_to_pool_and_mode_is_a_valid_peak_not_the_mean():
    pool = [dict(aa=0, shape=(4, 3, 3)), dict(aa=40, shape=(3, 4, 3))]
    history = [dict(shape=(4, 3, 3))] * 9 + [dict(shape=(3, 4, 3))]
    summary = shape.aa_summary(pool, history)
    assert np.isclose(summary["mean"], 16)
    assert summary["mode"] == 0
    assert np.isclose(summary["window_mass"], 0.6)
    assert summary["known_shape_weight"] == 1
    unknown = shape.aa_summary(pool, [dict(shape=None)])
    assert np.isnan(unknown["known_shape_weight"])
    assert unknown["mode"] in (0, 40)


def test_zero_native_aa_is_known_but_empty_pool_stays_unknown():
    zero = shape.aa_summary([dict(aa=0, shape=(4, 3, 3))], [dict(shape=(4, 3, 3))])
    assert zero["pool_count"] == 1
    assert zero["mean"] == 0
    assert zero["mode"] == 0
    missing = shape.aa_summary([], [])
    assert missing["pool_count"] == 0
    assert np.isnan(missing["mean"])


def test_mathematically_equal_shape_weights_choose_same_tied_mode():
    # A native September 2023 case exposed cumulative 0.49999999999999994 versus 0.5.
    values = [0.4, 8.3, 0.6, 3.0]
    exact = np.full(4, 0.25)
    equivalent = np.array([0.24999999999999997, 0.25, 0.24999999999999997, 0.24999999999999997])
    assert shape.weighted_mode(values, equivalent)[0] == shape.weighted_mode(values, exact)[0]


def test_exact48_boundary_current_xi_and_future_outcomes_cannot_change_features():
    old = game("old", "2023-12-20T14:00:00Z", own_aa=0)
    boundary = game("boundary", "2024-01-03T14:00:00Z", formation=(3, 4, 3), own_aa=40)
    current = game("current", "2024-01-06T18:00:00Z", formation=(5, 3, 2), own_aa=70)
    rows = [query(current), query(current, "a1")]
    native = shape.build_features(rows, [old, boundary, current])
    assert native[0, shape.NAMES.index("shape_own_3_observed_games")] == 1
    assert native[0, shape.NAMES.index("shape_aa_3_pool_count")] == 1
    assert native[0, shape.NAMES.index("shape_aa_3_mean")] == 0
    altered = copy.deepcopy([old, boundary, current])
    for g in altered[1:]:
        g["xi"] = {}
        for p in g["players"].values():
            p.update(started=None, score=np.nan, aa=np.nan, mins=-999)
    repeated = shape.build_features(rows, altered)
    np.testing.assert_array_equal(native, repeated)
    np.testing.assert_array_equal(shape.build_features(rows[::-1], [current, boundary, old]), native[::-1])


def test_new_club_and_different_cohort_do_not_inherit_old_club_aa_labels():
    old = game("old", "2023-12-20T14:00:00Z", own_aa=40)
    current = game("new", "2024-01-06T18:00:00Z", home="C", away="D")
    values = shape.build_features([query(current)], [old, current])
    assert values.shape == (1, 102)
    assert values[0, shape.NAMES.index("shape_aa_3_pool_count")] == 0
    assert np.isnan(values[0, shape.NAMES.index("shape_aa_3_mean")])
    same = game("same", "2024-01-06T18:00:00Z")
    values = shape.build_features([query(same, cohort="bench")], [old, same])
    assert values[0, shape.NAMES.index("shape_aa_3_pool_count")] == 0
