"""Testing only: independently rebuild probability counts, chronology and native forecasts."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_quantile_calibration as calibration
from app.research import score_quantile_calibration_run as runner
from app.research import score_quantile_curve as curve
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_modal_trees import CENTRES
from app.research.score_search import cutoff_for, measure, moment


def independent_bank(rows, classes, parts, first, prior):
    lock = cutoff_for(first).timestamp()
    observations = []
    unavailable = unknown = 0
    for i, row in enumerate(rows):
        available = moment(row["date"]).timestamp() + 172800
        if available >= lock:
            unavailable += 1
        elif row["level"] not in classes:
            unknown += 1
        else:
            column = list(classes).index(row["level"])
            values = sorted(float(parts[q][i, column]) for q in curve.QUANTILES)
            indicators = np.array([row["aa"] <= v for v in values], dtype=float)
            observations.append((row["pos"], float(row["level"]), available, indicators))

    def estimate(chosen, base):
        counts = np.array([sum(o[3][j] for o in chosen) for j in range(11)])
        return ((counts + prior * np.asarray(base)) / (len(chosen) + prior)).tolist()

    global_ = estimate(observations, curve.QUANTILES)
    positions, levels, counts_pos, counts_level = {}, {}, {}, {}
    for pos in sorted({o[0] for o in observations}):
        selected = [o for o in observations if o[0] == pos]
        positions[pos] = estimate(selected, global_)
        counts_pos[pos] = len(selected)
        for level in sorted({o[1] for o in selected}):
            chosen = [o for o in selected if o[1] == level]
            name = f"{pos}:{level}"
            levels[name] = estimate(chosen, positions[pos])
            counts_level[name] = len(chosen)
    return dict(
        global_=global_,
        position=positions,
        position_level=levels,
        knownCases=len(observations),
        unavailableCases=unavailable,
        unknownPastClasses=unknown,
        positionCounts=counts_pos,
        positionLevelCounts=counts_level,
        prior=prior,
        maximumAvailableUsed=max((o[2] for o in observations), default=None),
        firstLock=lock,
    )


def compare_banks(actual, reference):
    reference = dict(reference)
    reference["global"] = reference.pop("global_")
    if set(actual) != set(reference):
        raise ValueError("Independent calibration bank schema differs")
    for field in actual:
        if field == "global":
            if not np.allclose(actual[field], reference[field], rtol=0, atol=1e-15):
                raise ValueError("Independent global calibration CDF differs")
        elif field in ("position", "position_level"):
            if set(actual[field]) != set(reference[field]) or any(
                not np.allclose(actual[field][k], reference[field][k], rtol=0, atol=1e-15) for k in actual[field]
            ):
                raise ValueError("Independent hierarchical calibration CDF differs")
        elif actual[field] != reference[field]:
            raise ValueError("Independent calibration counts/availability differ: " + field)


def numerical_profiles(parts, classes, positions, bank, group, tails):
    u = (np.arange(200000) + 0.5) / 200000
    count, maximum = 0, 0.0
    for i in np.unique(np.linspace(0, len(positions) - 1, 4).astype(int)):
        for j, level in enumerate(classes):
            cdf = calibration.levels_for(bank, positions[i], level, group)
            knots = np.sort([parts[q][i, j] for q in curve.QUANTILES])
            a, b = knots[0], knots[-1]
            if tails == "extrapolate":
                a -= (knots[1] - knots[0]) / 2
                b += (knots[-1] - knots[-2]) / 2
            aa = np.interp(u, np.r_[0, cdf, 1], np.r_[a, knots, b])
            native = np.sort(np.clip(np.maximum(level if level >= 60 else 0, level + aa), 0, 100))
            expected = (
                np.searchsorted(native, CENTRES + 7, side="right") - np.searchsorted(native, CENTRES - 7, side="left")
            ) / len(native)
            observed = calibration.curve_mass(knots[None, :], level, tails, cdf)[0]
            error = float(np.max(np.abs(expected - observed)))
            maximum = max(maximum, error)
            count += 1
            if error > 2e-5:
                raise ValueError("Independent calibrated native CDF numerical integration differs")
    return dict(
        caseClassProfiles=count,
        deterministicDrawsPerProfile=len(u),
        maximumMassDifference=maximum,
        scope="Numerical integration only, not an accuracy result",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--refit-warm", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    read = lambda n: json.loads((args.report.parent / (n + ".json")).read_text())
    old_match, old_stability, old_ordinary, old_start, old_bench, parent = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
            "laliga_score_quantile_curve",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (report, old_match, old_stability, old_ordinary, old_start, old_bench, parent)
    ):
        raise ValueError("Calibration audit canonical source differs")
    with np.load(args.cache / "stats.npz") as f:
        base, stat_key = f["x"], str(f["key"])
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Calibration audit team features differ")
        x = np.column_stack((base, f["x"]))
    key = runner.identity(
        source,
        stat_key,
        old_match,
        old_stability,
        old_ordinary,
        parent["implementationKey"],
        sklearn.__version__,
        args.report.with_suffix(".plan.json"),
    )
    if key != report["implementationKey"] or parent["implementationKey"] != report["parentKey"]:
        raise ValueError("Calibration audit implementation/parent identity differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        masks = stability.phase_masks(rows)
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or winner != frozen["winner"]
            or best != frozen["best"]
            or (winner is not None) != (result["selected"] == "candidate")
            or len(frozen["candidates"]) != 24
        ):
            raise ValueError("Calibration audit frozen earlier all3 gate differs")
        previous = None
        reconstructed = checked_banks = bundles = 0
        for phase, _, _ in stability.PHASES:
            mask = masks[phase]
            target = mask["target"]
            old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
            receipt = result["earlierPeriods"][phase]["quantileBundle"]
            path = Path(receipt["path"])
            if hashlib.sha256(path.read_bytes()).hexdigest() != receipt["sha256"]:
                raise ValueError("Calibration audit quantile source SHA differs")
            with np.load(path) as f:
                parts = {q: f[f"q{q}"] for q in curve.QUANTILES}
                stats = json.loads(str(f["statistics"]))
                expected_key = key if phase == "warm2023" else parent["implementationKey"]
                if (
                    str(f["key"]) != expected_key
                    or not np.array_equal(f["classes"], old[0])
                    or not np.array_equal(f["probability"], old[1])
                    or stats != receipt["statistics"]
                    or stats["iterations"] != 240
                    or stats["fitCases"] != int(mask["fit"].sum())
                    or stats["targetCases"] != int(target.sum())
                    or any(v.shape != old[1].shape or not np.isfinite(v).all() for v in parts.values())
                ):
                    raise ValueError("Calibration audit fixed quantile bundle differs")
            bundles += 1
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            if previous is None:
                warm = (old, parts)
                previous = target_rows, old[0], parts
                continue
            control = controls.control_for(
                call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Calibration audit strongest control differs")
            active = [best] if phase == "later2026" else frozen["candidates"]
            masses = {}
            for prior in sorted({r["spec"]["prior"] for r in active}):
                bank = calibration.fit_levels(*previous, mask["first"], prior)
                reference = independent_bank(*previous, mask["first"], prior)
                compare_banks(bank, reference)
                if bank != result["earlierPeriods"][phase]["calibrationBanks"][str(prior)]:
                    raise ValueError("Calibration audit saved probability counts differ")
                checked_banks += 1
                for record in [r for r in active if r["spec"]["prior"] == prior]:
                    spec = record["spec"]
                    identity_ = prior, spec["group"], spec["tails"]
                    if identity_ not in masses:
                        mass = calibration.forecast_mass(
                            old[0], old[1], parts, positions[target], bank, spec["group"], spec["tails"]
                        )
                        masses[identity_] = windows.window_centres(mass, CENTRES)
                    forecast = ordinary.scoped_prediction(masses[identity_], control, positions[target], spec["scope"])
                    if phase == "later2026":
                        alternate = forecast
                        final = old, parts, bank, previous, spec, mass
                    elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                        raise ValueError("Calibration audit earlier native forecasts differ")
                    reconstructed += 1
            previous = target_rows, old[0], parts
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Calibration audit all-case final identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Calibration audit exact final native metrics differ")
        old, parts, bank, prev, spec, final_mass = final
        extra = [dict(date=r["date"], pos=r["pos"], aa=np.nan, level=np.nan) for r in target_rows]
        changed = copy.deepcopy(prev[0]) + extra
        augmented = {q: np.concatenate((v, np.zeros((len(extra), v.shape[1])))) for q, v in prev[2].items()}
        changed_bank = calibration.fit_levels(changed, prev[1], augmented, masks["later2026"]["first"], spec["prior"])
        repeated = calibration.forecast_mass(
            old[0], old[1], parts, positions[target], changed_bank, spec["group"], spec["tails"]
        )
        if not np.array_equal(final_mass, repeated):
            raise ValueError("Unavailable future placeholder labels changed calibrated masses")
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = dict(
            n=int(target.sum()),
            candidateCorrect=int(h1.sum()),
            controlCorrect=int(h0.sum()),
            gained=int((h1 & ~h0).sum()),
            lost=int((h0 & ~h1).sum()),
            quantileBundlesVerified=bundles,
            independentlyRebuiltCDFBanks=checked_banks,
            candidateForecastVectorsReconstructed=reconstructed,
            earlierAll3GateVerified=True,
            freezeSha256=hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
            unavailableFuturePlaceholdersAdded=len(extra),
            all201MassesUnchanged=True,
            numericalNativeCDF=numerical_profiles(parts, old[0], positions[target], bank, spec["group"], spec["tails"]),
        )
        if args.refit_warm:
            mask = masks["warm2023"]
            aa, levels = (np.array([r[n] for r in rows], dtype=float) for n in ("aa", "level"))
            aa[~mask["fit"]] = np.nan
            levels[~mask["fit"]] = np.nan
            print(f"QUANTILE_CALIBRATION_AUDIT_WARM_REFIT {cohort} all11models240", flush=True)
            repeated, _ = curve.fit_quantiles(
                x[keep],
                aa,
                levels,
                mask["fit"],
                mask["target"],
                warm[0][0],
                warm[0][2],
                240,
                prefix=f"calibration_audit_{cohort}_warm",
            )
            if any(not np.array_equal(repeated[q], warm[1][q]) for q in curve.QUANTILES):
                raise ValueError("Real warm 11quantile refit changed after outside-fit labels blanked")
            evidence[cohort]["realWarm11ModelRefitAfterOutsideLabelsBlanked"] = dict(
                outsideFitRowsBlanked=int((~mask["fit"]).sum()), all11QuantilesExactlyReproduced=True
            )
    output = dict(
        scope="Testing-only native calibration/source/freeze audit, exploratory not fresh blind proof",
        implementationKey=key,
        cohorts=evidence,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
