"""Independent complete native/CSV SOT, all24 lagged inputs, future mutation."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
from bisect import bisect_left
from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

from app.research import score_native_sot_features as study
from app.research.score_search import cutoff_for, moment


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--calendar", type=Path, required=True)
    parser.add_argument(
        "--report", type=Path, default=Path("reports/experiments/laliga_score_native_sot_features.json")
    )
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    source = json.loads((args.cache / "cases.json").read_text())
    native_raw, calendar_raw = args.games.read_bytes(), args.calendar.read_bytes()
    manifest_raw = (args.cache / "match-context/data.txt").read_bytes()
    old_key = hashlib.sha256(
        manifest_raw + Path(study.legacy.__file__).read_bytes() + native_raw + calendar_raw
    ).hexdigest()
    key = hashlib.sha256(
        (source["key"] + old_key).encode()
        + Path(study.__file__).read_bytes()
        + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    if (
        key != report["implementationKey"]
        or old_key != report["legacyFeatureKey"]
        or source["key"] != report["sourceKey"]
    ):
        raise ValueError("NativeSOT source/helper/plan changed")
    games = {g["id"]: g for g in (json.loads(line) for line in native_raw.decode().splitlines() if line.strip())}
    for r in source["rows"]:
        g, p = games[r["game"]], games[r["game"]]["players"][r["player"]]
        if (
            g["date"] != r["date"]
            or p["ver"] != 7
            or not p["played"]
            or p["started"] != (r["cohort"] == "start")
            or p["mins"] != r["minutes"]
            or any(abs(p[k] - r[k]) > 1e-7 for k in ("score", "aa", "level"))
        ):
            raise ValueError("Native full case identities differ")
    aliases = {
        "Ath Bilbao": "Athletic Club",
        "Ath Madrid": "Atletico Madrid",
        "Betis": "Real Betis",
        "Celta": "Celta Vigo",
        "Espanol": "Espanyol",
        "Vallecano": "Rayo Vallecano",
        "Sociedad": "Real Sociedad",
        "Valladolid": "Real Valladolid",
        "Alaves": "Deportivo Alaves",
        "Oviedo": "Real Oviedo",
        "Santander": "Racing Santander",
        "La Coruna": "Deportivo A Coruna",
    }
    calendar = {}
    for row in csv.DictReader(calendar_raw.decode("utf-8-sig").splitlines()):
        date = datetime.strptime(row["Date"], "%d/%m/%Y").strftime("%Y-%m-%d")
        year = int(date[:4]) - (int(date[5:7]) < 7)
        sides = tuple(study.legacy.CLUBS[aliases.get(row[k], row[k])] for k in ("HomeTeam", "AwayTeam"))
        identity = year, *sides
        if identity in calendar:
            raise ValueError("Duplicate CSV native fixture")
        calendar[identity] = dict(
            date=date + "T23:59:59Z",
            sides=sides,
            goals=[int(row[k]) for k in ("FTHG", "FTAG")],
            sot=[float(row[k]) for k in ("HST", "AST")],
        )
    compressed = (args.cache / "native_sot_observations.json.gz").read_bytes()
    path = args.cache / "native_sot_features.npz"
    if (
        hashlib.sha256(compressed).hexdigest() != report["observationsSha256"]
        or hashlib.sha256(path.read_bytes()).hexdigest() != report["featuresSha256"]
    ):
        raise ValueError("NativeSOT artifacts changed")
    archive = json.loads(gzip.decompress(compressed))
    if archive["key"] != key:
        raise ValueError("NativeSOT archive identity differs")
    records = archive["records"]
    rebuilt_records, native_fixtures, csv_fixtures, native_stat_rows = [], 0, 0, 0
    for r in records:
        if r["kind"] == "native_sorare":
            g = games[r["game"]]
            if g["date"] != r["date"] or [g[s]["slug"] for s in ("home", "away")] != r["sides"]:
                raise ValueError("NativeSOT canonical fixture identity differs")
            values = []
            for side in ("home", "away"):
                members = [
                    p for p in g["players"].values() if p.get("played") is True and p.get("team") == g[side]["slug"]
                ]
                if sum(p.get("started") is True for p in members) != 11 or any(
                    p.get("ver") != 7 or not isinstance(p.get("stats"), dict) for p in members
                ):
                    raise ValueError("Full native scored squad unavailable")
                counts = []
                for p in members:
                    if "ontarget_scoring_att" in p["stats"]:
                        count, points = p["stats"]["ontarget_scoring_att"]
                        if not math.isfinite(count) or count < 0 or abs(points - 3 * count) > 1e-7:
                            raise ValueError("NativeSOT scored stat is invalid")
                        counts.append(count)
                        native_stat_rows += 1
                values.append(math.fsum(counts))
            native_fixtures += 1
        elif r["kind"] == "calendar_csv":
            year = int(r["date"][:4]) - (int(r["date"][5:7]) < 7)
            g = calendar[year, *r["sides"]]
            if g["date"] != r["date"] or list(g["sides"]) != r["sides"]:
                raise ValueError("Historical CSV fixture identity differs")
            values = g["sot"]
            csv_fixtures += 1
        else:
            raise ValueError("Unknown SOT source origin")
        np.testing.assert_array_equal(values, r["sot"])
        matrix, old = np.array(r["metrics"], dtype=float), np.array(r["oldMetrics"], dtype=float)
        np.testing.assert_array_equal(matrix[:, [8, 9]], [[values[0], values[1]], [values[1], values[0]]])
        np.testing.assert_array_equal(
            matrix[:, [0, 1, 2, 3, 4, 5, 6, 7, 10, 11]], old[:, [0, 1, 2, 3, 4, 5, 6, 7, 10, 11]]
        )
        if moment(r["date"]) + timedelta(hours=48) != moment(r["available"]):
            raise ValueError("Source availability is not strict48h")
        rebuilt_records.append(dict(date=r["date"], available=moment(r["available"]), sides=r["sides"], metrics=matrix))
    if (native_fixtures, csv_fixtures) != (1218, 380):
        raise ValueError("Full source coverage changed")
    with np.load(path) as f:
        x, names, selected = f["x"], f["names"].tolist(), f["sot"]
        if str(f["key"]) != report["featureKey"]:
            raise ValueError("Native SOT feature key differs")
    columns = [i for i, keep in enumerate(selected) if keep]
    subnames = [names[i] for i in columns]
    club = defaultdict(list)
    for r in sorted(rebuilt_records, key=lambda r: r["available"]):
        for i, team in enumerate(r["sides"]):
            club[team].append((r["available"].timestamp(), moment(r["date"]), r["metrics"][i, 8], r["metrics"][i, 9]))
    times = {team: [r[0] for r in rs] for team, rs in club.items()}
    rebuilt = np.full((len(source["rows"]), 24), np.nan)
    for i, r in enumerate(source["rows"]):
        lock = cutoff_for(r["date"])
        g = games[r["game"]]
        own = g["players"][r["player"]]["team"]
        other = g["away"]["slug"] if g["home"]["slug"] == own else g["home"]["slug"]
        for side, team in (("own", own), ("opponent", other)):
            end = bisect_left(times.get(team, []), lock.timestamp())
            history = [a for a in club.get(team, [])[:end] if lock - a[1] <= timedelta(days=180)]
            for n in (3, 10):
                for j, field in ((2, "sot_for"), (3, "sot_against")):
                    values = [v[j] for v in history[-n:] if math.isfinite(v[j])]
                    mean = math.fsum(values) / len(values) if values else np.nan
                    sd = math.sqrt(math.fsum((v - mean) ** 2 for v in values) / len(values)) if values else np.nan
                    for suffix, value in (("mean", mean), ("sd", sd), ("count", len(values))):
                        rebuilt[i, subnames.index(f"{side}_{n}_{field}_{suffix}")] = value
    np.testing.assert_allclose(x[:, selected], rebuilt, rtol=0, atol=1e-10, equal_nan=True)
    with np.load(args.cache / "match_context_features.npz") as f:
        np.testing.assert_array_equal(x[:, ~selected], f["x"][:, ~selected])
        count_columns = [i for i, name in enumerate(names) if "_sot_" in name and name.endswith("_count")]
        np.testing.assert_array_equal(x[:, count_columns], f["x"][:, count_columns])
    first = min(cutoff_for(r["date"]) for r in source["rows"] if r["date"] >= "2026-01-01")
    indices = [i for i, r in enumerate(source["rows"]) if r["date"] >= "2026-01-01" and cutoff_for(r["date"]) == first]
    altered, mutations = deepcopy(rebuilt_records), 0
    for r in altered:
        if r["available"] >= first:
            r["metrics"][:] = 9999
            mutations += 1
    subset = [source["rows"][i] for i in indices]
    changed, changed_names, _ = study.context_features(subset, list(games.values()), altered)
    np.testing.assert_array_equal(changed, x[indices])
    if changed_names != names:
        raise ValueError("Mutated source schema differs")
    altered_games, native_mutations = deepcopy(games), 0
    for g in altered_games.values():
        if moment(g["date"]) + timedelta(hours=48) >= first:
            for p in g["players"].values():
                if p.get("played") is True:
                    p["stats"]["ontarget_scoring_att"] = [999.0, 2997.0]
            native_mutations += 1
    actual_rebuilt = []
    for r, archived in zip(rebuilt_records, records, strict=True):
        counts = (
            study.native_sot(altered_games[archived["game"]])
            if archived["kind"] == "native_sorare"
            else archived["sot"]
        )
        actual_rebuilt.append(study.replace_sot(r, counts))
    changed, _, _ = study.context_features(subset, list(altered_games.values()), actual_rebuilt)
    np.testing.assert_array_equal(changed, x[indices])
    output = dict(
        implementationKey=key,
        featureKey=report["featureKey"],
        nativeCasesVerified=len(source["rows"]),
        nativeFixturesVerified=native_fixtures,
        csvFixturesVerified=csv_fixtures,
        rawSideSOTsVerified=2 * len(records),
        nativeScoredSOTRecordsVerified=native_stat_rows,
        independentlyRecomputedRows=len(rebuilt),
        independentlyRecomputedColumns=24,
        unchangedOtherColumns=124,
        unchangedSOTCountColumns=8,
        actualFutureMutation=dict(
            firstLock=first.isoformat(),
            rows=len(indices),
            unavailableExternalFixturesChanged=mutations,
            unavailableNativeFixturesChanged=native_mutations,
            all148columnsExact=True,
        ),
        scope="Source/math/availability repair verification only, no accuracy claim",
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2))
    print("NATIVE_SOT_AUDITED " + json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
