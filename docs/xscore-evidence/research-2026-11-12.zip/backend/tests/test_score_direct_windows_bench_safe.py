from pathlib import Path

import numpy as np


def test_constant_first_target_with_varying_other_windows_remains_a_valid_fold(tmp_path, monkeypatch):
    packages = Path(__file__).parents[1] / "data" / "raw" / "formula-packages"
    monkeypatch.syspath_prepend(str(packages))
    import pandas as pd

    from app.research import score_direct_windows_bench_safe as safe

    monkeypatch.setitem(safe.MODELS, "probe", (2, 10, 20))
    scores = np.tile([40.0, 80.0], 30)
    frame = pd.DataFrame({"actor": np.tile(["a", "b"], 30), "numeric": np.zeros(60)})
    mask = {"fit": np.arange(60) < 50, "target": np.arange(60) >= 50}
    labels = safe.window_targets(scores[mask["fit"]])
    assert not labels[:, 0].any() and labels[:, 40].any() and not labels[:, 40].all()
    probability = safe.fit_windows(frame, ["actor"], scores, mask, "probe", tmp_path / "constant_first.npz", "toy-only")
    assert probability.shape == (10, 101)
    assert np.isfinite(probability).all() and (probability >= 0).all() and (probability <= 1).all()
