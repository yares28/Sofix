"""Testing only: rebuild ordinary-point forecasts while fixing decisive probabilities."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_small_regimes as small
from app.research import score_stability as stability
from app.research import score_stats_hybrid
from app.research.score_identity import category_values
from app.research.score_joint_density import components
from app.research.score_search import POSITIONS, bootstrap, measure
from app.research.score_stats_run import paired_interval

MODES = ("direct", "minutes", "rate", "specialists")
QUANTILES = (0.35, 0.5, 0.65)


def rate_targets(aa, minutes):
    if not np.isfinite(aa).all() or not np.isfinite(minutes).all() or (minutes <= 0).any():
        raise ValueError("Rate targets require known positive exposure")
    return aa * 90 / minutes, minutes / 90


def aa_design(numeric, minutes, levels, mode):
    if mode in ("minutes", "specialists"):
        return np.column_stack((numeric, minutes, levels))
    return np.column_stack((numeric, levels))


def scoped_prediction(candidate, control, positions, scope):
    return np.where(np.isin(positions, ("DEF", "MID")), candidate, control) if scope == "defmid" else candidate


def activity_features(x, names):
    def column(name):
        return x[:, names.index(name)] if name in names else np.full(len(x), np.nan)

    own, other = column("own_10_possession_mean") / 100, column("opponent_10_possession_mean") / 100
    with np.errstate(divide="ignore", invalid="ignore"):
        expected = own / (own + other)
        attack = np.clip(expected / own, 0.5, 2)
        defend = np.clip((1 - expected) / (1 - own), 0.5, 2)
    values = [expected]
    labels = ["expected_possession"]
    for label, field, factor in (
        ("adjusted_passes90", "accurate_pass", attack),
        ("adjusted_duels90", "duel_won", defend),
        ("adjusted_tackles90", "won_tackle", defend),
        ("adjusted_clearances90", "effective_clearance", defend),
    ):
        labels.append(label)
        values.append(column("counts_same_10_" + field) * factor)
    labels.append("role_depth_change")
    values.append(column("same_3_usage_pass_x_mean") - column("same_10_usage_pass_x_mean"))
    return np.column_stack(values), labels


def ordinary_inputs(base, names, player, player_names, match, match_names, cohort):
    groups, labels = small.compact_inputs(base, names, player, player_names, cohort)
    blocks, selected = [groups["usage"]], labels["usage"].copy()

    def add(matrix, available, wanted):
        present = [n for n in wanted if n in available and n not in selected]
        blocks.append(matrix[:, [available.index(n) for n in present]])
        selected.extend(present)

    fields = (
        "accurate_pass",
        "missed_pass",
        "duel_won",
        "duel_lost",
        "won_tackle",
        "interception_won",
        "effective_clearance",
        "poss_lost_ctrl",
        "fouls",
        "was_fouled",
        "saves",
        "goals_conceded",
        "accurate_long_balls",
    )
    add(base, names, [f"counts_{prefix}_{f}" for prefix in ("same_3", "same_10", "opponent") for f in fields])
    add(
        match,
        match_names,
        [
            f"{side}_10_{f}_mean"
            for side in ("own", "opponent")
            for f in ("possession", "ppda", "passes", "pass_accuracy", "box_against", "shots_against")
        ],
    )
    add(
        player,
        player_names,
        [
            f"same_{n}_usage_{f}_mean"
            for n in (3, 10)
            for f in ("crosses90", "box_passes90", "progressive90", "role_depth")
        ],
    )
    add(player, player_names, ["last_source_same_club"])
    numeric = np.column_stack(blocks)
    activity, activity_names = activity_features(numeric, selected)
    return np.column_stack((numeric, activity)), selected + activity_names


def regressor(loss, minutes=False):
    from catboost import CatBoostRegressor

    return CatBoostRegressor(
        loss_function=loss,
        iterations=250 if minutes else 400,
        depth=4 if minutes else 5,
        l2_leaf_reg=20,
        learning_rate=0.05,
        random_seed=20261104,
        thread_count=4,
        task_type="CPU",
        border_count=64,
        max_ctr_complexity=1,
        allow_writing_files=False,
        verbose=False,
    )


def forecast_minutes(frame, cats, actual, fit, check, path, key):
    from catboost import Pool

    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) == key:
                return stored["minutes"]
    model = regressor("MAE", minutes=True)
    model.fit(Pool(frame.loc[fit], label=actual[fit], cat_features=cats))
    predicted = np.clip(model.predict(Pool(frame.loc[check], cat_features=cats)), 1, 100)
    np.savez_compressed(path, key=key, minutes=predicted)
    return predicted


def fit_ordinary(
    frame, cats, aa, actual_minutes, levels, positions, fit, check, predicted_minutes, base, mode, path, key
):
    classes, _, old_parts = base
    if path.exists():
        with np.load(path) as stored:
            if str(stored["key"]) == key:
                if not {"classes", *[f"q{q}" for q in QUANTILES]}.issubset(stored.files):
                    raise ValueError("Wrong ordinary-point artifact type")
                if np.array_equal(stored["classes"], classes):
                    return {q: stored[f"q{q}"] for q in QUANTILES}
    from catboost import Pool

    parts = {q: values.copy() for q, values in old_parts.items()}
    for pos in ("DEF", "MID") if mode == "specialists" else (None,):
        training = fit & (positions == pos) if pos else fit
        checking = check & (positions == pos) if pos else check
        if not checking.any():
            continue
        if training.sum() < 20:
            raise ValueError("Too few earlier ordinary-point cases")
        train = frame.loc[training].copy()
        test = frame.loc[checking].copy()
        train["decisive_level"] = levels[training]
        if mode in ("minutes", "specialists"):
            train["minutes_if_playing"] = actual_minutes[training]
            test["minutes_if_playing"] = predicted_minutes[positions[check] == pos] if pos else predicted_minutes
        target, weight = (
            rate_targets(aa[training], actual_minutes[training]) if mode == "rate" else (aa[training], None)
        )
        model = regressor("MultiQuantile:alpha=0.35,0.5,0.65")
        model.fit(Pool(train, label=target, weight=weight, cat_features=cats))
        selected = np.flatnonzero(positions[check] == pos) if pos else np.arange(int(check.sum()))
        for j, level in enumerate(classes):
            test["decisive_level"] = level
            # Dataframe column order must match the training pool exactly.
            prediction = model.predict(Pool(test[train.columns], cat_features=cats))
            if mode == "rate":
                prediction *= predicted_minutes[:, None] / 90
            if prediction.shape != (len(selected), 3) or not np.isfinite(prediction).all():
                raise ValueError("Invalid ordinary-point prediction")
            for i, q in enumerate(QUANTILES):
                parts[q][selected, j] = prediction[:, i]
    np.savez_compressed(path, key=key, classes=classes, **{f"q{q}": a for q, a in parts.items()})
    return parts


def old_components(args, cohort, phase, mask, x, aa, levels, old_match, old_stability, key):
    if phase in ("autumn2025", "later2026"):
        ending = "selection" if phase == "autumn2025" else "later"
        expected_fit = np.array(
            [r["date"] < ("2025-07-01" if phase == "autumn2025" else "2026-01-01") for r in args.rows]
        )
        if not np.array_equal(mask["fit"], expected_fit):
            raise ValueError("Old component fit mask differs")
        return components(
            args.cache / f"feature_laliga_score_match_context_{cohort}_chances_and_intensity_{ending}.npz",
            old_match["implementationKey"],
        )
    if cohort == "start":
        return components(args.cache / f"laliga_score_stability_base_{phase}.npz", old_stability["implementationKey"])
    path = args.cache / f"{args.out.stem}_base_bench_{phase}.npz"
    if path.exists():
        return components(path, key)
    classes, probability, parts = score_stats_hybrid.conditional_components(x, aa, levels, mask["fit"], mask["target"])
    np.savez_compressed(
        path, key=key, classes=classes, probability=probability, **{f"q{q}": a for q, a in parts.items()}
    )
    return classes, probability, parts


def baseline(args, key, source, cohort, phase, mask, old_base, prior_base, prior_rows, positions, old_bench):
    if cohort == "bench":
        return stability.analogue_control(args, key, source, old_bench, phase, mask)
    classes, probability, parts, bank = stability.starter_control(prior_base, old_base, prior_rows, mask["first"])
    return empirical.empirical_predictions(classes, probability, parts, positions[mask["target"]], bank, 20, 0.75, 0)


def bank_from(previous_base, parts, rows, first_date):
    return empirical.fit_bank(
        previous_base[0],
        parts,
        np.array([r["aa"] for r in rows]),
        np.array([r["level"] for r in rows]),
        np.array([r["pos"] for r in rows]),
        stability.previous_bank_mask(rows, first_date),
        "raw",
    )


def aa_estimate(parts, probability):
    median = np.sort(np.stack([parts[q] for q in QUANTILES]), axis=0)[1]
    return np.sum(probability * median, axis=1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for n in ("cases", "stats-cache", "match-cache", "player-cache", "games", "cache", "packages", "out"):
        parser.add_argument("--" + n, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import catboost
    import pandas as pd

    source = json.loads(args.cases.read_text())
    read = lambda n: json.loads((args.out.parent / (n + ".json")).read_text())
    old_match, old_stability, old_player = (
        read("laliga_score_match_context"),
        read("laliga_score_stability"),
        read("laliga_score_player_context"),
    )
    old_bench, old_start = read("laliga_score_analogues"), read("laliga_score_match_empirical_density")
    if any(d["sourceKey"] != source["key"] for d in (old_match, old_stability, old_player, old_bench, old_start)):
        raise ValueError("Reference source differs")
    with np.load(args.stats_cache) as stored:
        base, names, stat_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    with np.load(args.match_cache) as stored:
        match, match_names = stored["x"], stored["names"].tolist()
        if str(stored["key"]) != old_match["featureKey"]:
            raise ValueError("Match input identity differs")
    with np.load(args.player_cache) as stored:
        player, player_names, player_key = stored["x"], stored["names"].tolist(), str(stored["key"])
    if player_key != old_player["featureKey"] or len(base) != len(source["rows"]) or len(player) != len(base):
        raise ValueError("Player input identity differs")
    raw = args.games.read_bytes()
    identities = category_values(
        source["rows"], [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    )
    files = [
        Path(__file__),
        Path(empirical.__file__),
        Path(stability.__file__),
        Path(small.__file__),
        Path(score_stats_hybrid.__file__),
        args.out.with_suffix(".plan.json"),
    ]
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + player_key
            + old_match["featureKey"]
            + old_stability["implementationKey"]
            + catboost.__version__
        ).encode()
        + raw
        + b"".join(p.read_bytes() for p in files)
    ).hexdigest()
    report = {
        "scope": "Testing only; decisive predictions unchanged; no live changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "libraryVersion": catboost.__version__,
        "evidenceLimit": "Repeated retrospective reuse, not fresh blind evidence",
        "cohorts": {},
    }
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        aa, levels, minutes, y = (np.array([r[n] for r in rows]) for n in ("aa", "level", "minutes", "score"))
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, feature_names = ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        frame = pd.DataFrame(numeric, columns=[f"n{i}" for i in range(numeric.shape[1])])
        cats = ["player_id", "playing_side", "opponent_side", "card_position"]
        for i, name in enumerate(cats):
            frame[name] = identities[keep, i]
        records = [
            {
                "spec": {"mode": mode, "spread": spread, "shift": shift, "scope": scope},
                "gains": [],
                "errors": [],
                "counts": [],
                "periods": {},
            }
            for mode in MODES
            for spread in (0.75, 1, 1.25)
            for shift in (-2, 0, 2)
            for scope in ("all", "defmid")
        ]
        prior_rows, prior_base, prior_parts = None, None, None
        audit = {}
        full = np.column_stack((base[keep], match[keep]))
        for phase, _, _ in stability.PHASES[:-1]:
            mask = masks[phase]
            target = mask["target"]
            target_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
            old_base = old_components(args, cohort, phase, mask, full, aa, levels, old_match, old_stability, key)
            predicted_minutes = forecast_minutes(
                frame,
                cats,
                minutes,
                mask["fit"],
                target,
                args.cache / f"{args.out.stem}_{cohort}_{phase}_minutes_forecast.npz",
                key,
            )
            current = {}
            for mode in MODES:
                current[mode] = fit_ordinary(
                    frame,
                    cats,
                    aa,
                    minutes,
                    levels,
                    positions,
                    mask["fit"],
                    target,
                    predicted_minutes,
                    old_base,
                    mode,
                    args.cache / f"{args.out.stem}_{cohort}_{phase}_aa_{mode}.npz",
                    key,
                )
                print(f"FITTED {cohort} {phase} {mode}", flush=True)
            audit[phase] = {
                "fit": int(mask["fit"].sum()),
                "target": int(target.sum()),
                "minutesMeanMiss": float(np.mean(np.abs(minutes[target] - predicted_minutes))),
                "ordinary": {},
            }
            if prior_rows is not None:
                control = baseline(
                    args, key, source, cohort, phase, mask, old_base, prior_base, prior_rows, positions, old_bench
                )
                audit[phase]["control"] = measure(y[target], control)
                if (
                    audit[phase]["control"]["within7"]
                    != old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]["within7"]
                ):
                    raise ValueError("Historical control did not reproduce")
                for mode in MODES:
                    bank = bank_from(prior_base, prior_parts[mode], prior_rows, mask["first"])
                    audit[phase]["ordinary"][mode] = measure(aa[target], aa_estimate(current[mode], old_base[1]))
                    for spread in (0.75, 1, 1.25):
                        for shift in (-2, 0, 2):
                            forecast = empirical.empirical_predictions(
                                old_base[0], old_base[1], current[mode], positions[target], bank, 20, spread, shift
                            )
                            for scope in ("all", "defmid"):
                                prediction = scoped_prediction(forecast, control, positions[target], scope)
                                metric = measure(y[target], prediction)
                                record = next(
                                    r
                                    for r in records
                                    if r["spec"] == {"mode": mode, "spread": spread, "shift": shift, "scope": scope}
                                )
                                gain = metric["within7"] - audit[phase]["control"]["within7"]
                                record["gains"].append(gain)
                                record["errors"].append(metric["mae"])
                                record["counts"].append(len(prediction))
                                record["periods"][phase] = {"gain": gain, "metrics": metric}
                print("PERIOD " + json.dumps({"cohort": cohort, "phase": phase, **audit[phase]}), flush=True)
            prior_rows, prior_base, prior_parts = target_rows, old_base, current
        winner, best = stability.choose_stable(records)
        passed = sum(min(r["gains"]) > 0 for r in records)
        args.out.with_suffix(f".{cohort}.frozen.json").write_text(
            json.dumps(
                {"winner": winner, "bestCandidate": best, "passingCandidates": passed, "candidates": records}, indent=2
            )
        )
        print(
            "FROZEN "
            + json.dumps({"cohort": cohort, "passingCandidates": passed, "winner": winner, "bestCandidate": best}),
            flush=True,
        )
        phase, mask = "later2026", masks["later2026"]
        target = mask["target"]
        old_base = old_components(args, cohort, phase, mask, full, aa, levels, old_match, old_stability, key)
        control = baseline(
            args, key, source, cohort, phase, mask, old_base, prior_base, prior_rows, positions, old_bench
        )
        path, reference = (
            ("laliga_score_match_empirical_density_predictions_start.npz", old_start)
            if cohort == "start"
            else ("analogues_predictions_bench.npz", old_bench)
        )
        with np.load(args.cache / path) as stored:
            if (
                str(stored["key"]) != reference["implementationKey"]
                or not np.array_equal(stored["y"], y[target])
                or not np.allclose(stored["prediction"], control, atol=1e-10, rtol=1e-10)
            ):
                raise ValueError("Final control did not reproduce exactly")
        spec = best["spec"]
        predicted_minutes = forecast_minutes(
            frame,
            cats,
            minutes,
            mask["fit"],
            target,
            args.cache / f"{args.out.stem}_{cohort}_{phase}_minutes_forecast.npz",
            key,
        )
        parts = fit_ordinary(
            frame,
            cats,
            aa,
            minutes,
            levels,
            positions,
            mask["fit"],
            target,
            predicted_minutes,
            old_base,
            spec["mode"],
            args.cache / f"{args.out.stem}_{cohort}_{phase}_aa_{spec['mode']}.npz",
            key,
        )
        bank = bank_from(prior_base, prior_parts[spec["mode"]], prior_rows, mask["first"])
        alternate = empirical.empirical_predictions(
            old_base[0], old_base[1], parts, positions[target], bank, 20, spec["spread"], spec["shift"]
        )
        alternate = scoped_prediction(alternate, control, positions[target], spec["scope"])
        prediction = alternate if winner else control.copy()
        old_aa, new_aa = aa_estimate(old_base[2], old_base[1]), aa_estimate(parts, old_base[1])
        new_aa = scoped_prediction(new_aa, old_aa, positions[target], spec["scope"])
        old_hit, new_hit = np.abs(y[target] - control) <= 7, np.abs(y[target] - alternate) <= 7
        weeks = [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
        result = {
            "winner": winner,
            "candidate": best,
            "selected": "candidate" if winner else "control",
            "passingCandidates": passed,
            "candidateCount": len(records) + 1,
            "featureNames": feature_names,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": measure(y[target], control),
            "candidateGain95": paired_interval(y[target], alternate, control, weeks),
            "weekly95": bootstrap(y[target], prediction, weeks),
            "candidateOrdinary": measure(aa[target], new_aa),
            "oldOrdinary": measure(aa[target], old_aa),
            "minutesMeanMiss": float(np.mean(np.abs(minutes[target] - predicted_minutes))),
            "candidateGainedCorrect": int((new_hit & ~old_hit).sum()),
            "candidateLostCorrect": int((old_hit & ~new_hit).sum()),
            "candidateChangedCases": int((alternate != control).sum()),
            "candidateHighScoreGames": measure(y[target][y[target] >= 60], alternate[y[target] >= 60]),
            "positions": {
                p: {
                    "score": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "ordinary": measure(aa[target][positions[target] == p], new_aa[positions[target] == p]),
                    "oldOrdinary": measure(aa[target][positions[target] == p], old_aa[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
            "controlReproduced": True,
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
            ordinary=new_aa,
            old_ordinary=old_aa,
            minutes=predicted_minutes,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "selected": result["selected"],
                    "later": result["later"],
                    "candidateLater": result["candidateLater"],
                    "ordinary": result["candidateOrdinary"],
                    "oldOrdinary": result["oldOrdinary"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
