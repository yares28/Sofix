"""Resolve the original two early official fixture calendars."""

import hashlib
import json
import re

import pdfplumber
from pypdf import PdfReader

from app.research.score_absence_calendars import DIRECTORY, parse

PLAYOFF_RESULT = "https://www.laliga.com/noticias/el-rcd-espanyol-vuelve-solo-un-ano-despues-a-laliga-ea-sports"


def normalize_calendar(page):
    # The 2023 draw uses corporate suffixes. The 2024 draw preceded the
    # promotion playoff; the later official result identifies its placeholder.
    return re.sub(r"\bSAD\b", "", page).replace("ESP / OVI", "RCD Espanyol de Barcelona")


def main():
    from pathlib import Path

    manifest = json.loads((DIRECTORY / "calendar_early_manifest.json").read_text(encoding="utf-8-sig"))
    names = json.loads((DIRECTORY / "official_club_registry.json").read_text())
    report = {}
    for item in manifest:
        path = Path(item["file"])
        data = path.read_bytes()
        assert item["status"] == 200 and data.startswith(b"%PDF-")
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
        season = path.stem.removeprefix("calendar_")
        pdf = PdfReader(path)
        records = parse((normalize_calendar(page.extract_text()) for page in pdf.pages), names)
        with pdfplumber.open(path) as other:
            assert records == parse((normalize_calendar(page.extract_text()) for page in other.pages), names)
        report[season] = dict(
            url=item["url"],
            sha256=item["sha256"],
            independentEnginesAgree=True,
            playoffPlaceholderEvidence=PLAYOFF_RESULT if season == "2024-25" else None,
            pairs=[dict(home=h, away=a, round=n) for (h, a), n in sorted(records.items())],
        )
        print(season, len(records), "round assignments verified", flush=True)
    (DIRECTORY / "calendar_early_rounds.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
