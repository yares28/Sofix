"""Read retained UEFA source archives as historical inputs to LaLiga research."""

from __future__ import annotations

import json
import zipfile
from collections import defaultdict
from datetime import timedelta
from pathlib import Path
from typing import Any

import numpy as np

from app.research.score_search import cutoff_for, moment

NAMES = [
    "euro_coverage",
    "euro_complete_recent_team_games",
    "euro_minutes_7",
    "euro_minutes_14",
    "euro_minutes_28",
    "euro_games_14",
    "euro_starts_14",
    "euro_last_days",
    "euro_last_minutes",
    "euro_last_score",
    "euro_recent_score_mean",
    "euro_team_games_7",
    "euro_team_games_14",
    "euro_team_last_days",
]


def read_archives(paths: list[Path]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    games = {}
    receipt = {
        "archives": [],
        "minutesRecords": 0,
        "incompleteGames": 0,
        "missingGameMetadata": 0,
        "unplayedSourceEntries": 0,
        "window": ["2023-06-01", "2026-07-01"],
        "availability": "Retrospective kickoff plus 48 hours, not archived pre-lock publication proof",
    }
    for path in paths:
        with zipfile.ZipFile(path) as archive:
            coverage = json.loads(archive.read("coverage.json"))
            receipt["archives"].append(
                {
                    "name": path.name,
                    "expected": coverage.get("expected"),
                    "saved": coverage.get("saved"),
                    "sourceComplete": coverage.get("sourceComplete"),
                }
            )
            if not coverage.get("sourceComplete"):
                raise ValueError("Archive source index is incomplete")
            for name in archive.namelist():
                if not name.startswith("games/") or not name.endswith(".json"):
                    continue
                raw = json.loads(archive.read(name)).get("raw") or {}
                if raw.get("statusTyped") != "played":
                    receipt["unplayedSourceEntries"] += 1
                    continue
                if not all(raw.get(k) for k in ("id", "date", "homeTeam", "awayTeam")):
                    receipt["missingGameMetadata"] += 1
                    continue
                starters = set()
                squad = set()
                complete = True
                for side in ("home", "away"):
                    formation = raw.get(side + "Formation") or {}
                    xi = {p["slug"] for line in formation.get("startingLineup") or [] for p in line if p.get("slug")}
                    complete &= len(xi) == 11 and formation.get("startingLineupAvailable") is True
                    starters |= xi
                    squad |= xi | {p["slug"] for p in formation.get("bench") or [] if p.get("slug")}
                scores = {(r.get("anyPlayer") or {}).get("slug"): r for r in raw.get("playerGameScores") or []}
                for player in squad:
                    r = scores.get(player) or {}
                    stats = r.get("anyPlayerGameStats") or {}
                    complete &= type(stats.get("playedInGame")) is bool
                    if player in starters:
                        complete &= stats.get("playedInGame") is True and stats.get("minsPlayed") is not None
                players = {}
                for player, r in scores.items():
                    stats = r.get("anyPlayerGameStats") or {}
                    if stats.get("playedInGame") is True:
                        if stats.get("minsPlayed") is None:
                            complete = False
                            continue
                        players[player] = {
                            "minutes": stats["minsPlayed"],
                            "started": player in starters,
                            "score": r.get("score")
                            if r.get("scoreStatus") == "FINAL" and r.get("scoringVersion") == 7
                            else None,
                        }
                        receipt["minutesRecords"] += 1
                game = {
                    "id": raw["id"],
                    "date": raw["date"],
                    "home": raw["homeTeam"]["slug"],
                    "away": raw["awayTeam"]["slug"],
                    "complete": bool(complete),
                    "players": players,
                }
                if raw["id"] in games and games[raw["id"]] != game:
                    raise ValueError("Conflicting duplicate European game")
                games[raw["id"]] = game
                receipt["incompleteGames"] += not complete
    receipt["games"] = len(games)
    return list(games.values()), receipt


def europe_features(
    rows: list[dict[str, Any]], laliga: list[dict[str, Any]], games: list[dict[str, Any]], workload_hours: int = 48
) -> tuple[np.ndarray, list[str]]:
    queue = sorted(games, key=lambda g: g["date"])
    by_club: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_player: dict[str, list[dict[str, Any]]] = defaultdict(list)
    target = {g["id"]: g for g in laliga}
    seen = 0
    out = []
    previous = None
    for row in rows:
        cutoff = cutoff_for(row["date"])
        if previous is not None and cutoff < previous:
            raise ValueError("Rows must be chronological")
        previous = cutoff
        while seen < len(queue) and moment(queue[seen]["date"]) + timedelta(hours=workload_hours) < cutoff:
            g = queue[seen]
            by_club[g["home"]].append(g)
            by_club[g["away"]].append(g)
            for player, p in g["players"].items():
                by_player[player].append({**p, "date": g["date"]})
            seen += 1
        if not "2023-06-01" <= row["date"][:10] < "2026-07-01":
            out.append([0.0, 0.0, *[np.nan] * (len(NAMES) - 2)])
            continue
        own = target[row["game"]]["players"][row["player"]]["team"]
        date = moment(row["date"])
        recent = [g for g in by_club[own] if date - moment(g["date"]) <= timedelta(days=28)]
        complete = all(g["complete"] for g in recent)
        history = [g for g in by_player[row["player"]] if date - moment(g["date"]) <= timedelta(days=70)]
        minutes = [
            sum(g["minutes"] for g in history if date - moment(g["date"]) <= timedelta(days=n)) if complete else np.nan
            for n in (7, 14, 28)
        ]
        fortnight = [g for g in history if date - moment(g["date"]) <= timedelta(days=14)]
        last = history[-1] if history else None
        scores = [
            g["score"] for g in history if g["score"] is not None and moment(g["date"]) + timedelta(hours=48) < cutoff
        ][-3:]
        club = by_club[own]
        out.append(
            [
                1.0,
                float(complete),
                *minutes,
                len(fortnight) if complete else np.nan,
                sum(g["started"] for g in fortnight) if complete else np.nan,
                (date - moment(last["date"])).total_seconds() / 86400 if last else np.nan,
                last["minutes"] if last else np.nan,
                last["score"]
                if last and last["score"] is not None and moment(last["date"]) + timedelta(hours=48) < cutoff
                else np.nan,
                float(np.mean(scores)) if scores else np.nan,
                *[sum(date - moment(g["date"]) <= timedelta(days=n) for g in recent) for n in (7, 14)],
                (date - moment(club[-1]["date"])).total_seconds() / 86400 if club else np.nan,
            ]
        )
    return np.asarray(out, dtype=np.float32), NAMES
