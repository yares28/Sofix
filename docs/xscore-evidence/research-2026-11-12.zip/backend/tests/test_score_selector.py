import numpy as np

from app.research.score_selector import advantage_target, choose_forecast


def test_selector_chooses_one_forecast_without_averaging():
    result = choose_forecast(np.array([40, 40]), np.array([80, 80]), np.array([-0.1, 0.1]), 0)
    assert result.tolist() == [40, 80]


def test_learning_target_tracks_the_actual_within_seven_objective():
    actual = np.array([40, 80, 60, 44])
    control = np.array([40, 40, 40, 40])
    alternate = np.array([80, 80, 80, 45])
    assert advantage_target(actual, control, alternate).tolist() == [-1, 1, 0, 0]
