import numpy as np
import pytest

from app.research import score_empirical_density as old
from app.research.score_exact_window import atoms, audit_grid, maximum_window, native_bounds


def test_exact_window_finds_a_narrow_maximum_between_half_point_grid_choices():
    samples, weights = np.array([40.13, 54.12]), np.array([0.5, 0.5])
    prediction, stats = maximum_window(samples, weights, 40)
    assert 47.12 <= prediction <= 47.13 and stats["chosenMass"] == 1
    grid = np.arange(0, 100.01, 0.5)
    assert np.max(((np.abs(samples[:, None] - grid) <= 7) * weights[:, None]).sum(axis=0)) == 0.5


def test_disjoint_modes_choose_a_valid_window_and_keep_control_when_already_optimal():
    prediction, _ = maximum_window([40, 80], [0.5, 0.5], 40)
    assert prediction == 40
    prediction, _ = maximum_window([40, 80], [0.5, 0.5], 60)
    assert prediction == 47 and abs(prediction - 40) <= 7
    assert abs(prediction - 80) > 7


def test_exact_window_handles_native_seven_boundaries_caps_and_duplicate_spikes():
    prediction, stats = maximum_window([0, 14, 100, 100], [0.25] * 4, 7)
    assert prediction == 7 and stats["chosenMass"] == 0.5
    prediction, stats = maximum_window([60, 60, 100], [0.4, 0.4, 0.2], 80)
    assert prediction == 67 and stats["chosenMass"] == 0.8


def test_atom_mixture_reproduces_old_conditional_cdf_on_every_grid_point():
    classes = np.array([35.0, 60])
    probability, location, scale = np.array([0.8, 0.2]), np.array([5.0, -5]), np.array([0.75, 0.75])
    pool, conditional = np.array([-100, -20, -2, 0, 5, 100.0]), np.array([-15, 1, 2.0])
    bank = {"global": pool, "positions": {"DEF": pool}, "levels": {("DEF", 35.0): conditional}}
    samples, weights = atoms(classes, probability, location, scale, "DEF", bank)
    assert np.isclose(weights.sum(), 1) and (samples >= 0).all() and (samples <= 100).all()
    centres = np.arange(0, 100.01, 0.5)
    actual = ((np.abs(samples[:, None] - centres) <= 7) * weights[:, None]).sum(axis=0)
    expected = np.zeros(len(centres))
    for j, level in enumerate(classes):
        low, high = centres - 7, centres + 7
        clipping = low <= (level if level >= 60 else 0), high >= 100, high < (level if level >= 60 else 0)
        bounds = (low - level - location[j]) / scale[j], (high - level - location[j]) / scale[j]
        mass = old.window_mass(pool, *bounds, *clipping)
        own = bank["levels"].get(("DEF", float(level)))
        if own is not None:
            mass = (len(own) * old.window_mass(own, *bounds, *clipping) + 20 * mass) / (len(own) + 20)
        expected += probability[j] * mass
    np.testing.assert_allclose(actual, expected, atol=1e-14, rtol=0)
    parts = classes, probability[None, :], {q: location[None, :].copy() for q in (0.35, 0.5, 0.65)}
    bank["mode"] = "raw"
    audit = audit_grid(parts, np.array(["DEF"]), bank)
    assert audit["cases"] == 1 and audit["gridPointsPerCase"] == 201
    assert audit["maximumLegacyNativeMassDifference"] < 1e-12


def test_exact_maximum_never_loses_to_any_checked_endpoint_or_grid_choice():
    rng = np.random.default_rng(15)
    for _ in range(60):
        samples, weights = rng.uniform(0, 100, 25), rng.uniform(0.01, 1, 25)
        prediction, stats = maximum_window(samples, weights, float(rng.uniform(0, 100)))
        choices = np.clip(np.concatenate((samples - 7, samples + 7, np.arange(0, 100.01, 0.1))), 0, 100)
        mass = ((np.abs(samples[:, None] - choices) <= 7) * weights[:, None]).sum(axis=0) / weights.sum()
        assert stats["chosenMass"] >= mass.max() - 1e-12
        assert stats["chosenMass"] == pytest.approx(weights[np.abs(samples - prediction) <= 7].sum() / weights.sum())


def test_roundoff_at_a_fourteen_point_span_never_claims_unachieved_mass():
    rng = np.random.default_rng(28)
    for base in rng.uniform(0, 86, 300):
        samples = np.array([base, base + 14])
        prediction, stats = maximum_window(samples, [0.5, 0.5], 50)
        assert stats["chosenMass"] == (np.abs(samples - prediction) <= 7).mean()


def test_native_boundaries_are_included_and_adjacent_representable_outside_is_excluded():
    x = np.concatenate(
        ([0, 7, np.nextafter(7.0, np.inf), 14, 60, 93, 100], np.random.default_rng(5).uniform(0, 100, 300))
    )
    low, high = native_bounds(x)
    assert (np.abs(x - low) <= 7).all() and (np.abs(x - high) <= 7).all()
    outside_low, outside_high = np.nextafter(low, -np.inf), np.nextafter(high, np.inf)
    assert ((outside_low < 0) | (np.abs(x - outside_low) > 7)).all()
    assert ((outside_high > 100) | (np.abs(x - outside_high) > 7)).all()


@pytest.mark.parametrize("weights", [[0, 0], [-1, 2], [np.nan, 1]])
def test_unknown_or_invalid_masses_are_rejected(weights):
    with pytest.raises(ValueError, match="Finite"):
        maximum_window([40, 80], weights, 40)
