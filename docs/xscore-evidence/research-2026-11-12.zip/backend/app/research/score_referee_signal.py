"""Testing-only earlier duel-winner signal; never score-within7 accuracy."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_search import cutoff_for, moment

PHASES = (
    ("spring2024", "2024-01-01", "2024-07-01"),
    ("season2024", "2024-07-01", "2025-07-01"),
    ("autumn2025", "2025-07-01", "2026-01-01"),
)
MATCHUP_FIELDS = (
    "own_known_games",
    "own_role_depth",
    "own_role_width",
    "own_duel_won90",
    "own_duel_lost90",
    "own_won_contest90",
    "own_won_tackle90",
    "opponent_recent_games",
    "own_duel_fraction",
    "opponent_duel_fraction",
    "opponent_baseline_duel_fraction",
    "expected_duel_fraction",
)


def fitted(x, counts, fit, target, architecture):
    if x.shape[1] not in (195, 204):
        raise ValueError("Registered paired referee input width differs")
    usable = fit & np.isfinite(counts).all(axis=1) & (np.nansum(counts, axis=1) > 0)
    if not usable.any() or np.any(counts[usable] < 0) or not (counts[usable].sum(axis=0) > 0).all():
        raise ValueError("Positive native win and loss training counts required")
    params = dict(usable=usable, missing_flag_width=np.array(195))
    if architecture == "logistic":
        from sklearn.linear_model import LogisticRegression

        median = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0.0 for c in x[usable].T])
        complete = np.where(np.isfinite(x), x, median)
        mean, scale = complete[usable].mean(axis=0), complete[usable].std(axis=0)
        scale = np.where(scale > 1e-8, scale, 1.0)
        inputs = np.column_stack(((complete - mean) / scale, ~np.isfinite(x[:, :195])))
        model = LogisticRegression(C=1, solver="lbfgs", max_iter=2000, tol=1e-8, random_state=20261106)
        params.update(median=median, mean=mean, scale=scale)
    elif architecture == "nonlinear":
        from sklearn.ensemble import HistGradientBoostingClassifier

        inputs = x
        model = HistGradientBoostingClassifier(
            max_iter=120,
            max_leaf_nodes=7,
            min_samples_leaf=80,
            learning_rate=0.06,
            l2_regularization=10,
            early_stopping=False,
            random_state=20261106,
        )
    else:
        raise ValueError("Unregistered architecture")
    xx = np.vstack((inputs[usable], inputs[usable]))
    yy = np.r_[np.ones(usable.sum()), np.zeros(usable.sum())]
    weights = np.r_[counts[usable, 0], counts[usable, 1]]
    positive = weights > 0
    model.fit(xx[positive], yy[positive], sample_weight=weights[positive])
    if architecture == "logistic":
        if int(model.n_iter_.max()) >= 2000:
            raise ValueError("Registered logistic model did not converge")
        params.update(coefficient=model.coef_[0], intercept=model.intercept_[0], iterations=model.n_iter_)
    params["probability"] = model.predict_proba(inputs[target])[:, 1]
    return params


def losses(counts, probability, selected):
    if len(counts) != len(probability) or not np.isfinite(probability).all():
        raise ValueError("Full finite prediction vector required")
    valid = selected & np.isfinite(counts).all(axis=1) & (np.nansum(counts, axis=1) > 0)
    w, lost = counts[valid].T
    n = w + lost
    p = np.clip(probability[valid], 1e-12, 1 - 1e-12)
    if not n.sum():
        raise ValueError("No recorded duels in primary group")
    return dict(
        cases=int(selected.sum()),
        positiveDuelCases=int(valid.sum()),
        duels=int(n.sum()),
        wins=int(w.sum()),
        brier=float(np.sum(w * (1 - p) ** 2 + lost * p**2) / n.sum()),
        logloss=float(-np.sum(w * np.log(p) + lost * np.log1p(-p)) / n.sum()),
    )


def interval(counts, baseline, proposed, weeks, selected):
    valid = selected & np.isfinite(counts).all(axis=1) & (np.nansum(counts, axis=1) > 0)
    w, lost = counts[valid].T
    old, new, week = baseline[valid], proposed[valid], np.asarray(weeks)[valid]
    gain = w * ((1 - old) ** 2 - (1 - new) ** 2) + lost * (old**2 - new**2)
    groups = sorted(set(week))
    numerator = np.array([gain[week == g].sum() for g in groups])
    denominator = np.array([(w + lost)[week == g].sum() for g in groups])
    draws = np.random.default_rng(20261106).integers(len(groups), size=(2000, len(groups)))
    return np.quantile(numerator[draws].sum(axis=1) / denominator[draws].sum(axis=1), [0.025, 0.975]).tolist()


def load_inputs(args):
    source = json.loads((args.cache / "cases.json").read_text())
    audit_path = args.out.parent / "laliga_score_referee_features.integrity.json"
    audit = json.loads(audit_path.read_text())
    if (
        audit["nativeCasesVerified"] != 38850
        or audit["independentColumns"] != 13
        or not audit["actualFutureMutation"]["all13ColumnsExact"]
    ):
        raise ValueError("Completed entire referee feature/time audit required")
    with np.load(args.cache / "referee_features.npz") as z:
        if str(z["key"]) != audit["featureKey"] or str(z["source_key"]) != source["key"]:
            raise ValueError("Frozen referee feature source differs")
        referee = z["x"].copy()
    matchup_path = args.cache / "matchup_features.npz"
    with np.load(matchup_path) as z:
        if str(z["key"]) != "c823678a28410cd6f76bd73b824f54579522f44c49021ee1def6accc63e70d55":
            raise ValueError("Frozen original matchup source differs")
        matchup, names = z["x"], z["names"].tolist()
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0":
        raise ValueError("Frozen native source differs")
    games = {g["id"]: g for g in map(json.loads, raw.decode("utf-8").splitlines())}
    counts = []
    for row in source["rows"]:
        g = games[row["game"]]
        p = g["players"][row["player"]]
        if (
            p["ver"] != 7
            or p["played"] is not True
            or bool(p["started"]) != (row["cohort"] == "start")
            or p["pos"] != row["pos"]
            or g["date"] != row["date"]
        ):
            raise ValueError("Native forecast label identity differs")
        if any(abs(p[k] - row[k]) > 1e-7 for k in ["score", "aa", "level"]):
            raise ValueError("Native score label differs")
        counts.append(
            [p["stats"].get(k, [0, 0])[0] for k in ["duel_won", "duel_lost"]]
            if row["pos"] != "GK"
            else [np.nan, np.nan]
        )
    counts = np.asarray(counts, dtype=float)
    if (
        np.any(counts[np.isfinite(counts)] < 0)
        or not np.equal(counts[np.isfinite(counts)], np.round(counts[np.isfinite(counts)])).all()
    ):
        raise ValueError("Native duel labels must be nonnegative integer counts")
    original = np.array([r["x"] for r in source["rows"]])
    extra = []
    for name in MATCHUP_FIELDS:
        value = matchup[:, names.index(name)].copy()
        extra.append(np.log1p(value) if name.endswith("90") or name.endswith("games") else value)
    controls = referee[:, :4].copy()
    controls[:, 1:] = np.log1p(controls[:, 1:])
    baseline = np.column_stack((original, *extra, controls))
    rates = referee[:, 4:].copy()
    rates[:, [0, 1, 2, 3, 4, 6]] = np.log1p(rates[:, [0, 1, 2, 3, 4, 6]])
    if baseline.shape != (38850, 195):
        raise ValueError("Registered common baseline schema differs")
    proposed = np.column_stack((baseline, rates))
    return (
        source,
        dict(baseline=baseline, referee=proposed),
        counts,
        dict(
            refereeFeatureKey=audit["featureKey"],
            refereeAuditSHA=hashlib.sha256(audit_path.read_bytes()).hexdigest(),
            originalMatchupSHA=hashlib.sha256(matchup_path.read_bytes()).hexdigest(),
            nativeSHA=hashlib.sha256(raw).hexdigest(),
            commonBaselineColumns=195,
            proposedColumns=204,
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_referee_duel_signal.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import sklearn
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, inputs, all_counts, provenance = load_inputs(args)
    key = hashlib.sha256(
        (source["key"] + json.dumps(provenance, sort_keys=True) + sklearn.__version__).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    report = dict(
        scope="Earlier referee duel-winner signal only, NOT xScore accuracy",
        implementationKey=key,
        sourceKey=source["key"],
        provenance=provenance,
        cohorts={},
        later2026="Not fitted/evaluated",
        evidenceLimit="Repeated retrospective outcome reuse; reconstructed official source version clocks; categorical published names; past planned referee proxies actual officiating; original publication receipt unproven",
    )
    for cohort in ("start", "bench"):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        counts = all_counts[keep]
        result = dict(periods={}, pooled={})
        pooled = {a: dict(counts=[], baseline=[], referee=[], weeks=[], defender=[]) for a in ("logistic", "nonlinear")}
        gains = {a: [] for a in pooled}
        for phase, begin, end in PHASES:
            target = np.array([begin <= r["date"] < end for r in rows])
            first = min(r["date"] for r, yes in zip(rows, target, strict=True) if yes)
            lock = cutoff_for(first)
            fit = np.array([r["date"] < begin and moment(r["date"]) + timedelta(hours=48) < lock for r in rows])
            result["periods"][phase] = dict(
                firstLock=lock.isoformat(), fit=int(fit.sum()), target=int(target.sum()), models={}
            )
            defender = np.array([r["pos"] == "DEF" for r, yes in zip(rows, target, strict=True) if yes])
            primary = defender if cohort == "start" else np.ones(target.sum(), bool)
            for architecture in pooled:
                probabilities, metrics = {}, {}
                for arm, full_x in inputs.items():
                    model = fitted(full_x[keep], counts, fit, target, architecture)
                    path = args.cache / f"{args.out.stem}_{cohort}_{phase}_{architecture}_{arm}.npz"
                    np.savez_compressed(path, key=key, fit=fit, target=target, actual=counts[target], **model)
                    probabilities[arm] = model["probability"]
                    metrics[arm] = {
                        g: losses(counts[target], model["probability"], selected)
                        for g, selected in (
                            ("primary", primary),
                            ("allOutfield", np.ones(target.sum(), bool)),
                            ("defender", defender),
                        )
                    }
                old, new = metrics["baseline"]["primary"], metrics["referee"]["primary"]
                gain = dict(logloss=old["logloss"] - new["logloss"], brier=old["brier"] - new["brier"])
                gains[architecture].append(gain)
                result["periods"][phase]["models"][architecture] = dict(metrics=metrics, primaryImprovement=gain)
                p = pooled[architecture]
                p["counts"].extend(counts[target])
                p["weeks"].extend(r["week"] for r, yes in zip(rows, target, strict=True) if yes)
                p["defender"].extend(defender)
                for arm in inputs:
                    p[arm].extend(probabilities[arm])
                print(
                    "REFEREE_DUEL_PERIOD "
                    + json.dumps(dict(cohort=cohort, phase=phase, architecture=architecture, primaryImprovement=gain)),
                    flush=True,
                )
        for architecture, p in pooled.items():
            c, old, new, defender = (np.array(p[k]) for k in ("counts", "baseline", "referee", "defender"))
            primary = defender if cohort == "start" else np.ones(len(c), bool)
            bounds = interval(c, old, new, p["weeks"], primary)
            all_outfield_gain = (
                losses(c, old, np.ones(len(c), bool))["brier"] - losses(c, new, np.ones(len(c), bool))["brier"]
            )
            consistent = all(g["brier"] > 0 and g["logloss"] > 0 for g in gains[architecture])
            result["pooled"][architecture] = dict(
                metrics={
                    arm: {
                        g: losses(c, probability, selected)
                        for g, selected in (
                            ("primary", primary),
                            ("allOutfield", np.ones(len(c), bool)),
                            ("defender", defender),
                        )
                    }
                    for arm, probability in (("baseline", old), ("referee", new))
                },
                primaryBrierGain95=bounds,
                allThreeEarlierPeriodsImprove=consistent,
                allOutfieldBrierGain=all_outfield_gain,
                passesSignalGate=consistent and bounds[0] > 0 and all_outfield_gain >= 0,
            )
        result["passesAnySignalGate"] = any(r["passesSignalGate"] for r in result["pooled"].values())
        result["disposition"] = (
            "Eligible for separately registered score-formula test, not proven score gain"
            if result["passesAnySignalGate"]
            else "REJECT/RETIRE referee-duel formula grid; neither architecture passed the earlier gate"
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
        print(
            "REFEREE_DUEL_RESULT "
            + json.dumps(dict(cohort=cohort, passed=result["passesAnySignalGate"], disposition=result["disposition"])),
            flush=True,
        )


if __name__ == "__main__":
    main()
