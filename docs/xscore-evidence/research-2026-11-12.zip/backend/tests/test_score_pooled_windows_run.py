"""Testing only: actual cached source-weighted fits cannot read held-out scores."""

from pathlib import Path
from uuid import uuid4

import numpy as np

from app.research import score_pooled_windows_audit as audit
from app.research import score_pooled_windows_run as runner


def test_actual_pooled_window_fit_ignores_outside_scores_and_repeats_training_prefix(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).parents[1] / "data/raw/formula-packages"))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    rng = np.random.default_rng(31)
    x = rng.normal(size=(180, 3))
    x[::11, 0] = np.nan
    y = rng.choice([40.0, 80.0], 180)
    queries = [
        dict(date="2023-12-01T12:00:00Z" if i < 150 else "2024-01-02T20:00:00Z", cohort="start", source="laliga")
        for i in range(180)
    ]
    fit = np.arange(180) < 150
    mask = dict(fit=fit, target=~fit, first="2024-01-02T20:00:00Z")
    spec = dict(width=4, ridge=0.001, group="ll")
    root = Path(__file__).parents[1] / "data/raw/pooled-window-tests" / uuid4().hex
    root.mkdir(parents=True)
    path1, path2, path4 = (root / f"{name}.npz" for name in ("first", "hidden", "longer"))
    first, _ = runner.fitted(
        x, y, queries, "start", "2024-01-01", mask, spec, 2, np.flatnonzero(~fit), np.arange(180), path1, "fixture"
    )
    y[~fit] = np.nan
    second, _ = runner.fitted(
        x, y, queries, "start", "2024-01-01", mask, spec, 2, np.flatnonzero(~fit), np.arange(180), path2, "fixture"
    )
    np.testing.assert_array_equal(first, second)
    runner.fitted(
        x, y, queries, "start", "2024-01-01", mask, spec, 4, np.flatnonzero(~fit), np.arange(180), path4, "fixture"
    )
    with np.load(path1) as a, np.load(path2) as b, np.load(path4) as c:
        rebuilt = audit.reconstructed_mass(x, fit, np.ones(180), np.flatnonzero(~fit), a)
        np.testing.assert_array_equal(rebuilt, a["mass"])
        np.testing.assert_array_equal(a["normaliser_mean"], b["normaliser_mean"])
        np.testing.assert_array_equal(a["normaliser_mean"], c["normaliser_mean"])
        np.testing.assert_array_equal(a["history"], c["history"][:2])
        for j in range(4):
            np.testing.assert_array_equal(a[f"w{j}"], b[f"w{j}"])
