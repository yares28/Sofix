"""Hindsight-only check of one recovery and interception component adjustment."""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_component_replacement import diagnostics
from app.research.score_openplay_duel_signal import native_archive
from app.research.score_openplay_regain_workload import native_points
from app.research.score_search import cutoff_for, moment
from app.research.score_shared_error_recovery import snapshots


def reference_points(rows, points):
    released = sorted((moment(r["date"]) + timedelta(hours=48), i) for i, r in enumerate(rows))
    people = defaultdict(lambda: deque(maxlen=6))
    position = defaultdict(lambda: deque(maxlen=120))
    cursor = 0
    forecast = np.zeros(len(rows))
    for lock, i in sorted((cutoff_for(r["date"]), j) for j, r in enumerate(rows)):
        while cursor < len(released) and released[cursor][0] < lock:
            _, j = released[cursor]
            past = rows[j]
            people[past["player"], past["pos"]].append(points[j])
            position[past["pos"]].append(points[j])
            cursor += 1
        own = people[rows[i]["player"], rows[i]["pos"]]
        pool = position[rows[i]["pos"]]
        forecast[i] = (sum(own) + 5 * (np.mean(pool) if pool else 0)) / (len(own) + 5)
    return forecast


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_regain_headroom.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    source = json.loads((args.cache / "cases.json").read_text())
    games = native_archive(args.games)
    read = lambda name: json.loads((args.out.parent / f"{name}.json").read_text())
    report = {"scope": "Hindsight only. Actual component points used to diagnose a stated adjustment.", "cohorts": {}}
    for cohort in ("start", "bench"):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        points = np.array([native_points(r, games[r["game"]]) for r in rows])
        difference = points - reference_points(rows, points)
        parts = snapshots(args, source, rows, cohort, read)
        lookup = {(r["game"], r["player"]): i for i, r in enumerate(rows)}
        report["cohorts"][cohort] = {}
        for phase, (subset, retained, *_unused) in parts.items():
            ids = [lookup[r["game"], r["player"]] for r in subset]
            y = np.array([r["score"] for r in subset])
            report["cohorts"][cohort][phase] = diagnostics(y, retained, difference[ids], np.ones(len(y), dtype=bool))
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
