import numpy as np

from app.research.score_openplay_duel_features import FEATURES, features_for


def test_matchup_uses_earlier_pairs_and_mirrors_opponent_zones():
    sides = {"home": {"slug": "home"}, "away": {"slug": "away"}}
    players = {
        "p": {"team": "home", "pos": "DEF", "played": True, "mins": 90},
        "r": {"team": "away", "pos": "FWD", "played": True, "mins": 90},
    }
    games = {
        key: sides | {"id": key, "date": date, "players": players}
        for key, date in (
            ("available", "2024-05-07T14:00:00Z"),
            ("exactly_at_lock", "2024-05-08T14:00:00Z"),
            ("target", "2024-05-12T19:00:00Z"),
        )
    }
    rows = [{"game": "target", "date": games["target"]["date"], "player": "p", "pos": "DEF"}]
    good = (0, 14.0, ("home", "away"), ("p", "r"))
    late = (0, 17.0, ("away", "home"), ("r", "p"))
    past_only = features_for(rows, games, {"available": [good]})
    np.testing.assert_array_equal(
        past_only, features_for(rows, games, {"available": [good], "exactly_at_lock": [late] * 30, "target": [late] * 30})
    )
    out = dict(zip(FEATURES, past_only[0], strict=True))
    assert out["player_games"] == out["opponent_games"] == 1
    assert out["aerial_defence_player_rate"] == out["aerial_defence_opponent_mix"] == 1
    assert out["aerial_attack_opponent_mix"] == 0
    assert out["aerial_projected_win"] > 0.5
    empty = dict(zip(FEATURES, features_for(rows, games, {})[0], strict=True))
    assert empty["player_games"] == 0 and np.isnan(empty["aerial_defence_player_rate"])
