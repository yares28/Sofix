"""Testing only: independent reference distributions, parent identities and native mixture choices."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_analogues as analogues
from app.research import score_density_blend_run as runner
from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_ordinary as ordinary
from app.research import score_stability as stability
from app.research.score_modal_trees import CENTRES
from app.research.score_search import measure
from app.research.score_windows import window_centres


def independent_reference(call, source, cohort, phase, masks, reports, old, receipt):
    target = masks[phase]["target"]
    if cohort == "bench":
        with np.load(receipt["path"]) as f:
            indices, distance = f["indices"], f["distance"]
        spec = reports["laliga_score_analogues"]["cohorts"]["bench"]["winner"]
        prepared = analogues.prepare_lookup(call.rows, target, masks[phase]["fit"], indices, distance)
        valid = indices >= 0
        scores = np.array([r["score"] for r in call.rows])[np.maximum(indices, 0)]
        weights = valid * (np.arange(500)[None, :] < spec["neighbours"])
        weights = weights * (1 + distance) ** -spec["distancePower"]
        weights = weights * np.exp2(-prepared["age"] / spec["halfLifeDays"])
        weights = weights * np.where(prepared["own"], spec["ownPlayerWeight"], 1)
        # Independently add each neighbour's weight to its complete interval of forecast choices.
        begin = np.searchsorted(CENTRES, scores - 7, side="left")
        end = np.searchsorted(CENTRES, scores + 7, side="right")
        width = len(CENTRES) + 1
        offsets = np.arange(len(scores))[:, None] * width
        changes = np.zeros(len(scores) * width)
        np.add.at(changes, (offsets + begin).ravel(), weights.ravel())
        np.add.at(changes, (offsets + end).ravel(), -weights.ravel())
        raw = np.cumsum(changes.reshape(len(scores), width)[:, :-1], axis=1)
        totals = weights.sum(axis=1)
        mass = np.divide(raw, totals[:, None], out=np.zeros_like(raw), where=totals[:, None] > 0)
        absent = totals <= 0
        mass[absent] = (np.abs(prepared["fallback"][absent, None] - CENTRES) <= 7).astype(float)
        return mass
    phases = [p[0] for p in stability.PHASES]
    previous_phase = phases[phases.index(phase) - 1]
    previous_rows = [r for r, yes in zip(call.rows, masks[previous_phase]["target"], strict=True) if yes]
    previous = flow.old_components(
        call,
        cohort,
        previous_phase,
        reports["laliga_score_match_context"],
        reports["laliga_score_stability"],
        reports["laliga_score_ordinary"],
    )
    bank = empirical.fit_bank(
        previous[0],
        previous[2],
        np.array([r["aa"] for r in previous_rows]),
        np.array([r["level"] for r in previous_rows]),
        np.array([r["pos"] for r in previous_rows]),
        stability.previous_bank_mask(previous_rows, masks[phase]["first"]),
        "raw",
    )
    positions = np.array([r["pos"] for r, yes in zip(call.rows, target, strict=True) if yes])
    location = np.sort(np.stack([old[2][q] for q in (0.35, 0.5, 0.65)]), axis=0)[1]
    mass = np.zeros((int(target.sum()), 201))
    lo_score, hi_score = CENTRES - 7, CENTRES + 7
    for pos in sorted(set(positions)):
        selected = positions == pos
        pool = bank["positions"].get(pos, bank["global"])
        for j, level in enumerate(old[0]):
            low = (lo_score[None, :] - level - location[selected, j, None]) / 0.75
            high = (hi_score[None, :] - level - location[selected, j, None]) / 0.75
            floor = level if level >= 60 else 0

            def distribution(samples, low=low, high=high, floor=floor):
                lower = np.searchsorted(samples, low, side="left") / len(samples)
                upper = np.searchsorted(samples, high, side="right") / len(samples)
                lower[:, lo_score <= floor] = 0
                upper[:, hi_score >= 100] = 1
                value = np.maximum(upper - lower, 0)
                value[:, hi_score < floor] = 0
                return value

            value = distribution(pool)
            specific = bank["levels"].get((pos, float(level)))
            if specific is not None and len(specific):
                value = (len(specific) * distribution(specific) + 20 * value) / (len(specific) + 20)
            mass[selected] += old[1][selected, j, None] * value
    return mass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source, report = (json.loads(p.read_text()) for p in (args.cases, args.report))
    names = (
        "laliga_score_match_context",
        "laliga_score_stability",
        "laliga_score_ordinary",
        "laliga_score_match_empirical_density",
        "laliga_score_analogues",
        *[v[0] for v in runner.FAMILIES.values()],
    )
    reports = {n: json.loads((args.report.parent / (n + ".json")).read_text()) for n in names}
    key = runner.implementation_key(source, reports, args.report.with_suffix(".plan.json"))
    if key != report["implementationKey"] or any(r["sourceKey"] != source["key"] for r in (*reports.values(), report)):
        raise ValueError("Density audit code/plan/canonical source identity differs")
    for stem, _ in runner.FAMILIES.values():
        parent_audit = json.loads((args.report.parent / (stem + ".integrity.json")).read_text())
        if parent_audit["implementationKey"] != reports[stem]["implementationKey"] or set(parent_audit["cohorts"]) != {
            "start",
            "bench",
        }:
            raise ValueError("Density audit full parent identity differs")
    evidence = {}
    for cohort, result in report["cohorts"].items():
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        masks = stability.phase_masks(rows)
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.report)
        frozen_path = args.report.with_name(args.report.stem + f".{cohort}.frozen.json")
        frozen = json.loads(frozen_path.read_text())
        winner, best = stability.choose_stable(frozen["candidates"])
        if (
            frozen["implementationKey"] != key
            or winner != frozen["winner"]
            or best != frozen["best"]
            or (winner is not None) != (result["selected"] == "candidate")
            or [r["spec"] for r in frozen["candidates"]] != [r["spec"] for r in runner.records()]
        ):
            raise ValueError("Density audit earlier all3 gate/settings differ")
        vectors = parent_caches = 0
        maximum_reference_difference = 0.0
        for phase, _, _ in stability.PHASES[1:]:
            print(f"DENSITY_BLEND_AUDIT {cohort} {phase}", flush=True)
            target = masks[phase]["target"]
            base, control, old, receipt = runner.reference(call, key, source, cohort, phase, masks, reports)
            independent = independent_reference(call, source, cohort, phase, masks, reports, old, receipt)
            difference = float(np.max(np.abs(base - independent)))
            maximum_reference_difference = max(maximum_reference_difference, difference)
            if difference > 1e-12 or receipt != result["earlierPeriods"][phase]["reference"]:
                raise ValueError("Density audit independent full reference window probabilities differ")
            expected = (
                reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else reports["laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"][
                    "cohorts"
                ][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Density audit original frozen native controls differ")
            active = [best] if phase == "later2026" else frozen["candidates"]
            for family in sorted({r["spec"]["family"] for r in active}):
                parent_report = reports[runner.FAMILIES[family][0]]
                parent_args = SimpleNamespace(cache=args.cache, out=args.report)
                new, parent_receipt = runner.parent_mass(parent_args, cohort, phase, family, old, parent_report)
                if parent_receipt != result["earlierPeriods"][phase]["parents"][family]:
                    raise ValueError("Density audit parent cache/frozen source SHA differs")
                parent_caches += 1
                parent_frozen = json.loads(
                    (args.report.parent / f"{runner.FAMILIES[family][0]}.{cohort}.frozen.json").read_text()
                )
                parent_forecast = ordinary.scoped_prediction(
                    window_centres(new, CENTRES), control, positions[target], parent_frozen["best"]["spec"]["scope"]
                )
                expected_parent = (
                    parent_frozen["best"]["periods"][phase]["metrics"]
                    if phase != "later2026"
                    else parent_report["cohorts"][cohort]["candidateLater"]
                )
                if measure(y[target], parent_forecast) != expected_parent:
                    raise ValueError("Density audit parent native forecasts differ from full parent audit")
                for record in [r for r in active if r["spec"]["family"] == family]:
                    spec = record["spec"]
                    mass = base * (1 - spec["weight"]) + new * spec["weight"]
                    chosen = window_centres(mass, CENTRES)
                    forecast = (
                        np.where(np.isin(positions[target], ["DEF", "MID"]), chosen, control)
                        if spec["scope"] == "defmid"
                        else chosen
                    )
                    if phase == "later2026":
                        alternate = forecast
                    elif measure(y[target], forecast) != record["periods"][phase]["metrics"]:
                        raise ValueError("Density audit native earlier mixture forecasts differ")
                    vectors += 1
        target = masks["later2026"]["target"]
        with np.load(args.cache / f"{args.report.stem}_predictions_{cohort}.npz") as f:
            if (
                str(f["key"]) != key
                or not np.array_equal(f["y"], y[target])
                or not np.array_equal(f["alternate"], alternate)
                or not np.array_equal(f["control"], control)
                or len(f["y"]) != {"start": 6754, "bench": 2925}[cohort]
            ):
                raise ValueError("Density audit complete final native identity differs")
            for field, name in (("prediction", "later"), ("alternate", "candidateLater"), ("control", "control")):
                if measure(y[target], f[field]) != result[name]:
                    raise ValueError("Density audit native final metrics differ")
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        evidence[cohort] = dict(
            n=int(target.sum()),
            candidateCorrect=int(h1.sum()),
            controlCorrect=int(h0.sum()),
            gained=int((h1 & ~h0).sum()),
            lost=int((h0 & ~h1).sum()),
            allReference201WindowMassesIndependentlyRebuilt=True,
            maximumIndependentReferenceProbabilityDifference=maximum_reference_difference,
            parentCacheNativeForecastsVerified=parent_caches,
            nativeForecastVectorsReconstructed=vectors,
            originalControlDecisionExactAllCases=True,
            frozenEarlierAll3ChoiceVerified=True,
            freezeSha256=hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        )
    output = dict(
        scope="Testing-only independent native full reference/parent/mixture/freeze audit; not fresh blind proof",
        implementationKey=key,
        cohorts=evidence,
    )
    args.report.with_suffix(".integrity.json").write_text(json.dumps(output, indent=2, allow_nan=False))
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
