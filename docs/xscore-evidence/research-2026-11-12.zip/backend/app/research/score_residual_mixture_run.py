"""Testing only: conditional AA mixture search with fixed longer-training confirmation."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from app.research import score_action_network as network
from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_local_errors as local
from app.research import score_local_errors_run as local_runner
from app.research import score_matchups_run as matched
from app.research import score_mixture_ordinary as mixture_base
from app.research import score_modal_capacity_run as controls
from app.research import score_modal_trees as modal
from app.research import score_ordinary as ordinary
from app.research import score_residual_mixture as mixture
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_search import POSITIONS, cutoff_for, measure
from app.research.score_stats_run import paired_interval

MODELS = mixture.SETTINGS


def fitted(bank, context, positions, mask, old, model, epochs, path, key):
    if path.exists():
        with np.load(path) as f:
            stats = json.loads(str(f["statistics"]))
            if (
                str(f["key"]) != key
                or not np.array_equal(f["classes"], old[0])
                or not np.array_equal(f["probability"], old[1])
                or stats["epochs"] != epochs
            ):
                raise ValueError("Residual mixture cached identity differs")
            return f["mass"], stats
    mass, stats = mixture.fit_forecasts(
        bank, context, old, positions, cutoff_for(mask["first"]).timestamp(), MODELS[model], epochs
    )
    np.savez_compressed(path, key=key, classes=old[0], probability=old[1], mass=mass, statistics=json.dumps(stats))
    return mass, stats


def prepare_banks(rows, context, cohort, args, old_match, old_stability, old_ordinary, key):
    masks = stability.phase_masks(rows)
    bank = None
    banks = {}
    unknown = {}
    for phase, _, _ in stability.PHASES:
        target = masks[phase]["target"]
        if phase != "warm2023":
            banks[phase] = {n: v.copy() for n, v in bank.items()}
            path = args.cache / f"{args.out.stem}_bank_{cohort}_{phase}_{key[:12]}.npz"
            if path.exists():
                with np.load(path) as f:
                    if str(f["key"]) != key or any(
                        not np.array_equal(f[n], v, equal_nan=True)
                        if v.dtype.kind in "fc"
                        else not np.array_equal(f[n], v)
                        for n, v in banks[phase].items()
                    ):
                        raise ValueError("Residual mixture immutable OOF bank differs")
            else:
                np.savez_compressed(path, key=key, **banks[phase])
        if phase == "later2026":
            break
        old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
        prior_rows = [r for r, yes in zip(rows, target, strict=True) if yes]
        current, unknown[phase] = local_runner.calibration_records(prior_rows, context[target], old)
        bank = current if bank is None else {n: np.concatenate((bank[n], current[n])) for n in bank}
    return banks, unknown


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    import scipy
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    read = lambda n: json.loads((args.out.parent / (n + ".json")).read_text())
    old_match, old_player, old_stability, old_ordinary, old_start, old_bench = map(
        read,
        (
            "laliga_score_match_context",
            "laliga_score_player_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_match_empirical_density",
            "laliga_score_analogues",
        ),
    )
    if any(
        r["sourceKey"] != source["key"]
        for r in (old_match, old_player, old_stability, old_ordinary, old_start, old_bench)
    ):
        raise ValueError("Mixture AA source cases differ")
    with np.load(args.cache / "stats.npz") as f:
        base, names, stat_key = f["x"], f["names"].tolist(), str(f["key"])
        matched.validate_stat_identity(stat_key, old_match, old_player)
    with np.load(args.cache / "match_context_features.npz") as f:
        if str(f["key"]) != old_match["featureKey"]:
            raise ValueError("Mixture AA match features differ")
        match, match_names = f["x"], f["names"].tolist()
    with np.load(args.cache / "player_context_features.npz") as f:
        if str(f["key"]) != old_player["featureKey"]:
            raise ValueError("Residual mixture player feature identity differs")
        player, player_names = f["x"], f["names"].tolist()
    if any(len(v) != len(source["rows"]) for v in (base, match, player)):
        raise ValueError("Residual mixture source coverage differs")
    modules = (
        mixture,
        mixture_base,
        network,
        local,
        local_runner,
        empirical,
        flow,
        matched,
        controls,
        modal,
        ordinary,
        stability,
        windows,
    )
    key = hashlib.sha256(
        (
            source["key"]
            + stat_key
            + old_match["featureKey"]
            + old_player["featureKey"]
            + old_match["implementationKey"]
            + old_stability["implementationKey"]
            + old_ordinary["implementationKey"]
            + scipy.__version__
            + np.__version__
        ).encode()
        + Path(__file__).read_bytes()
        + args.out.with_suffix(".plan.json").read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()
    report = {
        "scope": "Testing only, conditional out-of-fit ordinary-error mixture densities; no application changes",
        "sourceKey": source["key"],
        "implementationKey": key,
        "evidenceLimit": "Repeated historical reuse, exploratory not fresh blind proof",
        "cohorts": {},
    }
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] == key:
            report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        keep = np.array([r["cohort"] == cohort for r in source["rows"]])
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        args.rows = rows
        y = np.array([r["score"] for r in rows], dtype=float)
        positions = np.array([r["pos"] for r in rows])
        masks = stability.phase_masks(rows)
        numeric, ordinary_names = ordinary.ordinary_inputs(
            base[keep], names, player[keep], player_names, match[keep], match_names, cohort
        )
        context = numeric[:, [ordinary_names.index(n.format(c=cohort)) for n in local.CONTEXT]]
        banks, unknown_banks = prepare_banks(rows, context, cohort, args, old_match, old_stability, old_ordinary, key)
        candidates = [
            {"spec": {"model": m, "scope": s}, "gains": [], "errors": [], "counts": [], "periods": {}}
            for m in MODELS
            for s in ("all", "defmid")
        ]
        audit = {"unknownHistoricalClassesAdded": unknown_banks}

        def phase_inputs(phase, masks=masks, cohort=cohort, y=y):
            target = masks[phase]["target"]
            old = flow.old_components(args, cohort, phase, old_match, old_stability, old_ordinary)
            control = controls.control_for(
                args, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
            )
            expected = (
                old_stability["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else (old_start if cohort == "start" else old_bench)["cohorts"][cohort]["later"]
            )
            if measure(y[target], control) != expected:
                raise ValueError("Mixture AA strongest control differs")
            return target, old, control, expected

        def cached(
            phase, model, epochs, old, cohort=cohort, context=context, banks=banks, positions=positions, masks=masks
        ):
            print(f"RESIDUAL_MIXTURE_FITTING {cohort} {phase} {model} epochs{epochs}", flush=True)
            return fitted(
                banks[phase],
                context[masks[phase]["target"]],
                positions[masks[phase]["target"]],
                masks[phase],
                old,
                model,
                epochs,
                args.cache / f"{args.out.stem}_{cohort}_{phase}_{model}_e{epochs}.npz",
                key,
            )

        for phase, _, _ in stability.PHASES[1:-1]:
            target, old, control, expected = phase_inputs(phase)
            audit[phase] = {"fit": int(masks[phase]["fit"].sum()), "target": int(target.sum()), "models80": {}}
            for model in MODELS:
                mass, stats = cached(phase, model, 80, old)
                audit[phase]["models80"][model] = stats
                raw = windows.window_centres(mass, modal.CENTRES)
                for record in [r for r in candidates if r["spec"]["model"] == model]:
                    forecast = ordinary.scoped_prediction(raw, control, positions[target], record["spec"]["scope"])
                    metric = measure(y[target], forecast)
                    gain = metric["within7"] - expected["within7"]
                    record["gains"].append(gain)
                    record["errors"].append(metric["mae"])
                    record["counts"].append(len(forecast))
                    record["periods"][phase] = {"gain": gain, "metrics": metric}
        initial_winner, initial_best = stability.choose_stable(candidates)
        confirmation = {"spec": initial_best["spec"], "gains": [], "errors": [], "counts": [], "periods": {}}
        args.out.with_name(args.out.stem + f".{cohort}.selection80.json").write_text(
            json.dumps(
                {"implementationKey": key, "winner": initial_winner, "best": initial_best, "candidates": candidates},
                indent=2,
            )
        )
        print("RESIDUAL_MIXTURE_CONFIRM " + json.dumps({"cohort": cohort, "spec": initial_best["spec"]}), flush=True)
        for phase, _, _ in stability.PHASES[1:-1]:
            target, old, control, expected = phase_inputs(phase)
            mass, stats = cached(phase, initial_best["spec"]["model"], 160, old)
            audit[phase]["confirmation160"] = stats
            raw = windows.window_centres(mass, modal.CENTRES)
            forecast = ordinary.scoped_prediction(raw, control, positions[target], initial_best["spec"]["scope"])
            metric = measure(y[target], forecast)
            gain = metric["within7"] - expected["within7"]
            confirmation["gains"].append(gain)
            confirmation["errors"].append(metric["mae"])
            confirmation["counts"].append(len(forecast))
            confirmation["periods"][phase] = {"gain": gain, "metrics": metric}
        winner = confirmation if min(confirmation["gains"]) > 0 else None
        args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
            json.dumps(
                {
                    "implementationKey": key,
                    "winner": winner,
                    "best": confirmation,
                    "initialWinner80": initial_winner,
                    "initialBest80": initial_best,
                    "candidates80": candidates,
                },
                indent=2,
            )
        )
        print("FROZEN " + json.dumps({"cohort": cohort, "winner": winner, "best": confirmation}), flush=True)
        target, old, control, expected = phase_inputs("later2026")
        mass, stats = cached("later2026", confirmation["spec"]["model"], 160, old)
        audit["later2026"] = stats
        alternate = ordinary.scoped_prediction(
            windows.window_centres(mass, modal.CENTRES), control, positions[target], confirmation["spec"]["scope"]
        )
        prediction = alternate if winner else control.copy()
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        result = {
            "selected": "candidate" if winner else "control",
            "candidate": confirmation,
            "winner": winner,
            "initialBest80": initial_best,
            "candidateCount80": len(candidates) + 1,
            "earlierPeriods": audit,
            "later": measure(y[target], prediction),
            "candidateLater": measure(y[target], alternate),
            "control": expected,
            "candidateGainedCorrect": int((h1 & ~h0).sum()),
            "candidateLostCorrect": int((h0 & ~h1).sum()),
            "candidateGain95": paired_interval(
                y[target], alternate, control, [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
            ),
            "positions": {
                p: {
                    "candidate": measure(y[target][positions[target] == p], alternate[positions[target] == p]),
                    "control": measure(y[target][positions[target] == p], control[positions[target] == p]),
                }
                for p in POSITIONS
                if (positions[target] == p).any()
            },
        }
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            alternate=alternate,
            prediction=prediction,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(
                {"cohort": cohort, "selected": result["selected"], "candidateLater": result["candidateLater"]}
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
