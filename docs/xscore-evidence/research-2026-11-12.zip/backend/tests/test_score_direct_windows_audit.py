"""Testing only: independently reconstruct the frozen native window selection rule."""

import numpy as np
import pytest

from app.research import score_direct_windows as parent
from app.research import score_direct_windows_audit as audit


def test_independent_direct_audit_matches_native_ties_thresholds_and_all_case_scopes():
    rng = np.random.default_rng(81)
    p = rng.uniform(size=(120, 101))
    control = rng.integers(0, 201, 120) / 2
    pos = np.resize(np.array(["GK", "DEF", "MID", "FWD", "unknown"]), 120)
    p[0] = 0.1
    p[0, 40] = p[0, 80] = 0.6
    control[0] = 56.0
    p[1] = 0.1
    p[1, 40] = 0.625
    p[1, 50] = 0.5
    control[1] = 50.0
    p[2] = 0.1
    p[2, 40] = p[2, 41] = 0.7
    control[2] = 40.5
    np.testing.assert_array_equal(audit.independent_choice(p, control), parent.direct_choice(p, control))
    assert audit.independent_choice(p, control)[0] == 40
    for threshold in (0, 0.01, 0.025, 0.05, 0.125):
        for scope in ("all", "defmid"):
            np.testing.assert_array_equal(
                audit.independent_gate(p, control, pos, threshold, scope),
                parent.gated_choice(p, control, pos, threshold, scope),
            )
    assert audit.independent_gate(p, control, pos, 0.125, "all")[1] == 50
    assert audit.independent_gate(p, control, pos, 0, "all")[2] == 40.5


def test_independent_direct_audit_rejects_missing_or_invalid_probabilities():
    for p in (np.full((2, 101), np.nan), np.full((2, 101), -0.1), np.ones((2, 100)), np.full((2, 101), 1.1)):
        with pytest.raises(ValueError, match="probabilit"):
            audit.independent_choice(p, np.array([0.0, 100.0]))
