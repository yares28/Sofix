"""Testing only: past score modes and honest bounds for unpriced tackle counts."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path

import numpy as np

from app.research.score_modal_trees import CENTRES
from app.research.score_search import cutoff_for, moment


def combo_bonus(net_duels, tackles, interceptions):
    values = (net_duels, tackles, interceptions)
    if min(values) >= 3:
        return 12
    if min(values) >= 2:
        return 6
    return 4 if sum(v >= 2 for v in values) >= 2 else 0


def tackle_bounds(net_duels, interceptions, bonus):
    if not np.isfinite([net_duels, interceptions, bonus]).all():
        raise ValueError("Known bonus inputs required")
    possible = [t for t in range(4) if combo_bonus(net_duels, t, interceptions) == bonus]
    if not possible:
        raise ValueError("Recorded bonus is inconsistent with observed duel/interception counts")
    return min(possible), np.inf if 3 in possible else max(possible)


def _mode(scores):
    if not len(scores):
        return np.nan
    mass = (np.abs(scores[:, None] - CENTRES) <= 7).sum(axis=0)
    winners = CENTRES[mass == mass.max()]
    return float(winners[np.argmin(np.abs(winners - np.median(scores)))])


def history_summary(history):
    values = np.asarray(history, dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Unknown historical scores cannot become zero")
    low, high = values[values < 60], values[values >= 60]
    count = len(values)
    result = {
        "count": float(count),
        "mode": _mode(values),
        "low_mode": _mode(low),
        "high_mode": _mode(high),
        "high_fraction": float(len(high) / count) if count else np.nan,
    }
    for name, group in (("low", low), ("high", high)):
        mass = (np.abs(group[:, None] - CENTRES) <= 7).sum(axis=0).max() if len(group) else 0
        result[name + "_window_mass"] = float(mass / count) if count else np.nan
    for value in (35, 45, 60, 75, 90):
        result[f"mass_at_{value}"] = float(np.mean(np.abs(values - value) <= 7)) if count else np.nan
    result["mode5"], result["mode10"] = _mode(values[-5:]), _mode(values[-10:])
    result["mode5_change"] = result["mode5"] - result["mode"]
    return result


def record_bounds(row, person):
    stats = person.get("stats")
    if not isinstance(stats, dict):
        raise ValueError("Point-stat export missing")
    net = stats.get("duel_won", [0])[0] - stats.get("duel_lost", [0])[0]
    interceptions = stats.get("interception_won", [0])[0]
    bonus = sum(stats.get(n, [0, 0])[1] for n in ("double_double", "triple_double", "triple_triple"))
    if row["pos"] == "GK":
        low, high = 0, np.inf
    else:
        low, high = tackle_bounds(net, interceptions, bonus)
    observed = "won_tackle" in stats or row["pos"] in ("DEF", "MID")
    if observed:
        actual = stats.get("won_tackle", [0])[0]
        if not low <= actual <= high:
            raise ValueError("Native priced tackles fail the bonus bound")
        low = high = actual
    return {"low": low, "high": high, "observed": observed, "bonus": bonus, "minutes": row["minutes"]}


def build_history(rows, games):
    games_by_id = {g["id"]: g for g in games}
    records, identities = [], set()
    for row in rows:
        identity = row["game"], row["player"]
        if identity in identities:
            raise ValueError("Duplicate historical case")
        identities.add(identity)
        game = games_by_id[row["game"]]
        person = game["players"][row["player"]]
        if (
            game["date"] != row["date"]
            or person["pos"] != row["pos"]
            or row["cohort"] != ("start" if person["started"] else "bench")
        ):
            raise ValueError("Historical row identity differs")
        bound = record_bounds(row, person)
        records.append(
            {
                "available": moment(row["date"]) + timedelta(hours=48),
                "player": row["player"],
                "cohort": row["cohort"],
                "score": row["score"],
                **bound,
            }
        )
    records.sort(key=lambda r: r["available"])
    histories = defaultdict(lambda: deque(maxlen=20))
    seen, old_cutoff = 0, None
    values, names = [], []
    audit = {
        "rows": len(rows),
        "canonicalHistoryAgreements": 0,
        "exactTackleRecords": int(sum(r["observed"] for r in records)),
        "censoredPositiveMinimumRecords": int(sum(not r["observed"] and r["low"] > 0 for r in records)),
        "informativeCensoredRecords": int(
            sum(not r["observed"] and (r["low"] > 0 or np.isfinite(r["high"])) for r in records)
        ),
    }
    for row in rows:
        cutoff = cutoff_for(row["date"])
        if old_cutoff is not None and cutoff < old_cutoff:
            raise ValueError("History rows must be chronological")
        old_cutoff = cutoff
        while seen < len(records) and records[seen]["available"] < cutoff:
            record = records[seen]
            histories[record["player"], record["cohort"]].append(record)
            seen += 1
        history = list(histories[row["player"], row["cohort"]])
        scores = [r["score"] for r in history]
        if scores != row["recent"]:
            raise ValueError("Rebuilt past-only scores differ from canonical history")
        audit["canonicalHistoryAgreements"] += 1
        features = {"modal_history_" + k: v for k, v in history_summary(scores).items()}
        recent = history[-10:]
        exposure = sum(r["minutes"] for r in recent)
        features["tackle_observed_fraction"] = float(np.mean([r["observed"] for r in recent])) if recent else np.nan
        features["tackle_informative_fraction"] = (
            float(np.mean([r["low"] > 0 or np.isfinite(r["high"]) for r in recent])) if recent else np.nan
        )
        features["tackle_minimum90"] = sum(r["low"] for r in recent) * 90 / exposure if exposure else np.nan
        features["tackle_maximum90"] = (
            sum(r["high"] for r in recent) * 90 / exposure
            if exposure and all(np.isfinite(r["high"]) for r in recent)
            else np.nan
        )
        for bonus in (4, 6, 12):
            features[f"bonus_{bonus}_fraction"] = (
                float(np.mean([r["bonus"] == bonus for r in recent])) if recent else np.nan
            )
        if names and names != list(features):
            raise ValueError("History feature order changed")
        names = list(features)
        values.append(list(features.values()))
    return np.array(values), names, audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "games", "out", "report"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.cases.read_text())
    raw = args.games.read_bytes()
    games = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    key = hashlib.sha256(
        source["key"].encode() + raw + Path(__file__).read_bytes() + args.report.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    values, names, audit = build_history(source["rows"], games)
    if values.shape != (len(source["rows"]), len(names)) or np.isinf(values).any():
        raise ValueError("Invalid historical input coverage")
    np.savez_compressed(args.out, key=key, x=values, names=names)
    args.report.write_text(
        json.dumps(
            {
                "sourceKey": source["key"],
                "featureKey": key,
                "scope": "Testing-only inputs; no accuracy claim",
                "features": len(names),
                "audit": audit,
            },
            indent=2,
        )
    )
    print(json.dumps({"features": len(names), "audit": audit, "featureKey": key}), flush=True)


if __name__ == "__main__":
    main()
