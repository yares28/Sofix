"""Testing-only workflow contract for observed workload forecast ablations."""

import numpy as np
import pytest

from app.research import score_observed_workload as workload
from app.research import score_workload_conditioning as conditioning


def test_europe_ablation_never_uses_combined_club_or_player_features():
    groups = conditioning.feature_groups(workload.NAMES)
    assert groups["covered"].sum() == 86
    assert groups["euro"].sum() == 44
    assert all(n.startswith("load_euro_") for n, yes in zip(workload.NAMES, groups["euro"], strict=True) if yes)
    with pytest.raises(ValueError, match="names differ"):
        conditioning.feature_groups(list(workload.NAMES)[::-1])


def test_recent_scope_preserves_cold_unknown_and_recorded_zero_cases():
    x = np.full((5, len(workload.NAMES)), np.nan)
    p, c = (workload.NAMES.index(n) for n in ("load_euro_player_28_known_rows", "load_euro_club_14_observed_fixtures"))
    x[:, p] = [np.nan, 0, 1, 0, 0]
    x[:, c] = [np.nan, 0, 0, 1, 0]
    # One known row can be an explicit DNP. It is observed information, not absent history.
    x[2, workload.NAMES.index("load_euro_player_28_known_minutes")] = 0
    coverage = conditioning.recent_europe(x, workload.NAMES)
    assert coverage.tolist() == [False, False, True, True, False]
    candidate, control = np.arange(5, dtype=float) + 10, np.arange(5, dtype=float) + 20
    result = conditioning.scoped_prediction(candidate, control, coverage, "recent_euro")
    np.testing.assert_array_equal(result, [20, 21, 12, 13, 24])
    np.testing.assert_array_equal(conditioning.scoped_prediction(candidate, control, coverage, "all"), candidate)
    assert len(result) == 5
    with pytest.raises(ValueError, match="coverage differs"):
        conditioning.scoped_prediction(candidate, control[:3], coverage, "all")
    with pytest.raises(ValueError, match="scope"):
        conditioning.scoped_prediction(candidate, control, coverage, "select_winners")
