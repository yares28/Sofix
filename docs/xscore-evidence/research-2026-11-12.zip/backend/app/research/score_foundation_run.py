"""Repeatable LaLiga foundation experiment. Research only; no model promotion."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np

from app.research.score_foundation import build_cases
from app.research.score_search import POSITIONS, bootstrap, cutoff_for, interval_mode, measure

CONTRACT = {
    "requestedOutcome": "LaLiga score if starting and score if coming off bench; maximise share within seven points, aiming above 50% separately",
    "userActions": "None; investigate local archive, build missing signals, compare on later games",
    "authority": "Change/rebuild formula, combine signals and try random variables as controls; no change of target to average score",
    "primary": "Within seven on every eligible appearance, starts and substitutes separately; no pooled claim or confidence-based exclusions",
    "secondary": "Average error, bias, per-position coverage, weekly uncertainty and errors on high-score games",
    "split": "Train before July 2025; choose before January 2026; refit before January 2026; evaluate January-October 2026 once per frozen candidate",
    "evidenceLimit": "Retrospective forward test; these seasons were previously examined. Future prospective confirmation remains required",
    "availability": "Inferred Tuesday/Friday 14 UTC lock, results delayed 48h; no current-game stats, minutes, XI, score, decisive level or closing prices in normal predictions",
    "assumptions": "Previous formation line/width is a historical descriptor, not verified role tonight; only LaLiga workload is known",
    "diagnostics": "Future-known level/AA diagnostics quantify missing signal; never counted as usable predictions",
    "promotion": "Research only. Production and other competitions retain existing calculations until explicit release evidence",
}


def score_from_parts(level: float, allaround: np.ndarray) -> np.ndarray:
    return np.clip(level + allaround, level if level >= 60 else 0, 100)


def best_window(probability: np.ndarray) -> np.ndarray:
    """Input already represents P(actual score within seven of each centre)."""
    centres = np.arange(101)
    winners = np.abs(probability - probability.max(axis=1, keepdims=True)) <= 1e-12
    middle = (winners * centres).sum(axis=1) / winners.sum(axis=1)
    distance = np.where(winners, np.abs(centres - middle[:, None]), np.inf)
    return centres[distance.argmin(axis=1)].astype(float)


def football_context(games: list[dict[str, Any]], cache: Path) -> dict[str, Any]:
    """Fixed existing football architecture, fitted to local CSV results strictly before each lock."""
    import pandas as pd

    from app.backtest.data import load_history
    from app.modeling.dixon_coles import fit_dixon_coles
    from app.services.rating_predictions import load_config
    from app.sorare.gamedata import CLUB

    aliases = {
        **CLUB,
        "UD Almería": "Almeria",
        "UD Las Palmas": "Las Palmas",
        "Cádiz CF": "Cadiz",
        "Granada CF": "Granada",
        "CD Leganés": "Leganes",
        "Real Valladolid CF": "Valladolid",
    }
    matches = load_history(range(2016, 2027), cache, refresh_latest=False)
    config = load_config(Path(__file__).resolve().parents[2] / "artifacts/dixon_coles.json")
    out = {}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for g in games:
        grouped.setdefault(cutoff_for(g["date"]).isoformat(), []).append(g)
    for i, (lock, group) in enumerate(sorted(grouped.items())):
        clubs = {aliases[g[side]["name"]] for g in group for side in ("home", "away")}
        # Day-only CSV dates plus a conservative two-day publication allowance.
        before = pd.Timestamp(lock).tz_localize(None).normalize() - pd.Timedelta(days=2)
        model = fit_dixon_coles(matches, before, teams=clubs, config=config)
        prediction = model.predict(
            [aliases[g["home"]["name"]] for g in group], [aliases[g["away"]["name"]] for g in group]
        )
        for g, row in zip(group, prediction.to_dict("records"), strict=True):
            out[g["id"]] = {
                "before": lock,
                **{k: float(row[k]) for k in ("lam_h", "lam_a", "cs_h", "cs_a", "p_h", "p_d", "p_a")},
            }
        if i % 30 == 0:
            print(f"football contexts {i + 1}/{len(grouped)}", flush=True)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--packages", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingClassifier, HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=4)
    args.cache.mkdir(parents=True, exist_ok=True)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.with_suffix(".plan.json").write_text(json.dumps(CONTRACT, indent=2), encoding="utf-8")
    raw = args.games.read_bytes()
    fingerprint = hashlib.sha256(raw + Path(__file__).with_name("score_foundation.py").read_bytes()).hexdigest()
    games = [json.loads(s) for s in raw.decode("utf-8").splitlines() if s.strip()]
    context_path = args.cache / "football.json"
    csv_hash = hashlib.sha256(b"".join(p.read_bytes() for p in sorted(args.csv.glob("SP1_*.csv")))).hexdigest()
    context_key = hashlib.sha256(raw).hexdigest() + csv_hash
    cached = json.loads(context_path.read_text()) if context_path.exists() else {}
    if cached.get("key") != context_key:
        cached = {"key": context_key, "context": football_context(games, args.csv)}
        context_path.write_text(json.dumps(cached), encoding="utf-8")
    case_path = args.cache / "cases.json"
    casekey = fingerprint + context_key
    data = json.loads(case_path.read_text()) if case_path.exists() else {}
    if data.get("key") != casekey:
        rows, names = build_cases(games, cached["context"])
        data = {"key": casekey, "rows": rows, "features": names}
        case_path.write_text(json.dumps(data), encoding="utf-8")
    rows, names = data["rows"], data["features"]
    report: dict[str, Any] = {
        "contract": CONTRACT,
        "sourceSha256": hashlib.sha256(raw).hexdigest(),
        "games": len(games),
        "appearances": len(rows),
        "features": names,
        "cohorts": {},
        "status": "running",
    }
    for cohort in ("start", "bench"):
        mine = [r for r in rows if r["cohort"] == cohort]
        x = np.asarray([r["x"] for r in mine], dtype=np.float32)
        y = np.array([r["score"] for r in mine])
        dates = np.array([r["date"][:10] for r in mine])
        train, valid, test = (
            dates < "2025-07-01",
            (dates >= "2025-07-01") & (dates < "2026-01-01"),
            dates >= "2026-01-01",
        )
        out: dict[str, Any] = {
            "train": int(train.sum()),
            "selection": int(valid.sum()),
            "later": int(test.sum()),
            "candidates": [],
        }
        chosen: dict[str, Any] | None = None
        later_predictions = {}

        def record(
            name: str,
            validation: np.ndarray,
            prediction: np.ndarray,
            truth: np.ndarray = y[valid],
            collection: dict[str, Any] = out,
            forecasts: dict[str, np.ndarray] = later_predictions,
            cohort_name: str = cohort,
        ) -> None:
            nonlocal chosen
            value = {"name": name, "selection": measure(truth, validation)}
            collection["candidates"].append(value)
            forecasts[name] = prediction
            if "random_control" not in name and (
                chosen is None or value["selection"]["within7"] > chosen["selection"]["within7"]
            ):
                chosen = value
            print(cohort_name + " selection " + json.dumps(value), flush=True)

        # Simple player-specific and position baselines; all test cases remain included.
        position_mode = {
            p: interval_mode([r["score"] for r, keep in zip(mine, train, strict=True) if keep and r["pos"] == p])
            for p in POSITIONS
        }
        constant = np.array([position_mode[r["pos"]] for r in mine])
        record("position_common_score", constant[valid], constant[test])
        recent = np.array([interval_mode(r["recent"]) if r["recent"] else position_mode[r["pos"]] for r in mine])
        record("own_common_score", recent[valid], recent[test])
        centres = np.arange(101)
        target = (np.abs(y[:, None] - centres) <= 7).astype(np.float32)
        masks = {
            "full": np.ones(len(names), dtype=bool),
            "without_matchup": np.array([not n.startswith(("style_", "match_", "opponent_")) for n in names]),
        }
        # Train and refit only before the later evaluation boundary. Selection never uses later metrics.
        for group, columns in masks.items():
            for minimum in (30, 100):
                params = dict(
                    n_estimators=100,
                    min_samples_leaf=minimum,
                    max_features=0.7,
                    max_depth=16,
                    n_jobs=4,
                    random_state=20261103,
                )
                model = ExtraTreesRegressor(**params).fit(x[train][:, columns], target[train])
                validation = best_window(model.predict(x[valid][:, columns]))
                model.fit(x[~test][:, columns], target[~test])
                prediction = best_window(model.predict(x[test][:, columns]))
                record(f"window_forest:{group}:{minimum}", validation, prediction)
        # Noise is a negative control, not an assertion that arbitrary variables explain football.
        noise = np.random.default_rng(20261103).normal(size=(len(x), 8)).astype(np.float32)
        z = np.column_stack((x, noise))
        model = ExtraTreesRegressor(
            n_estimators=100, min_samples_leaf=30, max_features=0.7, max_depth=16, n_jobs=4, random_state=20261103
        )
        model.fit(z[train], target[train])
        validation = best_window(model.predict(z[valid]))
        model.fit(z[~test], target[~test])
        prediction = best_window(model.predict(z[test]))
        record("window_forest:random_control", validation, prediction)
        # Rebuild score from the predicted decisive level and all-around points for each possible level.
        level = np.array([r["level"] for r in mine])
        aa = np.array([r["aa"] for r in mine])
        for minimum in (50, 150):
            predictions = []
            for fit, evaluate in ((train, valid), (~test, test)):
                classifier = HistGradientBoostingClassifier(
                    max_leaf_nodes=7,
                    min_samples_leaf=minimum,
                    max_iter=100,
                    l2_regularization=10,
                    early_stopping=False,
                    random_state=20261103,
                )
                classifier.fit(x[fit], level[fit].astype(int))
                regressor = HistGradientBoostingRegressor(
                    loss="absolute_error",
                    max_leaf_nodes=15,
                    min_samples_leaf=minimum,
                    max_iter=120,
                    l2_regularization=10,
                    early_stopping=False,
                    random_state=20261103,
                )
                regressor.fit(np.column_stack((x[fit], level[fit])), aa[fit])
                levels = classifier.classes_
                probability = classifier.predict_proba(x[evaluate])
                possible = np.column_stack(
                    [regressor.predict(np.column_stack((x[evaluate], np.full(evaluate.sum(), v)))) for v in levels]
                )
                # Approximate remaining AA variation with a fixed symmetric kernel; tuned only on selection.
                mass = np.zeros((evaluate.sum(), 101))
                for j in range(len(levels)):
                    for residual in (-12, -6, 0, 6, 12):
                        simulated = score_from_parts(levels[j], possible[:, j, None] + residual)
                        mass += probability[:, j, None] * (np.abs(simulated - centres) <= 7)
                predictions.append(best_window(mass))
            record(f"decisive_then_allaround:{minimum}", *predictions)
        assert chosen is not None
        # Freeze the winner using earlier scores before calculating any later accuracy summaries.
        out["chosen"] = chosen
        out["laterResults"] = {name: measure(y[test], prediction) for name, prediction in later_predictions.items()}
        prediction = later_predictions[chosen["name"]]
        testrows = [r for r, keep in zip(mine, test, strict=True) if keep]
        out["weekly95"] = bootstrap(y[test], prediction, [r["week"] for r in testrows])
        out["positions"] = {
            p: measure(
                y[test][np.array([r["pos"] == p for r in testrows])],
                prediction[np.array([r["pos"] == p for r in testrows])],
            )
            for p in POSITIONS
            if any(r["pos"] == p for r in testrows)
        }
        out["highScoreCases"] = (
            measure(y[test][y[test] >= 60], prediction[y[test] >= 60]) if (y[test] >= 60).any() else None
        )
        # Source of missing signal: hypothetical perfect knowledge, explicitly excluded from candidate ranking.
        aa_mean = x[test, names.index(f"{cohort}_10_aa")]
        level_mean = x[test, names.index(f"{cohort}_10_level")]
        out["diagnosticOnly"] = {
            "knowsActualLevel": measure(
                y[test], np.clip(level[test] + aa_mean, np.where(level[test] >= 60, level[test], 0), 100)
            ),
            "knowsActualAllAround": measure(y[test], np.clip(level_mean + aa[test], 0, 100)),
            "notUsablePredictions": True,
        }
        out["weeks"] = len(set(r["week"] for r in testrows))
        report["cohorts"][cohort] = out
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(
            "COHORT RESULT "
            + json.dumps(
                {
                    "cohort": cohort,
                    "chosen": chosen,
                    "later": out["laterResults"][chosen["name"]],
                    "positions": out["positions"],
                }
            ),
            flush=True,
        )
    report["status"] = "research complete; no production promotion"
    report["coverage"] = dict(Counter(r["cohort"] for r in rows))
    args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
