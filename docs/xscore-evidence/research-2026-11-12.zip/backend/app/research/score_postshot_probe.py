"""Testing-only provider post-shot source qualification, never same-match forecasts."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

from app.research.score_prior_chances import words


def probability(value):
    return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1


def qualify(shots, native_sot, parent_known, collision):
    reasons = []
    if not parent_known:
        reasons.append("parent_identity_or_stream_unknown")
    if collision:
        reasons.append("same_side_surname_collision")
    if any(s.get("xgot_fotmob") is not None and not probability(s["xgot_fotmob"]) for s in shots):
        reasons.append("invalid_provider_quality")
    valid = [s for s in shots if probability(s.get("xgot_fotmob"))]
    if len(valid) != native_sot:
        reasons.append("provider_count_differs_native_sot")
    if any(s["xgot_fotmob"] > 0 and s.get("onTarget") is not True for s in valid):
        reasons.append("positive_postshot_on_offtarget")
    known = not reasons
    total = sum(s["xgot_fotmob"] for s in valid) if known else None
    paired = known and all(probability(s.get("xg_fotmob")) for s in valid)
    before = sum(s["xg_fotmob"] for s in valid) if paired else None
    return dict(
        known=known,
        reasons=reasons,
        nativeSOT=float(native_sot),
        providerCount=len(valid),
        postshotTotal=total,
        matchedPreshotTotal=before,
        postshotPerTarget=total / native_sot if known and native_sot > 0 else None,
        placementPerTarget=(total - before) / native_sot if paired and native_sot > 0 else None,
        zeroOrigin="native_no_sot_derived_zero" if known and native_sot == 0 else None,
    )


def build(native, games):
    sides = {(r["game"], r["club"]): r for r in native["sides"]}
    if len(sides) != len(native["sides"]):
        raise ValueError("Duplicate source side")
    people = defaultdict(list)
    for r in native["players"]:
        people[r["game"], r["club"]].append(r)
    collisions, streams = {}, {}
    for identity, side in sides.items():
        actor_names = {r["sourcePlayer"] for r in people[identity] if r["sourcePlayer"]}
        actor_names.update(s["player"] for s in side["shots"] if s.get("player"))
        surnames = Counter(words(name)[-1] for name in actor_names if words(name))
        collisions[identity] = {name for name in actor_names if words(name) and surnames[words(name)[-1]] > 1}
        by_player = defaultdict(list)
        for s in side["shots"]:
            by_player[words(s["player"])].append(s)
        streams[identity] = by_player
    records, totals, reasons, years = [], Counter(), Counter(), defaultdict(Counter)
    for r in native["players"]:
        g, p = games[r["game"]], games[r["game"]]["players"][r["player"]]
        if (
            g["date"] != r["date"]
            or p["team"] != r["club"]
            or p.get("played") is not True
            or p.get("ver") != 7
            or p.get("mins") != r["minutes"]
            or not isinstance(p.get("stats"), dict)
        ):
            raise ValueError("Mapped source/native player identity differs")
        native_sot = p["stats"].get("ontarget_scoring_att", [0, 0])[0]
        identity = r["game"], r["club"]
        shots = streams[identity].get(words(r["sourcePlayer"] or ""), [])
        result = qualify(shots, native_sot, r["known"], r["sourcePlayer"] in collisions[identity])
        records.append(
            {k: r[k] for k in ("game", "date", "player", "club", "cohort", "minutes", "sourcePlayer")} | result
        )
        local = Counter(
            records=1,
            nativeSOT=int(native_sot),
            known=int(result["known"]),
            knownNativeSOT=int(native_sot) if result["known"] else 0,
            knownPositiveSOT=int(result["known"] and native_sot > 0),
            pairedPositiveSOT=int(result["placementPerTarget"] is not None),
            derivedZeroSOT=int(result["zeroOrigin"] is not None),
        )
        totals.update(local)
        years[r["date"][:4]].update(local)
        reasons.update(result["reasons"])
    return records, dict(
        counts=dict(totals),
        reasons=dict(reasons),
        years={y: dict(c) for y, c in years.items()},
        sameSideSurnameCollisionNames=sum(len(v) for v in collisions.values()),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_postshot_probe.json"))
    args = parser.parse_args()
    raw, original = args.games.read_bytes(), (args.cache / "shot_style_observations.json.gz").read_bytes()
    if (
        hashlib.sha256(raw).hexdigest() != "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"
        or hashlib.sha256(original).hexdigest() != "31f5b36e6bddabeec8a143ebfe21ac213a6bfe7b3fd58f4c92be1f014191ab47"
    ):
        raise ValueError("Pinned raw post-shot source differs")
    native = json.loads(gzip.decompress(original))
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    records, summary = build(native, games)
    key = hashlib.sha256(
        raw + original + Path(__file__).read_bytes() + args.out.with_suffix(".plan.json").read_bytes()
    ).hexdigest()
    path = args.cache / "postshot_observations.json.gz"
    path.write_bytes(
        gzip.compress(
            json.dumps(dict(key=key, records=records), separators=(",", ":"), allow_nan=False).encode(), mtime=0
        )
    )
    report = dict(
        scope="Provider post-shot source-only qualification, no accuracy claim",
        implementationKey=key,
        nativeSHA=hashlib.sha256(raw).hexdigest(),
        originalShotSHA=hashlib.sha256(original).hexdigest(),
        observationsSHA=hashlib.sha256(path.read_bytes()).hexdigest(),
        summary=summary,
        provenance="Pinned provider xgot_fotmob only; same-surname/minute best-effort publisher linkage; numeric provider zero already lost as null. Qualified only when native scoring SOT count matches and source actor/flags uncontradicted.",
        warning="Quality and timing remain retrospective source assumptions, not original provider shot-ID/receipt proof. Zero-native-SOT derived total is explicit; no division-based placement value for zero shots. Placement delta uses paired on-target provider shots, not official SGA.",
        next="Independent every-raw-shot/qualification/identity audit required, then preregister time-lag features. No source-based exclusion of forecast cases.",
    )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print("POSTSHOT_SOURCE " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
