"""Offline paired score corrections and leave-one-teammate-out error diagnosis."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_trees as modal
from app.research import score_stability as stability
from app.research.score_event_probability import event_probabilities, forecast_policy
from app.research.score_failure_review import activity_groups
from app.research.score_matchups_run import bank_from
from app.research.score_search import POSITIONS, cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval
from app.research.score_windows import window_centres

MOVES = np.array([0, -3, 3, -7, 7])
NATIVE_SHA = "d929567d90aba106c17a7caf958a3aaeefc21749f11efe6dca4ea90d374f39d0"


def score_options(base):
    return np.clip(base[:, None] + MOVES, 0, 100)


def compare(y, base, forecast, keep):
    old = np.abs(y[keep] - base[keep]) <= 7
    new = np.abs(y[keep] - forecast[keep]) <= 7
    rescued, spoiled = int((new & ~old).sum()), int((old & ~new).sum())
    return {
        "n": int(keep.sum()),
        "baseHits": int(old.sum()),
        "hits": int(new.sum()),
        "changed": int((base[keep] != forecast[keep]).sum()),
        "rescued": rescued,
        "spoiled": spoiled,
        "net": rescued - spoiled,
    }


def historical_rewards(rows, rewards, available, locks, sides):
    """Release all appearances of a past match together; pool the position per side once."""
    grouped = defaultdict(list)
    for i, row in enumerate(rows):
        club, opp = sides[i]
        grouped[available[i], row["game"], club, opp, row["pos"]].append(i)
    pending = iter(sorted(grouped.items()))
    event = next(pending, None)
    memories = defaultdict(lambda: deque(maxlen=30))
    result = np.zeros((len(rows), 15))
    for i in np.argsort(locks, kind="stable"):
        while event is not None and event[0][0] < locks[i]:
            (_, _, club, opp, position), ids = event
            mean = rewards[ids, 1:].mean(axis=0)
            memories["club", club, position].append(mean)
            memories["opp", opp, position].append(mean)
            for j in ids:
                memories["player", rows[j]["player"], position].append(rewards[j, 1:])
            event = next(pending, None)
        club, opp = sides[i]
        position = rows[i]["pos"]
        for col, key in enumerate((("club", club), ("opp", opp), ("player", rows[i]["player"]))):
            past = memories[(*key, position)]
            if past:
                result[i, 5 * col : 5 * col + 4] = np.sum(past, axis=0) / (len(past) + 10)
                result[i, 5 * col + 4] = len(past)
    return result


def diagnose(rows, sides, y, base, neutral_score, median, level, available, locks, cohort, games):
    neutral = level == 35
    rest = y - neutral_score
    gap = neutral_score - base
    np.testing.assert_allclose(y - base, rest + gap, rtol=0, atol=1e-12)
    miss = neutral & (np.abs(y - base) > 7)
    groups = defaultdict(list)
    for i in np.flatnonzero(neutral):
        groups[rows[i]["game"], sides[i][0], rows[i]["pos"]].append(i)
    options = score_options(base)
    correct = np.abs(y[:, None] - options) <= 7
    shared = base.copy()
    loo = base.copy()
    peer = np.full(len(y), np.nan)
    prior = np.full(len(y), np.nan)
    components = [activity_groups(games[r["game"]]["players"][r["player"]]["stats"]) for r in rows]
    raw_groups = {name: np.array([values[name] for values in components]) for name in components[0]}
    raw_sum = np.array([r["aa"] for r in rows])
    np.testing.assert_allclose(sum(raw_groups.values()), raw_sum, atol=1e-7, rtol=0)
    raw_groups["scoreFloorOrCap"] = y - (35 + raw_sum)
    raw_groups["negativeForecast"] = 35 - neutral_score
    pending = sorted(groups.values(), key=lambda ids: available[ids[0]])
    past = {}
    cursor = 0
    for ids in sorted(groups.values(), key=lambda ids: locks[ids[0]]):
        lock = locks[ids[0]]
        while cursor < len(pending) and available[pending[cursor][0]] < lock:
            completed = pending[cursor]
            j = completed[0]
            past[sides[j][0], rows[j]["pos"]] = float(np.median(rest[completed]))
            cursor += 1
        shared[ids] = options[ids, np.argmax(correct[ids].sum(axis=0))]
        for i in ids:
            if len(ids) >= 2:
                peer[i] = np.median([rest[j] for j in ids if j != i])
                loo[i] = options[i, np.argmin(np.abs(MOVES - peer[i]))]
            prior[i] = past.get((sides[i][0], rows[i]["pos"]), np.nan)
    out = {}
    for label, scope in {
        "all": np.ones(len(y), dtype=bool),
        "DEF": np.array([r["pos"] == "DEF" for r in rows]),
    }.items():
        known = scope & np.isfinite(peer)
        both = known & np.isfinite(prior)
        centered_peer = peer[known] - peer[known].mean()
        covariance_parts = {
            name: float(centered_peer @ values[known] / known.sum()) for name, values in raw_groups.items()
        }
        total_covariance = float(centered_peer @ rest[known] / known.sum())
        np.testing.assert_allclose(sum(covariance_parts.values()), total_covariance, atol=1e-8, rtol=0)
        out[label] = {
            "neutralSwitch": compare(y, base, neutral_score, scope & neutral),
            "neutralMedian": compare(y, base, median, scope & neutral),
            "neutralMissesWithAtLeast7OrdinaryError": int((scope & miss & (np.abs(rest) >= 7)).sum()),
            "neutralMissesWithAtLeast3PointChangeFromNeutralSwitch": int((scope & miss & (np.abs(gap) >= 3)).sum()),
            "commonOffsetUpperBound": compare(y, base, shared, scope & neutral),
            "commonOffsetUpperBoundWithPeers": compare(y, base, shared, known),
            "commonOffsetUpperBoundWithoutPeers": compare(y, base, shared, scope & neutral & ~known),
            "usingActualOtherTeammateErrors": compare(y, base, loo, known),
            "sameGameCovariance": {
                "total": total_covariance,
                "terms": covariance_parts,
                "definition": "Focal realized component points and the negative forecast, each against the median other teammate error. Additive, diagnostic only.",
            },
            "sameCaseCorrelations": {
                "n": int(both.sum()),
                "sameGame": correlation(rest[both], peer[both]),
                "previousAvailableGame": correlation(rest[both], prior[both]),
            },
        }
    return {
        "componentSource": "retained starter components"
        if cohort == "start"
        else "auxiliary model, not retained mixture",
        "positions": out,
    }


def correlation(x, y):
    return float(np.corrcoef(x, y)[0, 1]) if len(x) >= 2 and x.std() > 0 and y.std() > 0 else None


def snapshots(args, source, rows, cohort, read):
    match, stable, ordinary = (read(f"laliga_score_{name}") for name in ("match_context", "stability", "ordinary"))
    name = "team_share" if cohort == "start" else "mixture_shrunk"
    ref = read(f"laliga_score_{name}")
    if any(r["sourceKey"] != source["key"] for r in (match, stable, ordinary, ref)):
        raise ValueError("Source fingerprint mismatch")
    masks = stability.phase_masks(rows)
    call = SimpleNamespace(cache=args.cache, rows=rows)
    position = np.array([r["pos"] for r in rows])
    prior = None
    snapshots = {}
    for phase, _, _ in stability.PHASES:
        target = masks[phase]["target"]
        subset = [r for r, take in zip(rows, target, strict=True) if take]
        classes, probability, parts = flow.old_components(call, cohort, phase, match, stable, ordinary)
        if phase == "warm2023":
            prior = ((classes, probability, parts), subset)
            continue
        bank = bank_from(*prior, masks[phase]["first"])
        neutral = np.broadcast_to((classes == 35).astype(float), probability.shape)
        pos = position[target]
        median = np.clip(35 + empirical.location_scale(parts, "raw")[0][:, classes == 35].ravel(), 0, 100)
        neutral_score = empirical.empirical_predictions(classes, neutral, parts, pos, bank, 20, 0.75, 0)
        if cohort == "start":
            old = empirical.empirical_predictions(classes, probability, parts, pos, bank, 20, 0.75, 0)
            path = args.cache / f"laliga_score_team_share_start_{phase}_quality_half.npz"
            with np.load(path) as f:
                if str(f["key"]) != ref["implementationKey"]:
                    raise ValueError("Event-rate source differs")
                alternative = event_probabilities(classes, *f["rates"].T, "counts", probability)
            candidate = empirical.empirical_predictions(classes, alternative, parts, pos, bank, 20, 0.75, 0)
            base = forecast_policy(candidate, old, pos, "state_changes", "outfield")
            changed = (pos != "GK") & ((candidate >= 60) != (old >= 60))
            probability = np.where(changed[:, None], alternative, probability)
        else:
            path = args.cache / f"laliga_score_mixture_shrunk_bench_{phase}_k2_width32_l2verystrong_e160.npz"
            with np.load(path) as f:
                if str(f["key"]) != ref["implementationKey"]:
                    raise ValueError("Mixture source differs")
                np.testing.assert_array_equal(f["probability"], probability)
                base = window_centres(f["mass"], modal.CENTRES)
        actual = np.array([r["score"] for r in subset])
        expected = ref["cohorts"][cohort]
        if phase == "later2026":
            with np.load(args.cache / f"laliga_score_{name}_predictions_{cohort}.npz") as f:
                if str(f["key"]) != ref["implementationKey"]:
                    raise ValueError("Retained forecast source differs")
                np.testing.assert_array_equal(f["prediction"], base)
                np.testing.assert_array_equal(f["y"], actual)
            metrics = expected["later"]
        else:
            metrics = expected["winner"]["periods"][phase]["metrics"]
        if measure(actual, base) != metrics:
            raise ValueError(f"Retained {cohort} {phase} metrics differ")
        snapshots[phase] = (subset, base, neutral_score, median, probability[:, classes == 35].ravel())
        # The earlier residual bank is defined using the unchanged component probabilities.
        prior = ((classes, probability, parts), subset)
    return snapshots


def run(args):
    sys.path.insert(0, str(args.packages.resolve()))
    from sklearn.ensemble import HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads((args.cache / "cases.json").read_text())
    read = lambda name: json.loads((args.out.parent / f"{name}.json").read_text())
    raw = args.games.read_bytes()
    if hashlib.sha256(raw).hexdigest() != NATIVE_SHA:
        raise ValueError("Native archive fingerprint differs")
    games = {g["id"]: g for g in (json.loads(line) for line in raw.decode().splitlines() if line.strip())}
    report = {"sourceKey": source["key"], "scope": "Test only; reused historic cases", "cohorts": {}}
    for cohort in ("start", "bench"):
        snapshots_by_phase = snapshots(args, source, [r for r in source["rows"] if r["cohort"] == cohort], cohort, read)
        phases = list(snapshots_by_phase)
        rows = [r for snapshot in snapshots_by_phase.values() for r in snapshot[0]]
        labels = np.concatenate([np.repeat(p, len(snapshots_by_phase[p][0])) for p in phases])
        base, neutral_score, median, p_neutral = (
            np.concatenate([snapshot[i] for snapshot in snapshots_by_phase.values()]) for i in (1, 2, 3, 4)
        )
        sides = []
        for r in rows:
            g = games[r["game"]]
            person = g["players"][r["player"]]
            club = person["team"]
            home, away = g["home"]["slug"], g["away"]["slug"]
            if (
                club not in (home, away)
                or person["ver"] != 7
                or person["started"] != (cohort == "start")
                or r["date"] != g["date"]
                or any(abs(r[k] - person[k]) > 1e-7 for k in ("aa", "level", "score"))
            ):
                raise ValueError("Native identity or outcome differs")
            sides.append((club, away if club == home else home))
        y, level = (np.array([r[k] for r in rows]) for k in ("score", "level"))
        available = np.array([(moment(r["date"]) + timedelta(hours=48)).timestamp() for r in rows])
        locks = np.array([cutoff_for(r["date"]).timestamp() for r in rows])
        options = score_options(base)
        hits = (np.abs(y[:, None] - options) <= 7).astype(float)
        rewards = hits - hits[:, :1]
        history = historical_rewards(rows, rewards, available, locks, sides)
        fields = ("home", "match_lam_h", "match_lam_a", f"{cohort}_history_count", f"{cohort}_3_minutes")
        indices = [source["features"].index(k) for k in fields]
        context = np.column_stack(
            (
                base,
                neutral_score - base,
                median,
                p_neutral,
                [POSITIONS.index(r["pos"]) for r in rows],
                [[r["x"][j] for j in indices] for r in rows],
            )
        ).astype(float)
        bundles = {"matchAndPlayer": context, "withPastRescuesAndSpoils": np.column_stack((context, history))}
        scores = {name: {} for name in bundles}
        for phase in phases:
            current = labels == phase
            if phase == "later2026":
                passing = [name for name in bundles if all(r["all"]["net"] > 0 for r in scores[name].values())]
                args.out.with_suffix(f".{cohort}.selection.json").write_text(
                    json.dumps({"passing": passing, "results": scores}, indent=2)
                )
            else:
                passing = list(bundles)
            if not passing:
                continue
            active = current & np.array([r["date"] >= "2024-04-01" for r in rows]) if phase == "spring2024" else current
            fit = available < locks[active].min()
            if (fit & active).any():
                raise ValueError("Earlier fit overlaps the scored cases")
            for name in passing:
                features = bundles[name]
                gains = np.zeros((len(rows), len(MOVES)))
                for j in range(1, len(MOVES)):
                    model = HistGradientBoostingRegressor(
                        max_iter=65, max_leaf_nodes=7, min_samples_leaf=100, l2_regularization=10, early_stopping=False
                    )
                    model.fit(features[fit], rewards[fit, j])
                    gains[active, j] = model.predict(features[active])
                choices = np.where(gains.max(axis=1) >= 0.04, gains.argmax(axis=1), 0)
                forecast = options[np.arange(len(rows)), choices]
                scores[name][phase] = {
                    "fit": int(fit.sum()),
                    "active": int(active.sum()),
                    "all": compare(y, base, forecast, current),
                    "neutral": compare(y, base, forecast, current & (level == 35)),
                    "weekGain95": paired_interval(
                        y[current],
                        forecast[current],
                        base[current],
                        [r["week"] for r, keep in zip(rows, current, strict=True) if keep],
                    ),
                }
        later = labels == "later2026"
        selected_rows = [r for r, keep in zip(rows, later, strict=True) if keep]
        later_sides = [s for s, keep in zip(sides, later, strict=True) if keep]
        report["cohorts"][cohort] = {
            "diagnosis": diagnose(
                selected_rows,
                later_sides,
                y[later],
                base[later],
                neutral_score[later],
                median[later],
                level[later],
                available[later],
                locks[later],
                cohort,
                games,
            ),
            "tests": scores,
        }
        print(
            cohort,
            {name: {p: v["all"]["net"] for p, v in results.items()} for name, results in scores.items()},
            flush=True,
        )
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/raw/score-foundation"))
    parser.add_argument("--packages", type=Path, default=Path("data/raw/formula-packages"))
    parser.add_argument("--out", type=Path, default=Path("reports/experiments/laliga_score_shared_error_recovery.json"))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
