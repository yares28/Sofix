"""Testing only: frozen-reference mixtures of three independently audited AA densities."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from app.research import score_analogues as analogues
from app.research import score_density_blend as density
from app.research import score_empirical_density as empirical
from app.research import score_flow as flow
from app.research import score_modal_capacity_run as controls
from app.research import score_ordinary as ordinary
from app.research import score_quantile_curve as curve
from app.research import score_shared_windows as normalising
from app.research import score_stability as stability
from app.research import score_windows as windows
from app.research.score_modal_trees import CENTRES
from app.research.score_search import cutoff_for, measure, moment
from app.research.score_stats_run import paired_interval

FAMILIES = {
    "mixture": ("laliga_score_mixture_shrunk", 160),
    "bands": ("laliga_score_histogram_ordinary", 240),
    "quantiles": ("laliga_score_quantile_curve", 240),
}
WEIGHTS = (0.05, 0.1, 0.25, 0.5, 0.75, 1.0)


def implementation_key(source, reports, plan):
    modules = (density, analogues, empirical, flow, controls, ordinary, curve, normalising, stability, windows)
    return hashlib.sha256(
        (source["key"] + "".join(reports[n]["implementationKey"] for n in sorted(reports)) + np.__version__).encode()
        + Path(__file__).read_bytes()
        + plan.read_bytes()
        + b"".join(Path(m.__file__).read_bytes() for m in modules)
    ).hexdigest()


def reference(call, key, source, cohort, phase, masks, reports):
    old_match, old_stability, old_ordinary, old_bench = (
        reports[n]
        for n in (
            "laliga_score_match_context",
            "laliga_score_stability",
            "laliga_score_ordinary",
            "laliga_score_analogues",
        )
    )
    control = controls.control_for(
        call, key, source, cohort, phase, masks, old_match, old_stability, old_ordinary, old_bench
    )
    mask = masks[phase]
    old = flow.old_components(call, cohort, phase, old_match, old_stability, old_ordinary)
    if cohort == "start":
        phases = [p[0] for p in stability.PHASES]
        previous_phase = phases[phases.index(phase) - 1]
        previous = flow.old_components(call, cohort, previous_phase, old_match, old_stability, old_ordinary)
        previous_rows = [r for r, yes in zip(call.rows, masks[previous_phase]["target"], strict=True) if yes]
        pieces = stability.starter_control(previous, old, previous_rows, mask["first"])
        positions = np.array([r["pos"] for r, yes in zip(call.rows, mask["target"], strict=True) if yes])
        mass = density.empirical_mass(*pieces[:3], positions, pieces[3])
        original = windows.window_centres(mass, CENTRES)
        receipt = dict(
            kind="original_empirical",
            previousPhase=previous_phase,
            bankCases=pieces[3]["cases"],
            bankUnknownPastClasses=pieces[3]["unknownLevels"],
        )
    else:
        spec = old_bench["cohorts"]["bench"]["winner"]
        if phase in ("autumn2025", "later2026"):
            ending = "selection" if phase == "autumn2025" else "later"
            path = call.cache / f"analogues_bench_{spec['group']}_{ending}.npz"
            expected = old_bench["implementationKey"]
        else:
            path = call.cache / f"{call.out.stem}_analogue_{phase}.npz"
            expected = key
        with np.load(path) as f:
            if str(f["key"]) != expected:
                raise ValueError("Reference neighbour-cache identity differs")
            indices, distance = f["indices"], f["distance"]
        available = np.array([moment(r["date"]).timestamp() + 172800 for r in call.rows])
        pos = np.array([r["pos"] for r in call.rows])
        locks = np.array([cutoff_for(r["date"]).timestamp() for r in call.rows])[mask["target"]]
        valid, safe = indices >= 0, np.maximum(indices, 0)
        if np.any(valid & ((available[safe] >= locks[:, None]) | (pos[safe] != pos[mask["target"], None]))):
            raise ValueError("Reference density has unavailable/wrong-position neighbour")
        prepared = analogues.prepare_lookup(call.rows, mask["target"], mask["fit"], indices, distance)
        mass, original, stats = density.lookup_mass(prepared, spec)
        receipt = dict(
            kind="original_neighbours",
            path=str(path),
            key=expected,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            statistics=stats,
            allNeighboursStrictlyAvailableAndSamePosition=True,
            normalizedTieDecisionDifferences=int((windows.window_centres(mass, CENTRES) != original).sum()),
        )
    if not np.array_equal(original, control):
        raise ValueError("Reference full-density decision does not reproduce exact frozen control")
    return mass, control, old, receipt


def parent_mass(args, cohort, phase, family, old, report):
    stem, iterations = FAMILIES[family]
    frozen_path = args.out.parent / f"{stem}.{cohort}.frozen.json"
    frozen = json.loads(frozen_path.read_text())
    if frozen["implementationKey"] != report["implementationKey"]:
        raise ValueError("Parent earlier-frozen density choice differs")
    model = frozen["best"]["spec"]["model"]
    suffix = f"_{model}" if family != "quantiles" else ""
    path = args.cache / f"{stem}_{cohort}_{phase}{suffix}_e{iterations}.npz"
    with np.load(path) as f:
        stats = json.loads(str(f["statistics"]))
        if (
            str(f["key"]) != report["implementationKey"]
            or not np.array_equal(f["classes"], old[0])
            or not np.array_equal(f["probability"], old[1])
            or stats.get("epochs", stats.get("iterations")) != iterations
        ):
            raise ValueError("Parent density class/event/source identity differs")
        if family == "quantiles":
            parts = {q: f[f"q{q}"] for q in curve.QUANTILES}
            mass = curve.forecast_mass(old[0], old[1], parts, model)
        else:
            mass = f["mass"]
    if mass.shape != (len(old[1]), 201):
        raise ValueError("Parent density lost forecast cases")
    return density.validate_mass(mass), dict(
        family=family,
        path=str(path),
        model=model,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        parentKey=report["implementationKey"],
        iterations=iterations,
        earlierFrozenSha256=hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
    )


def records():
    return [
        dict(spec=dict(family=f, weight=w, scope=s), gains=[], errors=[], counts=[], periods={})
        for f in FAMILIES
        for w in WEIGHTS
        for s in ("all", "defmid")
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "cache", "packages", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--cohort", choices=("start", "bench", "both"), default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.packages.resolve()))
    from threadpoolctl import threadpool_limits

    threadpool_limits(limits=2)
    source = json.loads(args.cases.read_text())
    names = (
        "laliga_score_match_context",
        "laliga_score_stability",
        "laliga_score_ordinary",
        "laliga_score_match_empirical_density",
        "laliga_score_analogues",
        *[v[0] for v in FAMILIES.values()],
    )
    reports = {n: json.loads((args.out.parent / (n + ".json")).read_text()) for n in names}
    if any(r["sourceKey"] != source["key"] for r in reports.values()):
        raise ValueError("Density combination canonical source differs")
    for stem, _ in FAMILIES.values():
        audit = json.loads((args.out.parent / (stem + ".integrity.json")).read_text())
        if audit["implementationKey"] != reports[stem]["implementationKey"] or set(audit["cohorts"]) != {
            "start",
            "bench",
        }:
            raise ValueError("Parent full native/real-refit density audit absent")
    key = implementation_key(source, reports, args.out.with_suffix(".plan.json"))
    report = dict(
        scope="Testing-only full-distribution shrinkage, no application changes",
        sourceKey=source["key"],
        implementationKey=key,
        evidenceLimit="Repeated historical reuse; exploratory not fresh blind proof",
        cohorts={},
    )
    if args.out.exists():
        saved = json.loads(args.out.read_text())
        if saved["implementationKey"] == key:
            report = saved
    for cohort in ("start", "bench") if args.cohort == "both" else (args.cohort,):
        rows = [r for r in source["rows"] if r["cohort"] == cohort]
        masks, candidates = stability.phase_masks(rows), records()
        y, positions = np.array([r["score"] for r in rows]), np.array([r["pos"] for r in rows])
        call = SimpleNamespace(rows=rows, cache=args.cache, out=args.out)
        evidence = {}
        winner = best = None
        for phase, _, _ in stability.PHASES[1:]:
            target = masks[phase]["target"]
            if phase == "later2026" and best is None:
                raise ValueError("Density combination must freeze before 2026")
            active = [best] if phase == "later2026" else candidates
            print(f"DENSITY_BLEND_REFERENCE {cohort} {phase}", flush=True)
            base, control, old, receipt = reference(call, key, source, cohort, phase, masks, reports)
            expected = (
                reports["laliga_score_stability"]["cohorts"][cohort]["earlierPeriods"][phase]["control"]
                if phase != "later2026"
                else reports["laliga_score_match_empirical_density" if cohort == "start" else "laliga_score_analogues"][
                    "cohorts"
                ][cohort]["later"]
            )
            metric = measure(y[target], control)
            if metric != expected:
                raise ValueError("Density combination strongest control metrics differ")
            evidence[phase] = dict(reference=receipt, control=metric, parents={})
            parent_densities = {}
            for family in sorted({r["spec"]["family"] for r in active}):
                parent_densities[family], parent_receipt = parent_mass(
                    args, cohort, phase, family, old, reports[FAMILIES[family][0]]
                )
                evidence[phase]["parents"][family] = parent_receipt
            for record in active:
                spec = record["spec"]
                forecast, _ = density.forecast(
                    base, parent_densities[spec["family"]], spec["weight"], control, positions[target], spec["scope"]
                )
                cm = measure(y[target], forecast)
                if phase == "later2026":
                    alternate = forecast
                else:
                    gain = cm["within7"] - metric["within7"]
                    record["gains"].append(gain)
                    record["errors"].append(cm["mae"])
                    record["counts"].append(len(forecast))
                    record["periods"][phase] = dict(gain=gain, metrics=cm)
            if phase == "autumn2025":
                winner, best = stability.choose_stable(candidates)
                frozen = dict(
                    implementationKey=key,
                    winner=winner,
                    best=best,
                    candidates=candidates,
                    passingCandidates=sum(min(r["gains"]) > 0 for r in candidates),
                )
                args.out.with_name(args.out.stem + f".{cohort}.frozen.json").write_text(
                    json.dumps(frozen, indent=2, allow_nan=False)
                )
                print(
                    "DENSITY_BLEND_FROZEN "
                    + json.dumps(dict(cohort=cohort, passing=frozen["passingCandidates"], spec=best["spec"])),
                    flush=True,
                )
        prediction = alternate if winner else control.copy()
        h1, h0 = np.abs(y[target] - alternate) <= 7, np.abs(y[target] - control) <= 7
        weeks = [r["week"] for r, yes in zip(rows, target, strict=True) if yes]
        result = dict(
            selected="candidate" if winner else "control",
            winner=winner,
            candidate=best,
            candidateCount=len(candidates) + 1,
            earlierPeriods=evidence,
            later=measure(y[target], prediction),
            candidateLater=measure(y[target], alternate),
            control=measure(y[target], control),
            candidateGain95=paired_interval(y[target], alternate, control, weeks),
            candidateGainedCorrect=int((h1 & ~h0).sum()),
            candidateLostCorrect=int((h0 & ~h1).sum()),
        )
        np.savez_compressed(
            args.cache / f"{args.out.stem}_predictions_{cohort}.npz",
            key=key,
            y=y[target],
            prediction=prediction,
            alternate=alternate,
            control=control,
        )
        report["cohorts"][cohort] = result
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False))
        print(
            "RESULT "
            + json.dumps(dict(cohort=cohort, selected=result["selected"], candidateLater=result["candidateLater"])),
            flush=True,
        )


if __name__ == "__main__":
    main()
